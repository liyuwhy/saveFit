package com.fitmix.sdk;

import android.os.Environment;

import java.io.File;

/**
 * 系统级别的配置常量
 */
public class Config {

    // 内网:       http://192.168.136.33:8180  http://192.168.136.85:8080(联调)
    // 外网测试:   http://app.igeekery.com:80
    // 外网正式：  https://appt.igeekery.com:443
    //       http://appt.igeekery.com:80
    /**
     * 后台服务器主机地址
     */
    public static final String API_HOST = "https://appt.igeekery.com";//"https://appt.igeekery.com";//"http://appt.igeekery.com";//"http://192.168.136.33";//"http://192.168.136.7";//


    /**
     */
    public static final String API_PORT = ":443";// ":443";//":80";//":8180";//":8080";//


    /**
     * 是否使用https,true:是,false:否
     */
    public static final boolean USE_HTTPS = true;

    /**
     * 匿名(未登录)用户编号,默认是-1
     */
    public static final int ANONYMOUS_UID = -1;

    /**
     * 图片资源服务器地址
     */
    public static final String RESOURCE_HOST = "http://yyssb.ifitmix.com/";

    //region ===================== 本地文件夹配置 =====================
    /**
     * 乐享动根文件夹名称
     */
    public static final String PRODUCT_DIR = "fitmix";
    /**
     * 乐享动根文件夹路径
     */
    public static final String PATH_APP_STORAGE = Environment
            .getExternalStorageDirectory().getAbsolutePath()
            + File.separator
            + PRODUCT_DIR + File.separator;
    /**
     * 乐享动音乐下载文件夹路径
     */
    public static final String PATH_DOWN_MUSIC = PATH_APP_STORAGE + "Music" + File.separator;
    /**
     * 乐享动缓存文件夹路径
     */
    public static final String PATH_CACHE = PATH_APP_STORAGE + "Cache" + File.separator;


    /**
     * 乐享动日志文件夹路径
     */
    public static final String LOGGER_CACHE = PATH_APP_STORAGE + "Logger" + File.separator;
    /**
     * 乐享动固件传输时间日志文件夹路径
     */
    public static final String LOGGER_FIRMSEND = PATH_APP_STORAGE + "Logger_firmSendTime" + File.separator;
    /**
     * 乐享动音乐缓存文件夹名
     */
    public static final String MUSIC_CACHE_DIR_NAME = "music_cache";
    /**
     * 乐享动音乐缓存文件夹路径
     */
    public static final String PATH_MUSIC_CACHE = PATH_CACHE + MUSIC_CACHE_DIR_NAME + File.separator;

    /**
     * 乐享动音乐封面下载文件夹路径
     */
    public static final String PATH_DOWN_PICTURE = PATH_APP_STORAGE + "Picture/";
    /**
     * 乐享动运动轨迹下载文件夹路径
     */
    public static final String PATH_DOWN_TRAIL = PATH_APP_STORAGE + "Trail" + File.separator;
    /**
     * 乐享动运动步数下载文件夹路径
     */
    public static final String PATH_DOWN_STEP = PATH_APP_STORAGE + "Step" + File.separator;
    /**
     * 乐享动跳绳计数下载文件夹路径
     */
    public static final String PATH_DOWN_SKIP = PATH_APP_STORAGE + "Skip" + File.separator;
    /**
     * 乐享动运动直播拍照下载文件夹路径
     */
    public static final String PATH_RUN_PHOTO = PATH_APP_STORAGE + "Photos" + File.separator;
    /**
     * 乐享动运动直播声效下载文件夹路径
     */
    public static final String PATH_RUN_VOICE = PATH_APP_STORAGE + "Voice" + File.separator;
    /**
     * 乐享动音乐专辑封面下载文件夹路径
     */
    public static final String PATH_LOCAL_COVER = PATH_APP_STORAGE + "Cover" + File.separator;
    /**
     * 乐享动临时文件(比如分享等)文件夹路径
     */
    public static final String PATH_LOCAL_TEMP = PATH_APP_STORAGE + "Temp" + File.separator;
    /**
     * 乐享动语音包文件夹路径
     */
    public static final String PATH_LOCAL_VOICE = PATH_APP_STORAGE + "Speak" + File.separator;
    /**
     * 乐享动话题文件夹路径
     */
    public static final String PATH_TOPIC = PATH_APP_STORAGE + "Topic" + File.separator;
    /**
     * 乐享动话题用户头像文件夹路径
     */
    public static final String PATH_TOPIC_AVATAR = PATH_APP_STORAGE + "Topic" + File.separator;
    /**
     * 后台下载下来的zip语音压缩包的通用语音子目录文件夹名  common
     */
    public static final String PATH_LOCAL_VOICE_COMMON = "common" + File.separator;
    /**
     * 后台下载下来的语音压缩包的心率子目录文件夹名  hrVoice
     */
    public static final String PATH_LOCAL_VOICE_HRVOICE = "hrVoice" + File.separator;

    /**
     * 乐享动语音包下跑步文件夹路径
     */
    public static final String PATH_LOCAL_VOICE_RUN = PATH_LOCAL_VOICE + "Run" + File.separator;
    /**
     * 乐享动语音包下跳绳文件夹路径
     */
    public static final String PATH_LOCAL_VOICE_SKIP = PATH_LOCAL_VOICE + "Skip" + File.separator;

    /**
     * 后台下载下来的心率耳机固件zip压缩包的子目录文件夹
     */
    public static final String PATH_LOCAL_FIRMWARE_VERSION_FILE = PATH_APP_STORAGE + "Firmware" + File.separator;

    /**
     * QQ sdk 分享图片临时文件夹
     */
    public static final String PATH_QQ_SDK_SHARE_IMG = Environment
            .getExternalStorageDirectory().getAbsolutePath()
            + File.separator + "tmp";

    //endregion ===================== 本地文件夹配置 =====================

    //region ===================== 数据库配置 =====================
    /**
     * 本地数据库名称
     */
    public static final String DB_NAME = "realm.db";

    //endregion ===================== 数据库配置 =====================

    //region ===================== 模块编号 =====================
    /**
     * 用户模块编号 100000
     */
    public static final int MODULE_USER = 100000;
    /**
     * 音乐模块编号 200000
     */
    public static final int MODULE_MUSIC = 200000;
    /**
     * 运动记录编号 300000
     */
    public static final int MODULE_SPORT = 300000;
    /**
     * 俱乐部模块编号 400000
     */
    public static final int MODULE_CLUB = 400000;
    /**
     * 赛事模块编号 500000
     */
    public static final int MODULE_COMPETITION = 500000;

    //endregion ================== 模块编号 =====================

    //region ===================== 缓存有效期 ======================
    /**
     * 缓存有效期 1分钟,单位为毫秒
     */
    public static final long CACHE_1_MINUTE = System.currentTimeMillis() + 60000;
    /**
     * 缓存有效期 5分钟,单位为毫秒
     */
    public static final long CACHE_5_MINUTE = System.currentTimeMillis() + 300000;
    /**
     * 缓存有效期 15分钟,单位为毫秒
     */
    public static final long CACHE_15_MINUTE = System.currentTimeMillis() + 900000;
    /**
     * 缓存有效期 1小时,单位为毫秒
     */
    public static final long CACHE_1_HOUR = System.currentTimeMillis() + 3600000;
    /**
     * 缓存有效期 1天,单位为毫秒
     */
    public static final long CACHE_1_DAY = System.currentTimeMillis() + 86400000;
    /**
     * 缓存有效期 在不注销登录时永久有效
     */
    public static final long CACHE_FOREVER = Long.MAX_VALUE;
    /**
     * 缓存有效期 设置有效期失效
     */
    public static final long CACHE_USELESS = 0;//
    /**
     * 忽略缓存
     */
    public static final long CACHE_IGNORE = 0;//System.currentTimeMillis();

    //endregion ================== 缓存有效期 ======================

    //region ===================== SharedPreferences相关 ======================

    //region ##################### SharedPreferences文件名 #####################
    /**
     * 用户信息模块SharedPreferences文件名
     */
    public static final String PREFS_USER = "prefs_user";
    /**
     * 俱乐部模块SharedPreferences文件名
     */
    public static final String PREFS_CLUB = "prefs_club";
    /**
     * 运动模块SharedPreferences文件名
     */
    public static final String PREFS_SPORT = "prefs_sport";
    /**
     * 音乐模块SharedPreferences文件名
     */
    public static final String PREFS_MUSIC = "prefs_music";
    /**
     * 赛事模块SharedPreferences文件名
     */
    public static final String PREFS_COMPETITION = "prefs_competition";
    /**
     * App V2.1.2之前用到的SharedPreferences文件名,兼容用
     */
    public static final String PREFS_OLD = "config";
    //endregion ################## SharedPreferences文件名 #####################

    //region ##################### PREFS_USER文件中的键名 #####################
//    /** 是否第一次启动乐享动app,boolean型,true:是,false:否*/
//    public static final String SP_KEY_FIRST_USE = "first_startup";
    /**
     * 服务器返回的API token SP键名,String型
     */
    public static final String SP_KEY_API_TOKEN = "api_token";
    /**
     * 用户UID SP键名,int型
     */
    public static final String SP_KEY_UID = "uid";
    /**
     * app是否被系统杀死键名,boolean型
     */
    public static final String SP_KEY_RUNNING_IF_KILLED = "running_if_killed";
    /**
     * 上一次登录的类型,int型,-1:表示未登录,1:表示邮箱登录,2:表示QQ授权登录,3:表示微信授权登录,4:表示新浪微博授权登录,5:表示手机登录
     */
    public static final String SP_KEY_LAST_LOGIN_TYPE = "last_login_type";
    /**
     * 上一次登录的邮箱账号 SP键名,String型
     */
    public static final String SP_KEY_LAST_USER = "last_user";
    /**
     * 上一次登录的密码 SP键名,String型
     */
    public static final String SP_KEY_LAST_PWD = "last_pwd";
    /**
     * GAIA连接的蓝牙地址 SP键名,String型
     */
    public static final String SP_KEY_GAIA_ADDRESS = "gaia_address";
    /**
     * 音乐缓存上限
     */
    public static final String SP_KEY_MUSIC_CACHE_SIZE = "music_cache_size";
    /**
     * 音乐缓存的默认大小,单位为MB,默认为200M
     */
    public static final int SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE = 200;//音乐缓存的默认大小，单位为MB

//    /** 是否第一次进入MineFragment的标示*/
//    public static final String SP_KEY_IS_FIRST_MINE = "isFirstMine";
    /**
     * 是否第一次创建训练计划标示
     */
    public static final String SP_KEY_IS_FIRST_CREATE_TRAIN_PLAN = "isFirstCreate";

    /**
     * 最近一次查看金币任务的时间,long型.只要不是今天,都在主界面显示红点提示
     */
    public static final String SP_KEY_LAST_VIEW_COIN_TASK_TIME = "lastViewCoinTask";
    /**
     * 是否是新的邮箱注册用户,boolean型
     */
    public static final String SP_KEY_IS_NEW_EMAIL_REGISTER = "isNewEmailRegister";
    /**
     * 是否是新的手机注册用户,boolean型
     */
    public static final String SP_KEY_IS_NEW_PHONE_REGISTER = "isNewPhoneRegister";

    /**
     * app 上一版本的Version code,int型
     */
    public static final String SP_KEY_APP_VERSION_CODE = "app_version_code";
    /**
     * app 上一次连接的心率耳机的mac地址,String型
     */
    public static final String SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS = "heart_rate_head_set_mac_address";

    /**
     * 加密公钥下载地址,String型
     */
    public static final String SP_KEY_PUBLIC_KEY_URL = "public_key_url";

    /**
     * IRON CLOUD手表设置信息(WatchSetting)json字符串,String型
     */
    public static final String SP_KEY_WATCH_SETTING = "watch_setting";

    /**
     * IRON CLOUD手表固件版本升级信息(WatchUpgrade)json字符串,String型
     */
    public static final String SP_KEY_WATCH_FIRM_UPGRADE = "watch_firm_upgrade";

    /**
     * 手表是否开启来电提醒,boolean型
     */
    public static final String SP_KEY_WATCH_CALL_NOTIFY = "watch_call_notify";

    /**
     * 手表是否开启短信提醒,boolean型
     */
    public static final String SP_KEY_WATCH_SMS_NOTIFY = "watch_sms_notify";

    /**
     * 手表APP消息通知设置(WatchAppNotify)json字符串,String型
     */
    public static final String SP_KEY_WATCH_APP_NOTIFY = "watch_app_notify";

    /**
     * 手表天气城市设置(WatchWeatherCity)json字符串,String型
     */
    public static final String SP_KEY_WATCH_WEATHER_CITY = "watch_weather_city";

    /**
     * 手表大文件发送信息(WatchBigFile)json字符串,String型
     */
    public static final String SP_KEY_WATCH_BIG_FILE = "watch_big_file";

    /**
     * 手表固件正在传输给手表的版本号,int型  0:代表没有在断点续传  非0：代表正在断点续传
     */
    public static final String SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION = "watch_firm_is_updating_version";

    /**
     * 强制手表固件升级是否正在传输给手表，boolean
     */
    public static final String SP_KEY_WATCH_FIRM_UPDATE_FORCE = "watch_firm_is_update_force";

    /**
     * 选择手表固件升级是否正在传输给手表，boolean
     */
    public static final String SP_KEY_WATCH_FIRM_UPDATE_SELECT = "watch_firm_is_update_select";

    /**
     * 手表固件正在传输给手表的进度,int型
     */
    public static final String SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS = "watch_firm_is_updating_version_progress";

    /**
     * 后台最新手表固件版本号,int型
     */
    public static final String SP_KEY_WATCH_FIRM_NEWEST = "watch_firm_newest_version";

    /**
     * IRON CLOUD手表日常数据信息(WatchDailyData)json字符串,String型
     */
    public static final String SP_KEY_WATCH_DAILY = "watch_daily";

//    /**
//     * 手表是否开启仅熄屏时APP消息通知,boolean型
//     */
//    public static final String SP_KEY_WATCH_APP_NOTIFY_SCREEN_OFF = "watch_app_notify_screen_off";

    //endregion ################## PREFS_USER文件中的键名 #####################

    //region ##################### PREFS_CLUB文件中的键名 #####################
    /**
     * 未处理的邀请俱乐部ID列表,以英文逗号分隔
     */
    public static final String SP_KEY_INVITE_CLUB_IDS = "invite_club_ids";
    /**
     * 未处理的邀请俱乐部名称列表,以英文逗号分隔
     */
    public static final String SP_KEY_INVITE_CLUB_NAMES = "invite_club_names";

    //endregion ##################### PREFS_CLUB文件中的键名 #####################

    //region ##################### PREFS_SPORT文件中的键名 #####################
    /**
     * 上一次运动是否已正常结束 SP键名,boolean型, true:是,false:否
     */
    public static final String SP_KEY_LAST_RUN_FINISHED = "last_run_finished";
    /**
     * 保存上一次运动是否已正常结束的时间戳 SP键名,long型
     */
    public static final String SP_KEY_LAST_RUN_SAVE_TIME = "last_run_saveTime";
    /**
     * 今日步数,保存在prefs_sport中,int型
     */
    public static final String SP_KEY_TODAY_STEPS = "today_steps";
    /**
     * 记录今日步数的时间,保存在prefs_sport中,long型
     */
    public static final String SP_KEY_TODAY_STEPS_TIME = "today_steps_time";
    /**
     * 运动过程中保存的运动开始时间,运动开始时设置,运动结束时设置为-1,long型
     */
    public static final String SP_KEY_START_TIME = "run_start_ime";
    /**
     * 运动过程中保存的跳绳开始时间,跳绳开始时设置,跳绳结束时设置为-1,long型
     */
    public static final String SP_KEY_START_TIME_SKIP = "skip_start_ime";

    /**
     * 跳绳运动语音播报的频率
     */
    public static final String SY_KEY_SIRI_RATE_SKIP = "skip_siri_rate";
    /**
     * 跳绳运动语音播报的默认频率
     */
    public static final int SY_KEY_SIRI_RATE_SKIP_DEFAULT = 20;
    /**
     * 1.室外运动时,保存定位前的运动距离(未正常结束的距离+本次定位之前的G-SENSOR运动距离)
     * 2.室内运动时,保存未正常结束的距离
     * long型
     */
    public static final String SP_KEY_LAST_RUN_DISTANCE = "last_run_distance";
    /**
     * 上一次非正常结束运动时的步数,int型
     */
    public static final String SP_KEY_LAST_RUN_STEPS = "last_run_steps";

//    /** 从后台服务器最近一次获取用户历史跑步记录的时间戳,long型*/
//    public static final String SP_KEY_RUN_RECORD_SYNC_TIME = "run_record_sync_time";

    /**
     * 最近一次同步微信步数的结果,String型
     */
    public static final String SP_KEY_SYNC_WECHAT_STEP = "sync_wechat_step";

    /**
     * 当前是否在跑步运动,boolean型
     */
    public static final String SP_KEY_RUN_SPORT = "isRunning";

    /**
     * 用户跑步运动设置距离跑选择值的滚轮下标,int型
     */
    public static final String SP_KEY_DISTANCE_RUN_INDEX = "distance_run_index";
    /**
     * 用户跑步运动设置时间跑选择值的滚轮下标,int型
     */
    public static final String SP_KEY_DURATION_RUN_INDEX = "duration_run_index";
    /**
     * 用户跑步运动设置卡路里跑选择值的滚轮下标,int型
     */
    public static final String SP_KEY_CALORIE_RUN_INDEX = "calorie_run_index";
    /**
     * 用户跑步运动设置配速跑选择值的滚轮下标,int型
     */
    public static final String SP_KEY_PACE_RUN_INDEX = "pace_run_index";
    /**
     * 跑步记录分享的基础url,String型
     */
    public static final String SP_KEY_RUN_SHARE_URL = "run_share_url";
    /**
     * app下载二维码,用于图片分享,String型
     */
    public static final String SP_KEY_APP_DOWNLOAD_QR = "app_download_qr";

    /**
     * 是否提示用户设置app后台运行权限,boolean型
     */
    public static final String SP_KEY_BACKGROUND_RUN_PERMISSION = "app_back_run_permission";

    //endregion ################## PREFS_SPORT文件中的键名 #####################

    //region ##################### PREFS_COMPETITION文件中的键名 #####################
    /**
     * 话题答案分享的基础url,String型
     */
    public static final String SP_KEY_TOPIC_ANSWER_SHARE = "topic_answer_share";
    //endregion ################## PREFS_COMPETITION文件中的键名 #####################

    //region ##################### PREFS_MUSIC文件中的键名 #####################

    //endregion ################## PREFS_MUSIC文件中的键名 #####################

    //endregion ===================== SharedPreferences相关 ======================

    //region ======================== Handler消息编号相关 ================================
    /**
     * 每秒刷新消息编号
     */
    public static final int MSG_REPEAT_EVERY_SECOND = 1002;
    /**
     * 每秒刷新消息编号
     */
    public static final int MSG_REPEAT_EVERY_SECOND_SKIP = 1200;
    /**
     * 启动锁屏界面消息编号
     */
    public static final int MSG_START_LOCK_SCREEN = 1006;
    /**
     * 动画倒计时消息编号
     */
    public static final int MSG_ANIMATION_TIMER = 1007;
    /**
     * 请求跳绳数据
     */
    public static final int MSG_SKIP_QUEST_TIMER = 1009;
    /**
     * 同步跑步记录任务完成消息编号
     */
    public static final int MSG_SYNC_TASK_DONE = 1008;

    //endregion ===================== Handler消息编号相关 ================================

    //region ================================ 地图定位相关 ================================
    /**
     * 定位类型,未知
     */
    public static final int LOCATION_TYPE_NONE = 0;
    /**
     * 定位类型,GPS定位
     */
    public static final int LOCATION_TYPE_GPS = 1;
    /**
     * 定位类型,网络定位
     */
    public static final int LOCATION_TYPE_LBS = 2;
    /**
     * GPS定位点可接受的最小精度,用于过滤GPS点
     */
    public static final int GPS_AVAILABLE_ACCURACY = 80;
    /**
     * 地图显示时镜头放大倍数
     */
    public static final int MAP_CAMERA_ZOOM = 16;
    /**
     * 地图显示时镜头最大放大倍数
     */
    public static final int MAP_CAMERA_ZOOM_MAX = 16;
    /**
     * 地图显示时镜头最小放大倍数
     */
    public static final int MAP_CAMERA_ZOOM_MIN = 12;
    /**
     * 地图画轨迹时,定位精度大于60米画虚线
     */
    public static final int GPS_ACCURACY_DOT = 60;
    //endregion ================================ 地图定位相关 ================================

    //region ================================ 数据库参数配置表参数名 ================================
    /**
     * 语音播报语调,int型,0:男声,1:女声.默认女声
     */
    public static final String SETTING_SIRI_TONE_TYPE = "settingSiriToneType";
    /**
     * 语音播报语调类型 男声
     */
    public static final int SIRI_TONE_TYPE_MALE = 0;
    /**
     * 语音播报语调类型 女声
     */
    public static final int SIRI_TONE_TYPE_FEMALE = 1;
    /**
     * 后台下载下来的zip语音压缩包的根目录文件夹 string型 如femaleVoiceEn
     */
    public static final String SETTING_VOICE_PACKAGE_DIR = "settingVoicePackageDir";
    /**
     * 当前语音播报 语音包类型 string型 如female、Run/female_en或者Skip/female_en等,默认为female即标准女声
     */
    public static final String SETTING_VOICE_PACKAGE_TYPE = "settingVoicePackageType";
    /**
     * 语音包类型 默认语音的话为空""，非正常的话为:female_en，类似
     */
    public static final String SETTING_VOICE_PACKAGE_VOICE_TYPE = "settingVoicePackageVoiceType";
    /**
     * 语音包名称 string型 如标准女声、英文女声等
     */
    public static final String SETTING_VOICE_PACKAGE_NAME = "settingVoicePackageName";
    /**
     * 已下载的语音包列表信息 显示下架已下载的语音包信息
     */
    public static final String SETTING_VOICE_PACKAGE_INFO = "settingVoicePackageInfo";
    /**
     * 已下载的语音包版本号,int型
     */
    public static final String SETTING_VOICE_PACKAGE_INFO_VERSION = "settingVoicePackageInfoVersion";
    /**
     * 语音播报距离下标,0:关闭,1:0.25公里,2:0.5公里,3:1公里,4:5公里,默认1公里,下标为3
     */
    public static final String SETTING_SIRI_DISTANCE = "settingSiriDistance";
    /**
     * 语音播报时间下标,0:关闭,1:1分钟,2:5分钟,3:10分钟,4:15分钟
     */
    public static final String SETTING_SIRI_TIME = "settingSiriTime";
    /**
     * 是否开启后台计步,boolean类型
     */
    public static final String SETTING_DAEMON_STEP_COUNTER = "settingDaemonStepCounter";
    /**
     * 是否在通知栏显示步数,boolean类型
     */
    public static final String SETTING_SHOW_STEP_IN_NOTIFICATION = "settingShowStepInNotification";
    /**
     * 是否在锁屏界面显示步数,boolean类型
     */
    public static final String SETTING_SHOW_STEP_IN_LOCK_SCREEN = "settingShowStepInLockScreen";
    /**
     * 是否开启消息推送,boolean类型
     */
    public static final String SETTING_MESSAGE_PUSH = "settingMessagePush";
    /**
     * 是否同步到QQ运动,boolean类型
     */
    public static final String SETTING_SYNC_TO_QQ_SPORT = "settingSyncQQSport";
    /**
     * 运动环境,1:室外,2:室内 int类型
     */
    public static final String SETTING_SPORT_ENVIRONMENT = "settingSportEnvironment";
    /**
     * 运动方式,1:跑步,2:跳绳 int类型
     */
    public static final String SETTING_SPORT_TYPE = "settingSportType";

    /**
     * 是否正在运动状态 boolean 类型
     */
    public static final String SETTING_IS_RUNNING = "isRunningStatus";

    /**
     * 运动方式,1:跑步
     */
    public static final int SPORT_TYPE_ALL = 0;
    /**
     * 运动方式,1:跑步
     */
    public static final int SPORT_TYPE_RUN = 1;
    /**
     * 运动方式,2:跳绳
     */
    public static final int SPORT_TYPE_SKIP = 2;
    /**
     * 运动方式,3:心率
     */
    public static final int SPORT_TYPE_HEART = 3;

    /**
     * 运动是否开启音乐 boolean类型
     */
    public static final String SETTING_SPORT_WITH_MUSIC = "settingSportWithMusic";
    /**
     * 运动是否开启语音播报 boolean类型
     */
    public static final String SETTING_SPORT_WITH_VOICE = "settingSportWithVoice";
    /**
     * 用户身高,单位为厘米 int型,默认172厘米
     */
    public static final String SETTING_USER_HEIGHT = "settingUserHeight";
    /**
     * 用户体重,单位为千克 int型,默认65千克
     */
    public static final String SETTING_USER_WEIGHT = "settingUserWeight";
    /**
     * 是否显示开放俱乐部 俱乐部假退出功能需要 boolean类型
     */
    public static final String SETTING_SHOW_OPEN_CLUB = "settingShowOpenClub";
    /**
     * 是否点击过手机绑定 我的消息提醒需要 boolean类型
     */
    public static final String SETTING_BIND_MOBILE = "settingBindMobile";
    /**
     * 配速跑语音播报间隔类型 int型,0:关闭 1:每30秒 2:每分钟 3:每两分钟 4:每5分钟 5:每十分钟
     */
    public static final String SETTING_PACE_RUN_VOICE_INTERVAL = "settingPaceRunVoiceInterval";
    /**
     * 定位信息,彩蛋接口、天气接口等需要 String类型 保存LocationInfo json字符串
     */
    public static final String SETTING_LOCATION_INFO = "settingLocationInfo";

    /**
     * 定位信息,当前是否在国外, boolean类型 true:国外  false:国内
     */
    public static final String SETTING_IS_ABROAD = "isAbroad";
    /**
     * 歌曲播放模式 单曲循环 0 列表循环 1 随机 2  int类型
     */
    public static final String SETTING_PLAY_MODE = "settingPlayModel";
//    /**
//     * 友盟推送设备token String类型
//     */
//    public static final String SETTING_DEVICE_TOKEN = "settingDeviceToken";
    /**
     * 用户性别,int型,1:男,2:女,默认为男
     */
    public static final String SETTING_USER_GENDER = "settingUserGender";
    /**
     * 性别,1:男
     */
    public static final int GENDER_MALE = 1;
    /**
     * 性别,2:女
     */
    public static final int GENDER_FEMALE = 2;
    /**
     * 用户年龄,int型,默认24
     */
    public static final String SETTING_USER_AGE = "settingUserAge";
    /**
     * 从后台服务器最近一次获取用户历史跑步记录的时间戳,long型
     */
    public static final String SETTING_RUN_RECORD_SYNC_TIME = "settingRunRecordSyncTime";
    /**
     * 从后台服务器最近一次获取用户历史跳绳记录的时间戳,long型
     */
    public static final String SETTING_SKIP_RECORD_SYNC_TIME = "settingSkipRecordSyncTime";
    /**
     * 用户昵称
     */
    public static final String SETTING_USER_NAME = "settingUserName";
    /**
     * 用户邮箱
     */
    public static final String SETTING_USER_EMAIL = "settingUserEmail";
    /**
     * 用户手机号码
     */
    public static final String SETTING_USER_MOBILE = "settingUserMobile";
    /**
     * 用户头像 网络url地址
     */
    public static final String SETTING_USER_AVATAR = "settingUserAvatar";
    /**
     * 用户QQ昵称
     */
    public static final String SETTING_USER_QQ_NAME = "settingUserQQName";
    /**
     * 用户微博昵称
     */
    public static final String SETTING_USER_WB_NAME = "settingUserWBName";
    /**
     * 用户微信昵称
     */
    public static final String SETTING_USER_WX_NAME = "settingUserWXName";
    /**
     * 用户QQ OpenId
     */
    public static final String SETTING_USER_QQ_OPENID = "settingUserQQOpenId";
    /**
     * 用户微博OpenId
     */
    public static final String SETTING_USER_WB_OPENID = "settingUserWBOpenId";
    /**
     * 用户微信OpenId
     */
    public static final String SETTING_USER_WX_OPENID = "settingUserWXOpenId";
    /**
     * 用户是否填写过参赛者资料,boolean型
     */
    public static final String SETTING_USER_ID_CARD = "settingUserIdCard";//用于判断用户是否填写过参赛者资料的凭证
    /**
     * 当前用户uid
     */
    public static final String SETTING_USER_ID = "settingUserId";

    /**
     * 存放音乐设置中,音乐信息json对象字符串  用户手动选择的默认歌曲 优先级较高
     */
    public static final String SETTING_EXPERT_MUSIC = "ExpertMusic";
    /**
     * 音乐设置中,后台推荐的歌曲信息json对象字符串  优先级较低
     */
    public static final String RECOMMEND_MUSIC = "RecommendMusic";

    /**
     * 用来记录新的版本号 用于提示用户升级 int 类型
     */
    public static final String SETTING_NEW_VERSION = "NewVersion";

    /**
     * 用来记录忽略升级的版本号 用于消息提醒 int 类型
     */
    public static final String SETTING_IGNORE_VERSION = "IgnoreVersion";

    /**
     * 是否点击过关于我们 我的消息提醒需要 boolean类型
     */
    public static final String SETTING_VERSION_UPDATE = "settingVersionRemind";

    /**
     * 是否点击过首页的通知列表的话题回答被讨论的详情 首页的消息红点提醒需要 boolean类型
     */
    public static final String SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE = "settingNoticeTopicAnswerDiscussRemind";

    /**
     * 是否点击过关闭今天训练计划的消息提醒的日期 long类型
     **/
    public static final String IGNORE_INFORMATION_DATE = "ignoreInformation";
    /**
     * 是否连接过跳绳 boolean类型
     */
    public static final String CONNECTED_SKIP_DEVICE = "connected_skip_device";

    /**
     * 最大心率，根据普通人群和肥胖人群区分
     */
    public static final String HEART_RATE_MAX = "heart_rate_max";//

    /**
     * 用户当前跑步等级 int型[0,16]
     * 1:初入跑坛,2:初级跑者I,3:初级跑者II,4:初级跑者III,5:中级跑者I,6:中级跑者II,7:中级跑者III,
     * 8:高级跑者I,9:高级跑者II,10:高级跑者III,
     * 11:顶级跑者I,12:顶级跑者II,13:顶级跑者III,14:神级跑者I,15:神级跑者II,16:神级跑者III
     */
    public static final String SETTING_USER_LEVEL = "coinTaskUserLevel";

    /**
     * 金币任务,绑定手机是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_BIND_PHONE = "coinTaskBindPhone";
    /**
     * 金币任务,绑定邮箱是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_BIND_EMAIL = "coinTaskBindEmail";
    /**
     * 金币任务,完善个人资料是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_COMPLETE_PERSONAL_INFO = "coinTaskCompletePersonalInfo";
    /**
     * 金币任务,完善个人参赛资料是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_COMPLETE_COMPETITION_INFO = "coinTaskCompleteComInfo";
    /**
     * 金币任务,创建或者加入俱乐部是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_CREATE_JOIN_CLUB = "coinTaskCreateJoinClub";
    /**
     * 金币任务,使用我的设备配对一次是否完成,true:完成,false:未完成
     */
    public static final String SETTING_COIN_TASK_PAIRING_BT = "coinTaskPairingBt";

    /**
     * 金币任务,每日三公里完成时间,long型
     */
    public static final String SETTING_COIN_TASK_THREE_MILE = "coinTaskThreeMile";
    /**
     * 金币任务,每日播放歌曲完成时间,long型
     */
    public static final String SETTING_COIN_TASK_PLAY_MIX = "coinTaskPlayMix";
    /**
     * 金币任务,每日分享歌曲完成时间,long型
     */
    public static final String SETTING_COIN_TASK_SHARE_MIX = "coinTaskShareMix";
    /**
     * 金币任务,每日分享运动记录完成时间,long型
     */
    public static final String SETTING_COIN_TASK_SHARE_RECORD = "coinTaskShareRecord";
    /**
     * 金币任务,每日分享视频完成时间,long型
     */
    public static final String SETTING_COIN_TASK_SHARE_VIDEO = "coinTaskShareVideo";

    /**
     * 加密公钥内容,String型
     */
    public static final String SETTING_PUBLIC_KEY = "settingPublicKey";

    /**
     * app 用来记录当前相连的心率耳机固件版本的Version code,String型
     */
    public static final String SETTING_HR_FIRMWARE_VERSION_CODE = "firmware_version_code";

    /**
     * app 首页展示次数,int型
     */
    public static final String SETTING_APP_HOME_AD_SHOW_NUM = "app_home_ad_show_num";

    /**
     * app 闪屏页展示次数,int型
     */
    public static final String SETTING_APP_SPLASH_AD_SHOW_NUM = "app_splash_ad_show_num";

    /**
     * app 首页广告相关展示次数信息
     */
    public static final String SETTING_APP_HOME_AD_SHOW_INFO = "app_home_ad_show_info";

    /**
     * app 上一次连接的手表信息,String型,保存WatchInfo json字符串
     */
    public static final String SETTING_WATCH_INFO = "settingWatchInfo";
    /**
     * app 上一次刷新手表天气时间信息,String型,
     */
    public static final String LAST_WATCH_FRESH_WEATHER_TIME = "last_watch_fresh_weather_time";

    /**
     * app 当前手表版本号
     */
    public static final String SETTING_WATCH_VERSIONNUM = "settingWatchVersionNum";

    //endregion ================================ 数据库参数配置表参数名 ================================

    //region ================================ 音乐操作相关 ================================

    //public static final int HTTP_CACHE_SIZE = 10 * 1024 * 1024;//http数据缓存大小
    /**
     * 下载http请求超时时间,单位为毫秒,默认30秒
     */
    public static final int REQUEST_TIME_OUT_SECOND = 30000;//http请求超时时间
    /**
     * 下载自定义http状态码,未知错误,值为10
     */
    public static final int ERROR_DOWNLOAD_UNKNOWN = 10;//歌曲下载时出的位置错误
    /**
     * 下载自定义http状态码,写文件时IO异常,即网络断开,值为11
     */
    public static final int ERROR_NET_ERROR = 11;//下载中写文件时IO异常,即网络断开
    /**
     * 下载自定义http状态码,取消下载,值为12
     */
    public static final int ERROR_DOWNLOAD_CANCEL = 12;//下载中歌曲取消下载
    /**
     * 下载自定义http状态码,下载暂停,值为13
     */
    public static final int ERROR_DOWNLOAD_PAUSE = 13;//下载暂停
    /**
     * 音乐下载头文件大小,默认2M
     */
    public static final int HEAD_SIZE = 1024 * 1024 * 2;//头文件大小
    /**
     * 音乐下载尾文件大小,默认2M
     */
    public static final int TAIL_SIZE = 1024 * 1024 * 2;//尾文件大小
    /**
     * HTTP 200
     */
    public static final int HTTP_200 = 200;
    /**
     * HTTP 206
     */
    public static final int HTTP_206 = 206;
    //public static final int HTTP_POST = 0;
    //public static final int HTTP_GET = 1;


    /**
     * 播放普通音乐时,快进或快退时间跨度,默认90秒
     */
    public static final int MUSIC_NEXT_SEGMENT_TIME = 90;

    /**
     * 音乐列表操作类型: fitmix列表
     */
    public static final int LIST_TYPE_SCENE = 300;
    /**
     * 音乐列表操作类型: 下载列表
     */
    public static final int LIST_TYPE_DOWNLOADED = 301;
    /**
     * 音乐列表操作类型: 收藏列表
     */
    public static final int LIST_TYPE_FAVORITE = 302;
    /**
     * 音乐列表操作类型: 最近播放
     */
    public static final int LIST_TYPE_RECENT = 303;
    /**
     * 音乐列表操作类型: 搜索列表
     */
    public static final int LIST_TYPE_SEARCH = 304;
    /**
     * 音乐列表操作类型: 本地音乐列表
     */
    public static final int LIST_TYPE_LOCAL = 305;
    /**
     * 音乐列表操作类型: 自建歌单列表
     */
    public static final int LIST_TYPE_SELF = 306;

    /**
     * 歌曲播放通知
     */
    public static final String MUSIC_PLAY_START = "com.fitmix.sdk.music_play";
    /**
     * 歌曲结束通知
     */
    public static final String MUSIC_PLAY_STOP = "com.fitmix.sdk.music_stop";
    /**
     * 歌曲结下载完成通知
     */
    public static final String MUSIC_DOWNLOAD_COMPLETE = "com.fitmix.sdk.music_download_complete";
    /**
     * 音乐播放状态更改通知
     */
    public static final String MUSIC_PLAY_STATE_CHANGED = "com.fitmix.sdk.play_state_changed";
    /**
     * 音乐播放快退通知
     */
    public static final String MUSIC_CHANGED_PREV = "com.fitmix.sdk.music_changed_prev";
    /**
     * 音乐播放快进通知
     */
    public static final String MUSIC_CHANGED_NEXT = "com.fitmix.sdk.music_changed_next";
    /**
     * 音乐默认通知
     */
    public static final String MUSIC_PLAY_DEFAULT = "com.fitmix.sdk.music_default";
    /**
     * 音乐加载完成通知
     */
    public static final String MUSIC_PREPARED = "com.fitmix.sdk.music_prepared";
    /**
     * 音乐缓冲进度加载通知
     */
    public static final String MUSIC_BUFFERINGUPDATE = "com.fitmix.sdk.music_buffering_update";

    //endregion ================================ 音乐操作相关 ================================

    //region ================================ 用户输入验证相关 ================================
    /**
     * 密码最小位数限制
     */
    public static final int PASSWORD_LENGTH_MIN = 6;
    /**
     * 用户名最小长度限制
     */
    public static final int USERNAME_LENGTH_MIN = 2;
    /**
     * 字符长度最大值
     */
    public static final int CLUB_NAME_LENGTH_MAX = 10;

    /**
     * 输入无误
     */
    public static final int ERROR_NO_ERROR = 0;
//    /** 网络连接超时*/
//    public static final String ERROR_CONNECT_OUT_TIME = "network_connect_out_time";
    /**
     * 输入的用户名字符太少
     */
    public static final int ERROR_USERNAME_TOO_SHORT = 1;
    /**
     * 输入的密码长度太小
     */
    public static final int ERROR_PASSWORD_TOO_SHORT = 2;
    /**
     * 输入的用户名格式错误
     */
    public static final int ERROR_FORMAT_ERROR = 3;
    /**
     * 输入的年龄错误
     */
    public static final int ERROR_AGE_ERROR = 4;
    /**
     * 网络不好
     */
    public static final int ERROR_NO_NETWORK = 5;
    /**
     * 输入的数据过长
     */
    public static final int ERROR_DATA_TOO_LONG = 6;
    /**
     * 输入的个人信息(年龄、身高、体重)为0错误
     */
    public static final int ERROR_PERSON_DATA = 7;
    /**
     * 输入的手机号码错误
     */
    public static final int ERROR_PHONE_DATA = 8;
    /**
     * 输入的密码不一致错误
     */
    public static final int ERROR_PASSWORD_NOT_MATCH = 9;
    /**
     * 未知错误
     */
    public static final int ERROR_UNKNOWN = 10;
    /**
     * 获取验证码错误
     */
    public static final int ERROR_GET_AUTH_CODE = 11;
    /**
     * 输入验证码错误
     */
    public static final int ERROR_EDIT_AUTH_CODE = 12;
    /**
     * 验证码错误
     */
    public static final int ERROR_AUTH_CODE_WRONG = 13;
    /**
     * 输入的手机号码不匹配错误
     */
    public static final int ERROR_PHONE_NUMBER_NOT_MATCH = 14;
    /**
     * 俱乐部公告名称不合格错误
     */
    public static final int ERROR_NOTICE_NAME_INVALID = 15;
    /**
     * 俱乐部公告地址不合格错误
     */
    public static final int ERROR_NOTICE_ADDRESS_INVALID = 16;
    /**
     * 俱乐部公告结束时间小于开始时间错误
     */
    public static final int ERROR_TIME_INVALID = 17;
    /**
     * 俱乐部公告封面不存在
     */
    public static final int ERROR_COVER_NOT_EXIST = 18;
    /**
     * 俱乐部名称错误
     */
    public static final int ERROR_CLUB_NAME_ERROR = 19;
    /**
     * 俱乐部描述错误
     */
    public static final int ERROR_CLUB_DESC_ERROR = 20;
    /**
     * 没有定位信息错误
     */
    public static final int ERROR_NO_LOCATION_INFO = 21;
    /**
     * 用户昵称不能为空
     */
    public static final int ERROR_NICKNAME_EMPTY = 22;
    /**
     * 个性签名不能为空
     */
    public static final int ERROR_SIGNATURE_EMPTY = 23;
    /**
     * 输入的邮箱不匹配错误
     */
    public static final int ERROR_EMAIL_NOT_MATCH = 24;
    /**
     * 邮箱已存在错误
     */
    public static final int URL_RET_CODE_EMAIL_EXIST = 1000;
    /**
     * 邮箱格式错误
     */
    public static final int URL_RET_CODE_EMAIL_EMPTY = 1001;
    /**
     * 用户名为空错误
     */
    public static final int URL_RET_CODE_USER_NAME_EMPTY = 1002;
    /**
     * 用户名已存在错误
     */
    public static final int URL_RET_CODE_USER_EXIST = 1003;
    /**
     * 年龄错误
     */
    public static final int URL_RET_AGE_ERROR = 1200;
    /**
     * 性别错误
     */
    public static final int URL_RET_SEX_ERROR = 1201;
    /**
     * 用户类型错误
     */
    public static final int URL_RET_USER_TYPE_ERROR = 1202;
    /**
     * 用户名不存在错误
     */
    public static final int URL_RET_CODE_USER_NOT_EXIST = 2000;
    /**
     * 用户名不存在错误
     */
    public static final int URL_RET_CODE_USER_NOT_EXIST2 = 3002;
    /**
     * 密码错误
     */
    public static final int URL_RET_PASSWORD_ERROR = 2001;
    /**
     * 重复操作错误
     */
    public static final int URL_RET_CODE_REPEAT_OPERATE = 5004;

    //endregion ================================ 用户输入验证相关 ================================

    //region =================================== 其它参数 ===================================

    /**
     * 计量单位,1:公制
     */
    public static final int UNIT_TYPE_CHINESE = 1;
    /**
     * 计量单位,2:英制
     */
    public static final int UNIT_TYPE_ENGLISH = 2;
    /**
     * 用户默认身高,172厘米
     */
    public static final int USER_DEFAULT_HEIGHT = 172;
    /**
     * 用户默认体重,65千克
     */
    public static final int USER_DEFAULT_WEIGHT = 65;
    /**
     * 用户默认年龄,24岁
     */
    public static final int USER_DEFAULT_AGE = 24;

    /**
     * 网络状态,没有网络连接
     */
    public static final int NETWORK_TYPE_NONE = 0;
    /**
     * 网络状态,手机网络类型
     */
    public static final int NETWORK_TYPE_MOBILE = 1;
    /**
     * 网络状态,wifi网络类型
     */
    public static final int NETWORK_TYPE_WIFI = 2;

    /**
     * 账号解绑类型,邮箱解绑
     */
    public static final int UNBIND_TYPE_BY_EMAIL = 6;
    /**
     * 账号解绑类型,QQ解绑
     */
    public static final int UNBIND_TYPE_BY_QQ = 7;
    /**
     * 账号解绑类型,微信解绑
     */
    public static final int UNBIND_TYPE_BY_WECHAT = 8;
    /**
     * 账号解绑类型,微博解绑
     */
    public static final int UNBIND_TYPE_BY_SINA = 9;
    /**
     * 账号解绑类型,手机解绑
     */
    public static final int UNBIND_TYPE_BY_PHONE = 10;

    /**
     * 账号绑定类型,绑定邮箱
     */
    public static final int BIND_TYPE_BY_EMAIL = 1;
    /**
     * 账号绑定类型,绑定QQ
     */
    public static final int BIND_TYPE_BY_QQ = 2;
    /**
     * 账号绑定类型,绑定微信
     */
    public static final int BIND_TYPE_BY_WECHAT = 3;
    /**
     * 账号绑定类型,绑定微博
     */
    public static final int BIND_TYPE_BY_SINA = 4;
    /**
     * 账号绑定类型,绑定手机
     */
    public static final int BIND_TYPE_BY_PHONE = 5;

    /**
     * MusicFragment界面,数据请求类型,获取音乐列表,值为1
     */
    public static final int REQUEST_MUSIC_ALBUM = 1;//获取音乐列表
    /**
     * MusicFragment界面,数据请求类型,获取电台列表,值为2
     */
    public static final int REQUEST_RADIO_ALBUM = 2;//获取电台列表
    /**
     * MusicFragment界面,数据请求类型,获取推荐专辑,值为3
     */
    public static final int REQUEST_RECOMMEND_ALBUM = 3;//获取推荐专辑

    /**
     * 俱乐部徽标宽度
     */
    public static final int USER_CLUB_WIDTH = 172;
    /**
     * 俱乐部徽标高度
     */
    public static final int USER_CLUB_HEIGHT = 232;
    /**
     * 自定义歌单封面图片宽度
     */
    public static final int USER_ALBUM_WIDTH = 750;
    /**
     * 自定义歌单封面图片高度
     */
    public static final int USER_ALBUM_HEIGHT = 320;

    /**
     * 邮箱或手机绑定返回码
     */
    public static final int REQUEST_BIND_PHONE_EMAIL_RESULT_CODE = 201;

    /**
     * 本地文件类型,乐享动音乐封面,值为0
     */
    public static final int DOWNLOAD_FORMAT_PICTURE = 0;
    /**
     * 本地文件类型,音乐,值为1
     */
    public static final int DOWNLOAD_FORMAT_MUSIC = 1;
    /**
     * 本地文件类型,轨迹文件,值为2
     */
    public static final int DOWNLOAD_FORMAT_TRAIL = 2;
    /**
     * 本地文件类型,乐享动音乐封面高清,值为3
     */
    public static final int DOWNLOAD_FORMAT_PICTURE2 = 3;
    /**
     * 本地文件类型,俱乐部徽标,值为4
     */
    public static final int DOWNLOAD_FORMAT_CLUB_COVER = 4;
    /**
     * 本地文件类型,音乐专辑封面,值为5
     */
    public static final int DOWNLOAD_FORMAT_ALBUM_COVER = 5;
    /**
     * 本地文件类型,用户头像,值为6
     */
    public static final int DOWNLOAD_FORMAT_AVATAR = 6;
    //	public static final int DOWNLOAD_FORMAT_NOTICE= 7;
    /**
     * 本地文件类型,计步文件,值为8
     */
    public static final int DOWNLOAD_FORMAT_STEP = 8;
    /**
     * 本地文件类型,自建歌单封面,值为9
     */
    public static final int DOWNLOAD_LOCAL_COVER = 9;

    //endregion =================================== 其它参数 ===================================

    //region ======================== 第三方平台相关 ================================
    /**
     * 微信APP ID
     */
    public static final String WEIXIN_APPID = "wx523eacdfe8922b80";
    /**
     * 微信APP Secret
     */
    public static final String WEIXIN_APPSECRET = "1be85ea935f2238096c8e4f2a4008cac";
    /**
     * 微信公众号ID
     */
    public static final String WEIXIN_ID = "gh_20e144b20c18";//"gh_512c721b91d2";
    /**
     * QQ APP ID
     */
    public static final String QQ_APPID = "1104452331";//1104452331
    /**QQ APP KEY*/
//	public static final String QQ_APP_KEY="DrZpeXJYL3O0gXVs";//DrZpeXJYL3O0gXVs
    /**
     * 新浪微博APP KEY
     */
    public static final String WEIBO_APPKEY = "1415931559";
//    /**新浪微博APP SECRET*/
//	public static final String WEIBO_APP_SECRET="b921b944edfbd3e0e198b7ea84e5b74d";
    /**
     * 新浪APP授权回调页
     * <p>
     * 注：关于授权回调页对移动客户端应用来说对用户是不可见的,所以定义为何种形式都将不影响,
     * 但是没有定义将无法使用 SDK 认证登录。
     * 建议使用默认回调页：https://api.weibo.com/oauth2/default.html
     * </p>
     */
    public static final String SINA_REDIRECT_URL = "https://api.weibo.com/oauth2/default.html";//"http://sns.whalecloud.com/sina2/callback";

    /**
     * Scope 是 OAuth2.0 授权机制中 authorize 接口的一个参数。通过 Scope,平台将开放更多的微博
     * 核心功能给开发者,同时也加强用户隐私保护,提升了用户体验,用户在新 OAuth2.0 授权页中有权利
     * 选择赋予应用的功能。
     * <p>
     * 我们通过新浪微博开放平台-->管理中心-->我的应用-->接口管理处,能看到我们目前已有哪些接口的
     * 使用权限,高级权限需要进行申请。
     * <p>
     * 目前 Scope 支持传入多个 Scope 权限,用逗号分隔。
     * <p>
     * 有关哪些 OpenAPI 需要权限申请,请查看：http://open.weibo.com/wiki/%E5%BE%AE%E5%8D%9AAPI
     * 关于 Scope 概念及注意事项,请查看：http://open.weibo.com/wiki/Scope
     */
    public static final String SINA_SCOPE =
            "email,direct_messages_read,direct_messages_write,"
                    + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
                    + "follow_app_official_microblog," + "invitation_write";//follow_app_official_microblog关注官方微博

//    /**
//     * 新浪官方微博ID
//     */
//    public static final String SINA_WEIBO_ID = "5889681883";//5698520327

    //endregion ======================== 第三方平台相关 ================================

    //region ======================== 心率相关 ================================
    /**
     * 静息心率模式,0
     */
    public static final int HEART_RATE_REST_TYPE = 0;
//    /**
//     * 跑步心率模式,1
//     */
//    public static final int HEART_RATE_RUN_TYPE = 1;
//    /**
//     * 跳绳心率模式,2
//     */
//    public static final int HEART_RATE_SKIP_TYPE = 2;
    /**
     * 默认的静息心率,默认为70
     */
    public static final int HEART_RATE_DEFAULT_REST_HR = 70;
    /**
     * 心率圆环图表运动数据类型,跑步1
     */
    public static final int LINE_CHART_SPORT_TYPE_RUN = 1;
    /**
     * 心率圆环图表运动数据类型,跳绳2
     */
    public static final int LINE_CHART_SPORT_TYPE_SKIP = 2;

//    public static final int HEART_RATE_AVG_VO2 = 250;//成年人安静时摄氧量大约 250ml·min -1
    /**
     * 心率耳机发送一键运动广播
     */
    public static final String HEART_RATE_CLICK_TO_RUN = "com.fitmix.sdk.hr.headset.click.to.run";

    /**
     * 心率教练模式,int 型 7:自由模式 6:自定义模式 5:极限强度模式 4:强化机能模式-无氧 3:强化心肺模式-有氧 2:燃脂模式
     */
    public static final String HEART_RATE_COACH_MODE = "heart_rate_coach_mode";

    /**
     * 心率教练模式 自定义模式最小心率,int 型
     */
    public static final String CUSTOM_COACH_MODE_MIM_VALUE = "heart_rate_custom_coach_mode_min_value";

    /**
     * 心率教练模式 自定义模式最大心率,int 型
     */
    public static final String CUSTOM_COACH_MODE_MAX_VALUE = "heart_rate_custom_coach_mode_max_value";

    //endregion ======================== 心率相关 ================================

    //region ======================== 金币系统相关 ========================
    /**
     * 金币任务,每日任务类型
     */
    public static final int COIN_TASK_TYPE_EVERYDAY = 0;
    /**
     * 金币任务,一次性任务类型
     */
    public static final int COIN_TASK_TYPE_ONCE = 1;

    /**
     * 金币任务,每日签到任务键值
     */
    public static final String COIN_TASK_SIGN = "EVERY_DAY_SIGN_IN";
    /**
     * 金币任务,每日运动三公里任务键值
     */
    public static final String COIN_TASK_THREE_MILE_KEY = "EVERY_DAY_RUN_THREE_MILE";
    /**
     * 金币任务,每日播放歌曲任务键值
     */
    public static final String COIN_TASK_PLAY_MIX_KEY = "EVERY_DAY_PLAY_MIX";
    /**
     * 金币任务,每日分享歌曲任务键值
     */
    public static final String COIN_TASK_SHARE_MIX_KEY = "EVERY_DAY_SHARE_MIX";
    /**
     * 金币任务,每日分享运动任务键值
     */
    public static final String COIN_TASK_SHARE_RECORD_KEY = "EVERY_DAY_SHARE_SPORT";
    /**
     * 金币任务,每日分享视频任务键值
     */
    public static final String COIN_TASK_SHARE_VIDEO_KEY = "EVERY_DAY_SHARE_VIDEO";

    /**
     * 金币任务,绑定邮箱一次性任务键值
     */
    public static final String COIN_TASK_EMAIL_BIND_KEY = "REGISTER_BY_EMAIL";
    /**
     * 金币任务,绑定手机一次性任务键值
     */
    public static final String COIN_TASK_PHONE_BIND_KEY = "REGISTER_BY_MOBILE";
    /**
     * 金币任务,完善个人资料一次性任务键值
     */
    public static final String COIN_TASK_COMPLETE_PERSONAL_INFO = "COMPLETE_PERSONAL_INFORMATION";
    /**
     * 金币任务,完善个人参赛资料一次性任务键值
     */
    public static final String COIN_TASK_COMPLETE_COMPETITION_INFO = "COMPLETE_COMPETITION_INFORMATION";
    /**
     * 金币任务,创建或者加入俱乐部一次性任务键值
     */
    public static final String COIN_TASK_CREATE_JOIN_CLUB = "CREATE_OR_JOIN_CLUB";
    /**
     * 金币任务,使用我的设备配对一次任务键值
     */
    public static final String COIN_TASK_PAIRING_BT = "USE_EQUIPMENT_PAIRING";

    /**
     * 金币任务,分享流量兑换结果任务键值
     */
    public static final String COIN_TASK_SHARE_FLOW = "SHARE_FLOW";


    /**
     * 用户跑步记录上传后,有关金币任务的广播
     */
    public static final String COIN_TASK_RUN_RECORD_BROADCAST = "com.fitmix.sdk.coin_task_run_record_broadcast";

    /**
     * BLE功能请求打开GPS
     */
    public static final int BLE_REQUEST_ENABLE_GPS = 19;

    /**
     * 请求打开GPS
     */
    public static final int REQUEST_ENABLE_GPS = 20;

    /**
     * 请求蓝牙BLE权限
     */
    public final static int REQUEST_ENABLE_BLUETOOTH = 21;

//    /**
//     * 打开系统蓝牙设置界面
//     */
//    public final static int REQUEST_ENABLE_BLUETOOTH_SETTING = 22;

    //endregion ======================== 金币系统相关 ========================

    //region ======================== 手表相关 ========================

    /**
     * 手表文件夹路径
     */
    public static final String PATH_WATCH = PATH_APP_STORAGE + "Watch" + File.separator;
    /**
     * 手表传过来的运动记录或sensor文件转换后的文件夹路径
     */
    public static final String PATH_WATCH_LOG_DATA = PATH_WATCH + "Log" + File.separator;
    /**
     * 手表传过来的大文件原始数据文件夹路径
     */
    public static final String PATH_WATCH_RAW_DATA = PATH_WATCH + "Raw" + File.separator;
    /**
     * 手表GPS记录文件路径
     */
    public static final String PATH_WATCH_SENSOR_GPS = PATH_WATCH + "WatchSensorGps" + File.separator;
    /**
     * 手表GSensor记录文件路径
     */
    public static final String PATH_WATCH_SENSOR_GSENSOR = PATH_WATCH + "WatchSensorGSensor" + File.separator;
    /**
     * 手表心率记录文件路径
     */
    public static final String PATH_WATCH_SENSOR_HR = PATH_WATCH + "WatchSensorHR" + File.separator;
    /**
     * 手表温度文件路径
     */
    public static final String PATH_WATCH_SENSOR_TEMPERATURE = PATH_WATCH + "WatchSensorTemperature" + File.separator;
    /**
     * 手表气压文件路径
     */
    public static final String PATH_WATCH_SENSOR_PRESSURE = PATH_WATCH + "WatchSensorPressure" + File.separator;
    /**
     * 手表湿度文件路径
     */
    public static final String PATH_WATCH_SENSOR_HUMIDITY = PATH_WATCH + "WatchSensorHumidity" + File.separator;
    /**
     * 手表指南针文件路径
     */
    public static final String PATH_WATCH_SENSOR_COMPASS = PATH_WATCH + "WatchSensorCompass" + File.separator;
    /**
     * 手表陀螺仪文件路径
     */
    public static final String PATH_WATCH_SENSOR_GYRO = PATH_WATCH + "WatchSensorGYRO" + File.separator;


    /**
     * 错误日志报告
     */
    public static final String PATH_WATCH_ERROR_LOG = PATH_WATCH + "WatchErrorLog" + File.separator;
//    /**
//     * 手表手表运动记步文件路径
//     */
//    public static final String PATH_WATCH_STEP = PATH_WATCH + "Step" + File.separator;
//    /**
//     * 手表手表运动轨迹文件路径
//     */
//    public static final String PATH_WATCH_TRAIL = PATH_WATCH + "Trail" + File.separator;

    /**
     * 手表不同类型传感器文件的后缀名
     */
    public static final String PATH_SENSOR_GPS_END = ".gps";
    public static final String PATH_SENSOR_GSENSOR_END = ".gsensor";
    public static final String PATH_SENSOR_HR_END = ".hr";
    public static final String PATH_SENSOR_TEMPERATURE_END = ".temperature";
    public static final String PATH_SENSOR_PRESSURE_END = ".pressure";
    public static final String PATH_SENSOR_HUMIDITY_END = ".humidity";
    public static final String PATH_SENSOR_COMPASS_END = ".compass";
    public static final String PATH_SENSOR_GYRO_END = ".gyro";
    public static final String PATH_SENSOR_DISTANCE_END = ".distance";


    /**
     * 手表图表文件后缀名
     */
    public static final String PRESSURE_CHART_SUFFIX = ".pressureChart";//气压图表
    public static final String TEMP_CHART_SUFFIX = ".temperatureChart";//气温图表
    public static final String HR_CHART_SUFFIX = ".hrChart";//心率图表
    public static final String ALTITUDE_CHART_SUFFIX = ".altitudeChart";//海拔图表
    public static final String BPM_CHART_SUFFIX = ".bpmChart";//步频图表
    public static final String SPEED_CHART_SUFFIX = ".speedChart";//速度图表，由里程转换而来
    public static final String STRIDE_CHART_SUFFIX = ".strideChart";//步幅图表


    public static final String LOG_NAME = "log.txt";
    //endregion ======================== 手表相关 ========================

}
