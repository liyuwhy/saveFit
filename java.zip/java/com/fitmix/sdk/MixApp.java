package com.fitmix.sdk;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.multidex.MultiDexApplication;
import android.support.v4.content.ContextCompat;

import com.facebook.cache.disk.DiskCacheConfig;
import com.facebook.common.internal.Supplier;
import com.facebook.common.util.ByteConstants;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.cache.MemoryCacheParams;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.fitmix.sdk.base.MyLifecycleHandler;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.cache.HttpProxyCacheServer;
import com.fitmix.sdk.model.database.DaoMaster;
import com.fitmix.sdk.model.database.DaoSession;
import com.fitmix.sdk.service.WatchRunService;
import com.xdandroid.hellodaemon.DaemonEnv;

import de.greenrobot.dao.query.QueryBuilder;


/**
 * 自定义APP类
 */
public class MixApp extends MultiDexApplication {

    private static Context context;
    private static DaoMaster daoMaster;
    private static DaoSession daoSession;
    public static SQLiteDatabase db;
//    private RefWatcher refWatcher;
//
//    public static RefWatcher getRefWatcher(Context context) {
//        MixApp application = (MixApp) context.getApplicationContext();
//        return application.refWatcher;
//    }

    //缓存代理服务
    private HttpProxyCacheServer proxy;

    /**
     * 获取缓存服务
     *
     * @param context
     * @return
     */
    public static HttpProxyCacheServer getProxy(Context context) {
        MixApp app = (MixApp) context.getApplicationContext();
        if (app.proxy == null) {
            try {
                app.proxy = app.newProxySet();
            } catch (Exception e) {
                e.printStackTrace();
                app.proxy = null;
            }
        }
        return app.proxy;
    }

    /**
     * 清除缓存管理器设置，用于重新设置缓存服务的相关参数（eg：缓存上限）
     */
    public static void setProxyToNull() {
        MixApp app = (MixApp) context.getApplicationContext();
        app.proxy = null;
    }

//    /**
//     * 内存上限设为默认的512MB
//     * @return
//     */
//    private HttpProxyCacheServer newProxyDefault() {
//        return new HttpProxyCacheServer(this);
//    }

    /**
     * 内存上限设为SharedPreference上存储的值
     *
     * @return
     */
    private HttpProxyCacheServer newProxySet() {
        int maxCacheSize = PrefsHelper.with(context, com.fitmix.sdk.Config.PREFS_USER).readInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, com.fitmix.sdk.Config.SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE);
        return new HttpProxyCacheServer.Builder(this)
                .maxCacheSize(maxCacheSize * 1024 * 1024)
                .build();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        createAppDirectory();
        // 打印数据库查询语句和结果
        QueryBuilder.LOG_SQL = false;
        QueryBuilder.LOG_VALUES = false;
//        MultiDex.install(this);//友盟报错 java.lang.NoClassDefFoundError: com.umeng.analytics.MobclickAgent
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            initFresco();//facebook fresco框架
        } else {
            Fresco.initialize(this);//facebook fresco框架
        }

        UmengAnalysisHelper.getInstance().onApplicationCreate(false);//友盟统计,关闭debug
//        refWatcher = LeakCanary.install(this);

//        BlockCanary.install(this, new AppBlockCanaryContext()).start();//BlockCanary
        //全局未处理的异常处理
        //Thread.setDefaultUncaughtExceptionHandler(CrashHandler.getInstance());//注释掉，否则友盟不统计异常,同时logcat不显示具体异常信息

        registerActivityLifecycleCallbacks(new MyLifecycleHandler());//注册app的运行状态回调

        //需要在 Application 的 onCreate() 中调用一次 DaemonEnv.initialize()
        DaemonEnv.initialize(this, WatchRunService.class, DaemonEnv.DEFAULT_WAKE_UP_INTERVAL);
        WatchRunService.sShouldStopService = false;
        DaemonEnv.startServiceMayBind(WatchRunService.class);
    }



    /**
     * 初始化facebook fresco
     */
    private void initFresco() {
        /**
         * oom android 5.0
         * https://github.com/facebook/fresco/issues/1396
         * */

        /*ImagePipelineConfig imagePipelineConfig = ImagePipelineConfig
                .newBuilder(getApplicationContext())
                .setDownsampleEnabled(true)
                //.setBitmapMemoryCacheParamsSupplier(new LollipopBitmapMemoryCacheParamsSupplier(activityManager))
                .build();
        Fresco.initialize(getApplicationContext(), imagePipelineConfig);*/
        String IMAGE_PIPELINE_CACHE_DIR = FitmixUtil.getPhotoPath();
        int MAX_HEAP_SIZE = (int) Runtime.getRuntime().maxMemory();
        int MAX_DISK_CACHE_SIZE = 40 * ByteConstants.MB;
        int MAX_MEMORY_CACHE_SIZE = MAX_HEAP_SIZE / 4;
        final MemoryCacheParams bitmapCacheParams = new MemoryCacheParams(
                MAX_MEMORY_CACHE_SIZE, // Max total size of elements in the cache
                Integer.MAX_VALUE,                     // Max entries in the cache
                MAX_MEMORY_CACHE_SIZE, // Max total size of elements in eviction queue
                Integer.MAX_VALUE,                     // Max length of eviction queue
                Integer.MAX_VALUE);

        ImagePipelineConfig config = ImagePipelineConfig.newBuilder(context)
                .setBitmapMemoryCacheParamsSupplier(new Supplier<MemoryCacheParams>() {
                    public MemoryCacheParams get() {
                        return bitmapCacheParams;
                    }
                })
                .setDownsampleEnabled(true)
                .setMainDiskCacheConfig(
                        DiskCacheConfig.newBuilder(this)
                                .setBaseDirectoryPath(context.getApplicationContext().getCacheDir())
                                .setBaseDirectoryName(IMAGE_PIPELINE_CACHE_DIR)
                                .setMaxCacheSize(MAX_DISK_CACHE_SIZE).build())
                .setBitmapsConfig(Bitmap.Config.RGB_565)
                .build();
        Fresco.initialize(context, config);

    }

    /**
     * 在外部存储器创建APP所需要的文件夹
     */
    private void createAppDirectory() {
        FileUtils.makeFolders(Config.PATH_APP_STORAGE);
        FileUtils.makeFolders(Config.PATH_DOWN_MUSIC);
        FileUtils.makeFolders(Config.PATH_DOWN_STEP);
        FileUtils.makeFolders(Config.PATH_DOWN_TRAIL);
        FileUtils.makeFolders(Config.PATH_DOWN_PICTURE);
        FileUtils.makeFolders(Config.PATH_RUN_PHOTO);
        FileUtils.makeFolders(Config.PATH_RUN_VOICE);
        FileUtils.makeFolders(Config.PATH_LOCAL_COVER);
        FileUtils.makeFolders(Config.PATH_CACHE);//存放缓存文件路径
        FileUtils.makeFolders(Config.PATH_LOCAL_VOICE);//语音包文件目录
        FileUtils.makeFolders(Config.PATH_TOPIC);//话题
        FileUtils.makeFolders(Config.PATH_TOPIC_AVATAR);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            FileUtils.deleteFile(Config.PATH_LOCAL_TEMP);//删除所有临时文件
            FileUtils.writeNoMediaFile(Config.PATH_APP_STORAGE);
            FileUtils.deleteFile(Config.PATH_QQ_SDK_SHARE_IMG);//删除QQ分享临时文件
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                FileUtils.deleteFile(Config.PATH_LOCAL_TEMP);//删除所有临时文件
                FileUtils.writeNoMediaFile(Config.PATH_APP_STORAGE);
                FileUtils.deleteFile(Config.PATH_QQ_SDK_SHARE_IMG);//删除QQ分享临时文件
            }
        }
        FileUtils.makeFolders(Config.PATH_LOCAL_TEMP);
        //手表相关的文件夹
        FileUtils.makeFolders(Config.PATH_WATCH);
        FileUtils.makeFolders(Config.PATH_WATCH_LOG_DATA);
        FileUtils.makeFolders(Config.PATH_WATCH_RAW_DATA);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_GPS);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_GSENSOR);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_HR);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_TEMPERATURE);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_PRESSURE);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_HUMIDITY);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_COMPASS);
        FileUtils.makeFolders(Config.PATH_WATCH_SENSOR_GYRO);
        FileUtils.makeFolders(Config.PATH_WATCH_ERROR_LOG);
    }

    public static Context getContext() {
        return context;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        getSqlDatabase(this).close();//程序退出时,关闭数据库
    }

    /**
     * 获取数据库ORM master
     *
     * @param context 上下文
     */
    public static DaoMaster getDaoMaster(Context context) {
        if (daoMaster == null) {
            DaoMaster.OpenHelper helper = new DaoMaster.DevOpenHelper(context, Config.DB_NAME, null);
            daoMaster = new DaoMaster(helper.getWritableDatabase());
        }
        return daoMaster;
    }


    /**
     * 获取数据库ORM Session
     *
     * @param context 上下文
     */
    public static DaoSession getDaoSession(Context context) {
        if (daoSession == null) {
            if (daoMaster == null) {
                daoMaster = getDaoMaster(context);
            }
            daoSession = daoMaster.newSession();
        }

        return daoSession;
    }

    /**
     * 获取数据库实例
     *
     * @param context 上下文
     */
    public static SQLiteDatabase getSqlDatabase(Context context) {
        if (daoSession == null) {
            if (daoMaster == null) {
                daoMaster = getDaoMaster(context);
            }
            db = daoMaster.getDatabase();
        }
        return db;
    }

}
