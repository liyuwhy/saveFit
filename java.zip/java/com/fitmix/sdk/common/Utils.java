package com.fitmix.sdk.common;

import android.content.Context;
import android.graphics.drawable.Drawable;

import com.fitmix.sdk.R;

import java.util.Calendar;

public class Utils {
    private static Utils instance;

    public static Utils getInstance() {
        if (instance == null)
            instance = new Utils();
        return instance;
    }

//    /**
//     * 获取今天凌晨的时间戳
//     */
//    public static long getTimesMorning() {
//        Calendar cal = Calendar.getInstance();
//        cal.set(Calendar.HOUR_OF_DAY, 0);
//        cal.set(Calendar.SECOND, 0);
//        cal.set(Calendar.MINUTE, 0);
//        cal.set(Calendar.MILLISECOND, 0);
//        return cal.getTimeInMillis();
//    }

    //    /**
//     * 让抽屉菜单全屏
//     * */
//    public static void fixMinDrawerMargin(DrawerLayout drawerLayout) {
//        try {
//            Field f = DrawerLayout.class.getDeclaredField("mMinDrawerMargin");
//            f.setAccessible(true);
//            f.set(drawerLayout, 0);
////            Log.i("TT", "fixMinDrawerMargin");
//            drawerLayout.requestLayout();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public static int getOldWeatherCode(int code) {
        switch (code) {
            case 100:
                return 0;
            case 101:
                return 1;
            case 102:
                return 2;
            case 103:
                return 3;
            case 104:
                return 4;
            case 300:
                return 5;
            case 301:
                return 6;
            case 302:
                return 7;
            case 303:
                return 8;
            case 304:
                return 9;
            case 305:
                return 10;
            case 306:
                return 11;
            case 307:
                return 12;
            case 308:
                return 13;
            case 309:
                return 14;
            case 310:
                return 15;
            case 311:
                return 16;
            case 312:
                return 17;
            case 313:
                return 18;
            case 400:
                return 19;
            case 401:
                return 20;
            case 402:
                return 21;
            case 403:
                return 22;
            case 404:
                return 23;
            case 405:
                return 24;
            case 406:
                return 25;
            case 407:
                return 26;
            case 500:
                return 27;
            case 501:
                return 28;
            case 502:
                return 29;
            case 503:
                return 30;
            case 504:
                return 31;
            case 507:
                return 32;
            case 508:
                return 33;
            default:
                return -1;
        }
    }

    /**
     * 判断当前时间是白天还是黑夜
     *
     * @return true:白天,false:黑夜
     */
    public boolean getIsDay() {
        long time = System.currentTimeMillis();
        Calendar mCalendar = Calendar.getInstance();
        mCalendar.setTimeInMillis(time);
        int hour = mCalendar.get(Calendar.HOUR_OF_DAY);
        return hour > 6 && hour < 18;
    }

    public Drawable getWhetherIcon(Context context, int type) {
        int array_whether_icon[] = {R.drawable.icon_tq_sunny100, R.drawable.icon_tq_cloudy101,
                R.drawable.icon_tq_few_clouds102, R.drawable.icon_tq_partly_cloudy103,
                R.drawable.icon_tq_overcast104, R.drawable.icon_tq_shower_rain300,
                R.drawable.icon_tq_heavy_shower_rain301, R.drawable.icon_tq_thundershower302,
                R.drawable.icon_tq_heavy_thunderstorm303, R.drawable.icon_tq_hail304,
                R.drawable.icon_tq_light_rain305, R.drawable.icon_tq_moderate_rain306,
                R.drawable.icon_tq_heavy_rain307, R.drawable.icon_tq_extreme_rain308,
                R.drawable.icon_tq_drizzle_rain309, R.drawable.icon_tq_storm310,
                R.drawable.icon_tq_heavy_storm311, R.drawable.icon_tq_severe_storm312,
                R.drawable.icon_tq_freezing_rain313, R.drawable.icon_tq_light_snow400,
                R.drawable.icon_tq_moderate_snow401, R.drawable.icon_tq_heavy_snow402,
                R.drawable.icon_tq_snowstorm403, R.drawable.icon_tq_sleet404,
                R.drawable.icon_tq_rain_and_snow405, R.drawable.icon_tq_shower_snow406,
                R.drawable.icon_tq_snow_flurry407, R.drawable.icon_tq_mist500,
                R.drawable.icon_tq_foggy501, R.drawable.icon_tq_haze502,
                R.drawable.icon_tq_sand503, R.drawable.icon_tq_dust504,
                R.drawable.icon_tq_duststorm507, R.drawable.icon_tq_sandstorm508};
        return context.getResources().getDrawable(array_whether_icon[type]);
    }

    /**
     * 根据天气类型,获取天气名称
     *
     * @param context 上下文
     * @param type    天气类型
     */
    public String getWhetherName(Context context, int type) {
        String[] arrays = context.getResources().getStringArray(R.array.whether_type);
        return arrays[type];
    }


//    /**
//     * 格式化
//     */
//    private static DecimalFormat dfs = null;
//
//    public static DecimalFormat format(String pattern) {
//        if (dfs == null) {
//            dfs = new DecimalFormat();
//        }
//        dfs.setRoundingMode(RoundingMode.FLOOR);
//        dfs.applyPattern(pattern);
//        return dfs;
//    }
//
//    /**
//     * 获取平方和
//     *
//     * @param a 参数1
//     * @param b 参数2
//     */
//    public static float hypo(int a, int b) {
//        return (float) Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
//    }
//
//    public static void copyfile(File fromFile, File toFile, Boolean rewrite) {
//        if (!fromFile.exists()) {
//            return;
//        }
//        if (!fromFile.isFile()) {
//            return;
//        }
//        if (!fromFile.canRead()) {
//            return;
//        }
//        if (!toFile.getParentFile().exists()) {
//            toFile.getParentFile().mkdirs();
//        }
//        if (toFile.exists() && rewrite) {
//            toFile.delete();
//        }
//        try {
//            FileInputStream fosfrom = new FileInputStream(fromFile);
//            FileOutputStream fosto = new FileOutputStream(toFile);
//            byte bt[] = new byte[1024];
//            int c;
//            while ((c = fosfrom.read(bt)) > 0) {
//                fosto.write(bt, 0, c); //将内容写到新文件当中
//            }
//            fosfrom.close();
//            fosto.close();
//        } catch (Exception ex) {
//            Log.e("readfile", ex.getMessage());
//        }
//    }

}
