package com.fitmix.sdk.common.share;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.OkHttpUtil;
import com.fitmix.sdk.wxapi.WechatAuthShareResult;
import com.sina.weibo.sdk.WbSdk;
import com.sina.weibo.sdk.api.ImageObject;
import com.sina.weibo.sdk.api.TextObject;
import com.sina.weibo.sdk.api.WebpageObject;
import com.sina.weibo.sdk.api.WeiboMultiMessage;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WbAuthListener;
import com.sina.weibo.sdk.auth.WbConnectErrorMessage;
import com.sina.weibo.sdk.auth.sso.SsoHandler;
import com.sina.weibo.sdk.share.WbShareCallback;
import com.sina.weibo.sdk.share.WbShareHandler;
import com.sina.weibo.sdk.utils.Utility;
import com.tencent.connect.UserInfo;
import com.tencent.connect.common.Constants;
import com.tencent.connect.share.QQShare;
import com.tencent.connect.share.QzoneShare;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.JumpToBizProfile;
import com.tencent.mm.sdk.openapi.SendAuth;
import com.tencent.mm.sdk.openapi.SendMessageToWX;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.mm.sdk.openapi.WXImageObject;
import com.tencent.mm.sdk.openapi.WXMediaMessage;
import com.tencent.mm.sdk.openapi.WXMusicObject;
import com.tencent.mm.sdk.openapi.WXWebpageObject;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class AuthShareHelper extends AppCompatActivity {

    public final String TAG = "AuthShareHelper";
    /**
     * 授权登录或分享请求键名
     */
    public static final String KEY_REQUESTCODE = "auth_share_request";
    /**
     * 授权登录或分享结果键名
     */
    public static final String KEY_RESULT_CODE = "auth_share_resultcode";
    /**
     * 授权登录或分享结果键名
     */
    public static final String KEY_RESULT_STRING = "auth_share_resultstr";
    /**
     * QQ或QQ空间分享数据集
     */
    public static final String KEY_QQ_SHARE_BUNDLE = "tencent_share";
    /**
     * 新浪微博分享数据集
     */
    public static final String KEY_SINA_SHARE_BUNDLE = "sina_share";
    /**
     * 微信分享数据集
     */
    public static final String KEY_WECHAT_SHARE_BUNDLE = "wechat_share";

    /**
     * 分享的标题KEY
     */
    public static final String KEY_SHARE_TITLE = "key_share_title";
    /**
     * 分享的内容KEY
     */
    public static final String KEY_SHARE_CONTENT = "key_share_content";
    /**
     * 分享的跳转URL KEY
     */
    public static final String KEY_SHARE_URL = "key_share_url";
    /**
     * 分享的图片地址 KEY
     */
    public static final String KEY_SHARE_IMAGE_URL = "key_share_image_url";
    /**
     * QQ授权登录
     */
    public static final int REQUESTCODE_QQ_LOGIN = 1000;
    /**
     * 新浪微博授权登录
     */
    public static final int REQUESTCODE_SINA_LOGIN = 1001;
    /**
     * 微信授权登录
     */
    public static final int REQUESTCODE_WECHAT_LOGIN = 1002;
    /**
     * QQ授权注销登录
     */
    public static final int REQUESTCODE_QQ_LOGOUT = 1004;

    /**
     * QQ分享请求编号
     */
    public static final int REQUESTCODE_QQ_SHARE = 2000;
    /**
     * QQ空间分享请求编号
     */
    public static final int REQUESTCODE_QZONE_SHARE = 2001;
    /**
     * 新浪微博分享请求编号
     */
    public static final int REQUESTCODE_SINA_SHARE = 2002;
    /**
     * 微信分享请求编号
     */
    public static final int REQUESTCODE_WECHAT_SHARE = 2003;
    /**
     * 微信朋友圈分享请求编号
     */
    public static final int REQUESTCODE_CIRCLE_SHARE = 2004;
    /**
     * QQ临时对话请求编号
     */
    public static final int REQUESTCODE_QQ_CONVERSATION = 2005;
    /**
     * 关注官方微博
     */
    public static final int REQUESTCODE_FOLLOW_WEIBO = 2006;
    /**
     * 关注微信公众号
     */
    public static final int REQUESTCODE_FOLLOW_WECHAT = 2007;
    /**
     * QQ 加群请求编号
     */
    public static final int REQUESTCODE_QQ_JOIN_GROUP = 2008;
    /**
     * QQ 授权登录 绑定
     */
    public static final int REQUESTCODE_QQ_BIND = 3001;
    /**
     * QQ 获取用户信息
     */
    public static final int REQUESTCODE_QQ_USER_INFO = 3002;
    /**
     * 微博授权登录 绑定
     */
    public static final int REQUESTCODE_SINA_BIND = 3003;
    /**
     * 微信授权登录 绑定
     */
    public static final int REQUESTCODE_WECHAT_BIND = 3004;
    /**
     * 微博 绑定 tag
     */
    public boolean isWBbind = true;

    /**
     * 结果成功
     */
    public static final int RESULTCODE_SUCCESS = 200;
    /**
     * 结果失败
     */
    public static final int RESULTCODE_FAILURE = 400;
    /**
     * 结果未知
     */
    public static final int RESULTCODE_UNKNOWN = 500;

    private int mCurrentRequestCode;// 当前的请求编号
    private Intent fromIntent;// 其它Activity请求的Intent
    private boolean hasReturnFromWeChat = false;//微信回调指示
    private boolean isGetInfo = false;//QQ 绑定tag

    //region ===========================Activity 生命周期回调==================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_share);

        // 新浪微博相关
        mAuthInfo = new AuthInfo(this, Config.WEIBO_APPKEY,
                Config.SINA_REDIRECT_URL, Config.SINA_SCOPE);
        WbSdk.install(this, mAuthInfo);//新浪微博sdk V2.0.3新方式
        mSinaSsoHandler = new SsoHandler(this);//新浪微博sdk V2.0.3新方式

//        mSinaSsoHandler = new SsoHandler(this, mAuthInfo);

        // 创建微博 SDK 接口实例
        mWeiboShareAPI = new WbShareHandler(this);//新浪微博sdk V2.0.3新方式
//        mWeiboShareAPI = WeiboShareSDK.createWeiboAPI(this,
//                Config.WEIBO_APPKEY);
        // 注册第三方应用到微博客户端中,注册成功后该应用将显示在微博的应用列表中。
        mWeiboShareAPI.registerApp();

        fromIntent = getIntent();
        if (fromIntent != null) {
            mCurrentRequestCode = fromIntent.getIntExtra(KEY_REQUESTCODE, 0);
            handleIntent(mCurrentRequestCode);
            // Log.i("TT","AuthShareHelper-->onCreate requestCode:"+mCurrentRequestCode);
        }

        Logger.i(Logger.DEBUG_TAG, "AuthShareHelper-->onCreate id:" + this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Logger.i("TT", "AuthShareHelper-->onNewIntent handle");

        // 从当前应用唤起微博并进行分享后,返回到当前应用时,需要在此处调用该函数
        // 来接收微博客户端返回的数据；执行成功,返回 true,并调用
        // {@link IWeiboHandler.Response#onResponse}；失败返回 false,不调用上述回调
//        mWeiboShareAPI.handleWeiboResponse(intent, mShareResponse);
        mWeiboShareAPI.doResultIntent(intent, mShareResponse);//新浪微博sdk V2.0.3新方式
    }

    /**
     * 销毁登录分享Activity
     */
    private void finishAuthShare() {
        if (mCurrentRequestCode == REQUESTCODE_QQ_USER_INFO && !isGetInfo) {
            return;
        }
        if (!isWBbind) {
            return;
        }
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);//动画
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 微信没办法从WXEntryActivity回调,通过SharedPreferences中转
        WechatAuthShareResult result = AccessTokenKeeper
                .readWechatAuthShareResult(this);
        Logger.i(TAG, "AuthShareHelper-->OnResume mCurrentRequestCode:" + mCurrentRequestCode + " weixin result is null:" + (result
                == null));
        if (result != null) {
            Logger.i(TAG, "AuthShareHelper-->OnResume weixin result code:" + result.mResultCode + " request code:" + result.mRequestCode);
        }

        switch (mCurrentRequestCode) {
            case REQUESTCODE_WECHAT_LOGIN:
                if (result != null
                        && result.mRequestCode == REQUESTCODE_WECHAT_LOGIN) {
                    Intent data = new Intent();
                    data.putExtra(KEY_RESULT_STRING, result.mResultStr);
                    data.putExtra(KEY_RESULT_CODE, result.mResultCode);
                    AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                    finishAuthShare();
                }
                break;

            case REQUESTCODE_WECHAT_SHARE:
                if (result != null
                        && result.mRequestCode == REQUESTCODE_WECHAT_SHARE) {
                    Intent data = new Intent();
                    data.putExtra(KEY_RESULT_STRING, result.mResultStr);
                    data.putExtra(KEY_RESULT_CODE, result.mResultCode);
                    AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                    finishAuthShare();
                }
                break;
            case REQUESTCODE_CIRCLE_SHARE:
                if (result != null
                        && result.mRequestCode == REQUESTCODE_CIRCLE_SHARE) {
                    Intent data = new Intent();
                    data.putExtra(KEY_RESULT_STRING, result.mResultStr);
                    data.putExtra(KEY_RESULT_CODE, result.mResultCode);
                    AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                    finishAuthShare();
                }
                break;
            case REQUESTCODE_WECHAT_BIND:
                if (result != null
                        && result.mRequestCode == REQUESTCODE_WECHAT_BIND) {
                    Intent data = new Intent();
                    data.putExtra("name", result.mWXName);
                    data.putExtra("openid", result.mWXOpenid);
                    AuthShareHelper.this.setResult(result.mResultCode, data);
                    finishAuthShare();
                }
                break;
        }
        if (hasReturnFromWeChat) {
            Logger.i("TT", "AuthShareHelper-->OnResume second times");
            finishAuthShare();
        }
        hasReturnFromWeChat = true;// 第二次调用onResume表明已从微信或其它状态返回
    }

    // 处理Intent请求
    private void handleIntent(int requestCode) {
//        Logger.i("TT", "AuthShareHelper-->handleIntent begin");
        Bundle bundle;
        Bitmap thumb = null;
        int contentType;
        boolean ifHaveLogo;
        String musicUrl;
        switch (requestCode) {

            case REQUESTCODE_QQ_LOGIN:// QQ登录
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_QQ_LOGIN");
                qqLogin();
                break;
            case REQUESTCODE_QQ_BIND:// QQ绑定
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_QQ_BIND");
                qqBind();
                break;

            case REQUESTCODE_SINA_LOGIN:// 微博登录
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_SINA_LOGIN");
                weiboLogin();
                break;
            case REQUESTCODE_SINA_BIND:// 微博登录 绑定
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_SINA_LOGIN");
                isWBbind = false;
                weiboBind();
                break;

            case REQUESTCODE_WECHAT_LOGIN:// 微信登录
//                Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_WECHAT_LOGIN");
                wechatLogin();
                break;
            case REQUESTCODE_WECHAT_BIND:// 微信登录绑定
//                Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_WECHAT_LOGIN");
                wechatBind();
                break;

            case REQUESTCODE_QQ_LOGOUT://QQ注销登录
                qqLogout();
                break;

            case REQUESTCODE_QQ_SHARE:// QQ分享
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_QQ_SHARE");
                bundle = fromIntent.getBundleExtra(KEY_QQ_SHARE_BUNDLE);
                qqShare(bundle);
                break;

            case REQUESTCODE_QZONE_SHARE:// QQ空间分享
//                Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_QZONE_SHARE");
                bundle = fromIntent.getBundleExtra(KEY_QQ_SHARE_BUNDLE);
                if (bundle != null) {
                    int shareChanel = bundle.getInt(QQShare.SHARE_TO_QQ_EXT_INT, 0);
                    if (shareChanel == QQShare.SHARE_TO_QQ_FLAG_QZONE_AUTO_OPEN) {
                        qqShare(bundle);//QQ空间目前不支持纯图片分享,只能通过QQ share
                    } else {
                        qqShareToQzone(bundle);
                    }
                } else {
                    qqShareToQzone(bundle);
                }
                break;
            case REQUESTCODE_WECHAT_SHARE:// 微信分享
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_WECHAT_SHARE");
                contentType = fromIntent.getIntExtra(ShareManager.SHARE_TYPE, ShareManager.SHARE_TYPE_WEB_PAGE);//接收内容类型参数
                ifHaveLogo = fromIntent.getBooleanExtra(ShareManager.IF_HAVE_LOGO, false);
                bundle = fromIntent.getBundleExtra(KEY_WECHAT_SHARE_BUNDLE);
                String wTitle = bundle.getString(KEY_SHARE_TITLE);
                String wContent = bundle.getString(KEY_SHARE_CONTENT);
                String wUrl = bundle.getString(KEY_SHARE_URL);
                String wImgUrl = bundle.getString(KEY_SHARE_IMAGE_URL);
                if (contentType != ShareManager.SHARE_TYPE_PIC) {//图片分享形式时,不处理缩略图
                    if (!TextUtils.isEmpty(wImgUrl)) {
                        thumb = ImageHelper.decodeBitmapFile(wImgUrl, 240, 240);//写成Bitmap形式,设置最大的长宽度(wImgeUrl, 240, 240)
                        if (thumb == null) {
                            thumb = BitmapFactory.decodeResource(getResources(),
                                    R.drawable.ic_launcher);
                        }

                        if (ifHaveLogo) {//判断时候需要加上logo标志
                            Bitmap thumbBmp = Bitmap.createScaledBitmap(thumb, THUMB_SIZE, THUMB_SIZE, true);//设置缩略图大小bitmap
                            Bitmap to_addBitmap = ImageHelper.drawable2Bitmap(ContextCompat.getDrawable(this, R.drawable.icon_fitmix_bottom));//获取需要合成加上的底部图片
                            if (to_addBitmap != null) {
                                Bitmap bottom_Bitmap = Bitmap.createScaledBitmap(to_addBitmap, THUMB_SIZE, 35, true);
                                thumb = ImageHelper.compositeImages(thumbBmp, bottom_Bitmap);
                            }
                        }
                    } else {
                        thumb = BitmapFactory.decodeResource(getResources(),
                                R.drawable.ic_launcher);
                    }
                }
                switch (contentType) {
                    //两方法唯一区别在于url参数,一个为音乐url,一个为网页url
                    case ShareManager.SHARE_TYPE_MUSIC:
                        musicUrl = fromIntent.getStringExtra(ShareManager.MUSIC_URL);
                        shareMusicInWeChat(wUrl, musicUrl, wTitle, wContent, thumb, false);
                        break;
                    case ShareManager.SHARE_TYPE_WEB_PAGE:
                        shareWebPage(wUrl, wTitle, wContent, thumb, false);
                        break;
                    case ShareManager.SHARE_TYPE_PIC:
                        sharePicInWeChat(wImgUrl, false);
                        break;
                    default:
                        shareWebPage(wUrl, wTitle, wContent, thumb, false);
                }
                break;

            case REQUESTCODE_CIRCLE_SHARE:// 微信朋友圈分享
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_CIRCLE_SHARE");
                contentType = fromIntent.getIntExtra(ShareManager.SHARE_TYPE, ShareManager.SHARE_TYPE_WEB_PAGE);
                bundle = fromIntent.getBundleExtra(KEY_WECHAT_SHARE_BUNDLE);
                String weTitle = bundle.getString(KEY_SHARE_TITLE);
                String weContent = bundle.getString(KEY_SHARE_CONTENT);
                String weUrl = bundle.getString(KEY_SHARE_URL);
                String weImgeUrl = bundle.getString(KEY_SHARE_IMAGE_URL);
                if (contentType != ShareManager.SHARE_TYPE_PIC) {//图片分享形式时,不处理缩略图
                    if (!TextUtils.isEmpty(weImgeUrl)) {
                        thumb = ImageHelper.decodeBitmapFile(weImgeUrl, 240, 240);//(weImgeUrl, 240, 240)
                    } else {
                        thumb = BitmapFactory.decodeResource(getResources(),
                                R.drawable.ic_launcher);
                    }
                }
                switch (contentType) {
                    //两方法唯一区别在于url参数,一个为音乐url,一个为网页url
                    case ShareManager.SHARE_TYPE_MUSIC:
                        musicUrl = fromIntent.getStringExtra(ShareManager.MUSIC_URL);
                        shareMusicInWeChat(weUrl, musicUrl, weTitle, weContent, thumb, true);
                        break;
                    case ShareManager.SHARE_TYPE_WEB_PAGE:
                        shareWebPage(weUrl, weTitle, weContent, thumb, true);
                        break;
                    case ShareManager.SHARE_TYPE_PIC:
                        sharePicInWeChat(weImgeUrl, true);
                        break;
                    default:
                        shareWebPage(weUrl, weTitle, weContent, thumb, true);
                }
                break;

            case REQUESTCODE_SINA_SHARE:// 新浪微博分享
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_SINA_SHARE");
                bundle = fromIntent.getBundleExtra(KEY_SINA_SHARE_BUNDLE);
                contentType = fromIntent.getIntExtra(ShareManager.SHARE_TYPE, ShareManager.SHARE_TYPE_WEB_PAGE);
                String weiboTitle = bundle.getString(KEY_SHARE_TITLE);
                String weiboContent = bundle.getString(KEY_SHARE_CONTENT);
                String weiboUrl = bundle.getString(KEY_SHARE_URL);
                String weiboImgeUrl = bundle.getString(KEY_SHARE_IMAGE_URL);

                if (!TextUtils.isEmpty(weiboImgeUrl)) {
                    if (contentType != ShareManager.SHARE_TYPE_PIC) {
                        thumb = ImageHelper.decodeBitmapFile(weiboImgeUrl, 240, 240);//(weiboImgeUrl, 240, 240)
                    } else {//图片分享形式时,不处理缩略图
                        thumb = BitmapFactory.decodeFile(weiboImgeUrl);
                    }
                } else {
                    thumb = BitmapFactory.decodeResource(getResources(),
                            R.drawable.ic_launcher);
                }
//                params = buildUpdateParams(weiboContent, weiboUrl, thumb, null,
//                        null);
                sendImageWeibo(contentType, weiboTitle, weiboContent, weiboUrl, thumb);
                break;

            case REQUESTCODE_QQ_CONVERSATION:// QQ临时对话
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_QQ_CONVERSATION");
                startWPAConversation("482221967");// XXX Geekery QQ
                break;

            case REQUESTCODE_FOLLOW_WEIBO:// 关注新浪官方微博
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_FOLLOW_WEIBO");
                followOfficeWeibo();
                break;

            case REQUESTCODE_FOLLOW_WECHAT:// 关注微信公众号
                // Log.i("TT","AuthShareHelper-->handleIntent REQUESTCODE_FOLLOW_WECHAT");
                followWechat();
                break;

            case REQUESTCODE_QQ_JOIN_GROUP:// 加QQ群
                joinQQGroup();
                break;

            default:// 未知请求
                // Log.i("TT","AuthShareHelper-->handleIntent default");
                setResult(RESULTCODE_UNKNOWN);
                finishAuthShare();
                break;
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clear();
    }

    /**
     * 清除资源
     */
    private void clear() {
        if (mTencent != null) {
            mTencent.releaseResource();
        }

        mTencentListener = null;
        mTencent = null;

        if (mWeiboShareAPI != null) {
            mWeiboShareAPI = null;
        }
        mWeiboShareAPI = null;
        mShareResponse = null;
        weiboAuthListener = null;
        mSinaSsoHandler = null;
//        params = null;

        wxapi = null;
    }

    @Override
    public void finish() {
        // Log.i("TT","AuthShareHelper-->finish...");
        super.finish();
    }

    @Override
    public void onBackPressed() {
        // XXX
        // http://stackoverflow.com/questions/2679250/setresult-does-not-work-when-back-button-pressed
        Logger.i(TAG, "AuthShareHelper-->onBackPressed");
        setResult(Activity.RESULT_CANCELED);
        finishAuthShare();
        super.onBackPressed();
    }

    //endregion ===========================Activity 生命周期回调==================================

    //region ===========================QQ登录或分享相关==================================
    private Tencent mTencent;


    public static class QqUiListener implements IUiListener {

        private WeakReference<AuthShareHelper> mActivity;

        public QqUiListener(AuthShareHelper activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void onError(UiError error) {
//             Log.e("TT","AuthShareHelper-->IUiListener onError:"+error+" currentRequestCode:"+mCurrentRequestCode);
            if (mActivity == null || mActivity.get() == null) {
                return;
            }
            AuthShareHelper shareHelper = mActivity.get();
            Intent data = new Intent();
            if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_LOGIN) {
                data.putExtra(KEY_RESULT_STRING, "QQ登录发生错误");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_SHARE) {
                data.putExtra(KEY_RESULT_STRING, "QQ分享发生错误");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QZONE_SHARE) {
                data.putExtra(KEY_RESULT_STRING, "QQ空间分享发生错误");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_BIND) {
                // Log.i("TT","AuthShareHelper-->qqShareToQzone IUiListener onDownloadCancel:");
                data.putExtra(KEY_RESULT_STRING, "QQ绑定发生错误");
            }
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            shareHelper.setResult(Activity.RESULT_OK, data);
            shareHelper.finishAuthShare();
        }

        @Override
        public void onComplete(Object obj) {
            if (mActivity == null || mActivity.get() == null) {
                return;
            }
            AuthShareHelper shareHelper = mActivity.get();
            Intent data = new Intent();
            if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_LOGIN) {
                JSONObject values = (JSONObject) obj;
                Logger.i("AuthShareHelper", "QqUiListener-->onComplete result:" + values);
                // 保存access_token,openid
                try {
                    String token = values
                            .getString(Constants.PARAM_ACCESS_TOKEN);
                    long expires = values.getLong(Constants.PARAM_EXPIRES_IN);
                    String openId = values.getString(Constants.PARAM_OPEN_ID);
                    Logger.i("AuthShareHelper", "AuthShareHelper-->qqLogin IUiListener onComplete token:" + token
                            + " expires:" + expires
                            + " openId:" + openId);
                    if (!TextUtils.isEmpty(token) // &&
                            // !TextUtils.isEmpty(expires)
                            && !TextUtils.isEmpty(openId)) {
                        shareHelper.mTencent.setAccessToken(token, expires + "");
                        shareHelper.mTencent.setOpenId(openId);
                        AccessTokenKeeper.writeQQAccessToken(
                                shareHelper, openId, token, expires);
                        // 回传openId,access token
                        data.putExtra(KEY_RESULT_STRING, "QQ登录成功");
                        data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
                        shareHelper.setResult(Activity.RESULT_OK, data);
                        shareHelper.finishAuthShare();
                    }
                } catch (Exception e) {
                }
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_SHARE) {
                Logger.i("AuthShareHelper", "AuthShareHelper-->qqShare IUiListener onComplete:" + obj);
                data.putExtra(KEY_RESULT_STRING, "QQ分享成功 ");
                data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
                shareHelper.setResult(Activity.RESULT_OK, data);
                shareHelper.finishAuthShare();
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QZONE_SHARE) {
//                 Log.i("TT","AuthShareHelper-->qqShareToQzone IUiListener onComplete:"+obj);
                data.putExtra(KEY_RESULT_STRING, "QQ空间分享成功 ");
                data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
                shareHelper.setResult(Activity.RESULT_OK, data);
                shareHelper.finishAuthShare();
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_BIND) {//绑定QQ
                JSONObject values = (JSONObject) obj;
                try {
                    String token = values
                            .getString(Constants.PARAM_ACCESS_TOKEN);
                    long expires = values.getLong(Constants.PARAM_EXPIRES_IN);
                    String openId = values.getString(Constants.PARAM_OPEN_ID);
                    if (!TextUtils.isEmpty(token) && !TextUtils.isEmpty(openId)) {
                        shareHelper.mTencent.setAccessToken(token, expires + "");
                        shareHelper.mTencent.setOpenId(openId);
                        shareHelper.setQQUserInfo();//获取QQ用户的信息
                    }
                } catch (Exception e) {
                }
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_USER_INFO) {//获取用户信息
//                String qqName = new JSonParser().getStringValue((JSONObject) obj, "nickname");
                JSONObject jsonObject = (JSONObject) obj;
                String qqName = jsonObject.optString("nickname");
                data.putExtra("name", qqName);
                data.putExtra("openid", shareHelper.mTencent != null ? shareHelper.mTencent.getOpenId() : "");
                shareHelper.isGetInfo = true;
            }

            if (shareHelper.isGetInfo) {
                shareHelper.setResult(RESULTCODE_SUCCESS, data);
                shareHelper.finishAuthShare();
            }
        }

        @Override
        public void onCancel() {
            if (mActivity == null || mActivity.get() == null) {
                return;
            }
            AuthShareHelper shareHelper = mActivity.get();
            Logger.i("AuthShareHelper", "AuthShareHelper-->IUiListener onCancel currentRequestCode:" + shareHelper.mCurrentRequestCode);
            Intent data = new Intent();
            if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_LOGIN) {
                // Log.i("TT","AuthShareHelper-->qqLogin IUiListener onCancel:");
                data.putExtra(KEY_RESULT_STRING, "取消QQ登录");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_SHARE) {
                // Log.i("TT","AuthShareHelper-->qqShare IUiListener onCancel:");
                data.putExtra(KEY_RESULT_STRING, " 取消QQ分享 ");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QZONE_SHARE) {
//                 Log.i("TT","AuthShareHelper-->qqShareToQzone IUiListener onCancel:");
                data.putExtra(KEY_RESULT_STRING, "取消QQ空间分享");
            } else if (shareHelper.mCurrentRequestCode == REQUESTCODE_QQ_BIND) {
                // Log.i("TT","AuthShareHelper-->qqShareToQzone IUiListener onCancel:");
                data.putExtra(KEY_RESULT_STRING, "取消QQ绑定");
            }
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            shareHelper.setResult(Activity.RESULT_OK, data);
            shareHelper.finishAuthShare();
        }
    }

    /**
     * QQ登录、QQ或QQ分享或绑定 回调
     */
    private QqUiListener mTencentListener = new QqUiListener(this);

    /**
     * 判断QQ APP是否安装
     */
    private boolean isQQInstalled() {
        if (mTencent == null) {
            mTencent = Tencent.createInstance(Config.QQ_APPID, this);
        }
        return mTencent.isSupportSSOLogin(this);
    }

    /**
     * QQ授权登录
     */
    private void qqLogin() {
        if (isQQInstalled()) {
            if (mTencent == null) {
                mTencent = Tencent
                        .createInstance(Config.QQ_APPID, this);
            }
            String scope = "all";// 配置相应的申请权限get_user_info
//             Log.i("TT","mTencent.isSessionValid:"+mTencent.isSessionValid());
            if (!mTencent.isSessionValid()) {
                mTencent.login(this, scope, mTencentListener);
            } else {
                SharedPreferences sp = getSharedPreferences(
                        AccessTokenKeeper.QQ_OAUTH_NAME,
                        Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = sp.edit();
                editor.putString(AccessTokenKeeper.KEY_OPENID, mTencent.getOpenId());
                editor.putString(AccessTokenKeeper.KEY_ACCESS_TOKEN, mTencent.getAccessToken());
                editor.apply();

                Intent data = new Intent();
                data.putExtra(KEY_RESULT_STRING,
                        "QQ登录成功,openId:" + mTencent.getOpenId() + ",token:"
                                + mTencent.getAccessToken());

                data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
                AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                finishAuthShare();
            }
        } else {// 手机没有安装QQ提示
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "手机未安装QQ,请先安装QQ");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    }

    /**
     * QQ授权登录后绑定
     */
    private void qqBind() {
        if (isQQInstalled()) {
            if (mTencent == null) {
                mTencent = Tencent
                        .createInstance(Config.QQ_APPID, this);
            }
            String scope = "all";// 配置相应的申请权限get_user_info
            mTencent.login(this, scope, mTencentListener);
        } else {// 手机没有安装QQ提示
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "手机未安装QQ,请先安装QQ");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    }

    /**
     * 得到QQ的昵称和openid 用于绑定操作
     */
    private void setQQUserInfo() {
        mCurrentRequestCode = REQUESTCODE_QQ_USER_INFO;
        UserInfo info = new UserInfo(this, mTencent.getQQToken());
        info.getUserInfo(mTencentListener);
    }

    /**
     * QQ 注销登录
     */
    private void qqLogout() {
        if (mTencent == null) {
            mTencent = Tencent.createInstance(Config.QQ_APPID, this);
        }
        mTencent.logout(this);
        finish();
    }

    /**
     * 分享到QQ空间
     */
    private void qqShareToQzone(final Bundle bundle) {
        if (mTencent == null) {
            mTencent = Tencent.createInstance(Config.QQ_APPID, this);
        }
        // QZone分享要在主线程做
        ThreadManager.getMainHandler().post(new Runnable() {
            @Override
            public void run() {
                if (null != mTencent) {
                    mTencent.shareToQzone(AuthShareHelper.this, bundle,
                            mTencentListener);
                }
            }
        });
//        Log.i("TT", "AuthShareHelper-->qqShareToQzone end bundle:" + bundle);
    }

    /**
     * QQ分享,不需要提前登录
     */
    private void qqShare(final Bundle bundle) {
        if (mTencent == null) {
            mTencent = Tencent.createInstance(Config.QQ_APPID, this);
        }
        // QQ分享要在主线程做
        ThreadManager.getMainHandler().post(new Runnable() {

            @Override
            public void run() {
                if (null != mTencent) {
                    mTencent.shareToQQ(AuthShareHelper.this, bundle,
                            mTencentListener);
                }
            }
        });

        // Log.i("TT","AuthShareHelper-->qqShare end");
    }

    /**
     * 组装QQ或QQ空间分享数据,图文分享(普通分享)
     *
     * @param shareToQQ true表示分享到QQ,false表示分享到QQ空间
     * @param url       消息被好友点击后的跳转URL
     * @param title     QQ分享标题
     * @param summary   QQ分享消息摘要
     * @param imgUrl    分享的图片URL或者本地路径,图片宽高不能超过140
     * @param appName   手机QQ客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
     */
    public static Bundle buildQQShareParams(boolean shareToQQ, String url,
                                            String title, String summary, String imgUrl, String appName) {
        Bundle bundle = new Bundle();
        if (shareToQQ) {
            // 分享的类型。图文分享(普通分享)填SHARE_TO_QQ_TYPE_DEFAULT
            bundle.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE,
                    QQShare.SHARE_TO_QQ_TYPE_DEFAULT);
            // 这条分享消息被好友点击后的跳转URL。
            bundle.putString(QQShare.SHARE_TO_QQ_TARGET_URL, url);
            // 分享的标题。注：PARAM_TITLE、PARAM_IMAGE_URL、PARAM_
            // SUMMARY不能全为空,最少必须有一个是有值的。
            bundle.putString(QQShare.SHARE_TO_QQ_TITLE, title);
            // 分享的消息摘要,最长50个字
            bundle.putString(QQShare.SHARE_TO_QQ_SUMMARY, summary);
            // 分享的图片URL或者本地路径
            // bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_LOCAL_URL, imgUrl);
            if (!TextUtils.isEmpty(imgUrl)) {
                if (FileUtils.isFileExist(imgUrl)) {
                    bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, imgUrl);//要求宽高不能超过140
                }
            }
            // 手Q客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
            bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, appName);
            // 标识该消息的来源应用,值为应用名称+AppId。
            // bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, "乐享动" +
            // OAuthContants.QQ_APPID);
        } else {
            // 分享的类型。图文分享(普通分享)填SHARE_TO_QZONE_TYPE_IMAGE_TEXT
            bundle.putInt(QzoneShare.SHARE_TO_QZONE_KEY_TYPE,
                    QzoneShare.SHARE_TO_QZONE_TYPE_IMAGE_TEXT);
            // 这条分享消息被好友点击后的跳转URL。
            bundle.putString(QzoneShare.SHARE_TO_QQ_TARGET_URL, url);
            // 分享的标题。注：PARAM_TITLE、PARAM_IMAGE_URL、PARAM_
            // SUMMARY不能全为空,最少必须有一个是有值的。
            bundle.putString(QzoneShare.SHARE_TO_QQ_TITLE, title);
            // 分享的消息摘要,最长50个字
            bundle.putString(QzoneShare.SHARE_TO_QQ_SUMMARY, summary);
            // 分享的图片URL或者本地路径
            if (!TextUtils.isEmpty(imgUrl)) {
                ArrayList<String> imageUrls = new ArrayList<>();
                if (FileUtils.isFileExist(imgUrl)) {
                    imageUrls.add(imgUrl);
                }
                bundle.putStringArrayList(QzoneShare.SHARE_TO_QQ_IMAGE_URL,
                        imageUrls);
            }
            // 手Q客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
            bundle.putString(QzoneShare.SHARE_TO_QQ_APP_NAME, appName);
            // 标识该消息的来源应用,值为应用名称+AppId。
            // bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, "乐享动" +
            // OAuthContants.QQ_APPID);
//            Log.i("TT",String.format("buildQQShareParams Qzone url:%s,title:%s,summary:%s,imgUrl:%s,appName:%s",
//                    url,title,summary,imgUrl,appName));
        }
        return bundle;
    }

    /**
     * 组装QQ或QQ空间分享数据,纯图片分享。注意:QQ空间目前不支持纯图片分享,只能通过QQ share
     *
     * @param shareToQQ true表示分享到QQ,false表示分享到QQ空间
     * @param imgUrl    分享的图片URL或者本地路径
     * @param appName   手机QQ客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
     */
    public static Bundle buildQQSharePicParams(boolean shareToQQ, String imgUrl, String appName) {
        Bundle bundle = new Bundle();
        if (shareToQQ) {
            // 分享的类型,纯图片
            bundle.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE,
                    QQShare.SHARE_TO_QQ_TYPE_IMAGE);
            //分享的图片URL或者本地路径
            bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_LOCAL_URL, imgUrl);
//            bundle.putInt(QQShare.SHARE_TO_QQ_EXT_INT,QQShare.SHARE_TO_QQ_FLAG_QZONE_AUTO_OPEN);
            // 手Q客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
            bundle.putString(QQShare.SHARE_TO_QQ_APP_NAME, appName);
        } else {
            // 分享的类型,纯图片
            bundle.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE,
                    QQShare.SHARE_TO_QQ_TYPE_IMAGE);
            //分享的图片URL或者本地路径
            bundle.putString(QQShare.SHARE_TO_QQ_IMAGE_LOCAL_URL, imgUrl);
            bundle.putInt(QQShare.SHARE_TO_QQ_EXT_INT, QQShare.SHARE_TO_QQ_FLAG_QZONE_AUTO_OPEN);
            // 手Q客户端顶部,替换“返回”按钮文字,如果为空,用返回代替
            bundle.putString(QzoneShare.SHARE_TO_QQ_APP_NAME, appName);
        }
        return bundle;
    }


    /**
     * 发起临时QQ会话
     *
     * @param uin 对方的QQ号码。
     */
    private void startWPAConversation(String uin) {
        if (mTencent == null) {
            mTencent = Tencent.createInstance(Config.QQ_APPID, this);
        }
        if (isQQInstalled()) {
            mTencent.startWPAConversation(this, uin, "");
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "QQ临时会话成功");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
            setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        } else {// 手机没有安装QQ提示
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "手机未安装QQ,请先安装QQ");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    }

    /**
     * 加入QQ群
     */
    public void joinQQGroup() {
        if (isQQInstalled()) {
            //String key = "CHZT7gX4ABt812Cw0PFZ16AUJT19IO9h";//QQ1群的Key
            //String key = "5zodNn4D1-cmJoIpLMiuxcJmVLxosX6C";//QQ2群的key
            String key = "rPBbyJAcDhIczHtuiiKjMU-vNaE8Jin5";//QQ3群的key
            Intent intent = new Intent();
            intent.setData(Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D" + key));
            // 此Flag可根据具体产品需要自定义,如设置,则在加群界面按返回,返回手Q主界面,不设置,按返回会返回到呼起产品界面    //
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(intent);
            } catch (Exception e) {

            }
            finishAuthShare();
        } else {// 手机没有安装QQ提示
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "手机未安装QQ,请先安装QQ");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }

    }

    //endregion ===========================QQ登录或分享相关==================================

    //region ===========================新浪微博登录或分享相关==================================
    /**
     * 微博分享的接口实例
     */
    private WbShareHandler mWeiboShareAPI;//新浪微博sdk V2.0.3新方式
    //    private IWeiboShareAPI mWeiboShareAPI;
    private AuthInfo mAuthInfo;
    private SsoHandler mSinaSsoHandler;
//    private WeiboParameters params;
//    private AttentionComponentView mAttentionView;

//    private IWeiboHandler.Response mShareResponse = new IWeiboHandler.Response() {//
//        /**
//         * 接收微客户端博请求的数据。 当微博客户端唤起当前应用并进行分享时,该方法被调用。
//         *
//         * @param baseResp
//         *            微博请求数据对象
//         * @see {@link IWeiboShareAPI#handleWeiboRequest}
//         */
//        @Override
//        public void onResponse(BaseResponse baseResp) {
//            Intent data = new Intent();
//            switch (baseResp.errCode) {
//                case WBConstants.ErrorCode.ERR_OK:
//                    // Log.i("TT","IWeiboHandler.Response-->微博客户端分享成功");
//                    data.putExtra(KEY_RESULT_STRING, "微博授权分享成功");
//                    data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
//                    break;
//                case WBConstants.ErrorCode.ERR_CANCEL:
//                    // Log.i("TT","IWeiboHandler.Response-->微博客户端分享取消");
//                    data.putExtra(KEY_RESULT_STRING, "微博授权分享取消");
//                    data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
//                    break;
//                case WBConstants.ErrorCode.ERR_FAIL:
//                    // Log.i("TT","IWeiboHandler.Response-->微博客户端分享失败");
//                    data.putExtra(KEY_RESULT_STRING, "微博授权分享失败");
//                    data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
//                    break;
//            }
//            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
//            finishAuthShare();
//        }
//    };

    /**
     * 接收微客户端博请求的数据。 当微博客户端唤起当前应用并进行分享时,该方法被调用。
     * <br/>新浪微博sdk V2.0.3新方式
     */
    private WbShareCallback mShareResponse = new WbShareCallback() {
        @Override
        public void onWbShareSuccess() {
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "微博授权分享成功");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }

        @Override
        public void onWbShareCancel() {
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "微博授权分享取消");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }

        @Override
        public void onWbShareFail() {
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "微博授权分享失败");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    };

    /**
     * 微博认证回调
     * <br/>新浪微博sdk V2.0.3新方式
     */
    private WbAuthListener weiboAuthListener = new WbAuthListener() {

        @Override
        public void onSuccess(Oauth2AccessToken oauth2AccessToken) {
            if (oauth2AccessToken == null) {
                Intent data = new Intent();
                String message = getString(R.string.weibosdk_toast_auth_failed);
                data.putExtra(KEY_RESULT_STRING, "微博授权登录发生错误" + message);
                data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
                AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                finishAuthShare();
                return;
            }
            Logger.i("AuthShareHelper", "weibo-->onComplete oauth2AccessToken:" + oauth2AccessToken);
            // 从这里获取用户输入的 电话号码信息
            // String phoneNum = mAccessToken.getPhoneNum();
            // Log.i("TT","AuthShareHelper-->weiBoLogin onComplete mAccessToken.isSessionValid():"+mAccessToken.isSessionValid()+" mCurrentRequestCode:"+mCurrentRequestCode);
            Intent data = new Intent();
            if (oauth2AccessToken.isSessionValid()) {
                // 保存 Token 到 SharedPreferences
                AccessTokenKeeper.writeSinaAccessToken(AuthShareHelper.this,
                        oauth2AccessToken);
                if (mCurrentRequestCode == REQUESTCODE_SINA_LOGIN) {
                    String result = "微博登录授权成功";
                    data.putExtra(KEY_RESULT_STRING, result);
                    Logger.i("AuthShareHelper", "AuthShareHelper-->weiBoLogin onComplete result:" + data.getStringExtra(KEY_RESULT_STRING));
                    data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
                    AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
                    AuthShareHelper.this.finishAuthShare();
                }

//                if (mCurrentRequestCode == REQUESTCODE_SINA_SHARE) {// 继续分享操作
//                    sendImageWeibo(params);
//                }

                if (mCurrentRequestCode == REQUESTCODE_FOLLOW_WEIBO) {// 继续关注操作
                    followOfficeWeibo();
                }
                if (mCurrentRequestCode == REQUESTCODE_SINA_BIND) {//微博绑定操作
                    setWBName(oauth2AccessToken.getToken(), oauth2AccessToken.getUid());
                }
            }
        }

        @Override
        public void cancel() {
            Intent data = new Intent();
            if (mCurrentRequestCode == REQUESTCODE_SINA_LOGIN) {
                Logger.i("AuthShareHelper", "AuthShareHelper-->weiBoLogin WeiboAuthListener onCancel:");
                data.putExtra(KEY_RESULT_STRING, "取消微博授权登录");
            }
            // Intent data = new Intent();
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }

        @Override
        public void onFailure(WbConnectErrorMessage wbConnectErrorMessage) {
            Intent data = new Intent();
            String message = getString(R.string.weibosdk_toast_auth_failed);
            if (wbConnectErrorMessage != null) {
                message = message + "\nObtained the code: " + wbConnectErrorMessage.getErrorCode();
            }
            data.putExtra(KEY_RESULT_STRING, "微博授权登录发生错误" + message);
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    };

//    private WeiboAuthListener weiboAuthListener = new WeiboAuthListener() {
//
//        @Override
//        public void onWeiboException(WeiboException exception) {
//            // Log.e("TT","AuthShareHelper-->WeiboAuthListener onWeiboException:"+exception);
//            Intent data = new Intent();
//            data.putExtra(KEY_RESULT_STRING, "微博授权登录发生错误");
//            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
//            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
//            finishAuthShare();
//        }
//
//        @Override
//        public void onComplete(Bundle bundle) {
//            Oauth2AccessToken mAccessToken = Oauth2AccessToken
//                    .parseAccessToken(bundle);
////            Log.i("TT", "weibo-->onComplete bundle:"+bundle);
//            // 从这里获取用户输入的 电话号码信息
//            // String phoneNum = mAccessToken.getPhoneNum();
//            // Log.i("TT","AuthShareHelper-->weiBoLogin onComplete mAccessToken.isSessionValid():"+mAccessToken.isSessionValid()+" mCurrentRequestCode:"+mCurrentRequestCode);
//            Intent data = new Intent();
//            if (mAccessToken.isSessionValid()) {
//                // 保存 Token 到 SharedPreferences
//                AccessTokenKeeper.writeSinaAccessToken(AuthShareHelper.this,
//                        mAccessToken);
//                if (mCurrentRequestCode == REQUESTCODE_SINA_LOGIN) {
//                    String result = "微博登录授权成功";
//                    data.putExtra(KEY_RESULT_STRING, result);
//                    // Log.i("TT","AuthShareHelper-->weiBoLogin onComplete result:"+data.getStringExtra(KEY_RESULT_STRING));
//                    data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
//                    AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
//                    AuthShareHelper.this.finishAuthShare();
//                }
//
//                if (mCurrentRequestCode == REQUESTCODE_SINA_SHARE) {// 继续分享操作
//                    sendImageWeibo(params);
//                }
//
//                if (mCurrentRequestCode == REQUESTCODE_FOLLOW_WEIBO) {// 继续关注操作
//                    followOfficeWeibo();
//                }
//                if (mCurrentRequestCode == REQUESTCODE_SINA_BIND) {//微博绑定操作
//                    setWBName(mAccessToken.getToken(), mAccessToken.getUid());
//                }
//            } else {
//                // 以下几种情况,您会收到 Code：
//                // 1. 当您未在平台上注册的应用程序的包名与签名时；
//                // 2. 当您注册的应用程序包名与签名不正确时；
//                // 3. 当您在平台上注册的包名和签名与您当前测试的应用的包名和签名不匹配时。
//                String code = bundle.getString("code");
//                String message = getString(R.string.weibosdk_toast_auth_failed);
//                if (!TextUtils.isEmpty(code)) {
//                    message = message + "\nObtained the code: " + code;
//                }
//                data.putExtra(KEY_RESULT_STRING, "微博授权登录发生错误:" + message);
//                data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
////                AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
////                finishAuthShare();
//            }
//        }
//
//        @Override
//        public void onCancel() {
//            // Log.i("TT","AuthShareHelper-->WeiboAuthListener onCancel:");
//            Intent data = new Intent();
//            if (mCurrentRequestCode == REQUESTCODE_SINA_LOGIN) {
//                // Log.i("TT","AuthShareHelper-->weiBoLogin WeiboAuthListener onCancel:");
//                data.putExtra(KEY_RESULT_STRING, "取消微博授权登录");
//            }
//            // Intent data = new Intent();
//            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
//            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
//            finishAuthShare();
//        }
//    };

    /**
     * 微博登录
     */
    public void weiboLogin() {
        Oauth2AccessToken accessToken = AccessTokenKeeper
                .readSinaAccessToken(this);

        if (accessToken.isSessionValid()) {
            // 授权仍有效,直接用access_token登录后台
            // Log.i("TT",
            // "weiBoLogin-->mAccessToken.isSessionValid() token:"+accessToken.getToken());
            Intent data = new Intent();
            String openId = accessToken.getUid();
            String token = accessToken.getToken();
            data.putExtra(KEY_RESULT_STRING, "微博登录成功,openId:" + openId
                    + ",token:" + token);
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        } else {
            // SSO 授权, ALL IN ONE ,没有则进行网页授权
            mSinaSsoHandler.authorize(weiboAuthListener);
        }
    }

    /**
     * 微博登录 绑定
     */
    public void weiboBind() {
        mSinaSsoHandler.authorize(weiboAuthListener);
    }

    // 新浪登录 设置新浪昵称和openid
    public void setWBName(final String accessToken, final String uid) {
//        String url = "https://api.weibo.com/2/users/show.json?access_token=" + accessToken + "&uid=" + uid;
//        String result = OkHttpUtil.getInstance().getStringFromServer(url);

        final String url = String.format("https://api.weibo.com/2/users/show.json?access_token=%s&uid=%s",
                accessToken,
                uid);
        ThreadManager.executeOnNetWorkThread(new Runnable() {
            @Override
            public void run() {
                Intent data = new Intent();
                String result = OkHttpUtil.getInstance().getStringFromServer(url);
                String WBName = "";
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    WBName = jsonObject.optString("screen_name");
//                    String WBName = NetParse.getInstance().getStringValueByTag(result, "screen_name");
                } catch (Exception e) {
                }
                data.putExtra("openid", uid);
                data.putExtra("name", WBName);
                isWBbind = true;
                AuthShareHelper.this.setResult(RESULTCODE_SUCCESS, data);
                finishAuthShare();
            }
        });
    }

//    /**
//     * 发送带本地图片的微博
//     */
//    public void sendImageWeibo(WeiboParameters params) {
//        // Log.i("TT","sendImageWeibo-->begin");
//        Oauth2AccessToken accessToken = AccessTokenKeeper
//                .readSinaAccessToken(this);
//        if (accessToken.isSessionValid()) {
//            params.put("access_token", accessToken.getToken());
//            String url = "https://api.weibo.com/2/statuses/upload.json";// 发微博地址
//            new AsyncWeiboRunner(AuthShareHelper.this).requestAsync(url,
//                    params, "POST", new RequestListener() {
//                        @Override
//                        public void onComplete(String response) {
//                            Logger.i("AuthShareHelper", "sendImageWeibo-->onComplete response:" + response);
//                            if (!TextUtils.isEmpty(response)
//                                    && response.startsWith("{\"created_at\"")) {
//                                // Log.i("TT","sendImageWeibo-->onComplete");
//                                Intent data = new Intent();
//                                data.putExtra(KEY_RESULT_STRING, "微博分享成功");
//                                data.putExtra(KEY_RESULT_CODE,
//                                        RESULTCODE_SUCCESS);
//                                AuthShareHelper.this.setResult(
//                                        Activity.RESULT_OK, data);
//                                // Log.i("TT","sendImageWeibo-->onComplete 微博分享成功 ");
//                                finishAuthShare();
//                            }
//                        }
//
//                        @Override
//                        public void onWeiboException(WeiboException e) {
//                            Logger.e("AuthShareHelper", e.getMessage());
//                            Intent data = new Intent();
//                            data.putExtra(KEY_RESULT_STRING, "微博分享失败");
//                            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
//                            AuthShareHelper.this.setResult(Activity.RESULT_OK,
//                                    data);
//                            finishAuthShare();
//                        }
//                    });
//        } else {
//            // SSO 授权, ALL IN ONE ,没有则进行网页授权
//            mSinaSsoHandler.authorize(weiboAuthListener);
//        }
//    }

    /**
     * 发送带本地图片的微博
     *
     * @param contentType 分享类型 ,444:网页,默认链接形式,445:音乐,446:图片
     * @param title       分享标题
     * @param content     分享内容
     * @param url         链接地址
     * @param thumb       缩略图或分享大图
     */
    public void sendImageWeibo(int contentType, String title, String content, String url, Bitmap thumb) {
        WeiboMultiMessage weiboMessage = new WeiboMultiMessage();

        if (contentType == ShareManager.SHARE_TYPE_PIC) {//图片
            if (thumb != null) {
                ImageObject imageObject = new ImageObject();
                imageObject.setImageObject(thumb);
                weiboMessage.imageObject = imageObject;
            }
        } else {
            TextObject textObject = new TextObject();
            textObject.title = title;
            textObject.text = title + "\n" + content;
            textObject.actionUrl = url;
            weiboMessage.textObject = textObject;
        }
        WebpageObject mediaObject = new WebpageObject();
        mediaObject.identify = Utility.generateGUID();
        mediaObject.title = title;
        mediaObject.description = content;
        // 设置 Bitmap 类型的图片到视频对象里
        if (contentType != ShareManager.SHARE_TYPE_PIC) {
            mediaObject.setThumbImage(thumb);//设置缩略图.注意:最终压缩过的缩略图大小不得超过 32kb。
        } else {
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
            mediaObject.setThumbImage(bitmap);//设置缩略图.注意:最终压缩过的缩略图大小不得超过 32kb。
        }
        mediaObject.actionUrl = url;
        mediaObject.defaultText = content;//Webpage 默认文案
        weiboMessage.mediaObject = mediaObject;

        if (mWeiboShareAPI == null) {
            // 创建微博 SDK 接口实例
            mWeiboShareAPI = new WbShareHandler(this);//新浪微博sdk V2.0.3新方式
            // 注册第三方应用到微博客户端中,注册成功后该应用将显示在微博的应用列表中。
            mWeiboShareAPI.registerApp();
        }
        mWeiboShareAPI.shareMessage(weiboMessage, false);

    }

    /**
     * 关注官方微博
     */
    public void followOfficeWeibo() {
        //TODO
//        Oauth2AccessToken accessToken = AccessTokenKeeper
//                .readSinaAccessToken(this);
//        // Log.i("TT","followOfficeWeibo begin accessToken.isSessionValid():"+accessToken.isSessionValid());
//        if (accessToken.isSessionValid()) {
//            // 授权仍有效,直接用access_token登录的用户关注
//            if (findViewById(R.id.ATTENTION_VIEW_ID) == null) {
//                mAttentionView = new AttentionComponentView(this);// 关注微博按钮
//                mAttentionView.setId(R.id.ATTENTION_VIEW_ID);
//                LayoutParams params = new LayoutParams(1, 1);
//                addContentView(mAttentionView, params);
//            } else {
//                mAttentionView = (AttentionComponentView) findViewById(R.id.ATTENTION_VIEW_ID);
//            }
//            mAttentionView.setClickable(true);
//            mAttentionView.setOnClickListener(new OnClickListener() {
//
//                @Override
//                public void onClick(View v) {
//                    try {// 通过反射私有方法,关注
//                        Method method = AttentionComponentView.class
//                                .getDeclaredMethod("execAttented"
//                                );
//                        method.setAccessible(true);
//                        method.invoke(mAttentionView);
//                    } catch (NoSuchMethodException ex) {
//                        ex.printStackTrace();
//                    } catch (InvocationTargetException e1) {
//                        e1.printStackTrace();
//                    } catch (IllegalAccessException e2) {
//                        e2.printStackTrace();
//                    }
//                }
//            });
//            mAttentionView
//                    .setAttentionParam(AttentionComponentView.RequestParam
//                            .createRequestParam(Config.WEIBO_APPKEY,
//                                    accessToken.getToken(),
//                                    Config.SINA_WEIBO_ID, "",
//                                    new WeiboAuthListener() {
//                                        @Override
//                                        public void onWeiboException(
//                                                WeiboException ex) {
//                                            // Log.e("TT","followOfficeWeibo-->WeiboAuthListener onWeiboException "+ex.getMessage());
//                                            Intent data = new Intent();
//                                            data.putExtra(KEY_RESULT_STRING,
//                                                    "关注新浪官方微博发生错误");
//                                            data.putExtra(KEY_RESULT_CODE,
//                                                    RESULTCODE_FAILURE);
//                                            setResult(Activity.RESULT_OK, data);
//                                            finishAuthShare();
//                                        }
//
//                                        @Override
//                                        public void onComplete(Bundle bundle) {
//                                            if (mWeiboShareAPI == null) {
//                                                mWeiboShareAPI = WeiboShareSDK.createWeiboAPI(AuthShareHelper.this,
//                                                        Config.WEIBO_APPKEY);
//                                            }
//                                            /** java.lang.NullPointerException
//                                             *  at com.fitmix.sdk.common.share.AuthShareHelper$8.onComplete(AuthShareHelper.java:1207)*/
//                                            boolean isInstalledWeibo =mWeiboShareAPI.isWbAppInstalled();
////                                            boolean isInstalledWeibo = mWeiboShareAPI
////                                                    .isWeiboAppInstalled();
//                                            // Log.i("TT","followOfficeWeibo-->WeiboAuthListener onComplete launch weibo?:"+isInstalledWeibo);
//                                            if (isInstalledWeibo) {// 如果手机安装了微博客户端则启动微博客户端
//                                                mWeiboShareAPI
//                                                        .launchWeibo(AuthShareHelper.this);
//                                            }
//                                            Intent data = new Intent();
//                                            data.putExtra(KEY_RESULT_STRING,
//                                                    "关注新浪官方微博成功");
//                                            data.putExtra(KEY_RESULT_CODE,
//                                                    RESULTCODE_SUCCESS);
//                                            setResult(Activity.RESULT_OK, data);
//                                            finishAuthShare();
//                                        }
//
//                                        @Override
//                                        public void onCancel() {
//                                            // Log.i("TT","followOfficeWeibo-->WeiboAuthListener onCancel");
//                                            Intent data = new Intent();
//                                            data.putExtra(KEY_RESULT_STRING,
//                                                    "关注新浪官方微博取消");
//                                            data.putExtra(KEY_RESULT_CODE,
//                                                    RESULTCODE_UNKNOWN);
//                                            setResult(Activity.RESULT_OK, data);
//                                            finishAuthShare();
//                                        }
//                                    }));
//
//            mAttentionView.performClick();
//            // Log.i("TT","followOfficeWeibo end");
//        } else {
//            // Toast.makeText(AuthShareHelper.this, R.string.need_login_weibo,
//            // Toast.LENGTH_SHORT)
//            // .show();
//            // SSO 授权, ALL IN ONE ,没有则进行网页授权
//            mSinaSsoHandler.authorize(weiboAuthListener);
//            // Log.i("TT","followOfficeWeibo-->reAuth mSinaSsoHandler is null:"+(mSinaSsoHandler
//            // == null)
//            // +" weiboAuthListener is null"+(weiboAuthListener == null));
//        }
    }

    /**
     * 组装新浪微博分享数据
     *
     * @param title   分享标题
     * @param content 分享消息内容
     * @param url     消息被点击后的跳转URL
     * @param imgUrl  分享的图片本地路径
     */
    public static Bundle buildWeiboShareParams(String title, String content, String url,
                                               String imgUrl) {
        Bundle bundle = new Bundle();

        if (!TextUtils.isEmpty(title)) {
            bundle.putString(KEY_SHARE_TITLE, title);
        } else {
            bundle.putString(KEY_SHARE_TITLE, "");
        }

        if (!TextUtils.isEmpty(content)) {
            bundle.putString(KEY_SHARE_CONTENT, content);
        } else {
            bundle.putString(KEY_SHARE_CONTENT, "");
        }

        if (!TextUtils.isEmpty(url)) {
            bundle.putString(KEY_SHARE_URL, url);
        } else {
            bundle.putString(KEY_SHARE_URL, "");
        }

        if (!TextUtils.isEmpty(imgUrl)) {
            if (FileUtils.isFileExist(imgUrl)) {
                bundle.putString(KEY_SHARE_IMAGE_URL, imgUrl);
            }
        } else {
            bundle.putString(KEY_SHARE_IMAGE_URL, "");
        }

        return bundle;
    }

//    /**
//     * 组装微博分享请求参数
//     *
//     * @param content   分享内容
//     * @param actionUrl 点击分享跳转的网址
//     * @param thumb     分享的图片
//     * @param lat       纬度
//     * @param lon       经度
//     * @return
//     */
//    private WeiboParameters buildUpdateParams(String content, String actionUrl,
//                                              Bitmap thumb, String lat, String lon) {
//        WeiboParameters params = new WeiboParameters(
//                Config.WEIBO_APPKEY);
//        if (TextUtils.isEmpty(content) || TextUtils.isEmpty(actionUrl)) {
//            // Log.i("TT","sendImageWeibo-->content or actionUrl is empty!");
//            return params;
//        }
//
//        if (!TextUtils.isEmpty(lon)) {
//            params.put("long", lon);
//        }
//        if (!TextUtils.isEmpty(lat)) {
//            params.put("lat", lat);
//        }
//        // 将网址与内容拼接
//        String cb = String.format("%s %s", content, actionUrl);
//        params.put("pic", thumb);
//        params.put("status", cb);
//        // Log.i("TT","AuthShareHelper buildUpdateParams-->content:"+cb+" thumb.bytes:"+thumb.getRowBytes());
//        return params;
//    }

    //endregion ===========================新浪微博登录或分享相关==================================

    //region ===========================微信登录或分享相关==================================
    private final int THUMB_SIZE = 100;// 缩略图大小
    private IWXAPI wxapi;// 和微信通信的openapi接口

    /**
     * 微信登录
     */
    public void wechatLogin() {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(AuthShareHelper.this,
                    Config.WEIXIN_APPID, true);
        }
        Intent data = new Intent();
        if (!wxapi.isWXAppInstalled()) {// 没有安装微信
            data.putExtra(KEY_RESULT_STRING, "请先安装微信");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
            // Toast.makeText(AuthShareHelper.this,
            // R.string.should_install_wechat,
            // Toast.LENGTH_SHORT).show();
            return;
        }

        // 重新设置结果信息
        // AccessTokenKeeper.writeWechatResult(getApplicationContext(),
        // AuthShareHelper.REQUESTCODE_WECHAT_LOGIN,
        // AuthShareHelper.RESULTCODE_UNKNOWN,"");

        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";// 获取用户个人信息
        req.state = "fitmix";// XXX 添加随机值,并随后校验可用于防止csrf攻击
        req.transaction = "login";//
        wxapi.sendReq(req);
        // finish();
    }

    /**
     * 微信登录 绑定
     */
    public void wechatBind() {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(AuthShareHelper.this,
                    Config.WEIXIN_APPID, true);
        }
        Intent data = new Intent();
        if (!wxapi.isWXAppInstalled()) {// 没有安装微信
            data.putExtra(KEY_RESULT_STRING, "请先安装微信");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
            return;
        }

        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";// 获取用户个人信息
        req.state = "fitmix";// XXX 添加随机值,并随后校验可用于防止csrf攻击
        req.transaction = "bind";//
        wxapi.sendReq(req);
        // finish();
    }

    /**
     * 微信分享网页
     *
     * @param url           网页网址
     * @param title         分享标题,注意限制长度不超过512字节
     * @param description   分享简介,注意长度必须小于1KB
     * @param thumb         分享小图标,注意限制内容大小不超过32KB
     * @param shareToCircle 是否分享到朋友圈
     */
    public void shareWebPage(String url, String title, String description,
                             Bitmap thumb, boolean shareToCircle) {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(this, Config.WEIXIN_APPID,
                    true);
        }
        WXWebpageObject webpage = new WXWebpageObject();
        webpage.webpageUrl = url;
        WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = title;
        msg.description = description;
        if (thumb != null) {
//            Bitmap thumbBmp = Bitmap.createScaledBitmap(thumb, THUMB_SIZE,
//                    THUMB_SIZE, true);

//            msg.thumbData = Util.bmpToByteArray(thumb, true); // 设置缩略图
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            thumb.compress(Bitmap.CompressFormat.PNG, 100, baos);
            int options = 90;
            while (baos.toByteArray().length / 1024 > 32) {  //循环判断如果压缩后图片是否大于32kb,大于继续压缩
                baos.reset();
                thumb.compress(Bitmap.CompressFormat.JPEG, options, baos);//这里压缩options%,把压缩后的数据存放到baos中
                options -= 10;//每次都减少10,注意有可能为负,为负会报错
                if (options == 0) {
                    break;
                }
            }
            msg.thumbData = baos.toByteArray();
            thumb.recycle();
            // msg.setThumbImage(thumb);
            // msg.thumbData = Util.bmpToByteArray(thumb, true);
            // Log.i("TT","Weixin shareWebPage msg.thumbData.length:"+msg.thumbData.length);
        }

        SendMessageToWX.Req req = new SendMessageToWX.Req();
        if (shareToCircle) {
            // 重新设置结果信息
            // AccessTokenKeeper.writeWechatResult(getApplicationContext(),
            // AuthShareHelper.REQUESTCODE_CIRCLE_SHARE,
            // AuthShareHelper.RESULTCODE_UNKNOWN,"");
            req.transaction = "shareToCircle";// +System.currentTimeMillis();
        } else {
            // 重新设置结果信息
            // AccessTokenKeeper.writeWechatResult(getApplicationContext(),
            // AuthShareHelper.REQUESTCODE_WECHAT_SHARE,
            // AuthShareHelper.RESULTCODE_UNKNOWN,"");
            req.transaction = "shareToFriend";// +System.currentTimeMillis();
        }
        req.message = msg;
        req.scene = shareToCircle ? SendMessageToWX.Req.WXSceneTimeline
                : SendMessageToWX.Req.WXSceneSession;
        wxapi.sendReq(req);
        // Log.i("TT","Weixin shareWebPage end");
        // finish();
    }

    /**
     * 在微信分享音乐
     *
     * @param url           音乐网页URL
     * @param musicUrl      音乐URL
     * @param title         分享标题,注意限制长度不超过512字节
     * @param description   分享简介,注意长度必须小于1KB
     * @param thumb         分享小图标,注意限制内容大小不超过32KB
     * @param shareToCircle 是否分享到朋友圈
     */
    public void shareMusicInWeChat(String url, String musicUrl, String title, String description,
                                   Bitmap thumb, boolean shareToCircle) {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(this, Config.WEIXIN_APPID,
                    true);
        }

        WXMusicObject music = new WXMusicObject();
        music.musicUrl = url;
        music.musicDataUrl = musicUrl;
//        music.musicLowBandUrl = url;//musicUrl
        WXMediaMessage msg = new WXMediaMessage();
        msg.mediaObject = music;
        msg.title = title;
        msg.description = description;

        if (thumb != null) {
//            msg.thumbData = Util.bmpToByteArray(thumb, true); // 设置缩略图
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            thumb.compress(Bitmap.CompressFormat.PNG, 100, baos);
            int options = 90;
            while (baos.toByteArray().length / 1024 > 32) {  //循环判断如果压缩后图片是否大于32kb,大于继续压缩
                baos.reset();
                thumb.compress(Bitmap.CompressFormat.JPEG, options, baos);//这里压缩options%,把压缩后的数据存放到baos中
                options -= 10;//每次都减少10,注意有可能为负,为负会报错
                if (options == 0) {
                    break;
                }
            }
            msg.thumbData = baos.toByteArray();
            thumb.recycle();
        }
//        msg.thumbData = Util.bmpToByteArray(thumb,true);
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        if (shareToCircle) {
            req.transaction = "shareToCircle";// +System.currentTimeMillis();
        } else {
            req.transaction = "shareToFriend";// +System.currentTimeMillis();
        }//transaction字段用于唯一标识一个请求
        req.message = msg;
        req.scene = shareToCircle ? SendMessageToWX.Req.WXSceneTimeline
                : SendMessageToWX.Req.WXSceneSession;
//        boolean issuccessful = wxapi.sendReq(req);
        wxapi.sendReq(req);
    }

    /**
     * 在微信分享图片
     *
     * @param pathName      分享图片文件的全路径
     * @param shareToCircle 是否分享到朋友圈
     */
    public void sharePicInWeChat(String pathName, boolean shareToCircle) {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(this, Config.WEIXIN_APPID,
                    true);
        }
        Bitmap bmp = BitmapFactory.decodeFile(pathName);
        if (bmp == null)
            return;
        //初始化WXImageObjectWXMediaMessage对象
        WXImageObject imgObj = new WXImageObject(bmp);
        WXMediaMessage msg = new WXMediaMessage();
        msg.mediaObject = imgObj;

        //构造一个Req
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        if (shareToCircle) {
            req.transaction = "shareToCircle";// +System.currentTimeMillis();
        } else {
            req.transaction = "shareToFriend";// +System.currentTimeMillis();
        }//transaction字段用于唯一标识一个请求
        req.message = msg;
        req.scene = shareToCircle ? SendMessageToWX.Req.WXSceneTimeline
                : SendMessageToWX.Req.WXSceneSession;
        wxapi.sendReq(req);
    }

    /**
     * 关注微信公众号
     */
    public void followWechat() {
        if (wxapi == null) {
            wxapi = WXAPIFactory.createWXAPI(this, Config.WEIXIN_APPID,
                    true);
        }

        if (wxapi.isWXAppInstalled()) {// 安装了微信
            // int times = getSharedPreferences(AccessTokenKeeper.WECHAT_OAUTH_NAME,
            // MODE_PRIVATE)
            // .getInt("followTimes", 0);
            // boolean followed = (times >=2);//是否已经关注了?目前没有方法判断用户是否已经关注了微信公众号 XXX
            // //https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN
            //
            // if(!followed){//网页形式的关注按钮有效
            // times++;
            // getSharedPreferences(AccessTokenKeeper.WECHAT_OAUTH_NAME,
            // MODE_PRIVATE)
            // .edit().putInt("followTimes", times).commit();//假设用户两次之后一定会关注
            //
            // JumpToBizWebview.Req webviewReq = new JumpToBizWebview.Req();
            // webviewReq.extMsg = "";
            // webviewReq.toUserName = FitmixConstant.WEIXIN_ID;// 公众号原始ID
            // webviewReq.webType = JumpToBizProfile.JUMP_TO_NORMAL_BIZ_PROFILE;
            // Bundle bundle = new Bundle();
            // webviewReq.toBundle(bundle);
            // sendJumpToBizWebviewReq(bundle);
            // }else{
            // // 下面这段注释的代码,在用户已关注公众号后,可以直接打开微信对话
            // JumpToBizProfile.MyReq req = new JumpToBizProfile.MyReq();
            // req.extMsg = "";
            // req.toUserName = FitmixConstant.WEIXIN_ID;//公众号原始ID
            // req.profileType = JumpToBizProfile.JUMP_TO_NORMAL_BIZ_PROFILE;
            // Bundle bundle = new Bundle();
            // req.toBundle(bundle);
            // sendJumpToBizProfileReq(bundle);
            // }
            JumpToBizProfile.MyReq req = new JumpToBizProfile.MyReq();
            req.extMsg = "http://we.qq.com/d/AQCZ9NC_G---PCMlFZPT7HUBeFFh3EgKHHndlys_";
            req.toUserName = Config.WEIXIN_ID;// 公众号原始ID
            req.profileType = JumpToBizProfile.JUMP_TO_HARD_WARE_BIZ_PROFILE;
            Bundle bundle = new Bundle();
            req.toBundle(bundle);
            sendJumpToBizProfileReq(bundle);

            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "访问微信公众号中");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_SUCCESS);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        } else {
            Intent data = new Intent();
            data.putExtra(KEY_RESULT_STRING, "请先安装微信");
            data.putExtra(KEY_RESULT_CODE, RESULTCODE_FAILURE);
            AuthShareHelper.this.setResult(Activity.RESULT_OK, data);
            finishAuthShare();
        }
    }

    /**
     * 网页形式跳转到微信公众号界面
     * */
//	private boolean sendJumpToBizWebviewReq(Bundle paramBundle) {
//		ContentResolver contentResolver = getContentResolver();
//		Uri localUri = Uri
//				.parse("content://com.tencent.mm.sdk.comm.provider/jumpToBizProfile");
//		String[] params = new String[] {
//				FitmixConstant.WEIXIN_APPID,
//				paramBundle
//						.getString("_wxapi_jump_to_biz_webview_req_to_user_name"),
//				paramBundle.getString("_wxapi_jump_to_biz_webview_req_ext_msg"),
//				paramBundle.getInt("_wxapi_jump_to_biz_webview_req_scene") + "" };
//		Cursor cr;
//		if ((cr = contentResolver.query(localUri, null, null, params, null)) != null) {
//			cr.close();
//		}
//		return true;
//	}

    /**
     * 普通形式跳转到微信公众号界面
     */
    protected boolean sendJumpToBizProfileReq(Bundle paramBundle) {
        ContentResolver contentResolver = getContentResolver();
        Uri localUri = Uri
                .parse("content://com.tencent.mm.sdk.comm.provider/jumpToBizProfile");
        String[] params = new String[]{
                Config.WEIXIN_APPID,
                paramBundle
                        .getString("_wxapi_jump_to_biz_profile_req_to_user_name"),
                paramBundle.getString("_wxapi_jump_to_biz_profile_req_ext_msg"),
                paramBundle.getInt("_wxapi_jump_to_biz_profile_req_scene") + "",
                paramBundle
                        .getInt("_wxapi_jump_to_biz_profile_req_profile_type")
                        + ""};
        Cursor cr;
        if ((cr = contentResolver.query(localUri, null, null, params, null)) != null) {
            cr.close();
        }
        return true;
    }

    /**
     * 组装微信分享数据
     *
     * @param title   分享的标题
     * @param content 分享消息内容
     * @param url     消息被点击后的跳转URL
     * @param imgUrl  分享的图片本地路径
     */
    public static Bundle buildWechatShareParams(String title, String content,
                                                String url, String imgUrl) {
        Bundle bundle = new Bundle();
        if (!TextUtils.isEmpty(title)) {
            bundle.putString(KEY_SHARE_TITLE, title);
        } else {
            bundle.putString(KEY_SHARE_TITLE, "");
        }

        if (!TextUtils.isEmpty(content)) {
            bundle.putString(KEY_SHARE_CONTENT, content);
        } else {
            bundle.putString(KEY_SHARE_CONTENT, "");
        }

        if (!TextUtils.isEmpty(url)) {
            bundle.putString(KEY_SHARE_URL, url);
        } else {
            bundle.putString(KEY_SHARE_URL, "");
        }

        if (!TextUtils.isEmpty(imgUrl)) {
            if (FileUtils.isFileExist(imgUrl)) {
                bundle.putString(KEY_SHARE_IMAGE_URL, imgUrl);
            }
        } else {
            bundle.putString(KEY_SHARE_IMAGE_URL, "");
        }

        return bundle;
    }

    //endregion ===========================微信登录或分享相关==================================

    //region ===========================Activity 结果回调==================================
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    final Intent data) {

        Logger.i(TAG, "AuthShareHelper-->onActivityResult requestCode:" + requestCode + " resultCode:" + resultCode
                + " mCurrentRequestCode:" + mCurrentRequestCode + ",mTencentListener is null:" + (mTencentListener == null) + ",data is null:" + (data == null));
        switch (mCurrentRequestCode) {
            case REQUESTCODE_QQ_LOGIN:
            case REQUESTCODE_QQ_LOGOUT:
            case REQUESTCODE_QQ_BIND:
            case REQUESTCODE_QQ_SHARE:
            case REQUESTCODE_QZONE_SHARE:
            case REQUESTCODE_QQ_CONVERSATION:

//                Tencent.onActivityResultData(requestCode, resultCode, data,
//                        mTencentListener);//V2.3.1已修复 https://my.oschina.net/atearsan/blog/504299
                if (requestCode == Constants.REQUEST_QQ_SHARE) {// QQ分享
                    if (resultCode == Constants.ACTIVITY_OK) {
                        Tencent.handleResultData(data, mTencentListener);
                    }
                }

                if (requestCode == Constants.REQUEST_QZONE_SHARE) {// QQ空间分享
                    if (resultCode == Constants.ACTIVITY_OK) {
                        Tencent.handleResultData(data, mTencentListener);
                    }
                }

//                if (requestCode == Constants.REQUEST_API) {// QQ 登录
//                    if (resultCode == Constants.RESULT_LOGIN) {
//                        Tencent.handleResultData(data, mTencentListener);
//                    }
//                }

                if (requestCode == Constants.REQUEST_LOGIN) {// QQ 登录
                    Tencent.onActivityResultData(requestCode, resultCode, data, mTencentListener);
                }

                break;

            case REQUESTCODE_SINA_LOGIN:
            case REQUESTCODE_SINA_SHARE:
            case REQUESTCODE_FOLLOW_WEIBO:
            case REQUESTCODE_SINA_BIND:
                // SSO 授权回调
                // 重要：发起 SSO 登陆的 Activity 必须重写 onActivityResults
                // if(requestCode == 32973){
                if (mSinaSsoHandler != null) {
                    // Log.i("TT","AuthShareHelper-->onActivityResult sina authorizeCallBack");
                    mSinaSsoHandler
                            .authorizeCallBack(requestCode, resultCode, data);
                }
                // }
                break;

        }

    }

    //endregion ===========================Activity 结果回调==================================

}
