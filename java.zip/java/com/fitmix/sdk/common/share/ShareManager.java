package com.fitmix.sdk.common.share;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.view.activity.BaseActivity;
import com.fitmix.sdk.view.dialog.ShareDialog;

import java.lang.ref.WeakReference;

public class ShareManager implements ShareDialog.OnShareListener {
    /**
     * 默认分享的图片路径或文件路径,乐享动logo
     */
    public final static String DEFAULT_FILE_NAME = "appLogo.jpg";

    /**
     * 分享类型,444:网页,默认链接形式
     */
    public final static int SHARE_TYPE_WEB_PAGE = 444;
    /**
     * 分享类型,445:音乐
     */
    public final static int SHARE_TYPE_MUSIC = 445;
    /**
     * 分享类型,446:图片
     */
    public final static int SHARE_TYPE_PIC = 446;
    private boolean picAddLogo = false; //默认分享链接中图片没有加上底部logo标志
    private String musicUrl;
    public final static String SHARE_TYPE = "shareType";
    public final static String MUSIC_URL = "musicurl";
    public final static String IF_HAVE_LOGO = "ifhavelogo";
    private int contentType = ShareManager.SHARE_TYPE_WEB_PAGE;
    private String filename;// 分享的文件路径,图片
    private String url;     // 分享的网页链接地址
    private String title;//分享的标题
    private ShareDialog shareBoard;//分享对话框
    private String content;//分享的文字内容
    private WeakReference<BaseActivity> mActivity;

    private String shareCategory;//分享的类别,用于友盟统计,目前类别有[音乐、运动成绩、俱乐部]
    /**
     * 音乐分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_MUSIC = "music";
    /**
     * 运动成绩分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_RUN_SCORE = "runScore";
    /**
     * 俱乐部分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_CLUB = "club";
    /**
     * 运动直播分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_LIVING = "livingShow";
    /**
     * 运动赛事分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_COMPETITION = "competition";
    /**
     * 运动视频分享类型,用于友盟统计
     */
    public final static String SHARE_CATEGORY_VIDEO = "video";
    /**
     * 其它分享类型
     */
    public final static String SHARE_CATEGORY_OTHER = "other";

    /**
     * 获取用于微信分享的音乐Url
     */
    public String getMusicUrl() {
        return musicUrl;
    }

    /**
     * 设置用于微信分享的音乐Url
     */
    public void setMusicUrl(String musicUrl) {
        this.musicUrl = musicUrl;
    }

    /**
     * 获取分享的类别,用于友盟统计,目前类别有[音乐、运动成绩、俱乐部、运动直播]
     *
     * @return ShareManager.SHARE_CATEGORY_MUSIC:分享音乐,
     * ShareManager.SHARE_CATEGORY_RUN_SCORE:分享运动成绩,
     * ShareManager.SHARE_CATEGORY_CLUB:分享俱乐部,
     * ShareManager.SHARE_CATEGORY_LIVING:运动直播
     */
    public String getShareCategory() {
        return shareCategory;
    }

    /**
     * 设置分享的类别,用于友盟统计,目前类别有[音乐、运动成绩、俱乐部、运动直播]
     *
     * @param shareCategory 分享的类别,目前类别有 1.ShareManager.SHARE_CATEGORY_MUSIC(音乐),
     *                      2.ShareManager.SHARE_CATEGORY_RUN_SCORE(运动成绩),
     *                      3.ShareManager.SHARE_CATEGORY_CLUB(俱乐部)
     *                      4.ShareManager.SHARE_CATEGORY_LIVING(运动直播)
     */
    public void setShareCategory(String shareCategory) {
        this.shareCategory = shareCategory;
    }

    /**
     * 获取分享的内容类型
     *
     * @return {@link ShareManager#SHARE_TYPE_WEB_PAGE}:网页(默认)<br/>
     * {@link ShareManager#SHARE_TYPE_MUSIC}:音乐(仅支持微信分享)<br/>
     * {@link ShareManager#SHARE_TYPE_PIC}:图片<br/>
     */
    public int getContentType() {
        return contentType;
    }

    /**
     * 设置分享的内容类型
     *
     * @param contentType {@link ShareManager#SHARE_TYPE_WEB_PAGE}:网页(默认)<br/>
     *                    {@link ShareManager#SHARE_TYPE_MUSIC}:音乐(仅支持微信分享)<br/>
     *                    {@link ShareManager#SHARE_TYPE_PIC}:图片<br/>
     */
    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    /**
     * 获取分享缩略图是否要加上fitmix的Logo
     */
    public boolean isPicAddLogo() {
        return picAddLogo;
    }

    /**
     * 设置分享缩略图是否要加上fitmix的Logo
     *
     * @param picAddLogo true:是,false:否
     */
    public void setPicAddLogo(boolean picAddLogo) {
        this.picAddLogo = picAddLogo;
    }

    /**
     * 获取分享的图片路径或文件路径
     */
    public String getFilename() {
        return filename;
    }

    /**
     * 设置分享的图片路径或文件路径
     *
     * @param filename 分享的图片路径或文件路径
     */
    public void setFilename(String filename) {
        if (DEFAULT_FILE_NAME.equals(filename) || TextUtils.isEmpty(filename)) {//路径为空或默认图片
            String path = FitmixUtil.getTempPath() + DEFAULT_FILE_NAME;
            //1.如果存在,则直接赋值
            if (FileUtils.isFileExist(path)) {
                this.filename = path;
                return;
            }
            //2.复制app logo 到temp文件夹
            Bitmap bitmap = BitmapFactory.decodeResource(MixApp.getContext().getResources(), R.drawable.logo);
            if (bitmap != null) {
                ImageHelper.saveBitmap2File(bitmap, path);
            }
            //3.设置fileName
            if (FileUtils.isFileExist(path)) {
                this.filename = path;
            }
        } else {
            this.filename = filename;
        }
    }

    /**
     * 获取分享的内容网页跳转地址
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置分享的内容网页跳转地址
     *
     * @param url 分享的内容网页跳转地址
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取分享的文字内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置分享的文字内容
     *
     * @param content 分享的文字内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取分享的文字标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置分享的文字标题
     *
     * @param title 分享的文字标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    public ShareManager(BaseActivity activity) {
        this.mActivity = new WeakReference<>(activity);
    }

    public Activity getContext() {
        return mActivity.get();
    }

    public void share() {
        if (getContext() == null) return;
//        Log.d(MyConfig.getInstance().getTag(), "title:" + getTitle() + ",content:" + getContent());

        BaseActivity activity = mActivity.get();
        if (activity == null) {
            return;
        }

        if (shareBoard == null) {
            shareBoard = new ShareDialog();
            shareBoard.setOnShareListener(this);
        }
        //显示
        shareBoard.show(activity.getFragmentManager(), "shareDialog");
    }

    private void shareToWeChatCircle() {
        if (getContext() == null) return;

        Intent intent = new Intent(getContext(), AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_CIRCLE_SHARE);
        bundle = AuthShareHelper.buildWechatShareParams(getTitle(), getContent(),
                getUrl(), getFilename());
        intent.putExtra(AuthShareHelper.KEY_WECHAT_SHARE_BUNDLE, bundle);
        intent.putExtra(ShareManager.SHARE_TYPE, getContentType());//传内容类型,分辨内容
        intent.putExtra(ShareManager.MUSIC_URL, getMusicUrl());//音乐url
        intent.putExtra(ShareManager.IF_HAVE_LOGO, isPicAddLogo());//是否加上fitmix图片修饰
        getContext().startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_CIRCLE_SHARE);

    }

    private void shareToWeChat() {
        if (getContext() == null) return;

        Intent intent = new Intent(getContext(), AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_WECHAT_SHARE);
        bundle = AuthShareHelper.buildWechatShareParams(getTitle(), getContent(),
                getUrl(), getFilename());
        intent.putExtra(AuthShareHelper.KEY_WECHAT_SHARE_BUNDLE, bundle);
        intent.putExtra(ShareManager.SHARE_TYPE, getContentType());//传内容类型,分辨内容
        intent.putExtra(ShareManager.MUSIC_URL, getMusicUrl());//音乐url
        intent.putExtra(ShareManager.IF_HAVE_LOGO, isPicAddLogo());//是否加上fitmix图片修饰
        getContext().startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_WECHAT_SHARE);
    }

    private void shareToQQ() {
        if (getContext() == null) return;

        Intent intent = new Intent(getContext(), AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_QQ_SHARE);
        if (contentType == SHARE_TYPE_PIC) {//纯图片分享
            bundle = AuthShareHelper.buildQQSharePicParams(true, getFilename(), "乐享动");
        } else {
            bundle = AuthShareHelper.buildQQShareParams(true, getUrl(), getTitle(),
                    getContent(), getFilename(), "乐享动");
        }
        intent.putExtra(AuthShareHelper.KEY_QQ_SHARE_BUNDLE, bundle);
        getContext().startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_SHARE);
    }

    private void shareToWeibo() {
        if (getContext() == null) return;

        Intent intent = new Intent(getContext(), AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_SINA_SHARE);
        intent.putExtra(ShareManager.SHARE_TYPE, getContentType());//传内容类型,分辨内容
        bundle = AuthShareHelper.buildWeiboShareParams(getTitle(), getContent(), getUrl(),
                getFilename());
        intent.putExtra(AuthShareHelper.KEY_SINA_SHARE_BUNDLE, bundle);
        getContext().startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_SINA_SHARE);
    }

    private void shareToQQZone() {
        if (getContext() == null) return;

        Intent intent = new Intent(getContext(), AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_QZONE_SHARE);
        if (contentType == SHARE_TYPE_PIC) {//纯图片分享
            bundle = AuthShareHelper.buildQQSharePicParams(false, getFilename(), "乐享动");
        } else {
            bundle = AuthShareHelper.buildQQShareParams(false, getUrl(), getTitle(),
                    getContent(), getFilename(), "乐享动");//QQ空间不支持纯图片分享,也不支持多图分享
        }

        intent.putExtra(AuthShareHelper.KEY_QQ_SHARE_BUNDLE, bundle);
        getContext().startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_QZONE_SHARE);
    }


    @Override
    public void doShare(int channel) {
        switch (channel) {
            case 0://微信好友
                shareToWeChat();
                break;
            case 1://微信朋友圈
                shareToWeChatCircle();
                break;
            case 2://QQ空间
                shareToQQZone();
                break;
            case 3://新浪微博
                shareToWeibo();
                break;
            case 4://QQ好友
                shareToQQ();
                break;
        }
    }


}