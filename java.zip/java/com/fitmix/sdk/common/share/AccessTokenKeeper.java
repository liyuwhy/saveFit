/*
 * Copyright (C) 2010-2013 The SINA WEIBO Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.fitmix.sdk.common.share;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.fitmix.sdk.wxapi.WechatAuthShareResult;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

/**
 * 该类定义了QQ,微信,新浪微博授权时所需要的参数。
 */
public class AccessTokenKeeper {
    public static final String SINA_OAUTH_NAME = "sina_oauth";
    public static final String WECHAT_OAUTH_NAME = "wechat_oauth";
    public static final String QQ_OAUTH_NAME = "qq_oauth";

    public static final String KEY_OPENID = "openid";//授权用户唯一标识
    public static final String KEY_ACCESS_TOKEN = "access_token";//接口调用凭证
    public static final String KEY_UNION_ID = "unionid";//微信Union id
//    public static final String KEY_APP_ID = "appid";//QQ APP ID

    private static final String KEY_REFRESH_TOKEN = "refresh_token";//access_token接口调用凭证超时时间,单位（秒）
    private static final String KEY_UID = "uid";
    private static final String KEY_EXPIRES_IN = "expires_in";//用户刷新access_token

    private static final String WX_NAME = "wx_name";//微信名称
    private static final String WX_OPENID = "wx_openid";//微信id

    /**
     * 保存新浪 Token 对象到 SharedPreferences。
     *
     * @param context 应用程序上下文环境
     * @param token   Token 对象
     */
    public static void writeSinaAccessToken(Context context, Oauth2AccessToken token) {
        if (null == context || null == token) {
            return;
        }
//        Log.i("TT","writeSinaAccessToken token:"+token);
        SharedPreferences pref = context.getSharedPreferences(SINA_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor editor = pref.edit();
        editor.putString(KEY_UID, token.getUid());
        editor.putString(KEY_ACCESS_TOKEN, token.getToken());
        editor.putString(KEY_REFRESH_TOKEN, token.getRefreshToken());
        editor.putLong(KEY_EXPIRES_IN, token.getExpiresTime());
        editor.apply();
    }

    /**
     * 微信绑定
     * <p>
     * 保存得到的微信姓名与 openid 到 SharedPreferences。
     *
     * @param context 应用程序上下文环境
     */
    public static void writeWXName(Context context, String wxName, String WxOpenid) {
        if (null == wxName || null == WxOpenid) {
            return;
        }
        SharedPreferences pref = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor editor = pref.edit();
        editor.putString(WX_NAME, wxName);
        editor.putString(WX_OPENID, WxOpenid);
        editor.apply();
    }

    /**
     * 从 SharedPreferences 读取新浪 Token 信息。
     *
     * @param context 应用程序上下文环境
     * @return 返回 Token 对象
     */
    public static Oauth2AccessToken readSinaAccessToken(Context context) {
        if (null == context) {
            return null;
        }

        Oauth2AccessToken token = new Oauth2AccessToken();
        SharedPreferences pref = context.getSharedPreferences(SINA_OAUTH_NAME, Context.MODE_PRIVATE);
        token.setUid(pref.getString(KEY_UID, ""));
        token.setToken(pref.getString(KEY_ACCESS_TOKEN, ""));
        token.setRefreshToken(pref.getString(KEY_REFRESH_TOKEN, ""));
        token.setExpiresTime(pref.getLong(KEY_EXPIRES_IN, 0));

        return token;
    }

    /**
     * 保存QQ Token 对象到 SharedPreferences。
     *
     * @param context      应用程序上下文环境
     * @param openid       授权用户唯一标识
     * @param access_token 接口调用凭证
     * @param expires      access_token接口调用凭证超时时间,单位（秒）
     */
    public static void writeQQAccessToken(Context context, String openid, String access_token, long expires) {
        if (null == context) {
            return;
        }
        SharedPreferences pref = context.getSharedPreferences(QQ_OAUTH_NAME, Context.MODE_PRIVATE);//MODE_APPEND
        Editor editor = pref.edit();
        editor.putString(KEY_OPENID, openid);
        editor.putString(KEY_ACCESS_TOKEN, access_token);
        editor.putLong(KEY_EXPIRES_IN, expires);
        editor.apply();
//        Log.i("TT","writeQQAccessToken openid:"+openid+" access_token:"+access_token +" context:"+context);
    }

    /**
     * 保存微信 Token 对象到 SharedPreferences。
     *
     * @param context       应用程序上下文环境
     * @param openid        授权用户唯一标识
     * @param access_token  接口调用凭证
     * @param refresh_token 用户刷新access_token
     * @param unionid       微信unionid
     * @param expires       access_token接口调用凭证超时时间,单位（秒）
     */
    public static void writeWechatAccessToken(Context context, String openid, String access_token, String refresh_token, String unionid, long expires) {
        if (null == context) {
            return;
        }

        SharedPreferences pref = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor editor = pref.edit();
        editor.putString(KEY_OPENID, openid);
        editor.putString(KEY_ACCESS_TOKEN, access_token);
        editor.putString(KEY_REFRESH_TOKEN, refresh_token);
        editor.putString(KEY_UNION_ID, unionid);
        editor.putLong(KEY_EXPIRES_IN, expires);
        editor.apply();
    }

    /**
     * 保存微信请求结果,用于回传
     *
     * @param context     应用程序上下文环境
     * @param requestCode 请求的编号,取值为AuthShareHelper中的REQUESTCODE_WECHAT_LOGIN,REQUESTCODE_WECHAT_SHARE
     * @param resultCode  结果编码,取值为AuthShareHelper中的RESULTCODE_SUCCESS, RESULTCODE_FAILURE, RESULTCODE_UNKNOWN
     * @param resultStr   结果文字内容
     */
    public static void writeWechatResult(Context context, int requestCode, int resultCode, String resultStr, String wxName, String WxOpenid) {
        if (null == context) {
            return;
        }
        SharedPreferences pref = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor editor = pref.edit();
        editor.putInt(AuthShareHelper.KEY_REQUESTCODE, requestCode);
        editor.putInt(AuthShareHelper.KEY_RESULT_CODE, resultCode);
        editor.putString(AuthShareHelper.KEY_RESULT_STRING, resultStr);
        editor.putString(WX_NAME, wxName);
        editor.putString(WX_OPENID, WxOpenid);
        editor.apply();
    }

    /**
     * 保存微信请求结果,用于回传
     *
     * @param context     应用程序上下文环境
     * @param requestCode 请求的编号,取值为AuthShareHelper中的REQUESTCODE_WECHAT_LOGIN,REQUESTCODE_WECHAT_SHARE
     * @param resultCode  结果编码,取值为AuthShareHelper中的RESULTCODE_SUCCESS, RESULTCODE_FAILURE, RESULTCODE_UNKNOWN
     * @param resultStr   结果文字内容
     */
    public static void writeWechatResult(Context context, int requestCode, int resultCode, String resultStr) {
        if (null == context) {
            return;
        }

        SharedPreferences pref = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor editor = pref.edit();
        editor.putInt(AuthShareHelper.KEY_REQUESTCODE, requestCode);
        editor.putInt(AuthShareHelper.KEY_RESULT_CODE, resultCode);
        editor.putString(AuthShareHelper.KEY_RESULT_STRING, resultStr);
        editor.apply();
    }

    /**
     * 从 SharedPreferences 读取微信登录或分享结果。
     *
     * @param context 应用程序上下文环境
     */
    public static WechatAuthShareResult readWechatAuthShareResult(Context context) {
        if (null == context) {
            return null;
        }

        SharedPreferences pref = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        int requestCode = pref.getInt(AuthShareHelper.KEY_REQUESTCODE, 0);
        int resultCode = pref.getInt(AuthShareHelper.KEY_RESULT_CODE, 0);
        String WXName = pref.getString(WX_NAME, "");
        String WXOpenid = pref.getString(WX_OPENID, "");
        String resultStr = pref.getString(AuthShareHelper.KEY_RESULT_STRING, "");
        WechatAuthShareResult result = new WechatAuthShareResult(requestCode, resultCode, resultStr, WXName, WXOpenid);
        //清理数据
        Editor editor = pref.edit();
        editor.putInt(AuthShareHelper.KEY_REQUESTCODE, 0);
        editor.putInt(AuthShareHelper.KEY_RESULT_CODE, 0);
        editor.putString(AuthShareHelper.KEY_RESULT_STRING, "");
        editor.putString(AuthShareHelper.KEY_RESULT_STRING, "");
        editor.apply();
        return result;
    }


    /**
     * 清空 SharedPreferences 中 Token信息。
     *
     * @param context 应用程序上下文环境
     */
    public static void clear(Context context) {
        if (null == context) {
            return;
        }
        //新浪
        SharedPreferences sina = context.getSharedPreferences(SINA_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor sina_editor = sina.edit();
        sina_editor.clear();
        sina_editor.apply();
        //QQ
        SharedPreferences qq = context.getSharedPreferences(QQ_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor qq_editor = qq.edit();
        qq_editor.clear();
        qq_editor.apply();
        //微信
        SharedPreferences wechat = context.getSharedPreferences(WECHAT_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor wechat_editor = wechat.edit();
        wechat_editor.clear();
        wechat_editor.apply();
    }

    /**
     * 清空 SharedPreferences 中 QQ 的 Token信息。
     *
     * @param context 应用程序上下文环境
     */
    public static void clearQQ(Context context) {
        if (null == context) {
            return;
        }
        //QQ
        SharedPreferences qq = context.getSharedPreferences(QQ_OAUTH_NAME, Context.MODE_PRIVATE);
        Editor qq_editor = qq.edit();
        qq_editor.clear();
        qq_editor.apply();
    }
}
