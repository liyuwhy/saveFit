package com.fitmix.sdk.common.share;

import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.DataSource;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.view.activity.BaseActivity;
import com.fitmix.sdk.view.bean.Competition;
import com.fitmix.sdk.view.bean.Video;

import java.io.File;

public class ShareUtils {

    private static ShareUtils instance;

    public static ShareUtils getInstance() {
        if (instance == null) {
            instance = new ShareUtils();
        }
        return instance;
    }

    //region ============================= 分享音乐 =============================

    /**
     * 分享音乐
     * <p/>
     * type 分享的类型  音乐 1 、电台 2
     */
    public void shareMusic(BaseActivity activity, final Music music) {
        if (music == null) return;
        getMusicBitmap(activity, music, music.getType() == 2 ? 2 : 1);
    }

    /**
     * 获取到歌曲的 bitmap 之后设置 bitmap
     */
    private void getMusicBitmap(final BaseActivity activity, final Music music, final int type) {
        if (music == null || TextUtils.isEmpty(music.getAlbumUrl()))
            return;
        BaseBitmapDataSubscriber baseBitmapDataSubscriber = new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                setMusicBitmap(activity, music, type, bitmap);
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
                // No cleanup required here.
                setMusicBitmap(activity, music, type, null);
            }
        };
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(music.getAlbumUrl()))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, this);
        dataSource.subscribe(baseBitmapDataSubscriber, CallerThreadExecutor.getInstance());
    }

    /**
     * 获得歌曲的 bitmap 之后就可以正式分享
     */
    private void setMusicBitmap(BaseActivity activity, Music music, int type, Bitmap bitmap) {
        if (music == null)
            return;
        String sTitle;
        String sContent;
        if (type == 1) {//音乐分享
//            sTitle = activity.getResources().getString(R.string.music_share);// 分享音乐标题
//            String sItemFormat = activity.getResources().getString(R.string.music_share_content);
//            sContent = String.format(sItemFormat, music.getName());
            sTitle = music.getName();
            sContent = activity.getResources().getString(R.string.music_share);
        } else {//电台分享
//            sTitle = activity.getResources().getString(R.string.radio_share);//分享电台标题
//            sContent = activity.getResources().getString(R.string.radio_share_content);
            sTitle = music.getName();
            sContent = activity.getResources().getString(R.string.radio_share);
        }
        String url = ApiConstants.getShareMusicUrl(music.getId());
        ShareManager share = new ShareManager(activity);
        share.setContent(sContent);
        share.setPicAddLogo(true);//加上logo标志
        share.setTitle(sTitle);
        share.setUrl(url);
        if (bitmap != null) {//
            String filename = "shareTemp.jpg";
            String tempPath = FitmixUtil.getTempPath();
            final File file = new File(tempPath, filename);
            ImageHelper.saveBitmapInLocal(file, bitmap);//saveShareBitmapInLocal
            share.setFilename(file.getPath());
        }
        share.setContentType(ShareManager.SHARE_TYPE_MUSIC);
        share.setMusicUrl(music.getUrl());
        share.setShareCategory(ShareManager.SHARE_CATEGORY_MUSIC);//分享类别为音乐,用于友盟分享统计
        share.share();

        //友盟统计
        UmengAnalysisHelper.getInstance().shareMusicReportPlus(activity, music.getId(), music.getName(), type);
    }

    //endregion ============================= 分享音乐 =============================

    //region ============================= 分享俱乐部 =============================

    /**
     * 分享俱乐部
     */
    public void shareClub(BaseActivity activity, String imageUrl, String clubShareUrl) {
        getClubBitmap(activity, imageUrl, clubShareUrl);
    }

    /**
     * 获取到俱乐部的图像
     */
    private void getClubBitmap(final BaseActivity activity, final String imageUrl, final String clubShareUrl) {
        if (TextUtils.isEmpty(imageUrl))
            return;
        BaseBitmapDataSubscriber baseBitmapDataSubscriber = new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                setClubBitmap(activity, clubShareUrl, bitmap);
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
                setClubBitmap(activity, clubShareUrl, null);
            }
        };
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(imageUrl))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, this);
        dataSource.subscribe(baseBitmapDataSubscriber, CallerThreadExecutor.getInstance());
    }

    /**
     * 获得俱乐部的 bitmap 之后就可以正式分享
     */
    private void setClubBitmap(BaseActivity activity, String clubShareUrl, Bitmap bitmap) {
        String sTitle = activity.getResources().getString(R.string.club_share);// 分享标题
        String sContent = activity.getResources().getString(R.string.club_share_content);
        ShareManager share = new ShareManager(activity);
        share.setContent(sContent);
        if (bitmap != null) {
            String filename = "shareTemp.jpg";
            String tempPath = FitmixUtil.getTempPath();
            final File file = new File(tempPath, filename);
            ImageHelper.saveBitmapInLocal(file, bitmap);//saveShareBitmapInLocal
            share.setFilename(file.getPath());
        }
        share.setTitle(sTitle);
        share.setUrl(clubShareUrl);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_CLUB);//分享类别为俱乐部,用于友盟分享统计
        share.share();
    }

    //endregion ============================= 分享俱乐部 =============================

    //region ============================= 分享赛事 =============================

    /**
     * 分享俱乐部
     */
    public void shareCompetition(BaseActivity activity, Competition competition, String url) {
        getCompetitionBitmap(activity, competition, url);
    }

    /**
     * 获取到俱乐部的图像
     */
    private void getCompetitionBitmap(final BaseActivity activity, final Competition competition, final String url) {
        if (competition == null || TextUtils.isEmpty(competition.getThemeImage()))
            return;
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(competition.getThemeImage()))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();

        BaseBitmapDataSubscriber baseBitmapDataSubscriber = new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                setCompetitionBitmap(activity, competition, url, bitmap);
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
                setCompetitionBitmap(activity, competition, url, null);
            }
        };

        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, this);
        dataSource.subscribe(baseBitmapDataSubscriber, CallerThreadExecutor.getInstance());
    }

    /**
     * 获得赛事的 bitmap 之后就可以正式分享
     */
    private void setCompetitionBitmap(BaseActivity activity, Competition competition, String url, Bitmap bitmap) {
        String sTitle = activity.getResources().getString(R.string.share_competition_title);// 分享标题
        ShareManager share = new ShareManager(activity);
        share.setContent(competition.getThemeName());
        if (bitmap != null) {
            String filename = "shareTemp.jpg";
            String tempPath = FitmixUtil.getTempPath();
            final File file = new File(tempPath, filename);
            ImageHelper.saveBitmapInLocal(file, bitmap);//saveShareBitmapInLocal
            share.setFilename(file.getPath());
        }
        share.setTitle(sTitle);
        share.setUrl(url);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_COMPETITION);//分享类别为赛事,用于友盟分享统计
        share.share();

        //友盟统计
        UmengAnalysisHelper.getInstance().shareCompetitionReportPlus(activity, competition.getThemeName());

    }

//    /**
//     * 分享俱乐部
//     */
//    public void shareCompetition(BaseActivity activity, String competitionShareUrl, String content) {
//
//        ShareManager share = new ShareManager(activity);
//        share.setContent(content);
//        share.setTitle(sTitle);
//        share.setFilename("");
//        share.setContentType(ShareManager.SHARE_TYPE_WEB_PAGE);
//        share.setUrl(competitionShareUrl);
//        share.setShareCategory(ShareManager.SHARE_CATEGORY_COMPETITION);//分享类别为赛事,用于友盟分享统计
//        share.share();
//    }
    //endregion ============================= 分享赛事 =============================

    //region ============================= 分享视频 =============================

    /**
     * 分享视频
     */
    public void shareVideo(BaseActivity activity, Video video) {
        getVideoBitmap(activity, video);
    }

    /**
     * 获取到视频封面的图像
     */
    private void getVideoBitmap(final BaseActivity activity, final Video video) {
        if (video == null || TextUtils.isEmpty(video.getPosterUrl())) {
            return;
        }
        BaseBitmapDataSubscriber baseBitmapDataSubscriber = new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                setVideoBitmap(activity, video, bitmap);
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
                setVideoBitmap(activity, video, null);
            }
        };
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(video.getPosterUrl()))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, this);
        dataSource.subscribe(baseBitmapDataSubscriber, CallerThreadExecutor.getInstance());
    }

    /**
     * 获得视频封面的 bitmap 之后就可以正式分享
     */
    private void setVideoBitmap(BaseActivity activity, Video video, Bitmap bitmap) {
        String sTitle = activity.getResources().getString(R.string.activity_main_discovery_video_share_title);// 分享标题
        String sItemFormat = activity.getResources().getString(R.string.activity_main_discovery_video_share_content);//分享内容
        String sContent = String.format(sItemFormat, video.getTitle());
        String url = ApiConstants.getShareVideoUrl(video.getId());
        ShareManager share = new ShareManager(activity);
        share.setContent(sContent);
        if (bitmap != null) {
            String filename = "shareTemp.jpg";
            String tempPath = FitmixUtil.getTempPath();
            final File file = new File(tempPath, filename);
            ImageHelper.saveBitmapInLocal(file, bitmap);//saveShareBitmapInLocal
            share.setFilename(file.getPath());
        }
        share.setPicAddLogo(true);//加上logo标志
        share.setTitle(sTitle);
        share.setUrl(url);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_VIDEO);//分享类别为视频,用于友盟分享统计
        share.share();
    }
    //endregion ============================= 分享视频 =============================
}
