package com.fitmix.sdk.common;

/**
 * 估数表
 */
public class ExpectancyTable {

    /**
     * 根据用户身高,目标配速获取适合的节拍器拍数,算法来自张晓锋统计规律
     *
     * @param height 身高,单位cm
     * @param pace   配速(一公里秒数),单位为秒
     */
    public static int getFitBpmByPace(int height, int pace) {
        int bpm = 0;
        if (height <= 0 || pace > 1260 || pace < 180) {
            return bpm;
        }

        if (height < 165) {//身高165厘米以下
            switch (pace) {
                case 180:
                case 190:
                    bpm = 230;
                    break;
                case 200:
                    bpm = 220;
                    break;
                case 210:
                    bpm = 210;
                    break;
                case 220:
                case 230:
                    bpm = 200;
                    break;
                case 240:
                case 250:
                    bpm = 190;
                    break;
                case 260:
                case 270:
                case 280:
                case 290:
                case 300:
                case 310:
                    bpm = 180;
                    break;
                case 320:
                case 330:
                case 340:
                case 350:
                case 360:
                case 370:
                    bpm = 170;
                    break;
                case 380:
                case 390:
                case 400:
                case 410:
                case 420:
                case 430:
                    bpm = 160;
                    break;
                case 440:
                case 450:
                case 460:
                case 470:
                case 480:
                case 490:
                    bpm = 150;
                    break;
                case 500:
                case 510:
                case 520:
                case 530:
                case 540:
                case 550:
                    bpm = 140;
                    break;
                case 560:
                case 570:
                case 580:
                case 590:
                case 600:
                case 610:
                case 620:
                case 630:
                case 640:
                case 650:
                case 660:
                case 670:
                    bpm = 130;
                    break;
                case 680:
                case 690:
                case 700:
                case 710:
                case 720:
                case 730:
                case 740:
                case 750:
                case 760:
                case 770:
                case 780:
                    bpm = 120;
                    break;
                case 790:
                case 800:
                case 810:
                case 820:
                case 830:
                case 840:
                case 850:
                case 860:
                case 870:
                case 880:
                case 890:
                    bpm = 110;
                    break;
                case 900:
                case 910:
                case 920:
                case 930:
                case 940:
                case 950:
                case 960:
                case 970:
                case 980:
                case 990:
                case 1000:
                case 1010:
                case 1020:
                case 1030:
                case 1040:
                    bpm = 100;
                    break;
                case 1050:
                case 1060:
                case 1070:
                case 1080:
                case 1090:
                case 1100:
                case 1110:
                case 1120:
                case 1130:
                case 1140:
                case 1150:
                case 1160:
                case 1170:
                case 1180:
                    bpm = 90;
                    break;
                case 1190:
                case 1200:
                default:
                    bpm = 80;
                    break;
            }
        } else if (height >= 165 && height <= 175) {//[165,175]
            switch (pace) {
                case 180:
                    bpm = 220;
                    break;
                case 190:
                    bpm = 210;
                    break;
                case 200:
                case 210:
                    bpm = 200;
                    break;
                case 220:
                case 230:
                    bpm = 190;
                    break;
                case 240:
                case 250:
                case 260:
                case 270:
                case 280:
                case 290:
                    bpm = 180;
                    break;
                case 300:
                case 310:
                case 320:
                case 330:
                case 340:
                case 350:
                    bpm = 170;
                    break;
                case 360:
                case 370:
                case 380:
                case 390:
                case 400:
                case 410:
                    bpm = 160;
                    break;
                case 420:
                case 430:
                case 440:
                case 450:
                case 460:
                case 470:
                    bpm = 150;
                    break;
                case 480:
                case 490:
                case 500:
                case 510:
                case 520:
                case 530:
                    bpm = 140;
                    break;
                case 540:
                case 550:
                case 560:
                case 570:
                case 580:
                case 590:
                case 600:
                case 610:
                case 620:
                case 630:
                case 640:
                case 650:
                    bpm = 130;
                    break;
                case 660:
                case 670:
                case 680:
                case 690:
                case 700:
                case 710:
                case 720:
                case 730:
                case 740:
                case 750:
                case 760:
                    bpm = 120;
                    break;
                case 770:
                case 780:
                case 790:
                case 800:
                case 810:
                case 820:
                case 830:
                case 840:
                case 850:
                case 860:
                case 870:
                    bpm = 110;
                    break;
                case 880:
                case 890:
                case 900:
                case 910:
                case 920:
                case 930:
                case 940:
                case 950:
                case 960:
                case 970:
                case 980:
                case 990:
                case 1000:
                case 1010:
                case 1020:
                    bpm = 100;
                    break;
                case 1030:
                case 1040:
                case 1050:
                case 1060:
                case 1070:
                case 1080:
                case 1090:
                case 1100:
                case 1110:
                case 1120:
                case 1130:
                case 1140:
                case 1150:
                case 1160:
                    bpm = 90;
                    break;
                case 1170:
                case 1180:
                case 1190:
                case 1200:
                default:
                    bpm = 80;
                    break;
            }
        } else {//175以上
            switch (pace) {
                case 180:
                case 190:
                    bpm = 200;
                    break;
                case 200:
                case 210:
                    bpm = 190;
                    break;
                case 220:
                case 230:
                case 240:
                case 250:
                case 260:
                case 270:
                    bpm = 180;
                    break;
                case 280:
                case 290:
                case 300:
                case 310:
                case 320:
                case 330:
                    bpm = 170;
                    break;
                case 340:
                case 350:
                case 360:
                case 370:
                case 380:
                case 390:
                    bpm = 160;
                    break;
                case 400:
                case 410:
                case 420:
                case 430:
                case 440:
                case 450:
                    bpm = 150;
                    break;
                case 460:
                case 470:
                case 480:
                case 490:
                case 500:
                case 510:
                    bpm = 140;
                    break;
                case 520:
                case 530:
                case 540:
                case 550:
                case 560:
                case 570:
                case 580:
                case 590:
                case 600:
                case 610:
                case 620:
                case 630:
                    bpm = 130;
                    break;
                case 640:
                case 650:
                case 660:
                case 670:
                case 680:
                case 690:
                case 700:
                case 710:
                case 720:
                case 730:
                case 740:
                    bpm = 120;
                    break;
                case 750:
                case 760:
                case 770:
                case 780:
                case 790:
                case 800:
                case 810:
                case 820:
                case 830:
                case 840:
                case 850:
                    bpm = 110;
                    break;
                case 860:
                case 870:
                case 880:
                case 890:
                case 900:
                case 910:
                case 920:
                case 930:
                case 940:
                case 950:
                case 960:
                case 970:
                case 980:
                case 990:
                case 1000:
                    bpm = 100;
                    break;
                case 1010:
                case 1020:
                case 1030:
                case 1040:
                case 1050:
                case 1060:
                case 1070:
                case 1080:
                case 1090:
                case 1100:
                case 1110:
                case 1120:
                case 1130:
                case 1140:
                    bpm = 90;
                    break;
                case 1150:
                case 1160:
                case 1170:
                case 1180:
                case 1190:
                case 1200:
                default:
                    bpm = 80;
                    break;
            }
        }
        return bpm;
    }
}
