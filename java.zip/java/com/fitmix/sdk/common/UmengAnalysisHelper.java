package com.fitmix.sdk.common;

import android.content.Context;
import android.text.TextUtils;

import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.Adverts;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.dplus.UMADplus;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

/**
 * 友盟统计帮助类
 */
public class UmengAnalysisHelper {

    /*=====================事件ID======================*/
//    private final String EVENT_ID_REGISTER = "REGISTER";//注册
//    private final String EVENT_ID_LOGIN = "LOGIN";//登录
//    private final String EVENT_ID_MUSIC_DOWNLOAD = "MIX_DOWNLOAD";//音乐下载
//    private final String EVENT_ID_MUSIC_COLLECTION = "MIX_COLLECTION";//音乐收藏
//    private final String EVENT_ID_MUSIC_ONLINE = "MIX_ONLINE";//音乐在线播放
//    private final String EVENT_ID_START_RUN = "START_SPORT";//开始运动
//    private final String EVENT_ID_STOP_RUN = "STOP_SPORT";//结束运动
//    private final String EVENT_ID_MUSIC_PLAY_DURATION = "MIX_PLAY_DURATION";//音乐播放时长
//    private final String EVENT_ID_SHARE = "SHARE";//分享统计


    private static UmengAnalysisHelper mInstance;
    //    private HashMap<String, String> map_ekv;//事件字典
    private HashMap<String, Object> map_kv;//u-d plus 事件字典

    public UmengAnalysisHelper() {

    }

    public static UmengAnalysisHelper getInstance() {
        if (mInstance == null) {
            mInstance = new UmengAnalysisHelper();
        }

        return mInstance;
    }

//    /**
//     * 添加事件键值对
//     *
//     * @param keys   键数组
//     * @param values 值数组
//     */
//    private void put(String[] keys, String[] values) {
//        if (map_ekv == null) {
//            map_ekv = new HashMap<>();
//        }
//        map_ekv.clear();
//        int length = (keys.length >= values.length) ? keys.length : 0;//保证key数组长度大于value数组
//        for (int index = 0; index < length; index++) {
//            map_ekv.put(keys[index], values[index]);
//        }
//    }

    /**
     * U-D Plus添加事件键值对
     *
     * @param keys   键数组
     * @param values 值数组
     */
    private void put2(String[] keys, String[] values) {
        if (map_kv == null) {
            map_kv = new HashMap<>();
        }
        map_kv.clear();
        int length = (keys.length >= values.length) ? keys.length : 0;//保证key数组长度大于value数组
        for (int index = 0; index < length; index++) {
            map_kv.put(keys[index], values[index]);
        }
    }


//    /**
//     * 添加事件键值对
//     *
//     * @param keyArrayString   键数组字符串,如"key1,key2,key3"用英文逗号分隔
//     * @param valueArrayString 值数组字符串,如"value1,value2,value3"用英文逗号分隔
//     */
//    private void put(String keyArrayString, String valueArrayString) {
//        if (map_ekv == null) {
//            map_ekv = new HashMap<>();
//        }
//        map_ekv.clear();
//        String[] keys = keyArrayString.split(",");
//        String[] values = valueArrayString.split(",");
//        int length = (keys.length >= values.length) ? keys.length : 0;//保证key数组长度大于value数组
//        for (int index = 0; index < length; index++) {
//            map_ekv.put(keys[index], values[index]);
//        }
//    }

//    /**
//     * 保证字符串不为null
//     *
//     * @param raw        用于判断的字符串
//     * @param defaultStr raw字符串为空时,要返回默认字符串
//     */
//    private String getNonNullString(String raw, String defaultStr) {
//        if (TextUtils.isEmpty(raw)) {
//            if (!TextUtils.isEmpty(defaultStr)) {
//                return defaultStr;
//            } else {
//                return "";
//            }
//        } else {
//            return raw;
//        }
//    }


//    /**
//     * 字符串除去首尾逗号和空格
//     */
//    private String removeComma(String raw) {
//
//        raw = raw.trim();
//        if (raw.startsWith(",")) {
//            raw = raw.substring(1);
//        }
//        if (raw.endsWith(",")) {
//            int length = raw.length();
//            raw = raw.substring(0, length - 1);
//        }
//
//        return raw;
//    }

//    /**
//     * 上报自定义的多属性事件
//     *
//     * @param context   上下文
//     * @param eventName 事件名称
//     * @param eventMap  事件属性哈希表
//     */
//    public void reportEvent(Context context, String eventName, Map<String, String> eventMap) {
//        if (context == null)
//            return;
//        WeakReference<Context> mContext = new WeakReference<>(context);
//        if (mContext.get() != null) {
//            MobclickAgent.onEvent(mContext.get(), eventName, eventMap);
//        }
//    }

    /**
     * U-D Plus方式上报自定义的多属性事件
     *
     * @param context   上下文
     * @param eventName 事件名称
     */
    public void reportEventPlus(Context context, String eventName) {
        if (context == null)
            return;
        WeakReference<Context> mContext = new WeakReference<>(context);
        if (mContext.get() != null) {
            UMADplus.track(mContext.get(), eventName);//u-d plus统计
        }
    }

    /**
     * U-D Plus方式上报自定义的多属性事件
     *
     * @param context   上下文
     * @param eventName 事件名称
     * @param eventMap  事件属性哈希表
     */
    public void reportEventPlus(Context context, String eventName, Map<String, Object> eventMap) {
        if (context == null)
            return;
        WeakReference<Context> mContext = new WeakReference<>(context);
        if (mContext.get() != null) {
            UMADplus.track(mContext.get(), eventName, eventMap);//u-d plus统计
        }
    }

//    /**
//     * 给当前用户标记超级属性,该用户后续触发的所有事件都将自动包含这些属性
//     *
//     * @param context       上下文
//     * @param propertyName  超级属性名
//     * @param propertyValue 超级属性值
//     */
//    public void registerSuperProperty(Context context, String propertyName, Object propertyValue) {
//        UMADplus.registerSuperProperty(context, propertyName, propertyValue);
//    }
//
//
//    /**
//     * 删除通过 registerSuperProperty 标记的超级属性,该用户后续的触发的行为事件将不再自动包含该属性
//     *
//     * @param context      上下文
//     * @param propertyName 要删除的超级属性的名称
//     */
//    public void unregisterSuperProperty(Context context, String propertyName) {
//        UMADplus.unregisterSuperProperty(context, propertyName);
//    }

    //region ===================================session的统计======================================
    /*
    * 1.确保在所有的Activity中都调用 MobclickAgent.onResume() 和MobclickAgent.onPause()方法,
    *   这两个调用将不会阻塞应用程序的主线程,也不会影响应用程序的性能。
    * 2.注意 如果您的Activity之间有继承或者控制关系请不要同时在父和子Activity中重复添加onPause和onResume方法,否则会造成重复统计,导致启动次数异常增高。
    *   (eg.使用TabHost、TabActivity、ActivityGroup时)。
    * 3.当应用在后台运行超过30秒（默认）再回到前端,将被认为是两个独立的session(启动),例如用户回到home,或进入其他程序,经过一段时间后再返回之前的应用。
    *   可通过接口：MobclickAgent.setSessionContinueMillis(long interval) 来自定义这个间隔（参数单位为毫秒）。
    * 4.如果开发者调用Process.kill或者System.exit之类的方法杀死进程,请务必在此之前调用MobclickAgent.onKillProcess(Context context)方法,用来保存统计数据。
    *
    * 非常重要：1.首先在程序入口处调用MobclickAgent.openActivityDurationTrack(false) 来禁止默认的Activity页面统计方式
    * 2.必须调用 MobclickAgent.onResume() 和MobclickAgent.onPause()方法,才能够保证获取正确的新增用户、活跃用户、启动次数、使用时长等基本数据。
    * 3. 使用 MobclickAgent.onPageStart 和 MobclickAgent.onPageEnd 方法统计页面(针对页面,页面可能是Activity 也可能是Fragment或View)
    * */

    /**
     * 用于session的统计,在App onCreate方法中调用,禁止默认的Activity页面统计方式
     *
     * @param debug 友盟统计实时调试,为true时,可以在友盟统计后台实时查看测试设备的统计日志
     */
    public void onApplicationCreate(boolean debug) {
        MobclickAgent.openActivityDurationTrack(false);
        MobclickAgent.setDebugMode(debug);
        MobclickAgent.setSessionContinueMillis(60000);//60秒
    }

    /**
     * 用于session的统计,在每个Activity的onResume方法中调用
     *
     * @param context  程序上下文
     * @param pageName 页面名称,如"LoginActivity"
     */
    public void onActivityResume(Context context, String pageName) {
        if (!TextUtils.isEmpty(pageName)) {
            MobclickAgent.onPageStart(pageName); //统计页面跳转(仅有Activity的应用中SDK自动调用,不需要单独写)
        } else {
            MobclickAgent.onPageStart("UnknownActivity");
        }
        MobclickAgent.onResume(context);//统计时长
    }

    /**
     * 用于session的统计,在每个Activity的onPause方法中调用
     *
     * @param context  程序上下文
     * @param pageName 页面名称,如"LoginActivity"
     */
    public void onActivityPause(Context context, String pageName) {
        if (!TextUtils.isEmpty(pageName)) {
            MobclickAgent.onPageEnd(pageName); //统计页面跳转(仅有Activity的应用中SDK自动调用,不需要单独写)保证 onPageEnd 在onPause 之前调用,因为 onPause 中会保存信息
        } else {
            MobclickAgent.onPageEnd("UnknownActivity");
        }
        MobclickAgent.onPause(context);
    }

    /**
     * 用于Fragment session的统计,在每个Fragment的onResume方法中调用
     *
     * @param pageName 页面名称,如"ClubFragment"
     */
    public void onFragmentResume(String pageName) {
        if (!TextUtils.isEmpty(pageName)) {
            MobclickAgent.onPageStart(pageName); //统计页面
        } else {
            MobclickAgent.onPageStart("UnknownFragment");//统计页面
        }
    }

    /**
     * 用于Fragment session的统计,在每个Fragment的onPause方法中调用
     *
     * @param pageName 页面名称,如"ClubFragment"
     */
    public void onFragmentPause(String pageName) {
        if (!TextUtils.isEmpty(pageName)) {
            MobclickAgent.onPageEnd(pageName);//统计页面
        } else {
            MobclickAgent.onPageEnd("UnknownFragment");//统计页面
        }
    }

    /**
     * 程序退出前完成统计使用时长
     *
     * @param context 上下文
     */
    public void onKillProcess(Context context) {
        MobclickAgent.onKillProcess(context);//在程序退出前完成统计使用时长
    }

    //endregion ===================================session的统计===================================

    //region ===================================自定义统计 begin===================================

//    /**
//     * 登录渠道方式统计
//     *
//     * @param context   上下文
//     * @param loginType 登录方式,目前有(fitmix:乐享动账号登录,try:试用,weibo:微博授权登录,qq:QQ授权登录,weixin:微信授权登录)
//     */
//    public void loginReport(Context context, String loginType) {
//        if (!TextUtils.isEmpty(loginType)) {
//            put("LOGIN_TYPE", loginType);
//        } else {
//            put("LOGIN_TYPE", "UnknownLoginType");
//        }
//        reportEvent(context, EVENT_ID_LOGIN, map_ekv);
//    }
//
//
//   /**
//     * 注册统计
//     *
//     * @param context 上下文
//     * @param age     年龄
//     * @param height  身高,单位CM
//     * @param weight  体重,单位KG
//     * @param gender  性别,"female":女, "male":男
//     */
//    public void registerReport(Context context, String age, String height, String weight, String gender) {
//        //年龄,身高,体重,性别
//        put("Age_Distribution,Height_Distribution,Weight_Distribution,Type", age + "," + height + "," + weight + "," + gender);
//        reportEvent(context, EVENT_ID_REGISTER, map_ekv);
//    }
//
//
//    /**
//     * 音乐下载统计事件
//     *
//     * @param context  上下文
//     * @param title    歌名
//     * @param dj       DJ歌手
//     * @param genre    曲风
//     * @param duration 时长
//     * @param scene    场景
//     */
//    public void musicDownloadReport(Context context, String title,
//                                    String dj, String genre, String duration, String scene) {
//
//        genre = getNonNullString(genre, null);
//        duration = getNonNullString(duration, null);
//        scene = getNonNullString(scene, null);
//        title = getNonNullString(title, null);
//        dj = getNonNullString(dj, null);
//
//        // 去掉曲风和场景前后多余逗号
//        genre = removeComma(genre);
//        scene = removeComma(scene);
//
//        //歌名,DJ歌手,曲风,时长,场景
//        String[] keys = new String[]{"Title", "Dj", "Genre", "Durtion", "Scene"};
//        String[] values = new String[]{title, dj, genre, duration, scene};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_MUSIC_DOWNLOAD, map_ekv);
//    }
//
//    /**
//     * 音乐收藏统计事件
//     *
//     * @param context  上下文
//     * @param title    歌名
//     * @param dj       DJ歌手
//     * @param genre    曲风
//     * @param duration 时长
//     * @param scene    场景
//     */
//    public void musicCollectionReport(Context context, String title,
//                                      String dj, String genre, String duration, String scene) {
//
//        genre = getNonNullString(genre, null);
//        duration = getNonNullString(duration, null);
//        scene = getNonNullString(scene, null);
//        title = getNonNullString(title, null);
//        dj = getNonNullString(dj, null);
//
//        // 去掉曲风和场景前后多余逗号
//        genre = removeComma(genre);
//        scene = removeComma(scene);
//
//        //歌名,DJ歌手,曲风,时长,场景
//        String[] keys = new String[]{"Title", "Dj", "Genre", "Durtion", "Scene"};
//        String[] values = new String[]{title, dj, genre, duration, scene};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_MUSIC_COLLECTION, map_ekv);
//    }
//
//    /**
//     * 音乐在线播放统计事件
//     *
//     * @param context  上下文
//     * @param title    歌名
//     * @param dj       DJ歌手
//     * @param genre    曲风
//     * @param duration 时长
//     * @param scene    场景
//     */
//    public void musicOnlinePlayReport(Context context, String title,
//                                      String dj, String genre, String duration, String scene) {
//
//        genre = getNonNullString(genre, null);
//        duration = getNonNullString(duration, null);
//        scene = getNonNullString(scene, null);
//        title = getNonNullString(title, null);
//        dj = getNonNullString(dj, null);
//
//        // 去掉曲风和场景前后多余逗号
//        genre = removeComma(genre);
//        scene = removeComma(scene);
//
//        //歌名,DJ歌手,曲风,时长,场景
//        String[] keys = new String[]{"Title", "Dj", "Genre", "Durtion", "Scene"};
//        String[] values = new String[]{title, dj, genre, duration, scene};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_MUSIC_ONLINE, map_ekv);
//    }
//
//    /**
//     * 开始运动事件统计
//     *
//     * @param context   上下文
//     * @param isOutDoor 是否为室外运动环境,true:室外,false:室内
//     * @param withMusic 是否有音乐,true:有,false:没有
//     * @param genre     音乐曲风
//     */
//    public void startRunReport(Context context, boolean isOutDoor, boolean withMusic, String genre) {
//
//        String environment = "Indoor";
//        if (isOutDoor) {
//            environment = "Outdoor";
//        }
//        String haveMusic = "NO";
//        if (withMusic) {
//            haveMusic = "YES";
//        }
//
//        String[] keys = new String[]{"Environment", "HAVE_MUSIC", "Genre"};
//        String[] values = new String[]{environment, haveMusic, genre};
//
//        put(keys, values);
//        reportEvent(context, EVENT_ID_START_RUN, map_ekv);
//    }
//
//    /**
//     * 结束运动事件统计
//     *
//     * @param context   上下文
//     * @param bpm       跑步BPM
//     * @param distance  跑步距离,单位米
//     * @param duration  跑步时长,单位毫秒
//     * @param startTime 跑步开始时间
//     */
//    public void stopRunReport(Context context, int bpm, long distance, long duration, String startTime) {
//        //BPM,距离, 时长,开始时间
//        String[] keys = new String[]{"BPM_Distribution", "Distance_Distribution", "Duration_Distribution", "Start_Time_Distribution"};
//        String[] values = new String[]{String.valueOf(bpm), String.valueOf(distance), String.valueOf(duration), startTime};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_STOP_RUN, map_ekv);
//    }
//
//    /**
//     * 音乐播放总时长统计
//     *
//     * @param context  上下文
//     * @param duration 音乐播放总时长,单位为秒,即(音乐播放器结束播放时间戳-开始播放时间戳)/1000
//     */
//    public void musicPlayDurationReport(Context context, long duration) {
//        String[] keys = new String[]{"Play_Duration"};
//        String[] values = new String[]{String.valueOf(duration)};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_MUSIC_PLAY_DURATION, map_ekv);
//    }

//    /**
//     * 分享统计
//     *
//     * @param context  上下文
//     * @param platform 分享平台,目前可取值有["QQ","QZone","Weibo","Weixin","Circle"],分别表示QQ,QQ空间,新浪微博,微信朋友,微信朋友圈
//     * @param type     分享类型,目前可取值有["Mix","RunScore"],分别表示音乐分享,运动成绩分享
//     */
//    public void shareReport(Context context, String platform, String type) {
//        String[] keys = new String[]{"Share_Platform", "Share_Type"};
//        String[] values = new String[]{platform, type};
//        put(keys, values);
//        reportEvent(context, EVENT_ID_SHARE, map_ekv);
//    }


    //endregion ===================================自定义统计===================================

    //region ============================ u-d plus 统计 ============================

    /**
     * U-D Plus 登录渠道方式统计
     *
     * @param context   上下文
     * @param loginType 登录方式,目前有(fitmix:乐享动账号登录,try:试用,weibo:微博授权登录,qq:QQ授权登录,weixin:微信授权登录)
     */
    public void loginReportPlus(Context context, String loginType) {
        String[] keys = new String[]{"登录方式"};
        String[] values;
        if (!TextUtils.isEmpty(loginType)) {
            values = new String[]{loginType};
        } else {
            values = new String[]{"未知"};
        }
        put2(keys, values);
        reportEventPlus(context, "登录", map_kv);
    }

    /**
     * U-D Plus统计音乐事件
     *
     * @param context   上下文
     * @param eventName 事件名称
     * @param musicId   音乐编号,非乐享动音乐为-1
     */
    public void musicReportPlus(Context context, String eventName, int musicId) {
        if (TextUtils.isEmpty(eventName))
            return;
        String[] keys = new String[]{"音乐编号"};
        String[] values = new String[]{String.valueOf(musicId)};

        put2(keys, values);
        reportEventPlus(context, eventName, map_kv);
    }


    /**
     * U-D Plus统计开始运动事件统计
     *
     * @param context   上下文
     * @param isInDoor  是否为室内运动环境,true:室内,false:室外
     * @param withMusic 是否有音乐,true:有,false:没有
     * @param withVoice 是否有语音播报,true:有,false:没有
     * @param runType   跑步类型,[自由跑,距离跑,时间跑,卡路里]等
     * @param target    任务目标
     */
    public void startRunReportPlus(Context context, boolean isInDoor, boolean withMusic, boolean withVoice, String runType, String target) {

        String environment = "室外";
        if (isInDoor) {
            environment = "室内";
        }
        String haveMusic = "关";
        if (withMusic) {
            haveMusic = "开";
        }

        String voice = "关";
        if (withVoice) {
            voice = "开";
        }

        String[] keys = new String[]{"运动环境", "音乐", "语音播报", "跑步类型", "运动目标"};
        String[] values = new String[]{environment, haveMusic, voice, runType, target};

        put2(keys, values);
        reportEventPlus(context, "运动设置\"开始\"", map_kv);
    }

    /**
     * U-D Plus在运动记录详情界面停留时长统计
     *
     * @param context  上下文
     * @param duration 停留时长,单位为毫秒
     */
    public void runRecordDuration(Context context, long duration) {
        if (context == null || duration < 1500) {//大于1.5秒
            return;
        }
        String[] keys = new String[]{"停留时长"};
        String[] values = new String[]{String.valueOf(duration / 1000)};//单位转化为秒

        put2(keys, values);
        reportEventPlus(context, "我的记录详情界面", map_kv);
    }

    /**
     * U-D Plus在运动主界面,节拍器使用时长统计
     *
     * @param context  上下文
     * @param duration 节拍器使用时长,单位为毫秒
     */
    public void metronomeDuration(Context context, long duration) {
        if (context == null || duration < 5000 || duration > 1000000000000L) {//大于5秒
            return;
        }
        String[] keys = new String[]{"节拍器使用时长"};
        String[] values = new String[]{String.valueOf(duration / 1000)};//单位转化为秒

        put2(keys, values);
        reportEventPlus(context, "节拍器", map_kv);
    }

    /**
     * U-D Plus统计自创建歌单数量
     *
     * @param context 上下文
     * @param uid     用户uid
     * @param number  自创建歌单数量
     */
    public void customAlbumReport(Context context, int uid, long number) {
        if (context == null || number <= 0 || uid <= 0) {
            return;
        }
        String[] keys = new String[]{"用户编号", "自建歌单数量"};
        String[] values = new String[]{String.valueOf(uid), String.valueOf(number)};

        put2(keys, values);
        reportEventPlus(context, "自建歌单", map_kv);
    }

    /**
     * U-D Plus搜索统计
     *
     * @param context    上下文
     * @param searchText 搜索词
     */
    public void searchReport(Context context, String searchText) {
        if (context == null || TextUtils.isEmpty(searchText)) {
            return;
        }
        String[] keys = new String[]{"搜索词"};
        String[] values = new String[]{searchText};

        put2(keys, values);
        reportEventPlus(context, "搜索统计", map_kv);
    }

    /**
     * U-D Plus专辑统计
     *
     * @param context   上下文
     * @param albumName 专辑名称
     */
    public void albumReport(Context context, String albumName) {
        if (context == null || TextUtils.isEmpty(albumName)) {
            return;
        }
        String[] keys = new String[]{"专辑名称"};
        String[] values = new String[]{albumName};

        put2(keys, values);
        reportEventPlus(context, "查看音乐专辑", map_kv);
    }

    /**
     * U-D Plus音乐播放事件
     *
     * @param context   上下文
     * @param eventName 事件名称
     * @param music     音乐信息
     */
    public void musicPlayReportPlus(Context context, String eventName, Music music) {
        if (TextUtils.isEmpty(eventName))
            return;
        String[] keys = new String[]{"音乐ID", "音乐名称", "手机流量播放", "音乐类型", "播放量"};
        String[] values = new String[]{String.valueOf(music.getId()), music.getName(), ApiUtils.getNetworkType() == 2 ? "否" : "是"
                , music.getLocalFlag() == 1 ? "本地音乐" : "乐享动音乐", String.valueOf(music.getAuditionCount() + 1)};

        put2(keys, values);
        reportEventPlus(context, eventName, map_kv);
    }

    /**
     * U-D Plus APP启动单次音乐播放时长事件
     *
     * @param context  上下文
     * @param duration 音乐播放时长,单位为秒
     */
    public void musicPlayDurationReportPlus(Context context, long duration) {
        if (context == null)
            return;
        String[] keys = new String[]{"音乐播放时长"};
        String[] values = new String[]{String.valueOf(duration)};

        put2(keys, values);
        reportEventPlus(context, "用户单次播放时长", map_kv);
    }


    /**
     * U-D Plus闪屏广告点击
     *
     * @param context       上下文
     * @param eventName     事件名称
     * @param advertisement 广告信息
     */
    public void advertisementReportPlus(Context context, String eventName, Adverts advertisement) {
        if (TextUtils.isEmpty(eventName))
            return;
        String[] keys = new String[]{"广告名称", "广告连接"};
        String[] values = new String[]{advertisement.getTitle(), advertisement.getToUrl()};

        put2(keys, values);
        reportEventPlus(context, eventName, map_kv);
    }

//    /**
//     * U-D Plus闪屏广告点击
//     *
//     * @param context       上下文
//     * @param eventName     事件名称
//     * @param advertisement 广告信息
//     */
//    public void advertisementReportPlus(Context context, String eventName, Advertisement advertisement) {
//        if (TextUtils.isEmpty(eventName))
//            return;
//        String[] keys = new String[]{"广告名称", "广告连接"};
//        String[] values = new String[]{advertisement.getTitle(), advertisement.getToUrl()};
//
//        put2(keys, values);
//        reportEventPlus(context, eventName, map_kv);
//    }

    /**
     * U-D Plus运动记录分享
     *
     * @param context  上下文
     * @param time     运动时长,单位秒
     * @param distance 运动距离,单位米
     * @param step     运动步数
     */
    public void shareRecordReportPlus(Context context, String time, String distance, String step) {
        if (context == null)
            return;
        String[] keys = new String[]{"运动时长(秒)", "运动距离(米)", "运动步数"};
        String[] values = new String[]{time, distance, step};

        put2(keys, values);
        reportEventPlus(context, "运动记录分享", map_kv);
    }

    /**
     * U-D Plus 音乐分享
     *
     * @param context 上下文
     * @param id      音乐ID
     * @param name    音乐名称
     * @param type    音乐类型,1:音乐,2:电台
     */
    public void shareMusicReportPlus(Context context, int id, String name, int type) {
        if (context == null) {
            return;
        }

        String[] keys = new String[]{"音乐ID", "音乐名称", "类型"};
        String[] values = new String[]{String.valueOf(id), name, type == 1 ? "音乐" : "电台"};

        put2(keys, values);
        reportEventPlus(context, "音乐分享", map_kv);
    }

    /**
     * 运动赛事点击
     *
     * @param context 上下文
     * @param name    赛事名称
     */
    public void competitionReportPlus(Context context, String name) {
        if (TextUtils.isEmpty(name) || context == null)
            return;

        String[] keys = new String[]{"赛事名称"};
        String[] values = new String[]{name};

        put2(keys, values);
        reportEventPlus(context, "点击赛事", map_kv);
    }

    /**
     * U-D Plus 赛事分享
     *
     * @param context 上下文
     * @param name    赛事名称
     */
    public void shareCompetitionReportPlus(Context context, String name) {
        if (context == null) {
            return;
        }

        String[] keys = new String[]{"赛事名称"};
        String[] values = new String[]{name};

        put2(keys, values);
        reportEventPlus(context, "赛事分享", map_kv);
    }

    /**
     * U-D Plus 点击运动视频
     *
     * @param context 上下文
     * @param name    视频名称
     */
    public void videoReportPlus(Context context, String name) {
        if (context == null) {
            return;
        }

        String[] keys = new String[]{"视频名称"};
        String[] values = new String[]{name};

        put2(keys, values);
        reportEventPlus(context, "点击运动视频", map_kv);
    }


    //endregion ============================ u-d plus 统计 ============================

}
