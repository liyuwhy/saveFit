package com.fitmix.sdk.common.bluetooth;

public class Bolt_gaia_t {
    public static final int BOLT_GAIA_BUFFER_LENGTH = 96;

    //	public static final int BOLT_GAIA_CMD_NONE = 0;
//	public static final int BOLT_GAIA_CMD_SET_FONT = 1;
//	public static final int BOLT_GAIA_CMD_SET_SPEED = 2;
//	public static final int BOLT_GAIA_CMD_STATIC_BMP = 3;
    public static final int BOLT_GAIA_CMD_STATIC_TEXT = 4;
    /**
     * 发送动态文字
     */
    public static final int BOLT_GAIA_CMD_ANIM_TEXT = 5;
//	public static final int BOLT_GAIA_CMD_DRAW_PIXEL = 6;
//	public static final int BOLT_GAIA_CMD_DRAW_LINE = 7;
//	public static final int BOLT_GAIA_CMD_SLICE_BMP = 8;
    /**
     * 发送表情
     */
    public static final int BOLT_GAIA_CMD_EMOJI = 9;
//	public static final int BOLT_GAIA_CMD_SET_LED_DISP_MODLE = 10;//新增
//	public static final int BOLT_GAIA_CMD_SET_LED_SW = 11;//新增
//	public static final int BOLT_GAIA_CMD_ENTER_HID_DFU = 240;
//	public static final int BOLT_GAIA_CMD_ENTER_DFU_CLASSIC = 241;//新增
//	public static final int BOLT_GAIA_CMD_MAX = 8;
//
//	public static final int GRAPHIC_SPEED_LV1 = 0;
//	public static final int GRAPHIC_SPEED_LV2 = 1;
//	public static final int GRAPHIC_SPEED_LV3 = 2;
//	public static final int GRAPHIC_SPEED_MAX = 3;

    //	public static final int GRAPHIC_FMT_1BIT = 0;
    public static final int GRAPHIC_FMT_4BIT = 1;
    public static final int GRAPHIC_FMT_8BIT = 2;
//	public static final int GRAPHIC_FMT_COUNT = 3;


//	public static final int BOLT_GATT_CHAR_MODEL = 0x2A24;
//	public static final int BOLT_GATT_CHAR_SERIALNO = 0x2A25;
//	public static final int BOLT_GATT_CHAR_FW_VER = 0x2A26;
//	public static final int BOLT_GATT_CHAR_HW_VER = 0x2A27;
//	public static final int BOLT_GATT_CHAR_MANUFACTURER = 0x2A29;

//	public static final int BOLT_GATT_CHAR_BOARD_NAME = 0x0604;
//	public static final int BOLT_GATT_CHAR_SW_VER = 0x0611;
    /**
     * G-SENSOR数据
     */
    public static final int BOLT_GATT_CHAR_SENSOR = 0x0666;
    //public static final int BOLT_GATT_CHAR_RUNNING_STEPS = 0x0670; //change to key pad definition
//	public static final int BOLT_GATT_CHAR_KEYPAD = 0x0670;
    public static final int BOLT_GATT_CHAR_HEART_RATE = 0x0678;
//	public static final int BOLT_GATT_CHAR_SENCE = 0x0680;
//	public static final int BOLT_GATT_CHAR_BPM = 0x0681;
    //public static final int BOLT_GATT_CHAR_GAIA_TRANSFER = 0x06E0;	//not use, use GAIA directly


    public byte cmd;
    public byte x;
    public byte y;
    public byte color;
    public byte color_format;
    public byte anim_count;
    public byte flag;
    public byte data[];

    public Bolt_gaia_t() {
        cmd = 0;
        x = 0;
        y = 0;
        color = (byte) 0xFF;
        color_format = GRAPHIC_FMT_4BIT;
        anim_count = 0;
        flag = 0;
        data = new byte[72];
    }

    public byte[] toBytes() {
        int i, j;
        byte[] gdata = new byte[BOLT_GAIA_BUFFER_LENGTH];
        i = 0;
        gdata[i++] = cmd;
        gdata[i++] = x;
        gdata[i++] = y;
        gdata[i++] = color;
        gdata[i++] = color_format;
        gdata[i++] = anim_count;
        gdata[i++] = flag;
        for (j = 0; j < data.length; j++) {
            gdata[i++] = data[j];
        }

        if (cmd == BOLT_GAIA_CMD_ANIM_TEXT || cmd == BOLT_GAIA_CMD_STATIC_TEXT)
//			gdata[i++] = '\0';
            gdata[i] = '\0';
        return gdata;
    }
}
