package com.fitmix.sdk.common.bluetooth;

import android.bluetooth.BluetoothDevice;

/**
 * 蓝牙事件监听
 */
public interface BtStatusListener {

    /**
     * 手机不支持蓝牙
     */
    void notSupportBt();

    /**
     * 需要手动打开蓝牙
     */
    void shouldTurnOnBt();

    /**
     * 发现蓝牙设备
     *
     * @param bluetoothDevice 蓝牙设备
     */
    void foundBtDevice(BluetoothDevice bluetoothDevice);

    /**
     * 正在查找蓝牙设备
     */
    void discovering();

    /**
     * 查找蓝牙设备完成
     */
    void discoverFinish();

    /**
     * A2DP连接成功
     */
    void a2dpConnectSuccess();

    /**
     * A2DP连接失败
     */
    void a2dpConnectFail();

    /**
     * A2DP断开连接
     */
    void a2dpDisconnect();

    /**
     * Gaia连接成功
     */
    void gaiaConnect();

    /**
     * Gaia断开连接
     */
    void gaiaDisconnect();

}
