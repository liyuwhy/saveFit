package com.fitmix.sdk.common.bluetooth;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothProfile.ServiceListener;
import android.os.Handler;

import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 蓝牙A2DP连接监听
 */
public class A2dpServiceListener implements ServiceListener {

    /**
     * A2DP连接成功消息
     */
    public static final int MSG_A2DP_CONNECT_SUCCESS = 106;
    /**
     * A2DP连接失败消息
     */
    public static final int MSG_A2DP_CONNECT_FAIL = 107;
    /**
     * A2DP断开连接消息
     */
    public static final int MSG_A2DP_DISCONNECT = 108;

    public BluetoothA2dp mBluetoothHeadset;
    public BluetoothDevice mBluetoothDevice;
    public BluetoothProfile mProxy;
    private WeakReference<Handler> mHandler;

    /**
     * @param btDevice 蓝牙设备
     */
    public A2dpServiceListener(BluetoothDevice btDevice, Handler handler) {
        mBluetoothDevice = btDevice;
        mHandler = new WeakReference<>(handler);
    }

    @Override
    public void onServiceConnected(int profile, BluetoothProfile proxy) {
        if (profile == BluetoothProfile.A2DP) {
            //use reflect method to get the Hide method "connect" in BluetoothA2DP
            mProxy = proxy;
            mBluetoothHeadset = (BluetoothA2dp) proxy;  //BluetoothA2dp a2dp
            Class<? extends BluetoothA2dp> clazz = mBluetoothHeadset.getClass();
            //通过BluetoothA2DP隐藏的connect(BluetoothDevice btDev)函数,打开btDev的A2DP服务
            Handler handler = mHandler.get();

            try {//先绑定配对
                Method m = mBluetoothDevice.getClass().getMethod("createBond");
                m.invoke(mBluetoothDevice);
            } catch (NoSuchMethodException e1) {
                e1.printStackTrace();
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
            } catch (IllegalArgumentException e3) {
                e3.printStackTrace();
            } catch (InvocationTargetException e4) {
                e4.printStackTrace();
            }

            try {
              /*
               * 1.Reflect this method
                 public boolean connect(BluetoothDevice device);
               *
               * 2.function definition
                 getMethod(String methodName, Class <?>... paramType)
               */
                //1.这步相当于定义函数
                Method method_Connect = clazz.getMethod("connect", BluetoothDevice.class);
                //invoke(object receiver,object... args)
                //2.这步相当于调用函数,invoke需要传入args：BluetoothDevice的实例
                method_Connect.invoke(mBluetoothHeadset, mBluetoothDevice); /*a2dp, mBTDevInThread*/
//                Logger.i(Logger.DEBUG_TAG, "onServiceConnected current thread:" + Thread.currentThread().getId());
                if (handler != null) {
                    handler.sendEmptyMessage(MSG_A2DP_CONNECT_SUCCESS);
                }
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
                if (handler != null)
                    handler.sendEmptyMessage(MSG_A2DP_CONNECT_FAIL);
            } catch (IllegalAccessException e1) {
                e1.printStackTrace();
                if (handler != null)
                    handler.sendEmptyMessage(MSG_A2DP_CONNECT_FAIL);
            } catch (IllegalArgumentException e2) {
                e2.printStackTrace();
                if (handler != null)
                    handler.sendEmptyMessage(MSG_A2DP_CONNECT_FAIL);
            } catch (InvocationTargetException e3) {
                e3.printStackTrace();
                if (handler != null)
                    handler.sendEmptyMessage(MSG_A2DP_CONNECT_FAIL);
            }
        }
    }

    @Override
    public void onServiceDisconnected(int profile) {
        if (profile == BluetoothProfile.A2DP) {
            mBluetoothHeadset = null;
            if (mHandler != null) {
                Handler reference = mHandler.get();
                if (reference != null) {
                    reference.sendEmptyMessage(MSG_A2DP_DISCONNECT);
                }
            }
        }
    }

}
