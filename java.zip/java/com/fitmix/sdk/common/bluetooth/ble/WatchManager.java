package com.fitmix.sdk.common.bluetooth.ble;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.Watch1024ReceivedTempData;
import com.fitmix.sdk.watch.bean.Watch1024SendTempData;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.UUID;

/**
 * 手表BLE管理
 */
public class WatchManager extends BleManager<BleManagerCallbacks> {

    //region ================================== BLE特征值及单例相关 ==================================

    public final static UUID HR_SERVICE_UUID = UUID.fromString("0000180D-0000-1000-8000-00805f9b34fb");
    /**
     * 手表主服务UUID
     */
    public final static UUID WATCH_SERVICE_UUID = UUID.fromString("0000FD01-0000-1000-8000-00805f9b34fb");

    /**
     * 接收手表数据
     */
    private final static UUID WATCH_READ_CHARACTERISTIC_UUID = UUID.fromString("0000FD02-0000-1000-8000-00805f9b34fb");
    /**
     * 发送数据给手表
     */
    public final static UUID WATCH_WRITE_CHARACTERISTIC_UUID = UUID.fromString("0000FD03-0000-1000-8000-00805f9b34fb");

    /**
     * 手表BLE服务特征值接收对象
     */
    private BluetoothGattCharacteristic mWatchReadCharacteristic, mWatchWriteCharacteristic;

    private Context mContext;

    public WatchManager(final Context context) {
        super(context);
    }

    //endregion ================================== BLE特征值及单例相关 ==================================

    //region ================================== 计时器相关 ==================================

    /**
     * 是否刚刚发送了1024中最后的20字节包
     */
    private boolean justSentLast20Pag = false;

    /**
     * Handler消息:发送完1024后等待手表发ack回应
     */
    private static final int MSG_SEND_WAIT_ACK_COUNT_DOWN = 100;

    /**
     * 当前已经等待手表数据层ack回复的秒数
     */
    public int mWaitAckTime;

    /**
     * 等待ack最大秒数,默认10秒
     */
    private final int MAX_WAIT_ACK_SECOND = 10;

    /**
     * Handler消息:发送1024字节后,开始倒计时等待手表回应response包
     */
    private static final int MSG_WAITING_RESPONSE_COUNT_DOWN = 1003;
    /**
     * 等待response超时秒数,默认40秒
     */
    private static final int MAX_WAIT_RESPONSE_TIME = 40;

    /**
     * 当前已经等待手表应用层response回复的秒数
     */
    public int mWaitResponseTime;

    /**
     * Handler消息:开始接收数据包后,规定时间内必须全部数据包接收完毕
     */
    private static final int MSG_COUNT_DOWN_RECEIVING = 101;
    /**
     * 接收数据包时长,标示接收超时
     */
    public int timeNowReceiving = 0;
    /**
     * 接收数据包超时阈值,最长为10秒
     */
    private static final int RECEIVING_TIMEOUT = 10;
    /**
     * 发送ACK次数，如果发送ack错误时，进行重发
     */
    private int sendAckTimes = 0;
    /**
     * 重发Ack的最大次数
     */
    private static final int MAX_SEND_ACK_TIMES = 2;

    private WatchManagerHandler watchManagerHandler;

    class WatchManagerHandler extends Handler {
        public WatchManagerHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_SEND_WAIT_ACK_COUNT_DOWN://发送完1024后等待ack回复
                    mWaitAckTime++;
                    if (mWaitAckTime < MAX_WAIT_ACK_SECOND) {
                        sendEmptyMessageDelayed(MSG_SEND_WAIT_ACK_COUNT_DOWN, 1000);
                    } else {
                        clearWaitAckState();
                        setPack1024SendState(STATE_SUCCESS);//默认为收到ack和response包
                        Logger.e(Logger.DEBUG_TAG, "WatchManager,等待ack超时");
                    }
                    break;

                case MSG_COUNT_DOWN_RECEIVING://每次接收1024字节的计时
                    timeNowReceiving += 1;
                    if (timeNowReceiving < RECEIVING_TIMEOUT) {//未超时
                        sendEmptyMessageDelayed(MSG_COUNT_DOWN_RECEIVING, 1000);
                    } else {//超时
                        Logger.e(Logger.DEBUG_TAG, "接收数据包超时");
                        timeNowReceiving = 0;
                        removeMessages(MSG_COUNT_DOWN_RECEIVING);
//                        sendAckCmd(ACK_TIMEOUT);
//                        clearReceivedData();//将之前接收到的置为空
                    }
                    break;

                case MSG_WAITING_RESPONSE_COUNT_DOWN://发送1024字节后,开始倒计时等待手表回应response包
                    mWaitResponseTime++;
                    if (mWaitResponseTime < MAX_WAIT_RESPONSE_TIME) {
                        sendEmptyMessageDelayed(MSG_WAITING_RESPONSE_COUNT_DOWN, 1000);
                    } else {
                        if (mSending1024Data != null) {
                            int groupTag = WatchFormatManager.getGroupTagFromTag(mSending1024Data.getTag());
                            int cell = WatchFormatManager.getCellFromTag(mSending1024Data.getTag());
                            Logger.e(Logger.DEBUG_TAG, "WatchManager,等待response超时 groupTag:" + groupTag + ",cell:" + cell);
                        } else {
                            Logger.e(Logger.DEBUG_TAG, "WatchManager,等待response超时");
                        }
                        clearWaitResponseState();
                    }
                    break;
            }
        }
    }

    public void setWatchManagerHandler(Context context) {
        mContext = context;
        watchManagerHandler = new WatchManagerHandler(context.getMainLooper());
    }

    private WatchManagerHandler getWatchManagerHandler() {
        if (watchManagerHandler == null) {
            watchManagerHandler = new WatchManagerHandler(mContext.getMainLooper());
        }
        return watchManagerHandler;
    }

    //endregion ================================== 计时器相关 ==================================

    //region ================================== BLE事件回调接口 ==================================

    private WatchManagerCallbacks mWatchManagerCallbacks;

    /**
     * 设置手表BLE事件回调
     */
    public void setWatchManagerCallbacks(WatchManagerCallbacks watchManagerCallbacks) {
        mWatchManagerCallbacks = watchManagerCallbacks;
        super.setGattCallbacks(mWatchManagerCallbacks);//补充WatchManagerCallbacks父类BleManagerCallbacks功能
    }

    /**
     * 获取手表数据读写功能是否可用
     *
     * @return true:是,false:否
     */
    public boolean isWatchDataChannelOk() {
        if (mBluetoothGatt == null)
            return false;

        if (mWatchReadCharacteristic != null || mWatchWriteCharacteristic != null)
            return true;

        return false;
    }


    /**
     * 获取当前的蓝牙GATT
     */
    public BluetoothGatt getBluetoothGatt() {
        return mBluetoothGatt;
    }

    //endregion ================================== BLE事件回调接口 ==================================

    //region ================================== BLE层协议相关 ==================================

    /**
     * ack数据包类型,还未发送
     */
    public static final byte ACK_NOT_SEND = 0x00;
    /**
     * ack数据包类型,成功
     */
    public static final byte ACK_SUCCESS = 0x01;
    /**
     * ack数据包类型,失败
     */
    public static final byte ACK_FAIL = 0x02;
    /**
     * ack数据包类型,头错误
     */
    public static final byte ACK_ERROR_HEADER = 0x03;
    /**
     * ack数据包类型,长度错误
     */
    public static final byte ACK_ERROR_LENGTH = 0x04;
    public static final byte ACK_SINGLE_BAG_SUCCESS = 0x05;
    /**
     * ack数据包类型,超时
     */
    public static final byte ACK_TIMEOUT = 0x06;

    /**
     * 是否正在发送数据,每次发送20字节后,必须收到蓝牙回馈（成功或失败）才算完成
     */
    private boolean is20Sending = false;

    public boolean isIs20Sending() {
        return is20Sending;
    }

    public void setIs20Sending(boolean is20Sending) {
        this.is20Sending = is20Sending;
    }

    /**
     * 当前20字节是否为回应手表的ack数据包
     */
    private boolean is20Ack = false;

    /**
     * 当前正在接收的1024字节数据
     */
    private Watch1024ReceivedTempData watch1024ReceivedTempData;

    private LinkedList<Watch1024ReceivedTempData> waitSendAckQueue;

    /**
     * 手机端接收1024字节包后,应该向手表发送ACK包,但由于目前写通道忙,将需要发送的ACK包加入等待列表
     */
    public LinkedList<Watch1024ReceivedTempData> getWaitSendAckQueue() {
        if (waitSendAckQueue == null) {
            waitSendAckQueue = new LinkedList<>();
        }
        return waitSendAckQueue;
    }

    private LinkedList<Watch1024ReceivedTempData> tempReceivedDataQueue;

    /**
     * 保存 手机端接收1024字节包后向手表发送ack回应情况
     */
    public LinkedList<Watch1024ReceivedTempData> getTempReceivedDataQueue() {
        if (tempReceivedDataQueue == null) {
            tempReceivedDataQueue = new LinkedList<>();
        }
        return tempReceivedDataQueue;
    }

    private boolean writeCharacteristicError = false;//蓝牙写（拆分1024字节数据包成n个20字节包）的特征值包出错

    //endregion ================================== BLE层协议相关 ==================================

    //region ================================== 父类BleManager相关 ==================================

    /**
     * 清除WatchManager有关状态
     */
    public void clear() {
        justSentLast20Pag = false;
        mWaitAckTime = 0;
        mWaitResponseTime = 0;
        timeNowReceiving = 0;
        sendAckTimes = 0;

        is20Sending = false;
        is20Ack = false;
        watch1024ReceivedTempData = null;
        if (waitSendAckQueue != null) {
            waitSendAckQueue.clear();
        }
        waitSendAckQueue = null;
        if (tempReceivedDataQueue != null) {
            tempReceivedDataQueue.clear();
        }
        tempReceivedDataQueue = null;

        pack1024SendState = STATE_SUCCESS;
        if (mSendDataQueue != null) {
            mSendDataQueue.clear();
        }
        mSendDataQueue = null;
        mSending1024Data = null;

        mMsgQueueHasData = false;
        ThreadManager.clearBleThread();
    }

    @Override
    protected BleManagerGattCallback getGattCallback() {
        return mGattCallback;
    }

    /**
     * BLE蓝牙底层gatt连接回调
     * <p>
     * BluetoothGatt callbacks for connection/disconnection, service discovery, receiving notification, etc
     * </p>
     * <p>
     * 流程:onServicesDiscovered-->isRequiredServiceSupported-->initGatt-->ensureServiceChangedEnabled
     * </p>
     * -->onCharacteristicNotified
     */
    private BleManagerGattCallback mGattCallback = new BleManagerGattCallback() {

        @Override
        protected Queue<Request> initGatt(final BluetoothGatt gatt) {
            final LinkedList<Request> requests = new LinkedList<>();
//			if (mHRLocationCharacteristic != null)
//				requests.push(Request.newReadRequest(mHRLocationCharacteristic));
            //有数据更改时,触发onCharacteristicNotified回调
            requests.add(Request.newEnableNotificationsRequest(mWatchReadCharacteristic));
            requests.add(Request.newEnableNotificationsRequest(mWatchWriteCharacteristic));
            return requests;
        }

        @Override
        protected boolean isRequiredServiceSupported(final BluetoothGatt gatt) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                final BluetoothGattService watchService = gatt.getService(WATCH_SERVICE_UUID);//手表服务
                if (watchService != null) {
                    mWatchReadCharacteristic = watchService.getCharacteristic(WATCH_READ_CHARACTERISTIC_UUID);
                    mWatchWriteCharacteristic = watchService.getCharacteristic(WATCH_WRITE_CHARACTERISTIC_UUID);
//					mWatchWriteCharacteristic.setWriteType();
                    Logger.i(Logger.DEBUG_TAG, "WatchManager-->BleManagerGattCallback isRequiredServiceSupported..");
                } else {
                    Logger.e(Logger.DEBUG_TAG, "WatchManager-->BleManagerGattCallback isRequiredServiceSupported watchService is null");
                }
            }
            return mWatchReadCharacteristic != null || mWatchWriteCharacteristic != null;
        }

//		@Override
//		protected boolean isOptionalServiceSupported(final BluetoothGatt gatt) {
//			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
//				//可选的服务特征值接收
//				final BluetoothGattService service = gatt.getService(HR_SERVICE_UUID);
//				if (service != null) {
//					mHRLocationCharacteristic = service.getCharacteristic(HR_SENSOR_LOCATION_CHARACTERISTIC_UUID);
//				}
//			}
//			return mHRLocationCharacteristic != null;
//		}

        @Override
        public void onCharacteristicRead(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic) {
            // do nothing
            Logger.i(Logger.DEBUG_TAG, "WatchManager-->onCharacteristicRead");
        }

        @Override
        protected void onDeviceDisconnected() {
            mWatchReadCharacteristic = null;
            mWatchWriteCharacteristic = null;
            clear();
        }

        /**
         * 写特征值成功,即发送20字节数据成功
         * @param gatt           GATT client invoked {@link BluetoothGatt#writeCharacteristic}
         * @param characteristic Characteristic that was written to the associated
         */
        @Override
        protected void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicWrite(gatt, characteristic);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {//TODO 这个回调不可靠??
                Logger.i(Logger.DEBUG_TAG, "WatchManager-->onCharacteristicWrite justSentLast20Pag:" + justSentLast20Pag +
                        ",pack1024SendState:" + pack1024SendState + ",is20Ack:" + is20Ack + ",thread id:" + Thread.currentThread().getId());
//                if (mWatchManagerCallbacks != null) {
                if (justSentLast20Pag && pack1024SendState == STATE_SENDING) {//data1024Sending
                    Logger.i(Logger.DEBUG_TAG, "WatchManager-->数据写成功最后一个20字节包成功 onCharacteristicWrite justSentLast20Pag:" + justSentLast20Pag +
                            ",pack1024SendState:" + pack1024SendState + ",is20Ack:" + is20Ack + ",thread id:" + Thread.currentThread().getId());
                    justSentLast20Pag = false;
//                        data1024Sending = false;
                    setPack1024SendState(STATE_WAITING);//pack1024SendState = STATE_WAITING;
                }

                if (is20Ack) {
//                        mWatchManagerCallbacks.sendAckCmdToWatchDone();
                    if (getTempReceivedDataQueue().size() > 0) {//在发送无直接关联的大包时（eg：底层ack回复包与付工应答包之间）需要准确收到write ack成功才进行下一步
                        Watch1024ReceivedTempData data = getTempReceivedDataQueue().poll();
                        Logger.d(Logger.DEBUG_TAG, "WatchManager--->onCharacteristicWrite is20Ack,分析1024，剩下的1024size==" + getTempReceivedDataQueue().size());
                        if (data != null && data.getAckCmd() == ACK_SUCCESS) {
                            if (mWatchManagerCallbacks != null) {
                                mWatchManagerCallbacks.receive1024DataSuccess(data.getReceived1024Data());
                            }
                        } else {
                            Logger.e(Logger.DEBUG_TAG, "WatchManager--->onCharacteristicWrite is20Ack,cmd = " + data.getAckCmd() + ",不分析1024包");
                        }
                    } else {
                        Logger.e(Logger.DEBUG_TAG, "WatchManager--->onCharacteristicWrite is20Ack,error,case size <= 0");
                    }

                    is20Ack = false;
                    sendAckTimes = 0;
//                        Logger.d(Logger.DEBUG_TAG, "WatchManager--->清空receivedData");
//                        clearReceivedData();
                }
//                }
                is20Sending = false;
            }
        }

        @Override
        protected void onError(String message, int errorCode) {
            Logger.e(Logger.DEBUG_TAG, "WatchManager--->onError(),message:" + message + ",errorCode:" + errorCode);
            if (ERROR_WRITE_CHARACTERISTIC.equals(message)) {//写数据失败
                is20Sending = false;
                if (mWatchManagerCallbacks != null) {
                    if (justSentLast20Pag && pack1024SendState == STATE_SENDING) {//&& mWatchManagerCallbacks.ifData1024Sending()) {
                        justSentLast20Pag = false;
//                        data1024Sending = false;// mWatchManagerCallbacks.setData1024Sending(false);
                        setPack1024SendState(STATE_WAITING);//pack1024SendState = STATE_WAITING;

//                        if (getNowWaitAckSecond().size() > 0) {
//                            getNowWaitAckSecond().remove(0);
//                            if (getNowWaitAckSecond().size() == 0) {
//                                getWatchManagerHandler().removeMessages(MSG_SEND_WAIT_ACK_COUNT_DOWN);
//                            }
//                        }
                    }

                    if (is20Ack) {
                        is20Ack = false;
                        sendAckTimes += 1;
                        if (sendAckTimes < MAX_SEND_ACK_TIMES) {
//                            resendAckCmd(mWatchManagerCallbacks.removeTemp1024Data());
                            if (getTempReceivedDataQueue().size() > 0) {
                                Watch1024ReceivedTempData tempData = getTempReceivedDataQueue().poll();
                                sendAckCmd(tempData, true);
                            } else {
                                Logger.e(Logger.DEBUG_TAG, "WatchManager--->removeTemp1024Data(),error");
                            }
                        } else {
                            Logger.e(Logger.DEBUG_TAG, "WatchManager--->onError(),重发次数达到最大,不再发送ack");
                        }
                    }
                }
            } else if (ERROR_CONNECTION_STATE_CHANGE.equals(message)) {//连接问题
                if (mWatchManagerCallbacks != null) {
                    mWatchManagerCallbacks.onError(message, errorCode);
                }
            }
        }

        @Override
        public void onCharacteristicNotified(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
//                WatchFormatManager.logoutAllByte("WatchManager--->onCharacteristicNotified():", characteristic.getValue());
//                Logger.i(Logger.DEBUG_TAG, "WatchManager-->onCharacteristicNotified thread id:" + Thread.currentThread().getId());
                if (characteristic != null && WATCH_READ_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                    byte[] value = characteristic.getValue();
                    WatchFormatManager.logoutAllByte("WatchManager--->数据收到响应 onCharacteristicNotified thread id:" + Thread.currentThread().getId() + ",value:", value);
                    if (value != null) {
                        if (value.length == 8 && value[0] == (byte) 0xaa && value[1] == (byte) 0x55 && value[5] == 2) {//为ack回复包 aa55
                            analyseAckData(value);
                        } else {//发送过来的数据
                            //android与手表BLE底层每次写20个字节,FIXME 注意此条件有没有可能出现误判?
                            if (value.length > 7 && value[0] == (byte) 0xaa && value[1] == (byte) 0x55 && value[5] == 1) {//新的1024字节包头
                                new1024PackReceive(value);
                            } else {//1024字节包后续
                                rest1024PackReceive(value);
                            }
                        }
                    }
                }
            }
        }
    };

    //endregion ================================== 父类BleManager相关 ==================================

    //region ================================== 接收 ==================================

    /**
     * 解析手表发来的ack数据包,长度20个字节内
     *
     * @param receivedData 接收到的ack数据
     */
    private void analyseAckData(byte[] receivedData) {
        if (pack1024SendState != STATE_WAITING) {
            Logger.e(Logger.DEBUG_TAG, "WatchManager--->pack1024SendState不在等待中,但收到ack");//fixme 大文件传输log 1
        }
        if (mSending1024Data != null)
            Logger.e(Logger.DEBUG_TAG, "WatchManager-->analyseAckData 当前发送的1024字节数据:" + mSending1024Data.toString());

        if (mSending1024Data != null && mSending1024Data.getType() == Watch1024SendTempData.TYPE_RESPONSE) {
            setPack1024SendState(STATE_SUCCESS);//当前1024包是response包,直接判定发送成功
        } else {
            setPack1024SendState(STATE_ACK);
            mWaitResponseTime = 0;//开启等待response包倒计时
            getWatchManagerHandler().sendEmptyMessageDelayed(MSG_WAITING_RESPONSE_COUNT_DOWN, 1000);
        }

        clearWaitAckState();//移除等待ack回复message

        /**接收到数据 */
        int lengthTotal = receivedData.length - 4;//减去固定头0xaa 0x55和2字节数据长度,共4字节
        int length = unsignedBytesToInt(receivedData[3], receivedData[2]);//长度至少是4
        if (lengthTotal != length) {//数据长度匹配
            WatchFormatManager.logoutAllByte("WatchManager--->analyseAckData(),lengthTotal:" + lengthTotal + ", != length:" + length + ",", receivedData, false);
            return;
        }
        byte result = receivedData[6];//结果 ack回应类型
        if (result == ACK_SUCCESS) {//接收成功
            Logger.i(Logger.DEBUG_TAG, "WatchManager--->analyseAckData() 收到ack,success");
        } else if (result == ACK_FAIL || result == ACK_TIMEOUT ||
                result == ACK_ERROR_HEADER || result == ACK_ERROR_LENGTH) {
            Logger.e(Logger.DEBUG_TAG, "WatchManager--->analyseAckData,ack result fail:" + result);
        }

    }

    /**
     * 解析接收到的20字节数据,新的1024字节包头
     *
     * @param value 包裹在20字节的数据,最多20个字节
     */
    private void new1024PackReceive(byte[] value) {
        int receivedTotalDataIndex = 0;
        int compareToReceivedCheckSum = value[2] ^ value[3] ^ value[4] ^ value[5];//length ^ serial number ^ cmd type ^ data
        //下标2、3保存的length包含cmd type(1字节,下标5),serial number(1字节,下标4),data(n字节,下标6开始),checksum(1字节,最后)
        int length = unsignedBytesToInt(value[3], value[2]);
        int receivedDataSerialNum = value[4];//serial number
        int receivedTotalDataLength = length - 3;//减去cmd type、serial number、checksum 3字节
        byte[] receivedTotalData = new byte[receivedTotalDataLength > 0 ? receivedTotalDataLength : 1024];//缓冲大小最大为1024字节
        Logger.i(Logger.DEBUG_TAG, "new1024PackReceive receivedTotalDataLength:"+receivedTotalDataLength);
        watch1024ReceivedTempData = new Watch1024ReceivedTempData(receivedDataSerialNum, ACK_NOT_SEND, receivedTotalData);
        watch1024ReceivedTempData.setDataTotalLength(receivedTotalDataLength);
        if (receivedTotalDataLength > 13) {//多于一个包
            for (int i = 0; i < 14; i++) {
                receivedTotalData[receivedTotalDataIndex + i] = value[6 + i];
                compareToReceivedCheckSum = compareToReceivedCheckSum ^ value[6 + i];
            }
            receivedTotalDataIndex += 14;
            watch1024ReceivedTempData.setCheckSum(compareToReceivedCheckSum);
            watch1024ReceivedTempData.setReceivedPos(receivedTotalDataIndex);
            getWatchManagerHandler().sendEmptyMessageDelayed(MSG_COUNT_DOWN_RECEIVING, 1000);//倒计时

        } else {//一个包
            for (int i = 0; i < receivedTotalDataLength; i++) {
                receivedTotalData[receivedTotalDataIndex + i] = value[6 + i];
                compareToReceivedCheckSum = compareToReceivedCheckSum ^ value[6 + i];
            }
            receivedTotalDataIndex += receivedTotalDataLength;
            watch1024ReceivedTempData.setCheckSum(compareToReceivedCheckSum);
            watch1024ReceivedTempData.setReceivedPos(receivedTotalDataIndex);

            if (value[value.length - 1] == compareToReceivedCheckSum) {
                Logger.i(Logger.DEBUG_TAG, "接收1024成功,小于20字节");
                if (getPack1024SendState() == STATE_SENDING) {
                    watch1024ReceivedTempData.setAckCmd(ACK_SUCCESS);
                    getWaitSendAckQueue().offer(watch1024ReceivedTempData);
                } else {
                    watch1024ReceivedTempData.setAckCmd(ACK_SUCCESS);
                    sendAckCmd(watch1024ReceivedTempData, false);
                }
            } else {
                Logger.e(Logger.DEBUG_TAG, "接收1024失败,小于20字节");
                if (getPack1024SendState() == STATE_SENDING) {
                    watch1024ReceivedTempData.setAckCmd(ACK_ERROR_LENGTH);
                    getWaitSendAckQueue().offer(watch1024ReceivedTempData);
                } else {
                    watch1024ReceivedTempData.setAckCmd(ACK_ERROR_LENGTH);
                    sendAckCmd(watch1024ReceivedTempData, false);
                }
            }
        }
        Logger.i(Logger.DEBUG_TAG, "WatchManager-->new1024PackReceive");
    }

    /**
     * 解析接收到的20字节数据,1024字节包余下部分
     *
     * @param value 包裹在20字节的数据,最多20字节
     */
    private void rest1024PackReceive(byte[] value) {
        if (watch1024ReceivedTempData == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchManager--->rest1024PackReceive(),receivedTotalData == null");
            return;
        }
        int receivedTotalDataIndex = watch1024ReceivedTempData.getReceivedPos();
        int receivedTotalDataLength = watch1024ReceivedTempData.getDataTotalLength();
        int compareToReceivedCheckSum = watch1024ReceivedTempData.getCheckSum();
        if (receivedTotalDataIndex + value.length <= receivedTotalDataLength) {//中间包,data.length默认为20
            for (int i = 0; i < value.length; i++) {
                watch1024ReceivedTempData.getReceived1024Data()[receivedTotalDataIndex + i] = value[i];
                compareToReceivedCheckSum = compareToReceivedCheckSum ^ value[i];
            }
            receivedTotalDataIndex += value.length;
            watch1024ReceivedTempData.setCheckSum(compareToReceivedCheckSum);
            watch1024ReceivedTempData.setReceivedPos(receivedTotalDataIndex);
        } else {//尾包
            //1.移除开始接收数据包后,规定时间内必须全部数据包接收完毕消息
            getWatchManagerHandler().removeMessages(MSG_COUNT_DOWN_RECEIVING);

            for (int i = 0; i < value.length - 1; i++) {//减去最后一位checkSum
                watch1024ReceivedTempData.getReceived1024Data()[receivedTotalDataIndex + i] = value[i];
                compareToReceivedCheckSum = compareToReceivedCheckSum ^ value[i];
            }
            receivedTotalDataIndex += value.length;
            watch1024ReceivedTempData.setCheckSum(compareToReceivedCheckSum);
            watch1024ReceivedTempData.setReceivedPos(receivedTotalDataIndex);

            boolean receive1024Success;
            if (value[value.length - 1] == compareToReceivedCheckSum) {
                receive1024Success = true;
                if (getPack1024SendState() == STATE_SENDING) {//保证每个1024字节包拆分的20字节包是连续的
                    Logger.w(Logger.DEBUG_TAG, "接收1024成功,正在发送1024字节数据中...");
                    watch1024ReceivedTempData.setAckCmd(ACK_SUCCESS);
                    getWaitSendAckQueue().offer(watch1024ReceivedTempData);
                } else {
                    Logger.i(Logger.DEBUG_TAG, "接收1024成功");
                    watch1024ReceivedTempData.setAckCmd(ACK_SUCCESS);
                    sendAckCmd(watch1024ReceivedTempData, false);
                }
            } else {//checkSum出错
                Logger.e(Logger.DEBUG_TAG, "接收1024失败");
                receive1024Success = false;
                if (getPack1024SendState() == STATE_SENDING) {
                    watch1024ReceivedTempData.setAckCmd(ACK_FAIL);
                    getWaitSendAckQueue().offer(watch1024ReceivedTempData);
                } else {
                    watch1024ReceivedTempData.setAckCmd(ACK_FAIL);
                    sendAckCmd(watch1024ReceivedTempData, false);
                }
            }
            Logger.i(Logger.DEBUG_TAG, "WatchManager-->rest1024PackReceive end,receive1024Success:" + receive1024Success);
        }
    }

    /**
     * 接收到手表数据层ack包,清除等待ack包倒计时消息
     */
    public void clearWaitAckState() {
        mWaitAckTime = 0;
        getWatchManagerHandler().removeMessages(MSG_SEND_WAIT_ACK_COUNT_DOWN);
    }

    /**
     * 接收到手表应用层response包,清除等待response包倒计时消息,
     * 并设置当前1024字节包发送状态为STATE_SUCCESS
     */
    public void clearWaitResponseState() {
        mWaitResponseTime = 0;
        getWatchManagerHandler().removeMessages(MSG_WAITING_RESPONSE_COUNT_DOWN);
        setPack1024SendState(STATE_SUCCESS);
    }

    //endregion ================================== 接收 ==================================

    //region ================================== 发送 ==================================

//    /**
//     * ble正在发送数据时,收到数据暂时存下需要发送的ack回应
//     */
//    private byte responseCode = 0x00;
    /**
     * 当前1024字节包发送的状态
     */
    private int pack1024SendState = STATE_SUCCESS;
    /**
     * 发送出去1024，并且收到应用层response回复
     */
    public static final int STATE_SUCCESS = 0;
    /**
     * 数据层正在发送1024数据包
     */
    public static final int STATE_SENDING = 1;
    /**
     * 数据层发送完1024包后等待数据层ack回复
     */
    public static final int STATE_WAITING = 2;
    /**
     * 数据层发送完1024包后收到数据层ack回复,等待应用层response回复
     */
    public static final int STATE_ACK = 3;
    /**
     * 重新发送中
     */
    public static final int STATE_RESENDING = 4;

    /**
     * 获取当前1024字节包发送的状态
     */
    public synchronized int getPack1024SendState() {
        return pack1024SendState;
    }

    /**
     * 设置当前1024字节包发送的状态
     *
     * @param state 当前1024字节包发送的状态 取值参考{@link WatchManager#STATE_SUCCESS} 等
     */
    public synchronized void setPack1024SendState(int state) {
//        Logger.i(Logger.DEBUG_TAG,"WatchManager,setPack1024SendState()");
        pack1024SendState = state;
        if (mWatchManagerCallbacks != null) {
            mWatchManagerCallbacks.data1024SendStateChange(state);
        }
        if (state == STATE_SUCCESS) {
            sendDataCmd();//开启下一个数据发送
        }
    }

    /**
     * BLE层发送最多20个字节的数据包
     *
     * @param data    数据包(硬件限制20字节以内)
     * @param is20Ack 当前20字节内容是否为回应手表数据层的ack数据包
     * @param ifEnd   当前20字节内容是否为1024字节包中的最后20字节包
     */
    private void sendMinPackageData(byte[] data, boolean is20Ack, boolean ifEnd) {
        if (is20Ack)
            Logger.i(Logger.DEBUG_TAG, "WatchManager--->BLE层发送数据包,一次最多20个字节 is20Ack:" + is20Ack + ",ifEnd:" + ifEnd + ",is20Sending:" + is20Sending);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            Logger.d(Logger.DEBUG_TAG, "WatchManager--->BLE层发送数据包,一次最多20个字节 mBluetoothGatt is null:" + (mBluetoothGatt == null));
            if (mBluetoothGatt != null) {
                BluetoothGattService mBluetoothService = mBluetoothGatt.getService(WatchManager.WATCH_SERVICE_UUID);
                Logger.d(Logger.DEBUG_TAG, "WatchManager--->BLE层发送数据包,一次最多20个字节 mBluetoothService is null:" + (mBluetoothService == null)
                        + ",mBluetoothGatt:" + mBluetoothGatt);
                if (mBluetoothService != null) {
                    BluetoothGattCharacteristic cmdCharacteristic = mBluetoothService.getCharacteristic(WatchManager.WATCH_WRITE_CHARACTERISTIC_UUID);
                    Logger.d(Logger.DEBUG_TAG, "WatchManager--->BLE层发送数据包,一次最多20个字节 cmdCharacteristic is null:" + (cmdCharacteristic == null) + ",is20Sending:" + is20Sending);
                    if (cmdCharacteristic != null) {
                        Logger.i(Logger.DEBUG_TAG, "WatchManager--->cmdCharacteristic != null");
                        while (true) {
                            if (!is20Sending) {
                                Logger.i(Logger.DEBUG_TAG, "WatchManager--->is20Sending == false");
                                is20Sending = true;
                                cmdCharacteristic.setValue(data);
                                if (is20Ack) {//为20字节ack
                                    this.is20Ack = is20Ack;
                                    Logger.i(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData(),是ack");
                                } else {
                                    Logger.i(Logger.DEBUG_TAG, "WatchManager--->ifEnd:" + ifEnd);
                                    if (ifEnd) { //不为ack,并且为数据包的最后一个20字节包
                                        if (!justSentLast20Pag) {
                                            Logger.i(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData(),异常");
                                            justSentLast20Pag = true;
                                            mWaitAckTime = 0;//getNowWaitAckSecond().add(0);
                                            getWatchManagerHandler().sendEmptyMessageDelayed(MSG_SEND_WAIT_ACK_COUNT_DOWN, 1000);
                                        } else {
                                            Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData(),异常");
                                        }
                                    }
                                }
                                if (mBluetoothGatt != null) {
                                    boolean writeResult = mBluetoothGatt.writeCharacteristic(cmdCharacteristic);
                                    String log = String.format("WatchManager--->BLE层发送数据包,写入结果:%s,回应手表ack:%s,1024字节包中的最后20字节包:%s,线程id:%s\n", writeResult, is20Ack, ifEnd, Thread.currentThread().getId());
                                    WatchFormatManager.logoutAllByte(log, data);
                                }
                                break;
                            } else {
                                try {
                                    Thread.sleep(1);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    } else {
                        Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData writeCharacteristic is null");
                    }
                } else {
                    Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData mBluetoothService is null");
                }
            } else {
                Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendMinPackageData mBluetoothGatt is null");
                clear();//解决手机断开蓝牙或手表断开蓝牙后不能发送命令或传数据给手表问题,主要是 pack1024SendState是1的问题
            }
        }
    }

    //endregion ================================== 发送 ==================================

    //region ================================== 新版发送 ==================================

    /**
     * 等待发送的数据队列
     */
    private PriorityQueue<Watch1024SendTempData> mSendDataQueue;

    /**
     * 蓝牙线程消息队列是否有Watch1024SendTempData任务,保证蓝牙线程消息队列只有一个Watch1024SendTempData发送任务
     */
    private boolean mMsgQueueHasData;

    /**
     * 获取等待发送的数据队列
     */
    public PriorityQueue<Watch1024SendTempData> getSendDataQueue() {
        if (mSendDataQueue == null) {
            mSendDataQueue = new PriorityQueue<>();//new PriorityQueue<>();
            mMsgQueueHasData = false;
            Logger.e(Logger.DEBUG_TAG, "WatchManager-->getSendDataQueue new new new new!!!");
        }
        return mSendDataQueue;
    }

    /**
     * 当前正在发送的1024字节数据
     */
    private Watch1024SendTempData mSending1024Data;

    /**
     * 根据tag,检测是否是正在发送的1024字节数据包封装,如果是则返回正在发送的1024字节数据包封装,否则返回null
     */
    public Watch1024SendTempData getSending1024Data(int tag) {
        if (mSending1024Data != null) {
            if (mSending1024Data.getTag() == tag) {
                return mSending1024Data;
            }
        }
        return null;
    }

    public Watch1024SendTempData getSending1024Data() {
        if (mSending1024Data != null) {
                return mSending1024Data;
        }
        return null;
    }

    /**
     * 添加要发送的数据到数据队列
     *
     * @param watch1024SendTempData 需要发送给手表的1024字节数据包封装
     */
    public boolean addDataToSendQueue(Watch1024SendTempData watch1024SendTempData) {
        if (watch1024SendTempData == null) {
            return false;
        }

        boolean result = getSendDataQueue().offer(watch1024SendTempData);
        Logger.i(Logger.DEBUG_TAG, "WatchManager-->addDataToSendQueue watch1024SendTempData:"
                + watch1024SendTempData.toString() + ",add success:" + result
                + "\ngetSendDataQueueSize():" + getSendDataQueueSize() + ",getPack1024SendState:" + getPack1024SendState() + ",蓝牙线程：" +
                ThreadManager.getWatchBleThreadHandler().getLooper().getThread().getState());
        if (getPack1024SendState() == WatchManager.STATE_SUCCESS) {
            sendDataCmd();//开启数据发送
        }
        return result;
    }

    /**
     * 获取等待发送数据队列长度
     */
    public int getSendDataQueueSize() {
        return getSendDataQueue().size();
    }

    /**
     * 在单独蓝牙线程池中,依次发送保存在mSendDataQueue的数据包
     */
    private void sendDataCmd() {
        if (mMsgQueueHasData) {//提交任务给蓝牙线程，线程没有干活
            Logger.e(Logger.DEBUG_TAG, "sendDataCmd-->mMsgQueueHasData is true!!!");
            return;
        }
        mMsgQueueHasData = ThreadManager.executeOnWatchBleThread(new Runnable() {
            @Override
            public void run() {
                Logger.d(Logger.DEBUG_TAG, "WatchManager-->sendDataCmd getPack1024SendState():" + getPack1024SendState() + ",thread id:" + Thread.currentThread().getId());
                //需要保证每次发送1024字节前,判断应用层是否允许、数据层是否允许
                if (getPack1024SendState() != WatchManager.STATE_SUCCESS) {
                    while (true) {
                        try {
                            if (getPack1024SendState() != WatchManager.STATE_SUCCESS) {
                                Thread.sleep(300);
                            } else {
                                break;
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (mBluetoothGatt != null) {
                    if (mSendDataQueue != null) {
                        mSending1024Data = mSendDataQueue.poll();
                        if (mSending1024Data != null) {
                            sendDataPart(mSending1024Data);
                        }
                    }

                } else {
                    Logger.e(Logger.DEBUG_TAG, "empty device");
                }
                Logger.e(Logger.DEBUG_TAG, "1024包结束");
                //蓝牙线程消息队列完成发送当前的Watch1024SendTempData
                mMsgQueueHasData = false;
            }
        });
    }

    /**
     * 拆分1024字节数据包成n个20字节包并发送
     *
     * @param watch1024SendTempData 需要发送给手表的1024字节数据包封装
     */
    private void sendDataPart(Watch1024SendTempData watch1024SendTempData) {
        Logger.i(Logger.DEBUG_TAG, "WatchManager--->数据开始封包sendDataPart getPack1024SendState():" + getPack1024SendState()
                + ",watch1024SendTempData:" + watch1024SendTempData.toString());
        //1.设置当前1024字节发送状态为正忙,阻塞后续的1024字节包发送,防止状态失控
        setPack1024SendState(STATE_SENDING);//pack1024SendState = STATE_SENDING;

        byte[] data = watch1024SendTempData.getData();
        writeCharacteristicError = false;
        //2.其它发送数据类型
        int packageNum = 0;
        byte[] dataPart;//需要发送的包（20字节包）
        int tempDataIndex = 0;//需要发送数据包的index
        int sendTotalDataLength = data != null ? data.length : 0;
        byte sendTotalDataCheckSum;

        if (sendTotalDataLength <= 13) {//能够一次性发完
            dataPart = new byte[7 + sendTotalDataLength];//最长为20字节
            dataPart[0] = (byte) 0xaa;
            dataPart[1] = (byte) 0x55;//固定头 0xaa 0x55
            dataPart[2] = (byte) ((3 + sendTotalDataLength) >> 8);
            dataPart[3] = (byte) (3 + sendTotalDataLength);//length = cmd(1字节) + serial number(1字节) + data + checksum (1字节)
            dataPart[4] = (byte) watch1024SendTempData.getPos();//数据层目前没有用到这个信息
            dataPart[5] = (byte) 0x01;//0x01:发送 0x02:接收
            sendTotalDataCheckSum = (byte) (dataPart[2] ^ dataPart[3] ^ dataPart[4] ^ dataPart[5]);
            for (int i = 0; i < sendTotalDataLength; i++) {
                dataPart[6 + i] = data[tempDataIndex + i];
                sendTotalDataCheckSum = (byte) (sendTotalDataCheckSum ^ dataPart[6 + i]);//checkSum
            }
            dataPart[6 + sendTotalDataLength] = sendTotalDataCheckSum;
            sendMinPackageData(dataPart, false, true);
        } else {//超过13个字节，不能一次性发完,即checkSum不能连带第一次发
            //region ================================== 头包 ==================================
            dataPart = new byte[20];//最长为20字节
            dataPart[0] = (byte) 0xaa;
            dataPart[1] = (byte) 0x55;//固定头 0xaa 0x55
            dataPart[2] = (byte) ((3 + sendTotalDataLength) >> 8);
            dataPart[3] = (byte) (3 + sendTotalDataLength);
            dataPart[4] = (byte) watch1024SendTempData.getPos();//数据层目前没有用到这个信息
            dataPart[5] = (byte) 0x01;//0x01:发送数据 0x02:ack回应
            sendTotalDataCheckSum = (byte) (dataPart[2] ^ dataPart[3] ^ dataPart[4] ^ dataPart[5]);

            for (int i = 0; i < 14; i++) {
                dataPart[6 + i] = data[tempDataIndex + i];
                sendTotalDataCheckSum = (byte) (sendTotalDataCheckSum ^ dataPart[6 + i]);//checkSum
            }
            sendMinPackageData(dataPart, false, false);//等待一秒，如果没有收到错误则默认是成功的
            tempDataIndex += 14;
            packageNum++;
            Logger.i(Logger.DEBUG_TAG, "test:头" + packageNum);
            if (writeCharacteristicError) {//如果写特征值出错
                Logger.e(Logger.DEBUG_TAG, "头,writeCharacteristicError");
            }

            //endregion ================================== 头包 ==================================
            //region ================================== 中包 ==================================

            while ((tempDataIndex + 20) <= sendTotalDataLength) {//中间包
                dataPart = new byte[20];
                for (int i = 0; i < 20; i++) {
                    dataPart[i] = data[tempDataIndex + i];
                    sendTotalDataCheckSum = (byte) (sendTotalDataCheckSum ^ dataPart[i]);//checkSum
                }
                sendMinPackageData(dataPart, false, false);
                tempDataIndex += 20;
                packageNum++;
                Logger.i(Logger.DEBUG_TAG, "test:中" + packageNum);
                if (writeCharacteristicError) {//如果写特征值出错
                    Logger.e(Logger.DEBUG_TAG, "中,writeCharacteristicError");
                    break;
                }
            }

            //endregion ================================== 中包 ==================================
            //region ================================== 尾包 ==================================
            dataPart = new byte[1 + sendTotalDataLength - tempDataIndex];
            for (int i = 0; i < sendTotalDataLength - tempDataIndex; i++) {
                dataPart[i] = data[tempDataIndex + i];
                sendTotalDataCheckSum = (byte) (sendTotalDataCheckSum ^ dataPart[i]);//checkSum
            }
            dataPart[sendTotalDataLength - tempDataIndex] = sendTotalDataCheckSum;//发送checkSum
            sendMinPackageData(dataPart, false, true);
            packageNum++;
            Logger.i(Logger.DEBUG_TAG, "test:尾" + packageNum);
            if (writeCharacteristicError) {//如果写特征值出错
                Logger.e(Logger.DEBUG_TAG, "尾,writeCharacteristicError");
            }
            //endregion ================================== 尾包 ==================================
        }

        //发送完成,加入等待回应列表
//        if (watch1024SendTempData.isWaitForResponse()) {
//            getWaitResponseLinkedList().offer(watch1024SendTempData);
//        }

        //处理(收到手表发来的数据需要回发ack包,但是由于BLE处于正在发送状态,而)延期的ack包
        if (getWaitSendAckQueue().size() > 0) {
            Watch1024ReceivedTempData tempData = getWaitSendAckQueue().poll();
            sendAckCmd(tempData, false);
        }
    }

    /**
     * 每接收到一个最多1024字节数据后,向手表发送ack回应包
     *
     * @param receivedTempData 接收到的1024字节数据包情况
     * @param isResend         是否是由于ack发送失败进行重发
     */
    public void sendAckCmd(final Watch1024ReceivedTempData receivedTempData, boolean isResend) {
        if (receivedTempData == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendAckCmd(),receivedTempData is null..");
            return;
        }

        if (receivedTempData.getReceived1024Data() == null) {
            Logger.e(Logger.DEBUG_TAG, "sendAckCmd(),receivedTotalData == null");
            return;
        }

        if (isResend) {//失败重发
            if (sendAckTimes >= MAX_SEND_ACK_TIMES) {
                Logger.e(Logger.DEBUG_TAG, "WatchManager--->sendAckCmd(),重发次数达到最大,不再进行重发");
                return;
            }
        } else {
            sendAckTimes = 0;
        }

        final int receivedDataSerialNum = receivedTempData.getReceivedDataSerialNum();
        getTempReceivedDataQueue().offer(receivedTempData);//保存

        ThreadManager.executeOnWatchBleThread(new Runnable() {
            @Override
            public void run() {
                byte[] data = new byte[8];//最长为20字节
                data[0] = (byte) 0xaa;
                data[1] = (byte) 0x55;
                data[2] = (byte) (4 >> 8);
                data[3] = (byte) (4);
                data[4] = (byte) receivedDataSerialNum;//目前没有实际用途
                data[5] = (byte) 0x02;//cmd type 1:发送数据,2:ack回应
                data[6] = receivedTempData.getAckCmd();//ack回应内容
                data[7] = (byte) (data[2] ^ data[3] ^ data[4] ^ data[5] ^ data[6]);//checksum
                sendMinPackageData(data, true, true);

                WatchFormatManager.logoutAllByte("WatchManager--->sendAckCmd() 目前的1024size:" + getTempReceivedDataQueue().size()
                                + ",还需要发送ack的数量:" + getWaitSendAckQueue().size() + ",thread id:" + Thread.currentThread().getId() + "\n"
                        , receivedTempData.getReceived1024Data());
            }
        });

    }

//    /**
//     * 发送手机是android标识
//     */
//    public void sendAndroidFlag() {
//        byte[] data = new byte[6];
//        data[0] = 1;
//        data[1] = 2;
//        data[2] = 3;
//        data[3] = 4;
//        data[4] = 5;
//        data[5] = 6;
//        sendMinPackageData(data, false, true);
//    }

    //endregion ================================== 新版发送 ==================================


}
