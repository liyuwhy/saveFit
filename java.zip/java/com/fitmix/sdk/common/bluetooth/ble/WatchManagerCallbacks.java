package com.fitmix.sdk.common.bluetooth.ble;

/**
 * 手表BLE事件回调,包括BLE底层事件回调(如蓝牙连接状态、服务发现回调、绑定状态等)以及应用层数据分析(如1024字节包的解析等)
 */

public interface WatchManagerCallbacks extends BleManagerCallbacks {

    /**
     * 当前发送1024字节包的状态更改
     *
     * @param state 参考{@link WatchManager#STATE_SUCCESS }等
     */
    void data1024SendStateChange(int state);

    /**
     * 成功接收手表发来的1024包
     *
     * @param receivedTotalData 收到的有意义的字节数组
     */
    void receive1024DataSuccess(byte[] receivedTotalData);

}
