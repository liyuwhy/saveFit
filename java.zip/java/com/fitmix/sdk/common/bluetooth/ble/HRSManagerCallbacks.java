/*
 * Copyright (c) 2015, Nordic Semiconductor
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.fitmix.sdk.common.bluetooth.ble;


public interface HRSManagerCallbacks extends BleManagerCallbacks {

    /**
     * Called when the sensor position information has been obtained from the sensor
     *
     * @param position the sensor position
     */
    void onHRSensorPositionFound(String position);

    /**
     * Called when new Heart Rate value has been obtained from the sensor
     *
     * @param value the new value
     */
    void onHRValueReceived(int value);

    /**
     * 耳机是否脱落及信号强度
     *
     * @param ifDrop      是否脱落
     * @param signalValue 信号强度
     */
    void onSignalValueReceived(boolean ifDrop, int signalValue);

    /**
     * 按键消息接收通知
     *
     * @param btnType 按键类型 0：耳机侧面心率按键，1：线控板的F按键
     * @param msgType 消息类型 0：单击，1：双击，2：单击并长按，3：长按，4：长按（或单击并长按）抬起
     */
    void onPushBtnReceived(int btnType, int msgType);

    //	/**	当发送心率耳机消息指令成功后执行的方法
//	 */
//	void onCmdSendSuccess();

    /**
     * 从心率耳机接收到的心率统计值
     *
     * @param avgHr 平均心率值
     * @param minHr 最小心率值
     * @param maxHr 最大心率值
     */
    void onLAVAHRReceive(int avgHr, int minHr, int maxHr);

    /**
     * 从心率耳机接收到的运动数据
     *
     * @param sportMode   运动模式 0：autonomous mode，1：Running，2：Low HR，3：Cycling，4：Weights & Sports，5：Aerobics，6：Lifestyle，默认：1（Running）
     * @param stepBPM     当前步频(步/分钟)
     * @param distance    运动距离,单位为米
     * @param totalStep   总步数
     * @param speed       当前速度,单位 0.01千米/小时
     * @param vo2         当前摄氧量,单位10ml/kg/min
     * @param calBurnRate 卡路里燃烧率,单位千卡/小时
     * @param totalCal    总卡路里,单位千卡
     * @param maxVo2      最大摄氧量,单位10ml/kg/min
     */
    void onSportDataReceive(int sportMode, int stepBPM, int distance, int totalStep, int speed, int vo2, int calBurnRate, int totalCal, int maxVo2);

    /**
     * 从心率耳机接收到的固件版本值
     *
     * @param firmwareVersion 固件版本值
     */
    void onHRFirmware(String firmwareVersion);
}
