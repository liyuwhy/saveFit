package com.fitmix.sdk.common.bluetooth;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothProfile.ServiceListener;

import java.lang.reflect.Method;
import java.util.List;

/**
 * 蓝牙A2DP连接监听
 */
public class ConnServListener implements ServiceListener {

    private BluetoothDevice mBluetoothDevice;
    private BluetoothA2dp mBluetoothHeadset;
    private boolean isMeConnected = false;
    //	private final String TAG = "fitmix";
    private int mConnectedCount;
    private String mNameFlag;
    private String mBTAddress;

    /**
     * @param btDevice 蓝牙设备
     */
    public ConnServListener(BluetoothDevice btDevice) {
        setDevice(btDevice);
        if (mBluetoothDevice != null)
            mBTAddress = btDevice.getAddress();
        isMeConnected = false;
        mConnectedCount = 0;
    }

    public void setDevice(BluetoothDevice btDevice) {
        mBluetoothDevice = btDevice;
    }

    public BluetoothDevice getDevice() {
        return mBluetoothDevice;
    }

    public BluetoothA2dp getBluetoothheadset() {
        return mBluetoothHeadset;
    }

    private void unpairDevice(BluetoothDevice device) {
        if (device == null)
            return;
        if (device.getAddress().isEmpty())
            return;
//		Log.d(TAG, "ConnServListener reconnect:" + device.getAddress());
        if (device.getBondState() != BluetoothDevice.BOND_BONDED)
            return;
        try {
//			Log.d(TAG, "unpairDevice removeBond");
            Method m = device.getClass().getMethod("removeBond");
            m.invoke(device);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createBond(BluetoothDevice device) {
        if (device == null)
            return;
        if (device.getAddress().isEmpty())
            return;
        if (device.getBondState() != BluetoothDevice.BOND_NONE)
            return;
        try {
//			Log.d(TAG, "createBond:" + device.getBondState());

            Method m = device.getClass().getMethod("createBond");
            m.invoke(device);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reconnect(BluetoothDevice device) {
        if (device == null)
            return;
        if (device.getAddress().isEmpty())
            return;

//		Log.d(TAG, "ConnServListener reconnect:" + device.getAddress() + ","
//				+ device.getBondState());
        if (device.getBondState() != BluetoothDevice.BOND_BONDED)
            return;
        try {
//			Log.d(TAG, "reconnect connect:" + device.getBondState());
            Method m = mBluetoothHeadset.getClass().getMethod("connect",
                    BluetoothDevice.class);
            m.invoke(mBluetoothHeadset, device);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkIsMeConnected() {
        boolean bConnected = false;
        mConnectedCount = 0;
        List<BluetoothDevice> cd = mBluetoothHeadset.getConnectedDevices();
        if (cd != null) {
//			Log.d(TAG, "ConnectedDevices count: " + cd.size());
            mConnectedCount = cd.size();
            for (int i = 0; i < cd.size(); i++) {
                BluetoothDevice t = cd.get(i);
//				Log.d(TAG,
//						"ConnectedDevices : " + t.getName() + "|"
//								+ t.getAddress());
                if ((mBTAddress != null) && (!mBTAddress.isEmpty())) {
                    if (t.getAddress().compareToIgnoreCase(mBTAddress) == 0)
                        bConnected = true;
                } else if ((mNameFlag != null) && (!mNameFlag.isEmpty())) {
                    if (t.getName().startsWith(mNameFlag)) {
                        bConnected = true;
                        mBTAddress = t.getAddress();
                    }
                }

            }
        }
        return bConnected;
    }

    public String getBtAddress() {
        return mBTAddress;
    }

    public void setNameFlag(String sNameFlag) {
        mNameFlag = sNameFlag;
    }

    public boolean isConnected() {
        return isMeConnected;
    }

    public int getConnectedCount() {
        return mConnectedCount;
    }

    public void autoConnectMyDevice() {
        if (isMeConnected || (mBluetoothDevice == null))
            return;
        createBond(mBluetoothDevice);
        if (mBluetoothDevice.getBondState() != BluetoothDevice.BOND_BONDED) return;
        reconnect(mBluetoothDevice);
        mConnectedCount += 1;
        isMeConnected = true;
    }

    public void clearConnectedCount() {
        mConnectedCount = 0;
    }

    public void disconnectMyDevice() {
        if ((!isMeConnected) || (mBluetoothDevice == null))
            return;
        unpairDevice(mBluetoothDevice);
        isMeConnected = false;
        mConnectedCount = 0;
    }

    public void disconnectOtherDevice() {

        List<BluetoothDevice> cd = mBluetoothHeadset.getConnectedDevices();
        if (cd != null) {
            for (int i = 0; i < cd.size(); i++) {
                BluetoothDevice t = cd.get(i);
                unpairDevice(t);
            }
            mConnectedCount = 0;
        }

    }

    @Override
    public void onServiceConnected(int profile, BluetoothProfile proxy) {
        if (proxy == null)
            return;
        if (isMeConnected) return;
        mBluetoothHeadset = (BluetoothA2dp) proxy;
        isMeConnected = checkIsMeConnected();
//		Log.d(TAG, "isMeConnected:" + isMeConnected + ", count: "
//				+ mConnectedCount);
        if (!isMeConnected) {
            if (mConnectedCount > 0)
                return;
            autoConnectMyDevice();
        }
    }

    @Override
    public void onServiceDisconnected(int arg0) {
        mConnectedCount = 0;
//		Log.d(TAG, "ConnServListener onServiceDisconnected");
    }

}
