package com.fitmix.sdk.common.bluetooth.skip;

import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.text.TextUtils;

import com.actions.ibluz.factory.IBluzDevice;
import com.actions.ibluz.manager.BluzManager;
import com.actions.ibluz.manager.BluzManagerData;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.bean.SkipNumberInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.SumSkipRope;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SkipInfo;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.activity.SkipMainActivity;

import java.io.File;
import java.io.FileWriter;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

/**
 * 跳绳蓝牙操作Service,负责蓝牙连接、断开、传输数据等处理
 */
public class SkipBluetoothService extends Service {

    /**
     * SkipService 名称
     */
    public static final String SERVICE_NAME = SkipBluetoothService.class.getName();

    //region ================================== Service生命周期相关 ==================================

    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        public SkipBluetoothService getService() {
            return SkipBluetoothService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService--->onCreate()");
        //setBluzConnector();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

//    @Override
//    public void onLowMemory() {
//        super.onLowMemory();
//        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
//        am.getMemoryInfo(mi);
//    }

    @Override
    public void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --- > onDestroy()");
        super.onDestroy();
        releaseBluz();
    }

    private void releaseBluz() {
        if (myHandler != null) {
            myHandler.removeCallbacksAndMessages(null);
        }
        myHandler = null;

        if (mBluzManager != null) {
            mBluzManager.release();
        }

        if (mBluzConnector != null) {
            mBluzConnector.release();
            mBluzConnector.releaseA2dp();
        }
        mBluzManager = null;
        mBluzConnector = null;
        mConnectState = null;
        a2dpListener = null;
        if (mOnIBluzDeviceConnectionListeners != null) {
            mOnIBluzDeviceConnectionListeners.clear();
            mOnIBluzDeviceConnectionListeners = null;
        }
        mOnIBluzDeviceA2dpConnectionListener = null;

        if (mOnCustomCommandListeners != null) {
            mOnCustomCommandListeners.clear();
            mOnCustomCommandListeners = null;
        }
    }

    //endregion ================================== Service生命周期相关 ==================================

    //region ================================== 跳绳蓝牙相关 ==================================
    /**
     * 防止重复进入跳绳主界面
     */
    private boolean skipping;

    /**
     * 获取蓝牙连接状态
     *
     * @return ConnectionState
     */
    public ConnectionState getConnectState() {
        if (mConnectState == null)
            mConnectState = new ConnectionState();
        return mConnectState;
    }

    private BluzConnector mBluzConnector;
    private BluzManager mBluzManager;
    /**
     * 蓝牙连接状态
     */
    private ConnectionState mConnectState;
    /**
     * service之外用于监听a2dp连接状态
     */
    private com.actions.ibluz.b.h a2dpListener;
    /**
     * service用于监听a2dp连接状态
     */
    private com.actions.ibluz.b.h mOnIBluzDeviceA2dpConnectionListener;
    /**
     * 跳绳数据返回给app的回调
     */
    private List<WeakReference<OnCustomCommandListener>> mOnCustomCommandListeners;
    /**
     * service用于监听数据连接状态
     */
    private List<WeakReference<OnIBluzDeviceConnectionListener>> mOnIBluzDeviceConnectionListeners;

    //region ================================== 蓝牙数据连接相关 ==================================

    /**
     * 获取数据连接蓝牙设备
     *
     * @return BluetoothDevice
     */
    public BluetoothDevice getSkipSppConnectDevice() {
        BluetoothDevice bluetoothDevice = null;
        if (mBluzConnector != null) {
            bluetoothDevice = mBluzConnector.getConnectedDevice();
        }
        return bluetoothDevice;
    }

    /**
     * 蓝牙连接状态回调监听接口
     */
    public interface OnIBluzDeviceConnectionListener {
        /**
         * 蓝牙连接
         *
         * @param device 蓝牙设备信息
         */
        void onConnected(BluetoothDevice device);

        /**
         * 蓝牙断开连接
         *
         * @param device 蓝牙设备信息
         */
        void onDisconnected(BluetoothDevice device);
    }

    /**
     * 蓝牙数据回调接口
     */
    public interface OnCustomCommandListener {
        /**
         * @param btConnectStatus 蓝牙连接状态
         * @param command         命令  cmd (8bit) + Status (8bit) + Reserve (16bit);
         * @param jumpNumber      跳绳个数  Jump_counter (16bit) +  Num_counter(16bit);
         * @param bytes           当前时间 和 偏移时间值
         */
        void onReady(int btConnectStatus, int command, int jumpNumber, byte[] bytes);
    }

    /**
     * 关闭数据连接
     */
    public void disConnectBluetoothDevice() {
        if (mBluzConnector != null) {
            BluetoothDevice bluetoothdevice = mBluzConnector.getConnectedDevice();
            if (bluetoothdevice != null && !TextUtils.isEmpty(bluetoothdevice.getName())) {
                disConnectDevice();
                Logger.e(Logger.DEBUG_TAG, "SkipBluetoothService disConnectBluetoothDevice disConnectDevice!!!");
            } else {
                if (mOnIBluzDeviceConnectionListeners != null && mOnIBluzDeviceConnectionListeners.size() > 0) {
                    for (WeakReference<OnIBluzDeviceConnectionListener> mOnIBluzDeviceConnectionListener : mOnIBluzDeviceConnectionListeners) {
                        if (mOnIBluzDeviceConnectionListener != null) {
                            OnIBluzDeviceConnectionListener onIBluzDeviceConnectionListener = mOnIBluzDeviceConnectionListener.get();
                            if (onIBluzDeviceConnectionListener != null) {
                                onIBluzDeviceConnectionListener.onDisconnected(null);
                            }
                        }
                    }
                }
            }
            getConnectState().setSppState(ConnectionState.SPP_DISCONNECTED);
        }
    }

    /**
     * 数据连接特定的蓝牙设备
     */
    public void connectBluetoothDevice(BluetoothDevice bluetoothdevice) {
        if (mBluzConnector != null) {
            mBluzConnector.connect(bluetoothdevice);
            Logger.d(Logger.DEBUG_TAG, "SkipBluetoothService connectBluetoothDevice!!!");
        }
    }

    /**
     * 断开数据连接
     */
    public void disConnectDevice() {
        if (mBluzConnector != null)
            mBluzConnector.disconnect();
    }

    /**
     * 设置数据连接监听
     */
    public void addOnIBluzDeviceConnectionListener(OnIBluzDeviceConnectionListener listener) {
        if (mOnIBluzDeviceConnectionListeners == null) {
            mOnIBluzDeviceConnectionListeners = new ArrayList<>();
        }
        mOnIBluzDeviceConnectionListeners.add(new WeakReference<>(listener));
    }

    /**
     * 移除数据连接监听
     */
    public void removeOnIBluzDeviceConnectionListener(OnIBluzDeviceConnectionListener listener) {
        if (mOnIBluzDeviceConnectionListeners != null) {
            mOnIBluzDeviceConnectionListeners.remove(new WeakReference<>(listener));
        }
    }

    /**
     * 停止每秒查询跳绳信息/状态 0x82
     */
    public void removeMessage() {
        skipping = true;
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND_SKIP);
    }

    /**
     * 开启每秒查询跳绳信息/状态 0x82
     */
    public void sendMessage() {
        skipping = false;
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND_SKIP);
        getMyHandler().sendEmptyMessage(Config.MSG_REPEAT_EVERY_SECOND_SKIP);
    }

    /**
     * 添加蓝牙数据交互回调监听
     */
    public void addOnCustomCommandListener(OnCustomCommandListener listener) {
        if (mOnCustomCommandListeners == null) {
            mOnCustomCommandListeners = new ArrayList<>();
        }
        mOnCustomCommandListeners.add(new WeakReference<>(listener));
    }

    /**
     * 移除蓝牙数据交互回调监听
     */
    public void removeOnCustomCommandListener(OnCustomCommandListener listener) {
        if (mOnCustomCommandListeners != null) {
            mOnCustomCommandListeners.remove(new WeakReference<>(listener));
        }
    }

    /**
     * 开启跳绳蓝牙连接service
     */
    private void startSkipBluetoothService() {
        Intent i = new Intent(this, SkipBluetoothService.class);
        Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --->  startSkipBluetoothService()");
        startService(i);
    }

    private IBluzDevice.OnConnectionListener mOnConnectionListener = new IBluzDevice.OnConnectionListener() {
        @Override
        public void onConnected(BluetoothDevice device) {
            if (device != null) {
                String deviceName = device.getName();
                if (!TextUtils.isEmpty(deviceName)) {// && deviceName.contains("Geekery Rope")
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --- > mOnConnectionListener --- > onConnected");
                    getConnectState().setSppState(ConnectionState.SPP_CONNECTED);
                    if (mOnIBluzDeviceConnectionListeners != null && mOnIBluzDeviceConnectionListeners.size() > 0) {
                        for (WeakReference<OnIBluzDeviceConnectionListener> mOnIBluzDeviceConnectionListener : mOnIBluzDeviceConnectionListeners) {
                            if (mOnIBluzDeviceConnectionListener != null) {
                                OnIBluzDeviceConnectionListener onIBluzDeviceConnectionListener = mOnIBluzDeviceConnectionListener.get();
                                if (onIBluzDeviceConnectionListener != null) {
                                    onIBluzDeviceConnectionListener.onConnected(device);
                                }
                            }
                        }
                    }
                    setBluzDeviceConnected();
                }
            }
        }

        @Override
        public void onDisconnected(BluetoothDevice device) {
            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --- > mOnConnectionListener --- > onDisconnected");
            getConnectState().setSppState(ConnectionState.SPP_DISCONNECTED);
            if (mOnIBluzDeviceConnectionListeners != null && mOnIBluzDeviceConnectionListeners.size() > 0) {
                for (WeakReference<OnIBluzDeviceConnectionListener> mOnIBluzDeviceConnectionListener : mOnIBluzDeviceConnectionListeners) {
                    if (mOnIBluzDeviceConnectionListener != null) {
                        OnIBluzDeviceConnectionListener onIBluzDeviceConnectionListener = mOnIBluzDeviceConnectionListener.get();
                        if (onIBluzDeviceConnectionListener != null) {
                            onIBluzDeviceConnectionListener.onDisconnected(device);
                        }
                    }
                }
            }
            removeMessage();
            setBluzDeviceDisconnected();
            stopSelf();
        }
    };

    private void setBluzDeviceConnected() {
        createBluzManager();
        startSkipBluetoothService();
    }

    private void setBluzDeviceDisconnected() {
        releaseManager();
    }

    private void releaseManager() {
        if (mBluzManager != null) {
            mBluzManager.release();
            mBluzManager = null;
        }
    }

    /**
     * 创建蓝牙数据传输协议 管理类（第三方封装的jar包）
     */
    public void createBluzManager() {
        if (mBluzConnector == null) {
            mBluzManager = null;
        } else {
            mBluzManager = new BluzManager(this, mBluzConnector, new BluzManagerData.OnManagerReadyListener() {
                @Override
                public void onReady() {
                    if (mBluzManager == null) {
                        return;
                    }
                    mBluzManager.setSystemTime();
                    mBluzManager.setOnCustomCommandListener(new BluzManagerData.OnCustomCommandListener() {
                        @Override
                        public void onReady(int btConnectStatus, int command, int jumpNumber, byte[] bytes) {
                            if (btConnectStatus == SkipCommandHelper.getJumpInfoResultKey(1)) {//在线获得的跳绳数据
                                int cmd = command & 0xff;
                                if (!skipping && cmd == 1) {//开始运动
                                    startSkipMainActivity();
                                }
                            } else if (btConnectStatus == SkipCommandHelper.getJumpInfoResultKey(0)) {//蓝牙已断开
                                processOffLineData(command, jumpNumber, bytes);
                                return;//只在当前处理离线数据
                            }
                            if (mOnCustomCommandListeners != null && mOnCustomCommandListeners.size() > 0) {
                                for (WeakReference<OnCustomCommandListener> mOnCustomCommandListener : mOnCustomCommandListeners) {
                                    if (mOnCustomCommandListener != null) {
                                        OnCustomCommandListener onCustomCommandListener = mOnCustomCommandListener.get();
                                        if (onCustomCommandListener != null) {
                                            onCustomCommandListener.onReady(btConnectStatus, command, jumpNumber, bytes);
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            });
            sendHasOffLineData();
        }
    }

    /**
     * 开始运动
     */
    private void startSkipMainActivity() {
//        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
//        if (sportType != Config.SPORT_TYPE_SKIP) return;//如果不是跳绳运动就不起作用
        //当前在跑步界面的话,不开始
        boolean isRunning = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_RUN_SPORT, false);
        if (isRunning) {
            return;
        }

        Intent intent = new Intent();
        intent.setClass(this, SkipMainActivity.class);
        intent.putExtra("skipping", true);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    //endregion ================================== 蓝牙数据连接相关 ==================================

    // region ================================== 蓝牙音频连接相关 ==================================

    /**
     * 获取音频连接蓝牙设备
     *
     * @return BluetoothDevice
     */
    public BluetoothDevice getSkipA2dpLinkDevice() {
        BluetoothDevice bluetoothDevice = null;
        if (mBluzConnector != null) {
            bluetoothDevice = mBluzConnector.getConnectedA2dpDevice();
        }
        return bluetoothDevice;
    }

    /**
     * 音频连接特定的蓝牙设备
     */
    public void connectBluetoothDeviceByA2dp(BluetoothDevice bluetoothDevice) {
        if (mBluzConnector != null) {
            if (bluetoothDevice != null) {
                mBluzConnector.a2dpConnect(bluetoothDevice, getA2dpConnectLister());
            } else {
                mBluzConnector.a2dpConnect(this, getA2dpConnectLister());
            }
        }
    }

    /**
     * a2dp 连接监听 用于外部回调
     */
    private com.actions.ibluz.b.h getA2dpConnectLister() {
        if (mOnIBluzDeviceA2dpConnectionListener == null) {
            mOnIBluzDeviceA2dpConnectionListener = new com.actions.ibluz.b.h() {
                @Override
                public void a() {
                    if (a2dpListener != null) {
                        a2dpListener.a();
                    }
                }

                @Override
                public void h() {
                    if (a2dpListener != null) {
                        a2dpListener.h();
                    }
                }

                @Override
                public void a(BluetoothDevice device, int state) {
                    if (a2dpListener != null) {
                        a2dpListener.a(device, state);
                    }
                    getConnectState().setA2dpState(state);
                }
            };
        }
        return mOnIBluzDeviceA2dpConnectionListener;
    }

    /**
     * 断开音频连接
     */
    public void disConnectA2dpDevice(BluetoothDevice device) {
        if (mBluzConnector != null) {
            mBluzConnector.a2dpDisconnect(device);
            getConnectState().setA2dpState(ConnectionState.A2DP_DISCONNECTED);
        }
    }

    /**
     * 添加a2dp监听
     */
    public void addOnIBluzDeviceA2dpConnectionListener(com.actions.ibluz.b.h a2dpListener) {
        this.a2dpListener = a2dpListener;
    }

    /**
     * 移除a2dp监听
     */
    public void removeOnIBluzDeviceA2dpConnectionListener() {
        if (this.a2dpListener != null)
            this.a2dpListener = null;
    }

    //endregion ================================== 蓝牙音频连接相关 ==================================

    /**
     * 设置蓝牙连接
     */
    public void setBluzConnector() {
        mBluzConnector = getBluzConnector();
    }

    private BluzConnector getBluzConnector() {
        if (mBluzConnector == null) {
            mBluzConnector = (BluzConnector) BluzDeviceFactory.getDevice(this, "SPP_ONLY");
            if (mBluzConnector != null) {
                mBluzConnector.setOnConnectionListener(mOnConnectionListener);
            }
        }
        return mBluzConnector;
    }

    /**
     * 发现特定的蓝牙设备
     */
    public void discoveryBluetoothDevice(IBluzDevice.OnDiscoveryListener OnDiscoveryListener) {
        if (mBluzConnector != null) {
            mBluzConnector.setOnDiscoveryListener(OnDiscoveryListener);
        }
    }

    /**
     * 开始查找设备
     */
    public void startDiscovery() {
        if (mBluzConnector != null) {
            mBluzConnector.b();
            mBluzConnector.startDiscovery();
        }
    }

    /**
     * 移除查找设备的监听
     */
    public void removeDiscoveryListener() {
        if (mBluzConnector != null) {
            mBluzConnector.c();
            mBluzConnector.setOnDiscoveryListener(null);
        }
    }

    /**
     * 蓝牙是否开启
     */
    public boolean isEnabled() {
        return getBluzConnector().isEnabled();
    }

    /**
     * 向跳绳发送指令
     *
     * @param key  指令的key
     * @param arg1 指令的参数
     */
    public void sendCustomCommand(int key, int arg1) {
        sendCustomCommand(key, arg1, 0, null);
    }

    /**
     * 向跳绳发送指令
     *
     * @param key  指令的key
     * @param arg1 指令的参数1
     * @param arg2 指令的参数2
     * @param obj  指令带的数据
     */
    public void sendCustomCommand(int key, int arg1, int arg2, byte[] obj) {
        if (mBluzManager != null) {
            mBluzManager.sendCustomCommand(key, arg1, arg2, obj);
        }
    }

    //region ================================= 离线跳绳数据处理 =====================================

    /**
     * 自定义handler
     */
    protected static class MyHandler extends WeakHandler {
        public MyHandler(Service SkipBluetoothService) {
            super(SkipBluetoothService);
        }

        public void handleMessage(Message msg) {
            SkipBluetoothService service = (SkipBluetoothService) getReference();
            if (service == null)
                return;
            switch (msg.what) {
                case Config.MSG_SKIP_QUEST_TIMER:
                    service.sendCommandBySteps();
                    break;
                case Config.MSG_REPEAT_EVERY_SECOND_SKIP://每秒刷新一次运动数据
                    service.queryForStartSkip();
                    sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND_SKIP,
                            2000);
                    break;

            }
        }
    }

    private MyHandler myHandler;

    /**
     * 获取Handler,保证不为null
     */
    private MyHandler getMyHandler() {
        if (myHandler == null)
            myHandler = new MyHandler(this);
        return myHandler;
    }

    /**
     * 获取跳绳信息/状态 0x82 不停查询为了自动开始
     */
    private void queryForStartSkip() {
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --->queryForStartSkip()");
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(1), 2);
    }

    private int steps;
    private int connectTimeOutCount = 0;

    /**
     * 处理连接超时
     */
    private void sendCommandBySteps() {
        connectTimeOutCount++;
        if (connectTimeOutCount > 3) {
            getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
            sendGetOffLineDataResult(1);
            return;
        }
        if (steps > 0) {
            switch (steps) {
                case 1:
                    sendHasOffLineData();
                    break;
                case 2:
                    sendGetOffLineData();
                    break;
                case 3:
                    break;
            }
        }
    }

    /**
     * 2秒后调用sendCommandBySteps方法
     *
     * @param steps 后续操作
     */
    private void resetTimer(int steps) {
        this.steps = steps;
        getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
        getMyHandler().sendEmptyMessageDelayed(Config.MSG_SKIP_QUEST_TIMER, 2000);
    }

    /**
     * 获取有没有离线跳绳记录
     */
    private void sendHasOffLineData() {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 1);
        resetTimer(1);
    }

    /**
     * 获取离线的跳绳记录数据
     */
    private void sendGetOffLineData() {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 2);
        resetTimer(2);
    }

    /**
     * 获取记录结果
     *
     * @param type 0 校验成功 1 超时 2 校验失败 3 数据丢包
     */
    private void sendGetOffLineDataResult(int type) {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 3, type, null);
        resetTimer(3);
    }

    /**
     * 当前序列号
     */
    private int currentSerialNumber;
    /**
     * 离线的临时的跳绳记录信息
     */
    private SkipLogInfo currentSkipLogInfo;

    /**
     * 获取离线的临时的跳绳记录信息
     */
    private SkipLogInfo getCurrentSkipLogInfo() {
        if (currentSkipLogInfo == null) {
            currentSkipLogInfo = new SkipLogInfo();
        }
        return currentSkipLogInfo;
    }

    private String getRightString(int number) {
        if (number < 10) {
            return "0" + number;
        } else {
            return String.valueOf(number);
        }
    }

    private long baseTime = -1;
    private int numberCount = -1;
    private int timeSpace = -1;
    private long checkSum = -1;
    private long currentCheck = -1;

    /**
     * 处理获得的离线跳绳记录信息
     *
     * @param command    命令  cmd (8) + Status (8) + Reserve (16);
     * @param jumpNumber 跳绳个数  Jump_counter (16) +  Num_counter(16);
     * @param bytes      当前时间 和 偏移时间值
     */
    private synchronized void processOffLineData(int command, int jumpNumber, byte[] bytes) {
        //Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> processOffLineData() --- > i1 : " + i1);
        if (command == 1 && jumpNumber == 0) {//没有记录停止获取操作
            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 没有记录停止获取操作");
            getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
            sendMessage();
        } else if (command == 1 && jumpNumber > 0) {//如果有未同步跳绳记录
            connectTimeOutCount = 0;
            currentSerialNumber = 0;
            currentSkipLogInfo = null;
            sendGetOffLineData();
        } else if (command == 2) {//获取数据之后
            int serialNumber = jumpNumber & 0x0000ffff;//序列号
            int totalPackageNumber = (jumpNumber >> 16) & 0x0000ffff;//该条记录总包数
            if ((serialNumber - 1) != currentSerialNumber) {
                Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 数据丢包 totalPackageNumber : " + totalPackageNumber + "  serialNumber : " + serialNumber + " currentSerialNumber : " + currentSerialNumber);
                sendGetOffLineDataResult(3);
                return;
            }
            currentSerialNumber = serialNumber;
            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> serialNumber : " + serialNumber + " totalPackageNumber : " + totalPackageNumber);
            if (bytes != null && bytes.length > 0) {
                if (serialNumber == 1) {
                    connectTimeOutCount = 0;
                    int version = bytes[0] & 0xff;
                    timeSpace = bytes[1] & 0xff;
                    int year = bytes[2] & 0xff;
                    int month = bytes[3] & 0xff;
                    int day = bytes[4] & 0xff;
                    int hour = bytes[5] & 0xff;
                    int minute = bytes[6] & 0xff;
                    int second = bytes[7] & 0xff;
                    long jumpTime = (bytes[8] & 0xff) | ((bytes[9] & 0xff) << 8);
                    int jumpCount = (bytes[10] & 0xff) | ((bytes[11] & 0xff) << 8);
                    int dataCount = (bytes[12] & 0xff) | ((bytes[13] & 0xff) << 8);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> version : " + version);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> timeSpace : " + timeSpace);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> year : " + year);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> month : " + month);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> day : " + day);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> hour : " + hour);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> minute : " + minute);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> second : " + second);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> jumpTime : " + jumpTime);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> jumpCount : " + jumpCount);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> dataCount : " + dataCount);
                    if (jumpCount <= 20 && version == 0x64 && timeSpace == 0x05) {//FIXME 当小于20个时不做处理,小心version,timeSpace
                        sendGetOffLineDataResult(0);//校验成功
                        return;
                    }
                    checkSum = bytes[14] & 0xff;
                    //临时校验
                    currentCheck = version ^ timeSpace ^ year ^ month ^ day ^ hour ^ minute ^ second
                            ^ (bytes[8] & 0xff) ^ (bytes[9] & 0xff) ^ (bytes[10] & 0xff) ^ (bytes[11] & 0xff) ^ (bytes[12] & 0xff) ^ (bytes[13] & 0xff);

                    String dateTime = (year + 2000) + "-" + getRightString(month) + "-" + getRightString(day) + " " + getRightString(hour) + ":" + getRightString(minute) + ":" + getRightString(second);
                    try {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());//FIXME yyyy-MM-dd KK:mm:ss
                        Date date = simpleDateFormat.parse(dateTime);
                        baseTime = date.getTime();
                    } catch (Exception e) {
                        baseTime = -1;
                        e.printStackTrace();
                    }
                    if (baseTime < 0) return;

                    getCurrentSkipLogInfo().setStartTime(baseTime);
                    getCurrentSkipLogInfo().setSkipTime(jumpTime * 1000);
                    getCurrentSkipLogInfo().setSkipNumber(jumpCount);
                    getCurrentSkipLogInfo().setUid(UserDataManager.getUid());
                    getCurrentSkipLogInfo().setEndTime(baseTime + jumpTime * 1000);

                    if (dataCount > 0 && currentSkipLogInfo != null) {
                        for (int j = 0; j < (bytes.length - 15); j++) {
                            baseTime = baseTime + timeSpace * 1000;
                            int number = bytes[j + 15] & 0xff;
                            currentCheck = currentCheck ^ number;
                            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --->第" + serialNumber + " 包 第 " + (j + 1) + " 个数据 number : " + number);
                            numberCount = numberCount + number;
                            int bpm = number * 12;
                            getCurrentSkipLogInfo().setCalorie(getCurrentSkipLogInfo().getCalorie() + calculateCalorie(timeSpace * 1000, bpm > 450 ? 450 : bpm));
//                            String text = "第" + serialNumber + " 包 第 " + (j + 1) + " 个数据 number : " + number + " numberCount : " + numberCount;
//                            writeFileWithString(text);
                            saveOffLineDataToDb(numberCount, baseTime, bpm);
                        }
                    }
                } else {
                    if (currentSkipLogInfo != null) {
                        for (int j = 0; j < bytes.length; j++) {
                            baseTime = baseTime + timeSpace * 1000;
                            int number = bytes[j] & 0xff;
                            currentCheck = currentCheck ^ number;
                            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService --->第" + serialNumber + " 包 第 " + (j + 1) + " 个数据 number : " + number);
                            numberCount = numberCount + number;
                            int bpm = number * 12;
                            getCurrentSkipLogInfo().setCalorie(getCurrentSkipLogInfo().getCalorie() + calculateCalorie(timeSpace * 1000, bpm > 450 ? 450 : bpm));
//                            String text = "第" + serialNumber + " 包 第 " + (j + 1) + " 个数据 number : " + number + " numberCount : " + numberCount;
//                            writeFileWithString(text);
                            saveOffLineDataToDb(numberCount, baseTime, bpm);
                        }
                    }
                }
            }
            if (currentSkipLogInfo != null) {
                createFileWithByte(bytes);
                if (serialNumber == totalPackageNumber) {
                    if ((currentCheck ^ checkSum) != 0) {
                        //Toast.makeText(this, "SkipBluetoothService ---> 校验失败", Toast.LENGTH_LONG).show();
                        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> checkSum : " + checkSum + " currentCheck : " + currentCheck);
                        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 校验失败");
//                        String text = "SkipBluetoothService ---> checkSum : " + checkSum + " currentCheck : " + currentCheck;
//                        writeFileWithString(text);
                        sendGetOffLineDataResult(2);//校验失败
                        return;
                    }
                    deleteFile();
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 校验成功");
                    currentSerialNumber = 0;
                    if (currentSkipLogInfo != null) {
                        saveOffLineSkipRecordToDb(getCurrentSkipLogInfo());
                        writeOffLineDataFiles();
                    }
                }
            }
        } else if (command == 3) {//一条记录数据获取完成 之后 再次检查有没有未同步的数据
            Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 一条记录数据获取完成 之后 再次检查有没有未同步的数据");
            sendHasOffLineData();
        } else if (command == 4) {
            if (jumpNumber == 0) {
                //TODO 强制退出获取历史记录
            } else if (jumpNumber == 1) {
                //TODO 获取命令异常 重新获取
            }
        }
    }

    /**
     * 保存离线跳绳信息到数据库表SkipInfo
     *
     * @param skipNumber 跳绳个数
     * @param time       跳绳记录时刻的时间戳,单位毫秒
     * @param bpm        跳频,每分钟个数
     */
    private void saveOffLineDataToDb(int skipNumber, long time, int bpm) {
        SkipInfo skipInfo = new SkipInfo();
        skipInfo.setSkipId(getCurrentSkipLogInfo().getStartTime());
        skipInfo.setSkipNumber(skipNumber);
        if (bpm > 450) bpm = 450;
        skipInfo.setSkipBpm(bpm);
        skipInfo.setTime(time - getCurrentSkipLogInfo().getStartTime());
        skipInfo.setUid(getCurrentSkipLogInfo().getUid());
        SportRecordsHelper.writeSkipInfoSync(this, skipInfo);
    }

    /**
     * 添加或更新跑步记录到数据库
     *
     * @param skipLogInfo 跳绳运动信息
     */
    private void saveOffLineSkipRecordToDb(SkipLogInfo skipLogInfo) {
        if (skipLogInfo == null)
            return;
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> 添加或更新跑步记录到数据库");
        SportRecord sportRecord = new SportRecord(null);
        sportRecord.setUid(skipLogInfo.getUid());//用户Uid
        sportRecord.setStartTime(skipLogInfo.getStartTime());//运动开始时间
        sportRecord.setFlag(1);//运动完成标志
        sportRecord.setType(2);//类型
        sportRecord.setStep(skipLogInfo.getSkipNumber());//运动数量
        sportRecord.setRunTime(skipLogInfo.getSkipTime());//运动时长
        sportRecord.setUploaded(0);//记录未同步
        if (skipLogInfo.getSkipTime() > 60000) {
            sportRecord.setBpm((int) (1.0f * skipLogInfo.getSkipNumber() / (skipLogInfo.getSkipTime() / 60000.0f)));//总的平均BPM
        } else if (skipLogInfo.getSkipTime() > 0) {
            sportRecord.setBpm((int) (skipLogInfo.getSkipNumber() * 60000.0f / skipLogInfo.getSkipTime()));//总的平均BPM
        }
        sportRecord.setEndTime(skipLogInfo.getEndTime());//运动结束时间
        sportRecord.setCalorie((long) skipLogInfo.getCalorie());//运动卡路里
        refreshSkipStatisticsInfo(true);
        SportRecordsHelper.insertOrReplaceSportRecord(this, sportRecord);
    }

    /**
     * 刷新运动总数据(运动时长,卡路里,跳绳个数,距离)
     *
     * @param bAdd 是否增加数量
     */
    private void refreshSkipStatisticsInfo(boolean bAdd) {
        SkipLogInfo skipLogInfo = getCurrentSkipLogInfo();
        if (skipLogInfo == null)
            return;
        if (bAdd) {
            //1.更新在登录接口结果中的个人信息(运动总时长、总消耗、总步数、总距离)
            int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
            int requestId = -1;
            if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
                requestId = UserDataManager.getInstance().generateRequestId(2);
            } else if (loginType == 2) {//表示QQ授权登录
                requestId = UserDataManager.getInstance().generateRequestId(3);
            } else if (loginType == 3) {//表示微信授权登录
                requestId = UserDataManager.getInstance().generateRequestId(5);
            } else if (loginType == 4) {//表示新浪微博授权登录
                requestId = UserDataManager.getInstance().generateRequestId(4);
            }
            if (requestId > 0) {
                DataReqStatus dataReqStatus = DataReqStatusHelper.getInstance().getDataReqStatusById(requestId);
                if (dataReqStatus != null) {
                    String result = dataReqStatus.getResult();
                    Login login = JsonHelper.getObject(result, Login.class);
                    if (login != null && login.getUser() != null) {
                        SumSkipRope sumSkipRope = login.getUser().getSumSkipRope();
                        if (sumSkipRope == null) sumSkipRope = new SumSkipRope();
                        long totalSkipTime = sumSkipRope.getRunTime() + skipLogInfo.getSkipTime();//单位为毫秒 TODO 现在后台给的数值为毫秒值  以后不知道改不改
                        sumSkipRope.setRunTime(totalSkipTime);
                        long totalCalorie = sumSkipRope.getCalorie() + (int) skipLogInfo.getCalorie();
                        sumSkipRope.setCalorie(totalCalorie);
                        long totalSkipNumber = sumSkipRope.getSkipNum() + skipLogInfo.getSkipNumber();
                        sumSkipRope.setSkipNum(totalSkipNumber);
                        login.getUser().setSumSkipRope(sumSkipRope);
                        String newResult = JsonHelper.createJsonString(login);
                        if (!TextUtils.isEmpty(newResult)) {
                            dataReqStatus.setResult(newResult);
                            DataReqStatusHelper.getInstance().updateDataReqStatus(dataReqStatus);
                        }
                    }
                }
            }
        }
    }

    /**
     * 写离线跳绳文件文件
     */
    private void writeOffLineDataFiles() {
        final int uid = UserDataManager.getUid();
        if (currentSkipLogInfo == null) return;
        final long skipId = currentSkipLogInfo.getStartTime();
        if (skipId < 0) {
            return;
        }
        currentSkipLogInfo = null;
        final String skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipId + ".skip";
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> skipFileName : ----1--- " + skipFileName);
        SportRecordsHelper.asyncGetAllSkipInfo(this, uid, skipId, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SkipInfo> skipInfoList = (List<SkipInfo>) operation.getResult();
                if (skipInfoList != null && skipInfoList.size() > 0) {
                    List<SkipNumberInfo> skipNumberInfoList = new ArrayList<>();
                    //数据库跳绳计数信息实体(SkipInfo)转换为跳绳计数信息实体(SkipNumberInfo)
                    for (SkipInfo skipInfo : skipInfoList) {
                        SkipNumberInfo skipNumberInfo = new SkipNumberInfo();
                        skipNumberInfo.setTime(skipInfo.getTime() == null ? 0 : skipInfo.getTime());
                        skipNumberInfo.setBpm(skipInfo.getSkipBpm() == null ? 0 : skipInfo.getSkipBpm());
                        skipNumberInfo.setCount(skipInfo.getSkipNumber() == null ? 0 : skipInfo.getSkipNumber());
                        skipNumberInfo.setHeartRate(skipInfo.getHeartRate() == null ? 0 : skipInfo.getHeartRate());
                        skipNumberInfoList.add(skipNumberInfo);
                    }
                    boolean success = JsonHelper.writeSkipNumberFile(skipFileName, skipNumberInfoList);
                    Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService ---> skipFileName : ----2--- " + skipFileName);
                    if (success) {//写文件成功,删除数据库表记录
                        SportRecordsHelper.deleteSkipInfo(SkipBluetoothService.this, uid, skipId);
                        sendGetOffLineDataResult(0);
                    }
                }
            }
        });
    }

    //endregion ================================= 离线跳绳数据处理 =====================================

    //endregion ================================== 跳绳蓝牙相关 ==================================

    /**
     * 根据byte数组生成文件
     *
     * @param bytes 生成文件用到的byte数组
     */
    private void createFileWithByte(byte[] bytes) {
        /**
         * 创建File对象，其中包含文件所在的目录以及文件的命名
         */
        String text = byteToHexStr(bytes);
        File file = new File(Config.PATH_LOCAL_TEMP,
                getCurrentSkipLogInfo().getStartTime() + ".txt");
        FileWriter writer = null;
        try {
            if (file.exists()) {
                writer = new FileWriter(file, true);
            } else {
                if (file.createNewFile()) {
                    writer = new FileWriter(file);
                }
            }
            if (writer != null) {
                writer.write(text);
                writer.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 根据byte数组生成文件
     */
    private void deleteFile() {
        File file = new File(Config.PATH_LOCAL_TEMP,
                getCurrentSkipLogInfo().getSkipTime() + ".txt");
        // 如果文件存在则删除
        if (file.exists()) {
            file.delete();
        }
    }

    public String byteToHexStr(byte[] bytes) {
        StringBuilder hex = new StringBuilder();
        for (byte aByte : bytes) {
            String j = Integer.toHexString(aByte & 0xFF);
            if (j.length() == 1) {
                j = '0' + j;
            }
            j = " " + j;
            hex.append(j);
        }
        return hex.toString();
    }

    //region ================================== 跳绳参数相关 ==================================
    /**
     * 用户体重,单位为千克
     */
    private int weight = 0;
    /**
     * 用户身高,单位为厘米
     */
    private int height = 0;
    /**
     * 用户性别,int型,1:男,2:女
     */
    private int gender = 0;
    /**
     * 用户年龄,int型
     */
    private int age = 0;


    /**
     * 获取用户体重
     *
     * @return 用户体重, 单位为千克
     */
    public int getWeight() {
        if (weight == 0) {
            weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);
        }
        if (weight == 0) {//数据库表保存了Login接口返回为0的结果时
            weight = Config.USER_DEFAULT_WEIGHT;
        }
        return weight;
    }

    /**
     * 获取用户身高
     *
     * @return 用户身高, 单位为厘米
     */
    public int getHeight() {
        if (height == 0) {
            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        }
        if (height == 0) {//数据库表保存了Login接口返回为0的结果时
            height = Config.USER_DEFAULT_HEIGHT;
        }
        return height;
    }

    /**
     * 获取用户性别
     *
     * @return 用户性别, 1:男,2:女
     */
    public int getGender() {
        if (gender == 0) {
            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        }
        return gender;
    }

    /**
     * 获取用户年龄
     */
    public int getAge() {
        if (age == 0) {
            age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
        }
        return age;
    }

    /**
     * 获取卡路里计算结果
     */
    private double calculateCalorie(long duration, int bpm) {
        double result = FitmixUtil.calculateSkipCalorie(getGender() == Config.GENDER_FEMALE,
                getAge(),
                getWeight(),
                getHeight(),
                duration,
                bpm);
        Logger.i(Logger.DEBUG_TAG, "SkipBluetoothService-->calculateCalorie()--->duration:" + duration + ",bpm: " + bpm + ",卡路里:" + result);
        return result;
    }


    /**
     * 蓝牙连接状态
     */
    public static class ConnectionState {
        public static final int STATE_INIT = 0;

        public static final int A2DP_CONNECTED = 1;
        public static final int A2DP_CONNECTING = 2;
        public static final int A2DP_DISCONNECTED = 3;
        public static final int A2DP_FAILURE = 4;
        public static final int A2DP_PAIRING = 5;

        public static final int SPP_CONNECTED = 11;
        public static final int SPP_CONNECTING = 12;
        public static final int SPP_DISCONNECTED = 13;
        public static final int SPP_FAILURE = 14;
        private int mSppState;
        private int mA2dpState;

        public ConnectionState() {
            mSppState = STATE_INIT;
            mA2dpState = STATE_INIT;
        }

        public int getSppState() {
            return mSppState;
        }

        public void setSppState(int mSppState) {
            this.mSppState = mSppState;
        }

        public int getA2dpState() {
            return mA2dpState;
        }

        public void setA2dpState(int mA2dpState) {
            this.mA2dpState = mA2dpState;
        }
    }

    //endregion ================================== 跳绳参数相关 ==================================
}
