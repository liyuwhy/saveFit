package com.fitmix.sdk.common.bluetooth.skip;

import com.actions.ibluz.manager.BluzManager;
import com.actions.ibluz.manager.BluzManagerData;

/**
 * 跳绳蓝牙命令帮助类
 */
public class SkipCommandHelper {
    /**
     * 返回码
     *
     * @return key 16770
     */
    public static int getLedModeResponseKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.ANS, 0x82);
    }

    /**
     * 设置灯条闪灯模式
     *
     * @return key 21378
     */
    public static int getSetLedModeKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.SET, 0x82);
    }

    /**
     * 获取跳绳所有记录列表
     *
     * @return key 20801
     */
    public static int getJumpLogListKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x41);
    }

    /**
     * 获取跳绳单条记录
     *
     * @return key 20802
     */
    public static int getJumpLogKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x42);
    }

    /**
     * 获取跳绳数据
     *
     * @return key 20820
     */
    public static int getJumpInfoKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x54);
    }

    /**
     * 获取跳绳版本
     *
     * @return key 20870
     */
    public static int getSkipDeviceVersionKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x86);
    }

    /**
     * 获取跳绳版本
     *
     * @return key 16774
     */
    public static int getSkipDeviceVersionResponseKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.ANS, 0x86);
    }

    /**
     * 开始/结束跳绳指令
     *
     * @return key值 21377
     */
    public static int getJumpActionKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.SET, 0x81);
    }

    /**
     * 获取跳绳信息,查询类型
     *
     * @param state 蓝牙连接状态 1 连接 0 未连接
     * @return key state == 1-->20866,state == 0-->20867
     */
    public static int getJumpInfoKey(int state) {
        switch (state) {
            case 0://蓝牙未连接时
                return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x83);
            case 1://蓝牙连接时
                return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x82);
        }
        return BluzManager.buildKey(BluzManagerData.CommandType.QUE, 0x83);
    }

    /**
     * 获取跳绳信息,响应类型
     *
     * @param state 蓝牙连接状态 1 连接 0 未连接
     * @return key 已连接:16770,未连接:16771
     */
    public static int getJumpInfoResultKey(int state) {
        switch (state) {
            case 0://蓝牙未连接时
                return BluzManager.buildKey(BluzManagerData.CommandType.ANS, 0x83);
            case 1://蓝牙连接时
                return BluzManager.buildKey(BluzManagerData.CommandType.ANS, 0x82);
        }
        return BluzManager.buildKey(BluzManagerData.CommandType.ANS, 0x83);
    }

    /**
     * 获取跳绳运动状态命令键值,设置类型
     *
     * @return 跳绳运动状态命令键值 0x87-->21383,结合参数 PARAM 1:运动恢复 2:运动复位
     */
    public static int getJumpStatusKey() {
        return BluzManager.buildKey(BluzManagerData.CommandType.SET, 0x87);
    }

}
