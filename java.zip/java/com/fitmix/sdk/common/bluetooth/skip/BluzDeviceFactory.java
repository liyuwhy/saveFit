//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//
package com.fitmix.sdk.common.bluetooth.skip;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;

import com.actions.ibluz.b.e;

import java.util.UUID;

public class BluzDeviceFactory {
    private static UUID a = null;

//    public BluzDeviceFactory() {
//    }

    public static com.actions.ibluz.b.d getDevice(Context context) {
        return getDevice(context, "SPP");
    }

    public static void setUUID(UUID uuid) {
        a = uuid;
    }

    /**
     * 获取跳绳蓝牙A2DP,数据通道连接帮助类{@link BluzConnector}实例
     *
     * @param context 上下文
     * @param type    蓝牙类型,BLE,SPP,SPP_ONLY
     */
    public static com.actions.ibluz.b.d getDevice(Context context, String type) {
        if (BluetoothAdapter.getDefaultAdapter() == null) {
            return null;
        } else {
            if ("SPP".equals(type)) {
                return new BluzConnector(context, true, a);
            } else if ("BLE".equals(type)) {
                new e(context);
            } else if ("SPP_ONLY".equals(type)) {
                return new BluzConnector(context, false, a);
            }
        }
        return null;
    }

//    public static class ConnectionState {
//        public static final int A2DP_CONNECTED = 1;
//        public static final int A2DP_CONNECTING = 2;
//        public static final int A2DP_DISCONNECTED = 3;
//        public static final int A2DP_FAILURE = 4;
//        public static final int A2DP_PAIRING = 5;
//        public static final int SPP_CONNECTED = 11;
//        public static final int SPP_CONNECTING = 12;
//        public static final int SPP_DISCONNECTED = 13;
//        public static final int SPP_FAILURE = 14;
//
//        public ConnectionState() {
//        }
//    }
//
//    public static class ConnectionType {
//        public static final String SPP = "SPP";
//        public static final String BLE = "BLE";
//        public static final String SPP_ONLY = "SPP_ONLY";
//
//        public ConnectionType() {
//        }
//    }
}
