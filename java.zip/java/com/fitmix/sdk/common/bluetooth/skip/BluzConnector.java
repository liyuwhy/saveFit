package com.fitmix.sdk.common.bluetooth.skip;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Build;

import com.actions.ibluz.b.a;
import com.actions.ibluz.b.c;
import com.fitmix.sdk.common.Logger;

import java.util.UUID;

/**
 * 跳绳蓝牙A2DP,数据通道连接帮助类.
 */
public class BluzConnector extends com.actions.ibluz.b.f {
    private boolean enable;
    protected com.actions.ibluz.b.b a2dpBluz = null;

//    public BluzConnector(Context context, boolean a2dp) {
//        super(context, a2dp);
//    }

    public BluzConnector(Context context, boolean a2dp, UUID uuid) {
        super(context, a2dp, uuid);
    }

    /**
     * 音频通道连接
     *
     * @param device   要音频连接的设备信息
     * @param listener a2dp 连接监听
     */
    public void a2dpConnect(BluetoothDevice device, com.actions.ibluz.b.h listener) {
        if (this.a2dpBluz != null && device != null) {
            this.a2dpBluz.a(listener);
            this.d();
            try {
                this.a2dpBluz.c(device);
            } catch (Exception e) {
                listener.a(device, 4);
            }
        }
    }

    /**
     * 音频通道连接
     *
     * @param context  上下文
     * @param listener a2dp 连接监听
     */
    public void a2dpConnect(Context context, com.actions.ibluz.b.h listener) {
        if (this.a2dpBluz == null) {
            if (Build.VERSION.SDK_INT >= 11) {
                this.a2dpBluz = new a(context);
            } else {
                this.a2dpBluz = new c(context);
            }
        }
        if (this.a2dpBluz != null) {
            this.a2dpBluz.a(listener);
        }
    }

    /**
     * 音频通道断开
     *
     * @param device 要断开音频连接的设备信息
     */
    public void a2dpDisconnect(BluetoothDevice device) {
        Logger.i(Logger.DEBUG_TAG, "BluzConnector --- a2dpDisconnect ---1");
        if (this.a2dpBluz != null) {
            if (device != null) {
                Logger.i(Logger.DEBUG_TAG, "BluzConnector --- a2dpDisconnect --- 2");
                this.a2dpBluz.b(device);
            }
        }
    }

    /**
     * 获取音频连接蓝牙设备
     *
     * @return BluetoothDevice
     */
    public BluetoothDevice getConnectedA2dpDevice() {
        return this.a2dpBluz != null ? this.a2dpBluz.d() : null;
    }

    /**
     * 开启蓝牙设备查找
     */
    public void startDiscovery() {
        if (this.e != null) {
            e = null;
        }
        this.d();
        this.b.startDiscovery();
    }

    /**
     * 释放蓝牙数据通道资源
     */
    public void release() {
        Logger.i(Logger.DEBUG_TAG, "BluzConnector --- release");
        if (this.b != null) {
            this.d();
        }
        if (this.e != null) {
            e = null;
        }
    }

    /**
     * 释放蓝牙音频通道资源
     */
    public void releaseA2dp() {
        if (this.a2dpBluz != null) {
            this.a2dpBluz.g();
        }
    }

    /**
     * 数据通道连接
     */
    public void connect(BluetoothDevice device) {
        if (device != null) {
            if (this.f != null) {
                if (device.equals(this.f)) {
                    Logger.i(Logger.DEBUG_TAG, "BluzConnector --- already connected");
                    return;
                }
                Logger.i(Logger.DEBUG_TAG, "BluzConnector --- replace device");
                this.disconnect();
            } else if (this.e != null && device.equals(this.e) && this.h) {
                Logger.i(Logger.DEBUG_TAG, "BluzConnector --- in connecting");
                return;
            }

            this.h = true;
            this.e = device;
            this.d();
            this.a();
            initA2dp();
        }
    }

    /**
     * 初始化a2dp设备
     */
    private void initA2dp() {
        if (this.a2dpBluz == null) {
            if (Build.VERSION.SDK_INT >= 11) {
                this.a2dpBluz = new a(this.a);
            } else {
                this.a2dpBluz = new c(this.a);
            }
        }
    }

    /**
     * 数据通道断开
     */
    public void disconnect() {
        this.h();
        if (this.e != null) {
            e = null;
        }
    }

    protected void b() {
        super.b();
        enable = true;
    }

    protected void c() {
        if (enable) {
            super.c();
            enable = false;
        }
    }
}
