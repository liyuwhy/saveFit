package com.fitmix.sdk.common;

import com.fitmix.sdk.common.bluetooth.ble.WatchManager;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.Watch1024ReceivedTempData;
import com.fitmix.sdk.watch.bean.Watch1024SendTempData;

import java.util.LinkedList;
import java.util.PriorityQueue;

/*
 *  @creator:   liyu
 *  @createTime:  2018/6/15 15:30
 *  @desc：    TODO
 */
public class MonitorInfoUtil {

    private static MonitorInfoUtil mMonitorInfoUtil = new MonitorInfoUtil();

    public static MonitorInfoUtil getMonitorBleInfoUtil() {
        return mMonitorInfoUtil;
    }

    private volatile  boolean isSendBigData = false;
    private volatile  int bigPackageIndex ;

    WatchManager manager;

    public void startSendBigDataSign(){
        isSendBigData = true;
    }

    public void endSendBigDataSign(){
        isSendBigData = false;
    }

    public void packageIndex(int packageIndex){
        bigPackageIndex = packageIndex;
    }





    public BelInfoBean getBelInfo(){

        if( manager == null){
            return  null;
        }

        Watch1024SendTempData watch1024SendTempData = manager.getSending1024Data();
        int state = manager.getPack1024SendState();
        LinkedList<Watch1024ReceivedTempData> toSendAckQueue =  manager.getWaitSendAckQueue();
        //sendAck 回复后 ----   onWrite 周期内  已经发送回复 还未确认回复成功
        LinkedList<Watch1024ReceivedTempData> temReceviedQueue =  manager.getTempReceivedDataQueue();
        // 发送队列
        PriorityQueue<Watch1024SendTempData> sendTempDataPriorityQueue = manager.getSendDataQueue();
        BelInfoBean belInfoBean =  new BelInfoBean(state,getStateString(manager),sendTempDataPriorityQueue.size(),toSendAckQueue.size());
        belInfoBean.setWaitStr(getWaittingTimeState(manager));
        return belInfoBean;
    }


    public String currentSenderStr(){

        if( manager == null){
            return  "";
        }
        Watch1024SendTempData watch1024SendTempData = manager.getSending1024Data();
        if( watch1024SendTempData == null){
            return "无法获取当前发送状态";
        }

        //1:大文件,2:普通数据,3:response包,4:ack包
        String typeStr = "";
        switch ( watch1024SendTempData.getType() ){
            case 1:
                typeStr = "大文件";
                break;
            case 2:
                typeStr = "普通数据";
                break;
            case 3:
                typeStr = "response 包";
                break;
            case 4:
                typeStr = "ack包";
                break;
        }

        int groupTag = WatchFormatManager.getGroupTagFromTag(watch1024SendTempData.getTag());
        int cell = WatchFormatManager.getCellFromTag(watch1024SendTempData.getTag());

        String str =  String.format("当前发送内容: 类型 %s cell:%d tag:%d fileIndex:%d ",typeStr,cell,groupTag,watch1024SendTempData.getPos() );
        StringBuilder stringBuilder = new StringBuilder(str);
        if(watch1024SendTempData.getType()  == 1 ){
            stringBuilder.append(" packageIndex:"+bigPackageIndex);
        }
        return stringBuilder.toString();
    }

    public String getStateString(WatchManager manager){
        if( manager == null){
            return "无法获取发送状态";
        }

        int state = manager.getPack1024SendState();
        switch ( state){
            case WatchManager.STATE_SUCCESS:
                return "就绪状态(发送出去1024，并且收到应用层response回复)";
            case WatchManager.STATE_SENDING:
                return "正在发送(数据层正在发送1024数据包)";
            case WatchManager.STATE_WAITING:
                return "等待确认回复(数据层发送完1024包后等待数据层ack回复)";
            case WatchManager.STATE_ACK:
                return "等待响应回复(数据层发送完1024包后收到数据层ack回复,等待应用层response回复)";
            case WatchManager.STATE_RESENDING:
                return "重新发送中(重新发送中)";
        }
        return "其它状态";
    }

    public String getWaittingTimeState(WatchManager manager){

        if( manager == null){
            return "无法获取等待状态";
        }
        int ackTime =  manager.mWaitAckTime; // 10 s 超时
        int responseTime =  manager.mWaitResponseTime;  //  30 s
        int receivieTime = manager.timeNowReceiving;  //  10 s

        String str = String.format("等待ack时间: %d/10  等待response时间: %d/30 正在接收: %d /10",
                 ackTime,responseTime,receivieTime);
         return str;
    }



    public  static  class BelInfoBean{

        public  int    state;
        public String stateStr;
        public String waitStr;
        public  int  sendQueueSize;     // 需要发送
        public  int toSendAckQueueSize;// 需要回复队列长度





        public BelInfoBean(int state, String stateStr, int sendQueueSize, int toSendAckQueueSize) {
            this.state = state;
            this.stateStr = stateStr;
            this.sendQueueSize = sendQueueSize;
            this.toSendAckQueueSize = toSendAckQueueSize;
        }


        public void setWaitStr(String waitStr) {
            this.waitStr = waitStr;
        }

        public String toShowStr(){
            StringBuilder sb = new StringBuilder("状态:\n");
            sb.append(state + " --" + stateStr +"\n");
            sb.append("待发送队列长度:"+sendQueueSize+" \n");
            sb.append("接收队列长度:"+toSendAckQueueSize+" \n");
            sb.append("等待状态:"+waitStr+" \n");
            return sb.toString();
        }
    }



}
