package com.fitmix.sdk.common;


import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.download.DownloadStatus;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.common.download.DownloadUploadController;
import com.fitmix.sdk.model.database.CustomAlbumHelper;
import com.fitmix.sdk.model.database.CustomAlbumListHelper;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.DownloadInfoDao;
import com.fitmix.sdk.model.database.DownloadInfoHelper;
import com.fitmix.sdk.model.database.FavoriteMusicHelper;
import com.fitmix.sdk.model.database.LocalMusicHelper;
import com.fitmix.sdk.model.database.MusicInfo;
import com.fitmix.sdk.model.database.MusicInfoHelper;
import com.fitmix.sdk.model.database.PlayingMusicHelper;
import com.fitmix.sdk.model.database.RecentMusicHelper;
import com.fitmix.sdk.view.bean.Album;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.query.QueryBuilder;

public class OperateMusicUtils {
//    private static OperateMusicUtils instance;
//
//    public static OperateMusicUtils getInstance() {
//        if (instance == null) {
//            instance = new OperateMusicUtils();
//        }
//        return instance;
//    }

    /**
     * 通过音乐Id得到数据库中的音乐信息
     *
     * @param musicId 音乐Id
     * @return 音乐信息, 注意空值判断
     */
    public static Music getMusicById(int musicId) {
        return MusicInfoHelper.getInstance().getMusicByID(musicId);
    }

    /**
     * 通过音乐url得到数据库中的音乐信息
     *
     * @param url 音乐url
     * @return Music 音乐信息,注意空值判断
     */
    public static Music getMusicByUrl(String url) {
        return MusicInfoHelper.getInstance().getMusicByUrl(url);
    }


    //region ============================= 下载音乐 =============================

    public static void downloadMusic(final Music music) {
        if (music == null) return;
        DownloadUploadController.getInstance().startDownloadMusic(music);
    }

    //endregion ============================= 下载音乐 =============================

    //region ============================= 收藏音乐 =============================

    /**
     * 在本地收藏或取消收藏音乐
     */
    public static void favoriteSwitchInLocale(Music music) {
        OperateMusicUtils.insertMusic(music, Config.LIST_TYPE_FAVORITE);
    }

    //endregion ============================= 收藏音乐 =============================

    //region =============================添加音乐======================

    /**
     * @param musicList 根据音乐列表类型
     */
    public static boolean insertMusicList(List<Music> musicList, int type) {
        if ((musicList == null) || (musicList.size() <= 0))
            return false;
        for (int i = 0; i < musicList.size(); i++) {
            if (checkMusicExist(musicList.get(i), type))
                continue;
            insertMusic(musicList.get(i), type);
        }
        return true;
    }

    /**
     * 将音乐信息插入数据库表
     *
     * @param music 要插入的音乐信息
     * @param type  要插入的数据库表,取值为:
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_DOWNLOADED}:下载表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_RECENT}:最近播放表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_FAVORITE}:收藏表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_LOCAL}:本地表</p>
     */
    public static void insertMusic(Music music, int type) {
        if (music == null) {
            return;
        }
        switch (type) {
            case Config.LIST_TYPE_DOWNLOADED:
                break;
            case Config.LIST_TYPE_RECENT:
                if (getRecentMusicNumber() > 29) {//如果最近播放数据库条目数大于等于30
                    updateRecentMusicFar(music.getId());
                    break;
                } else {
                    if (checkMusicExist(music, type)) {
                        updateRecentMusic(music.getId());
                    } else {
                        insertRecentMusic(music.getId());
                    }
                }
                break;
            case Config.LIST_TYPE_FAVORITE:
                if (checkMusicExist(music, type)) {//音乐已收藏 执行取消收藏操作
                    deleteFavoriteMusic(music.getId());
                } else {
                    insertFavoriteMusic(music.getId());
                }
                break;
            case Config.LIST_TYPE_LOCAL:
                insertLocalMusic(music.getId());
                break;
            case Config.LIST_TYPE_SCENE:
                insertFitmixMusic(music);
                break;
        }
    }

    //endregion ================================================

    //region =============================删除音乐======================

    /**
     * 删除音乐
     */
    public static void deleteMusic(Music music, int type) {
        if (music == null)
            return;
        switch (type) {
            case Config.LIST_TYPE_DOWNLOADED:
                break;
            case Config.LIST_TYPE_RECENT:
                deleteRecentMusic(music.getId());
                break;
            case Config.LIST_TYPE_FAVORITE:
                deleteFavoriteMusic(music.getId());
                break;
            case Config.LIST_TYPE_LOCAL:
                deleteLocalMusic(music.getId());
                break;
        }
    }

    //endregion ==========================删除音乐======================

    //region =============================检查音乐======================

    /**
     * 检查音乐是否在数据库已存在
     *
     * @param music 要检查的音乐信息
     * @param type  要查看的数据库表,取值为:
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_DOWNLOADED}:下载表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_RECENT}:最近播放表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_FAVORITE}:收藏表</p>
     *              <p>{@link com.fitmix.sdk.Config#LIST_TYPE_LOCAL}:本地表</p>
     * @return boolean true:存在,false:不存在
     */
    public static boolean checkMusicExist(Music music, int type) {
        if (music == null) {
            return false;
        }
        switch (type) {
            case Config.LIST_TYPE_DOWNLOADED:
                return checkMusicIsDownloadedLocal(music);
            case Config.LIST_TYPE_RECENT:
                return RecentMusicHelper.getInstance().checkRecentMusicExist(music.getId());
            case Config.LIST_TYPE_FAVORITE:
                return FavoriteMusicHelper.getInstance().checkFavoriteMusicExist(music.getId());
            case Config.LIST_TYPE_LOCAL:
                return LocalMusicHelper.getInstance().checkLocalMusicExist(music.getId());
            case Config.LIST_TYPE_SCENE:
                return MusicInfoHelper.getInstance().checkFitmixMusicExist(music.getId());
        }
        return false;
    }

//    /**
//     * 检测音乐是否下载(根据Download数据库表检索)
//     */
//    public static boolean checkMusicIsDownloaded(Music music) {
//        if(music == null){
//            return false;
//        }
//        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().queryBuilder();
//        queryBuilder.where(DownloadInfoDao.Properties.RemoteUrl.eq(music.getUrl()));
//        queryBuilder.where(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_COMPLETED));
//        if (queryBuilder.count() > 0) {
//            boolean localExit = FitmixUtil.ifMusicInLocal(music);
//            if (!localExit) {
//                OperateMusicUtils.deleteDownLoadMusic(music, null);
//            } else {
//                return true;
//            }
//        }
//        return false;
//    }

    /**
     * 判断音乐是否下载（根据本地音乐文件夹下逐个对比）
     *
     * @param music
     * @return
     */
    public static boolean checkMusicIsDownloadedLocal(Music music) {
        if (music == null) {
            return false;
        }
        File rootFile = new File(FitmixUtil.getMusicPath());
        if (rootFile != null) {
            File[] files = rootFile.listFiles();// 列出所有文件
            /** 解决bug: Caused by: java.lang.NullPointerException
             *  at com.fitmix.sdk.common.OperateMusicUtils.checkMusicIsDownloadedLocal(OperateMusicUtils.java:234)*/
            if (files != null) {
                for (File file : files) {
                    if (file != null && !TextUtils.isEmpty(file.getName())) {
                        if (file.getName().contains(".") &&
                                String.valueOf(music.getId()).equals(file.getName().substring(0, file.getName().indexOf(".")))) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    //endregion ==========================检查音乐======================

    //region =============================歌单列表======================

    /**
     * 通过专辑的Id查找歌曲列表
     */
    public static List<Music> getMusicByAlbumId(int albumId) {
        return CustomAlbumListHelper.getInstance().getAlbumMusicList(albumId);
    }

    /**
     * 通过专辑的场景查找歌曲列表
     */
    public static List<Music> getMusicByScene(int scene) {
        return MusicInfoHelper.getInstance().getMusicByScene(scene);
    }

    /**
     * 获取自建专辑列表
     */
    public static List<Album> getAlbumList() {
        return CustomAlbumHelper.getInstance().getAlbumList();
    }

    /**
     * 添加自建专辑
     */
    public static void addCustomAlbum(Album album) {
        CustomAlbumHelper.getInstance().insertCustomAlbum(album);
    }

    /**
     * 更新自建专辑信息
     *
     * @param album                  根据专辑
     * @param asyncOperationListener 监听器
     */
    public static void updateCustomAlbum(Album album, AsyncOperationListener asyncOperationListener) {
        CustomAlbumHelper.getInstance().updateCustomAlbum(album, asyncOperationListener);
    }

    /**
     * 删除自建专辑信息
     *
     * @param asyncOperationListener 监听器
     */
    public static void deleteCustomAlbum(int AlbumId, AsyncOperationListener asyncOperationListener) {
        CustomAlbumHelper.getInstance().deleteCustomAlbum(AlbumId, asyncOperationListener);
    }

    /**
     * 在自建专辑中插入歌曲列表
     *
     * @param albumId 专辑ID
     * @param musicId 歌曲ID
     */
    public static void addCustomAlbumList(int albumId, int musicId) {
        CustomAlbumListHelper.getInstance().addMusicInCustomAlbumList(albumId, musicId);
    }

    /**
     * 获取自建专辑的数量
     */
    public static long getAlbumNumber() {
        return CustomAlbumHelper.getInstance().getCustomAlbumNumber();
    }

    /**
     * 获取下一个自建专辑的Id
     */
    public static int getNextLocaleAlbumId() {
        return CustomAlbumHelper.getInstance().getNextLocaleAlbumId();
    }
    //endregion ===================================================

    //region =============================下载歌曲列表======================
    private static DownloadInfoDao getDownloadInfoDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao();
    }

    /**
     * 从DownloadInfo数据库表中搜索已下载完成的音乐列表（由于考虑到版本升级后已下载数据库表为空，因此暂时不用这种方式获取已下载音乐列表）
     *
     * @return
     */
    public static List<Music> getDownloadedMusic() {
        QueryBuilder<DownloadInfo> queryBuilder = getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_COMPLETED),
                DownloadInfoDao.Properties.Type.eq(DownloadType.TYPE_MUSIC))
                .orderDesc(DownloadInfoDao.Properties.DownloadId);
        List<DownloadInfo> downloadInfoList = queryBuilder.list();
        List<Music> listMusic = new ArrayList<>();
        if (downloadInfoList != null && downloadInfoList.size() > 0) {
            for (DownloadInfo downloadinfo : downloadInfoList) {
                Music music = OperateMusicUtils.getMusicByUrl(downloadinfo.getRemoteUrl());
                if (music != null) {
                    listMusic.add(music);
                }
            }
        }
        return listMusic;
    }

    /**
     * 获取本地音乐文件夹已下载完成的音乐信息列表
     */
    public static List<Music> getDownLoadedMusicByLocal() {
        List<Music> list = new ArrayList<>();
        List<String> idList = getLocalMusicIdList();
        for (int i = 0; i < idList.size(); i++) {
            try {
                /**
                 * 解决bug:java.lang.NumberFormatException: Invalid int
                 * */
                int musicId = Integer.parseInt(idList.get(i));
                list.add(MusicInfoHelper.getInstance().getMusicByID(musicId));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return list;
    }

    /**
     * 获取已经下载完成的歌曲数量
     *
     * @return
     */
    public static int getLocalMusicSize() {
        return getLocalMusicIdList().size();
    }

    /**
     * 从本地音乐文件夹获取已下载完成的音乐ID列表
     */
    public static List<String> getLocalMusicIdList() {
        List<String> idList = new ArrayList<>();
        File rootFile = new File(FitmixUtil.getMusicPath());
        if (rootFile != null && rootFile.isDirectory()) {
            File[] files = rootFile.listFiles();//列出所有文件
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        return idList;
                    }
                    if (file.getName() != null && (file.getName().endsWith(".m4a") || file.getName().endsWith(".mp3"))) {
                        try {
                            String musicName = (file.getName().substring(0, file.getName().indexOf(".")));//处理 indexOf = -1问题
                            /**
                             * 解决bug:java.lang.NumberFormatException: Invalid int
                             * */
                            int musicId = Integer.parseInt(musicName);
                            if ((MusicInfoHelper.getInstance().getMusicByID(musicId)) != null) {
                                idList.add(musicName);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        return idList;
    }

    public static Long getDownloadedMusicNumber() {
        QueryBuilder<DownloadInfo> queryBuilder = getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_COMPLETED),
                DownloadInfoDao.Properties.Type.eq(DownloadType.TYPE_MUSIC))
                .orderDesc(DownloadInfoDao.Properties.DownloadId);
        return queryBuilder.count();
    }

    /**
     * 数据库表中删除已下载的歌曲(因为本地无,数据库表DownloadInfo中有,即表示已下载)
     *
     * @param asyncOperationListener 监听器
     */
    public static void deleteDownLoadMusic(Music music, AsyncOperationListener asyncOperationListener) {
        DownloadInfoHelper.asyncDeleteDownloadInfoList(DownloadInfoHelper.getDownloadInfoListByUrl(music.getUrl()), asyncOperationListener);
    }

    /**
     * 删除已下载的歌曲
     */
    public static void deleteDownLoadMusic(Music music) {
        DownloadInfoHelper.asyncDeleteDownloadInfo(DownloadInfoHelper.getDownloadInfoByUrl(music.getUrl()));
    }

    /**
     * 在本地文件夹中删除已下载的歌曲
     */
    public static boolean deleteMusicDownloadedFile(Music music) {
        if (music == null)
            return false;
        String sFilename = getLocalPath(music);
        if (sFilename == null)
            return false;
        File f = new File(sFilename);
        if (f.exists()) {
            return f.delete();
        }
        return false;
    }

    /**
     * 获取歌曲的存储路径
     */
    private static String getLocalPath(Music music) {
        String s = music.getUrl();
        int index = s.lastIndexOf(".");
        if (index == -1) {
            return null;
        }
        String engName = s.substring(index, s.length());
        return Config.PATH_DOWN_MUSIC + music.getId() + engName;
    }

    //endregion ================================================

    //region =============================最近播放列表======================

    /**
     * 插入最近播放的歌曲ID信息
     */
    private static void insertRecentMusic(int musicID) {
        RecentMusicHelper.getInstance().insertRecentMusic(musicID);
    }

    /**
     * 更新最近播放的歌曲ID信息
     */
    private static void updateRecentMusic(int musicID) {
        RecentMusicHelper.getInstance().updateRecentMusic(musicID);
    }

    /**
     * 获取最近播放的歌曲数量
     */
    public static Long getRecentMusicNumber() {
        return RecentMusicHelper.getInstance().getRecentMusicNumber();
    }

    /**
     * 更新播放时间最远的歌曲信息为最近播放的歌曲信息
     */
    private static void updateRecentMusicFar(int musicID) {
        RecentMusicHelper.getInstance().updateRecentMusicFar(musicID);
    }

    /**
     * 删除最近播放歌曲
     */
    public static void deleteRecentMusic(int musicID) {
        RecentMusicHelper.getInstance().deleteRecentMusic(musicID);
    }

    /**
     * 获取最近播放歌曲列表
     */
    public static List<Music> getRecentMusic() {
        return MusicInfoHelper.getInstance().getMusicListByIdList(RecentMusicHelper.getInstance().getRecentMusicIDList());
    }

    //endregion ================================================

    //region =============================收藏歌曲列表======================

    /**
     * 获取收藏歌曲列表
     */
    public static List<Music> getFavoriteMusic() {
        return MusicInfoHelper.getInstance().getMusicListByIdList(FavoriteMusicHelper.getInstance().getFavoriteMusicIDList());
    }

    /**
     * 获取收藏歌曲数目
     */
    public static long getFavoriteMusicNumber() {
        return FavoriteMusicHelper.getInstance().getFavoriteMusicNumber();
    }

    /**
     * 取消收藏
     */
    private static void deleteFavoriteMusic(int musicID) {
        FavoriteMusicHelper.getInstance().deleteFavoriteMusic(musicID);
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(musicID);
        if (musicInfo != null) {
            musicInfo.setCollectCount(musicInfo.getCollectCount() - 1);
            MusicInfoHelper.getInstance().writeMusicInfo(musicInfo);
        }
    }

    /**
     * 收藏歌曲
     */
    private static void insertFavoriteMusic(int musicID) {
        FavoriteMusicHelper.getInstance().insertFavoriteMusic(musicID);
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(musicID);
        if (musicInfo != null) {
            musicInfo.setCollectCount(musicInfo.getCollectCount() + 1);
            MusicInfoHelper.getInstance().writeMusicInfo(musicInfo);
        }
    }

    //endregion ================================================

    //region =============================本地歌曲列表======================

    /**
     * 获取本地歌曲数目
     */
    public static long getLocalMusicNumber() {
        return LocalMusicHelper.getInstance().getLocalMusicNumber();
    }

    /**
     * 获取本地歌曲列表
     */
    public static List<Music> getLocalMusic() {
        return MusicInfoHelper.getInstance().getMusicListByIdList(LocalMusicHelper.getInstance().getLocalMusicIDList());
    }

    /**
     * 插入本地音乐
     */
    private static void insertLocalMusic(int musicID) {
        LocalMusicHelper.getInstance().insertLocalMusic(musicID);
    }

    /**
     * 删除本地音乐
     */
    private static void deleteLocalMusic(int musicID) {
        MusicInfoHelper.getInstance().deleteMusic(musicID);
        LocalMusicHelper.getInstance().deleteLocalMusic(musicID);
    }

    //endregion ================================================

    //region ============================= 正在播放歌曲列表 ======================

    /**
     * 添加音乐列表到数据库播放列表
     */
    public static void setMusicPlayingList(List<Music> musicPlayingList) {
        PlayingMusicHelper.getInstance().setMusicPlayingList(musicPlayingList);
    }

    /**
     * 更新数据库播放列表(PlayingMusic)中音乐播放状态
     *
     * @param music 正在播放的音乐信息
     */
    public static void setPlayingMusic(Music music) {
        if (music == null) return;
        PlayingMusicHelper.getInstance().setPlayingMusic(music);
    }

    /**
     * 更新数据库播放列表(PlayingMusic)中音乐播放状态
     *
     * @param musicId 正在播放的音乐id
     */
    public static void setPlayingMusic(int musicId) {
        PlayingMusicHelper.getInstance().setPlayingMusic(musicId);
    }

    /**
     * 获取正在播放歌曲列表
     */
    public static List<Music> getMusicPlayingList() {
        List<Integer> musicIdList = PlayingMusicHelper.getInstance().getPlayingMusicIdList();
        return MusicInfoHelper.getInstance().getMusicListByIdList(musicIdList);
    }

    /**
     * 获取正在播放歌曲列表,注意返回值为-1的情况
     */
    public static int getIndexInPlayingList() {
        return PlayingMusicHelper.getInstance().getIndexInPlayingList();
    }
    //endregion ================================================

    //region =============================fitmix列表======================

    /**
     * 添加FITMiX歌曲
     *
     * @param music
     */
    private static void insertFitmixMusic(Music music) {
        MusicInfoHelper.getInstance().insertMusic(music);
    }

    /**
     * 通过专辑ID 和 歌曲ID 删除本地歌单中的歌曲
     *
     * @param AlbumID                专辑ID
     * @param musicID                歌曲ID
     * @param asyncOperationListener 监听
     */
    public static void deleteMusicInAlbumList(int AlbumID, int musicID, AsyncOperationListener asyncOperationListener) {
        CustomAlbumListHelper.getInstance().deleteMusicFromAlbum(AlbumID, musicID, asyncOperationListener);
    }

    /**
     * 通过专辑ID 和 歌曲ID 删除本地歌单中的歌曲
     *
     * @param AlbumID 专辑ID
     * @param musicID 歌曲ID
     */
    public static void deleteMusicInAlbumList(int AlbumID, int musicID) {
        CustomAlbumListHelper.getInstance().deleteMusicFromAlbum(AlbumID, musicID);
    }
    //endregion ================================================

}
