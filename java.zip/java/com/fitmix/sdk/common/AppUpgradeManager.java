package com.fitmix.sdk.common;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;

import com.fitmix.sdk.R;
import com.fitmix.sdk.view.activity.BaseActivity;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * APP升级管理
 */
public class AppUpgradeManager {

    private static final int DOWNLOAD = 1;
    private static final int DOWNLOAD_FINISH = 2;
    private String mNewVersionFeature;
    private String downLoadPath = null;
    private String mSavePath;
    private int progress;
    private boolean cancelUpdate = false;
    private Context mContext;


    private MaterialDialog mDownloadDialog;

    private MyHandler mHandler;
    private OnCancelUpgradeListener onCancelUpgradeListener;

    public interface OnCancelUpgradeListener {
        void OnCancelUpgrade();
    }

    public void setOnCancelUpgradeListener(OnCancelUpgradeListener listener) {
        onCancelUpgradeListener = listener;
    }

    private class DownloadApkThread extends Thread {
        @Override
        public void run() {
            try {
                if (Environment.getExternalStorageState().equals(
                        Environment.MEDIA_MOUNTED)) {
                    String sdPath = Environment.getExternalStorageDirectory()
                            + "/";
                    mSavePath = sdPath + "download";
                    URL url = new URL(downLoadPath);

                    HttpURLConnection conn = (HttpURLConnection) url
                            .openConnection();
                    conn.connect();

                    int length = conn.getContentLength();
                    InputStream is = conn.getInputStream();

                    File file = new File(mSavePath);

                    if (!file.exists()) {
                        file.mkdir();
                    }
                    File apkFile = new File(mSavePath, "newVersion.apk");
                    FileOutputStream fos = new FileOutputStream(apkFile);
                    int count = 0;

                    byte buf[] = new byte[1024];

                    do {
                        int numRead = is.read(buf);
                        count += numRead;

                        progress = (int) ((count * 1.0f / length) * 100);

                        mHandler.sendEmptyMessage(DOWNLOAD);
                        if (numRead <= 0) {
                            mHandler.sendEmptyMessage(DOWNLOAD_FINISH);
                            break;
                        }
                        fos.write(buf, 0, numRead);
                    } while (!cancelUpdate);
                    fos.close();
                    is.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            mDownloadDialog.dismiss();

        }
    }

    static class MyHandler extends WeakHandler {
        public MyHandler(AppUpgradeManager manager) {
            super(manager);
        }


        @Override
        public void handleMessage(Message msg) {
            AppUpgradeManager manager = (AppUpgradeManager) getReference();
            if (manager == null) {
                super.handleMessage(msg);
                return;
            }

            switch (msg.what) {
                case DOWNLOAD:
                    if (manager.mDownloadDialog != null)
                        manager.mDownloadDialog.setProgress(manager.progress);
                    break;
                case DOWNLOAD_FINISH:
                    manager.installApk();
                    manager.exitManager();
                    break;
                default:
                    break;
            }
            super.handleMessage(msg);
        }

    }

    /**
     * APP升级管理
     *
     * @param context     上下文
     * @param downloadUrl 新版APP下载Url
     * @param content     升级内容
     */
    public AppUpgradeManager(Context context, String downloadUrl, String content) {
        this.mContext = context;
        this.downLoadPath = downloadUrl;
        mNewVersionFeature = content;
        this.mHandler = new MyHandler(this);
    }

    /**
     * 提示版本升级
     *
     * @param force true:强制升级,false:非强制升级
     */
    public void newVersionPrompt(boolean force) {
        if (force) {
            showNoticeDialogForce();
        } else {
            showNoticeDialog();
        }
    }


    private void downloadApk() {
        new DownloadApkThread().start();
    }

    private void exitManager() {
        Activity activity = (Activity) mContext;
        if ((activity == null) || cancelUpdate) return;
        activity.setResult(Activity.RESULT_CANCELED);
        activity.finish();

    }

    public void installApk() {
        String sdPath = Environment.getExternalStorageDirectory()
                + "/";
        mSavePath = sdPath + "download";
        File apkfile = new File(mSavePath, "newVersion.apk");
        if (!apkfile.exists()) {
            return;
        }

        openAPKFile((Activity) mContext,apkfile.toString());

      /*  Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse("file://" + apkfile.toString()),
                "application/vnd.android.package-archive");
        mContext.startActivity(i);*/
    }



    /**
     * 打开安装包
     *
     * @param mContext
     * @param fileUri
     */
    public void openAPKFile(Activity mContext, String fileUri) {
        // 核心是下面几句代码
        if (null != fileUri) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                File apkFile = new File(fileUri);
                //兼容7.0
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Uri contentUri  = FileProvider.getUriForFile(mContext,
                            mContext.getPackageName() + ".fileProvider",
                            apkFile);
                    intent.setDataAndType(contentUri, "application/vnd.android.package-archive");

              /*      //兼容8.0
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        boolean hasInstallPermission = mContext.getPackageManager().canRequestPackageInstalls();
                        if (!hasInstallPermission) {
                            //ToastUtil.makeText(MyApplication.getContext(), MyApplication.getContext().getString(R.string.string_install_unknow_apk_note), false);
                            startInstallPermissionSettingActivity();
                            return;
                        }
                    }
                    */

                } else {
                    intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                }
                if (mContext.getPackageManager().queryIntentActivities(intent, 0).size() > 0) {
                    mContext.startActivity(intent);
                }
            } catch (Throwable e) {
                e.printStackTrace();
                ((BaseActivity) mContext).showAppMessage(mContext.getString(R.string.activity_upgrade_fial_app),AppMsg.STYLE_INFO );
            }
        }
    }

    /**
     * 跳转到设置-允许安装未知来源-页面
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void startInstallPermissionSettingActivity() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }



    //下载对话框
    private void showDownloadDialog() {
        mDownloadDialog = new MaterialDialog.Builder(mContext)
                .title(R.string.download_app)
                .negativeText(R.string.cancel)
                .progress(false, 100, true)
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                        cancelUpdate = true;
                        if (onCancelUpgradeListener != null)
                            onCancelUpgradeListener.OnCancelUpgrade();
                    }
                })
                .showListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialogInterface) {
                        downloadApk();//开始下载APK文件
                    }
                }).show();

        mDownloadDialog.setCanceledOnTouchOutside(false);
    }

    //新版本提示框
    private void showNoticeDialog() {
        new MaterialDialog.Builder(mContext)
                .title(R.string.new_version_tip)
                .content(mNewVersionFeature)
                .positiveText(R.string.update_now)
                .negativeText(R.string.update_later)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                showDownloadDialog();
                                break;

                            case NEGATIVE://取消下载
                                if (onCancelUpgradeListener != null)
                                    onCancelUpgradeListener.OnCancelUpgrade();
                                break;
                        }
                    }
                }).show();

    }

    //下载对话框
    private void showDownloadDialogForce() {
        mDownloadDialog = new MaterialDialog.Builder(mContext)
                .title(R.string.download_app)
                .negativeText(R.string.exit_app)
                .progress(false, 100, true)
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                        cancelUpdate = true;
                        if (onCancelUpgradeListener != null)
                            onCancelUpgradeListener.OnCancelUpgrade();
                    }
                })
                .showListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialogInterface) {
                        downloadApk();//开始下载APK文件
                    }
                }).show();

        mDownloadDialog.setCanceledOnTouchOutside(false);
    }

    //新版本提示框
    private void showNoticeDialogForce() {
        new MaterialDialog.Builder(mContext)
                .title(R.string.new_version_tip)
                .content(mNewVersionFeature)
                .cancelable(false)
                .positiveText(R.string.update_now)
                .negativeText(R.string.exit_app)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                showDownloadDialogForce();
                                break;

                            case NEGATIVE://取消下载
                                if (onCancelUpgradeListener != null)
                                    onCancelUpgradeListener.OnCancelUpgrade();
                                break;
                        }
                    }
                }).show();

    }

}
