package com.fitmix.sdk.common;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import com.fitmix.sdk.model.database.SettingsHelper;

/*
 *  @creator:   liyu
 *  @createTime:  2018/8/29 13:45
 *  @desc：    蓝牙设备本地缓存 （节省蓝牙搜索步骤）
 */
public class DeviceLocalUtil {

    public static BluetoothDevice  checkLocalDevice(String watchMacAddress){
        Logger.d(Logger.LOG_TAG,"DeviceLocalUtil watchMacAddress" + watchMacAddress);
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        watchMacAddress.toUpperCase();
        if (adapter != null) {
            if( BluetoothAdapter.checkBluetoothAddress(watchMacAddress)){
                return adapter.getRemoteDevice(watchMacAddress);
            }
        }
        return null;
    }

    public static void putDevice2Local(BluetoothDevice device ){
        String deviceStr = JsonHelper.createJsonString(device);
        SettingsHelper.putString("deviceStr",deviceStr);
    }
}
