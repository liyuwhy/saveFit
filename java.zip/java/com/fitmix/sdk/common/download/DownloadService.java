package com.fitmix.sdk.common.download;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.OkHttpUtil;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.DownloadInfoHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import okhttp3.Call;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * 下载上传服务,用于资源文件下载或上传
 */
public class DownloadService extends Service {
    /**
     * 类名
     */
    public static final String NAME = DownloadService.class.getName();
    /**
     * 没有任务时,默认15秒后销毁Service
     */
    private static final long STOP_SELF_DELAY = TimeUnit.SECONDS.toMillis(15L);
    /**
     * 销毁Service任务
     */
    private final Runnable mStopSelfRunnable = new Runnable() {
        @Override
        public void run() {
            Logger.i(Logger.DEBUG_TAG, "DownloadService-->stopSelf");
            stopSelf();
        }
    };

    /**
     * 最大后台线程数
     */
    private final int MAX_THREADS = 2 * FitmixUtil.getPhoneCpuCoreNum();

    /**
     * 指令类型,0表示下载,1表示上传
     */
    public static final String CMD_TYPE = "CMD_TYPE";
    /**
     * 下载命令
     */
    public static final int CMD_DOWNLOAD = 0;
    /**
     * 上传命令
     */
    public static final int CMD_UPLOAD = 1;
    /**
     * 资源文件网络url
     */
    public static final String EXTRA_DOWNLOAD_URL = "download_url";
    /**
     * 文件下载类型,参考 {@link com.fitmix.sdk.common.download.DownloadType}
     */
    public static final String EXTRA_DOWNLOAD_TYPE = "download_type";
    /**
     * 资源文件本地保存的全路径
     */
    public static final String EXTRA_DESTINATION = "download_destination";
    /**
     * 要上传的本地文件全路径
     */
    public static final String EXTRA_UPLOAD_LOCAL = "upload_local";
    /**
     * 要上传的文件的网络保存url
     */
    public static final String EXTRA_UPLOAD_URL = "upload_url";
    /**
     * 要上传的文件的标签,如png,voice等
     */
    public static final String EXTRA_UPLOAD_TAG = "upload_tag";
    /**
     * 线程池
     */
    private ExecutorService mThreadPoolExecutor;
    /**
     * 当前运行的线程数,如果运行的线程数大于最大后台线程数,后续新来的任务需要排队
     */
    private int runningThread = 0;

    /**
     * 同步增加运行线程数
     */
    protected synchronized void runningThreadAdd() {
        runningThread += 1;
        onRunningThreadCountChange();
    }

    /**
     * 同步减少运行线程数
     */
    protected synchronized void runningThreadReduce() {
        runningThread -= 1;
        onRunningThreadCountChange();
    }

    /**
     * 当前运行的线程数变化事件
     */
    private void onRunningThreadCountChange() {
        if (runningThread <= 0) {
            //任务列表中没有等待状态的下载,销毁service
            if (mHandler != null) {
                mHandler.postDelayed(mStopSelfRunnable, STOP_SELF_DELAY);
            }
        }
    }

    /**
     * 当前下载任务列表,远程url为key
     */
    private Map<String, DownloadTask> currentDownLoadTasks;
    /**
     * 当前上传任务列表,本地文件的全路径为key
     */
    private Map<String, UploadTask> currentUploadTasks;
    /**
     * 下载状态监听
     */
    private List<WeakReference<DownloadInfoListener>> downloadListeners;
    /**
     * 上传状态监听
     */
    private List<WeakReference<UploadInfoListener>> uploadListeners;

    /**
     * 文件上传下载消息handler
     */
    public static class MessageHandler extends Handler {
        private WeakReference<DownloadService> mService;

        public MessageHandler(DownloadService service) {
            mService = new WeakReference<>(service);
        }

        @Override
        public void handleMessage(Message msg) {
            DownloadInfo downloadInfo;
            UploadInfo uploadInfo;
            switch (msg.what) {
                //region =================================== 下载消息 ===================================
                case DownloadStatus.STATUS_WAITING://下载等待
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownPrepare(downloadInfo);
                        }
                    }
                    break;
                case DownloadStatus.STATUS_DOWNLOADING://下载中
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownloading(downloadInfo);
                        }
                    }
                    break;
                case DownloadStatus.STATUS_PAUSED://下载暂停
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownPause(downloadInfo);
                        }
                    }
                    break;
                case DownloadStatus.STATUS_COMPLETED://下载完成
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownCompleted(downloadInfo);
                        }
                    }
                    break;
                case DownloadStatus.STATUS_CANCEL://下载取消
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownCancel(downloadInfo);
                        }
                    }
                    break;
                case DownloadStatus.STATUS_FAILED://下载失败
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            int errorCode = msg.arg1;
                            if (errorCode == ApiUtils.HTTP_NETWORK_FAIL) {
                                String e = mService.get().getString(R.string.check_network_out_time);
                                if (!TextUtils.isEmpty(e)) {
                                    downloadService.dispatchDownFail(downloadInfo, e);
                                } else {
                                    downloadService.dispatchDownFail(downloadInfo, "600");
                                }
                            } else if (errorCode == 404) {
                                String e = mService.get().getString(R.string.rsp_error_unknown_error);
                                if (!TextUtils.isEmpty(e)) {
                                    downloadService.dispatchDownFail(downloadInfo, e);
                                } else {
                                    downloadService.dispatchDownFail(downloadInfo, "404");
                                }
                            }
                        }
                    }
                    break;
                case DownloadStatus.STATUS_EXIST://文件已存在
                    downloadInfo = (DownloadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchDownFileExist(downloadInfo);
                        }
                    }
                    break;
                //endregion =================================== 下载消息 ===================================

                //region =================================== 上传消息 ===================================
                case UploadStatus.STATUS_FAIL://上传失败
                    uploadInfo = (UploadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            int errorCode = msg.arg1;
                            downloadService.dispatchUpFail(uploadInfo, errorCode);
                        }
                    }
                    break;

                case UploadStatus.STATUS_SUCCESS://上传成功
                    uploadInfo = (UploadInfo) msg.obj;
                    if (mService != null) {
                        DownloadService downloadService = mService.get();
                        if (downloadService != null) {
                            downloadService.dispatchUpSuccess(uploadInfo);
                        }
                    }
                    break;
                //endregion =================================== 上传消息 ===================================
            }
        }
    }

    private MessageHandler mHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        //创建任务线程池
        if (mThreadPoolExecutor == null) {
            mThreadPoolExecutor = Executors.newFixedThreadPool(MAX_THREADS);
        }

        //初始化
        downloadListeners = new ArrayList<>();
        uploadListeners = new ArrayList<>();
        mHandler = new MessageHandler(this);

        //创建任务列表
        if (currentDownLoadTasks == null) {
            currentDownLoadTasks = new HashMap<>();
            //从数据库中加载所有等待或暂停的下载任务,以倒序排序
            DownloadInfoHelper.getDownloadInfoListAsync(this, DownloadType.TYPE_ALL, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    List<DownloadInfo> downloadInfoList = (List<DownloadInfo>) operation.getResult();
                    if (downloadInfoList != null && downloadInfoList.size() > 0) {
                        for (DownloadInfo downloadInfo : downloadInfoList) {
                            if (downloadInfo != null && !TextUtils.isEmpty(downloadInfo.getRemoteUrl())) {
                                Logger.i(Logger.DEBUG_TAG, "onAsyncOperationCompleted-->downloadInfo.getRemoteUrl():" + downloadInfo.getRemoteUrl());
                                DownloadTask downloadThread = new DownloadTask(downloadInfo);
                                currentDownLoadTasks.put(downloadInfo.getRemoteUrl(), downloadThread);
                            }
                        }
                    }
                }
            });
        }
        if (currentUploadTasks == null) {
            currentUploadTasks = new HashMap<>();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        //当服务被Bind的时候,返回一个带有服务对象的类给Bind服务的Activity
        return new GetServiceClass();
    }

    /**
     * 传递服务对象的类
     */
    public class GetServiceClass extends Binder {
        public DownloadService getService() {
            return DownloadService.this;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mThreadPoolExecutor.shutdown();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            int action = intent.getIntExtra(CMD_TYPE, 0);
            switch (action) {
                case CMD_DOWNLOAD://下载
                    String downloadUrl = intent.getStringExtra(EXTRA_DOWNLOAD_URL);
                    String destination = intent.getStringExtra(EXTRA_DESTINATION);
                    int downloadType = intent.getIntExtra(EXTRA_DOWNLOAD_TYPE, DownloadType.TYPE_FILE);
                    if (!TextUtils.isEmpty(downloadUrl) && !TextUtils.isEmpty(destination)) {
                        String name = FileUtils.getFileName(destination);//获取文件名
                        String localPath = FileUtils.getFolderName(destination);//获取文件夹路径
                        DownloadInfo info = new DownloadInfo(null, localPath, name, downloadUrl, downloadType, DownloadStatus.STATUS_WAITING, 0L, 0L);
                        checkDownloadTask(info, true);
                    }
                    break;

                case CMD_UPLOAD://上传
                    String uploadUrl = intent.getStringExtra(EXTRA_UPLOAD_URL);
                    String local = intent.getStringExtra(EXTRA_UPLOAD_LOCAL);
                    String tag = intent.getStringExtra(EXTRA_UPLOAD_TAG);
                    if (!TextUtils.isEmpty(uploadUrl) && !TextUtils.isEmpty(local)
                            && !TextUtils.isEmpty(tag)) {
                        UploadInfo uploadInfo = new UploadInfo(uploadUrl, local, tag);
                        checkUploadTask(uploadInfo);
                    }
                    break;
            }
        }
        return START_REDELIVER_INTENT;
    }

    //region ============================= 下载与Activity交互 =============================

    /**
     * 根据资源下载的url,本地保存的全路径,文件下载类型创建下载
     *
     * @param context      上下文
     * @param url          资源下载的url,如 http://yyssb.ifitmix.com//1000/fa4f3dd58b4644a5af14293b5550c7ce.m4a
     * @param localPath    资源本地保存全路径,如   /mnt/sdcard/fitmix/Music/2100092.m4a
     * @param downloadType 资源类型,参考 {@link com.fitmix.sdk.common.download.DownloadType }
     */
    public static void makeDownload(Context context, String url, String localPath, int downloadType) {
        if (context == null || TextUtils.isEmpty(url) || TextUtils.isEmpty(localPath))
            return;
        Intent intent = new Intent(context, DownloadService.class);
        intent.putExtra(CMD_TYPE, CMD_DOWNLOAD);
        intent.putExtra(DownloadService.EXTRA_DOWNLOAD_URL, url);
        intent.putExtra(DownloadService.EXTRA_DESTINATION, localPath);
        intent.putExtra(DownloadService.EXTRA_DOWNLOAD_TYPE, downloadType);
        context.startService(intent);
    }

    /**
     * 添加下载信息事件回调
     *
     * @param listener 下载信息事件回调
     */
    public void addDownloadListener(DownloadInfoListener listener) {
        if (downloadListeners == null) {
            downloadListeners = new ArrayList<>();
        }
        downloadListeners.add(new WeakReference<>(listener));
    }

    /**
     * 移除下载信息事件回调
     *
     * @param listener 下载信息事件回调
     */
    public void removeDownloadListener(DownloadInfoListener listener) {
        if (downloadListeners == null) {
            return;
        }
        downloadListeners.remove(new WeakReference<>(listener));
    }

    /**
     * 获取资源下载状态
     *
     * @param url 资源文件网络url
     * @return 资源下载状态, 参考 {@link com.fitmix.sdk.common.download.DownloadStatus }
     */
    public int getDownloadStatus(String url) {
        int downloadStatus = DownloadStatus.STATUS_WAITING;
        if (!TextUtils.isEmpty(url) && currentDownLoadTasks != null) {
            DownloadTask downloadThread = currentDownLoadTasks.get(url);
            if (downloadThread != null && downloadThread.getDownloadInfo() != null) {
                downloadStatus = downloadThread.getDownloadInfo().getStatus();
            }
        }
        return downloadStatus;
    }

    /**
     * 恢复下载
     *
     * @param url 资源文件网络url
     */
    public void resumeDownload(String url) {
        if (TextUtils.isEmpty(url))
            return;
        if (currentDownLoadTasks != null) {
            DownloadTask downloadThread = currentDownLoadTasks.get(url);
            if (downloadThread != null) {
                DownloadInfo downloadInfo = downloadThread.getDownloadInfo();
                if (downloadInfo != null) {
                    downloadInfo.setStatus(DownloadStatus.STATUS_WAITING);
                    DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
                    checkDownloadTask(downloadInfo, false);
                }
            }
        }
    }

    /**
     * 暂停下载
     *
     * @param url 资源文件网络url
     */
    public void pauseDownload(String url) {
        if (TextUtils.isEmpty(url))
            return;
        if (currentDownLoadTasks != null) {
            DownloadTask downloadTask = currentDownLoadTasks.get(url);
            if (downloadTask != null) {
                DownloadInfo downloadInfo = downloadTask.getDownloadInfo();
                if (downloadInfo != null) {
                    downloadInfo.setStatus(DownloadStatus.STATUS_PAUSED);
                }
                DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
            }
        }
    }

    /**
     * 取消下载
     *
     * @param url 资源文件网络url
     */
    public void cancelDownload(String url) {
        if (TextUtils.isEmpty(url))
            return;
        if (currentDownLoadTasks != null) {
            DownloadTask downloadTask = currentDownLoadTasks.get(url);
            if (downloadTask != null) {
                DownloadInfo downloadInfo = downloadTask.getDownloadInfo();
                if (downloadInfo != null) {
                    downloadInfo.setStatus(DownloadStatus.STATUS_CANCEL);
                    DownloadInfoHelper.asyncDeleteDownloadInfo(downloadInfo);//从数据库中移除
                    sendMsgToSelf(DownloadStatus.STATUS_CANCEL, downloadInfo);
                }
            }
            //从任务列表中移除
            currentDownLoadTasks.remove(url);
        }
    }

    //endregion ============================= 下载与Activity交互 =============================

    //region ============================= 下载状态消息回调 =============================

    /**
     * 分发从下载线程中收到的准备下载消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownPrepare(DownloadInfo downloadInfo) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchNotSupportBt");
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            DownloadInfoListener downloadInfoListener = listener.get();
            if (downloadInfoListener != null) {
                downloadInfoListener.onPrepare(downloadInfo);
            }
        }

    }

    /**
     * 分发从下载线程中收到的下载中消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownloading(DownloadInfo downloadInfo) {
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            DownloadInfoListener downloadInfoListener = listener.get();
            if (downloadInfoListener != null) {
                downloadInfoListener.onDownloading(downloadInfo);
            }
        }
    }

    /**
     * 分发从下载线程中收到的下载暂停消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownPause(DownloadInfo downloadInfo) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchDownPause");
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            DownloadInfoListener downloadInfoListener = listener.get();
            if (downloadInfoListener != null) {
                downloadInfoListener.onPause(downloadInfo);
            }
        }
    }

    /**
     * 分发从下载线程中收到的下载完成消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownCompleted(DownloadInfo downloadInfo) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchDownCompleted");
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            if (listener != null) {
                DownloadInfoListener downloadInfoListener = listener.get();
                if (downloadInfoListener != null) {
                    downloadInfoListener.onCompleted(downloadInfo);
                }
            }
        }
    }

    /**
     * 分发从下载线程中收到的下载取消消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownCancel(DownloadInfo downloadInfo) {
//        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchDownCancel");
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            if (listener != null) {
                DownloadInfoListener downloadInfoListener = listener.get();
                if (downloadInfoListener != null) {
                    downloadInfoListener.onCancel(downloadInfo);
                }
            }
        }
    }

    /**
     * 分发从下载线程中收到的下载失败消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownFail(DownloadInfo downloadInfo, String errorMsg) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchDownFail ---> errorMsg :" + errorMsg);
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            DownloadInfoListener downloadInfoListener = listener.get();
            if (downloadInfoListener != null) {
                downloadInfoListener.onFail(downloadInfo, errorMsg);
            }
        }
    }

    /**
     * 分发从下载线程中收到的文件已存在消息
     *
     * @param downloadInfo 资源下载信息
     */
    protected void dispatchDownFileExist(DownloadInfo downloadInfo) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchDownFileExist");
        for (WeakReference<DownloadInfoListener> listener : downloadListeners) {
            DownloadInfoListener downloadInfoListener = listener.get();
            if (downloadInfoListener != null) {
                downloadInfoListener.onExist(downloadInfo);
            }
        }
    }

    /**
     * 向UI线程发送下载状态消息
     *
     * @param downloadStatus 当前下载状态,参考 {@link com.fitmix.sdk.common.download.DownloadStatus }
     */
    private void sendMsgToSelf(int downloadStatus, DownloadInfo downloadInfo) {
        if (mHandler != null) {
            Message message = new Message();
            message.what = downloadStatus;
            message.obj = downloadInfo;
            mHandler.sendMessage(message);
        }
    }

    //endregion ============================= 下载状态消息回调 =============================

    //region ================================== 下载任务相关 ==================================

    /**
     * 检查下载任务
     *
     * @param downloadInfo 下载对象的信息
     * @param fromCommand  是否由onStartCommand方法调用
     */
    private synchronized void checkDownloadTask(@Nullable DownloadInfo downloadInfo, boolean fromCommand) {
        if (downloadInfo != null) {
//            Logger.i(Logger.DEBUG_TAG, "checkDownloadTask downloadInfo name:" + downloadInfo.getName() + " status:" + downloadInfo.getStatus());
            // 1.先检查是否存在同名的文件
            File file = new File(downloadInfo.getLocalPath() + File.separator + downloadInfo.getName());
            if (file.exists()) {
                DownloadInfo ll = DownloadInfoHelper.getDownloadInfoByUrl(downloadInfo.getRemoteUrl());
                if (ll == null) {
                    //写入数据库
                    downloadInfo.setStatus(DownloadStatus.STATUS_COMPLETED);
                    downloadInfo.setCurrentSize(file.length());
                    downloadInfo.setTotalSize(file.length());
                    DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
                } else if (ll.getStatus() != DownloadStatus.STATUS_COMPLETED) {
                    ll.setStatus(DownloadStatus.STATUS_COMPLETED);
                    DownloadInfoHelper.asyncWriteDownloadInfo(ll);
                }
                sendMsgToSelf(DownloadStatus.STATUS_EXIST, downloadInfo);
            } else {
                // 2.再检查是否在任务总表中
                if (currentDownLoadTasks.containsKey(downloadInfo.getRemoteUrl())) {
                    DownloadTask downloadTask = currentDownLoadTasks.get(downloadInfo.getRemoteUrl());
                    if (downloadTask != null) {
                        DownloadInfo bean = downloadTask.getDownloadInfo();
                        //检测当前的状态,1.如果是等待或失败状态的则当作新任务重新开始下载
                        //2.如果是暂停状态并且是由Intent发送过来则当作新任务重新开始下载
                        switch (bean.getStatus()) {
                            case DownloadStatus.STATUS_WAITING:
                            case DownloadStatus.STATUS_FAILED:
                                bean.setStatus(DownloadStatus.STATUS_WAITING);
                                startDownLoadTask(bean);
                                break;
                            case DownloadStatus.STATUS_PAUSED:
                                if (fromCommand) {
                                    bean.setStatus(DownloadStatus.STATUS_WAITING);
                                    startDownLoadTask(bean);
                                }
                                break;
                        }
                    }
                } else {
                    //如果不存在,则添加到总表,并添加到数据库
                    downloadInfo.setStatus(DownloadStatus.STATUS_WAITING);
                    DownloadTask downloadTask = new DownloadTask(downloadInfo);
                    currentDownLoadTasks.put(downloadInfo.getRemoteUrl(), downloadTask);
                    DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
                    startDownLoadTask(downloadInfo);
                }
            }
        }
    }

    /**
     * 将任务添加到下载队列中
     *
     * @param downloadInfo 下载对象的信息
     */
    private void startDownLoadTask(DownloadInfo downloadInfo) {
        Logger.i(Logger.DEBUG_TAG, "startDownLoadTask runningThread:" + runningThread);
        if (runningThread < MAX_THREADS) {
            String url = downloadInfo.getRemoteUrl();
            if (!TextUtils.isEmpty(url)) {
                //如果当前还有空闲的位置则直接下载 , 否则就是在等待中
                runningThreadAdd();
                DownloadTask downloadTask = currentDownLoadTasks.get(url);
                if (downloadTask != null) {
                    Logger.i(Logger.DEBUG_TAG, "startDownLoadTask downloadInfo name:" + downloadInfo.getName() + " status:" + downloadInfo.getStatus()
                            + " runningThread:" + runningThread);
                    mThreadPoolExecutor.submit(downloadTask);
                }
            }
        }
    }

    /**
     * 文件下载任务
     */
    public class DownloadTask implements Callable<String> {
        /**
         * 当前文件下载信息
         */
        private DownloadInfo downloadInfo;
        /**
         * 本地临时文件
         */
        private File localTempFile;
        /**
         * 断点续传http头
         */
        private String httpRange = null;

        /**
         * 创建文件下载任务
         *
         * @param downloadInfo 要下载的文件信息,如本地名称,路径等等
         */
        public DownloadTask(DownloadInfo downloadInfo) {
            this.downloadInfo = downloadInfo;
        }

        /**
         * 获取当前下载信息
         */
        public DownloadInfo getDownloadInfo() {
            return downloadInfo;
        }

        @Override
        public String call() throws Exception {
            // 1.先检查是否有之前的临时文件
            localTempFile = new File(downloadInfo.getLocalPath() + File.separator + downloadInfo.getName() + ".tmp");
            if (localTempFile.exists()) {
                httpRange = "bytes=" + localTempFile.length() + "-";
            }
            // 2.创建 OkHttp 对象相关
            OkHttpClient client = OkHttpUtil.getInstance().getClient();
            // 3.检测网络状况
            if (!ApiUtils.isNetWorkAvailable()) {
                //需要问题提示没有网络
                //本地有临时文件时,存为暂停状态,有failure的appMsg文字提示
                //本地无临时文件时,存为出错状态,有failure的appMsg文字提示

                downloadFailed(localTempFile.exists(), ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
//                downloadPaused();
                return null;
            }
            // 4.如果有临时文件,则在下载的头中添加下载区域,即断点续传
            Request request;
            if (!TextUtils.isEmpty(httpRange)) {
                request = new Request.Builder().url(downloadInfo.getRemoteUrl()).header("Range", httpRange)
                        .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                                ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                                ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                        .build();
            } else {
                request = new Request.Builder().url(downloadInfo.getRemoteUrl())
                        .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                                ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                                ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                        .build();
            }
            Call call = client.newCall(request);
            try {
                bytes2File(call);
            } catch (IOException e) {
                e.printStackTrace();

                if (e.getMessage() != null && e.getMessage().contains("interrupted")) {
//                    Logger.e("DownloadTask", "Download task: " + downloadInfo.getRemoteUrl() + "exception:interrupted, Canceled");
                    downloadPaused();
                } else if (e.getMessage() != null && e.getMessage().contains("Connection timed out")) {//连接超时即网络断开
//                    Logger.e("DownloadTask", "Download task: " + downloadInfo.getRemoteUrl() + "exception:Connection timed out, Canceled");
                    downloadPaused();
                } else {
                    downloadFailed(false, 404);
                }
                return null;
            }
            if (downloadInfo.getStatus() == DownloadStatus.STATUS_DOWNLOADING) {
                //执行到此,如果当前状态还处在正在下载,说明下载期间没有被取消、暂停或下载异常
                downloadCompleted();
            }
            return null;
        }

        /**
         * DownloadTask 向主线程发送下载状态消息
         *
         * @param downloadStatus 当前下载状态,参考 {@link com.fitmix.sdk.common.download.DownloadStatus }
         * @param errorCode      下载错误代码,参考http code 以及{@link com.fitmix.sdk.model.api.ApiUtils }自定义错误
         */
        private void sendMsgToMainThread(int downloadStatus, int errorCode) {
            if (mHandler != null) {
                Message message = new Message();
                message.what = downloadStatus;
                message.obj = downloadInfo;
                message.arg1 = errorCode;
                mHandler.sendMessage(message);
            }
        }

        /**
         * DownloadTask 向主线程发送下载状态消息
         *
         * @param downloadStatus 当前下载状态,参考 {@link com.fitmix.sdk.common.download.DownloadStatus }
         */
        private void sendMsgToMainThread(int downloadStatus) {
            sendMsgToMainThread(downloadStatus, 200);
        }

        /**
         * 将下载的数据存到本地文件
         *
         * @param call OkHttp的Call对象
         * @throws IOException 下载的异常
         */
        private void bytes2File(Call call) throws IOException {
            //设置输出流.
            OutputStream outPutStream;
            //1.检测是否支持断点续传
            Response response = call.execute();
            ResponseBody responseBody = response.body();
            String responseRange = response.headers().get("Content-Range");
            if (responseRange == null || !responseRange.contains(Long.toString(localTempFile.length()))) {
                //最后的标记为 true 表示下载的数据可以从上一次的位置写入,否则会清空文件数据.
                outPutStream = new FileOutputStream(localTempFile, false);
                Logger.i(Logger.DEBUG_TAG, "DownloadTask-->bytes2File 文件不存在");
            } else {
                outPutStream = new FileOutputStream(localTempFile, true);
                Logger.i(Logger.DEBUG_TAG, "DownloadTask-->bytes2File 文件存在,追加下载");
            }

            //2.如果有下载过的历史文件,则把下载总大小设为 总数据大小+文件大小.否则就是总数据大小
            if (TextUtils.isEmpty(httpRange)) {
                downloadInfo.setTotalSize(responseBody.contentLength());
            } else {
                downloadInfo.setTotalSize(responseBody.contentLength() + localTempFile.length());
            }
            //3.通知准备下载
            sendMsgToMainThread(DownloadStatus.STATUS_WAITING);

            int length;
            byte[] buffer = new byte[1024];//设置缓存大小
            //4.开始写入文件
            InputStream inputStream = responseBody.byteStream();
            while ((length = inputStream.read(buffer)) != -1) {
                //下载暂停或者取消时,停止写文件并通知
                if (downloadInfo.getStatus() == DownloadStatus.STATUS_PAUSED) {
                    downloadPaused();
                    break;
                }
                if (downloadInfo.getStatus() == DownloadStatus.STATUS_CANCEL) {
                    downloadCancel();
                    break;
                }
                //写文件
                outPutStream.write(buffer, 0, length);
                //通知正在下载,并汇报进度
                downloadInfo.setStatus(DownloadStatus.STATUS_DOWNLOADING);
                if (localTempFile != null) {
                    downloadInfo.setCurrentSize(localTempFile.length());
                }
                sendMsgToMainThread(DownloadStatus.STATUS_DOWNLOADING);
            }
            //清空缓冲区
            outPutStream.flush();
            outPutStream.close();
            inputStream.close();
            responseBody.close();
        }

        /**
         * 查找一个等待中的下载任务
         *
         * @return 查找到的下载任务信息, 没有则返回Null
         */
        private DownloadInfo getNextDownloadTask() {
            for (DownloadTask downloadTask : currentDownLoadTasks.values()) {
                DownloadInfo nextDownload = downloadTask.getDownloadInfo();
                if (nextDownload != null) {
                    if (nextDownload.getStatus() == DownloadStatus.STATUS_WAITING) {
//                        nextDownload.setStatus(DownloadStatus.STATUS_PAUSED);
                        return nextDownload;
                    }
                }
            }
            return null;
        }

//        /**
//         * 导出数据库到临时文件夹
//         */
//        public void backupDatabase() {
//            try {
//                //Open your local db as the input stream
//                String inFileName = "/data/data/com.fitmix.sdk/databases/realm.db";
//                File dbFile = new File(inFileName);
//                FileInputStream fis = new FileInputStream(dbFile);
//
//                String outFileName = Config.PATH_LOCAL_TEMP + "realm.db";
//                //Open the empty db as the output stream
//                OutputStream output = new FileOutputStream(outFileName);
//                //transfer bytes from the inputfile to the outputfile
//                byte[] buffer = new byte[1024];
//                int length;
//                while ((length = fis.read(buffer)) > 0) {
//                    output.write(buffer, 0, length);
//                }
//                //Close the streams
//                output.flush();
//                output.close();
//                fis.close();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }

        /**
         * 下载失败后的操作
         *
         * @param errorCode 错误代码,如http 404 以及{@link com.fitmix.sdk.model.api.ApiUtils}自定义的错误
         */
        private void downloadFailed(boolean ifFileExist, int errorCode) {
            runningThreadReduce();
            if (!ifFileExist) {
                downloadInfo.setStatus(DownloadStatus.STATUS_FAILED);
            } else {
                downloadInfo.setStatus(DownloadStatus.STATUS_PAUSED);
            }
            //通知下载失败
            sendMsgToMainThread(DownloadStatus.STATUS_FAILED, errorCode);
            //更新数据库
            DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
            if (currentDownLoadTasks.size() > 0) {
                //执行剩余的等待任务
                checkDownloadTask(getNextDownloadTask(), false);
            }
//            backupDatabase();
        }

        /**
         * 下载暂停后的操作
         */
        private void downloadPaused() {
            runningThreadReduce();

            downloadInfo = DownloadInfoHelper.getDownloadInfoById(downloadInfo.getRemoteUrl());
            downloadInfo.setStatus(DownloadStatus.STATUS_PAUSED);

            //通知下载暂停
            sendMsgToMainThread(DownloadStatus.STATUS_PAUSED);

            //写数据库操作

            DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);

            if (currentDownLoadTasks.size() > 0) {
                //执行剩余的等待任务
                checkDownloadTask(getNextDownloadTask(), false);
            }
            Log.i("TT", "备份数据库成功");
        }

        /**
         * 下载取消后的操作
         */
        private void downloadCancel() {
            runningThreadReduce();
            downloadInfo.setStatus(DownloadStatus.STATUS_CANCEL);
            //通知下载取消
            sendMsgToMainThread(DownloadStatus.STATUS_CANCEL);
            if (currentDownLoadTasks != null) {
                //从任务列表中移除任务
                currentDownLoadTasks.remove(downloadInfo.getRemoteUrl());
                if (currentDownLoadTasks.size() > 0) {
                    //执行剩余的等待任务
                    checkDownloadTask(getNextDownloadTask(), false);
                }
            }
        }

        /**
         * 下载完成后的操作
         */
        private void downloadCompleted() {
            // 1.当前下载数减一
            runningThreadReduce();
            downloadInfo.setStatus(DownloadStatus.STATUS_COMPLETED);
            // 2.将临时文件名更改回正式文件名
            localTempFile.renameTo(new File(downloadInfo.getLocalPath() + File.separator + downloadInfo.getName()));

            if (currentDownLoadTasks != null) {
                //4.从总表中移除这项下载信息
                currentDownLoadTasks.remove(downloadInfo.getRemoteUrl());
                //5.更新数据库
                DownloadInfoHelper.asyncWriteDownloadInfo(downloadInfo);
                // 3.通知下载完成
                sendMsgToMainThread(DownloadStatus.STATUS_COMPLETED);
                if (currentDownLoadTasks.size() > 0) {
                    //执行剩余的等待任务
                    checkDownloadTask(getNextDownloadTask(), false);
                }
            }
        }
    }

    //endregion ================================== 下载任务相关 ==================================

    //region ============================= 上传与Activity交互 =============================

    /**
     * 根据文件上传的url,本地文件的全路径,文件上传标签创建上传任务
     *
     * @param context   上下文
     * @param url       文件上传的url
     * @param localPath 本地文件的全路径,如   /mnt/sdcard/fitmix/Step/355418_1462840286000.step
     * @param uploadTag 文件上传标签,表示文件上传类型,如png等
     */
    public static void makeUpload(Context context, String url, String localPath, String uploadTag) {
        if (context == null || TextUtils.isEmpty(url) || TextUtils.isEmpty(localPath))
            return;
        Intent intent = new Intent(context, DownloadService.class);
        intent.putExtra(CMD_TYPE, CMD_UPLOAD);
        intent.putExtra(DownloadService.EXTRA_UPLOAD_URL, url);
        intent.putExtra(DownloadService.EXTRA_UPLOAD_LOCAL, localPath);
        intent.putExtra(DownloadService.EXTRA_UPLOAD_TAG, uploadTag);
        context.startService(intent);
    }

    /**
     * 添加上传事件回调
     *
     * @param listener 上传事件回调
     */
    public void addUploadListener(UploadInfoListener listener) {
        if (uploadListeners == null) {
            uploadListeners = new ArrayList<>();
        }
        uploadListeners.add(new WeakReference<>(listener));
    }

    /**
     * 移除上传事件回调
     *
     * @param listener 上传事件回调
     */
    public void removeUploadListener(UploadInfoListener listener) {
        if (uploadListeners == null) {
            return;
        }
        uploadListeners.remove(new WeakReference<>(listener));
    }
    //endregion ============================= 上传与Activity交互 =============================

    //region ============================= 上传状态消息回调 =============================

    /**
     * 分发从上传线程中收到的上传失败消息
     *
     * @param uploadInfo 上传信息
     * @param errorCode  上传错误代码,参考http code 以及{@link com.fitmix.sdk.model.api.ApiUtils }自定义错误
     */
    protected void dispatchUpFail(UploadInfo uploadInfo, int errorCode) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchUpFail");
        for (WeakReference<UploadInfoListener> listener : uploadListeners) {
            if (listener != null) {
                UploadInfoListener uploadInfoListener = listener.get();
                if (uploadInfoListener != null) {
                    uploadInfoListener.onFail(uploadInfo, errorCode);
                }
            }
        }

    }

    /**
     * 分发从上传线程中收到的上传成功消息
     *
     * @param uploadInfo 上传信息
     */
    protected void dispatchUpSuccess(UploadInfo uploadInfo) {
        Logger.i(Logger.DEBUG_TAG, "DownloadService-->dispatchUpSuccess");
        for (WeakReference<UploadInfoListener> listener : uploadListeners) {
            if (listener != null && listener.get() != null) {
                listener.get().onSuccess(uploadInfo);
            }
        }

    }

    //endregion ============================= 上传状态消息回调 =============================

    //region ================================== 上传任务相关 ==================================

    /**
     * 检查上传任务
     *
     * @param uploadInfo 文件上传信息
     */
    private void checkUploadTask(UploadInfo uploadInfo) {
        if (uploadInfo != null) {
//            Logger.i(Logger.DEBUG_TAG, "checkUploadTask uploadInfo url:" + uploadInfo.getUrl() + " localPath:" + uploadInfo.getLocalFilePath());
            // 检查是否在任务总表中,
            if (currentUploadTasks.containsKey(uploadInfo.getLocalFilePath())) {
                UploadTask uploadTask = currentUploadTasks.get(uploadInfo.getLocalFilePath());
                if (uploadTask != null) {
                    UploadInfo bean = uploadTask.getUploadInfo();
                    //检测当前的状态,1.如果是等待则当作新任务重新开始上传
                    switch (bean.getStatus()) {
                        case UploadStatus.STATUS_WAITING:
                            bean.setStatus(UploadStatus.STATUS_WAITING);
                            startUploadTask(bean);
                            break;
                    }
                }
            } else {
                //不存在,则添加到总表
                UploadTask uploadTask = new UploadTask(uploadInfo);
                currentUploadTasks.put(uploadInfo.getLocalFilePath(), uploadTask);
                startUploadTask(uploadInfo);
            }
        }
    }

    private void startUploadTask(UploadInfo uploadInfo) {
        if (runningThread < MAX_THREADS) {
            //如果当前还有空闲的位置则直接上传 , 否则就是在等待中
            runningThreadAdd();
            UploadTask uploadTask = new UploadTask(uploadInfo);
            if (uploadTask != null) {
                Logger.i(Logger.DEBUG_TAG, "startDownLoadTask uploadTask uploadUrl:" + uploadInfo.getUrl()
                        + " localFilePath:" + uploadInfo.getLocalFilePath()
                        + " runningThread:" + runningThread);
                mThreadPoolExecutor.submit(uploadTask);
            }
        }
    }

    /**
     * 文件上传任务
     */
    public class UploadTask implements Callable<String> {

        private UploadInfo uploadInfo;
        private File localFile;

        /**
         * 创建文件上传任务
         *
         * @param uploadInfo 文件上传信息
         */
        public UploadTask(UploadInfo uploadInfo) {
            this.uploadInfo = uploadInfo;
        }

        /**
         * 获取上传信息
         */
        public UploadInfo getUploadInfo() {
            return uploadInfo;
        }

        /**
         * 查找一个等待中的上传任务
         *
         * @return 查找到的上传任务信息, 没有则返回Null
         */
        public UploadInfo getNextUploadTask() {
            for (UploadTask uploadTask : currentUploadTasks.values()) {
                UploadInfo nextUpload = uploadTask.getUploadInfo();
                if (nextUpload != null) {
                    return nextUpload;
                }
            }
            return null;
        }

        /**
         * UploadTask 向主线程发送上传状态消息
         *
         * @param uploadStatus 当前上传状态,参考 {@link com.fitmix.sdk.common.download.UploadStatus }
         * @param errorCode    上传错误代码,参考http code 以及{@link com.fitmix.sdk.model.api.ApiUtils }自定义错误
         */
        private void sendMsgToMainThread(int uploadStatus, int errorCode) {
            if (mHandler != null) {
                Message message = new Message();
                message.what = uploadStatus;
                message.arg1 = errorCode;
                message.obj = uploadInfo;
                mHandler.sendMessage(message);
            }
        }

        /**
         * 上传失败
         *
         * @param errorCode 上传错误代码,参考http code 以及{@link com.fitmix.sdk.model.api.ApiUtils }自定义错误
         */
        private void uploadFail(int errorCode) {
            // 移除任务,并通知
            uploadInfo.setStatus(UploadStatus.STATUS_FAIL);
            currentUploadTasks.remove(uploadInfo.getLocalFilePath());
            runningThreadReduce();
            sendMsgToMainThread(UploadStatus.STATUS_FAIL, errorCode);
            if (currentUploadTasks.size() > 0) {
                //检查下一个上传任务
                checkUploadTask(getNextUploadTask());
            }
        }

        /**
         * 上传成功
         */
        private void uploadSuccess() {
            // 移除任务,并通知
            uploadInfo.setStatus(UploadStatus.STATUS_SUCCESS);
            currentUploadTasks.remove(uploadInfo.getLocalFilePath());
            runningThreadReduce();
            sendMsgToMainThread(UploadStatus.STATUS_SUCCESS, 200);
            if (currentUploadTasks.size() > 0) {
                //检查下一个上传任务
                checkUploadTask(getNextUploadTask());
            }
        }

        @Override
        public String call() throws Exception {
            // 1.检查文件路径,是否为空
            if (uploadInfo == null || TextUtils.isEmpty(uploadInfo.getLocalFilePath()) || TextUtils.isEmpty(uploadInfo.getUploadTag())) {
                uploadFail(ApiUtils.HTTP_REQUEST_INPUT_INVALID);//无效的请求
                return null;
            }
            localFile = new File(uploadInfo.getLocalFilePath());
            // 2.创建 OkHttp 对象相关
            OkHttpClient client = OkHttpUtil.getInstance().getClient();
            // 3.检测网络状况
            if (!ApiUtils.isNetWorkAvailable()) {
                // 移除任务,并通知
                uploadFail(ApiUtils.HTTP_NETWORK_FAIL);//网络错误
                return null;
            }
            // 4.设置上传状态
            uploadInfo.setStatus(UploadStatus.STATUS_UPLOADING);
            // 5.设置上传http请求头
            Request request;
            if (localFile.exists()) {
                String sString = "form-data; name=\"" + uploadInfo.getUploadTag() + "\";filename=\""
                        + localFile.getName() + "\"";

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart(uploadInfo.getUploadTag(), localFile.getName(),
                                RequestBody.create(null, localFile))
                        .addPart(
                                Headers.of("Content-Disposition", sString),
                                RequestBody.create(
                                        MediaType.parse("application/octet-stream"),
                                        localFile)).build();
                request = new Request.Builder().url(uploadInfo.getUrl())
                        .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                                ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                                ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                        .post(requestBody).build();
            } else {
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addPart(Headers.of("Content-Disposition", "form-data; name=\"" + uploadInfo.getUploadTag() + "\""),
                                RequestBody.create(null, ""))
                        .build();
                request = new Request.Builder().url(uploadInfo.getUrl())
                        .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                                ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                                ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                        .post(requestBody).build();
            }
            // 5.上传操作
            try {
                Response response = client.newCall(request).execute();
                if (response != null) {
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        if (!TextUtils.isEmpty(result)) {
                            Logger.i(Logger.DEBUG_TAG, "UploadTask-->success result:" + result);
                        }
                        uploadSuccess();
                    } else {
                        uploadFail(response.code());
                    }
                    return "{code:" + response.code() + "}";
                }
            } catch (Exception e) {
                uploadFail(ApiUtils.HTTP_REQUEST_EXCEPTION);//未知错误
            }
            return null;
        }
    }
    //endregion ================================== 上传任务相关 ==================================

}