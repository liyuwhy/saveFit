package com.fitmix.sdk.common.download;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.model.database.DownloadInfo;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadThread extends Thread {

    protected DownloadInfo downloadInfo;//数据库中下载表的字段
    protected File localTempFile;//下载的临时文件
    protected String mUrl;//音乐资源url
    protected String mLocale; // 音乐文件的文件夹路径（完整路径）


    //	private int mMode = FitmixConstant.HTTP_GET;
    private int mPercent = 0;

    private long mTotalDownload = 0;
    private long mCurrentDownloaded = 0;

    private int mDownloadSpeed = 0;
    protected int mDownloaded = 0;//本次下载的下载总量
    protected int mRetCode = 0;
    //	private String sRetCodeString;
    private final int BUFFER_SIZE = 1024;
    protected boolean bEnableDownloadSeg = false;

    public DownloadThread(DownloadInfo downloadInfo) {
        super();
        this.downloadInfo = downloadInfo;
        localTempFile = new File(downloadInfo.getLocalPath() + File.separator + downloadInfo.getName() + ".tmp");

    }


    protected MyConfig getMyConfig() {
        return MyConfig.getInstance();
    }

    /**
     * 设置下载任务的必须参数
     *
     * @param url    音乐资源url
     * @param locale 存放本地的url（成功文件路径）
     */
    public void setDownloadParam(String url, String locale) {
        mUrl = url;
        mLocale = locale;
    }


    @Override
    public void run() {
        super.run();
        int sResult = doInBackground();
        onPostExecute(sResult);
    }

    protected int getTotalDownloadSize(String urlPath) {
        int size = 0;
        try {
            URL url = new URL(urlPath);
            HttpURLConnection urlConn = (HttpURLConnection) url
                    .openConnection();
            urlConn.setRequestProperty("Accept-Encoding", "identity");
            size = urlConn.getContentLength();
            urlConn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }

//		Log.d(getMyConfig().getTag(), "contentLength:" + size);
        return size;
    }

    protected boolean initDownload() {
        mPercent = 0;
        mTotalDownload = 0;
        mCurrentDownloaded = 0;
        mDownloadSpeed = 0;
//		if (iDownloadFlag == DOWNLOADFLAG_IDLE)
//			setDownloadFlag(DOWNLOADFLAG_DOWNLOADING);
        if (mUrl == null || mLocale == null)
            return false;
        if (mUrl.isEmpty() || mLocale.isEmpty())
            return false;

//		Log.d(getMyConfig().getTag(), "url:" + mUrl + ",locale:" + mLocale);
        return true;
    }

    /**
     * 请求下载,获取HttpHRLConnection（关键参数为起始和末尾的position）
     *
     * @param path
     * @param startPosition
     * @param endPosition
     * @return
     */
    protected HttpURLConnection requestDownload(String path, long startPosition,
                                                long endPosition) {
        HttpURLConnection urlConn = null;
        try {
            URL url = new URL(path);
            urlConn = (HttpURLConnection) url.openConnection();
            urlConn.setConnectTimeout(Config.REQUEST_TIME_OUT_SECOND);
//			if (mMode == FitmixConstant.HTTP_POST)
//				urlConn.setRequestMethod("POST");

            if ((startPosition >= 0) && (endPosition > startPosition)) {
                urlConn.setAllowUserInteraction(true);
                urlConn.setRequestProperty("Range", "bytes=" + startPosition
                        + "-" + endPosition);
//				Log.d(getMyConfig().getTag(), "range:" + startPosition + "-"
//						+ endPosition);
            }
            urlConn.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return urlConn;
    }

    protected HttpURLConnection requestDownload(String path, String sRange) {
        if (path == null || path.isEmpty())
            return null;
        if (sRange == null || sRange.isEmpty())
            return null;

        HttpURLConnection urlConn = null;
        try {
            URL url = new URL(path);
            urlConn = (HttpURLConnection) url.openConnection();
            urlConn.setConnectTimeout(Config.REQUEST_TIME_OUT_SECOND);
//			if (mMode == FitmixConstant.HTTP_POST)
//				urlConn.setRequestMethod("POST");

            if ((sRange != null) && (!sRange.isEmpty())) {
                urlConn.setAllowUserInteraction(true);
                urlConn.setRequestProperty("Range", "bytes=" + sRange);
//				Log.d(getMyConfig().getTag(), "range:" + sRange);
            }
            urlConn.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return urlConn;
    }

    protected boolean isEnableDownload() {
        return downloadInfo.getStatus() != DownloadStatus.STATUS_FAILED;
    }

    /**
     * 开始写每段（头、中、尾）数据到文件
     *
     * @param urlConn
     * @param sFilename
     * @param startPosition 本段开始的位置
     * @param downloaded    （头、中、尾）已经下完的数据量,
     * @param total         文件总的大小
     * @param segTotal      本段所需要下的大小
     * @return
     */
    protected int writeDownloadFile(HttpURLConnection urlConn,
                                    String sFilename, long startPosition, long downloaded, long total, long segTotal) {
        if (downloadInfo == null) {
            return Config.ERROR_DOWNLOAD_UNKNOWN;
        }
        if (urlConn == null)
            return Config.ERROR_DOWNLOAD_UNKNOWN;
        if ((total <= 0) || (downloaded < 0) || (downloaded > total)
                || (startPosition < 0) || (startPosition >= total))
            return Config.ERROR_DOWNLOAD_UNKNOWN;
        if (sFilename == null || sFilename.isEmpty())
            return Config.ERROR_DOWNLOAD_UNKNOWN;


        long segHadDownload = 0;//本段已经下了的大小
        if (downloaded < Config.HEAD_SIZE) {
            segHadDownload = downloaded;
        } else if (downloaded > Config.HEAD_SIZE && downloaded < Config.HEAD_SIZE + Config.TAIL_SIZE) {
            segHadDownload = downloaded - Config.HEAD_SIZE;
        } else if (downloaded > Config.HEAD_SIZE + Config.TAIL_SIZE && downloaded < total) {
            segHadDownload = downloaded - Config.HEAD_SIZE - Config.TAIL_SIZE;
        }


        int iUrlCode;
        InputStream inputStream = null;
        RandomAccessFile FOS = null;
        try {
            iUrlCode = urlConn.getResponseCode();
            if (!(iUrlCode == Config.HTTP_200 || iUrlCode == Config.HTTP_206))
                return iUrlCode;
            inputStream = urlConn.getInputStream();
            if (inputStream == null)
                return Config.ERROR_DOWNLOAD_UNKNOWN;

            //多线程下载所需类
            FOS = new RandomAccessFile(sFilename, "rw");//必须为读写类型
            FOS.seek(startPosition);
            byte buf[] = new byte[BUFFER_SIZE];
            long iTotalDownloaded = downloaded;

            int numread;//本次写的数据量
            int percent = (int) (iTotalDownloaded * 100.0 / total);
            int oldpercent = percent;
            //long speed = 0;
            long oldTime = System.currentTimeMillis();
//			long oldDownload = iTotalDownloaded;

            mDownloaded = 0;
            while ((numread = inputStream.read(buf)) != -1) {
                //下载暂停或者取消时,停止写文件并通知
                if (downloadInfo.getStatus() == DownloadStatus.STATUS_PAUSED) {
                    downloadPaused();
                    iUrlCode = Config.ERROR_DOWNLOAD_PAUSE;
                    if (inputStream != null)
                        inputStream.close();
                    if (FOS != null)
                        FOS.close();
                    return iUrlCode;
                }
                if (downloadInfo.getStatus() == DownloadStatus.STATUS_CANCEL) {
                    downloadCancel();
                    iUrlCode = Config.ERROR_DOWNLOAD_CANCEL;
                    if (inputStream != null)
                        inputStream.close();
                    if (FOS != null)
                        FOS.close();
                    return iUrlCode;
                }

                FOS.write(buf, 0, numread);
                mDownloaded += numread;
                iTotalDownloaded += numread;
                percent = (int) (iTotalDownloaded * 100.0 / total);
                if (percent != oldpercent) {
                    long now = System.currentTimeMillis();
                    if ((now - oldTime) >= 1000) {
                        //speed = (iTotalDownloaded - oldDownload) * 1000
                        //		/ (int) (now - oldTime);
//						oldDownload = iTotalDownloaded;
                        oldTime = now;
                    }
                    //并汇报进度
                    downloadInfo.setCurrentSize(iTotalDownloaded);
                    //设置状态
                    downloadInfo.setStatus(DownloadStatus.STATUS_DOWNLOADING);
                    //通知主线程,正在下载
                    sendMsgToMainThread(DownloadStatus.STATUS_DOWNLOADING);
                }
            }
            //最后通过判断接收是否正常判断网络是否断开,如果断开则做音乐停止操作
            if (mDownloaded + segHadDownload >= segTotal) {//如果接收数据总量等于数据总量才设置iUrlCode为成功
                iUrlCode = Config.ERROR_NO_ERROR;
            } else { //如果接收总量小于本段所需接收的量,则表示网络中断错误,设暂停
                downloadPaused();
                iUrlCode = Config.ERROR_DOWNLOAD_PAUSE;
            }
        } catch (Exception e) {
            //每次报的异常e=null
            downloadPaused();
            iUrlCode = Config.ERROR_DOWNLOAD_PAUSE;
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null)
                    inputStream.close();
                if (FOS != null)
                    FOS.close();
            } catch (Exception e) {
                iUrlCode = Config.ERROR_DOWNLOAD_UNKNOWN;
                e.printStackTrace();
            }
        }
        return iUrlCode;
    }

    /**
     * 下载暂停后的操作
     */
    protected void downloadPaused() {
    }

    /**
     * 下载取消后的操作
     */
    protected void downloadCancel() {
    }

    protected void sendMsgToMainThread(int downloadStatus) {

    }

    protected String getCacheFilename(String sLocalFile) {
        if (sLocalFile == null || sLocalFile.isEmpty())
            return null;
        return sLocalFile + ".tmp";
    }

    protected void processDownloadResult(int iResultCode, long iTotalSize) {
//		File fileCache = new File(getCacheFilename(mLocale));
////		long lSize = fileCache.length();
//		boolean bOK = false;
//		if (iResultCode == 0) {
//			File fileOK = new File(mLocale);
//			if (fileCache.length() == iTotalSize) {
//				fileCache.renameTo(fileOK);
//				bOK = true;
//			}
//
//		}
//		if ((!bOK) && bClearCache) {
//			fileCache.delete();
//		}
    }

    protected DownloadInfo getDownloadInfo() {
        return downloadInfo;
//		String sCacheFile = getCacheFilename(sLocalFile);
//		int startPosition = 0;
//		File tempFile = new File(sCacheFile);
//		if (tempFile.exists())
//			startPosition = (int) tempFile.length();
//		return startPosition;
    }

    /**
     * @param urlPath
     * @param startPosition 开始的位置
     * @param endPosition   本步骤的终点
     * @param downloaded    之前下载了的位置,
     * @param total         下载总共的大小
     * @param segTotal      本段所需下载的总量
     * @return
     */
    protected int downloadSeg(String urlPath, long startPosition,
                              long endPosition, long downloaded, long total, long segTotal) {
        HttpURLConnection urlConn = requestDownload(urlPath, startPosition,
                endPosition - 1);
        if (urlConn == null)
            return Config.ERROR_DOWNLOAD_UNKNOWN;
        int iUrlCode = writeDownloadFile(urlConn, getCacheFilename(mLocale),
                startPosition, downloaded, total, segTotal);

        if (urlConn != null)
            urlConn.disconnect();
        return iUrlCode;
    }

    /**
     * 下载进度文件修改,暂停
     */
    protected void processPause() {
    }

    protected void processContinue() {

    }

    /**
     * //保存下载进度临时文件
     */
    protected void saveDownloadPara() {

    }

//	/**
//	 * 在下载的途中,每0.1S就检测网络状态,如果检测不到网络则标志下载为pause。
//	 */
//	protected void checkNetwork() {
//
//		while (true) {
//			if (downloadInfo.getStatus() != DOWNLOADFLAG_PAUSE) {
//
//				if (!ApiUtils.isNetWorkAvailable()) {
//					setDownloadFlag(DOWNLOADFLAG_PAUSE);
//				}
//			}
//			if ((iDownloadFlag != DOWNLOADFLAG_PAUSE)
//					&& (ApiUtils.isNetWorkAvailable())) {
//				break;
//			}
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//
//		}
//	}

    protected int doInBackground() {
//		mRetCode = 0;
//		if (!initDownload()) {
////			mHandler.sendEmptyMessage();
//			downloadFailed(localTempFile.exists(), ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
////			mRetCode = FitmixConstant.ERROR_UNKNOW;
////			return "{code:" + mRetCode + "}";
//		}
//
//		int startPosition = 0;
//		int size;
//		int endPosition;
//		if (bEnableDownloadSeg)
//			startPosition = getDownloadInfo(mLocale);
//
//		checkNetwork();
//		mDownloadThread++;
//		if (bEnableDownloadSeg) {
//			size = getTotalDownloadSize(mUrl);
//			endPosition = size;
//			mRetCode = downloadSeg(mUrl, startPosition, endPosition,
//					startPosition, endPosition);
//			processDownloadResult(mRetCode, endPosition);
//		} else {
//			size = getTotalDownloadSize(mUrl);
//			mRetCode = downloadSeg(mUrl, 0, 0, 0, size);
//			processDownloadResult(mRetCode, size);
//
//		}
//
//		mDownloadThread--;
        return mRetCode;
    }

    public int getRetCode() {
        return mRetCode;
    }

//	public String getRetCodeString() {
//		return sRetCodeString;
//	}

    public int getDownloadPercent() {
        return mPercent;
    }

//	protected void publishProgress(int percent, long total, long downloaded,
//			int speed) {
//		mPercent = percent;
//		mTotalDownload = total;
//		mCurrentDownloaded = downloaded;
//		mDownloadSpeed = speed;
//		if (bEnableSendUpdateProgress && (mHandler != null))
//			mHandler.sendEmptyMessage(FitmixConstant.MSG_PROGRESS_UPDATE);
//	}

    /**
     * 根据返回的code对下载进度文件进行修改
     *
     * @param result
     */
    protected void onPostExecute(int result) {
//		Message message = Message.obtain();
//		message.what = FitmixConstant.MSG_DOWNLOAD_FINISH;
//		message.arg1 = iRequestType;
//		Bundle bundleData = new Bundle();
//		bundleData.putString("resultString", result);
//		bundleData.putString("url", mUrl);
//		bundleData.putString("locale", mLocale);
//		message.setData(bundleData);
//
//		try {
//			if (mHandler != null)
//				mHandler.sendMessage(message);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
    }


}
