package com.fitmix.sdk.common.download;

/**
 * 上传状态
 */
public class UploadStatus {
    /**
     * 上传状态,20:等待
     */
    public static final int STATUS_WAITING = 20;
    /**
     * 上传状态,21:上传中
     */
    public static final int STATUS_UPLOADING = 21;
    /**
     * 上传状态,22:上传完成
     */
    public static final int STATUS_SUCCESS = 22;
    /**
     * 上传状态,23:上传失败
     */
    public static final int STATUS_FAIL = 23;
}
