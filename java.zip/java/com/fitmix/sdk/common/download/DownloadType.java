package com.fitmix.sdk.common.download;

/**
 * 下载的资源类型
 */
public class DownloadType {

    /**
     * 下载的资源类型,-1:所有
     */
    public static final int TYPE_ALL = -1;
    /**
     * 下载的资源类型,0:普通文件
     */
    public static final int TYPE_FILE = 0;
    /**
     * 下载的资源类型,1:音乐文件
     */
    public static final int TYPE_MUSIC = 1;


}
