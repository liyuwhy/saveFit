package com.fitmix.sdk.common.download;

/**
 * 下载状态
 */
public class DownloadStatus {
    /**
     * 下载状态,0:等待
     */
    public static final int STATUS_WAITING = 0;
    /**
     * 下载状态,1:下载中
     */
    public static final int STATUS_DOWNLOADING = 1;
    /**
     * 下载状态,2:下载暂停
     */
    public static final int STATUS_PAUSED = 2;
    /**
     * 下载状态,3:下载完成
     */
    public static final int STATUS_COMPLETED = 3;
    /**
     * 下载状态,4:下载取消
     */
    public static final int STATUS_CANCEL = 4;
    /**
     * 下载状态,5:下载失败
     */
    public static final int STATUS_FAILED = 5;
    /**
     * 下载状态,6:文件已存在
     */
    public static final int STATUS_EXIST = 6;
}
