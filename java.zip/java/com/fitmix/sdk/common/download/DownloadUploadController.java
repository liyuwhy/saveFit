package com.fitmix.sdk.common.download;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.Logger;


public class DownloadUploadController {

    private static DownloadUploadController instance;
    private DownloadUploadService downloadUploadService;
    private DownloadInfoListener downloadListener;
    private UploadInfoListener uploadInfoListener;

    public DownloadUploadService getDownloadUploadService() {
        if (downloadUploadService == null) {
            init();
            Logger.e(Logger.DEBUG_TAG, "DownloadUploadController-->downloadUploadService == null");
        }
        return downloadUploadService;
    }

    public synchronized static DownloadUploadController getInstance() {
        if (instance == null) {
            instance = new DownloadUploadController();
            instance.init();
            Logger.i(Logger.DEBUG_TAG, "PlayerController  --- getInstance > ");
        }
        return instance;
    }

    private Context getContext() {
        return MixApp.getContext();
    }

    private void init() {
        getContext().bindService(new Intent(getContext(), DownloadUploadService.class),
                serviceConnection, Context.BIND_AUTO_CREATE);
    }

    public void setDownloadListener(DownloadInfoListener downloadListener) {
        this.downloadListener = downloadListener;
        if (getDownloadUploadService() != null) {
            getDownloadUploadService().addDownloadListener(this.downloadListener);
        }
    }

    public void removeDownloadListener() {
        if (getDownloadUploadService() != null && downloadListener != null) {
            getDownloadUploadService().removeDownloadListener(downloadListener);
        }
        downloadListener = null;//内存泄漏
    }

    public void setUploadInfoListener(UploadInfoListener uploadInfoListener) {
        this.uploadInfoListener = uploadInfoListener;
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Logger.i(Logger.DEBUG_TAG, "DownloadUploadController-->onServiceConnected");
            if (DownloadUploadService.NAME.equals(name.getClassName())) {
                Logger.i(Logger.DEBUG_TAG, "DownloadUploadController-->equals()");
                downloadUploadService = ((DownloadUploadService.GetServiceClass) service).getService();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (DownloadUploadService.NAME.equals(name.getClassName())) {
                if (downloadUploadService == null)
                    return;

                if (downloadListener != null) {//注销下载状态监听
                    downloadUploadService.removeDownloadListener(downloadListener);
                }

                if (uploadInfoListener != null) {//注销上传状态监听
                    downloadUploadService.removeUploadListener(uploadInfoListener);
                }
            }
        }
    };

    public void startDownloadMusic(Music music) {
        DownloadUploadService.makeDownload(getContext(), music.getUrl(), getLocalPath(music), DownloadType.TYPE_MUSIC);
    }

    public String getLocalPath(Music music) {
        String s = music.getUrl();
        int index = s.lastIndexOf(".");
        if (index == -1) {
            return null;
        }
        String engName = s.substring(index, s.length());
        return FitmixUtil.getMusicPath() + music.getId() + engName;
    }

    /**
     * 恢复下载
     *
     * @param url 资源文件网络url
     */
    public void resumeDownload(String url) {
        if (getDownloadUploadService() != null) {
            getDownloadUploadService().resumeDownload(url);
        }
    }

    /**
     * 暂停下载
     *
     * @param url 资源文件网络url
     */
    public void pauseDownload(String url) {
        /**
         * java.lang.NullPointerException
         * at com.fitmix.sdk.common.download.DownloadUploadController.pauseDownload(DownloadUploadController.java:122)
         * */
        if (getDownloadUploadService() != null) {
            getDownloadUploadService().pauseDownload(url);
        }
    }

    /**
     * 取消下载
     *
     * @param url 资源文件网络url
     */
    public void cancelDownload(String url) {
        if (getDownloadUploadService() != null) {
            getDownloadUploadService().cancelDownload(url);
        }
    }
}
