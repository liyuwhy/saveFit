package com.fitmix.sdk.common.download;

/**
 * 上传信息事件监听
 */
public interface UploadInfoListener {

    /**
     * 上传成功
     */
    void onSuccess(UploadInfo uploadInfo);

    /**
     * 上传失败
     */
    void onFail(UploadInfo uploadInfo, int errorCode);

}
