package com.fitmix.sdk.common.download;

/**
 * 文件上传信息
 */
public class UploadInfo {

    /**
     * 要上传的文件的网络保存url
     */
    private String url;
    /**
     * 要上传的文件本地全路径
     */
    private String localFilePath;
    /**
     * 上传标签
     */
    private String uploadTag;
    /**
     * 文件上传状态,参考 {@link com.fitmix.sdk.common.download.UploadStatus }
     */
    private int status;

    /**
     * 创建文件上传信息
     *
     * @param url           要上传的文件的网络保存url
     * @param localFilePath 要上传的本地文件全路径
     * @param uploadTag     上传标签
     */
    public UploadInfo(String url, String localFilePath, String uploadTag) {
        this.url = url;
        this.localFilePath = localFilePath;
        this.uploadTag = uploadTag;
    }

    public String getLocalFilePath() {
        return localFilePath;
    }

    public void setLocalFilePath(String localFilePath) {
        this.localFilePath = localFilePath;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUploadTag() {
        return uploadTag;
    }

    public void setUploadTag(String uploadTag) {
        this.uploadTag = uploadTag;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
