package com.fitmix.sdk.common.download;

import com.fitmix.sdk.model.database.DownloadInfo;

/**
 * 下载信息事件监听
 */
public interface DownloadInfoListener {
    /**
     * 准备下载
     */
    void onPrepare(DownloadInfo downloadInfo);

    /**
     * 下载中
     */
    void onDownloading(DownloadInfo downloadInfo);

    /**
     * 暂停下载
     */
    void onPause(DownloadInfo downloadInfo);

    /**
     * 下载完成
     */
    void onCompleted(DownloadInfo downloadInfo);

    /**
     * 下载取消
     */
    void onCancel(DownloadInfo downloadInfo);

    /**
     * 下载失败
     */
    void onFail(DownloadInfo downloadInfo, String errorMsg);

    /**
     * 下载文件在本地已存在
     */
    void onExist(DownloadInfo downloadInfo);

}
