package com.fitmix.sdk.common;

import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.model.database.MusicInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Music 和 MusicInfo 相互转化的类
 */
public class MusicParserUtil {

    private static MusicParserUtil instance;

    public static MusicParserUtil getInstance() {
        if (instance == null) {
            instance = new MusicParserUtil();
        }
        return instance;
    }

    public List<Music> getMusicListByMusicInfoList(List<MusicInfo> musicInfoList) {
        if (musicInfoList == null || musicInfoList.isEmpty()) return null;
        List<Music> musicList = new ArrayList<>();
        for (MusicInfo musicInfo : musicInfoList) {
            musicList.add(getMusicByMusicInfo(musicInfo));
        }
        return musicList;
    }

    public List<MusicInfo> getMusicInfoListByMusicList(List<Music> musicList) {
        if (musicList == null || musicList.isEmpty()) return null;
        List<MusicInfo> musicInfoList = new ArrayList<>();
        for (Music music : musicList) {
            musicInfoList.add(getMusicInfoByMusic(music));
        }
        return musicInfoList;
    }

    /**
     * 通过数据库中的音乐信息 MusicInfo 解析成可以同服务器返回数据相同的 Music
     *
     * @param musicInfo 数据库中的音乐信息 {@link com.fitmix.sdk.model.database.MusicInfo}
     * @return Music 服务器返回数据的Music {@link com.fitmix.sdk.bean.Music}
     */
    public Music getMusicByMusicInfo(MusicInfo musicInfo) {
        if (musicInfo == null) return null;
        Music music = new Music();
        music.setId((int) musicInfo.getMusicID());
        music.setUrl(musicInfo.getUrl());
        music.setName(musicInfo.getName());
        music.setAlbumUrl(musicInfo.getAlbumUrl());
        music.setAlbumUrl_2(musicInfo.getAlbumUrl2());
        music.setAuthor(musicInfo.getAuthor());
        music.setIntroduce(musicInfo.getIntroduction());
        music.setBpm(musicInfo.getBpm());
        music.setBaseAuditionCount(musicInfo.getBaseAuditionCount());
        music.setAuditionCount(musicInfo.getAuditionCount());
        music.setCollectNumber(musicInfo.getCollectCount());
        music.setDownloadCount(musicInfo.getDownloadCount());
        music.setShareCount(musicInfo.getShareCount());
        music.setTrackLength(musicInfo.getTrackLength());
        music.setSort(musicInfo.getSort());
        music.setGenre(getListByString(musicInfo.getGenre()));
        music.setScene(getListByString(musicInfo.getScene()));
        music.setLocalFlag(musicInfo.getLocalFlag());
        music.setType(musicInfo.getType() == 2 ? 2 : 1);
        return music;
    }

    /**
     * 通过音乐信息Music 生成数据库表中的一个MusicInfo
     *
     * @param music 服务器返回数据的Music {@link com.fitmix.sdk.bean.Music}
     * @return MusicInfo 数据库中的音乐信息 {@link com.fitmix.sdk.model.database.MusicInfo}
     */
    public MusicInfo getMusicInfoByMusic(Music music) {
        if (music == null) return null;
        MusicInfo musicInfo = new MusicInfo();
        musicInfo.setMusicID(music.getId());
        musicInfo.setUrl(music.getUrl());
        musicInfo.setName(music.getName());
        musicInfo.setAlbumUrl(music.getAlbumUrl());
        musicInfo.setAlbumUrl2(music.getAlbumUrl_2());
        musicInfo.setAuthor(music.getAuthor());
        musicInfo.setIntroduction(music.getIntroduce());
        musicInfo.setBpm(music.getBpm());
        musicInfo.setBaseAuditionCount(music.getBaseAuditionCount());
        musicInfo.setAuditionCount(music.getAuditionCount());
        musicInfo.setCollectCount(music.getCollectNumber());
        musicInfo.setDownloadCount(music.getDownloadCount());
        musicInfo.setShareCount(music.getShareCount());
        musicInfo.setTrackLength(music.getTrackLength());
        musicInfo.setSort(music.getSort());
        musicInfo.setGenre(getStringByList(music.getGenre()));
        musicInfo.setScene(getStringByList(music.getScene()));
        musicInfo.setLocalFlag(music.getLocalFlag());
        musicInfo.setType(music.getType() == 2 ? 2 : 1);
        return musicInfo;
    }

    /**
     * 把数据库 中存储的字符串转为 list
     *
     * @param string such as ,1,2,
     * @return list<Integer> list.get(0) = 1,list.get(1) = 2
     */
    public List<Integer> getListByString(String string) {
        if (string == null || string.isEmpty()) return null;
        String[] stringArr = string.split(",");
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i < stringArr.length; i++) {
            list.add(Integer.parseInt(stringArr[i]));
        }
        return list;
    }

    /**
     * 把list 转为 字符串存进数据库中
     *
     * @param list<Integer> list.get(0) = 1,list.get(1) = 2
     * @return string such as ,1,2,
     */
    public String getStringByList(List<Integer> list) {
        if (list == null || list.isEmpty()) return null;
        StringBuilder sb = new StringBuilder(",");
        for (Integer i : list) {
            sb.append(i).append(",");
        }
        return sb.toString();
    }
}
