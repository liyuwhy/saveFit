package com.fitmix.sdk.common.pedometer;

import com.fitmix.sdk.bean.RunStepInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * 步频、速度、计步距离计算管理,注意内存回收
 */
public class BpmManager {



    private static BpmManager instance;
    /**
     * BPM计算时间窗口,默认30个
     */
    private final int RUN_STEP_BPM_SECONDS = 30;
    private double dDistance;//由步数累计算出的运动距离
    private int iBpm;//当前30个计步点分析出步频
    //    private int iBpmShown;//实时展示给用户的步频
//    private boolean bBpmShowLocked;
    private List<RunStepInfo> mRunStepList;//用于计算BPM的缓存步数信息列表

    private BpmManager() {
        clear();
    }

    public static BpmManager getInstance() {
        if (instance == null) {
            instance = new BpmManager();
        }
        return instance;
    }

    /**
     * 根据步频(每分钟步数)和性别获取 (每步距离/身高)比
     *
     * @param iBpm    步频(每分钟步数)
     * @param bFemale 是否为女性
     * @return 每步距离(M)/身高(CM)
     */
    public static double getStepRatioByBpm(int iBpm, boolean bFemale) {
        //final float RATIO_MALE_1 = 0.32f;
        //final float RATIO_MALE_2 = 0.44f;
        //final float RATIO_MALE_3 = 0.52f;
        //final float RATIO_MALE_4 = 0.60f;

        //final float RATIO_FEMALE_1 = 0.30f;
        //final float RATIO_FEMALE_2 = 0.42f;
        //final float RATIO_FEMALE_3 = 0.50f;
        //final float RATIO_FEMALE_4 = 0.55f;

        final int BPM1 = 60;
        final int BPM2 = 120;
        final int BPM3 = 150;
        final int BPM4 = 180;

        double dRatio;
        if (bFemale) {
            if (iBpm <= BPM1) {
                dRatio = 0.30f;
            } else if (iBpm <= BPM2) {
                //dRatio = RATIO_FEMALE_1 + (RATIO_FEMALE_2 - RATIO_FEMALE_1)
                //* (iBpm - BPM1) / (BPM2 - BPM1);
                dRatio = 0.18 + 0.002 * iBpm;
            } else if (iBpm <= BPM3) {
                //dRatio = RATIO_FEMALE_2 + (RATIO_FEMALE_3 - RATIO_FEMALE_2)
                //* (iBpm - BPM2) / (BPM3 - BPM2);
                dRatio = 0.096 + 0.0027 * iBpm;
            } else if (iBpm <= BPM4) {
                //dRatio = RATIO_FEMALE_3 + (RATIO_FEMALE_4 - RATIO_FEMALE_3)
                //* (iBpm - BPM3) / (BPM4 - BPM3);
                dRatio = 0.245 + 0.0017 * iBpm;
            } else {
                dRatio = 0.55f;
            }
        } else {
            if (iBpm <= BPM1) {
                dRatio = 0.32f;
            } else if (iBpm <= BPM2) {
                //dRatio = RATIO_MALE_1 + (RATIO_MALE_2 - RATIO_MALE_1)
                //* (iBpm - BPM1) / (BPM2 - BPM1);
                dRatio = 0.2 + 0.002 * iBpm;
            } else if (iBpm <= BPM3) {
                //dRatio = RATIO_MALE_2 + (RATIO_MALE_3 - RATIO_MALE_2)
                //* (iBpm - BPM2) / (BPM3 - BPM2);
                dRatio = 0.116 + 0.0027 * iBpm;
            } else if (iBpm <= BPM4) {
                //dRatio = RATIO_MALE_3 + (RATIO_MALE_4 - RATIO_MALE_3)
                //* (iBpm - BPM3) / (BPM4 - BPM3);
                dRatio = 0.115 + 0.0027 * iBpm;
            } else {
                dRatio = 0.60f;
            }
        }

        return dRatio;
    }

    /**
     * 获取用于计算BPM的缓存步数列表
     */
    private List<RunStepInfo> getRunStepList() {
        if (mRunStepList == null)
            mRunStepList = new ArrayList<>(RUN_STEP_BPM_SECONDS);
        return mRunStepList;
    }

    /**
     * 清理资源
     */
    private void clear() {
        dDistance = 0;
        iBpm = 0;
//        iBpmShown = 0;
//        bBpmShowLocked = false;

        clearSteps();
    }

    /**
     * 清除缓存的(用于分析平均步频)步数信息
     */
    public void clearSteps() {
        if (mRunStepList != null)
            getRunStepList().clear();
        mRunStepList = null;
    }

    /**
     * 分析步频信息并计算步数距离
     *
     * @param bFemale   是否是女性
     * @param dHeight   身高,单位为厘米
     * @param iStep     此时的步数
     * @param lStepTime 时间戳
     * @param distance  运动距离,单位米
     */
    public void addStepsToArray(boolean bFemale, double dHeight, int iStep, long lStepTime, long distance) {

        // 1.创建步数信息
        int iLen = getRunStepList().size();
        RunStepInfo info = new RunStepInfo(lStepTime, iStep, distance);
        // 2.获取最近一次保存的步数
        int iOldStep = iStep;
        if (iLen > 0)
            iOldStep = getRunStepList().get(iLen - 1).getStep();
        // 3.新创建的步数信息加入用于计算BPM的缓存步数信息列表
        if (iLen < RUN_STEP_BPM_SECONDS) {
            getRunStepList().add(info);
        } else {
            getRunStepList().remove(0);
            getRunStepList().add(info);
        }
        // 4.分析步频
        parseBpm();
        // 5.根据步数,步频计算运动距离
        int iStepDiff = iStep - iOldStep;
        dDistance += iStepDiff * getStepRatioByBpm(iBpm, bFemale) * dHeight
                / 100;
    }

    /**
     * 获取由步数累计算出的运动距离
     *
     * @return 由步数累计算出的运动距离, 单位为米
     */
    public int getDistance() {
        return (int) dDistance;
    }

    /**
     * 获取当前由实时步频得出的运动速度
     *
     * @param bFemale 是否是女性
     * @param dHeight 身高,单位为厘米
     * @return 运动速度, 单位米/秒
     */
    public double getSpeed(boolean bFemale, double dHeight) {
        return getSpeedByBpm(getBpm(), bFemale, dHeight);
    }

//    /**
//     * 获取当前展示给用户的步频得出的运动速度
//     *
//     * @param bFemale 是否是女性
//     * @param dHeight 身高,单位为厘米
//     * @return 运动速度, 单位米/秒
//     */
//    public double getShowSpeed(boolean bFemale, double dHeight) {
//        return getSpeedByBpm(getShowBpm(), bFemale, dHeight);
//    }

    public void releaseResource() {
        clear();
    }

    /**
     * 获取当前实时分析出步频
     */
    public int getBpm() {
        return iBpm;
    }

//    /**
//     * 获取展示给用户的步频
//     */
//    public int getShowBpm() {
//        return iBpmShown;
//    }
//
//    /**
//     * 设置展示给用户的步频
//     *
//     * @param showBpm
//     */
//    public int setShowBpm(int showBpm) {
//        return iBpmShown = showBpm;
//    }


    /**
     * 获取最近指定秒数内的步频
     *
     * @param iSeconds 指定秒数
     * @return 最近指定秒数内的步频
     */
    private int getBpmInSeconds(int iSeconds) {
        if (iSeconds <= 0)
            return -1;
        int iLen = getRunStepList().size();
        if (iLen <= 1)
            return -1;

        return getBpmAfterTime(getRunStepList().get(iLen - 1).getTime()
                - iSeconds * 1000);
    }

    /**
     * 从缓存步数列表,获取指定下标区间的步频
     *
     * @param iIndex1 下标1
     * @param iIndex2 下标2
     * @return 指定下标区间的步频
     */
    private int getBpmBetween(int iIndex1, int iIndex2) {
        int iLen = getRunStepList().size();
        if (iLen <= 1)
            return -1;
        if (iIndex1 == iIndex2)
            return -1;
        if ((iIndex1 < 0) || (iIndex1 >= iLen))
            return -1;
        if ((iIndex2 < 0) || (iIndex2 >= iLen))
            return -1;

        long lTime = getRunStepList().get(iIndex1).getTime()
                - getRunStepList().get(iIndex2).getTime();

        int steps = getRunStepList().get(iIndex1).getStep()
                - getRunStepList().get(iIndex2).getStep();

        if (lTime == 0)
            return -1;
        if (lTime > 60000) {
            return (int) (1.0f * steps / (lTime / 60000.0f));
        } else {
            return (int) (60000.0f * steps / lTime);
        }
    }

    /**
     * 获取指定时间在缓存步数列表中的下标
     *
     * @return 指定时间在缓存步数列表中的下标
     */
    private int getIndexAfterTime(long time) {
        int iLen = getRunStepList().size();
        int iIndex = -1;
        long lTempTime = time - 400;//TIME_DIFF;
        for (int i = 0; i < iLen - 2; i++) {
            if (getRunStepList().get(i).getTime() >= lTempTime) {
                iIndex = i;
                break;
            }
        }
        return iIndex;
    }

    /**
     * 获取指定时间之后的步频
     *
     * @param lTime 指定时间
     * @return 指定时间之后的步频
     */
    private int getBpmAfterTime(long lTime) {
        int iLen = getRunStepList().size();
        if (iLen <= 1)
            return -1;
        int iIndex = getIndexAfterTime(lTime);
        if (iIndex < 0)
            iIndex = 0;

        return getBpmBetween(iIndex, iLen - 1);
    }

    /**
     * 分析步频
     */
    private void parseBpm() {
        //1.最近30秒的步频
        iBpm = getBpmInSeconds(RUN_STEP_BPM_SECONDS);
        if (iBpm < 0)
            iBpm = 0;
//        //2.分析最近5秒内的步频
//        int iTempBpm = getBpmInSeconds(5);
//        if (iTempBpm >= 60){//BPM_THRESHOLD_FOR_LOCK) {
//            bBpmShowLocked = false;
//            iBpmShown = iBpm;
//        } else {
//            if (!bBpmShowLocked) {
////                iBpmShown = getBpmInSeconds(10);
//                iBpmShown = getBpmBetween(0, 9);
//                if (iBpmShown < 0) iBpmShown = iBpm;
//                bBpmShowLocked = true;
//            }
//        }

    }


    /**
     * 根据步频(每分钟步数)获取运动速度
     *
     * @param bpm     步频(每分钟步数)
     * @param bFemale 是否是女性
     * @param dHeight 身高,单位为厘米
     * @return 运动速度, 单位米/秒
     */
    public static double getSpeedByBpm(int bpm, boolean bFemale, double dHeight) {
        return (bpm * getStepRatioByBpm(bpm, bFemale) * dHeight / 6000);
    }


}
