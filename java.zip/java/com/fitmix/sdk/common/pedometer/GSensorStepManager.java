package com.fitmix.sdk.common.pedometer;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.Logger;

/**
 * 传感器管理,负责传感器数据传入计步算法计步
 */
public class GSensorStepManager {
//    /**
//     * 蓝牙耳机上一个X轴数据
//     */
//    private short oldSensorX;
//    /**
//     * 蓝牙耳机上一个Y轴数据
//     */
//    private short oldSensorY;
//    /**
//     * 蓝牙耳机上一个Z轴数据
//     */
//    private short oldSensorZ;
//    /**
//     * 蓝牙耳机传感器数据丢失次数
//     */
//    private int iSensorDataLostContinue;

    /**
     * 传感器数据是否来源于耳机
     */
    private boolean bFitmixHeadSet;
    /**
     * 是否开始计步
     */
    private boolean bStartStepCount;
    /**
     * 计步算法
     */
    private PedometerBase mStepCount;
    /**
     * 是否用付华强计步算法
     */
    private final boolean STEP_COUNT_BY_FHQ = true;
    //    private OnStepChangeListener mStepChangeListener;//步数更改事件
    private static GSensorStepManager instance;

    /**
     * 步数来源,0:加速传感器结合计步算法计步,
     * 1:Android 4.4自带的计步感应传感器 step detector,
     * 2:Android 4.4自带的计步传感器 step counter
     */
    private int pedometerSource;
//    /** 加速传感器计步算法步数*/
//    private int pedometerSteps;
    /**
     * Android 4.4自带的计步感应传感器步数,目前只用于后台计步
     */
    private int mAndroidDetectSteps;
    /**
     * Android 4.4自带的计步传感器初始步数,目前只用于后台计步
     */
    private int mAndroidInitSteps;
    /**
     * Android 4.4自带的计步传感器步数,目前只用于后台计步
     */
    private int mAndroidSteps;
    /**
     * 是否后台计步,后台计步时可启用Android 4.4自带的计步传感器步数
     */
    private boolean isDaemonStep;

    /**
     * 步数更改事件监听接口
     */
    public interface OnStepChangeListener {
        void onStepChange();
    }

    /**
     * 设置步数更改事件监听
     *
     * @param listener 步数更改事件回调
     */
    public void setOnStepChangeListener(OnStepChangeListener listener) {
//        mStepChangeListener = listener;
        if (mStepCount != null) {
            mStepCount.setOnStepChangeListener(listener);
        }
    }

    /**
     * 最近一次传感器响应时间
     */
    private long mLastSensorTime;

    /**
     * 获取最近一次传感器响应时间
     */
    public long getLastSensorTime() {
        return mLastSensorTime;
    }

    private final SensorEventListener mSensorListener = new SensorEventListener() {

        @Override
        public void onAccuracyChanged(Sensor sensor, int arg1) {
            //不处理
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
//            Log.e("TT", "onSensorChanged bStartStepCount:" + bStartStepCount);
            //1.不处理未开始计步或者用耳机计步的情况
            if (!bStartStepCount)
                return;
            if (isFitmixHeadset())
                return;
            //2.更新最近一次传感器响应时间
            mLastSensorTime = System.currentTimeMillis();
            //3.传感器数据处理
            switch (e.sensor.getType()) {
                case Sensor.TYPE_ACCELEROMETER://加速传感器
                    if (!isPedometerValid())
                        break;
//                    Log.e("TT", "onSensorChanged TYPE_ACCELEROMETER");
                    //long now = System.currentTimeMillis();
                    mStepCount.processAcceleratorData(e.values[0], e.values[1], e.values[2], System.currentTimeMillis());
                    break;

                case Sensor.TYPE_STEP_DETECTOR://Android 4.4自带计步感应传感器
//                    if(e.values[0] == 1.0f){//步数有效,meizu value 为0?
//                        Log.e("TT", "onSensorChanged TYPE_STEP_DETECTOR valid");
                    mAndroidDetectSteps++;
//                    if (mStepChangeListener != null) {
//                        mStepChangeListener.onStepChange();
//                    }
//                    }
//                    Log.e("TT", "onSensorChanged TYPE_STEP_DETECTOR steps:" + mAndroidDetectSteps+" value:"+e.values[0]
//                            +" mStepChangeListener is null:"+(mStepChangeListener == null));
                    break;

                case Sensor.TYPE_STEP_COUNTER://Android 4.4自带计步传感器
                    if (mAndroidInitSteps > 0) {
                        mAndroidSteps = (int) (e.values[0]) - mAndroidInitSteps;
                    } else {//小于等于0 或开始计步时,设置初始步数
                        mAndroidInitSteps = (int) (e.values[0]);
                    }
//                    if (mStepChangeListener != null) {
//                        mStepChangeListener.onStepChange();
//                    }
//                    Logger.e("TT", "onSensorChanged TYPE_STEP_COUNTER mAndroidInitSteps:"+mAndroidInitSteps+ ",steps:"+mAndroidSteps);
                    break;
            }
        }
    };

    /**
     * 释放资源
     */
    public void releaseResource() {
        if (mStepCount != null)
            mStepCount.release();
        mStepCount = null;
    }

    public static GSensorStepManager getInstance() {
        if (instance == null) {
            instance = new GSensorStepManager();
        }
        return instance;
    }

    private GSensorStepManager() {
        init();
    }

    private void init() {
        if (mStepCount == null) {
            if (STEP_COUNT_BY_FHQ) {
                mStepCount = new FhqStepCount();
                Logger.i(Logger.DEBUG_TAG, "pedometer algorithm FhqStepCount");
            } else {
                mStepCount = new ThresholdStepCount();
                Logger.i(Logger.DEBUG_TAG, "pedometer algorithm ThresholdStepCounter");
            }
        }
//        resetData();
        bStartStepCount = false;
    }

//    /**
//     * 重置
//     */
//    private void resetData() {
//        oldSensorX = 0;
//        oldSensorY = 0;
//        oldSensorZ = 0;
//        iSensorDataLostContinue = 0;
//
//    }

    /**
     * 传感器数据是否来自耳机
     *
     * @return true:是,false:否
     */
    public boolean isFitmixHeadset() {
        return bFitmixHeadSet;
    }

    /**
     * 设置耳机传感器数据计步
     */
    public void changeToFitmixHeadset() {
        stopStep();
        this.bFitmixHeadSet = true;
        startStep();
    }

    /**
     * 设置手机传感器数据计步
     */
    public void changeToPhone() {
        stopStep();
        this.bFitmixHeadSet = false;
        startStep();
    }

    /**
     * 设置计步模式
     *
     * @param mode 1:室外跑步模式,2:室内跑步模式,3:走路模式
     */
    public void setMode(int mode) {
        if (mStepCount != null) {
            mStepCount.setMode(mode);
        }
        isDaemonStep = mode == PedometerBase.MODE_WALK;
    }

    /**
     * 重置步数
     */
    public void resetStep() {
        if (!isPedometerValid())
            return;
        mStepCount.resetStepCount();
        mAndroidDetectSteps = 0;
        mAndroidInitSteps = 0;
        mAndroidSteps = 0;
    }

    /**
     * 重置android自带计步器数据
     */
    public void resetAndroidStep() {
        mAndroidDetectSteps = 0;
        mAndroidInitSteps = 0;
        mAndroidSteps = 0;
    }

    /**
     * 计步算法是否初始化
     *
     * @return true:是,false:否
     */
    private boolean isPedometerValid() {
        return (mStepCount != null);
    }

    /**
     * 获取步数
     *
     * @return 步数
     */
    public int getSteps() {
        if (!isPedometerValid())
            return 0;
        if (pedometerSource == 0) {
            return mStepCount.getStepCount();
        } else if (pedometerSource == 1) {
            return mAndroidDetectSteps;
        } else if (pedometerSource == 2) {
            return mAndroidSteps;
        }
        return 0;
    }

    /**
     * 注册手机传感器
     */
    private void registerSensorListener(Context context,
                                        SensorEventListener listener) {
        if (context == null || listener == null)
            return;

//        Log.i("TT","GSensorStepManager-->registerSensorListener");
        SensorManager sensorManager = (SensorManager) context
                .getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null)
            return;

//        Log.i("TT","GSensorStepManager-->registerSensorListener 1 SDK_INT:"+(Build.VERSION.SDK_INT));
        Sensor stepDetectSensor = null;//Android 4.4自带的计步感应传感器
        Sensor androidStepSensor = null;//Android 4.4自带的计步传感器
        // 1.如果手机支持android自带的计步传感器,优先用计步感应传感器
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                boolean hasDetectSensor = context.getPackageManager().hasSystemFeature("android.hardware.sensor.stepdetector");
                boolean hasStepSensor = context.getPackageManager().hasSystemFeature("android.hardware.sensor.stepcounter");
                stepDetectSensor = sensorManager
                        .getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
                if (hasDetectSensor && stepDetectSensor != null && isDaemonStep) {//跑步时,不用该传感器,部分用户手机步数偏少
                    sensorManager.registerListener(listener, stepDetectSensor,
                            SensorManager.SENSOR_DELAY_NORMAL);
//                    Log.i("TT", "GSensorStepManager-->register stepDetectSensor" + (stepDetectSensor != null));
                    pedometerSource = 1;
                } else {
                    stepDetectSensor = null;
                    androidStepSensor = sensorManager
                            .getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
                    if (hasStepSensor && androidStepSensor != null && isDaemonStep) {//跑步时,不用该传感器,因为读数不能实时
                        sensorManager.registerListener(listener, androidStepSensor,
                                SensorManager.SENSOR_DELAY_NORMAL);
//                        Log.i("TT", "GSensorStepManager-->register stepCounterSensor" + (androidStepSensor != null));
                        pedometerSource = 2;
                    } else {
                        androidStepSensor = null;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                stepDetectSensor = null;
                androidStepSensor = null;
            }
        }

//        Log.i("TT","GSensorStepManager-->registerSensorListener 2 stepDetectSensor is null:"+(stepDetectSensor == null)
//        +" androidStepSensor is null:"+(androidStepSensor == null));
        // 2.手机不支持android自带的计步传感器,用加速度传感器结合计步算法
        if (stepDetectSensor == null && androidStepSensor == null) {
            Sensor accelerometerSensor = sensorManager
                    .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (accelerometerSensor == null)
                return;
            sensorManager.registerListener(listener, accelerometerSensor,
                    SensorManager.SENSOR_DELAY_GAME);//GAME
            pedometerSource = 0;
        }
        Logger.i(Logger.DEBUG_TAG, "GSensorStepManager-->registerSensorListener pedometerSource:" + pedometerSource);
    }

    /**
     * 注册手机传感器
     */
    public void registerSensorListener() {
        registerSensorListener(MixApp.getContext(), mSensorListener);
    }

    /**
     * 注销手机传感器
     */
    private void unregisterSensorListener(Context context,
                                          SensorEventListener listener) {
        if (context == null || listener == null)
            return;
        SensorManager sensorManager = (SensorManager) context
                .getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null)
            return;
        sensorManager.unregisterListener(listener);
        mLastSensorTime = 0;//清空最近一次传感器响应时间
//        Log.i("TT", "unregisterSensorListener");
    }

    /**
     * 注销手机传感器
     */
    public void unregisterSensorListener() {
        unregisterSensorListener(MixApp.getContext(), mSensorListener);
    }

    /**
     * 开始计步,注意调用此方法前要设置好计步模式.即调用{@link com.fitmix.sdk.common.pedometer.GSensorStepManager#setMode(int)}
     */
    public void startStep() {
//        Log.i("TT","GSensorStepManager-->startStep bStartStepCount:" +bStartStepCount +" bFitmixHeadSet:"+bFitmixHeadSet +" isPedometerValid():"+isPedometerValid());
        if (!isPedometerValid())
            return;
        if (bStartStepCount)
            return;
        if (!bFitmixHeadSet)
            registerSensorListener();

//        resetData();
        mStepCount.startDetection();
        bStartStepCount = true;
    }

    /**
     * 停止计步
     */
    public void stopStep() {
        if (!isPedometerValid())
            return;
        if (!bStartStepCount)
            return;
        if (!bFitmixHeadSet)
            unregisterSensorListener();
        mStepCount.stopDetection();
        bStartStepCount = false;
    }


}
