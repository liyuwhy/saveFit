package com.fitmix.sdk.common.pedometer;

/**
 * 计步算法抽象基类
 */
public abstract class PedometerBase {
    /**
     * 室外跑步模式
     */
    public static final int MODE_RUN_OUTDOOR = 1;
    /**
     * 室内跑步模式
     */
    public static final int MODE_RUN_INDOOR = 2;
    /**
     * 走路模式
     */
    public static final int MODE_WALK = 3;

    /**
     * 运动模式,PedometerBase.MODE_RUN_INDOOR 0:室外跑步,PedometerBase.MODE_RUN_INDOOR 1:室内跑步,PedometerBase.MODE_WALK 2:走路
     */
    protected int mode;//运动模式

    /**
     * 步数更改事件
     */
    protected GSensorStepManager.OnStepChangeListener mStepChangeListener;

    public PedometerBase() {
        init();
    }

    /**
     * 初始化计步算法
     */
    protected abstract void init();// {mode = MODE_RUN_OUTDOOR;}

    /**
     * 设置运动模式
     *
     * @param mode 运动模式,PedometerBase.MODE_RUN_INDOOR 0:室外跑步,PedometerBase.MODE_RUN_INDOOR 1:室内跑步,PedometerBase.MODE_WALK 2:走路
     */
    protected void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * 获取运动模式
     *
     * @return 0:室外跑步,1:室内跑步,2:走路
     */
    protected int getMode() {
        return mode;
    }

    /**
     * 开始计步检测
     */
    protected abstract void startDetection();

    /**
     * 停止计步检测
     */
    protected abstract void stopDetection();

    /**
     * 重置步数
     */
    protected abstract void resetStepCount();

    /**
     * 获取步数
     */
    protected abstract int getStepCount();

    /**
     * 设置步数更改事件监听
     *
     * @param listener 步数更改事件回调
     */
    protected void setOnStepChangeListener(GSensorStepManager.OnStepChangeListener listener) {
        mStepChangeListener = listener;
    }

    /**
     * 处理加速传感器数据
     *
     * @param x    加速传感器X轴数据
     * @param y    加速传感器Y轴数据
     * @param z    加速传感器Z轴数据
     * @param time 时间戳
     */
    protected abstract int processAcceleratorData(float x, float y, float z, long time);

    /**
     * 清理释放资源
     */
    protected abstract void release();

}
