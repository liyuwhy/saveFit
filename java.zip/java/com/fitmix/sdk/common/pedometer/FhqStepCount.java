package com.fitmix.sdk.common.pedometer;

/**
 * 付华强计步算法
 */
public class FhqStepCount extends PedometerBase {
    private final int SECOND_FOR_STORE = 5; // 缓冲保留几秒的数据
    //private final int FRAMES_IN_ONE_SECOND = 25; // 每秒数据的帧数
    private final int MAX_NORMAL_WAVE_IN_ONE_SECOND = 4; // 每秒正常波浪数
    //private final int DATA_BUFFER_SIZE = SECOND_FOR_STORE * FRAMES_IN_ONE_SECOND;// 数据缓冲大小
    private final int PEAK_BUFFER_SIZE = SECOND_FOR_STORE * MAX_NORMAL_WAVE_IN_ONE_SECOND;//波峰缓冲大小
    private final int TREND_UP = 1; // 向上趋势标志
    private final int TREND_DOWN = -1; // 向下趋势标志
    private final int WAVE_PEAK = 1; // 波峰标志
    private final int WAVE_TROUGH = -1; // 波谷标志
    private final int STEP_CACHE_ARRAY_SIZE = 10;

    private int iTrendLast; // 上一个趋势
    private int iValueLast; // 上一个值
    private long iTimeLast; // 上次时间
    private int iLastAddTrend;
    private int steps; // 步数
    private boolean bWorking; // 是否正在工作
    private long lStartTime; // 开始工作时间

    private FhqDataBuffer peakBuffer; // 波峰buffer
    private FhqDataBuffer troughBuffer; // 波谷buffer
    //	private FhqDataBuffer dataBuffer; // 数据buffer
    private FhqDataBuffer stepBuffer; // 步数buffer
    private int noiseLevel;//去噪等级

    /**
     * 上一次传感器数据处理时间戳
     */
    private long lLastSensorDataTime;

    /**
     * 数据缓冲类型
     */
    private class FhqDataBuffer {
        private int arrayValue[];//值数组
        private long arrayTime[];//值存储时的时间戳数组
        private int iWriteIndex;//下一次写数据的下标
        private int iDataCount;//数组大小
        private int iBufferSize;//数组容量
        private int valueTotal; //数组值总和

        public FhqDataBuffer(int size) {
            iBufferSize = size;
            if (arrayValue == null)
                arrayValue = new int[iBufferSize];
            if (arrayTime == null)
                arrayTime = new long[iBufferSize];
            reset();
        }

        public void reset() {
            iDataCount = 0;
            iWriteIndex = 0;
            valueTotal = 0;
        }

        /**
         * 获取数据缓冲数组大小
         */
        public int getDataCount() {
            return iDataCount;
        }

        /**
         * 从值数组中获取指定下标的值
         *
         * @param index 下标
         */
        public int getValueOfIndex(int index) {
            int startIndex = getStartIndex();
            return arrayValue[(startIndex + index) % iBufferSize];
        }

        /**
         * 将值数组中所有值设置为指定的值
         *
         * @param value 指定的值
         */
        public void clearValuesTo(int value) {
            for (int i = 0; i < iBufferSize; i++) {
                arrayValue[i] = value;
            }
        }

        private boolean isDataBufferValid() {
            if (arrayValue == null || arrayTime == null)
                return false;
            return iBufferSize > 0;
        }

        private int getLastIndex() {
            return (iWriteIndex - 1 + iBufferSize) % iBufferSize;
        }

        /**
         * 向数据缓冲添加值
         *
         * @param value 值
         * @param time  值对应的时间戳
         */
        public void addToBuffer(int value, long time) {
            if (!isDataBufferValid())
                return;
            if (iDataCount >= iBufferSize)
                valueTotal -= arrayValue[iWriteIndex];

            arrayValue[iWriteIndex] = value;
            arrayTime[iWriteIndex] = time;
            iWriteIndex = (iWriteIndex + 1) % iBufferSize;
            iDataCount++;
            valueTotal += value;
            if (iDataCount > iBufferSize)
                iDataCount = iBufferSize;
        }

        /**
         * 获取最近一个添加的值
         */
        public int getLastValue() {
            if (!isDataBufferValid())
                return -1;
            if (iDataCount <= 0)
                return -1;
            return arrayValue[getLastIndex()];
        }

        /**
         * 获取最近一个添加的值所对应的时间
         */
        public long getLastTime() {
            if (!isDataBufferValid())
                return -1;
            if (iDataCount <= 0)
                return -1;
            return arrayTime[getLastIndex()];
        }

        /**
         * 将最近一个添加的值回滚
         */
        public void rollBack() {
            if (!isDataBufferValid())
                return;
            if (iDataCount <= 0)
                return;
            iDataCount--;

            valueTotal -= arrayValue[getLastIndex()];
            iWriteIndex = getLastIndex();
        }

        private int getStartIndex() {
            int iStartIndex = iWriteIndex;
            if (iDataCount < iBufferSize)
                iStartIndex = (iWriteIndex - iDataCount + iBufferSize)
                        % iBufferSize;
            return iStartIndex;
        }

        public long getAverageTimeSpace() {
            if (!isDataBufferValid())
                return -1;
            if (iDataCount < 2)
                return -1;

            return (getLastTime() - arrayTime[getStartIndex()])
                    / (iDataCount - 1);

        }

        public int getAverageValueQuick() {
            if (!isDataBufferValid())
                return -1;
            if (iDataCount <= 0)
                return -1;
            return valueTotal / iDataCount;
        }

//		@SuppressWarnings("unused")
//		public int getAverageValueNormal() {
//			if (!isDataBufferValid())
//				return -1;
//			if (iDataCount <= 0)
//				return -1;
//			int iStartIndex = getStartIndex();
//
//			int iValue = 0;
//			for (int i = 0; i < iDataCount; i++) {
//				iValue += arrayValue[(iStartIndex + i) % iBufferSize];
//			}
//			iValue /= iDataCount;
//			return iValue;
//		}
    }

    public FhqStepCount() {
        init();
        resetStepCount();
    }

    // region ===============================复写继承基类方法========================================
    @Override
    public void init() {
        lLastSensorDataTime = 0;
        if (peakBuffer == null)
            peakBuffer = new FhqDataBuffer(PEAK_BUFFER_SIZE);
        if (troughBuffer == null)
            troughBuffer = new FhqDataBuffer(PEAK_BUFFER_SIZE);
//		if (dataBuffer == null)
//			dataBuffer = new FhqDataBuffer(DATA_BUFFER_SIZE);
        if (stepBuffer == null)
            stepBuffer = new FhqDataBuffer(STEP_CACHE_ARRAY_SIZE);
        setMode(MODE_RUN_OUTDOOR);
    }

    @Override
    public void release() {
        peakBuffer = null;
        troughBuffer = null;
//		dataBuffer = null;
        stepBuffer = null;
    }

    @Override
    public void setMode(int mode) {
        super.setMode(mode);
        switch (getMode()) {
            case MODE_RUN_INDOOR:
                noiseLevel = 150;
                break;
            case MODE_RUN_OUTDOOR:
                noiseLevel = 200;
                break;
            case MODE_WALK:
                noiseLevel = 400;
                break;
        }
    }

    @Override
    public void startDetection() {
        lLastSensorDataTime = 0;
        clearStepArrayData();
        bWorking = true;
        lStartTime = System.currentTimeMillis();//Calendar.getInstance().getTimeInMillis();
    }

    @Override
    public void stopDetection() {
        //不处理
    }

    @Override
    public void resetStepCount() {
        clearStepArrayData();
        steps = 0;
        lLastSensorDataTime = 0;
    }

    @Override
    public int getStepCount() {
        switch (getMode()) {
            default:
            case MODE_RUN_OUTDOOR:
            case MODE_RUN_INDOOR:
                return steps >> 1;
            case MODE_WALK:
                return getStepsByStepBuffer();
        }

    }

    /**
     * 处理加速传感器数据
     *
     * @param x    加速传感器X轴数据
     * @param y    加速传感器Y轴数据
     * @param z    加速传感器Z轴数据
     * @param time 时间戳
     * @return |x|+|y|+|z|
     */
    @Override
    public int processAcceleratorData(float x, float y, float z, long time) {
        if (!checkValid())
            return 0;
        if (!bWorking)
            return 0;
        //每40ms取样一次
        long timeSpace = time - lLastSensorDataTime;
        if (timeSpace < 40)
            return 0;

        if (timeSpace >= 60) {
            if ((lLastSensorDataTime > 0) && (timeSpace >= 80)) {
                //mSensorLostDataCount += timeSpace / 40 - 1;
            }
            lLastSensorDataTime = time;
        } else {
            lLastSensorDataTime += 40;
        }

        if ((time - lStartTime) <= 1000)
            return 0;

        int x1 = (int) (x * 104.42);//1024 / SensorManager.GRAVITY_EARTH);
        int y1 = (int) (y * 104.42);//1024 / SensorManager.GRAVITY_EARTH);
        int z1 = (int) (z * 104.42);//1024 / SensorManager.GRAVITY_EARTH);

        int value = Math.abs(x1) + Math.abs(y1) + Math.abs(z1);//|x|+|y|+|z|
//        dataBuffer.addToBuffer(value, time);
        parseData(value, time);
        if ((time - stepBuffer.getLastTime()) >= 1000) {
            stepBuffer.addToBuffer(steps, time);
        }
        return value;
    }

    // endregion ===============================复写继承基类方法========================================

    private boolean checkValid() {
        return !(peakBuffer == null || troughBuffer == null || stepBuffer == null);//|| dataBuffer == null
    }

    private void clearStepArrayData() {
        if (!checkValid())
            return;
        iTrendLast = 0;
        iValueLast = 0;
        iTimeLast = 0;
        iLastAddTrend = 0;
        bWorking = false;
//		dataBuffer.reset();
        peakBuffer.reset();
        troughBuffer.reset();
        stepBuffer.reset();
    }

    /**
     * 获取步数
     */
    private int getStepsByStepBuffer() {
        if (stepBuffer == null) return 0;
        if (stepBuffer.getDataCount() < STEP_CACHE_ARRAY_SIZE) return 0;
        int value = stepBuffer.getValueOfIndex(2);
        if (stepBuffer.getValueOfIndex(0) == stepBuffer.getValueOfIndex(1) &&
                stepBuffer.getValueOfIndex(STEP_CACHE_ARRAY_SIZE - 1) == stepBuffer.getValueOfIndex(STEP_CACHE_ARRAY_SIZE - 3)) {
            value = stepBuffer.getValueOfIndex(0);
            steps = value;
            stepBuffer.clearValuesTo(steps);
        }
        return value >> 1;
    }

    private void parseData(int value, long time) {
//		if (!checkValid())
//			return;
        boolean bAdded = addToPeakOrTrough(value, time);
        if (bAdded) {
            steps++;
            if (mStepChangeListener != null) {
                mStepChangeListener.onStepChange();
            }
        }
    }

    private void setLastValue(int value, long time, int trend) {
        iValueLast = value;
        iTimeLast = time;
        iTrendLast = trend;
    }

    /**
     * 判断波峰波谷,核心算法
     *
     * @param value 加速传感器复合轴值|x|+|y|+|z|
     * @param time  加速传感器复合轴值所对应的时间戳
     * @return true:计步有效,false:计步无效
     */
    private boolean addToPeakOrTrough(int value, long time) {
        if (!checkValid())
            return false;
        if (value == iValueLast)
            return false;
        if (time <= iTimeLast)
            return false;

        boolean bPeak = false;
        boolean bTrough = false;
        int iTrend = 0;
        if (value > iValueLast)
            iTrend = TREND_UP; //上升趋势
        else if (value < iValueLast)
            iTrend = TREND_DOWN;//下降趋势

        if ((iTrendLast == TREND_UP) && (iTrend == TREND_DOWN))
            bPeak = true; // 产生波峰
        else if ((iTrendLast == TREND_DOWN) && (iTrend == TREND_UP))
            bTrough = true; // 产生波谷

        boolean bNeedAdd = (bPeak || bTrough);
        if (!bNeedAdd) {
            setLastValue(value, time, iTrend);
            return false;
        }

        long timeSpace;
        int peakValue = peakBuffer.getAverageValueQuick(); // 平均波峰值
        int troughValue = troughBuffer.getAverageValueQuick(); // 平均波谷值
        if (bPeak) {
            timeSpace = peakBuffer.getAverageTimeSpace(); // 平均波峰时间间隔
        } else {
            timeSpace = troughBuffer.getAverageTimeSpace(); // 平均波谷时间间隔
        }
        long timeSpaceThreshold = timeSpace / 3;

        if (iLastAddTrend == WAVE_PEAK) { // 上次是波峰
            if (bTrough) { // 本次是波谷
                int valueDiff = Math.abs(peakBuffer.getLastValue() - value); // 和波峰的差值
                if (valueDiff <= noiseLevel)
                    bNeedAdd = false; // 消除噪声
                else if (valueDiff < ((peakValue - troughValue) / 2)) { // 差值小于半山腰
                    if ((time - peakBuffer.getLastTime()) <= timeSpaceThreshold)
                        bNeedAdd = false; // 时间间隔小于峰值间隔阀值
                    else { // 可能从运动到停止过程,暂定OK

                    }
                } else { // 过了半山腰,暂定OK

                }
            } else { // 本次又是波峰(因为前一个波谷被过滤掉)
                if (value > peakBuffer.getLastValue()) { // 一峰更比一峰高
                    peakBuffer.rollBack(); // 回退,重新记录峰值
                    steps--;
                } else { // 没有上一个峰值高,忽略
                    bNeedAdd = false;
                }
            }
        } else if (iLastAddTrend == WAVE_TROUGH) { // 上次是波谷
            if (bPeak) { // 本次是波峰
                int valueDiff = Math.abs(value - troughBuffer.getLastValue()); // 和波峰的差值
                if (valueDiff <= noiseLevel)
                    bNeedAdd = false; // 消除噪声
                else if ((valueDiff < (peakValue - troughValue) / 2)) { // 差值小于半山腰
                    if ((time - troughBuffer.getLastTime()) <= timeSpaceThreshold)
                        bNeedAdd = false; // 时间间隔小于波谷间隔1/4
                    else { // 可能从运动到停止过程

                    }
                } else { // 过了半山腰,暂定OK

                }
            } else { // 本次又是波谷(因为前一个波峰被过滤掉)
                if (value < troughBuffer.getLastValue()) { // 一谷更比一谷低
                    peakBuffer.rollBack(); // 回退,重新记录峰值
                    steps--;
                } else { // 没有上一个谷值低,忽略
                    bNeedAdd = false;
                }
            }

        }

        if (bNeedAdd) {
            if (bPeak && (iLastAddTrend != WAVE_PEAK)) { // 加入新的波峰
                iLastAddTrend = WAVE_PEAK;
                peakBuffer.addToBuffer(iValueLast, iTimeLast);
            } else if (bTrough && (iLastAddTrend != WAVE_TROUGH)) { // 加入新的波谷
                iLastAddTrend = WAVE_TROUGH;
                troughBuffer.addToBuffer(iValueLast, iTimeLast);
            }

        }
        setLastValue(value, time, iTrend);

        return bNeedAdd;
    }

}
