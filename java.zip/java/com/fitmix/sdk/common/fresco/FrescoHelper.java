package com.fitmix.sdk.common.fresco;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;

import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.DataSource;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.fitmix.sdk.common.ImageHelper;

import java.io.File;

/**
 * Facebook Fresco帮助类
 */
public class FrescoHelper {

    /**
     * Bitmap保存成功回调
     */
    public interface BitmapSaveCallback {
        /**
         * Bitmap保存成功后要继续的操作
         *
         * @param url Bitmap对应网络的url
         */
        void afterBitmapSave(String url);
    }

    /**
     * Fresco加载图片的同时保存图片到本地
     *
     * @param context   上下文
     * @param url       远程url
     * @param localPath 保存在本地的文件名,绝对路径
     */
    public static void saveImage2Local(final Context context, String url, final String localPath) {
        saveImage2Local(context, url, localPath, null);
    }


    /**
     * Fresco加载图片的同时保存图片到本地
     *
     * @param context   上下文
     * @param url       远程url
     * @param localPath 保存在本地的文件名,绝对路径
     * @param callback  Bitmap保存成功回调
     */
    public static void saveImage2Local(final Context context, final String url, final String localPath, final BitmapSaveCallback callback) {
        if (TextUtils.isEmpty(url) || TextUtils.isEmpty(localPath)) {
            return;
        }
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(url))
                .setProgressiveRenderingEnabled(true)
                .build();

        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, context);

        dataSource.subscribe(new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(Bitmap bitmap) {
                ImageHelper.saveBitmap2File(bitmap, localPath);
                if (callback != null) {
                    callback.afterBitmapSave(url);
                }
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
            }
        }, CallerThreadExecutor.getInstance());
    }


    /**
     * 根据控件的宽度、高度设置重新计算大小的图片,防止在android 5.0以上产生oom
     * <p>
     * Resize 有以下几个限制：
     * 目前，只有 JPEG 图片可以修改尺寸。
     * 对于产生的图片的尺寸，只能粗略地控制。图片不能修改为确定的尺寸，只能通过支持的修改选项来变化。这意味着即使是修改后的图片，也需要在展示前进行 scale 操作。
     * 只支持以下的修改选项： N / 8，1 <= N <= 8
     * Resize 是由软件执行的，相比硬件加速的 scale 操作较慢。
     *
     * @param view SimpleDraweeView控件
     * @param uri  图片资源url
     */
    public static void getResizeController(SimpleDraweeView view, Uri uri) {
        if (uri == null || view == null) {
            return;
        }
        ImageRequestBuilder imageRequestBuilder =
                ImageRequestBuilder.newBuilderWithSource(uri);

        imageRequestBuilder.setResizeOptions(new ResizeOptions(
                view.getLayoutParams().width,
                view.getLayoutParams().height));
        DraweeController draweeController = Fresco.newDraweeControllerBuilder()
                .setImageRequest(imageRequestBuilder.build())
                .setOldController(view.getController())
                //.setAutoPlayAnimations(true)
                .build();
        view.setController(draweeController);
    }

    /**
     * 根据控件的宽度、高度设置重新计算大小的图片,防止在android 5.0以上产生oom
     * <p>
     * Resize 有以下几个限制：
     * 目前，只有 JPEG 图片可以修改尺寸。
     * 对于产生的图片的尺寸，只能粗略地控制。图片不能修改为确定的尺寸，只能通过支持的修改选项来变化。这意味着即使是修改后的图片，也需要在展示前进行 scale 操作。
     * 只支持以下的修改选项： N / 8，1 <= N <= 8
     * Resize 是由软件执行的，相比硬件加速的 scale 操作较慢。
     *
     * @param targetView SimpleDraweeView控件
     * @param filepath   图片资源文件全路径
     */
    public static void getResizeController(SimpleDraweeView targetView, String filepath) {
        Uri uri = Uri.fromFile(new File(filepath));

        ImageRequest request = ImageRequestBuilder.newBuilderWithSource(uri)
                //根据View的尺寸放缩图片
                .setResizeOptions(new ResizeOptions(targetView.getWidth(), targetView.getHeight()))
                .build();

        DraweeController controller = Fresco.newDraweeControllerBuilder()
                .setOldController(targetView.getController())
                .setImageRequest(request)
                .setCallerContext(uri)
                .build();

        targetView.setController(controller);
    }

}
