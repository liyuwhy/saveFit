package com.fitmix.sdk.common.vrlibs.strategy.projection;

import android.content.Context;

import com.fitmix.sdk.common.vrlibs.MD360DirectorFactory;
import com.fitmix.sdk.common.vrlibs.strategy.IModeStrategy;

public abstract class AbsProjectionStrategy implements IModeStrategy, IProjectionMode {

    @Override
    public void onResume(Context context) {

    }

    @Override
    public void onPause(Context context) {

    }

    protected MD360DirectorFactory hijackDirectorFactory() {
        return null;
    }
}
