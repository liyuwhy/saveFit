package com.fitmix.sdk.common.vrlibs.strategy.interactive;

import android.content.Context;

public interface IInteractiveMode {

    void onResume(Context context);

    void onPause(Context context);

    boolean handleDrag(int distanceX, int distanceY);
}
