package com.fitmix.sdk.common.vrlibs.strategy.projection;

import android.app.Activity;
import android.graphics.RectF;

import com.fitmix.sdk.common.vrlibs.objects.MDAbsObject3D;
import com.fitmix.sdk.common.vrlibs.objects.MDDome3D;
import com.fitmix.sdk.common.vrlibs.objects.MDObject3DHelper;

public class DomeProjection extends AbsProjectionStrategy {

    MDAbsObject3D object3D;

    private float mDegree;

    private boolean mIsUpper;

    private RectF mTextureSize;

    public DomeProjection(RectF textureSize, float degree, boolean isUpper) {
        this.mTextureSize = textureSize;
        this.mDegree = degree;
        this.mIsUpper = isUpper;
    }

    @Override
    public void on(Activity activity) {
        object3D = new MDDome3D(mTextureSize, mDegree, mIsUpper);
        MDObject3DHelper.loadObj(activity, object3D);
    }

    @Override
    public void off(Activity activity) {

    }

    @Override
    public boolean isSupport(Activity activity) {
        return true;
    }

    @Override
    public MDAbsObject3D getObject3D() {
        return object3D;
    }
}
