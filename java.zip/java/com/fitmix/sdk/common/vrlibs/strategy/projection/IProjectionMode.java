package com.fitmix.sdk.common.vrlibs.strategy.projection;

import com.fitmix.sdk.common.vrlibs.objects.MDAbsObject3D;

public interface IProjectionMode {
    MDAbsObject3D getObject3D();
}
