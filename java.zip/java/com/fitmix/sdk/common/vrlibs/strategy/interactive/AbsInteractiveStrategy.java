package com.fitmix.sdk.common.vrlibs.strategy.interactive;

import com.fitmix.sdk.common.vrlibs.MD360Director;
import com.fitmix.sdk.common.vrlibs.strategy.IModeStrategy;

import java.util.List;

public abstract class AbsInteractiveStrategy implements IModeStrategy, IInteractiveMode {

    private InteractiveModeManager.Params params;

    public AbsInteractiveStrategy(InteractiveModeManager.Params params) {
        this.params = params;
    }

    public InteractiveModeManager.Params getParams() {
        return params;
    }

    protected List<MD360Director> getDirectorList() {
        return params.projectionModeManager.getDirectors();
    }
}
