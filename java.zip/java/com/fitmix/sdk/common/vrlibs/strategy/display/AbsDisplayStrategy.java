package com.fitmix.sdk.common.vrlibs.strategy.display;

import android.content.Context;

import com.fitmix.sdk.common.vrlibs.strategy.IModeStrategy;

public abstract class AbsDisplayStrategy implements IModeStrategy, IDisplayMode {

    @Override
    public void onResume(Context context) {

    }

    @Override
    public void onPause(Context context) {

    }
}
