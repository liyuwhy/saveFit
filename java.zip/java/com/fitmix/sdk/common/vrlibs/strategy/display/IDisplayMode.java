package com.fitmix.sdk.common.vrlibs.strategy.display;

public interface IDisplayMode {
    int getVisibleSize();
}
