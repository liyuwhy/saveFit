package com.fitmix.sdk.common.vrlibs.strategy.projection;

import android.app.Activity;

import com.fitmix.sdk.common.vrlibs.MD360Director;
import com.fitmix.sdk.common.vrlibs.MD360DirectorFactory;
import com.fitmix.sdk.common.vrlibs.objects.MDAbsObject3D;
import com.fitmix.sdk.common.vrlibs.objects.MDObject3DHelper;
import com.fitmix.sdk.common.vrlibs.objects.MDStereoSphere3D;

public class StereoSphereProjection extends AbsProjectionStrategy {

    private static class FixedDirectorFactory extends MD360DirectorFactory {
        @Override
        public MD360Director createDirector(int index) {
            return MD360Director.builder().build();
        }
    }

    private MDAbsObject3D object3D;

    @Override
    public void on(Activity activity) {
        object3D = new MDStereoSphere3D();
        MDObject3DHelper.loadObj(activity, object3D);
    }

    @Override
    public void off(Activity activity) {

    }

    @Override
    public boolean isSupport(Activity activity) {
        return true;
    }

    @Override
    public MDAbsObject3D getObject3D() {
        return object3D;
    }

    @Override
    protected MD360DirectorFactory hijackDirectorFactory() {
        return new FixedDirectorFactory();
    }
}
