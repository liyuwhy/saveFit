package com.fitmix.sdk.common.vrlibs.strategy;

import android.app.Activity;
import android.content.Context;

public interface IModeStrategy {

    void on(Activity activity);

    void off(Activity activity);

    boolean isSupport(Activity activity);

    void onResume(Context context);

    void onPause(Context context);

}
