package com.fitmix.sdk.common.vrlibs.strategy.display;

import com.fitmix.sdk.common.vrlibs.MDVRLibrary;
import com.fitmix.sdk.common.vrlibs.strategy.ModeManager;

public class DisplayModeManager extends ModeManager<AbsDisplayStrategy> implements IDisplayMode {

    public static final int[] sModes = {MDVRLibrary.DISPLAY_MODE_NORMAL, MDVRLibrary.DISPLAY_MODE_GLASS};

    public DisplayModeManager(int mode) {
        super(mode);
    }

    @Override
    protected int[] getModes() {
        return sModes;
    }

    @Override
    protected AbsDisplayStrategy createStrategy(int mode) {
        switch (mode) {
            case MDVRLibrary.DISPLAY_MODE_GLASS:
                return new GlassStrategy();
            case MDVRLibrary.DISPLAY_MODE_NORMAL:
            default:
                return new NormalStrategy();
        }
    }

    @Override
    public int getVisibleSize() {
        return getStrategy().getVisibleSize();
    }

}
