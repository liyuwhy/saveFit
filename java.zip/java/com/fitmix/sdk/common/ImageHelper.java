package com.fitmix.sdk.common;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import android.os.Build;
import android.text.TextUtils;

import com.fitmix.sdk.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 图片处理帮助类
 */

public class ImageHelper {

    /**
     * 保存内存中的bitmap到本地文件
     *
     * @param bitmap    要保存的bitmap
     * @param localPath 保存在本地的文件名,绝对路径
     */
    public static void saveBitmap2File(Bitmap bitmap, String localPath) {
        if (bitmap == null) {
            return;
        }
        String fileExtension = FileUtils.getFileExtension(localPath);
        if (fileExtension != null && fileExtension.equals("gif")) {//gif暂时不处理
            return;
        }

        try {
            File file = new File(localPath);
            FileOutputStream fos = new FileOutputStream(file);
            assert bitmap != null;
            if (fileExtension != null && fileExtension.equals("png")) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            } else {//默认为jpg
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            }
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 保存内存中的bitmap到本地jpg文件,当文件存在时,删除后重新写入文件
     *
     * @param file   文件名全路径
     * @param bitmap 位图
     * @return 更新后的文件名全路径
     */
    public static String saveBitmapInLocal(File file, Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        try {
            if (file.exists()) {
                file.delete();
            }

            if (file.createNewFile()) {
                OutputStream outStream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
                outStream.flush();
                outStream.close();
            }
        } catch (IOException e) {
        }
        return file.getPath();
    }

    /**
     * 调整图片到指定大小,并保存到指定文件
     *
     * @param bmp       bitmap
     * @param width     图片要调整的宽度
     * @param height    图片要调整的高度
     * @param sDestFile 保存的指定文件名
     */
    public static void adjustPhotoToFitSize(Bitmap bmp, int width, int height, String sDestFile) {
        if (bmp == null || sDestFile == null || sDestFile.isEmpty())
            return;
        Bitmap bmp2 = adjustPhotoToFitSize(bmp, width, height);
        saveBitmap2File(bmp2, sDestFile);
        if (bmp2 != null)
            bmp2.recycle();
    }

    /**
     * 调整图片到指定大小
     *
     * @param bmp    bitmap
     * @param width  图片要调整的宽度
     * @param height 图片要调整的高度
     * @return 设整后的位图
     */
    public static Bitmap adjustPhotoToFitSize(Bitmap bmp, int width, int height) {
        if (bmp == null)
            return bmp;
        Matrix matrix = new Matrix();
        matrix.postScale(width * 1.0f / bmp.getWidth(), height * 1.0f / bmp.getHeight());
        Bitmap result = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true);
        Logger.i(Logger.DEBUG_TAG, "ImageHelper-->adjustPhotoToFitSize target width:" + width + ",target height:" + height + ",bmp.getWidth():" + bmp.getWidth()
                + ",bmp.getHeight():" + bmp.getHeight() + ",result bmp width:" + result.getWidth() + ",result bmp height:" + result.getHeight());
        return result;
    }

    /**
     * 限制图片最大宽度为屏幕,如果原图宽度大于屏幕,则缩放原图并保存回原文件,否则不操作
     *
     * @param context   上下文
     * @param sFilename 原图片文件名,绝对路径
     * @param sDestFile 重新处理后,要保存的指定文件名
     * @return true:已对原图片进行了限制宽度为屏幕宽度处理,false:没有处理
     */
    public static boolean restrictPhotoToScreenWidth(Context context, String sFilename, String sDestFile) {
        if (context == null || TextUtils.isEmpty(sFilename) || TextUtils.isEmpty(sDestFile))
            return false;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        try {
            BitmapFactory.decodeStream(new FileInputStream(sFilename), null, options); //以码流的形式进行解码
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        int imageWidth = options.outWidth;
        int imageHeight = options.outHeight;

        if (imageHeight <= 0 || imageWidth <= 0) {//原图宽度高度不合法
            return false;
        }

//        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
//        Display display = wm.getDefaultDisplay();
//        int screenWidth = display.getWidth();
        int screenWidth = 600;//先最大限制成600px
        if (imageWidth <= screenWidth) {//原图宽度不大于屏幕宽度,不操作
            return false;
        }

        int imageNewHeight = (int) (imageHeight * 1.0f * screenWidth / imageWidth);
        Bitmap bitmap = decodeBitmapFile(sFilename, screenWidth, imageNewHeight);//保持原图比例缩放图片
        saveBitmapInLocal(new File(sDestFile), bitmap);//保存缩放后的图片
        return true;
    }


    /**
     * 图片文件输入流转图片字节数组
     *
     * @param is 图片文件输入流
     * @return 图片字节数组
     */
    public static byte[] streamToBytes(InputStream is) {
        if (is == null)
            return null;
        final int iBufferSize = 1024 * 2;
        ByteArrayOutputStream os = null;
        byte[] buffer;
        int len;
        try {
            os = new ByteArrayOutputStream();
            buffer = new byte[iBufferSize];
            while ((len = is.read(buffer)) >= 0) {
                os.write(buffer, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return os.toByteArray();
    }

    /**
     * 调整图片大小
     *
     * @param sFilename 图片文件名,绝对路径
     * @param maxWidth  最大宽度
     * @param maxHeight 最大高度
     */
    public static Bitmap decodeBitmapFile(String sFilename, int maxWidth, int maxHeight) {
        if (sFilename == null || sFilename.isEmpty())
            return null;

        Bitmap bitmap = BitmapFactory.decodeFile(sFilename);
        if (bitmap != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                Logger.i(Logger.DEBUG_TAG, "ImageHelper decodeBitmapFile-->getAllocationByteCount:" + bitmap.getAllocationByteCount() + ",width:" + bitmap.getWidth() + ",height:" + bitmap.getHeight());
            } else {
                Logger.i(Logger.DEBUG_TAG, "ImageHelper decodeBitmapFile-->getByteCount:" + bitmap.getByteCount() + ",width:" + bitmap.getWidth() + ",height:" + bitmap.getHeight());
            }
            return adjustPhotoToFitSize(bitmap, maxWidth, maxHeight);
        }

        return bitmap;
    }

    /**
     * drawable转bitmap
     *
     * @param drawable
     * @return bitmap
     */
    public static Bitmap drawable2Bitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        } else if (drawable instanceof NinePatchDrawable) {
            Bitmap bitmap = Bitmap
                    .createBitmap(
                            drawable.getIntrinsicWidth(),
                            drawable.getIntrinsicHeight(),
                            drawable.getOpacity() != PixelFormat.OPAQUE ? android.graphics.Bitmap.Config.ARGB_8888
                                    : android.graphics.Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
                    drawable.getIntrinsicHeight());
            drawable.draw(canvas);
            return bitmap;
        } else {
            return null;
        }
    }

    /**
     * 两Bitmap图片沿底部合成,在分享图片上使用
     *
     * @param srcBitmap 底图
     * @param dstBitmap 覆盖在底图上的图
     * @return 合成后的位图
     */
    public static Bitmap compositeImages(Bitmap srcBitmap, Bitmap dstBitmap) {

        Bitmap bmp;
        //下面这个Bitmap中创建的函数就可以创建一个空的Bitmap
        bmp = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), srcBitmap.getConfig());
        Paint paint = new Paint();
        Canvas canvas = new Canvas(bmp);
        //首先绘制第一张图片,很简单,就是和方法中getDstImage一样
        canvas.drawBitmap(srcBitmap, 0, 0, paint);

        //在绘制第二张图片的时候,我们需要指定一个Xfermode
        //这里采用Multiply模式,这个模式是将两张图片的对应的点的像素相乘
        //,再除以255,然后以新的像素来重新绘制显示合成后的图像
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OVER));
        canvas.drawBitmap(dstBitmap, 0, srcBitmap.getHeight() - dstBitmap.getHeight(), paint);//沿底部合成

        return bmp;
    }


    /**
     * 获取位图中的主要颜色值
     */
    public static int getMainColorOfBitmap(Bitmap bmp) {
        if (bmp == null)
            return 0;
        final int ZOOM_SIZE = 32;
        Matrix matrix = new Matrix();
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int size = (w > h) ? h : w;
        size *= 0.5;

        int iLeft = (w - size) / 2;
        int iTop = (h - size) / 2;

        matrix.postScale((float) (ZOOM_SIZE * 1.0 / size),
                (float) (ZOOM_SIZE * 1.0 / size));

        Bitmap bmp2 = Bitmap.createBitmap(bmp, iLeft, iTop, size, size, matrix,
                true);
        int iBufSize = ZOOM_SIZE * ZOOM_SIZE;
        int pixels[] = new int[iBufSize];
        if (bmp2 != null) {
            bmp2.getPixels(pixels, 0, ZOOM_SIZE, 0, 0, ZOOM_SIZE, ZOOM_SIZE);
        }
        int r = 0;
        int g = 0;
        int b = 0;
        for (int i = 0; i < iBufSize; i++) {
            r += (pixels[i] << 8) >> 24;
            g += (pixels[i] << 16) >> 24;
            b += (pixels[i] << 24) >> 24;

        }
        r /= iBufSize;
        g /= iBufSize;
        b /= iBufSize;
        r &= 0x0000FF;
        g &= 0x0000FF;
        b &= 0x0000FF;

        int color = 0xFF000000 | (r << 16) | (g << 8) | b;
        if (bmp2 != null)
            bmp2.recycle();
        return color;
    }


    /**
     * 根据截图生成分享图片
     *
     * @param screenShot 截图
     * @param saveFile   分享图片文件名
     * @return true:生成成功,false:生成失败
     */
    public static boolean makeSharePic(Context context, Bitmap screenShot, String saveFile) {

        if (screenShot == null || TextUtils.isEmpty(saveFile)) {
            return false;
        }

        Bitmap footer = BitmapFactory.decodeResource(context.getResources(), R.drawable.default_surprise);
        if (footer != null) {
            Matrix matrix = new Matrix();
            int width = screenShot.getWidth();
            float scale = footer.getWidth() * 1.0f / width;
            matrix.postScale(scale, scale);
            Bitmap part1 = Bitmap.createBitmap(screenShot, 0, 0, screenShot.getWidth(), screenShot.getHeight(), matrix, true);


            Bitmap bmp = Bitmap.createBitmap(part1.getWidth(), part1.getHeight() + footer.getHeight(), screenShot.getConfig());
            Paint paint = new Paint();
            Canvas canvas = new Canvas(bmp);
            //绘制上部分
            canvas.drawBitmap(part1, 0, 0, paint);

            //在绘制第二张图片的时候,我们需要指定一个Xfermode
            //这里采用Multiply模式,这个模式是将两张图片的对应的点的像素相乘
            //,再除以255,然后以新的像素来重新绘制显示合成后的图像
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.OVERLAY));
            canvas.drawBitmap(footer, 0, bmp.getHeight() - footer.getHeight(), paint);//沿底部合成

            saveBitmap2File(bmp, saveFile);
        }

        return true;
    }

}
