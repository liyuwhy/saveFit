package com.fitmix.sdk.common;

import android.os.Build;
import android.text.TextUtils;

import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.manager.UserDataManager;

/**
 * 自定义的 异常处理类 , 实现了UncaughtExceptionHandler接口
 */
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static CrashHandler mInstance;

    //1.私有化构造方法
    private CrashHandler() {
    }

    public static synchronized CrashHandler getInstance() {
        if (mInstance != null) {
            return mInstance;
        } else {
            mInstance = new CrashHandler();
            return mInstance;
        }
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        // 1.获取当前程序的版本名称
        String versionInfo = ApiUtils.getApkVersionName();
        // 2.获取当前用户uid
        int uid = UserDataManager.getUid();
        // 3.获取手机
        int sdk = Build.VERSION.SDK_INT;// API Level
        String device = Build.DEVICE;//Device
        String model = Build.MODEL;// Model
        String product = Build.PRODUCT;// Product

        //4.获取传感器信息

        //5.上传信息
        StringBuilder sb = new StringBuilder("uncaughtException error:");
        if (throwable != null && !TextUtils.isEmpty(throwable.getMessage())) {
            sb.append(throwable.getMessage());
        }
        if (!TextUtils.isEmpty(versionInfo)) {
            sb.append(",app version:").append(versionInfo);
        }
        sb.append(",user id:").append(uid);
        sb.append(",android sdk:").append(sdk);
        if (!TextUtils.isEmpty(device)) {
            sb.append(",device:").append(device);
        }
        if (!TextUtils.isEmpty(model)) {
            sb.append(",model:").append(model);
        }
        if (!TextUtils.isEmpty(product)) {
            sb.append(",product:").append(product);
        }

        Logger.e(Logger.DEBUG_TAG, sb.toString());
       // System.exit(1);
    }


}