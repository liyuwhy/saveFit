package com.fitmix.sdk.common;


import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;

import com.fitmix.sdk.BuildConfig;
import com.fitmix.sdk.Config;

/**
 * 统一Log日志管理,要修改日志等级,运行如下所示指令:
 * <p>
 * <p>
 * <pre>
 *   adb shell setprop log.tag.fitmix &lt;LOGLEVEL>
 *   LOGLEVEL 表示以下几个值之一:
 *     VERBOSE, DEBUG, INFO, WARN or ERROR
 * </pre>
 * <p>
 * 默认日志的等级是DEBUG.
 * <p>
 * 在release版本日志默认是关闭的,如果要开启,更改{@link #ENABLE_LOGS_IN_RELEASE}的值.
 */
public final class Logger {

    /**
     * 日志默认TAG
     */
    public static final String LOG_TAG = "fitmix";

    /**
     * 日志调试TAG
     */
    public static final String DEBUG_TAG = "TT";

    /**
     * 数据请求流TAG
     */
    public static final String DATA_FLOW_TAG = "dataFlow";


    /**
     * 信鸽消息推送TAG
     */
    public static final String XG_TAG = "XINGE";

    /**
     * 是否允许在release版本显示日志
     */
    private static final boolean ENABLE_LOGS_IN_RELEASE = false;

    private static Log2File.WriteHandler mWriteHandler;



    public static boolean canLog(int level) {
        return (ENABLE_LOGS_IN_RELEASE || BuildConfig.DEBUG);// && Log.isLoggable(LOG_TAG, level);
    }

    public static void d(String tag, String message) {
        if (canLog(Log.DEBUG)) {
            Log.d(tag, message);
        }
        log2File(tag,message);
    }

    public static void v(String tag, String message) {
        if (canLog(Log.VERBOSE)) {
            Log.v(tag, message);
        }
    }

    public static void i(String tag, String message) {
        if (canLog(Log.INFO)) {
            Log.i(tag, message);
        }
        log2File(tag,message);
    }

    public static void i(String tag, String message, Throwable thr) {
        if (canLog(Log.INFO)) {
            Log.i(tag, message, thr);
        }
        log2File(tag,message);
    }

    public static void w(String tag, String message) {
        if (canLog(Log.WARN)) {
            Log.w(tag, message);
        }
        log2File(tag,message);
    }

    public static void w(String tag, String message, Throwable thr) {
        if (canLog(Log.WARN)) {
            Log.w(tag, message, thr);
        }
        log2File(tag,message);
    }

    public static void e(String tag, String message) {
        if (canLog(Log.ERROR)) {
            Log.e(tag, message);
        }
        log2File(tag,message);
    }

    public static void e(String tag, String message, Throwable thr) {
        if (canLog(Log.ERROR)) {
            Log.e(tag, message, thr);
        }
        log2File(tag,message);
    }

    public static void init(){
        HandlerThread handlerThread = new HandlerThread("writeLogThread");
        handlerThread.start();
        FileUtils.makeDirs(Config.LOGGER_CACHE);
        mWriteHandler = new Log2File.WriteHandler(handlerThread.getLooper(), Config.LOGGER_CACHE,1024 * 500);
    }



    public static void log2File(String tag,String message){
      /*  if( !BuildConfig.DEBUG){  // debug下才写入日志
            return;
        }
        if( mWriteHandler == null){
            init();
        }
        if(mWriteHandler != null){
            Message msg = mWriteHandler.obtainMessage();
            msg.obj =  Log2File.log(tag,message);
            mWriteHandler.sendMessage(msg);
        }*/
    }

    private static Log2File.WriteHandler mWriteTimeHandler;
    private static long lastTime = 0;
    public static void logTimeFile(int tag){
        long timeInterval = System.currentTimeMillis()-lastTime;
        String message;
        if (tag == 4){
            message=tag +":"+ timeInterval+Log2File.NEW_LINE;
        }else {
            message=tag +":"+ timeInterval+",";
        }
        lastTime = System.currentTimeMillis();
        if( !BuildConfig.DEBUG){  // debug下才写入日志
            return;
        }
        if( mWriteTimeHandler == null){
            HandlerThread handlerThread = new HandlerThread("writeLogTimeThread");
            handlerThread.start();
            FileUtils.makeDirs(Config.LOGGER_FIRMSEND);
            mWriteTimeHandler = new Log2File.WriteHandler(handlerThread.getLooper(), Config.LOGGER_FIRMSEND,1024 * 500);
        }
        if(mWriteTimeHandler != null){
            Message msg = mWriteTimeHandler.obtainMessage();
            msg.obj =  message;
            mWriteTimeHandler.sendMessage(msg);
        }
    }
}
