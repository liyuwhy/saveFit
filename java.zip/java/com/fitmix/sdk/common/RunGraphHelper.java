package com.fitmix.sdk.common;

import android.util.SparseIntArray;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.bean.RunDataInfo;
import com.fitmix.sdk.bean.RunStepInfo;
import com.fitmix.sdk.bean.SkipNumberInfo;
import com.fitmix.sdk.bean.TrailInfo;
import com.fitmix.sdk.common.pedometer.BpmManager;

import java.util.ArrayList;
import java.util.List;

/**
 * 运动图表帮助类,包括功能有:
 * 1.根据从计步文件得到的步数信息集合,分析得出运动步频,配速等用于图表展示
 * 2.根据从轨迹文件得到的轨迹点信息集合,分析得出运动的海拔用于图表展示
 */
public class RunGraphHelper {

    /**
     * 在图表上最多的数据点数
     */
    public static final int GRAPH_MAX_POINTS = 30;

    //region ===================================== 步数信息分析 =====================================

    /**
     * 从步数信息集合获取运动时长
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @return 运动时长, 单位为毫秒
     */
    public static long getStepDuration(List<RunStepInfo> runStepList) {
        if (runStepList == null || runStepList.size() <= 1) return 0;
        long startTime = 0;
        for (int i = 0; i < runStepList.size(); i++) {
            if (runStepList.get(i).getTime() != 0) {
                startTime = runStepList.get(i).getTime();
                break;
            }
        }
        return runStepList.get(runStepList.size() - 1).getTime() - startTime;
    }

//    /**
//     * 获取手表运动的运动时长
//     *
//     * @param runStepInfoList
//     * @return
//     */
//    public static long getWatchStepDuration(List<RunStepInfo> runStepInfoList) {
//        if (runStepInfoList == null || runStepInfoList.size() <= 1) return 0;
//        return runStepInfoList.get(runStepInfoList.size() - 1).getTime();
//    }
//
//    /**
//     * 从步数信息集合获取运动距离
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @return 运动距离, 单位为米
//     */
//    public static long getStepDistance(List<RunStepInfo> runStepList) {
//        if (runStepList == null || runStepList.size() <= 1) return 0;
//        return runStepList.get(runStepList.size() - 1).getDistance();
//    }
//
//    /**
//     * 从步数信息集合获取总步数
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @return 运动总步数
//     */
//    public static int getTotalSteps(List<RunStepInfo> runStepList) {
//        if (runStepList == null || runStepList.size() <= 1) return 0;
//        return runStepList.get(runStepList.size() - 1).getStep();
//    }

//    /**
//     * 根据步数信息集合和要分段的数量,获取相应的速度图表数据点集合
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @param height 用户身高,单位为厘米
//     * @param gender 用户性别,int型,1:男,2:女
//     * @param iPoints 要分段的数量
//     *
//     * @return 绘制在速度图表上的数据点集合
//     * */
//    public static List<RunDataInfo> getSpeedArray(List<RunStepInfo> runStepList,int height,int gender,int iPoints) {
//        if(runStepList == null || runStepList.size() <= 1)return null;
//
////        double baseDistance = getStepDistance();
////        double distance = getStepDistance(runStepList);
//        double ratio = 1.0;//distance / baseDistance;
//        if(ratio <= 0.8 || ratio >= 1.2)return getSpeedArrayByGPS(runStepList,iPoints);
//        return getSpeedArrayByGSensor(runStepList, height, gender, iPoints);
//    }

//    /**
//     * 根据步数信息集合和要分段的数量,获取相应的速度图表数据点集合
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @param height 用户身高,单位为厘米
//     * @param gender 用户性别,int型,1:男,2:女
//     *
//     * @return 绘制在速度图表上的数据点集合,时间值单位为运动总时长/分钟,值单位为米/秒
//     * */
//    public static List<RunDataInfo> getSpeedArrayByGSensor(List<RunStepInfo> runStepList,int height,int gender) {
//        if(runStepList == null || runStepList.size() <= 1)return null;
//        List<RunDataInfo> list = getBpmArray(runStepList);
//
//        if(list == null)return null;
//        int iLen = list.size();
//        if(iLen <= 0)return null;
//        double heightInMeter = height / 100.0;
//        boolean bFemale = (gender == Config.GENDER_FEMALE);
//
//        int bpm;
//        for(int i = 0; i < iLen; i++){
//            RunDataInfo info = list.get(i);
//            bpm = (int) info.getData();
//            info.setData(heightInMeter * BpmManager.getStepRatioByBpm(bpm, bFemale) * info.getData() / 60);//米/秒
//        }
//        return list;
//    }

    /**
     * 根据步数信息集合和要分段的数量,获取相应的速度图表数据点集合
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @return 绘制在速度图表上的数据点集合, 时间值单位为运动总时长/分钟,值单位为米/秒
     */
    public static List<RunDataInfo> getSpeedArray(List<RunStepInfo> runStepList) {
        if (runStepList == null || runStepList.size() <= 1) return null;

        int iLen = runStepList.size();
        SparseIntArray stepIndex = getStepCharacteristicIndex(runStepList);

        List<RunDataInfo> list = new ArrayList<>();
        long starTime = runStepList.get(0).getTime();
        long distance;
        long duration;
        for (int i = 0; i < stepIndex.size(); i++) {
            int index = stepIndex.get(i);
            if (index < iLen && runStepList.get(index) != null) {
                RunDataInfo info = new RunDataInfo();
                info.setTime(runStepList.get(index).getTime() - starTime);
                double data;
                if (i == 0) {
                    //按比例计算
                    distance = runStepList.get(index).getDistance() - runStepList.get(0).getDistance();
                    duration = runStepList.get(index).getTime() - runStepList.get(0).getTime();
                    if (duration > 0) {
                        data = 1000.0 * distance / duration;
                    } else {
                        data = distance;
                    }
                } else {
                    //按比例计算
                    int pre = stepIndex.get(i - 1);
                    distance = runStepList.get(index).getDistance() - runStepList.get(pre).getDistance();
                    duration = runStepList.get(index).getTime() - runStepList.get(pre).getTime();
                    if (duration > 0) {
                        data = 1000.0 * distance / duration;
                    } else {
                        data = distance;
                    }
                }
                if (data >= 0) {
                    info.setData(data);
                    list.add(info);
                }
            }
        }
        return list;
    }


//    public static List<RunDataInfo> getSpeedArrayByGPS(List<RunStepInfo> runStepList,int iPoints) {
//        if(runStepList == null || runStepList.size() <= 1)return null;
//
//        long starTime = runStepList.get(0).getTime();
//        double oldDistance = runStepList.get(0).getDistance();
//        long now;
//        long timeSpace = 0;
//        double distance;
//        int iLen = runStepList.size();
//        if ((iLen - 1) > iPoints) timeSpace = getStepDuration(runStepList) / iPoints;
//        long compareTime = timeSpace;
//        List<RunDataInfo> list = new ArrayList<>();
//        for (int i = 1; i < iLen; i++) {
//            now = runStepList.get(i).getTime() - starTime;
//            if (now < compareTime) continue;
//            RunDataInfo info = new RunDataInfo();
//            info.setTime(now);
//            distance = runStepList.get(i).getDistance();
//
//            info.setData((distance - oldDistance) * 1000 / (now - compareTime + timeSpace));
//            list.add(info);
//            oldDistance = distance;
//            compareTime += timeSpace;
//        }
//        return list;
//    }
//
//    public static List<RunDataInfo> getSpeedArrayByGSensor(List<RunStepInfo> runStepList,int height,int gender,int iPoints) {
//        List<RunDataInfo> list = getBpmArray(runStepList, iPoints);
//        if(list == null)return null;
//        int iLen = list.size();
//        if(iLen <= 0)return null;
////        double baseDistance = getStepDistance();
////        if(baseDistance <= 0)return null;
//        double ratio = 1.0;//getStepDistance(runStepList) / baseDistance;
//        double heightInMeter = height / 100;
//        boolean bFemale = (gender == Config.GENDER_FEMALE);
//
//        for(int i = 0; i < iLen; i++){
//            RunDataInfo info = list.get(i);
//            info.setData(heightInMeter * BpmManager.getStepRatioByBpm((int) info.getData(), bFemale) * ratio * info.getData() / 60);
//        }
//        return list;
//    }


//    /**
//     * 根据步数信息集合和要分段的数量,获取相应的步幅图表数据点集合
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @param height 用户身高,单位为厘米
//     * @param gender 用户性别,int型,1:男,2:女
//     * @param iPoints 要分段的数量
//     *
//     * @return 绘制在步幅图表上的数据点集合,
//     * */
//    public static List<RunDataInfo> getStrideArray(List<RunStepInfo> runStepList,int height,int gender,int iPoints) {
//        if(runStepList == null || runStepList.size() <= 1)return null;
//
//        List<RunDataInfo> list = getBpmArray(runStepList, iPoints);
//        if(list == null)return null;
//        int iLen = list.size();
//        if(iLen <= 0)return null;
//        double baseDistance = getStepDistance(runStepList);
//
//        if(baseDistance <= 0)return null;
//        int bpm;
//        double ratio = 1.0;//getTotalDistance() / baseDistance;
//        double heightInMeter = height / 100;
//        boolean bFemale = (gender == Config.GENDER_FEMALE);
//
//        for(int i = 0; i < iLen; i++){
//            RunDataInfo info = list.get(i);
//            bpm = (int)info.getData();
//            info.setData(heightInMeter * BpmManager.getStepRatioByBpm(bpm, bFemale) * ratio);
//        }
//        return list;
//    }


    /**
     * 根据步数信息集合和要分段的数量,获取相应的步幅图表数据点集合
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @param height      用户身高,单位为厘米
     * @param gender      用户性别,int型,1:男,2:女
     * @return 绘制在步幅图表上的数据点集合, 时间值单位为运动总时长/分钟,值单位为米/步
     */
    public static List<RunDataInfo> getStrideArrayByGSensor(List<RunStepInfo> runStepList, int height, int gender) {
        if (runStepList == null || runStepList.size() <= 1) return null;

        List<RunDataInfo> list = getBpmArray(runStepList);
        if (list == null) return null;
        int iLen = list.size();
        if (iLen <= 0) return null;

        int bpm;
        boolean bFemale = (gender == Config.GENDER_FEMALE);
        for (int i = 0; i < iLen; i++) {
            RunDataInfo info = list.get(i);
            bpm = (int) info.getData();
            info.setData(height * BpmManager.getStepRatioByBpm(bpm, bFemale) / 100.0f);
        }
        return list;
    }

//    /**
//     * 根据步数信息集合和要分段的数量,获取相应的步频图表数据点集合
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @param iPoints 要分段的数量
//     *
//     * @return 绘制在步频图表上的数据点集合
//     * */
//    public static List<RunDataInfo> getBpmArray(List<RunStepInfo> runStepList,int iPoints) {
//        if(runStepList == null || runStepList.size() <= 1)return null;
//
//        int iLen = runStepList.size();
//        long starTime = runStepList.get(0).getTime();
//        int oldStep = runStepList.get(0).getStep();
//        long now;
//        long timeSpace = 0;
//        int steps;
//        if ((iLen - 1) > iPoints) {
//            timeSpace = getStepDuration(runStepList) / iPoints;
//        }
//        long compareTime = timeSpace;
//        List<RunDataInfo> list = new ArrayList<>();
//        int adjustSteps = 0;
//        for (int i = 1; i < iLen; i++) {
//            now = runStepList.get(i).getTime() - starTime;
////            if((runStepList.get(i).getStep() < 10) && runStepList.get(i).getStep() < runStepList.get(i - 1).getStep()){
////                adjustSteps += runStepList.get(i - 1).getStep();
////            }
//            if (now < compareTime) continue;
//            RunDataInfo info = new RunDataInfo();
//            info.setTime(now);
//            steps = runStepList.get(i).getStep() + adjustSteps;
//            long space = now - compareTime + timeSpace;
//            if(space > 0) {
//                info.setData((steps - oldStep) * 60000 / space);
//            }
//            list.add(info);
//            oldStep = steps;
//            compareTime += timeSpace;
//        }
//
//        return list;
//    }

//    /**
//     * 根据步数信息集合和要分段的数量,获取轴对应的时间分段间隔
//     *
//     * @param runStepList 从计步文件得到的步数信息集合
//     * @param iLines      要分段的数量
//     * @return 时间分段间隔, 单位为毫秒
//     */
//    public static long getAxisTimeSpace(List<RunStepInfo> runStepList, int iLines) {
//        long space = getStepDuration(runStepList) / iLines;
//        if (space < 1000) {//1秒
//            space = space / 100 * 100;    //0.1秒倍数
//        } else if (space < 10000) {//10秒
//            space = space / 1000 * 1000;    //1秒倍数
//        } else if (space < 60000) {//1分钟
//            space = space / 10000 * 10000;    //10秒倍数
//        } else if (space < 10 * 60 * 1000) {//10分钟
//            space = space / 60000 * 60000;    //10分钟倍数
//        } else {
//            space = 60 * 60 * 1000;        // 1小时
//        }
//        return space;
//    }

    /**
     * 根据步数信息集合和要分段的数量,获取轴对应的时间分段间隔
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @param iLines      要分段的数量
     * @return 时间分段间隔, 单位为毫秒
     */
    public static long getAxisTimeSpace(List<RunStepInfo> runStepList, int iLines) {
        long space = getStepDuration(runStepList) / iLines;
        if (space < 1000) {//1秒
            space = space / 100 * 100;    //0.1秒倍数
        } else if (space < 10000) {//10秒
            space = space / 1000 * 1000;    //1秒倍数
        } else if (space < 60000) {//1分钟
            space = space / 10000 * 10000;    //10秒倍数
        } else if (space < 600000) {//10分钟
            space = space / 60000 * 60000;    //1分钟倍数
        } else if (space < 3600000) {//1小时
            space = space / 600000 * 600000;    //10分钟倍数
        } else {
            space = 60 * 60 * 1000;        // 1小时
        }
        return space;
    }

    /**
     * 根据步数信息集合和要分段的数量,获取相应的步频图表数据点集合
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @return 绘制在步频图表上的数据点集合, 时间值单位为运动总时长/分钟,值单位为步/分钟
     */
    public static List<RunDataInfo> getBpmArray(List<RunStepInfo> runStepList) {
        if (runStepList == null || runStepList.size() <= 1) return null;

        int iLen = runStepList.size();
        SparseIntArray stepIndex = getStepCharacteristicIndex(runStepList);

        List<RunDataInfo> list = new ArrayList<>();
        long starTime = runStepList.get(0).getTime();
        int step;
        long duration;
        for (int i = 0; i < stepIndex.size(); i++) {
            int index = stepIndex.get(i);
            if (index < iLen && runStepList.get(index) != null) {
                RunDataInfo info = new RunDataInfo();
                info.setTime(runStepList.get(index).getTime() - starTime);
                double data;
                if (i == 0) {
                    //按比例计算
                    step = runStepList.get(index).getStep() - runStepList.get(0).getStep();
                    duration = runStepList.get(index).getTime() - runStepList.get(0).getTime();
                    if (duration > 60000) {
                        data = 1.0f * step / (duration / 60000.0f);
                    } else if (duration > 0) {
                        data = 60000.0 * step / duration;
                    } else {
                        data = step;
                    }
                } else {
                    //按比例计算
                    int pre = stepIndex.get(i - 1);
                    step = runStepList.get(index).getStep() - runStepList.get(pre).getStep();
                    duration = runStepList.get(index).getTime() - runStepList.get(pre).getTime();
                    if (duration > 60000) {
                        data = 1.0f * step / (duration / 60000.0f);
                    } else if (duration > 0) {
                        data = 60000.0 * step / duration;
                    } else {
                        data = step;
                    }
                }
                if (data >= 0) {
                    info.setData(data);
                    list.add(info);
                }
            }
        }
        return list;
    }

    /**
     * 从步数信息集合中获取时间轴单位长度对应的步数信息下标集合
     *
     * @param runStepList 从计步文件得到的步数信息集合
     * @return 时间轴单位长度对应的步数信息下标集合
     */
    private static SparseIntArray getStepCharacteristicIndex(List<RunStepInfo> runStepList) {
        SparseIntArray stepIndex = new SparseIntArray();

        if (runStepList == null || runStepList.size() <= 1) {
            return stepIndex;
        }
        int iLen = runStepList.size();
        long space = 60000;//默认每1分钟时间间隔取一个数据点
        //1.判断运动总时长,如果运动时长超过31分钟,则时间间隔加长,保证点数为30,曲线较平滑
        long runTime = runStepList.get(iLen - 1).getTime() - runStepList.get(0).getTime();
        if (runTime > 1860000) {//31分钟
            space = runTime / GRAPH_MAX_POINTS;
        }

        if (runStepList != null && runStepList.get(0) != null) {
            int flag = 0;
            int index = 0;
            for (int i = 1; i < iLen; i++) {
                if ((runStepList.get(i).getTime() - runStepList.get(flag).getTime()) > space) {
                    flag = i;
                    stepIndex.put(index, i);
                    index++;
                }
            }
            if (stepIndex.size() > 0) {
                int lastIndex = iLen - 1;
                if (stepIndex.get(index - 1) < lastIndex) {//最后一段不是刚好满整分钟,添加最后一个点
                    stepIndex.put(index, lastIndex);
                }
            } else {//小于1分钟,算最后一个点
                stepIndex.put(0, iLen - 1);
            }
        }
        return stepIndex;
    }


    //endregion ===================================== 步数信息分析 =====================================

    //region ===================================== 轨迹信息分析 =====================================

    /**
     * 根据轨迹信息集合、要分段的数量、计步开始时间和运动时长,获取相应的海拔图表数据点集合
     *
     * @param trailInfoList 从轨迹文件得到的轨迹信息集合
     * @param iPoints       要分段的数量
     * @param startTime     计步开始时间,单位为毫秒
     * @param duration      运动时长,单位为毫秒
     * @return 绘制在海拔图表上的数据点集合
     */
    public static List<RunDataInfo> getAltitudeArray(List<TrailInfo> trailInfoList, int iPoints, long startTime, long duration) {
        if (trailInfoList == null || trailInfoList.size() <= 1) return null;

        int iLen = trailInfoList.size();

        long now;
        long timeSpace;
        timeSpace = duration / iPoints;
        long compareTime = timeSpace;
        if (timeSpace <= 0) return null;
        List<RunDataInfo> list = new ArrayList<>();


        double altitude = 0;
        long tempTime = -1;
        double oldAltitude = 0;
        long totalTime = 0;

        for (int i = 0; i < iLen; i++) {
            if (trailInfoList.get(i).getType() != Config.LOCATION_TYPE_GPS) continue;
            if (tempTime <= -1) {
                oldAltitude = trailInfoList.get(i).getAltitude();
                tempTime = trailInfoList.get(i).getTime();
            }
            altitude += (trailInfoList.get(i).getAltitude() + oldAltitude) * (trailInfoList.get(i).getTime() - tempTime) / 2;
            totalTime += trailInfoList.get(i).getTime() - tempTime;
            tempTime = trailInfoList.get(i).getTime();
            oldAltitude = trailInfoList.get(i).getAltitude();
            now = trailInfoList.get(i).getTime() - startTime;
            if (now < compareTime) continue;
            if (totalTime > 0) {
                RunDataInfo info = new RunDataInfo();
                info.setTime(now);
                info.setData(altitude / totalTime);
                list.add(info);
            }
            while (now + timeSpace > compareTime) {
                compareTime += timeSpace;
            }
            altitude = 0;
            totalTime = 0;
        }
        return list;
    }

    //endregion ===================================== 轨迹信息分析 =====================================

    //region ===================================== 跳绳计数信息分析 =====================================

    /**
     * @return 运动时长, 单位为毫秒
     */
    public static long getSkipDuration(List<SkipNumberInfo> skipNumberInfoList, long endTime, long startTime) {
        long duration;
        if (skipNumberInfoList == null || skipNumberInfoList.size() <= 1) return 0;
        //duration= skipNumberInfoList.get(skipNumberInfoList.size() - 1).getTime() - startTime;
        duration = skipNumberInfoList.get(skipNumberInfoList.size() - 1).getTime();
//        Logger.i(Logger.DEBUG_TAG, "RunGraphHelper ---> getSkipDuration duration : " + duration);
        return duration;
    }

    /**
     * 根据跳绳计数信息集合和要分段的数量,获取轴对应的时间分段间隔
     *
     * @param iLines 要分段的数量
     * @return 时间分段间隔, 单位为毫秒
     */
    public static long getAxisTimeSpaceSkipType(long skipTime, int iLines) {
        long space = skipTime / iLines;
        if (space < 1000) {//1秒
            space = space / 100 * 100;    //0.1秒倍数
        } else if (space < 10000) {//10秒
            space = space / 1000 * 1000;    //1秒倍数
        } else if (space < 60000) {//1分钟
            space = space / 10000 * 10000;    //10秒倍数
        } else if (space < 10 * 60 * 1000) {//10分钟
            space = space / 60000 * 60000;    //1分钟倍数
        } else if (space < 60 * 60 * 1000) {//1小时
            space = space / 600000 * 600000;    //10分钟倍数
        } else {
            space = 60 * 60 * 1000;        // 1小时
        }
        Logger.i(Logger.DEBUG_TAG, "RunGraphHelper ---> getAxisTimeSpaceSkipType space : " + space);
        return space;
    }

    public static List<RunDataInfo> getSpeedArrayBySkipInfo(List<SkipNumberInfo> skipNumberInfoList, long startTime, int iPoints) {
        List<RunDataInfo> list = getBpmArrayBySkipType2(skipNumberInfoList, startTime, iPoints);
        if (list != null && list.size() > 0 && list.size() % 2 == 0) {
            list.add(list.get(list.size() - 1));
        }
        return list;
    }

    /**
     * 根据跳绳计数信息集合和要分段的数量,获取相应的跳频图表数据点集合
     *
     * @param skipNumberInfoList 从计数文件得到的跳绳计数信息集合
     * @param iPoints            要分段的数量
     * @return 绘制在跳频图表上的数据点集合
     */
    public static List<RunDataInfo> getBpmArrayBySkipType(List<SkipNumberInfo> skipNumberInfoList, long startTime, int iPoints) {
        if (skipNumberInfoList == null || skipNumberInfoList.size() <= 1) return null;
        List<RunDataInfo> list = new ArrayList<>();
        for (int i = 0; i < skipNumberInfoList.size(); i++) {
            RunDataInfo info = new RunDataInfo();
            //info.setTime(skipNumberInfoList.get(i).getTime() - startTime);
            info.setTime(skipNumberInfoList.get(i).getTime());
            info.setData(skipNumberInfoList.get(i).getBpm());
            list.add(info);
        }
        Logger.i(Logger.DEBUG_TAG, "RunGraphHelper ---> getBpmArrayBySkipType list : " + list.size());
        return getBpmArrayBySkipType3(list);
    }


    /**
     * 根据跳绳计数信息集合和要分段的数量,获取相应的跳频图表数据点集合
     *
     * @param skipNumberInfoList 从计数文件得到的跳绳计数信息信息集合
     * @param startTime          跳绳开始时间
     * @return 绘制在跳频图表上的数据点集合, 时间值单位为运动总时长/分钟,值单位为个/分钟
     */
    private static List<RunDataInfo> getBpmArrayBySkipType2(List<SkipNumberInfo> skipNumberInfoList, long startTime, int iPoints) {
        if (skipNumberInfoList == null || skipNumberInfoList.size() <= 1) return null;

        int iLen = skipNumberInfoList.size();
        SparseIntArray stepIndex = getSkipCharacteristicIndex(skipNumberInfoList, startTime);
        double data;
        List<RunDataInfo> list = new ArrayList<>();
        for (int i = 0; i < stepIndex.size(); i++) {
            int index = stepIndex.get(i);
            if (index < iLen && skipNumberInfoList.get(index) != null) {
                //long time = skipNumberInfoList.get(index).getTime() - startTime;
                long time = skipNumberInfoList.get(index).getTime();
                if (time < 0) continue;
                if (list.size() > 0 && time < list.get(list.size() - 1).getTime()) continue;
                RunDataInfo info = new RunDataInfo();
                data = skipNumberInfoList.get(stepIndex.get(i)).getBpm();
                if (data >= 0) {
                    info.setData(data);
                    info.setTime(time);
                    list.add(info);
                }
            }
        }

        return getBpmArrayBySkipType3(list);
    }

    /**
     * 从跳绳计数信息集合中获取时间轴单位长度对应的步数信息下标集合
     *
     * @param skipNumberInfoList 从计数文件得到的跳绳计数信息信息集合
     * @return 时间轴单位长度对应的步数信息下标集合
     */
    private static SparseIntArray getSkipCharacteristicIndex(List<SkipNumberInfo> skipNumberInfoList, long startTime) {
        SparseIntArray stepIndex = new SparseIntArray();

        if (skipNumberInfoList == null || skipNumberInfoList.size() <= 1) {
            return stepIndex;
        }
        int iLen = skipNumberInfoList.size();
        //long skipTime = skipNumberInfoList.get(iLen - 1).getTime() - startTime;
        long skipTime = skipNumberInfoList.get(iLen - 1).getTime();
        long space = skipTime / 60;
        if (skipNumberInfoList != null && skipNumberInfoList.get(0) != null) {
            int flag = 0;
            int index = 0;
            for (int i = 0; i < iLen; i++) {
                if (i == 0) {
                    //if ((skipNumberInfoList.get(i).getTime() - startTime) > space) {
                    if ((skipNumberInfoList.get(i).getTime()) > space) {
                        flag = i;
                        stepIndex.put(index, i);
                        index++;
                    }
                } else {
                    if ((skipNumberInfoList.get(i).getTime() - skipNumberInfoList.get(flag).getTime()) > space) {
                        flag = i;
                        stepIndex.put(index, i);
                        index++;
                    }
                }
            }
            if (stepIndex.size() > 0) {
                int lastIndex = iLen - 1;
                if (stepIndex.get(index - 1) < lastIndex) {//最后一段不是刚好满整分钟,添加最后一个点
                    stepIndex.put(index, lastIndex);
                }
            } else {
                stepIndex.put(0, iLen - 1);
            }
        }
        return stepIndex;
    }

    private static List<RunDataInfo> getBpmArrayBySkipType3(List<RunDataInfo> runDataInfoList) {
        if (runDataInfoList == null || runDataInfoList.size() <= 1) return null;
        int iLen = runDataInfoList.size();
        int windowsSize = 4;
        if (iLen < (windowsSize + 4)) return runDataInfoList;
        List<RunDataInfo> list = new ArrayList<>();
        for (int i = 0; i < iLen; i++) {
            RunDataInfo runDataInfo = new RunDataInfo();
            double bpm = 0;
            if (i < windowsSize) {
                for (int j = 0; j <= i; j++) {
                    bpm += runDataInfoList.get(j).getData();
                }
                bpm /= i + 1;
            } else {
                for (int j = 0; j <= windowsSize; j++) {
                    bpm += runDataInfoList.get(i - j).getData();
                }
                bpm /= (windowsSize + 1);
//                bpm = runDataInfoList.get(i).getData() + runDataInfoList.get(i - 1).getData() +
//                        runDataInfoList.get(i - 2).getData() + runDataInfoList.get(i - 3).getData() + runDataInfoList.get(i - 4).getData();
//                bpm /= 5;
            }
            runDataInfo.setData(bpm);
            runDataInfo.setTime(runDataInfoList.get(i).getTime());
            list.add(runDataInfo);
        }
        return list;
    }
    //endregion ===================================== 跳绳计数信息分析 =====================================

}
