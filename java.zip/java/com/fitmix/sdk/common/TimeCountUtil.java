package com.fitmix.sdk.common;

import android.os.CountDownTimer;

public class TimeCountUtil extends CountDownTimer {
    private ITimeCountListener listener;

    public TimeCountUtil(long millisInFuture, long countDownInterval, ITimeCountListener listener) {
        super(millisInFuture, countDownInterval);
        this.listener = listener;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        listener.onTick(millisUntilFinished);
    }

    @Override
    public void onFinish() {
        listener.onFinish();
    }

    public interface ITimeCountListener {
        void onTick(long millisUntilFinished);

        void onFinish();
    }
}
