package com.fitmix.sdk.common.encrypt;

/**
 * RSA公钥存储转换用
 */
public class AppPublicKey {

    private String algorithm;
    private String format;
    private String encodedBytes;

    public AppPublicKey(String algorithm, String format, String encodedBytes) {
        this.algorithm = algorithm;
        this.format = format;
        this.encodedBytes = encodedBytes;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getEncodedBytes() {
        return encodedBytes;
    }

    public void setEncodedBytes(String encodedBytes) {
        this.encodedBytes = encodedBytes;
    }

    public String getAlgorithm() {
        return algorithm;

    }

    public String getFormat() {
        return format;
    }

}
