package com.fitmix.sdk.common.encrypt;

import android.util.Base64;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.SettingsHelper;

import java.io.IOException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

/**
 *  * RSA非对称型加密的公钥和私钥
 *  
 */
public class KeyRSAUtil {

    private static Key publicKey;//公钥

    private static Key getPublicKey() {
        if (publicKey == null) { //&& !TextUtils.isEmpty(PUB_ADDRESS)) {
            try {// 将文件中的公钥对象读出
                publicKey = loadPubKey();//loadPubKey(PUB_ADDRESS);
            } catch (Exception e) {
                Logger.e("加密", "KeyRSAUtil-->getPublicKey error:" + e.getMessage());
            }
        }
        return publicKey;
    }

    /**
     * 根据String转换成PublicKey
     */
    public static Key load(String publicK) throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] keyBytes = Base64.decode(publicK.getBytes(), Base64.DEFAULT);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");

        return keyFactory.generatePublic(spec);
    }

    public static Key loadPubKey() throws IOException, ClassNotFoundException {
        Key key = null;
        String publicKeyStr = SettingsHelper.getString(-1, Config.SETTING_PUBLIC_KEY, "");
        AppPublicKey myPublicKey = JsonHelper.getObject(publicKeyStr, AppPublicKey.class);
        try {
            if (myPublicKey != null) {
                key = load(myPublicKey.getEncodedBytes());
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        Logger.i("加密", "loadPubKey publicKeyStr:" + publicKeyStr);
//        if (key != null) {
//            Logger.i("加密", "loadPubKey key.getAlgorithm():" + key.getAlgorithm() + ",key.getFormat():" + key.getFormat() + "\nencode:" + key.getEncoded());
//        }

        return key;
    }

    /**
     * 加密,流程为RSA-->自定义Base64
     */
    public static String encrypt(String source) throws Exception {
        Key key = getPublicKey();

        /** 得到Cipher对象来实现对源数据的RSA加密 */
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] b = source.getBytes("UTF-8");
        /** 执行加密操作 */
        byte[] b1 = cipher.doFinal(b);
        String result = Base64Util.IBase64.encode(b1);
        Logger.i("加密", "RSA-->BASE64 result:" + result);
        return result;
    }

}
