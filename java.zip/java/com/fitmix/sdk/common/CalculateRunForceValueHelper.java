package com.fitmix.sdk.common;

/**
 * 计算跑力值帮助类
 */

public class CalculateRunForceValueHelper {

    /**
     * @param distance 单位：米
     * @param time     单位：秒
     * @return 跑力值 int类型
     */
    public static int getRunForceValue(double distance, int time) {
        int value = 0;
        if (distance < 1600) {//小于1600米，不计算跑力值
            return 0;
        } else if (distance >= 1600 && distance < 3000) {
            //处于1600米
            if (time <= (11 * 60 + 54) && time > (11 * 60 + 36)) {
                return 20;
            } else if (time <= (11 * 60 + 36) && time > (11 * 60 + 19)) {
                return 21;
            } else if (time <= (11 * 60 + 19) && time > (11 * 60 + 1)) {
                return 22;
            } else if (time <= (11 * 60 + 1) && time > (10 * 60 + 45)) {
                return 23;
            } else if (time <= (10 * 60 + 45) && time > (10 * 60 + 28)) {
                return 24;
            } else if (time <= (10 * 60 + 28) && time > (10 * 60 + 11)) {
                return 25;
            } else if (time <= (10 * 60 + 11) && time > (9 * 60 + 35)) {
                return 26;
            } else if (time <= (9 * 60 + 35) && time > (9 * 60 + 39)) {
                return 27;
            } else if (time <= (9 * 60 + 39) && time > (9 * 60 + 24)) {
                return 28;
            } else if (time <= (9 * 60 + 24) && time > (9 * 60 + 11)) {
                return 29;
            } else if (time <= (9 * 60 + 11) && time > (8 * 60 + 55)) {
                return 30;
            } else if (time <= (8 * 60 + 55) && time > (8 * 60 + 41)) {
                return 31;
            } else if (time <= (8 * 60 + 41) && time > (8 * 60 + 27)) {
                return 32;
            } else if (time <= (8 * 60 + 27) && time > (8 * 60 + 14)) {
                return 33;
            } else if (time <= (8 * 60 + 14) && time > (8 * 60 + 1)) {
                return 34;
            } else if (time <= (8 * 60 + 1) && time > (7 * 60 + 49)) {
                return 35;
            } else if (time <= (7 * 60 + 49) && time > (7 * 60 + 38)) {
                return 36;
            } else if (time <= (7 * 60 + 38) && time > (7 * 60 + 27)) {
                return 37;
            } else if (time <= (7 * 60 + 27) && time > (7 * 60 + 17)) {
                return 38;
            } else if (time <= (7 * 60 + 17) && time > (7 * 60 + 7)) {
                return 39;
            } else if (time <= (7 * 60 + 7) && time > (6 * 60 + 58)) {
                return 40;
            } else if (time <= (6 * 60 + 58) && time > (6 * 60 + 49)) {
                return 41;
            } else if (time <= (6 * 60 + 49) && time > (6 * 60 + 41)) {
                return 42;
            } else if (time <= (6 * 60 + 41) && time > (6 * 60 + 32)) {
                return 43;
            } else if (time <= (6 * 60 + 32) && time > (6 * 60 + 25)) {
                return 44;
            } else if (time <= (6 * 60 + 25) && time > (6 * 60 + 17)) {
                return 45;
            } else if (time <= (6 * 60 + 17) && time > (6 * 60 + 10)) {
                return 46;
            } else if (time <= (6 * 60 + 10) && time > (6 * 60 + 3)) {
                return 47;
            } else if (time <= (6 * 60 + 3) && time > (5 * 60 + 56)) {
                return 48;
            } else if (time <= (5 * 60 + 56) && time > (5 * 60 + 50)) {
                return 49;
            } else if (time <= (5 * 60 + 50) && time > (5 * 60 + 44)) {
                return 50;
            } else if (time <= (5 * 60 + 44) && time > (5 * 60 + 38)) {
                return 51;
            } else if (time <= (5 * 60 + 38) && time > (5 * 60 + 32)) {
                return 52;
            } else if (time <= (5 * 60 + 32) && time > (5 * 60 + 27)) {
                return 53;
            } else if (time <= (5 * 60 + 27) && time > (5 * 60 + 21)) {
                return 54;
            } else if (time <= (5 * 60 + 21) && time > (5 * 60 + 16)) {
                return 55;
            } else if (time <= (5 * 60 + 16) && time > (5 * 60 + 11)) {
                return 56;
            } else if (time <= (5 * 60 + 11) && time > (5 * 60 + 6)) {
                return 57;
            } else if (time <= (5 * 60 + 6) && time > (5 * 60 + 2)) {
                return 58;
            } else if (time <= (5 * 60 + 2) && time > (4 * 60 + 57)) {
                return 59;
            } else if (time <= (4 * 60 + 57) && time > (4 * 60 + 53)) {
                return 60;
            } else if (time <= (4 * 60 + 53) && time > (4 * 60 + 49)) {
                return 61;
            } else if (time <= (4 * 60 + 49) && time > (4 * 60 + 45)) {
                return 62;
            } else if (time <= (4 * 60 + 45) && time > (4 * 60 + 41)) {
                return 63;
            } else if (time <= (4 * 60 + 41) && time > (4 * 60 + 37)) {
                return 64;
            } else if (time <= (4 * 60 + 37) && time > (4 * 60 + 33)) {
                return 65;
            } else if (time <= (4 * 60 + 33) && time > (4 * 60 + 30)) {
                return 66;
            } else if (time <= (4 * 60 + 30) && time > (4 * 60 + 26)) {
                return 67;
            } else if (time <= (4 * 60 + 26) && time > (4 * 60 + 23)) {
                return 68;
            } else if (time <= (4 * 60 + 23) && time > (4 * 60 + 19)) {
                return 69;
            } else if (time <= (4 * 60 + 19) && time > (4 * 60 + 16)) {
                return 70;
            } else if (time <= (4 * 60 + 16) && time > (4 * 60 + 13)) {
                return 71;
            } else if (time <= (4 * 60 + 13) && time > (4 * 60 + 10)) {
                return 72;
            } else if (time <= (4 * 60 + 10) && time > (4 * 60 + 7)) {
                return 73;
            } else if (time <= (4 * 60 + 7) && time > (4 * 60 + 4)) {
                return 74;
            } else if (time <= (4 * 60 + 4) && time > (4 * 60 + 2)) {
                return 75;
            } else if (time <= (4 * 60 + 2) && time > (3 * 60 + 58)) {
                return 76;
            } else if (time <= (3 * 60 + 58) && time > (3 * 60 + 56)) {
                return 77;
            } else if (time <= (3 * 60 + 56) && time > (3 * 60 + 53)) {
                return 78;
            } else if (time <= (3 * 60 + 53) && time > (3 * 60 + 51)) {
                return 79;
            } else if (time <= (3 * 60 + 51) && time > (3 * 60 + 48)) {
                return 80;
            } else if (time <= (3 * 60 + 48) && time > (3 * 60 + 46)) {
                return 81;
            } else if (time <= (3 * 60 + 46) && time > (3 * 60 + 44)) {
                return 82;
            } else if (time <= (3 * 60 + 44) && time > (3 * 60 + 42)) {
                return 83;
            } else if (time <= (3 * 60 + 42) && time > (3 * 60 + 39)) {
                return 84;
            } else if (time <= (3 * 60 + 39)) {
                return 85;
            }

        } else if (distance >= 3000 && distance < 5000) {
            //处于3000米 3公里

            if (time <= (23 * 60 + 20) && time > (22 * 60 + 45)) {
                return 20;
            } else if (time <= (22 * 60 + 45) && time > (22 * 60 + 11)) {
                return 21;
            } else if (time <= (22 * 60 + 11) && time > (21 * 60 + 37)) {
                return 22;
            } else if (time <= (21 * 60 + 37) && time > (21 * 60 + 4)) {
                return 23;
            } else if (time <= (21 * 60 + 4) && time > (20 * 60 + 31)) {
                return 24;
            } else if (time <= (20 * 60 + 31) && time > (19 * 60 + 59)) {
                return 25;
            } else if (time <= (19 * 60 + 59) && time > (19 * 60 + 27)) {
                return 26;
            } else if (time <= (19 * 60 + 27) && time > (18 * 60 + 56)) {
                return 27;
            } else if (time <= (18 * 60 + 56) && time > (18 * 60 + 26)) {
                return 28;
            } else if (time <= (18 * 60 + 26) && time > (17 * 60 + 56)) {
                return 29;
            } else if (time <= (17 * 60 + 56) && time > (17 * 60 + 27)) {
                return 30;
            } else if (time <= (17 * 60 + 27) && time > (16 * 60 + 59)) {
                return 31;
            } else if (time <= (16 * 60 + 59) && time > (16 * 60 + 33)) {
                return 32;
            } else if (time <= (16 * 60 + 33) && time > (16 * 60 + 9)) {
                return 33;
            } else if (time <= (16 * 60 + 9) && time > (15 * 60 + 45)) {
                return 34;
            } else if (time <= (15 * 60 + 45) && time > (15 * 60 + 23)) {
                return 35;
            } else if (time <= (15 * 60 + 23) && time > (15 * 60 + 1)) {
                return 36;
            } else if (time <= (15 * 60 + 1) && time > (14 * 60 + 41)) {
                return 37;
            } else if (time <= (14 * 60 + 41) && time > (14 * 60 + 21)) {
                return 38;
            } else if (time <= (14 * 60 + 21) && time > (14 * 60 + 3)) {
                return 39;
            } else if (time <= (14 * 60 + 3) && time > (13 * 60 + 45)) {
                return 40;
            } else if (time <= (13 * 60 + 45) && time > (13 * 60 + 28)) {
                return 41;
            } else if (time <= (13 * 60 + 28) && time > (13 * 60 + 11)) {
                return 42;
            } else if (time <= (13 * 60 + 11) && time > (12 * 60 + 55)) {
                return 43;
            } else if (time <= (12 * 60 + 55) && time > (12 * 60 + 40)) {
                return 44;
            } else if (time <= (12 * 60 + 40) && time > (12 * 60 + 26)) {
                return 45;
            } else if (time <= (12 * 60 + 26) && time > (12 * 60 + 12)) {
                return 46;
            } else if (time <= (12 * 60 + 12) && time > (11 * 60 + 58)) {
                return 47;
            } else if (time <= (11 * 60 + 58) && time > (11 * 60 + 45)) {
                return 48;
            } else if (time <= (11 * 60 + 45) && time > (11 * 60 + 33)) {
                return 49;
            } else if (time <= (11 * 60 + 33) && time > (11 * 60 + 21)) {
                return 50;
            } else if (time <= (11 * 60 + 21) && time > (11 * 60 + 9)) {
                return 51;
            } else if (time <= (11 * 60 + 9) && time > (10 * 60 + 58)) {
                return 52;
            } else if (time <= (10 * 60 + 58) && time > (10 * 60 + 47)) {
                return 53;
            } else if (time <= (10 * 60 + 47) && time > (10 * 60 + 37)) {
                return 54;
            } else if (time <= (10 * 60 + 37) && time > (10 * 60 + 27)) {
                return 55;
            } else if (time <= (10 * 60 + 27) && time > (10 * 60 + 17)) {
                return 56;
            } else if (time <= (10 * 60 + 17) && time > (10 * 60 + 8)) {
                return 57;
            } else if (time <= (10 * 60 + 8) && time > (9 * 60 + 58)) {
                return 58;
            } else if (time <= (9 * 60 + 58) && time > (9 * 60 + 50)) {
                return 59;
            } else if (time <= (9 * 60 + 50) && time > (9 * 60 + 41)) {
                return 60;
            } else if (time <= (9 * 60 + 41) && time > (9 * 60 + 33)) {
                return 61;
            } else if (time <= (9 * 60 + 33) && time > (9 * 60 + 25)) {
                return 62;
            } else if (time <= (9 * 60 + 25) && time > (9 * 60 + 17)) {
                return 63;
            } else if (time <= (9 * 60 + 17) && time > (9 * 60 + 9)) {
                return 64;
            } else if (time <= (9 * 60 + 9) && time > (9 * 60 + 2)) {
                return 65;
            } else if (time <= (9 * 60 + 2) && time > (8 * 60 + 55)) {
                return 66;
            } else if (time <= (8 * 60 + 55) && time > (8 * 60 + 48)) {
                return 67;
            } else if (time <= (8 * 60 + 48) && time > (8 * 60 + 41)) {
                return 68;
            } else if (time <= (8 * 60 + 41) && time > (8 * 60 + 34)) {
                return 69;
            } else if (time <= (8 * 60 + 34) && time > (8 * 60 + 28)) {
                return 70;
            } else if (time <= (8 * 60 + 28) && time > (8 * 60 + 22)) {
                return 71;
            } else if (time <= (8 * 60 + 22) && time > (8 * 60 + 16)) {
                return 72;
            } else if (time <= (8 * 60 + 16) && time > (8 * 60 + 10)) {
                return 73;
            } else if (time <= (8 * 60 + 10) && time > (8 * 60 + 4)) {
                return 74;
            } else if (time <= (8 * 60 + 4) && time > (7 * 60 + 58)) {
                return 75;
            } else if (time <= (7 * 60 + 58) && time > (7 * 60 + 53)) {
                return 76;
            } else if (time <= (7 * 60 + 53) && time > (7 * 60 + 48)) {
                return 77;
            } else if (time <= (3 * 60 + 56) && time > (3 * 60 + 53)) {
                return 78;
            } else if (time <= (3 * 60 + 53) && time > (3 * 60 + 51)) {
                return 79;
            } else if (time <= (3 * 60 + 51) && time > (3 * 60 + 48)) {
                return 80;
            } else if (time <= (3 * 60 + 48) && time > (3 * 60 + 46)) {
                return 81;
            } else if (time <= (3 * 60 + 46) && time > (3 * 60 + 44)) {
                return 82;
            } else if (time <= (3 * 60 + 44) && time > (3 * 60 + 42)) {
                return 83;
            } else if (time <= (3 * 60 + 42) && time > (3 * 60 + 39)) {
                return 84;
            } else if (time <= (3 * 60 + 39)) {
                return 85;
            }

        } else if (distance >= 5000 && distance < 10000) {
            //处于5000米 5公里

            if (time <= (42 * 60 + 24) && time > (40 * 60 + 49)) {
                return 20;
            } else if (time <= (40 * 60 + 49) && time > (39 * 60 + 22)) {
                return 21;
            } else if (time <= (39 * 60 + 22) && time > (38 * 60 + 1)) {
                return 22;
            } else if (time <= (38 * 60 + 1) && time > (36 * 60 + 44)) {
                return 23;
            } else if (time <= (36 * 60 + 44) && time > (35 * 60 + 33)) {
                return 24;
            } else if (time <= (35 * 60 + 33) && time > (34 * 60 + 27)) {
                return 25;
            } else if (time <= (34 * 60 + 27) && time > (33 * 60 + 25)) {
                return 26;
            } else if (time <= (33 * 60 + 25) && time > (32 * 60 + 27)) {
                return 27;
            } else if (time <= (32 * 60 + 27) && time > (31 * 60 + 32)) {
                return 28;
            } else if (time <= (31 * 60 + 32) && time > (30 * 60 + 40)) {
                return 29;
            } else if (time <= (30 * 60 + 40) && time > (29 * 60 + 51)) {
                return 30;
            } else if (time <= (29 * 60 + 51) && time > (29 * 60 + 5)) {
                return 31;
            } else if (time <= (29 * 60 + 5) && time > (28 * 60 + 21)) {
                return 32;
            } else if (time <= (28 * 60 + 21) && time > (27 * 60 + 39)) {
                return 33;
            } else if (time <= (27 * 60 + 39) && time > (27 * 60)) {
                return 34;
            } else if (time <= (27 * 60) && time > (26 * 60 + 22)) {
                return 35;
            } else if (time <= (26 * 60 + 22) && time > (25 * 60 + 46)) {
                return 36;
            } else if (time <= (25 * 60 + 46) && time > (25 * 60 + 12)) {
                return 37;
            } else if (time <= (25 * 60 + 12) && time > (24 * 60 + 39)) {
                return 38;
            } else if (time <= (24 * 60 + 39) && time > (24 * 60 + 8)) {
                return 39;
            } else if (time <= (24 * 60 + 8) && time > (23 * 60 + 38)) {
                return 40;
            } else if (time <= (23 * 60 + 38) && time > (23 * 60 + 9)) {
                return 41;
            } else if (time <= (23 * 60 + 9) && time > (22 * 60 + 41)) {
                return 42;
            } else if (time <= (22 * 60 + 41) && time > (22 * 60 + 15)) {
                return 43;
            } else if (time <= (22 * 60 + 15) && time > (21 * 60 + 50)) {
                return 44;
            } else if (time <= (21 * 60 + 50) && time > (21 * 60 + 25)) {
                return 45;
            } else if (time <= (21 * 60 + 25) && time > (21 * 60 + 2)) {
                return 46;
            } else if (time <= (21 * 60 + 2) && time > (20 * 60 + 39)) {
                return 47;
            } else if (time <= (20 * 60 + 39) && time > (20 * 60 + 18)) {
                return 48;
            } else if (time <= (20 * 60 + 18) && time > (19 * 60 + 57)) {
                return 49;
            } else if (time <= (19 * 60 + 57) && time > (19 * 60 + 36)) {
                return 50;
            } else if (time <= (19 * 60 + 36) && time > (19 * 60 + 17)) {
                return 51;
            } else if (time <= (19 * 60 + 17) && time > (18 * 60 + 58)) {
                return 52;
            } else if (time <= (18 * 60 + 58) && time > (18 * 60 + 40)) {
                return 53;
            } else if (time <= (18 * 60 + 40) && time > (18 * 60 + 22)) {
                return 54;
            } else if (time <= (18 * 60 + 22) && time > (18 * 60 + 5)) {
                return 55;
            } else if (time <= (18 * 60 + 5) && time > (17 * 60 + 49)) {
                return 56;
            } else if (time <= (17 * 60 + 49) && time > (17 * 60 + 33)) {
                return 57;
            } else if (time <= (17 * 60 + 33) && time > (17 * 60 + 17)) {
                return 58;
            } else if (time <= (17 * 60 + 17) && time > (17 * 60 + 3)) {
                return 59;
            } else if (time <= (17 * 60 + 3) && time > (16 * 60 + 48)) {
                return 60;
            } else if (time <= (16 * 60 + 48) && time > (16 * 60 + 34)) {
                return 61;
            } else if (time <= (16 * 60 + 34) && time > (16 * 60 + 20)) {
                return 62;
            } else if (time <= (16 * 60 + 20) && time > (16 * 60 + 7)) {
                return 63;
            } else if (time <= (16 * 60 + 7) && time > (15 * 60 + 54)) {
                return 64;
            } else if (time <= (15 * 60 + 54) && time > (15 * 60 + 42)) {
                return 65;
            } else if (time <= (15 * 60 + 42) && time > (15 * 60 + 29)) {
                return 66;
            } else if (time <= (15 * 60 + 29) && time > (15 * 60 + 18)) {
                return 67;
            } else if (time <= (15 * 60 + 18) && time > (15 * 60 + 6)) {
                return 68;
            } else if (time <= (15 * 60 + 6) && time > (14 * 60 + 55)) {
                return 69;
            } else if (time <= (14 * 60 + 55) && time > (14 * 60 + 44)) {
                return 70;
            } else if (time <= (14 * 60 + 44) && time > (14 * 60 + 33)) {
                return 71;
            } else if (time <= (14 * 60 + 33) && time > (14 * 60 + 23)) {
                return 72;
            } else if (time <= (14 * 60 + 23) && time > (14 * 60 + 13)) {
                return 73;
            } else if (time <= (14 * 60 + 13) && time > (14 * 60 + 3)) {
                return 74;
            } else if (time <= (14 * 60 + 3) && time > (13 * 60 + 54)) {
                return 75;
            } else if (time <= (13 * 60 + 54) && time > (13 * 60 + 44)) {
                return 76;
            } else if (time <= (13 * 60 + 44) && time > (13 * 60 + 35)) {
                return 77;
            } else if (time <= (13 * 60 + 35) && time > (13 * 60 + 26)) {
                return 78;
            } else if (time <= (13 * 60 + 26) && time > (13 * 60 + 18)) {
                return 79;
            } else if (time <= (13 * 60 + 18) && time > (13 * 60 + 9)) {
                return 80;
            } else if (time <= (13 * 60 + 9) && time > (13 * 60 + 1)) {
                return 81;
            } else if (time <= (13 * 60 + 1) && time > (12 * 60 + 53)) {
                return 82;
            } else if (time <= (12 * 60 + 53) && time > (12 * 60 + 45)) {
                return 83;
            } else if (time <= (12 * 60 + 45) && time > (12 * 60 + 37)) {
                return 84;
            } else if (time <= (12 * 60 + 37)) {
                return 85;
            }

        } else if (distance >= 10000 && distance < 21097) {
            //处于10000米 10公里
            if (time <= (60 * 60 + 28 * 60 + 3) && time > (60 * 60 + 24 * 60 + 47)) {
                return 20;
            } else if (time <= (60 * 60 + 24 * 60 + 47) && time > (60 * 60 + 21 * 60 + 47)) {
                return 21;
            } else if (time <= (60 * 60 + 21 * 60 + 47) && time > (60 * 60 + 18 * 60 + 59)) {
                return 22;
            } else if (time <= (60 * 60 + 18 * 60 + 59) && time > (60 * 60 + 16 * 60 + 20)) {
                return 23;
            } else if (time <= (60 * 60 + 16 * 60 + 20) && time > (60 * 60 + 13 * 60 + 53)) {
                return 24;
            } else if (time <= (60 * 60 + 13 * 60 + 53) && time > (60 * 60 + 11 * 60 + 36)) {
                return 25;
            } else if (time <= (60 * 60 + 11 * 60 + 36) && time > (60 * 60 + 9 * 60 + 28)) {
                return 26;
            } else if (time <= (60 * 60 + 9 * 60 + 28) && time > (60 * 60 + 7 * 60 + 28)) {
                return 27;
            } else if (time <= (60 * 60 + 7 * 60 + 28) && time > (60 * 60 + 5 * 60 + 34)) {
                return 28;
            } else if (time <= (60 * 60 + 5 * 60 + 34) && time > (60 * 60 + 3 * 60 + 46)) {
                return 29;
            } else if (time <= (60 * 60 + 3 * 60 + 46) && time > (60 * 60 + 2 * 60 + 3)) {
                return 30;
            } else if (time <= (60 * 60 + 2 * 60 + 3) && time > (60 * 60 + 26)) {
                return 31;
            } else if (time <= (60 * 60 + 26) && time > (58 * 60 + 54)) {
                return 32;
            } else if (time <= (58 * 60 + 54) && time > (57 * 60 + 26)) {
                return 33;
            } else if (time <= (57 * 60 + 26) && time > (56 * 60 + 3)) {
                return 34;
            } else if (time <= (56 * 60 + 3) && time > (54 * 60 + 44)) {
                return 35;
            } else if (time <= (54 * 60 + 44) && time > (53 * 60 + 29)) {
                return 36;
            } else if (time <= (53 * 60 + 29) && time > (52 * 60 + 17)) {
                return 37;
            } else if (time <= (52 * 60 + 17) && time > (51 * 60 + 9)) {
                return 38;
            } else if (time <= (51 * 60 + 9) && time > (50 * 60 + 3)) {
                return 39;
            } else if (time <= (50 * 60 + 3) && time > (49 * 60 + 1)) {
                return 40;
            } else if (time <= (49 * 60 + 1) && time > (48 * 60 + 1)) {
                return 41;
            } else if (time <= (48 * 60 + 1) && time > (47 * 60 + 4)) {
                return 42;
            } else if (time <= (47 * 60 + 4) && time > (46 * 60 + 9)) {
                return 43;
            } else if (time <= (46 * 60 + 9) && time > (45 * 60 + 16)) {
                return 44;
            } else if (time <= (45 * 60 + 16) && time > (44 * 60 + 25)) {
                return 45;
            } else if (time <= (44 * 60 + 25) && time > (43 * 60 + 36)) {
                return 46;
            } else if (time <= (43 * 60 + 36) && time > (42 * 60 + 50)) {
                return 47;
            } else if (time <= (42 * 60 + 50) && time > (42 * 60 + 4)) {
                return 48;
            } else if (time <= (42 * 60 + 4) && time > (41 * 60 + 21)) {
                return 49;
            } else if (time <= (41 * 60 + 21) && time > (40 * 60 + 39)) {
                return 50;
            } else if (time <= (40 * 60 + 39) && time > (39 * 60 + 59)) {
                return 51;
            } else if (time <= (39 * 60 + 59) && time > (39 * 60 + 20)) {
                return 52;
            } else if (time <= (39 * 60 + 20) && time > (38 * 60 + 42)) {
                return 53;
            } else if (time <= (38 * 60 + 42) && time > (38 * 60 + 6)) {
                return 54;
            } else if (time <= (38 * 60 + 6) && time > (37 * 60 + 31)) {
                return 55;
            } else if (time <= (37 * 60 + 31) && time > (36 * 60 + 57)) {
                return 56;
            } else if (time <= (36 * 60 + 57) && time > (36 * 60 + 24)) {
                return 57;
            } else if (time <= (36 * 60 + 24) && time > (35 * 60 + 52)) {
                return 58;
            } else if (time <= (35 * 60 + 52) && time > (35 * 60 + 22)) {
                return 59;
            } else if (time <= (35 * 60 + 22) && time > (34 * 60 + 52)) {
                return 60;
            } else if (time <= (34 * 60 + 52) && time > (34 * 60 + 23)) {
                return 61;
            } else if (time <= (34 * 60 + 23) && time > (33 * 60 + 55)) {
                return 62;
            } else if (time <= (33 * 60 + 55) && time > (33 * 60 + 28)) {
                return 63;
            } else if (time <= (33 * 60 + 28) && time > (33 * 60 + 1)) {
                return 64;
            } else if (time <= (33 * 60 + 1) && time > (32 * 60 + 35)) {
                return 65;
            } else if (time <= (32 * 60 + 35) && time > (32 * 60 + 11)) {
                return 66;
            } else if (time <= (32 * 60 + 11) && time > (31 * 60 + 46)) {
                return 67;
            } else if (time <= (31 * 60 + 46) && time > (31 * 60 + 23)) {
                return 68;
            } else if (time <= (31 * 60 + 23) && time > (31 * 60)) {
                return 69;
            } else if (time <= (31 * 60) && time > (30 * 60 + 38)) {
                return 70;
            } else if (time <= (30 * 60 + 38) && time > (30 * 60 + 16)) {
                return 71;
            } else if (time <= (30 * 60 + 16) && time > (29 * 60 + 55)) {
                return 72;
            } else if (time <= (29 * 60 + 55) && time > (29 * 60 + 34)) {
                return 73;
            } else if (time <= (29 * 60 + 34) && time > (29 * 60 + 14)) {
                return 74;
            } else if (time <= (29 * 60 + 14) && time > (28 * 60 + 55)) {
                return 75;
            } else if (time <= (28 * 60 + 55) && time > (28 * 60 + 36)) {
                return 76;
            } else if (time <= (28 * 60 + 36) && time > (28 * 60 + 17)) {
                return 77;
            } else if (time <= (28 * 60 + 17) && time > (27 * 60 + 59)) {
                return 78;
            } else if (time <= (27 * 60 + 59) && time > (27 * 60 + 41)) {
                return 79;
            } else if (time <= (27 * 60 + 41) && time > (27 * 60 + 24)) {
                return 80;
            } else if (time <= (27 * 60 + 24) && time > (27 * 60 + 7)) {
                return 81;
            } else if (time <= (27 * 60 + 7) && time > (26 * 60 + 51)) {
                return 82;
            } else if (time <= (26 * 60 + 51) && time > (26 * 60 + 34)) {
                return 83;
            } else if (time <= (26 * 60 + 34) && time > (26 * 60 + 19)) {
                return 84;
            } else if (time <= (26 * 60 + 19)) {
                return 85;
            }
        } else if (distance >= 21097 && distance < 42195) {
            //处于21097米 半马
            if (time <= (3 * 60 * 60 + 15 * 60 + 15) && time > (3 * 60 * 60 + 8 * 60 + 2)) {
                return 20;
            } else if (time <= (3 * 60 * 60 + 8 * 60 + 2) && time > (3 * 60 * 60 + 60 + 23)) {
                return 21;
            } else if (time <= (3 * 60 * 60 + 60 + 23) && time > (2 * 60 * 60 + 55 * 60 + 7)) {
                return 22;
            } else if (time <= (2 * 60 * 60 + 55 * 60 + 7) && time > (2 * 60 * 60 + 49 * 60 + 20)) {
                return 23;
            } else if (time <= (2 * 60 * 60 + 49 * 60 + 20) && time > (2 * 60 * 60 + 43 * 60 + 53)) {
                return 24;
            } else if (time <= (2 * 60 * 60 + 43 * 60 + 53) && time > (2 * 60 * 60 + 38 * 60 + 48)) {
                return 25;
            } else if (time <= (2 * 60 * 60 + 38 * 60 + 48) && time > (2 * 60 * 60 + 34 * 60 + 3)) {
                return 26;
            } else if (time <= (2 * 60 * 60 + 34 * 60 + 3) && time > (2 * 60 * 60 + 29 * 60 + 34)) {
                return 27;
            } else if (time <= (2 * 60 * 60 + 29 * 60 + 34) && time > (2 * 60 * 60 + 25 * 60 + 15)) {
                return 28;
            } else if (time <= (2 * 60 * 60 + 25 * 60 + 15) && time > (2 * 60 * 60 + 21 * 60 + 4)) {
                return 29;
            } else if (time <= (2 * 60 * 60 + 21 * 60 + 4) && time > (2 * 60 * 60 + 17 * 60 + 21)) {
                return 30;
            } else if (time <= (2 * 60 * 60 + 17 * 60 + 21) && time > (2 * 60 * 60 + 13 * 60 + 49)) {
                return 31;
            } else if (time <= (2 * 60 * 60 + 13 * 60 + 49) && time > (2 * 60 * 60 + 10 * 60 + 27)) {
                return 32;
            } else if (time <= (2 * 60 * 60 + 10 * 60 + 27) && time > (2 * 60 * 60 + 7 * 60 + 16)) {
                return 33;
            } else if (time <= (2 * 60 * 60 + 7 * 60 + 16) && time > (2 * 60 * 60 + 4 * 60 + 13)) {
                return 34;
            } else if (time <= (2 * 60 * 60 + 4 * 60 + 13) && time > (2 * 60 * 60 + 60 + 19)) {
                return 35;
            } else if (time <= (2 * 60 * 60 + 60 + 19) && time > (60 * 60 + 58 * 60 + 34)) {
                return 36;
            } else if (time <= (60 * 60 + 58 * 60 + 34) && time > (60 * 60 + 55 * 60 + 55)) {
                return 37;
            } else if (time <= (60 * 60 + 55 * 60 + 55) && time > (60 * 60 + 53 * 60 + 24)) {
                return 38;
            } else if (time <= (60 * 60 + 53 * 60 + 24) && time > (60 * 60 + 50 * 60 + 59)) {
                return 39;
            } else if (time <= (60 * 60 + 50 * 60 + 59) && time > (60 * 60 + 48 * 60 + 40)) {
                return 40;
            } else if (time <= (60 * 60 + 48 * 60 + 40) && time > (60 * 60 + 46 * 60 + 27)) {
                return 41;
            } else if (time <= (60 * 60 + 46 * 60 + 27) && time > (60 * 60 + 44 * 60 + 20)) {
                return 42;
            } else if (time <= (60 * 60 + 44 * 60 + 20) && time > (60 * 60 + 42 * 60 + 17)) {
                return 43;
            } else if (time <= (60 * 60 + 42 * 60 + 17) && time > (60 * 60 + 40 * 60 + 20)) {
                return 44;
            } else if (time <= (60 * 60 + 40 * 60 + 20) && time > (60 * 60 + 38 * 60 + 27)) {
                return 45;
            } else if (time <= (60 * 60 + 38 * 60 + 27) && time > (60 * 60 + 36 * 60 + 38)) {
                return 46;
            } else if (time <= (60 * 60 + 36 * 60 + 38) && time > (60 * 60 + 34 * 60 + 53)) {
                return 47;
            } else if (time <= (60 * 60 + 34 * 60 + 53) && time > (60 * 60 + 33 * 60 + 12)) {
                return 48;
            } else if (time <= (60 * 60 + 33 * 60 + 12) && time > (60 * 60 + 31 * 60 + 35)) {
                return 49;
            } else if (time <= (60 * 60 + 31 * 60 + 35) && time > (60 * 60 + 30 * 60 + 2)) {
                return 50;
            } else if (time <= (60 * 60 + 30 * 60 + 2) && time > (60 * 60 + 28 * 60 + 31)) {
                return 51;
            } else if (time <= (60 * 60 + 28 * 60 + 31) && time > (60 * 60 + 27 * 60 + 4)) {
                return 52;
            } else if (time <= (60 * 60 + 27 * 60 + 4) && time > (60 * 60 + 25 * 60 + 40)) {
                return 53;
            } else if (time <= (60 * 60 + 25 * 60 + 40) && time > (60 * 60 + 24 * 60 + 18)) {
                return 54;
            } else if (time <= (60 * 60 + 24 * 60 + 18) && time > (60 * 60 + 23 * 60)) {
                return 55;
            } else if (time <= (60 * 60 + 23 * 60) && time > (60 * 60 + 21 * 60 + 43)) {
                return 56;
            } else if (time <= (60 * 60 + 21 * 60 + 43) && time > (60 * 60 + 20 * 60 + 30)) {
                return 57;
            } else if (time <= (60 * 60 + 20 * 60 + 30) && time > (60 * 60 + 19 * 60 + 18)) {
                return 58;
            } else if (time <= (60 * 60 + 19 * 60 + 18) && time > (60 * 60 + 18 * 60 + 9)) {
                return 59;
            } else if (time <= (60 * 60 + 18 * 60 + 9) && time > (60 * 60 + 17 * 60 + 2)) {
                return 60;
            } else if (time <= (60 * 60 + 17 * 60 + 2) && time > (60 * 60 + 15 * 60 + 57)) {
                return 61;
            } else if (time <= (60 * 60 + 15 * 60 + 57) && time > (60 * 60 + 14 * 60 + 54)) {
                return 62;
            } else if (time <= (60 * 60 + 14 * 60 + 54) && time > (60 * 60 + 13 * 60 + 53)) {
                return 63;
            } else if (time <= (60 * 60 + 13 * 60 + 53) && time > (60 * 60 + 12 * 60 + 53)) {
                return 64;
            } else if (time <= (60 * 60 + 12 * 60 + 53) && time > (60 * 60 + 11 * 60 + 56)) {
                return 65;
            } else if (time <= (60 * 60 + 11 * 60 + 56) && time > (60 * 60 + 11 * 60)) {
                return 66;
            } else if (time <= (60 * 60 + 11 * 60) && time > (60 * 60 + 10 * 60 + 5)) {
                return 67;
            } else if (time <= (60 * 60 + 10 * 60 + 5) && time > (60 * 60 + 9 * 60 + 12)) {
                return 68;
            } else if (time <= (60 * 60 + 9 * 60 + 12) && time > (60 * 60 + 8 * 60 + 21)) {
                return 69;
            } else if (time <= (60 * 60 + 8 * 60 + 21) && time > (60 * 60 + 7 * 60 + 31)) {
                return 70;
            } else if (time <= (60 * 60 + 7 * 60 + 31) && time > (60 * 60 + 6 * 60 + 42)) {
                return 71;
            } else if (time <= (60 * 60 + 6 * 60 + 42) && time > (60 * 60 + 5 * 60 + 54)) {
                return 72;
            } else if (time <= (60 * 60 + 5 * 60 + 54) && time > (60 * 60 + 5 * 60 + 8)) {
                return 73;
            } else if (time <= (60 * 60 + 5 * 60 + 8) && time > (60 * 60 + 4 * 60 + 23)) {
                return 74;
            } else if (time <= (60 * 60 + 4 * 60 + 23) && time > (60 * 60 + 3 * 60 + 39)) {
                return 75;
            } else if (time <= (60 * 60 + 3 * 60 + 39) && time > (60 * 60 + 2 * 60 + 56)) {
                return 76;
            } else if (time <= (60 * 60 + 2 * 60 + 56) && time > (60 * 60 + 2 * 60 + 15)) {
                return 77;
            } else if (time <= (60 * 60 + 2 * 60 + 15) && time > (60 * 60 + 60 + 34)) {
                return 78;
            } else if (time <= (60 * 60 + 60 + 34) && time > (60 * 60 + 54)) {
                return 79;
            } else if (time <= (60 * 60 + 54) && time > (60 * 60 + 15)) {
                return 80;
            } else if (time <= (60 * 60 + 15) && time > (59 * 60 + 38)) {
                return 81;
            } else if (time <= (59 * 60 + 38) && time > (59 * 60 + 1)) {
                return 82;
            } else if (time <= (59 * 60 + 1) && time > (58 * 60 + 25)) {
                return 83;
            } else if (time <= (58 * 60 + 25) && time > (57 * 60 + 50)) {
                return 84;
            } else if (time <= (57 * 60 + 50)) {
                return 85;
            }
        } else if (distance >= 42195) {//处于42195米 全马
            if (time <= (6 * 60 * 60 + 44 * 60) && time > (6 * 60 * 60 + 44 * 60)) {
                return 20;
            } else if (time <= (6 * 60 * 60 + 44 * 60) && time > (6 * 60 * 60 + 31 * 60)) {
                return 21;
            } else if (time <= (6 * 60 * 60 + 31 * 60) && time > (6 * 60 * 60 + 19 * 60)) {
                return 22;
            } else if (time <= (6 * 60 * 60 + 19 * 60) && time > (6 * 60 * 60 + 8 * 60)) {
                return 23;
            } else if (time <= (6 * 60 * 60 + 8 * 60) && time > (5 * 60 * 60 + 56 * 60)) {
                return 24;
            } else if (time <= (5 * 60 * 60 + 56 * 60) && time > (5 * 60 * 60 + 45 * 60)) {
                return 25;
            } else if (time <= (5 * 60 * 60 + 45 * 60) && time > (5 * 60 * 60 + 35 * 60)) {
                return 26;
            } else if (time <= (5 * 60 * 60 + 35 * 60) && time > (5 * 60 * 60 + 25 * 60)) {
                return 27;
            } else if (time <= (5 * 60 * 60 + 25 * 60) && time > (5 * 60 * 60 + 15 * 60)) {
                return 28;
            } else if (time <= (5 * 60 * 60 + 15 * 60) && time > (5 * 60 * 60 + 6 * 60)) {
                return 29;
            } else if (time <= (5 * 60 * 60 + 6 * 60) && time > (4 * 60 * 60 + 49 * 60 + 17)) {
                return 30;
            } else if (time <= (4 * 60 * 60 + 49 * 60 + 17) && time > (4 * 60 * 60 + 41 * 60 + 57)) {
                return 31;
            } else if (time <= (4 * 60 * 60 + 41 * 60 + 57) && time > (4 * 60 * 60 + 34 * 60 + 59)) {
                return 32;
            } else if (time <= (4 * 60 * 60 + 34 * 60 + 59) && time > (4 * 60 * 60 + 28 * 60 + 22)) {
                return 33;
            } else if (time <= (4 * 60 * 60 + 22 * 60 + 3) && time > (4 * 60 * 60 + 16 * 60 + 3)) {
                return 34;
            } else if (time <= (4 * 60 * 60 + 16 * 60 + 3) && time > (4 * 60 * 60 + 10 * 60 + 19)) {
                return 35;
            } else if (time <= (4 * 60 * 60 + 10 * 60 + 19) && time > (4 * 60 * 60 + 4 * 60 + 50)) {
                return 36;
            } else if (time <= (4 * 60 * 60 + 4 * 60 + 50) && time > (3 * 60 * 60 + 59 * 60 + 35)) {
                return 37;
            } else if (time <= (3 * 60 * 60 + 59 * 60 + 35) && time > (3 * 60 * 60 + 54 * 60 + 34)) {
                return 38;
            } else if (time <= (3 * 60 * 60 + 54 * 60 + 34) && time > (3 * 60 * 60 + 49 * 60 + 45)) {
                return 39;
            } else if (time <= (3 * 60 * 60 + 49 * 60 + 45) && time > (3 * 60 * 60 + 45 * 60 + 9)) {
                return 40;
            } else if (time <= (3 * 60 * 60 + 45 * 60 + 9) && time > (3 * 60 * 60 + 40 * 60 + 43)) {
                return 41;
            } else if (time <= (3 * 60 * 60 + 40 * 60 + 43) && time > (3 * 60 * 60 + 36 * 60 + 28)) {
                return 42;
            } else if (time <= (3 * 60 * 60 + 36 * 60 + 28) && time > (3 * 60 * 60 + 32 * 60 + 23)) {
                return 43;
            } else if (time <= (3 * 60 * 60 + 32 * 60 + 23) && time > (3 * 60 * 60 + 28 * 60 + 26)) {
                return 44;
            } else if (time <= (3 * 60 * 60 + 28 * 60 + 26) && time > (3 * 60 * 60 + 24 * 60 + 39)) {
                return 45;
            } else if (time <= (3 * 60 * 60 + 24 * 60 + 39) && time > (3 * 60 * 60 + 21 * 60)) {
                return 46;
            } else if (time <= (3 * 60 * 60 + 21 * 60) && time > (3 * 60 * 60 + 17 * 60 + 29)) {
                return 47;
            } else if (time <= (3 * 60 * 60 + 17 * 60 + 29) && time > (3 * 60 * 60 + 14 * 60 + 6)) {
                return 48;
            } else if (time <= (3 * 60 * 60 + 14 * 60 + 6) && time > (3 * 60 * 60 + 10 * 60 + 49)) {
                return 49;
            } else if (time <= (3 * 60 * 60 + 10 * 60 + 49) && time > (3 * 60 * 60 + 7 * 60 + 39)) {
                return 50;
            } else if (time <= (3 * 60 * 60 + 7 * 60 + 39) && time > (3 * 60 * 60 + 4 * 60 + 36)) {
                return 51;
            } else if (time <= (3 * 60 * 60 + 4 * 60 + 36) && time > (3 * 60 * 60 + 60 + 39)) {
                return 52;
            } else if (time <= (3 * 60 * 60 + 60 + 39) && time > (2 * 60 * 60 + 58 * 60 + 47)) {
                return 53;
            } else if (time <= (2 * 60 * 60 + 58 * 60 + 47) && time > (2 * 60 * 60 + 56 * 60 + 1)) {
                return 54;
            } else if (time <= (2 * 60 * 60 + 56 * 60 + 1) && time > (2 * 60 * 60 + 53 * 60 + 20)) {
                return 55;
            } else if (time <= (2 * 60 * 60 + 53 * 60 + 20) && time > (2 * 60 * 60 + 50 * 60 + 45)) {
                return 56;
            } else if (time <= (2 * 60 * 60 + 50 * 60 + 45) && time > (2 * 60 * 60 + 48 * 60 + 14)) {
                return 57;
            } else if (time <= (2 * 60 * 60 + 48 * 60 + 14) && time > (2 * 60 * 60 + 45 * 60 + 47)) {
                return 58;
            } else if (time <= (2 * 60 * 60 + 45 * 60 + 47) && time > (2 * 60 * 60 + 43 * 60 + 25)) {
                return 59;
            } else if (time <= (2 * 60 * 60 + 43 * 60 + 25) && time > (2 * 60 * 60 + 41 * 60 + 8)) {
                return 60;
            } else if (time <= (2 * 60 * 60 + 41 * 60 + 8) && time > (2 * 60 * 60 + 38 * 60 + 54)) {
                return 61;
            } else if (time <= (2 * 60 * 60 + 38 * 60 + 54) && time > (2 * 60 * 60 + 36 * 60 + 44)) {
                return 62;
            } else if (time <= (2 * 60 * 60 + 36 * 60 + 44) && time > (2 * 60 * 60 + 34 * 60 + 38)) {
                return 63;
            } else if (time <= (2 * 60 * 60 + 34 * 60 + 38) && time > (2 * 60 * 60 + 32 * 60 + 35)) {
                return 64;
            } else if (time <= (2 * 60 * 60 + 32 * 60 + 35) && time > (2 * 60 * 60 + 30 * 60 + 36)) {
                return 65;
            } else if (time <= (2 * 60 * 60 + 30 * 60 + 36) && time > (2 * 60 * 60 + 28 * 60 + 40)) {
                return 66;
            } else if (time <= (2 * 60 * 60 + 28 * 60 + 40) && time > (2 * 60 * 60 + 26 * 60 + 47)) {
                return 67;
            } else if (time <= (2 * 60 * 60 + 26 * 60 + 47) && time > (2 * 60 * 60 + 24 * 60 + 57)) {
                return 68;
            } else if (time <= (2 * 60 * 60 + 24 * 60 + 57) && time > (2 * 60 * 60 + 23 * 60 + 10)) {
                return 69;
            } else if (time <= (2 * 60 * 60 + 23 * 60 + 10) && time > (2 * 60 * 60 + 21 * 60 + 26)) {
                return 70;
            } else if (time <= (2 * 60 * 60 + 21 * 60 + 26) && time > (2 * 60 * 60 + 19 * 60 + 44)) {
                return 71;
            } else if (time <= (2 * 60 * 60 + 19 * 60 + 44) && time > (2 * 60 * 60 + 18 * 60 + 5)) {
                return 72;
            } else if (time <= (2 * 60 * 60 + 18 * 60 + 5) && time > (2 * 60 * 60 + 16 * 60 + 29)) {
                return 73;
            } else if (time <= (2 * 60 * 60 + 16 * 60 + 29) && time > (2 * 60 * 60 + 14 * 60 + 55)) {
                return 74;
            } else if (time <= (2 * 60 * 60 + 14 * 60 + 55) && time > (2 * 60 * 60 + 13 * 60 + 23)) {
                return 75;
            } else if (time <= (2 * 60 * 60 + 13 * 60 + 23) && time > (2 * 60 * 60 + 11 * 60 + 54)) {
                return 76;
            } else if (time <= (2 * 60 * 60 + 11 * 60 + 54) && time > (2 * 60 * 60 + 10 * 60 + 27)) {
                return 77;
            } else if (time <= (2 * 60 * 60 + 10 * 60 + 27) && time > (2 * 60 * 60 + 9 * 60 + 2)) {
                return 78;
            } else if (time <= (2 * 60 * 60 + 9 * 60 + 2) && time > (2 * 60 * 60 + 7 * 60 + 38)) {
                return 79;
            } else if (time <= (2 * 60 * 60 + 7 * 60 + 38) && time > (2 * 60 * 60 + 6 * 60 + 17)) {
                return 80;
            } else if (time <= (2 * 60 * 60 + 6 * 60 + 17) && time > (2 * 60 * 60 + 4 * 60 + 57)) {
                return 81;
            } else if (time <= (2 * 60 * 60 + 4 * 60 + 57) && time > (2 * 60 * 60 + 3 * 60 + 40)) {
                return 82;
            } else if (time <= (2 * 60 * 60 + 3 * 60 + 40) && time > (2 * 60 * 60 + 2 * 60 + 24)) {
                return 83;
            } else if (time <= (2 * 60 * 60 + 2 * 60 + 24) && time > (2 * 60 * 60 + 60 + 10)) {
                return 84;
            } else if (time <= (2 * 60 * 60 + 60 + 10)) {
                return 85;
            }
        }

        return value;
    }


    /**
     * @param distance 单位：米
     * @return 恰当的路程 int类型 单位：公里
     */
    public static int getRealDistanceValue(double distance) {
        int value = 0;
        if (distance >= 3000 && distance < 5000) {
            //处于3000米 3公里
            return 3;
        } else if (distance >= 5000 && distance < 10000) {
            //处于5000米 5公里
            return 5;
        } else if (distance >= 10000 && distance < 21097) {
            //处于10000米 10公里
            return 10;
        } else if (distance >= 21097 && distance < 42195) {
            //处于21097米 半马
            return 21;
        } else if (distance >= 42195) {//处于42195米 全马
            return 42;
        }

        return value;
    }

    /**
     * @param value        跑力值 int类型
     * @param distanceType 1:5公里 2:10公里 3：半马 4：全马
     * @return
     */
    public static String getBestRunTime(int value, int distanceType) {
        String time = "--";
        switch (value) {
            case 20:
                if (1 == distanceType) {
                    time = "00:42:24";
                } else if (2 == distanceType) {
                    time = "01:28:03";
                } else if (3 == distanceType) {
                    time = "03:15:15";
                } else if (4 == distanceType) {
                    time = "06:44:00";
                }
                break;
            case 21:
                if (1 == distanceType) {
                    time = "00:40:49";
                } else if (2 == distanceType) {
                    time = "01:24:47";
                } else if (3 == distanceType) {
                    time = "03:08:02";
                } else if (4 == distanceType) {
                    time = "06:31:00";
                }
                break;
            case 22:
                if (1 == distanceType) {
                    time = "00:39:22";
                } else if (2 == distanceType) {
                    time = "01:21:47";
                } else if (3 == distanceType) {
                    time = "03:01:23";
                } else if (4 == distanceType) {
                    time = "06:19:00";
                }
                break;
            case 23:
                if (1 == distanceType) {
                    time = "00:38:01";
                } else if (2 == distanceType) {
                    time = "01:18:59";
                } else if (3 == distanceType) {
                    time = "02:55:07";
                } else if (4 == distanceType) {
                    time = "06:08:00";
                }
                break;
            case 24:
                if (1 == distanceType) {
                    time = "00:36:44";
                } else if (2 == distanceType) {
                    time = "01:16:20";
                } else if (3 == distanceType) {
                    time = "02:49:20";
                } else if (4 == distanceType) {
                    time = "05:56:00";
                }
                break;
            case 25:
                if (1 == distanceType) {
                    time = "00:35:33";
                } else if (2 == distanceType) {
                    time = "01:13:53";
                } else if (3 == distanceType) {
                    time = "02:43:53";
                } else if (4 == distanceType) {
                    time = "05:45:00";
                }
                break;
            case 26:
                if (1 == distanceType) {
                    time = "00:34:27";
                } else if (2 == distanceType) {
                    time = "01:11:36";
                } else if (3 == distanceType) {
                    time = "02:38:48";
                } else if (4 == distanceType) {
                    time = "05:35:00";
                }
                break;
            case 27:
                if (1 == distanceType) {
                    time = "00:33:25";
                } else if (2 == distanceType) {
                    time = "01:09:28";
                } else if (3 == distanceType) {
                    time = "02:34:03";
                } else if (4 == distanceType) {
                    time = "05:25:00";
                }
                break;
            case 28:
                if (1 == distanceType) {
                    time = "00:32:27";
                } else if (2 == distanceType) {
                    time = "01:07:28";
                } else if (3 == distanceType) {
                    time = "02:29:34";
                } else if (4 == distanceType) {
                    time = "05:15:00";
                }
                break;
            case 29:
                if (1 == distanceType) {
                    time = "00:31:32";
                } else if (2 == distanceType) {
                    time = "01:05:34";
                } else if (3 == distanceType) {
                    time = "02:25:15";
                } else if (4 == distanceType) {
                    time = "05:06:00";
                }
                break;
            case 30:
                if (1 == distanceType) {
                    time = "00:30:40";
                } else if (2 == distanceType) {
                    time = "01:03:46";
                } else if (3 == distanceType) {
                    time = "02:21:04";
                } else if (4 == distanceType) {
                    time = "04:49:17";
                }
                break;
            case 31:
                if (1 == distanceType) {
                    time = "00:29:51";
                } else if (2 == distanceType) {
                    time = "01:02:03";
                } else if (3 == distanceType) {
                    time = "02:17:21";
                } else if (4 == distanceType) {
                    time = "04:41:57";
                }
                break;
            case 32:
                if (1 == distanceType) {
                    time = "00:29:05";
                } else if (2 == distanceType) {
                    time = "01:00:26";
                } else if (3 == distanceType) {
                    time = "02:13:49";
                } else if (4 == distanceType) {
                    time = "04:34:59";
                }
                break;
            case 33:
                if (1 == distanceType) {
                    time = "00:28:21";
                } else if (2 == distanceType) {
                    time = "00:58:54";
                } else if (3 == distanceType) {
                    time = "02:10:27";
                } else if (4 == distanceType) {
                    time = "04:28:22";
                }
                break;
            case 34:
                if (1 == distanceType) {
                    time = "00:27:39";
                } else if (2 == distanceType) {
                    time = "00:57:26";
                } else if (3 == distanceType) {
                    time = "02:07:16";
                } else if (4 == distanceType) {
                    time = "04:22:03";
                }
                break;
            case 35:
                if (1 == distanceType) {
                    time = "00:27:00";
                } else if (2 == distanceType) {
                    time = "00:56:03";
                } else if (3 == distanceType) {
                    time = "02:04:13";
                } else if (4 == distanceType) {
                    time = "04:16:03";
                }
                break;
            case 36:
                if (1 == distanceType) {
                    time = "00:26:22";
                } else if (2 == distanceType) {
                    time = "00:54:44";
                } else if (3 == distanceType) {
                    time = "02:01:19";
                } else if (4 == distanceType) {
                    time = "04:10:19";
                }
                break;
            case 37:
                if (1 == distanceType) {
                    time = "00:25:46";
                } else if (2 == distanceType) {
                    time = "00:53:29";
                } else if (3 == distanceType) {
                    time = "01:58:34";
                } else if (4 == distanceType) {
                    time = "04:04:50";
                }
                break;
            case 38:
                if (1 == distanceType) {
                    time = "00:25:12";
                } else if (2 == distanceType) {
                    time = "00:52:17";
                } else if (3 == distanceType) {
                    time = "01:55:55";
                } else if (4 == distanceType) {
                    time = "03:59:35";
                }
                break;
            case 39:
                if (1 == distanceType) {
                    time = "00:24:39";
                } else if (2 == distanceType) {
                    time = "00:51:09";
                } else if (3 == distanceType) {
                    time = "01:53:24";
                } else if (4 == distanceType) {
                    time = "03:54:34";
                }
                break;
            case 40:
                if (1 == distanceType) {
                    time = "00:24:08";
                } else if (2 == distanceType) {
                    time = "00:50:03";
                } else if (3 == distanceType) {
                    time = "01:50:59";
                } else if (4 == distanceType) {
                    time = "03:49:45";
                }
                break;
            case 41:
                if (1 == distanceType) {
                    time = "00:23:38";
                } else if (2 == distanceType) {
                    time = "00:49:01";
                } else if (3 == distanceType) {
                    time = "01:48:40";
                } else if (4 == distanceType) {
                    time = "03:45:09";
                }
                break;
            case 42:
                if (1 == distanceType) {
                    time = "00:23:09";
                } else if (2 == distanceType) {
                    time = "00:48:01";
                } else if (3 == distanceType) {
                    time = "01:46:27";
                } else if (4 == distanceType) {
                    time = "03:40:43";
                }
                break;
            case 43:
                if (1 == distanceType) {
                    time = "00:22:41";
                } else if (2 == distanceType) {
                    time = "00:47:04";
                } else if (3 == distanceType) {
                    time = "01:44:20";
                } else if (4 == distanceType) {
                    time = "03:36:28";
                }
                break;
            case 44:
                if (1 == distanceType) {
                    time = "00:22:15";
                } else if (2 == distanceType) {
                    time = "00:46:09";
                } else if (3 == distanceType) {
                    time = "01:42:17";
                } else if (4 == distanceType) {
                    time = "03:32:23";
                }
                break;
            case 45:
                if (1 == distanceType) {
                    time = "00:21:50";
                } else if (2 == distanceType) {
                    time = "00:45:16";
                } else if (3 == distanceType) {
                    time = "01:40:20";
                } else if (4 == distanceType) {
                    time = "03:28:26";
                }
                break;
            case 46:
                if (1 == distanceType) {
                    time = "00:21:25";
                } else if (2 == distanceType) {
                    time = "00:44:25";
                } else if (3 == distanceType) {
                    time = "01:38:27";
                } else if (4 == distanceType) {
                    time = "03:24:39";
                }
                break;
            case 47:
                if (1 == distanceType) {
                    time = "00:21:02";
                } else if (2 == distanceType) {
                    time = "00:43:36";
                } else if (3 == distanceType) {
                    time = "01:36:38";
                } else if (4 == distanceType) {
                    time = "03:21:00";
                }
                break;
            case 48:
                if (1 == distanceType) {
                    time = "00:20:39";
                } else if (2 == distanceType) {
                    time = "00:42:50";
                } else if (3 == distanceType) {
                    time = "01:34:53";
                } else if (4 == distanceType) {
                    time = "03:17:29";
                }
                break;
            case 49:
                if (1 == distanceType) {
                    time = "00:20:18";
                } else if (2 == distanceType) {
                    time = "00:42:04";
                } else if (3 == distanceType) {
                    time = "01:33:12";
                } else if (4 == distanceType) {
                    time = "03:14:06";
                }
                break;
            case 50:
                if (1 == distanceType) {
                    time = "00:19:57";
                } else if (2 == distanceType) {
                    time = "00:41:21";
                } else if (3 == distanceType) {
                    time = "01:31:35";
                } else if (4 == distanceType) {
                    time = "03:10:49";
                }
                break;
            case 51:
                if (1 == distanceType) {
                    time = "00:19:36";
                } else if (2 == distanceType) {
                    time = "00:40:39";
                } else if (3 == distanceType) {
                    time = "01:30:02";
                } else if (4 == distanceType) {
                    time = "03:07:39";
                }
                break;
            case 52:
                if (1 == distanceType) {
                    time = "00:19:17";
                } else if (2 == distanceType) {
                    time = "00:39:59";
                } else if (3 == distanceType) {
                    time = "01:28:31";
                } else if (4 == distanceType) {
                    time = "03:04:36";
                }
                break;
            case 53:
                if (1 == distanceType) {
                    time = "00:18:58";
                } else if (2 == distanceType) {
                    time = "00:39:20";
                } else if (3 == distanceType) {
                    time = "01:27:04";
                } else if (4 == distanceType) {
                    time = "03:01:39";
                }
                break;
            case 54:
                if (1 == distanceType) {
                    time = "00:18:40";
                } else if (2 == distanceType) {
                    time = "00:38:42";
                } else if (3 == distanceType) {
                    time = "01:25:40";
                } else if (4 == distanceType) {
                    time = "02:58:47";
                }
                break;
            case 55:
                if (1 == distanceType) {
                    time = "00:18:22";
                } else if (2 == distanceType) {
                    time = "00:38:06";
                } else if (3 == distanceType) {
                    time = "01:24:18";
                } else if (4 == distanceType) {
                    time = "02:56:01";
                }
                break;
            case 56:
                if (1 == distanceType) {
                    time = "00:18:05";
                } else if (2 == distanceType) {
                    time = "00:37:31";
                } else if (3 == distanceType) {
                    time = "01:23:00";
                } else if (4 == distanceType) {
                    time = "02:53:20";
                }
                break;
            case 57:
                if (1 == distanceType) {
                    time = "00:17:49";
                } else if (2 == distanceType) {
                    time = "00:36:57";
                } else if (3 == distanceType) {
                    time = "01:21:43";
                } else if (4 == distanceType) {
                    time = "02:50:45";
                }
                break;
            case 58:
                if (1 == distanceType) {
                    time = "00:17:33";
                } else if (2 == distanceType) {
                    time = "00:36:24";
                } else if (3 == distanceType) {
                    time = "01:20:30";
                } else if (4 == distanceType) {
                    time = "02:48:14";
                }
                break;
            case 59:
                if (1 == distanceType) {
                    time = "00:17:17";
                } else if (2 == distanceType) {
                    time = "00:35:52";
                } else if (3 == distanceType) {
                    time = "01:19:18";
                } else if (4 == distanceType) {
                    time = "02:45:47";
                }
                break;
            case 60:
                if (1 == distanceType) {
                    time = "00:17:03";
                } else if (2 == distanceType) {
                    time = "00:35:22";
                } else if (3 == distanceType) {
                    time = "01:18:09";
                } else if (4 == distanceType) {
                    time = "02:43:25";
                }
                break;
            case 61:
                if (1 == distanceType) {
                    time = "00:16:48";
                } else if (2 == distanceType) {
                    time = "00:34:52";
                } else if (3 == distanceType) {
                    time = "01:17:02";
                } else if (4 == distanceType) {
                    time = "02:41:08";
                }
                break;
            case 62:
                if (1 == distanceType) {
                    time = "00:16:34";
                } else if (2 == distanceType) {
                    time = "00:34:23";
                } else if (3 == distanceType) {
                    time = "01:15:57";
                } else if (4 == distanceType) {
                    time = "02:38:54";
                }
                break;
            case 63:
                if (1 == distanceType) {
                    time = "00:16:20";
                } else if (2 == distanceType) {
                    time = "00:33:55";
                } else if (3 == distanceType) {
                    time = "01:14:54";
                } else if (4 == distanceType) {
                    time = "02:36:44";
                }
                break;
            case 64:
                if (1 == distanceType) {
                    time = "00:16:07";
                } else if (2 == distanceType) {
                    time = "00:33:28";
                } else if (3 == distanceType) {
                    time = "01:13:53";
                } else if (4 == distanceType) {
                    time = "02:34:38";
                }
                break;
            case 65:
                if (1 == distanceType) {
                    time = "00:15:54";
                } else if (2 == distanceType) {
                    time = "00:33:01";
                } else if (3 == distanceType) {
                    time = "01:12:53";
                } else if (4 == distanceType) {
                    time = "02:32:35";
                }
                break;
            case 66:
                if (1 == distanceType) {
                    time = "00:15:42";
                } else if (2 == distanceType) {
                    time = "00:32:35";
                } else if (3 == distanceType) {
                    time = "01:11:56";
                } else if (4 == distanceType) {
                    time = "02:30:36";
                }
                break;
            case 67:
                if (1 == distanceType) {
                    time = "00:15:29";
                } else if (2 == distanceType) {
                    time = "00:32:11";
                } else if (3 == distanceType) {
                    time = "01:11:00";
                } else if (4 == distanceType) {
                    time = "02:28:40";
                }
                break;
            case 68:
                if (1 == distanceType) {
                    time = "00:15:18";
                } else if (2 == distanceType) {
                    time = "00:31:46";
                } else if (3 == distanceType) {
                    time = "01:10:05";
                } else if (4 == distanceType) {
                    time = "02:26:47";
                }
                break;
            case 69:
                if (1 == distanceType) {
                    time = "00:15:06";
                } else if (2 == distanceType) {
                    time = "00:31:23";
                } else if (3 == distanceType) {
                    time = "01:09:12";
                } else if (4 == distanceType) {
                    time = "02:24:57";
                }
                break;
            case 70:
                if (1 == distanceType) {
                    time = "00:14:55";
                } else if (2 == distanceType) {
                    time = "00:31:00";
                } else if (3 == distanceType) {
                    time = "01:08:21";
                } else if (4 == distanceType) {
                    time = "02:23:10";
                }
                break;
            case 71:
                if (1 == distanceType) {
                    time = "00:14:44";
                } else if (2 == distanceType) {
                    time = "00:30:38";
                } else if (3 == distanceType) {
                    time = "01:07:31";
                } else if (4 == distanceType) {
                    time = "02:21:26";
                }
                break;
            case 72:
                if (1 == distanceType) {
                    time = "00:14:33";
                } else if (2 == distanceType) {
                    time = "00:30:16";
                } else if (3 == distanceType) {
                    time = "01:06:42";
                } else if (4 == distanceType) {
                    time = "02:19:44";
                }
                break;
            case 73:
                if (1 == distanceType) {
                    time = "00:14:23";
                } else if (2 == distanceType) {
                    time = "00:29:55";
                } else if (3 == distanceType) {
                    time = "01:05:54";
                } else if (4 == distanceType) {
                    time = "02:18:05";
                }
                break;
            case 74:
                if (1 == distanceType) {
                    time = "00:14:13";
                } else if (2 == distanceType) {
                    time = "00:29:34";
                } else if (3 == distanceType) {
                    time = "01:05:08";
                } else if (4 == distanceType) {
                    time = "02:16:29";
                }
                break;
            case 75:
                if (1 == distanceType) {
                    time = "00:14:03";
                } else if (2 == distanceType) {
                    time = "00:29:14";
                } else if (3 == distanceType) {
                    time = "01:04:23";
                } else if (4 == distanceType) {
                    time = "02:14:55";
                }
                break;
            case 76:
                if (1 == distanceType) {
                    time = "00:13:54";
                } else if (2 == distanceType) {
                    time = "00:28:55";
                } else if (3 == distanceType) {
                    time = "01:03:39";
                } else if (4 == distanceType) {
                    time = "02:13:23";
                }
                break;
            case 77:
                if (1 == distanceType) {
                    time = "00:13:44";
                } else if (2 == distanceType) {
                    time = "00:28:36";
                } else if (3 == distanceType) {
                    time = "01:02:56";
                } else if (4 == distanceType) {
                    time = "02:11:54";
                }
                break;
            case 78:
                if (1 == distanceType) {
                    time = "00:13:35";
                } else if (2 == distanceType) {
                    time = "00:28:17";
                } else if (3 == distanceType) {
                    time = "01:02:15";
                } else if (4 == distanceType) {
                    time = "02:10:27";
                }
                break;
            case 79:
                if (1 == distanceType) {
                    time = "00:13:26";
                } else if (2 == distanceType) {
                    time = "00:27:59";
                } else if (3 == distanceType) {
                    time = "01:01:34";
                } else if (4 == distanceType) {
                    time = "02:09:02";
                }
                break;
            case 80:
                if (1 == distanceType) {
                    time = "00:13:18";
                } else if (2 == distanceType) {
                    time = "00:27:41";
                } else if (3 == distanceType) {
                    time = "01:00:54";
                } else if (4 == distanceType) {
                    time = "02:07:38";
                }
                break;
            case 81:
                if (1 == distanceType) {
                    time = "00:13:09";
                } else if (2 == distanceType) {
                    time = "00:27:24";
                } else if (3 == distanceType) {
                    time = "01:00:15";
                } else if (4 == distanceType) {
                    time = "02:06:17";
                }
                break;
            case 82:
                if (1 == distanceType) {
                    time = "00:13:01";
                } else if (2 == distanceType) {
                    time = "00:27:07";
                } else if (3 == distanceType) {
                    time = "00:59:38";
                } else if (4 == distanceType) {
                    time = "02:04:57";
                }
                break;
            case 83:
                if (1 == distanceType) {
                    time = "00:12:53";
                } else if (2 == distanceType) {
                    time = "00:26:51";
                } else if (3 == distanceType) {
                    time = "00:59:01";
                } else if (4 == distanceType) {
                    time = "02:03:40";
                }
                break;
            case 84:
                if (1 == distanceType) {
                    time = "00:12:45";
                } else if (2 == distanceType) {
                    time = "00:26:34";
                } else if (3 == distanceType) {
                    time = "00:58:25";
                } else if (4 == distanceType) {
                    time = "02:02:24";
                }
                break;
            case 85:
                if (1 == distanceType) {
                    time = "00:12:37";
                } else if (2 == distanceType) {
                    time = "00:26:19";
                } else if (3 == distanceType) {
                    time = "00:57:50";
                } else if (4 == distanceType) {
                    time = "02:01:10";
                }
                break;

        }
        return time;
    }
}
