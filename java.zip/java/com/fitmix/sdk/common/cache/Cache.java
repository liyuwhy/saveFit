package com.fitmix.sdk.common.cache;

/**
 * Cache for proxy.
 *
 * @author Alexey Danilov (danikula@gmail.com).
 */
public interface Cache {

    /**
     * 获取RandomAccessFile文件的长度，即获取文件最后一个data的位置
     *
     * @return
     * @throws ProxyCacheException
     */
    int available() throws ProxyCacheException;

    /**
     * 读取指定位置的数据
     *
     * @param buffer
     * @param offset
     * @param length
     * @return
     * @throws ProxyCacheException
     */
    int read(byte[] buffer, long offset, int length) throws ProxyCacheException;

    /**
     * 往临时文件里写数据
     *
     * @param data
     * @param length
     * @throws ProxyCacheException
     */
    void append(byte[] data, int length) throws ProxyCacheException;

    /**
     * 缓存结束后操作
     *
     * @throws ProxyCacheException
     */
    void close() throws ProxyCacheException;

    /**
     * 缓存完成后的操作，由临时文件生成音频文件后缀的文件
     *
     * @throws ProxyCacheException
     */
    void complete() throws ProxyCacheException;

    /**
     * 判断缓存是否完成
     *
     * @return
     */
    boolean isCompleted();
}
