package com.fitmix.sdk.common.cache;

import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Log;

import com.fitmix.sdk.common.cache.file.DiskUsage;
import com.fitmix.sdk.common.cache.file.FileNameGenerator;
import com.fitmix.sdk.common.cache.file.Md5FileNameGenerator;
import com.fitmix.sdk.common.cache.file.TotalCountLruDiskUsage;
import com.fitmix.sdk.common.cache.file.TotalSizeLruDiskUsage;
import com.fitmix.sdk.common.cache.sourcestorage.SourceInfoStorage;
import com.fitmix.sdk.common.cache.sourcestorage.SourceInfoStorageFactory;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import static com.fitmix.sdk.common.cache.Preconditions.checkAllNotNull;
import static com.fitmix.sdk.common.cache.Preconditions.checkNotNull;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

/**
 * Simple lightweight proxy server with file caching support that handles HTTP requests.
 * Typical usage:
 * <pre><code>
 * public onCreate(Bundle state) {
 *      super.onCreate(state);
 * <p/>
 *      HttpProxyCacheServer proxy = getProxy();
 *      String proxyUrl = proxy.getProxyUrl(VIDEO_URL);
 *      videoView.setVideoPath(proxyUrl);
 * }
 * <p/>
 * private HttpProxyCacheServer getProxy() {
 * // should return single instance of HttpProxyCacheServer shared for whole app.
 * }
 * <code/></pre>
 *
 * @author Alexey Danilov (danikula@gmail.com).
 */
public class HttpProxyCacheServer {

    private static final String PROXY_HOST = "127.0.0.1";
    private static final String PING_REQUEST = "ping";
    private static final String PING_RESPONSE = "ping ok";

    private final Object clientsLock = new Object();
    private final ExecutorService socketProcessor = Executors.newFixedThreadPool(8);//线程池中定义最多跑的线程数量
    //url为键，HttpProxyCacheServerClients为值的键值对，HttpProxyCacheServerClients为HttpProxyCacheServer的客户端
    private final Map<String, HttpProxyCacheServerClients> clientsMap = new ConcurrentHashMap<>();
    private final ServerSocket serverSocket;
    private final int port;
    private final Thread waitConnectionThread;
    private final Config config;
    private boolean pinged;

    public HttpProxyCacheServer(Context context) {
//        int max_cache_size = PrefsHelper.with(context, com.fitmix.sdk.Config.PREFS_USER).readInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, com.fitmix.sdk.Config.SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE);
//        this(new Builder(context).maxCacheSize((PrefsHelper.with(context, com.fitmix.sdk.Config.PREFS_USER).readInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, com.fitmix.sdk.Config.SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE)) * 1024 * 1024).buildConfig());
        this(new Builder(context).buildConfig());
    }

    private HttpProxyCacheServer(Config config) {
        this.config = checkNotNull(config);
        try {
            InetAddress inetAddress = InetAddress.getByName(PROXY_HOST);
            this.serverSocket = new ServerSocket(0, 8, inetAddress);//port服务端要监听的端口；backlog客户端连接请求的队列长度；bindAddr服务端绑定IP。如果设置端口为0，则系统会自动为其分配一个端口
            this.port = serverSocket.getLocalPort();
            CountDownLatch startSignal = new CountDownLatch(1);//辅助线程类
            this.waitConnectionThread = new Thread(new WaitRequestsRunnable(startSignal));
            this.waitConnectionThread.start();
            startSignal.await(); // freeze thread, wait for server starts，线程阻塞，直到CountDownLatch的count为0才继续执行,确保线程跑完才继续往下执行
            Log.i(ProxyCacheUtils.LOG_TAG, "Proxy cache server started. Ping it...");
            makeSureServerWorks();
        } catch (IOException | InterruptedException e) {
            socketProcessor.shutdown();
            throw new IllegalStateException("Error starting local proxy server", e);
        }
    }

    private void makeSureServerWorks() {
        int maxPingAttempts = 3;//设置尝试ping的最多的次数
        int delay = 300;
        int pingAttempts = 0;
        while (pingAttempts < maxPingAttempts) {
            try {
                //Future模式可以这样来描述：我有一个任务，提交给了Future，Future替我完成这个任务。期间我自己可以去做任何想做的事情。
                //一段时 间之后，我就便可以从Future那儿取出结果。就相当于下了一张订货单，一段时间后可以拿着提订单来提货，这期间可以干别的任何事情。
                //其中Future 接口就是订货单，真正处理订单的是Executor类，它根据Future接口的要求来生产产品。
                //Future接口提供方法来检测任务是否被执行完，等待任务执行完获得结果，也可以设置任务执行的超时时间。这个设置超时的方法就是实现Java程 序执行超时的关键。
                Future<Boolean> pingFuture = socketProcessor.submit(new PingCallable());
                this.pinged = pingFuture.get(delay, MILLISECONDS);//等待300ms，后去结果
                if (this.pinged) {
                    return;
                }
                SystemClock.sleep(delay);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                Log.e(ProxyCacheUtils.LOG_TAG, "Error pinging server [attempt: " + pingAttempts + ", timeout: " + delay + "]. ", e);
            }
            pingAttempts++;
            delay *= 2;
        }
        Log.e(ProxyCacheUtils.LOG_TAG, "Shutdown server… Error pinging server [attempts: " + pingAttempts + ", max timeout: " + delay / 2 + "]. " +
                "If you see this message, please, email me danikula@gmail.com");
        shutdown();
    }

    private boolean pingServer() throws ProxyCacheException {
        String pingUrl = appendToProxyUrl(PING_REQUEST);//http://127.0.0.1:port/ProxyCacheUtils.encode(ping)
        HttpUrlSource source = new HttpUrlSource(pingUrl);
        try {
//            Log.d(ProxyCacheUtils.LOG_TAG, "time:"+System.currentTimeMillis()+"before pingServer");
            byte[] expectedResponse = PING_RESPONSE.getBytes();
            source.open(0);
//            Log.d(ProxyCacheUtils.LOG_TAG,"after pingService,time:"+System.currentTimeMillis());
            byte[] response = new byte[expectedResponse.length];
            source.read(response);
            boolean pingOk = Arrays.equals(expectedResponse, response);
            Log.d(ProxyCacheUtils.LOG_TAG, "Ping response: `" + new String(response) + "`, pinged? " + pingOk);
            return pingOk;
        } catch (ProxyCacheException e) {
            Log.e(ProxyCacheUtils.LOG_TAG, "Error reading ping response", e);
            return false;
        } finally {
            source.close();
        }
    }

    public String getProxyUrl(String url) {
        if (!pinged) {
            Log.e(ProxyCacheUtils.LOG_TAG, "Proxy server isn't pinged. Caching doesn't work. If you see this message, please, email me danikula@gmail.com");
        }
        if (isCached(url)) {
            File cacheFile = getCacheFile(url);
            touchFileSafely(cacheFile);
            return Uri.fromFile(cacheFile).toString();
        }
        return pinged ? appendToProxyUrl(url) : url;
    }

    private void touchFileSafely(File cacheFile) {
        try {
            config.diskUsage.touch(cacheFile);
        } catch (IOException e) {
            Log.e("Error touching file " + cacheFile, e.toString());
        }
    }

    private File getCacheFile(String url) {
        File cacheDir = config.cacheRoot;
        String fileName = config.fileNameGenerator.generate(url);
        return new File(cacheDir, fileName);
    }

    private String appendToProxyUrl(String url) {
        return String.format("http://%s:%d/%s", PROXY_HOST, port, ProxyCacheUtils.encode(url));
    }

    public void registerCacheListener(CacheListener cacheListener, String url) {
        checkAllNotNull(cacheListener, url);
        synchronized (clientsLock) {
            try {
                getClients(url).registerCacheListener(cacheListener);
            } catch (ProxyCacheException e) {
                Log.d(ProxyCacheUtils.LOG_TAG, "Error registering cache listener", e);
            }
        }
    }

    public void unregisterCacheListener(CacheListener cacheListener, String url) {
        checkAllNotNull(cacheListener, url);
        synchronized (clientsLock) {
            try {
                getClients(url).unregisterCacheListener(cacheListener);
            } catch (ProxyCacheException e) {
                Log.d(ProxyCacheUtils.LOG_TAG, "Error registering cache listener", e);
            }
        }
    }

    public void unregisterCacheListener(CacheListener cacheListener) {
        checkNotNull(cacheListener);
        synchronized (clientsLock) {
            for (HttpProxyCacheServerClients clients : clientsMap.values()) {
                clients.unregisterCacheListener(cacheListener);
            }
        }
    }

    /**
     * Checks is cache contains fully cached file for particular url.
     *
     * @param url an url cache file will be checked for.
     * @return {@code true} if cache contains fully cached file for passed in parameters url.
     */
    public boolean isCached(String url) {
        checkNotNull(url, "Url can't be null!");
        File cacheFile = getCacheFile(url);
        return cacheFile.exists();
    }

    public void shutdown() {
        Log.i(ProxyCacheUtils.LOG_TAG, "Shutdown proxy server");

        shutdownClients();

        config.sourceInfoStorage.release();

        waitConnectionThread.interrupt();
        try {
            if (!serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException e) {
            onError(new ProxyCacheException("Error shutting down proxy server", e));
        }
    }

    private void shutdownClients() {
        synchronized (clientsLock) {
            for (HttpProxyCacheServerClients clients : clientsMap.values()) {
                clients.shutdown();
            }
            clientsMap.clear();
        }
    }

    private void waitForRequest() {
        try {
            //阻塞函数，如：Thread.sleep、Thread.join、Object.wait等在检查到线程的中断状态时，会抛出InterruptedException，同时会清除线程的中断状态
            while (!Thread.currentThread().isInterrupted()) {//判断线程是否处于中断状态
                Socket socket = serverSocket.accept();//获取服务器传递的
                Log.d(ProxyCacheUtils.LOG_TAG, "Accept new socket " + socket);
                socketProcessor.submit(new SocketProcessorRunnable(socket));
            }
        } catch (IOException e) {
            onError(new ProxyCacheException("Error during waiting connection", e));
        }
    }

    /**
     * 处理服务器传递过来的Socket
     *
     * @param socket
     */
    private void processSocket(Socket socket) {
        try {
            //根据socket的输入流，定义一个网络请求
            GetRequest request = GetRequest.read(socket.getInputStream());
            Log.i(ProxyCacheUtils.LOG_TAG, "Request to cache proxy:" + request);
            String url = ProxyCacheUtils.decode(request.uri);
            if (PING_REQUEST.equals(url)) {//url为"ping"，第一次均为ping服务器，走该方法内
                responseToPing(socket);
            } else {//url为音频资源的url，ping服务器成功后走该方法
                HttpProxyCacheServerClients clients = getClients(url);
                //处理从服务器传递过来的request请求
                clients.processRequest(request, socket);
            }
        } catch (SocketException e) {
            // There is no way to determine that client closed connection http://stackoverflow.com/a/10241044/999458
            // So just to prevent log flooding don't log stacktrace
            Log.d(ProxyCacheUtils.LOG_TAG, "Closing socket… Socket is closed by client.");
        } catch (ProxyCacheException | IOException e) {
            onError(new ProxyCacheException("Error processing request", e));
        } finally {
            releaseSocket(socket);
            Log.d(ProxyCacheUtils.LOG_TAG, "Opened connections: " + getClientsCount());
        }
    }

    private void responseToPing(Socket socket) throws IOException {
        OutputStream out = socket.getOutputStream();
        out.write("HTTP/1.1 200 OK\n\n".getBytes());
        out.write(PING_RESPONSE.getBytes());
    }

    private HttpProxyCacheServerClients getClients(String url) throws ProxyCacheException {
        synchronized (clientsLock) {
            HttpProxyCacheServerClients clients = clientsMap.get(url);
            if (clients == null) {
                clients = new HttpProxyCacheServerClients(url, config);
                clientsMap.put(url, clients);
            }
            return clients;
        }
    }

    private int getClientsCount() {
        synchronized (clientsLock) {
            int count = 0;
            for (HttpProxyCacheServerClients clients : clientsMap.values()) {
                count += clients.getClientsCount();
            }
            return count;
        }
    }

    /**
     * close Socket
     *
     * @param socket
     */
    private void releaseSocket(Socket socket) {
        closeSocketInput(socket);
        closeSocketOutput(socket);
        closeSocket(socket);
    }

    private void closeSocketInput(Socket socket) {
        try {
            if (!socket.isInputShutdown()) {
                socket.shutdownInput();
            }
        } catch (SocketException e) {
            // There is no way to determine that client closed connection http://stackoverflow.com/a/10241044/999458
            // So just to prevent log flooding don't log stacktrace
            Log.d(ProxyCacheUtils.LOG_TAG, "Releasing input stream… Socket is closed by client.");
        } catch (IOException e) {
            onError(new ProxyCacheException("Error closing socket input stream", e));
        }
    }

    private void closeSocketOutput(Socket socket) {
        try {
            if (socket.isOutputShutdown()) {
                socket.shutdownOutput();
            }
        } catch (IOException e) {
            onError(new ProxyCacheException("Error closing socket output stream", e));
        }
    }

    private void closeSocket(Socket socket) {
        try {
            if (!socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            onError(new ProxyCacheException("Error closing socket", e));
        }
    }

    private void onError(Throwable e) {
        Log.e(ProxyCacheUtils.LOG_TAG, "HttpProxyCacheServer error", e);
    }

    private final class WaitRequestsRunnable implements Runnable {

        private final CountDownLatch startSignal;//辅助线程类

        public WaitRequestsRunnable(CountDownLatch startSignal) {
            this.startSignal = startSignal;
        }

        @Override
        public void run() {
            startSignal.countDown();
            waitForRequest();
        }
    }

    /**
     * 根据服务器传递过来的socket，跑一个线程
     */
    private final class SocketProcessorRunnable implements Runnable {

        private final Socket socket;

        public SocketProcessorRunnable(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            processSocket(socket);
        }
    }

    /**
     * ping服务器的线程runnable方法
     */
    private class PingCallable implements Callable<Boolean> {

        @Override
        public Boolean call() throws Exception {
            return pingServer();
        }
    }

    /**
     * Builder for {@link HttpProxyCacheServer}.
     */
    public static final class Builder {

        private static final long DEFAULT_MAX_SIZE = 512 * 1024 * 1024;

        private File cacheRoot;//缓存文件的目录
        private FileNameGenerator fileNameGenerator;//根据URL生成MD5名称的生成器
        private DiskUsage diskUsage;//缓存大小的最大值
        private SourceInfoStorage sourceInfoStorage;//存储缓存相关信息的数据库表

        public Builder(Context context) {
            this.sourceInfoStorage = SourceInfoStorageFactory.newSourceInfoStorage(context);
            this.cacheRoot = StorageUtils.getIndividualCacheDirectory(context);
            this.diskUsage = new TotalSizeLruDiskUsage(DEFAULT_MAX_SIZE);
            this.fileNameGenerator = new Md5FileNameGenerator();
        }

        /**
         * Overrides default cache folder to be used for caching files.
         * <p/>
         * By default AndroidVideoCache uses
         * '/Android/data/[app_package_name]/cache/video-cache/' if card is mounted and app has appropriate permission
         * or 'video-cache' subdirectory in default application's cache directory otherwise.
         * <p/>
         * <b>Note</b> directory must be used <b>only</b> for AndroidVideoCache files.
         *
         * @param file a cache directory, can't be null.
         * @return a builder.
         */
        public Builder cacheDirectory(File file) {
            this.cacheRoot = checkNotNull(file);
            return this;
        }

        /**
         * Overrides default cache file name generator {@link Md5FileNameGenerator} .
         *
         * @param fileNameGenerator a new file name generator.
         * @return a builder.
         */
        public Builder fileNameGenerator(FileNameGenerator fileNameGenerator) {
            this.fileNameGenerator = checkNotNull(fileNameGenerator);
            return this;
        }

        /**
         * Sets max cache size in bytes.
         * All files that exceeds limit will be deleted using LRU strategy.
         * Default value is 512 Mb.
         * <p/>
         * Note this method overrides result of calling {@link #maxCacheFilesCount(int)}
         *
         * @param maxSize max cache size in bytes.
         * @return a builder.
         */
        public Builder maxCacheSize(long maxSize) {
            this.diskUsage = new TotalSizeLruDiskUsage(maxSize);
            return this;
        }

        /**
         * Sets max cache files count.
         * All files that exceeds limit will be deleted using LRU strategy.
         * <p/>
         * Note this method overrides result of calling {@link #maxCacheSize(long)}
         *
         * @param count max cache files count.
         * @return a builder.
         */
        public Builder maxCacheFilesCount(int count) {
            this.diskUsage = new TotalCountLruDiskUsage(count);
            return this;
        }

        /**
         * Builds new instance of {@link HttpProxyCacheServer}.
         *
         * @return proxy cache. Only single instance should be used across whole app.
         */
        public HttpProxyCacheServer build() {
            Config config = buildConfig();
            return new HttpProxyCacheServer(config);
        }

        private Config buildConfig() {
            return new Config(cacheRoot, fileNameGenerator, diskUsage, sourceInfoStorage);
        }

    }
}
