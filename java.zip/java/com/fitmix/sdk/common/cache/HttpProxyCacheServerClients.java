package com.fitmix.sdk.common.cache;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.fitmix.sdk.common.cache.file.FileCache;

import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import static com.fitmix.sdk.common.cache.Preconditions.checkNotNull;


/**
 * Http缓存服务客户端
 * Client for {@link HttpProxyCacheServer}
 *
 * @author Alexey Danilov (danikula@gmail.com).
 */
final class HttpProxyCacheServerClients {
    //AtomicInteger，一个提供原子操作的Integer的类。在Java语言中，++i和i++操作并不是线程安全的，
    // 在使用的时候，不可避免的会用到synchronized关键字。而AtomicInteger则通过一种线程安全的加减操作接口。
    private final AtomicInteger clientsCount = new AtomicInteger(0);
    private final String url;
    private volatile HttpProxyCache proxyCache;
    //CopyOnWriteArrayList
    //通俗的理解是当我们往一个容器添加元素的时候，不直接往当前容器添加，
    // 而是先将当前容器进行Copy，复制出一个新的容器，然后新的容器里添加元素，添加完元素之后，再将原容器的引用指向新的容器。
    // 这样做的好处是我们可以对CopyOnWrite容器进行并发的读，而不需要加锁，因为当前容器不会添加任何元素。
    // 所以CopyOnWrite容器也是一种读写分离的思想，读和写不同的容器。
    //http://ifeve.com/java-copy-on-write/
    private final List<CacheListener> listeners = new CopyOnWriteArrayList<>();
    private final CacheListener uiCacheListener;
    private final Config config;

    public HttpProxyCacheServerClients(String url, Config config) {
        this.url = checkNotNull(url);
        this.config = checkNotNull(config);
        this.uiCacheListener = new UiListenerHandler(url, listeners);
    }

    /**
     * 处理服务器的请求
     *
     * @param request
     * @param socket
     * @throws ProxyCacheException
     * @throws IOException
     */
    public void processRequest(GetRequest request, Socket socket) throws ProxyCacheException, IOException {
        startProcessRequest();//新建缓存代理
        try {
            clientsCount.incrementAndGet();
            proxyCache.processRequest(request, socket);//在缓存代理中处理请求
        } finally {
            finishProcessRequest();
        }
    }

    /**
     * 开启Http请求缓存
     *
     * @throws ProxyCacheException
     */
    private synchronized void startProcessRequest() throws ProxyCacheException {
        Log.d("ProxyCache", "HttpProxyCacheServerClients.startProcessRequest(),proxyCache == " + (proxyCache == null ? "null" : "not null"));
        proxyCache = proxyCache == null ? newHttpProxyCache() : proxyCache;
    }

    private synchronized void finishProcessRequest() {

        if (clientsCount.decrementAndGet() <= 0) {
            Log.d("ProxyCache", "HttpProxyCacheServerClients.finishProcessRequest(),,,,clientsCount.decrementAndGet() <= 0");
            proxyCache.shutdown();
            proxyCache = null;//完成后清除缓冲代理，
        } else {
            Log.d("ProxyCache", "HttpProxyCacheServerClients.finishProcessRequest(),,,,clientsCount.decrementAndGet() > 0");
        }
    }

    public void registerCacheListener(CacheListener cacheListener) {
        listeners.add(cacheListener);
    }

    public void unregisterCacheListener(CacheListener cacheListener) {
        listeners.remove(cacheListener);
    }

    public void shutdown() {
        listeners.clear();
        if (proxyCache != null) {
            proxyCache.registerCacheListener(null);
            proxyCache.shutdown();
            proxyCache = null;
        }
        clientsCount.set(0);
    }

    public int getClientsCount() {
        return clientsCount.get();
    }

    /**
     * 生成Http缓存代理
     *
     * @return
     * @throws ProxyCacheException
     */
    private HttpProxyCache newHttpProxyCache() throws ProxyCacheException {
        HttpUrlSource source = new HttpUrlSource(url, config.sourceInfoStorage);
        FileCache cache = new FileCache(config.generateCacheFile(url), config.diskUsage);
        HttpProxyCache httpProxyCache = new HttpProxyCache(source, cache);
        httpProxyCache.registerCacheListener(uiCacheListener);
        return httpProxyCache;
    }

    private static final class UiListenerHandler extends Handler implements CacheListener {

        private final String url;
        private final List<CacheListener> listeners;

        public UiListenerHandler(String url, List<CacheListener> listeners) {
            super(Looper.getMainLooper());
            this.url = url;
            this.listeners = listeners;
        }

        @Override
        public void onCacheAvailable(File file, String url, int percentsAvailable) {
            Message message = obtainMessage();
            message.arg1 = percentsAvailable;
            message.obj = file;
            sendMessage(message);
        }

        @Override
        public void handleMessage(Message msg) {
            for (CacheListener cacheListener : listeners) {
                cacheListener.onCacheAvailable((File) msg.obj, url, msg.arg1);
            }
        }
    }
}
