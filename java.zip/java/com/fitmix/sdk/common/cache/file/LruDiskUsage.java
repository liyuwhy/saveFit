package com.fitmix.sdk.common.cache.file;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * {@link DiskUsage} that uses LRU (Least Recently Used) strategy to trim cache.
 *
 * @author Alexey Danilov (danikula@gmail.com).
 */
abstract class LruDiskUsage implements DiskUsage {

    private static final String LOG_TAG = "ProxyCache";
    private final ExecutorService workerThread = Executors.newSingleThreadExecutor();

    @Override
    public void touch(File file) throws IOException {
        workerThread.submit(new TouchCallable(file));
//        touchInBackground(file);
    }

    /**
     * 根据一文件获取同一目录下全部文件的列表（按照文件修改的顺序），与缓存上限进行对比，多出则删除。
     *
     * @param file
     * @throws IOException
     */
    private void touchInBackground(File file) throws IOException {
        Log.d("ProxyCache", "LruDiskUsage  touchInBackground()");
        Files.setLastModifiedNow(file);
        List<File> files = Files.getLruListFiles(file.getParentFile());
        trim(files);
    }

    protected abstract boolean accept(File file, long totalSize, int totalCount);

    /**
     * 将已有的文件列表总大小与最大的缓存限制进行对比，如果超过则删除新加的文件
     *
     * @param files
     */
    private void trim(List<File> files) {

        long totalSize = countTotalSize(files);
        int totalCount = files.size();
        Log.d("ProxyCache", "LruDiskUsage  trim(),totalSize=" + totalCount + ",totalCount=" + totalCount);
        for (File file : files) {
            boolean accepted = accept(file, totalSize, totalCount);
            if (!accepted) {
                long fileSize = file.length();
                boolean deleted = file.delete();
                if (deleted) {
                    totalCount--;
                    totalSize -= fileSize;
                    Log.i(LOG_TAG, "Cache file " + file + " is deleted because it exceeds cache limit");
                } else {
                    Log.e(LOG_TAG, "Error deleting file " + file + " for trimming cache");
                }
            }
        }
    }

    private long countTotalSize(List<File> files) {
        long totalSize = 0;
        for (File file : files) {
            totalSize += file.length();
        }
        return totalSize;
    }

    private class TouchCallable implements Callable<Void> {

        private final File file;

        public TouchCallable(File file) {
            this.file = file;
        }

        @Override
        public Void call() throws Exception {
            touchInBackground(file);
            return null;
        }
    }
}
