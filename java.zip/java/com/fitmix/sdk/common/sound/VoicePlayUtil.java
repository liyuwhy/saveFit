package com.fitmix.sdk.common.sound;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.text.TextUtils;

import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.Logger;

public class VoicePlayUtil {

//    public String gettotaltimeassets(Context context) {
//
//        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
//        AssetFileDescriptor d = null;
//        try {
//            d = context.getAssets().openFd("ASSETS FILE NAME");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        mmr.setDataSource(d.getFileDescriptor(), d.getStartOffset(), d.getLength());
//        String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
//        long dur = Long.parseLong(duration);
//        String seconds = String.valueOf((dur % 60000) / 1000);
//        Logger.d("seconds===========>", seconds);
//        mmr.release();
//        return seconds;
//    }

    /**
     * 获取音效文件的声音时长
     *
     * @param filePath 音效文件名
     */
    public static long getVoiceEnDuration(String filePath, Context context) {
        if (FileUtils.isFileExist(filePath)) {
            // load data file
            try {
                MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                metaRetriever.setDataSource(context, Uri.parse(filePath));
                // get mp3 info
                // convert duration to seconds:seconds
                String duration =
                        metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long dur = Long.parseLong(duration);
                // close object
                metaRetriever.release();
                Logger.i(Logger.DEBUG_TAG, "filePath:" + filePath + ",long  duration:" + dur);
                return dur;
            } catch (Exception e) {
                Logger.e(Logger.DEBUG_TAG, "getVoiceEnDuration error:" + e.getMessage());
            }
        }
        return 2000;
    }

    /**
     * 获取apk包中音效文件的声音时长
     *
     * @param rawId raw文件id名
     */
    public static long getRawVoiceEnDuration(int rawId, Context context) {
        String filePath;
        if (rawId != -1) {
            filePath = "android.resource://" + context.getPackageName() + "/" + rawId;
            if (!TextUtils.isEmpty(filePath)) {
                // load data file
                MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                metaRetriever.setDataSource(context, Uri.parse(filePath));
                // get mp3 info
                // convert duration to seconds:seconds
                String duration =
                        metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long dur = Long.parseLong(duration);
                // close object
                metaRetriever.release();
                Logger.i(Logger.DEBUG_TAG, "filePath:" + filePath + ",long  duration:" + dur);
                return dur;
            }
        }
        return 1500;
    }

//    public static String getRingDuring(String mUri) {
//        String duration = null;
//        android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
//
//        try {
//            if (mUri != null) {
//                HashMap<String, String> headers = null;
//                if (headers == null) {
//                    headers = new HashMap<>();
//                    headers.put("User-Agent", "Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; MW-KW-001 Build/JRO03C) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 UCBrowser/1.0.0.001 U4/0.8.0 Mobile Safari/533.1");
//                }
//                mmr.setDataSource(mUri, headers);
//            }
//
//            duration = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
//        } catch (Exception ex) {
//        } finally {
//            mmr.release();
//        }
//        Logger.e("ryan", "duration " + duration);
//        return duration;
//    }
}
