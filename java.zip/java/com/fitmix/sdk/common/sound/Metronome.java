package com.fitmix.sdk.common.sound;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;

import com.fitmix.sdk.MixApp;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 哒哒声节拍器
 */
public class Metronome {

    private long mPeriod;
    private int mSoundId;
    private int mStreamId;

    private SoundPool mSoundPool;
    private ScheduledExecutorService executor;

    public Metronome() {

    }

    private ScheduledExecutorService getSheduledService() {
        if (executor == null)
            executor = Executors.newScheduledThreadPool(1);
        return executor;
    }

    private SoundPool getSoundPool() {
        if (mSoundPool == null)
            mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        return mSoundPool;
    }

    public void releaseResource() {
        stopSheduledService();
        if (mSoundPool != null) {
            if (mStreamId >= 0)
                getSoundPool().stop(mStreamId);
            if (mSoundId >= 0)
                getSoundPool().unload(mSoundId);

            getSoundPool().setOnLoadCompleteListener(null);
            getSoundPool().release();
        }
        mSoundPool = null;

    }

    private final OnLoadCompleteListener repeatListener = new OnLoadCompleteListener() {

        @Override
        public void onLoadComplete(final SoundPool sp, final int soundID,
                                   int status) {
            if (status != 0)
                return;
            mSoundId = soundID;
            setPeriod(mPeriod);
        }
    };

    public long getPeriod() {
        return mPeriod;
    }

    public boolean isResourceLoaded() {
        return mSoundId > 0;
    }

    public void playMetronome(Context context, int resId, long period) {
        if ((context == null))
            return;
        mPeriod = period;
        mSoundId = -1;
        mStreamId = -1;
        getSoundPool().setOnLoadCompleteListener(repeatListener);
        getSoundPool().load(context, resId, 1);
    }

    public void playMetronome(int resId, long period) {
        playMetronome(MixApp.getContext(), resId, period);
    }

    public void setPeriod(long period) {
        if ((period < 250) && (period > 0)) {
        } else {
            mPeriod = period;
            stopSheduledService();
            if (mPeriod > 0)
                repeatPlaySingleSound();
        }
    }

    private void stopSheduledService() {
        if (executor != null) {
            if (!getSheduledService().isShutdown())
                getSheduledService().shutdown();
        }
        executor = null;
    }

    private void repeatPlaySingleSound() {
        if (mPeriod <= 0)
            return;
        if ((mPeriod < 250) || (mPeriod > 1000))
            return;

        if (!getSheduledService().isShutdown()) {
            getSheduledService().scheduleAtFixedRate(new Runnable() {
                public void run() {
                    if (mStreamId >= 0)
                        getSoundPool().stop(mStreamId);
                    mStreamId = getSoundPool().play(mSoundId, 1.0f, 1.0f, 1, 0,
                            1);

                }
            }, 0, mPeriod, TimeUnit.MILLISECONDS);
        }
    }

}
