package com.fitmix.sdk.common.sound;

import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.database.SettingsHelper;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * 语音管理器,包装各个模块用到的语音播报和节拍器
 */
public class VoiceManager {
    /**
     * 语音类型,int型,0:男声,1:女声
     */
    protected int mToneType;//暂时都是Config.SIRI_TONE_TYPE_FEMALE ,为1
    protected int mBpm;//节拍
    protected boolean bMetronomeWorking;

    protected long lastDistance;
    protected long lastTime;
    protected long lastSpeed;

    protected SoundPlayer soundPlayer;
    protected MusicMetronome musicMetronome;

    private final int RANDOM_VOICE = 0;
    private final int SCORE_VOICE = -1;


    public VoiceManager() {
        init();
    }

    public SoundPlayer getSoundPlayer() {
        if (soundPlayer == null)
            soundPlayer = new SoundPlayer();
        return soundPlayer;
    }


    protected void clear() {
        mToneType = Config.SIRI_TONE_TYPE_FEMALE;
        mBpm = 0;
//        bUseMetronome = false;
        bMetronomeWorking = false;

        lastDistance = 0;
        lastTime = 0;
        lastSpeed = 0;
    }

    protected void init() {
        clear();
    }

    /**
     * 停止并销毁声音播报和节拍器
     */
    public void releaseResource() {
        if (soundPlayer != null) {
            soundPlayer.releaseResource();
        }
        soundPlayer = null;
        releaseMetronome();
        clear();
    }


    //region ================================== 节拍器 =====================================

    /**
     * 节拍器
     */
    protected MusicMetronome getMusicMetronome() {
        if (musicMetronome == null) {
            musicMetronome = new MusicMetronome();
            musicMetronome.start();
        }
        return musicMetronome;
    }

    /**
     * 停止并销毁节拍器
     */
    public void releaseMetronome() {
        stopMetronome();
        if (musicMetronome != null) {
            musicMetronome.releaseResource();
        }
        musicMetronome = null;
    }

    //endregion ================================== 节拍器 =====================================

    //region ================================== 其它语言包 =====================================

    private final String RANDOM_TYPE = "random";
    private final String SCORE_TYPE = "score";
    private String hrVoicePath = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_DIR, "") + Config.PATH_LOCAL_VOICE_HRVOICE;
    private String commonPath = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_DIR, "") + Config.PATH_LOCAL_VOICE_COMMON;

    /**
     * 获取当前语音播报类型 female、Run/female_en或者Skip/female_en
     *
     * @return type
     */
    private String getCurrentVoiceType() {
        String voiceType = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
        Logger.d(Logger.DEBUG_TAG, "currentVoiceType:" + voiceType);
        if (voiceType.contains("en") || voiceType.contains("En") || voiceType.contains("EN")) {
            return "female_en";
        } else {
            return "female";
        }
    }

    /**
     * 根据语音包类型获取该语言类型的 0-19数字的声音路径（英文情况下）
     *
     * @return
     */
    private String[] getNumberVoiceByVoiceType() {
        return new String[]{
                commonPath + "0.mp3",
                commonPath + "1.mp3",
                commonPath + "2.mp3",
                commonPath + "3.mp3",
                commonPath + "4.mp3",
                commonPath + "5.mp3",
                commonPath + "6.mp3",
                commonPath + "7.mp3",
                commonPath + "8.mp3",
                commonPath + "9.mp3",
                commonPath + "10.mp3",
                commonPath + "11.mp3",
                commonPath + "12.mp3",
                commonPath + "13.mp3",
                commonPath + "14.mp3",
                commonPath + "15.mp3",
                commonPath + "16.mp3",
                commonPath + "17.mp3",
                commonPath + "18.mp3",
                commonPath + "19.mp3",
                commonPath + "20.mp3",
                commonPath + "30.mp3",
                commonPath + "40.mp3",
                commonPath + "50.mp3",
                commonPath + "60.mp3",
                commonPath + "70.mp3",
                commonPath + "80.mp3",
                commonPath + "90.mp3",
        };
    }

    /**
     * 根据语音包类型获取该语言类型的 千百十and声音路径（英文）
     *
     * @return
     */
    private String[] getUnitByVoiceType() {
        return new String[]{
                commonPath + "thousand.mp3",
                commonPath + "hundred.mp3",
                commonPath + "and.mp3"};
    }

    /**
     * 根据语音包类型获取该语言类型的 跑步路程(完整马拉松) 每一公里 对应的语音 的声音路径
     *
     * @param voiceType 语音包 dirname
     * @return
     */
    private String[] getExtraByVoiceType(String voiceType) {
        return new String[]{
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice1.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice2.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice1.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice2.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice2.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice2.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice3.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice2.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice4.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice3.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice5.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice4.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice6.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice5.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice7.mp3",
                RANDOM_TYPE,
                SCORE_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_staticVoice.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_guideVoice6.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice8.mp3",
                RANDOM_TYPE,
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_marathonVoice9.mp3"
        };
    }

    /**
     * 根据语音包类型获取该语言类型的 随机口号 的声音路径
     *
     * @param voiceType
     * @return
     */
    private String[] getRandomByVoiceType(String voiceType) {
        return new String[]{
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice1.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice2.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice3.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice4.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice5.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice6.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice7.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice8.mp3",
                Config.PATH_LOCAL_VOICE + voiceType + File.separator + voiceType + "_sloganVoice9.mp3",};
    }

    /**
     * 根据语音播报语调、运动时长,获取运动时长播报声音资源拼接集合
     *
     * @param voiceType 语音包 dirname
     * @param second    运动时长,单位为秒
     * @return 运动时长播报声音资源拼接集合, 如【你已运动 10 分钟 20 秒】
     */
    private ArrayList<String> getRunDurationPathList(String voiceType, int second) {
        int min = second / 60;
        int sec = second % 60;
        int hour = min / 60;
        min %= 60;

        if ((min < 0) || (hour >= 10000))
            return null;
        int index = voiceType.lastIndexOf("/");
        String type = voiceType.substring(index + 1, voiceType.length());

        ArrayList<String> hourList = null;
        ArrayList<String> minList = null;
        ArrayList<String> secList = null;
        if (hour > 0)
            hourList = numberToVoiceMode1(voiceType, type, hour);
        if ((min != 0) || (hour == 0))
            minList = numberToVoiceMode1(voiceType, type, min);
        if (sec != 0)
            secList = numberToVoiceMode1(voiceType, type, sec);
        if ((hourList == null) && (minList == null) && (secList == null))
            return null;
        ArrayList<String> sounds = new ArrayList<>();
        sounds.add(commonPath + "have_sport.mp3");//你已运动
        if (hourList != null) {
            sounds.addAll(hourList);
            sounds.add(commonPath + "hour.mp3");//小时
        }
        if (minList != null) {
            sounds.addAll(minList);
            sounds.add(commonPath + "minute.mp3");//分钟
        }
        if (secList != null) {
            sounds.addAll(secList);
            sounds.add(commonPath + "second.mp3");//秒
        }

        if (hourList != null)
            hourList.clear();
        if (minList != null)
            minList.clear();
        if (secList != null)
            secList.clear();
        return sounds;
    }

    /**
     * 根据语音播报语调、运动距离,获取运动距离播报声音资源拼接集合
     *
     * @param voiceType 语音包 dirname
     * @param distance  运动距离,单位为公里
     * @return 运动距离播报声音资源拼接集合, 如【你已运动 10 公里】
     */
    private ArrayList<String> getRunDistancePathList(String voiceType, String distance) {
        if ((distance == null) || distance.isEmpty())
            return null;
        int index = voiceType.lastIndexOf("/");
        String type = voiceType.substring(index + 1, voiceType.length());

        distance = distance.replace(',', '.');
        int iIndex = distance.indexOf(".");
        int iNumber;
        ArrayList<String> part1;
        if (iIndex != -1) {
            iNumber = Integer.parseInt(distance.substring(0, iIndex));
        } else {
            iNumber = Integer.parseInt(distance);
        }
        part1 = numberToVoiceMode1(voiceType, type, iNumber);

        ArrayList<String> part2 = numberToVoiceMode2(distance.substring(iIndex + 1));

        ArrayList<String> sounds = new ArrayList<>();

        sounds.add(commonPath + "have_sport.mp3");//你已运动
        if (part1 != null)
            sounds.addAll(part1);
        if (iIndex != -1) {
            sounds.add(commonPath + "dot.mp3");//点
            if (part2 != null)
                sounds.addAll(part2);
        }
        sounds.add(commonPath + "km.mp3");//公里
        if (part1 != null)
            part1.clear();
        if (part2 != null)
            part2.clear();
        return sounds;
    }

    /**
     * 根据语音播报语调、运动距离、运动时长,获取运动成绩声音资源拼接集合
     *
     * @param voiceType 语音包 dirname
     * @param distance  运动距离,单位为公里
     * @param second    运动时长,单位为秒
     * @return 运动成绩声音资源拼接集合, 如【你已运动 10 公里,用时 1 小时 10 分 20 秒】
     */
    private ArrayList<String> getRunScorePathList(String voiceType, String distance,
                                                  int second) {
        ArrayList<String> distanceList = getRunDistancePathList(voiceType, distance);
        ArrayList<String> durationList = getRunDurationPathList(voiceType, second);
        if ((distanceList == null) || (durationList == null)) {
            if (distanceList != null)
                distanceList.clear();
            if (durationList != null)
                durationList.clear();
            return null;
        }
        ArrayList<String> sounds = new ArrayList<>();
        sounds.addAll(distanceList);
        //  durationList.set(0, commonPath + "_use_time.mp3");//用时  TODO 暂时没有
        sounds.addAll(durationList);

        if (distanceList != null)
            distanceList.clear();
        if (durationList != null)
            durationList.clear();
        return sounds;

    }

    /**
     * 根据语音播报语调、运动距离、运动时长、消耗卡路里、鼓励类型,获取运动成绩声音资源拼接集合
     *
     * @param voiceType 语音包 dirname
     * @param distance  运动距离,单位为公里
     * @param second    运动时长,单位为秒
     * @param calorie   消耗卡路里,单位为卡路里
     * @param type      鼓励类型
     * @return 运动成绩声音资源拼接集合
     */
    private ArrayList<String> getRunScorePathList(String voiceType, String distance,
                                                  int second, int calorie, int type) {

        ArrayList<String> sounds = getRunScorePathList(voiceType, distance, second);
        if (sounds == null)
            return null;

        int index = voiceType.lastIndexOf("/");
        String voicePackageType = voiceType.substring(index + 1, voiceType.length());


        String consumePath = commonPath + "consume.mp3";
        sounds.add(consumePath);
        ArrayList<String> list = numberToVoiceMode1(voiceType, voicePackageType, calorie);
        if (list != null)
            sounds.addAll(list);
        String calPath = commonPath + "Kcal.mp3";
        sounds.add(calPath);
        String resultPath = null;

        if (type >= 0 && !TextUtils.isEmpty(resultPath))
            sounds.add(resultPath);

        if (list != null)
            list.clear();
        return sounds;
    }

    //endregion ================================== 其它语言包 =========================================

    //region ================================== 默认语音包(中文女声) =======================================

//    /** 男声数字0至9*/
//    private final int numberVoice_male[] = { R.raw.male_0, R.raw.male_1,
//            R.raw.male_2, R.raw.male_3, R.raw.male_4, R.raw.male_5,
//            R.raw.male_6, R.raw.male_7, R.raw.male_8, R.raw.male_9 };
    /**
     * 女声数字0至9
     */
    private final int numberVoice_female[] = {R.raw.female_0, R.raw.female_1,
            R.raw.female_2, R.raw.female_3, R.raw.female_4, R.raw.female_5,
            R.raw.female_6, R.raw.female_7, R.raw.female_8, R.raw.female_9};
//    /** 男声数字单位千百十*/
//    private final int unit_male[] = { R.raw.male_thousand, R.raw.male_hundred,
//            R.raw.male_10 };
    /**
     * 女声数字单位千百十
     */
    private final int unit_female[] = {R.raw.female_thousand,
            R.raw.female_hundred, R.raw.female_10};

    /**
     * 全马过程中,每一公里对应的激励语音
     */
    private final int extra_female[] = {
            R.raw.female_run_guide_voice1,//注意聆听身体的声音,速度会主动来找你 1km
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_guide_voice2,//专注呼吸、节奏,调整好步伐
            R.raw.female_run_marathon_voice1,//很好,你完全具备了准跑者的潜质
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice2,//专注呼吸、节奏,调整好步伐
            R.raw.female_run_marathon_voice2,//非常棒,你已经是一名合格的跑者了 10km
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice2,//专注呼吸、节奏,调整好步伐
            R.raw.female_run_marathon_voice3,//非常棒,还有5公里你就能挑战半马了 15km
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice2,//专注呼吸、节奏,调整好步伐
            R.raw.female_run_marathon_voice4,//非常棒,你完全具备完成半马的水平 20km
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice3,//目标就在前方,加速也别太快
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice4,//控制身体惯速,专注内心目标
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_guide_voice5,//要来点挑战吗?相信你的能量
            RANDOM_VOICE,
            SCORE_VOICE,
            R.raw.female_run_marathon_voice5,//非常棒,还有5公里你就能挑战全马了 35km
            R.raw.female_run_static_voice,//注意跑姿、摆臂,保持身体的运动速度
            R.raw.female_run_marathon_voice7,//非常棒,还有5公里你就能完成全马了 37km
            R.raw.female_run_guide_voice6,//控制好节奏,超越自己,你可以
            R.raw.female_run_slogan_voice6,//喝口水继续加油
            R.raw.female_run_marathon_voice6,//非常棒,你完全具备挑战全马资格 40km
            RANDOM_VOICE,
            R.raw.female_run_marathon_voice9};//非常棒,你已经成功进级全马阵营 42km

    /**
     * 随机激励语音
     */
    private final int random_female[] = {R.raw.female_run_slogan_voice1,//抛开杂念,享受每一步
            R.raw.female_run_slogan_voice6,//喝口水继续加油
            R.raw.female_run_slogan_voice2,//体能开始消耗,喝口水加油
            R.raw.female_run_slogan_voice3,//有目标才会有动力
            R.raw.female_run_slogan_voice4,//保持体力补充能量
            R.raw.female_run_slogan_voice5,//放空自己,专注你的目标
            R.raw.female_run_slogan_voice7,//越上新的台阶,世界变得不一样了
            R.raw.female_run_guide_voice5,//要来点挑战吗?相信你的能量
            R.raw.female_run_slogan_voice9};//熬过最难的部分,成功就在你眼前

    /**
     * 设置语音播报音调
     *
     * @param toneType 语音播报音调,0:男声,1:女声
     */
    public void setToneType(int toneType) {
        mToneType = toneType;
    }

    /**
     * 跑步:语音播报,运动目标已完成
     */
    public void playTaskComplete() {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "male":
            case "female":
            default:
                getSoundPlayer().playSingleSound(R.raw.task_complete);
                break;
        }
    }

    /**
     * 跳绳:语音播报,运动目标已完成
     */
    public void playTaskSkipComplete() {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "male":
            case "female":
                getSoundPlayer().playSingleSound(R.raw.task_complete);
                break;
            default:
                //因为暂时无特定的语音 英文情况下不播
                break;
        }
    }

    /**
     * 播报运动成绩
     *
     * @param distance 运动距离,单位为米
     * @param time     运动时长,单位为毫秒
     */
    public void playRunDataOfMarathon(long distance, long time) {
        long timeLastKm;
        int type;
        final int MAX_SPEED = 99 * 60 + 59;
        if (distance > lastDistance)
            timeLastKm = (time - lastTime) * 1000 / (distance - lastDistance);
        else
            timeLastKm = MAX_SPEED;

        if (lastSpeed == 0) {
            type = 0;
        } else {
            if (timeLastKm > 105 * lastSpeed / 100)
                type = -1;
            else if (timeLastKm < 95 * lastSpeed / 100)
                type = 1;
            else
                type = 0;
        }
        playRunDataOfMarathon(mToneType,
                (int) (distance / 1000), (int) (time / 1000),
                (int) (timeLastKm / 1000), type);
        lastDistance = distance;
        lastTime = time;
        lastSpeed = timeLastKm;
    }

    /**
     * 根据语音播报语调、运动时长,获取运动时长播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param second   运动时长,单位为秒
     * @return 运动时长播报声音资源拼接集合, 如【你已运动 10 分钟 20 秒】
     */
    private ArrayList<Integer> getRunDurationList(int toneType, int second) {
        int min = second / 60;
        int sec = second % 60;
        int hour = min / 60;
        min %= 60;

        if ((min < 0) || (hour >= 10000))
            return null;
        ArrayList<Integer> hourList = null;
        ArrayList<Integer> minList = null;
        ArrayList<Integer> secList = null;
        if (hour > 0)
            hourList = numberToVoiceMode1(toneType, hour);
        if ((min != 0) || (hour == 0))
            minList = numberToVoiceMode1(toneType, min);
        if (sec != 0)
            secList = numberToVoiceMode1(toneType, sec);
        if ((hourList == null) && (minList == null) && (secList == null))
            return null;

        ArrayList<Integer> sounds = new ArrayList<>();

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                sounds.add(R.raw.male_have_sport);
//                if (hourList != null) {
//                    sounds.addAll(hourList);
//                    sounds.add(R.raw.male_hour);
//                }
//                if (minList != null) {
//                    sounds.addAll(minList);
//                    sounds.add(secList == null ? R.raw.male_long_minute
//                            : R.raw.male_minute);
//                }
//                if (secList != null) {
//                    sounds.addAll(secList);
//                    sounds.add(R.raw.male_second);
//                }
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                sounds.add(R.raw.female_run_have_sport);//你已运动
                if (hourList != null) {
                    sounds.addAll(hourList);
                    sounds.add(R.raw.female_hour);//小时
                }
                if (minList != null) {
                    sounds.addAll(minList);
                    sounds.add(secList == null ? R.raw.female_long_minute
                            : R.raw.female_minute);//分钟 分
                }
                if (secList != null) {
                    sounds.addAll(secList);
                    sounds.add(R.raw.female_second);//秒
                }
                break;

        }
        if (hourList != null)
            hourList.clear();
        if (minList != null)
            minList.clear();
        if (secList != null)
            secList.clear();
        return sounds;
    }

    /**
     * 根据语音播报语调、运动距离,获取运动距离播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为公里
     * @return 运动距离播报声音资源拼接集合, 如【你已运动 10 公里】
     */
    private ArrayList<Integer> getRunDistanceList(int toneType, String distance) {
        if ((distance == null) || distance.isEmpty())
            return null;
        distance = distance.replace(',', '.');
        int iIndex = distance.indexOf(".");
        int iNumber;
        ArrayList<Integer> part1;
        if (iIndex != -1) {
            iNumber = Integer.parseInt(distance.substring(0, iIndex));
        } else {
            iNumber = Integer.parseInt(distance);
        }
        part1 = numberToVoiceMode1(toneType, iNumber);

        ArrayList<Integer> part2 = numberToVoiceMode2(toneType,
                distance.substring(iIndex + 1));

        ArrayList<Integer> sounds = new ArrayList<>();

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                sounds.add(R.raw.male_have_sport);
//                if (part1 != null)
//                    sounds.addAll(part1);
//                if (iIndex != -1) {
//                    sounds.add(R.raw.male_dot);
//                    if (part2 != null)
//                        sounds.addAll(part2);
//                }
//                sounds.add(R.raw.male_km);
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                sounds.add(R.raw.female_run_have_sport);//你已运动
                if (part1 != null)
                    sounds.addAll(part1);
                if (iIndex != -1) {
                    sounds.add(R.raw.female_dot);//点
                    if (part2 != null)
                        sounds.addAll(part2);
                }
                sounds.add(R.raw.female_km);//公里
                break;


        }
        if (part1 != null)
            part1.clear();
        if (part2 != null)
            part2.clear();
        return sounds;
    }

    /**
     * 根据语音播报语调、运动距离、运动时长,获取运动成绩声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为公里
     * @param second   运动时长,单位为秒
     * @return 运动成绩声音资源拼接集合, 如【你已运动 10 公里,用时 1 小时 10 分 20 秒】
     */
    private ArrayList<Integer> getRunScoreList(int toneType, String distance,
                                               int second) {

        ArrayList<Integer> distanceList = getRunDistanceList(toneType, distance);
        ArrayList<Integer> durationList = getRunDurationList(toneType, second);
        if ((distanceList == null) || (durationList == null)) {
            if (distanceList != null)
                distanceList.clear();
            if (durationList != null)
                durationList.clear();
            return null;
        }
        ArrayList<Integer> sounds = new ArrayList<>();
        sounds.addAll(distanceList);
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                durationList.set(0, R.raw.female_use_time);//用时
                break;
        }
        sounds.addAll(durationList);

        if (distanceList != null)
            distanceList.clear();
        if (durationList != null)
            durationList.clear();
        return sounds;
    }

    /**
     * 根据语音播报语调、运动距离、运动时长、消耗卡路里、鼓励类型,获取运动成绩声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为公里
     * @param second   运动时长,单位为秒
     * @param calorie  消耗卡路里,单位为卡路里
     * @param type     鼓励类型
     * @return 运动成绩声音资源拼接集合
     */
    private ArrayList<Integer> getRunScoreList(int toneType, String distance,
                                               int second, int calorie, int type) {

        ArrayList<Integer> sounds = getRunScoreList(toneType, distance, second);
        if (sounds == null)
            return null;
        int id;
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                id = R.raw.male_consume;
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                id = R.raw.female_consume; //消耗
                break;
        }
        sounds.add(id);
        ArrayList<Integer> list = numberToVoiceMode1(toneType, calorie);
        if (list != null)
            sounds.addAll(list);
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                id = R.raw.male_kcal;
//                sounds.add(id);
//                if (type > 0)
//                    id = R.raw.male_score_a;
//                else if (type == 0)
//                    id = R.raw.male_score_b;
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                id = R.raw.female_kcal;//大卡
                sounds.add(id);
                if (type > 0)
                    id = R.raw.female_run_improve;//恭喜你,你今天的成绩超越了上一次,别忘了做好拉伸
                else if (type == 0)
                    id = R.raw.female_run_decline;//今天跑得不错,保持下去
                break;
        }
        if (type >= 0)
            sounds.add(id);

        if (list != null)
            list.clear();
        return sounds;
    }

    private ArrayList<Integer> getMarathonList(int toneType, int distance,
                                               int second, int secondLastKM, int type) {
        if (distance <= 0)
            return null;
        ArrayList<Integer> distanceList = getRunDistanceList(toneType, ""
                + distance);
        ArrayList<Integer> durationList = getRunDurationList(toneType, second);
        ArrayList<Integer> lastKMList = getRunDurationList(toneType,
                secondLastKM);
        int extra[];
        int random_array[];
        int idScore;
        if ((distanceList == null) || (durationList == null)
                || (lastKMList == null)) {
            if (distanceList != null)
                distanceList.clear();
            if (durationList != null)
                durationList.clear();
            if (lastKMList != null)
                lastKMList.clear();
            return null;
        }
        ArrayList<Integer> sounds = new ArrayList<>();
        sounds.addAll(distanceList);
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                durationList.set(0, R.raw.female_use_time);//用时
                lastKMList.set(0, R.raw.female_run_last_km_use_time);//最近一公里耗时
                extra = extra_female;
                random_array = random_female;
                if (type > 0) {
                    idScore = R.raw.female_incream_speed;//热情不能带你到终点,控制速度
                } else if (type == 0) {
                    idScore = R.raw.female_run_ascendvoice;//你已经找到自己的节奏,保持下去
                } else {
                    idScore = R.raw.female_descendvoice;//速度有所下降哦,调整步频你可以做得更好
                }
                break;
        }

        sounds.addAll(durationList);
        sounds.addAll(lastKMList);
        int id = 0;
        if (extra != null && (distance - 1) < extra.length) {
            id = extra[distance - 1];
            if (id == RANDOM_VOICE) {
                Random ran = new Random(System.currentTimeMillis());
                int value = ran.nextInt() % random_array.length;
                if (value < 0)
                    value = -value;
                id = random_array[value];
            } else if (id == SCORE_VOICE) {
                id = idScore;
            }
        }
        if (id > 0)
            sounds.add(id);
        if (distanceList != null)
            distanceList.clear();
        if (durationList != null)
            durationList.clear();
        if (lastKMList != null)
            lastKMList.clear();
        return sounds;

    }

    /**
     * 播报运动时长,如【你已运动 10 分钟 20 秒】
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param second   运动时长,单位为秒
     */
    public void playRunDuration(int toneType, int second) {
        switch (getCurrentVoiceType()) {
            case "female_en":
                ArrayList<String> sounds0 = getRunDurationPathList("female_en", second);
                if (sounds0 == null || (sounds0.size() == 0))
                    return;

                getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
                sounds0.clear();
                break;
            case "male":
            case "female":
            default:
                ArrayList<Integer> sounds = getRunDurationList(toneType, second);
                if (sounds == null || (sounds.size() == 0))
                    return;

                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 播报运动成绩,如【你已运动 10 公里,用时 1 小时 10 分 20 秒】
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为米
     * @param second   运动时长,单位为秒
     */
    public void playRunScore(int toneType, long distance, int second) {
        String sDistance = FormatUtil.formatDistance(distance);
        switch (getCurrentVoiceType()) {
            case "female_en":
                ArrayList<String> sounds0 = getRunScorePathList("female_en", sDistance, second);
                if (sounds0 == null || (sounds0.size() == 0))
                    return;

                getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
                sounds0.clear();
                break;
            case "male":
            case "female":
            default:
                ArrayList<Integer> sounds = getRunScoreList(toneType, sDistance, second);
                if (sounds == null || (sounds.size() == 0))
                    return;

                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 播报运动成绩,如【运动结束,您已运动10公里,用时1小时10分钟,消耗670大卡,恭喜你...】
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为米
     * @param sportT   区间运动时长,单位为秒
     * @param runTime  运动时长,单位为秒
     * @param calorie  运动消耗卡路里,单位卡路里
     * @param type     鼓励类型
     */
    public void playRunScore(final int toneType, final long distance, final int sportT, final int runTime,
                             final int calorie, final int type) {
        switch (getCurrentVoiceType()) {
            case "female_en":
                ThreadManager.executeOnSubThread2(new Runnable() {
                    @Override
                    public void run() {
                        String sDistance = FormatUtil.formatDistance(distance);
                        ArrayList<String> sounds0 = getRunScorePathList("female_en", sDistance, runTime, calorie, type);
                        if (sounds0 == null || (sounds0.size() == 0))
                            return;

                        sounds0.add(0, commonPath + "sport_finish.mp3");
                        switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
                            case 7:
                                break;
                            case 6://累计心率区间训练**分钟！
                                sounds0.add(hrVoicePath + "hr_adduptraining.mp3");
                                sounds0.addAll(numberToVoice("female_en", sportT / 60));
                                sounds0.add(hrVoicePath + "minute.mp3");
                                break;
                            case 5://累计极限强度训练***分钟！
                                sounds0.add(hrVoicePath + "hr_maxhrrange_1.mp3");
                                sounds0.addAll(numberToVoice("female_en", sportT / 60));
                                sounds0.add(hrVoicePath + "minute.mp3");
                                break;
                            case 4://累计强化机能训练***分钟！
                                sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                                sounds0.addAll(numberToVoice("female_en", sportT / 60));
                                sounds0.add(hrVoicePath + "minute.mp3");
                                break;
                            case 3://累计强化心肺训练***分钟！
                                sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                                sounds0.addAll(numberToVoice("female_en", sportT / 60));
                                sounds0.add(hrVoicePath + "minute.mp3");
                                break;
                            case 2://累计燃脂训练***分钟
                                sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                                sounds0.addAll(numberToVoice("female_en", sportT / 60));
                                sounds0.add(hrVoicePath + "minute.mp3");
                                break;
                        }
                        getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
                        sounds0.clear();
                    }
                });
                break;
            case "male":
            case "female":
            default:
                ThreadManager.executeOnSubThread2(new Runnable() {
                    @Override
                    public void run() {
                        String sDistance = FormatUtil.formatDistance(distance);
                        ArrayList<Integer> sounds = getRunScoreList(toneType, sDistance,
                                runTime, calorie, type);
                        if (sounds == null || (sounds.size() == 0))
                            return;

                        sounds.add(0, R.raw.female_sport_finish);//运动结束
                        switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
                            case 7:
                                break;
                            case 6://累计心率区间训练**分钟！
                                sounds.add(R.raw.female_hr_adduptraining);
                                sounds.addAll(numberToVoiceMode1(1, sportT / 60));
                                sounds.add(R.raw.female_minute);
                                break;
                            case 5://累计极限强度训练***分钟！
                                sounds.add(R.raw.female_hr_maxhrrange_1);
                                sounds.addAll(numberToVoiceMode1(1, sportT / 60));
                                sounds.add(R.raw.female_minute);
                                break;
                            case 4://累计强化机能训练***分钟！
                                sounds.add(R.raw.female_hr_enhancemode_3);
                                sounds.addAll(numberToVoiceMode1(1, sportT / 60));
                                sounds.add(R.raw.female_minute);
                                break;
                            case 3://累计强化心肺训练***分钟！
                                sounds.add(R.raw.female_hr_enhancecardiomode_3);
                                sounds.addAll(numberToVoiceMode1(1, sportT / 60));
                                sounds.add(R.raw.female_minute);
                                break;
                            case 2://累计燃脂训练***分钟
                                sounds.add(R.raw.female_hr_fatburningmode_3);
                                sounds.addAll(numberToVoiceMode1(1, sportT / 60));
                                sounds.add(R.raw.female_minute);
                                break;
                        }
                        getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                        sounds.clear();
                    }
                });
                break;
        }
    }

    /**
     * 播报运动成绩
     *
     * @param distance 运动距离,单位为公里
     * @param second   运动时长,单位为秒
     */
    public void playRunDataOfMarathon(int toneType, int distance, int second,
                                      int secondLastKM, int type) {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "male":
            case "female":
            default:
                ArrayList<Integer> sounds = getMarathonList(toneType, distance, second,
                        secondLastKM, type);
                if (sounds == null || (sounds.size() == 0))
                    return;

                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 播报运动距离
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param distance 运动距离,单位为米
     */
    public void playRunDistance(int toneType, long distance) {
        String sDistance = FormatUtil.formatDistance(distance);
        switch (getCurrentVoiceType()) {
            case "female_en":
                ArrayList<String> sounds0 = getRunDistancePathList("female_en", sDistance);
                if (sounds0 == null || (sounds0.size() == 0))
                    return;
                getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
                sounds0.clear();
                break;
            case "male":
            case "female":
            default:
                ArrayList<Integer> sounds = getRunDistanceList(toneType, sDistance);
                if (sounds == null || (sounds.size() == 0))
                    return;
                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }

    }


    //endregion ================================== 默认语音包(中文女声) =======================================

    //region ======================================= RunMainActivity用到 =======================================

//    private final int countdown_male[] = { R.raw.male_ready_go };
//    private final int countdown_female[] = {R.raw.female_countdown};

    /**
     * 跑步播报【321 GO】
     */
    public void playCounterDown() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "countdown.mp3");
                break;
            case "female":
            case "male":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_countdown);
                break;
        }
    }

    /**
     * 跳绳播报【321 GO】
     */
    public void playCounterDownSkip() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "countdown.mp3");
                break;
            case "female":
            case "male":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_countdown);
                break;
        }
    }

    /**
     * 播报【运动结束】
     */
    public void playStopRun() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "sport_finish.mp3");
                break;
            case "male":
            case "female":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_sport_finish);
                break;
        }
    }

    /**
     * 跑步:播报【运动暂停】
     */
    public void playPauseRun() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "sport_pause.mp3");
                break;
            case "male":
            case "female":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_sport_pause);
                break;
        }
    }

    /**
     * 跳绳:播报【运动暂停】
     */
    public void playPauseSkip() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "sport_pause.mp3");
                break;
            case "male":
            case "female":
                getSoundPlayer().playSingleSound(R.raw.female_sport_pause);
                break;
            default:
                break;
        }
    }

    /**
     * 跑步:播报【运动继续】
     */
    public void playContinueRun() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "sport_continue.mp3");
                break;
            case "male":
            case "female":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_sport_continue);
                break;
        }
    }

    /**
     * 跳绳:播报【运动继续】
     */
    public void playContinueSkip() {
        switch (getCurrentVoiceType()) {
            case "female_en":
                getSoundPlayer().playSingleSound(commonPath + "sport_continue.mp3");
                break;
            case "male":
            case "female":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_sport_continue);
                break;
        }
    }

    /**
     * 播放节拍器
     */
    public void startMetronome() {
//        if (bUseMetronome)
//            return;
//        bUseMetronome = true;
        runMetronome(mBpm);
    }

    /**
     * 停止节拍器
     */
    public void stopMetronome() {
        runMetronome(0);
    }

    public boolean isMetronomeWorking() {
        return bMetronomeWorking;
    }


    /**
     * 播放节拍器
     *
     * @param bpm 对应步频,0:关闭,取值范围[80,240]
     */
    public void runMetronome(int bpm) {
        if (bpm <= 0) {
            getMusicMetronome().setBpm(0);
            bMetronomeWorking = false;
            return;
        }
        mBpm = bpm;
        bMetronomeWorking = true;
        getMusicMetronome().setBpm(bpm);
    }

    /**
     * 配速跑,速度太快提醒。播报【加速也别太快】
     *
     * @param time 当前一公里秒数
     */
    public void playSpeedTooFast(int time) {
        ArrayList<Integer> sounds = new ArrayList<>();
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default:
                sounds.add(R.raw.female_run_speed_target);//当前配速
                sounds.addAll(getRunPaceList(1, time));
                sounds.add(R.raw.female_run_speed_fast);//速度太快
                break;
        }
        getSoundPlayer().playMultiSoundsIfIdle(sounds, getTimeSpaceByRes(sounds));
        sounds.clear();
    }

    /**
     * 配速跑,速度太慢提醒。播报【速度有所下降】
     *
     * @param time 当前一公里秒数
     */
    public void playSpeedTooSlow(int time) {
        ArrayList<Integer> sounds = new ArrayList<>();

        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default://因为暂时无特定的语音
                sounds.add(R.raw.female_run_speed_target);//当前配速
                sounds.addAll(getRunPaceList(1, time));
                sounds.add(R.raw.female_run_speed_slow);//速度太慢
                break;
        }
        getSoundPlayer().playMultiSoundsIfIdle(sounds, getTimeSpaceByRes(sounds));
        sounds.clear();
    }

    /**
     * 配速跑,速度刚好提醒。播报【你已找到自己的节奏】
     */
    public void playSpeedFit() {
        ArrayList<Integer> sounds = new ArrayList<>();

        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default://因为暂时无特定的语音
                sounds.add(R.raw.female_run_ascendvoice);//你已找到自己的节奏
                break;
        }
        getSoundPlayer().playMultiSoundsIfIdle(sounds, getTimeSpaceByRes(sounds));
        sounds.clear();
    }

    /**
     * 根据语音播报语调、一公里秒数,获取一公里耗时播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param second   一公里秒数,单位为秒
     * @return 一公里耗时播报声音资源拼接集合, 如【5 分 20 秒】
     */
    private ArrayList<Integer> getRunPaceList(int toneType, int second) {
        int min = second / 60;
        int sec = second % 60;
        int hour = min / 60;
        min %= 60;

        if ((min < 0) || (hour >= 10000))
            return null;
        ArrayList<Integer> hourList = null;
        ArrayList<Integer> minList = null;
        ArrayList<Integer> secList = null;
        if (hour > 0)
            hourList = numberToVoiceMode1(toneType, hour);
        if ((min != 0) || (hour == 0))
            minList = numberToVoiceMode1(toneType, min);
        if (sec != 0)
            secList = numberToVoiceMode1(toneType, sec);
        if ((hourList == null) && (minList == null) && (secList == null))
            return null;

        ArrayList<Integer> sounds = new ArrayList<>();

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                if (hourList != null) {
                    sounds.addAll(hourList);
                    sounds.add(R.raw.female_hour);//小时
                }
                if (minList != null) {
                    sounds.addAll(minList);
                    sounds.add(secList == null ? R.raw.female_long_minute
                            : R.raw.female_minute);//分钟 分
                }
                if (secList != null) {
                    sounds.addAll(secList);
                    sounds.add(R.raw.female_second);//秒
                }
                break;

        }
        if (hourList != null)
            hourList.clear();
        if (minList != null)
            minList.clear();
        if (secList != null)
            secList.clear();
        return sounds;
    }

    //endregion ======================================= RunMainActivity用到 =======================================

    //region ================================== 心率相关语音 =========================================

    /**
     * 播报各种训练模式欢迎语
     */
    public void playCounterDownAndHeartRateMessage() {

        switch (getCurrentVoiceType()) {
            case "female_en":
                ArrayList<String> sounds0 = new ArrayList<>();
                sounds0.add(commonPath + "countdown.mp3");//321 GO
                switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
                    case 7:
                        sounds0.add(hrVoicePath + "hr_freestylemode.mp3");//当前为自由训练模式，Let's go!
                        break;
                    case 6:
                        sounds0.add(hrVoicePath + "hr_custommode.mp3");//当前为自定义训练模式，Let's go!
                        break;
                    case 5:
                        sounds0.add(hrVoicePath + "hr_ultimatestrengthmode.mp3");//当前为极限训练模式，Let's go!
                        break;
                    case 4:
                        sounds0.add(hrVoicePath + "hr_enhancemode.mp3");//当前为强化机能训练模式，Let's go!
                        break;
                    case 3:
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode.mp3");//当前为强化心肺训练模式，Let's go!
                        break;
                    case 2:
                        sounds0.add(hrVoicePath + "hr_fatburningmode.mp3");//当前为燃脂训练模式，Let's go!
                        break;
                }
                //   sounds.add(R.raw.female_hr_run_start);//聆听心率声音 把握燃脂节奏,Let's go!
                getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
                sounds0.clear();
                break;
            case "female":
            case "male":
            default:
//                getSoundPlayer().playSingleSound(Config.PATH_LOCAL_VOICE + getCurrentVoiceType() + File.separator + getCurrentVoicePackageType() + "_countdown.mp3");
                ArrayList<Integer> sounds = new ArrayList<>();
                sounds.add(R.raw.female_countdown);//321 GO
                switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
                    case 7:
                        sounds.add(R.raw.female_hr_freestylemode);//当前为自由训练模式，Let's go!
                        break;
                    case 6:
                        sounds.add(R.raw.female_hr_custommode);//当前为自定义训练模式，Let's go!
                        break;
                    case 5:
                        sounds.add(R.raw.female_hr_ultimatestrengthmode);//当前为极限训练模式，Let's go!
                        break;
                    case 4:
                        sounds.add(R.raw.female_hr_enhancemode);//当前为强化机能训练模式，Let's go!
                        break;
                    case 3:
                        sounds.add(R.raw.female_hr_enhancecardiomode);//当前为强化心肺训练模式，Let's go!
                        break;
                    case 2:
                        sounds.add(R.raw.female_hr_fatburningmode);//当前为燃脂训练模式，Let's go!
                        break;
                }
                //   sounds.add(R.raw.female_hr_run_start);//聆听心率声音 把握燃脂节奏,Let's go!
                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 根据当前心率区间及运动时长播放鼓励话语
     *
     * @param isNotFirstInHotMode                 = false;//不是第一次进入热身区间  默认 false
     * @param isNotFirstInFatMode                 = false;//不是第一次进入燃脂区间  默认 false
     * @param isNotFirstInHeartLungMode           = false;//不是第一次进入强化心肺区间  默认 false
     * @param isNotFirstInBodyMode                = false;//不是第一次进入强化机能区间  默认 false
     * @param isNotFirstInSuperMode               = false;//不是第一次进入极限强度区间  默认 false
     * @param lowZoneTime;//心率值低于区间下限时间，每次进来，从0计
     * @param inZoneTime;//心率值位于区间范围时间，每次进来，从0计
     * @param upZoneTime;//心率值高于于区间上限时间，每次进来，从0计
     * @param superZoneTime;//心率值高于极限值时间，每次进来，从0计
     * @param inCoachModeAllTime;//在教练模式区间内的持续总时间
     */
    public void playHeartRateLevelMessage(int currentHRValue, int latestRestHeartRate, int inCoachModeAllTime, int lowZoneTime,
                                          int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                                          boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {

        int custom_min = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MIM_VALUE, 130);
        int custom_max = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MAX_VALUE, 170);

        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
        age = age > 0 ? age : Config.USER_DEFAULT_AGE;//新用户可能存在获取到的SettingsHelper.getInt(Config.SETTING_USER_AGE, 24)为0的情况
        int max = SettingsHelper.getInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age));
        double hr_01 = (int) (latestRestHeartRate + 0.5 * (max - latestRestHeartRate));//放松与热身之间的边界值
        int hr_21 = (int) (latestRestHeartRate + 0.6 * (max - latestRestHeartRate));
        int hr_32 = (int) (latestRestHeartRate + 0.7 * (max - latestRestHeartRate));
        int hr_43 = (int) (latestRestHeartRate + 0.8 * (max - latestRestHeartRate));
        int hr_54 = (int) (latestRestHeartRate + 0.9 * (max - latestRestHeartRate));

        /*int max = 130;
        double hr_01 = 20;//放松与热身之间的边界值
        int hr_21 = 40;
        int hr_32 = 60;
        int hr_43 = 80;
        int hr_54 = 100;*/


        int userCoachMode = SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7);


        switch (getCurrentVoiceType()) {
            case "female_en":
                playFemaleEnglishHrVoice(currentHRValue, inCoachModeAllTime, lowZoneTime, inZoneTime, upZoneTime, superZoneTime, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode, custom_min, custom_max, max, hr_01, hr_21, hr_32, hr_43, hr_54, userCoachMode);
                break;
            case "female":
            case "male":
            default:
                playFemaleHrVoice(currentHRValue, lowZoneTime, inZoneTime, upZoneTime, superZoneTime, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode, custom_min, custom_max, max, hr_01, hr_21, hr_32, hr_43, hr_54, userCoachMode);
        }
    }

    /**
     * 播报女声心率语音
     */
    private void playFemaleHrVoice(int currentHRValue, int lowZoneTime, int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode, int customMin, int customMax, int max, double hr_01, int hr_21, int hr_32, int hr_43, int hr_54, int userCoachMode) {
        ArrayList<Integer> sounds = new ArrayList<>();
        switch (userCoachMode) {
            case 7://心率教练模式-自由模式
                if (currentHRValue > hr_01 && currentHRValue <= hr_21) {//心率达到运动热身区间
                    if (inZoneTime == 5) {
                        sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                        sounds.add(R.raw.female_hr_warmup);//已进入热身区间！
                    }
                } else if (currentHRValue >= hr_21 && currentHRValue <= hr_32) {//心率达到燃烧脂肪区间
                    if (inZoneTime == 5) {
                        if (!isNotFirstInFatMode) {
                            sounds.add(R.raw.female_hr_fatburningmode_1);//已进入燃脂区间，
                            sounds.add(R.raw.female_hr_fatburningmode_2);//燃脂训练应持续30到60分钟！
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                            sounds.add(R.raw.female_hr_fatburningmode_1);//已进入燃脂区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计燃脂训练1--4分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计燃脂训练5分钟！此阶段以燃烧糖类为主！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计燃脂训练6--9分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {//累计燃脂训练10分钟！脂肪燃烧刚刚开始！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计燃脂训练**分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计燃脂训练15分钟！肌肉利用氧气的能力在提升！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_8);
                    } else if (inZoneTime == 60 * 20) {//累计燃脂训练20分钟！燃脂训练基本达标！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_6);
                    } else if (inZoneTime == 60 * 25) {//累计燃脂训练25分钟！注意补充水分以及电解质，如盐汽水。
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 25));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_7);
                    } else if (inZoneTime == 60 * 30) {//累计燃脂训练30分钟！本次训练完美！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 30));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_9);
                    } else if ((inZoneTime == 60 * 60)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_10);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计燃脂训练**分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_10);
                    }
                } else if (currentHRValue >= hr_32 && currentHRValue <= hr_43) {//心率达到强化心肺区间
                    if (inZoneTime == 5) {
                        if (!isNotFirstInHeartLungMode) {
                            sounds.add(R.raw.female_hr_enhancecardiomode_1);//已进入强化心肺区间，
                            sounds.add(R.raw.female_hr_enhancecardiomode_2);//强化心肺训练应持续30到90分钟！
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                            sounds.add(R.raw.female_hr_enhancecardiomode_1);//已进入强化心肺区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化心肺训练1--4分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计强化心肺训练5分钟！心肺更强壮，才能跑得更远！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化心肺训练6--9分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {///累计强化心肺训练10分钟！锻炼耐力，是更强壮的基础！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计强化心肺训练6--9分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计强化心肺训练15分钟！注意补充水分以及电解质，如盐汽水。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_7);
                    } else if (inZoneTime == 60 * 20) {//累计强化心肺训练20分钟！可适当补充能量，如碳水化合物。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_8);
                    } else if (inZoneTime == 60 * 25) {//累计强化心肺训练25分钟！强化心肺锻炼基本达标！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 25));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_6);
                    } else if (inZoneTime == 60 * 30) {//累计强化心肺训练30分钟！马拉松在向你招手！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 30));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_9);
                    } else if ((inZoneTime == 60 * 60)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_10);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化心肺训练**分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_10);
                    }
                } else if (currentHRValue >= hr_43 && currentHRValue <= hr_54) {//心率达到强化肌能区间
                    if (inZoneTime == 5) {//已进入强化机能区间，强化机能训练应持续20到30分钟！
                        if (!isNotFirstInBodyMode) {
                            sounds.add(R.raw.female_hr_enhancemode_1);
                            sounds.add(R.raw.female_hr_enhancemode_2);
                        } else {//已进入强化机能区间，强化机能训练应持续20到30分钟
                            sounds.add(R.raw.female_hr_current_heartrate);
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                            sounds.add(R.raw.female_hr_enhancemode_1);
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计强化机能训练5分钟！肌能训练，可以提升身体排除乳酸能力！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {//累计强化机能训练20分钟！肌肉会有点酸痛，那是乳酸正在堆积。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 30
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计强化机能训练15分钟！当你觉得难受，请将速度降下来。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_6);
                    } else if (inZoneTime == 60 * 20) {//累计强化机能训练20分钟！不断挑战当前的酸痛，可以提高乳酸阈值。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_7);
                    } else if (inZoneTime == 60 * 30) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_8);
                    } else if ((inZoneTime > 60 * 30) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_8);
                    }
                } else if (currentHRValue >= hr_54 && currentHRValue < max) {//心率达到极限强度区间
                    if (inZoneTime == 5) {//已进入极限强度区间
                        if (!isNotFirstInSuperMode) {
                            sounds.add(R.raw.female_hr_maxhrrange);
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                            sounds.add(R.raw.female_hr_maxhrrange);
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计极限强度训练**分钟！
                        sounds.add(R.raw.female_hr_maxhrrange_1);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime >= 300 && (inZoneTime % 60 == 0)) {//累计极限强度训练**分钟！建议休息5分钟再训练！
                        sounds.add(R.raw.female_hr_maxhrrange_1);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_maxhrrange_2);
                    }
                } else if (currentHRValue > max) {
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            case 6://心率教练模式-自定义
                if (currentHRValue < customMin - 5) {
                    if (lowZoneTime == 5) {//当前心率***，请加速！
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    }
                } else if (currentHRValue >= customMin && currentHRValue <= customMax) {
                    if (inZoneTime == 5) {//当前心率***，已进入自定义心率区间
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_custommode_1);
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0) {//累计心率区间训练**分钟！
                        sounds.add(R.raw.female_hr_adduptraining);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    }
                } else if (currentHRValue > customMax + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            case 5://心率教练模式-极限强度
                if (currentHRValue > hr_01 && currentHRValue < hr_54 - 5) {
                    if (lowZoneTime == 5) {
                        sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                        sounds.add(R.raw.female_hr_warmup);//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    }
                } else if (currentHRValue >= hr_54 && currentHRValue < max) {
                    if (inZoneTime == 5) {//已进入极限强度区间
                        if (!isNotFirstInSuperMode) {
                            sounds.add(R.raw.female_hr_maxhrrange);
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                            sounds.add(R.raw.female_hr_maxhrrange);
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 5 * 60) {//累计极限强度训练**分钟
                        sounds.add(R.raw.female_hr_maxhrrange_1);
                        sounds.addAll(numberToVoiceMode1(1, (inZoneTime / 60)));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime >= 300 && inZoneTime % 60 == 0) {//累计极限强度训练**分钟！建议休息5分钟再训练！
                        sounds.add(R.raw.female_hr_maxhrrange_1);
                        sounds.addAll(numberToVoiceMode1(1, (inZoneTime / 60)));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_maxhrrange_2);
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            case 4://教练模式-强化机能
                if (currentHRValue > hr_01 && currentHRValue < hr_43 - 5) {
                    if (lowZoneTime == 5) {
                        sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                        sounds.add(R.raw.female_hr_warmup);//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    }
                } else if (currentHRValue >= hr_43 && currentHRValue < hr_54) {
                    if (inZoneTime == 5) {//已进入强化机能区间，强化机能训练应持续20到30分钟！
                        if (!isNotFirstInBodyMode) {
                            sounds.add(R.raw.female_hr_enhancemode_1);
                            sounds.add(R.raw.female_hr_enhancemode_2);
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                            sounds.add(R.raw.female_hr_enhancemode_1);
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计强化机能训练5分钟！肌能训练，可以提升身体排除乳酸能力！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {//累计强化机能训练20分钟！肌肉会有点酸痛，那是乳酸正在堆积。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 30
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            ) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计强化机能训练15分钟！当你觉得难受，请将速度降下来。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_6);
                    } else if (inZoneTime == 60 * 20) {//累计强化机能训练20分钟！不断挑战当前的酸痛，可以提高乳酸阈值。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_7);
                    } else if (inZoneTime == 60 * 30) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_8);
                    } else if ((inZoneTime > 60 * 30) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化机能训练**分钟！
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds.add(R.raw.female_hr_enhancemode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancemode_8);
                    }
                } else if (currentHRValue > hr_54 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            case 3://教练模式-强化心肺
                if (currentHRValue > hr_01 && currentHRValue < hr_32 - 5) {
                    if (lowZoneTime == 5) {
                        sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                        sounds.add(R.raw.female_hr_warmup);//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    }
                } else if (currentHRValue >= hr_32 && currentHRValue < hr_43) {
                    if (inZoneTime == 5) {
                        if (!isNotFirstInHeartLungMode) {
                            sounds.add(R.raw.female_hr_enhancecardiomode_1);//已进入强化心肺区间，
                            sounds.add(R.raw.female_hr_enhancecardiomode_2);//强化心肺训练应持续30到90分钟！
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                            sounds.add(R.raw.female_hr_enhancecardiomode_1);//已进入强化心肺区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化心肺训练1--4分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计强化心肺训练5分钟！心肺更强壮，才能跑得更远！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化心肺训练6--9分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {///累计强化心肺训练10分钟！锻炼耐力，是更强壮的基础！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计强化心肺训练6--9分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计强化心肺训练15分钟！注意补充水分以及电解质，如盐汽水。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_7);
                    } else if (inZoneTime == 60 * 20) {//累计强化心肺训练20分钟！可适当补充能量，如碳水化合物。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_8);
                    } else if (inZoneTime == 60 * 25) {//累计强化心肺训练25分钟！强化心肺锻炼基本达标！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 25));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_6);
                    } else if (inZoneTime == 60 * 30) {//累计强化心肺训练30分钟！马拉松在向你招手！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, 30));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_9);
                    } else if ((inZoneTime == 60 * 60)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_10);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化心肺训练**分钟！
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds.add(R.raw.female_hr_enhancecardiomode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_enhancecardiomode_10);
                    }
                } else if (currentHRValue > hr_43 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            case 2://教练模式-燃脂模式
                if (currentHRValue > hr_01 && currentHRValue < hr_21 - 5) {
                    if (lowZoneTime == 5) {
                        sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                        sounds.add(R.raw.female_hr_warmup);//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_speedup);
                    }
                } else if (currentHRValue >= hr_21 && currentHRValue < hr_32) {
                    if (inZoneTime == 5) {
                        if (!isNotFirstInFatMode) {
                            sounds.add(R.raw.female_hr_fatburningmode_1);//已进入燃脂区间，
                            sounds.add(R.raw.female_hr_fatburningmode_2);//燃脂训练应持续30到60分钟！
                        } else {
                            sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                            sounds.addAll(numberToVoiceMode1(1, currentHRValue));//**
                            sounds.add(R.raw.female_hr_fatburningmode_1);//已进入燃脂区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计燃脂训练1--4分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 5) {//累计燃脂训练5分钟！此阶段以燃烧糖类为主！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 5));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_4);
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计燃脂训练6--9分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 10) {//累计燃脂训练10分钟！脂肪燃烧刚刚开始！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 10));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_5);
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计燃脂训练**分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if (inZoneTime == 60 * 15) {//累计燃脂训练15分钟！肌肉利用氧气的能力在提升！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 15));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_8);
                    } else if (inZoneTime == 60 * 20) {//累计燃脂训练20分钟！燃脂训练基本达标！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 20));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_6);
                    } else if (inZoneTime == 60 * 25) {//累计燃脂训练25分钟！注意补充水分以及电解质，如盐汽水。
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 25));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_7);
                    } else if (inZoneTime == 60 * 30) {//累计燃脂训练30分钟！本次训练完美！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, 30));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_9);
                    } else if ((inZoneTime == 60 * 60)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_10);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计燃脂训练**分钟！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds.add(R.raw.female_hr_fatburningmode_3);
                        sounds.addAll(numberToVoiceMode1(1, inZoneTime / 60));
                        sounds.add(R.raw.female_long_minute);
                        sounds.add(R.raw.female_hr_fatburningmode_10);
                    }
                } else if (currentHRValue > hr_32 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds.add(R.raw.female_hr_current_heartrate);
                        sounds.addAll(numberToVoiceMode1(1, currentHRValue));
                        sounds.add(R.raw.female_hr_slowdown);
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds.add(R.raw.female_hr_toohigh);
                    }
                }
                break;
            default:
                break;
        }
        if (sounds.size() > 0) {
            getSoundPlayer().playMultiSounds(sounds, getRawTimeSpaceByRes(sounds));
            sounds.clear();
        }
    }

    /**
     * 播报女声英文心率语音
     */
    private void playFemaleEnglishHrVoice(int currentHRValue, int inCoachModeAllTime, int lowZoneTime, int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode, int custom_min, int custom_max, int max, double hr_01, int hr_21, int hr_32, int hr_43, int hr_54, int userCoachMode) {
        ArrayList<String> sounds0 = new ArrayList<>();
        switch (userCoachMode) {
            case 7://心率教练模式-自由模式
                if (currentHRValue > hr_01 && currentHRValue <= hr_21) {//心率达到运动热身区间
                    if (inZoneTime == 5) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_warmup.mp3");//已进入热身区间！
                    }
                } else if (currentHRValue >= hr_21 && currentHRValue <= hr_32) {//心率达到燃烧脂肪区间
                    if (inZoneTime == 5) {
                        if (!isNotFirstInFatMode) {
                            sounds0.add(hrVoicePath + "hr_fatburningmode_1.mp3");//已进入燃脂区间，
                            sounds0.add(hrVoicePath + "hr_fatburningmode_2.mp3");//燃脂训练应持续30到60分钟！
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_fatburningmode_1.mp3");//已进入燃脂区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计燃脂训练1--4分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计燃脂训练5分钟！此阶段以燃烧糖类为主！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计燃脂训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {//累计燃脂训练10分钟！脂肪燃烧刚刚开始！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 10));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计燃脂训练**分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计燃脂训练15分钟！肌肉利用氧气的能力在提升！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_8.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计燃脂训练20分钟！燃脂训练基本达标！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_6.mp3");
                    } else if (inZoneTime == 60 * 25) {//累计燃脂训练25分钟！注意补充水分以及电解质，如盐汽水。
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 25));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_7.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计燃脂训练30分钟！本次训练完美！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_9.mp3");
                    } else if ((inZoneTime == 60 * 60)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_10.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计燃脂训练**分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_10.mp3");
                    }
                } else if (currentHRValue >= hr_32 && currentHRValue <= hr_43) {//心率达到强化心肺区间
                    if (inZoneTime == 5) {
                        if (!isNotFirstInHeartLungMode) {
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_1.mp3");//已进入强化心肺区间，
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_2.mp3");//强化心肺训练应持续30到90分钟！
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_1.mp3");//已进入强化心肺区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化心肺训练1--4分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计强化心肺训练5分钟！心肺更强壮，才能跑得更远！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化心肺训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {///累计强化心肺训练10分钟！锻炼耐力，是更强壮的基础！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 10));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计强化心肺训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计强化心肺训练15分钟！注意补充水分以及电解质，如盐汽水。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_7.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计强化心肺训练20分钟！可适当补充能量，如碳水化合物。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_8.mp3");
                    } else if (inZoneTime == 60 * 25) {//累计强化心肺训练25分钟！强化心肺锻炼基本达标！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 25));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_6.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计强化心肺训练30分钟！马拉松在向你招手！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_9.mp3");
                    } else if ((inZoneTime == 60 * 60)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_10.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化心肺训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_10.mp3");
                    }
                } else if (currentHRValue >= hr_43 && currentHRValue <= hr_54) {//心率达到强化肌能区间
                    if (inZoneTime == 5) {//已进入强化机能区间，强化机能训练应持续20到30分钟！
                        if (!isNotFirstInBodyMode) {
                            sounds0.add(hrVoicePath + "hr_enhancemode_1.mp3");
                            sounds0.add(hrVoicePath + "hr_enhancemode_2.mp3");
                        } else {//当前心率**，已进入强化机能区间
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_enhancemode_1.mp3");
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计强化机能训练5分钟！肌能训练，可以提升身体排除乳酸能力！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {//累计强化机能训练20分钟！肌肉会有点酸痛，那是乳酸正在堆积。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 30
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计强化机能训练15分钟！当你觉得难受，请将速度降下来。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_6.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计强化机能训练20分钟！不断挑战当前的酸痛，可以提高乳酸阈值。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_7.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_8.mp3");
                    } else if ((inZoneTime > 60 * 30) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_8.mp3");
                    }
                } else if (currentHRValue >= hr_54 && currentHRValue < max) {//心率达到极限强度区间
                    if (inZoneTime == 5) {//已进入极限强度区间
                        if (!isNotFirstInSuperMode) {
                            sounds0.add(hrVoicePath + "hr_maxhrrange.mp3");
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_maxhrrange.mp3");
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计极限强度训练**分钟！
                        sounds0.add(hrVoicePath + "hr_maxhrrange_1.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime >= 300 && (inZoneTime % 60 == 0)) {//累计极限强度训练**分钟！建议休息5分钟再训练！
                        sounds0.add(hrVoicePath + "hr_maxhrrange_1.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_maxhrrange_2.mp3");
                    }
                } else if (currentHRValue > max) {
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            case 6://心率教练模式-自定义
                if (currentHRValue < custom_min - 5) {
                    if (lowZoneTime == 10) {//当前心率***，请加速！
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    }
                } else if (currentHRValue >= custom_min && currentHRValue <= custom_max) {
                    if (inZoneTime == 5) {//当前心率***，已进入自定义心率区间
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_custommode_1.mp3");
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0) {//累计心率区间训练**分钟！
                        sounds0.add(hrVoicePath + "hr_adduptraining.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    }
                } else if (currentHRValue > custom_max + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }

                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            case 5://心率教练模式-极限强度
                if (currentHRValue > hr_01 && currentHRValue < hr_54 - 5) {
                    if (lowZoneTime == 5) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_warmup.mp3");//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    }
                } else if (currentHRValue >= hr_54 && currentHRValue < max) {
                    if (inZoneTime == 5) {//已进入极限强度区间
                        if (!isNotFirstInSuperMode) {
                            sounds0.add(hrVoicePath + "hr_maxhrrange.mp3");
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_maxhrrange.mp3");
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 5 * 60) {//累计极限强度训练**分钟
                        sounds0.add(hrVoicePath + "hr_maxhrrange_1.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime >= 300 && inZoneTime % 60 == 0) {//累计极限强度训练**分钟！建议休息5分钟再训练！
                        sounds0.add(hrVoicePath + "hr_maxhrrange_1.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_maxhrrange_2.mp3");
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            case 4://心率教练模式-强化机能
                if (currentHRValue > hr_01 && currentHRValue < hr_43 - 5) {
                    if (lowZoneTime == 5) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_warmup.mp3");//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    }
                } else if (currentHRValue >= hr_43 && currentHRValue < hr_54) {
                    if (inZoneTime == 5) {//已进入强化机能区间，强化机能训练应持续20到30分钟！
                        if (!isNotFirstInBodyMode) {
                            sounds0.add(hrVoicePath + "hr_enhancemode_1.mp3");
                            sounds0.add(hrVoicePath + "hr_enhancemode_2.mp3");
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_enhancemode_1.mp3");
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计强化机能训练5分钟！肌能训练，可以提升身体排除乳酸能力！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {//累计强化机能训练20分钟！肌肉会有点酸痛，那是乳酸正在堆积。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 30
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计强化机能训练15分钟！当你觉得难受，请将速度降下来。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_6.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计强化机能训练20分钟！不断挑战当前的酸痛，可以提高乳酸阈值。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_7.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_8.mp3");
                    } else if ((inZoneTime > 60 * 30) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化机能训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化机能训练**分钟！单次强化机能训练时间不宜过长，建议多组训练。
                        sounds0.add(hrVoicePath + "hr_enhancemode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancemode_8.mp3");
                    }
                } else if (currentHRValue > hr_54 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                } else if (currentHRValue >= max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            case 3://心率教练模式-强化心肺
                if (currentHRValue > hr_01 && currentHRValue < hr_32 - 5) {
                    if (lowZoneTime == 5) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_warmup.mp3");//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    }
                } else if (currentHRValue >= hr_32 && currentHRValue < hr_43) {
                    if (inZoneTime == 5) {
                        if (!isNotFirstInHeartLungMode) {
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_1.mp3");//已进入强化心肺区间，
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_2.mp3");//强化心肺训练应持续30到90分钟！
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_enhancecardiomode_1.mp3");//已进入强化心肺区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计强化心肺训练1--4分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计强化心肺训练5分钟！心肺更强壮，才能跑得更远！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计强化心肺训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {///累计强化心肺训练10分钟！锻炼耐力，是更强壮的基础！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 10));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计强化心肺训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计强化心肺训练15分钟！注意补充水分以及电解质，如盐汽水。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_7.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计强化心肺训练20分钟！可适当补充能量，如碳水化合物。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_8.mp3");
                    } else if (inZoneTime == 60 * 25) {//累计强化心肺训练25分钟！强化心肺锻炼基本达标！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 25));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_6.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计强化心肺训练30分钟！马拉松在向你招手！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_9.mp3");
                    } else if ((inZoneTime == 60 * 60)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_10.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计强化心肺训练**分钟！
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计强化心肺训练**分钟！强化心肺训练，宜控制在100分钟以内。
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_enhancecardiomode_10.mp3");
                    }
                } else if (currentHRValue > hr_43 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            case 2://心率教练模式-燃脂模式
                if (currentHRValue > hr_01 && currentHRValue < hr_21 - 5) {
                    if (lowZoneTime == 5 && inCoachModeAllTime == 5) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_warmup.mp3");//已进入热身区间！
                    } else if (lowZoneTime >= 30 && lowZoneTime % 30 == 0) {//当前心率***，请加速！
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_speedup.mp3");
                    }
                } else if (currentHRValue >= hr_21 && currentHRValue < hr_32) {
                    if (inZoneTime == 5) {
                        if (!isNotFirstInFatMode) {
                            sounds0.add(hrVoicePath + "hr_fatburningmode_1.mp3");//已进入燃脂区间，
                            sounds0.add(hrVoicePath + "hr_fatburningmode_2.mp3");//燃脂训练应持续30到60分钟！
                        } else {
                            sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");//当前心率
                            sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                            sounds0.add(hrVoicePath + "hr_fatburningmode_1.mp3");//已进入燃脂区间！
                        }
                    } else if (inZoneTime > 30 && inZoneTime % 60 == 0 && inZoneTime < 60 * 5) {//累计燃脂训练1--4分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 5) {//累计燃脂训练5分钟！此阶段以燃烧糖类为主！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 5));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_4.mp3");
                    } else if (inZoneTime > 300 && inZoneTime % 60 == 0 && inZoneTime < 60 * 10) {//累计燃脂训练6--9分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 10) {//累计燃脂训练10分钟！脂肪燃烧刚刚开始！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 10));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_5.mp3");
                    } else if (inZoneTime > 600 && inZoneTime % 60 == 0 && inZoneTime < 60 * 60
                            && inZoneTime != 60 * 15
                            && inZoneTime != 60 * 20
                            && inZoneTime != 60 * 25
                            && inZoneTime != 60 * 30
                            && inZoneTime != 60 * 40
                            && inZoneTime != 60 * 50) {//累计燃脂训练**分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if (inZoneTime == 60 * 15) {//累计燃脂训练15分钟！肌肉利用氧气的能力在提升！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 15));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_8.mp3");
                    } else if (inZoneTime == 60 * 20) {//累计燃脂训练20分钟！燃脂训练基本达标！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 20));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_6.mp3");
                    } else if (inZoneTime == 60 * 25) {//累计燃脂训练25分钟！注意补充水分以及电解质，如盐汽水。
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 25));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_7.mp3");
                    } else if (inZoneTime == 60 * 30) {//累计燃脂训练30分钟！本次训练完美！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), 30));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_9.mp3");
                    } else if ((inZoneTime == 60 * 60)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_10.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % 60 == 0) && (inZoneTime % (5 * 60) != 0)) {//累计燃脂训练**分钟！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                    } else if ((inZoneTime > 60 * 60) && (inZoneTime % (5 * 60) == 0)) {//累计燃脂训练**分钟！燃脂训练宜控制在120分钟以内！
                        sounds0.add(hrVoicePath + "hr_fatburningmode_3.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), inZoneTime / 60));
                        sounds0.add(commonPath + "minute.mp3");
                        sounds0.add(hrVoicePath + "hr_fatburningmode_10.mp3");
                    }
                } else if (currentHRValue > hr_32 + 5 && currentHRValue < max) {
                    if (upZoneTime == 10) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    } else if (upZoneTime > 10 && upZoneTime % 30 == 0) {
                        sounds0.add(hrVoicePath + "hr_current_heartrate.mp3");
                        sounds0.addAll(numberToVoice(getCurrentVoiceType(), currentHRValue));
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                } else if (currentHRValue > max) {//心率过高！请减速！
                    if (superZoneTime >= 5 && superZoneTime % 5 == 0) {
                        sounds0.add(hrVoicePath + "hr_toohigh.mp3");
                        sounds0.add(hrVoicePath + "hr_slowdown.mp3");
                    }
                }
                break;
            default:
                break;
        }
        if (sounds0.size() > 0) {
            getSoundPlayer().playMultiSoundsByPath(sounds0, getTimeSpaceByPathRes(sounds0));
            sounds0.clear();
        }
    }

    /**
     * 每个区间第一分钟的语音拼接
     *
     * @param toneType  语调
     * @param levelArea 心率区间 ,取值范围为
     */
    private void playMultiSoundsAtHrFirstMinute(String toneType, int levelArea) {
        ArrayList<Integer> sounds = new ArrayList<>();

        switch (toneType) {
            case "female":
            case "male":
            default:
                switch (levelArea) {
                    case 2:
                        sounds.add(R.raw.female_hr_fat_burn_1_header);//太给力了
                        sounds.add(R.raw.female_hr_fat_burn_1_content);//您已经进入燃脂区间
                        break;
                    case 3:
                        sounds.add(R.raw.female_hr_aerobic_1_header);//太棒了
                        sounds.add(R.raw.female_hr_aerobic_1_content);//您已进入强化心肺区间
                        break;
                    case 4:
                        sounds.add(R.raw.female_hr_anaerobic_1_header);//不可思议
                        sounds.add(R.raw.female_hr_anaerobic_1_content);//您已进入强化机能区间
                        break;
                    case 5:
                        sounds.add(R.raw.female_hr_max_1_header);//oh my god,难以置信
                        sounds.add(R.raw.female_hr_max_1_content);//您已进入极限强度区间
                        break;
                }
        }
        if (sounds == null || (sounds.size() == 0))
            return;
        getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
        sounds.clear();
    }

    /**
     * 播报当前最大摄氧量,如：当前最大摄氧量______比正常人平均值高____%,非常棒,坚持训练计划(非常棒,坚持训练计划)
     *
     * @param maxVo2 最大摄氧量,单位ml/kg/min
     * @param avgVo2 正常人平均值摄氧量,单位ml/kg/min
     */
    public void playMaxVo2(float maxVo2, float avgVo2) {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 补充


                break;
            case "female":
            case "male":
            default:
                ArrayList<Integer> sounds = getMaxVo2MessageList(0, maxVo2, avgVo2);
                if (sounds == null || (sounds.size() == 0))
                    return;
                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 根据语音播报语调、
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param ml2      最大摄氧量
     * @param avgml2   正常人的最大摄氧量
     * @return 最大摄氧量播报声音资源拼接集合 如 当前最大摄氧量______比正常人平均值高____%,非常棒,坚持训练计划
     * 当前最大摄氧量______比正常人平均值低____%,还需加强训练,加油
     */
    private ArrayList<Integer> getMaxVo2MessageList(int toneType, float ml2, float avgml2) {
        if (ml2 < 0 || avgml2 <= 0)
            return null;

        ArrayList<Integer> ml2Difference = null;
        DecimalFormat df = new DecimalFormat("0.0");
        String sResult = df.format(ml2);
        int iIndex = sResult.indexOf(".");
        int iNumber;
        ArrayList<Integer> part1;
        if (iIndex != -1) {
            iNumber = Integer.parseInt(sResult.substring(0, iIndex));
        } else {
            iNumber = Integer.parseInt(sResult);
        }
        part1 = numberToVoiceMode1(toneType, iNumber);

        ArrayList<Integer> part2 = numberToVoiceMode2(toneType,
                sResult.substring(iIndex + 1));

        boolean higherThanAvg;
        int difference;
        if (ml2 > avgml2) {
            higherThanAvg = true;
            difference = (int) ((ml2 - avgml2) * 100 / avgml2);
        } else {
            higherThanAvg = false;
            difference = (int) ((avgml2 - ml2) * 100 / avgml2);
        }

        if (difference > 0)
            ml2Difference = numberToVoiceMode1(toneType, difference);
        if (ml2Difference == null)
            return null;

        ArrayList<Integer> sounds = new ArrayList<>();

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                sounds.add(R.raw.female_hr_aerobic_now_vo2max);//当前最大摄氧量
                if (part1 != null)
                    sounds.addAll(part1);
                if (iIndex != -1) {
                    sounds.add(R.raw.female_dot);//点
                    if (part2 != null)
                        sounds.addAll(part2);
                }

                if (higherThanAvg) {
                    sounds.add(R.raw.female_hr_aerobic_now_vo2max_higher);//比正常人平均值高
                } else {
                    sounds.add(R.raw.female_hr_aerobic_now_vo2max_lower);//比正常人平均值低
                }
                if (ml2Difference != null) {
                    sounds.add(R.raw.female_hr_aerobic_percent);//百分之
                    sounds.addAll(ml2Difference);
                }
                if (higherThanAvg) {
                    sounds.add(R.raw.female_hr_aerobic_now_vo2max_higher_end);//非常棒,坚持训练计划
                } else {
                    sounds.add(R.raw.female_hr_aerobic_now_vo2max_lower_end);//加强训练,加油
                }
                break;
        }

        if (part1 != null) {
            part1.clear();
        }
        if (part2 != null) {
            part2.clear();
        }
        if (ml2Difference != null)
            ml2Difference.clear();

        return sounds;
    }

    /**
     * 播报脂肪燃烧,如【您已燃烧____克脂肪】
     *
     * @param fatBurn 脂肪燃烧,单位为克
     */
    public void playFatBurn(float fatBurn) {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default:
                ArrayList<Integer> sounds = getFatBurnMessageList(0, fatBurn);
                if (sounds == null || (sounds.size() == 0))
                    return;
                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 心率耳机按下心率圆圈按键,播放：当前心率值：语音
     */
    public void playHrVoice(int currentHr) {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default:
                ArrayList<Integer> sounds = getCurrentHRMessageList(0, currentHr);
                if (sounds == null || (sounds.size() == 0))
                    return;
                getSoundPlayer().playMultiSounds(sounds, getTimeSpaceByRes(sounds));
                sounds.clear();
                break;
        }
    }

    /**
     * 心率耳机连接成功后播放
     */
    public void playLAVAVoice() {
        switch (getCurrentVoiceType()) {
            case "female_en"://TODO 后续补充
                break;
            case "female":
            case "male":
            default:
                getSoundPlayer().playSingleSound(R.raw.female_hr_run_start);//聆听心率声音 把握燃脂节奏,Let's go!
                break;
        }
    }

    /**
     * 根据语音播报语调、脂肪克数,获取燃烧脂肪播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param gram     脂肪燃烧克数,单位克
     * @return 脂肪燃烧播报声音资源拼接集合, 如【您已燃烧____克脂肪】
     */
    private ArrayList<Integer> getFatBurnMessageList(int toneType, float gram) {
        if ((gram < 0))
            return null;
        ArrayList<Integer> sounds = new ArrayList<>();
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                if (gram > 0) {
                    sounds.add(R.raw.female_hr_have_burned);//您已燃烧
                    DecimalFormat df = new DecimalFormat("0.0");
                    String sResult = df.format(gram);
                    int iIndex = sResult.indexOf(".");
                    int iNumber;
                    ArrayList<Integer> part1;
                    if (iIndex != -1) {
                        iNumber = Integer.parseInt(sResult.substring(0, iIndex));
                    } else {
                        iNumber = Integer.parseInt(sResult);
                    }
                    part1 = numberToVoiceMode1(toneType, iNumber);

                    ArrayList<Integer> part2 = numberToVoiceMode2(toneType,
                            sResult.substring(iIndex + 1));
                    if (part1 != null)
                        sounds.addAll(part1);
                    if (iIndex != -1) {
                        sounds.add(R.raw.female_dot);//点
                        if (part2 != null)
                            sounds.addAll(part2);
                    }
                    sounds.add(R.raw.female_hr_garm_fat);//克脂肪
                }
                break;
        }
        return sounds;
    }

    /**
     * 根据语音播报语调、当前心率值,获取心率值播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param hr       当前心率值,
     * @return 当前心率值播报声音资源拼接集合, 如【当前心率值：】
     */
    public ArrayList<Integer> getCurrentHRMessageList(int toneType, int hr) {
        if ((hr <= 0))
            return null;
        ArrayList<Integer> sounds = new ArrayList<>();

        ArrayList<Integer> ml2List = numberToVoiceMode1(toneType, hr);
        if ((ml2List == null))
            return null;

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                if (hr >= 0) {
                    sounds.add(R.raw.female_hr_current_heartrate);//当前心率
                    if (ml2List != null) {
                        sounds.addAll(ml2List);
                    }
                }
                break;
        }
        return sounds;
    }

    //endregion ================================== 心率相关语音 =========================================

    //region ================================== 跳绳报数语音 =========================================

    /**
     * 播报跳绳次数
     *
     * @param number 数字
     */
    public void playNumber(int number) {
        String voiceType = getCurrentVoiceType();
        ArrayList<String> numList = null;

        if ("female".equals(voiceType)) {//默认的语音
            ArrayList<Integer> theNumList = numberToVoiceMode1(Config.SIRI_TONE_TYPE_FEMALE, number);
            getSoundPlayer().playMultiSounds(theNumList, getTimeSpaceByRes(theNumList));
            if (theNumList != null && theNumList.size()>0){
                theNumList.clear();
            }
        } else {//选定的语音包
            if (number > 0) {
                numList = numberToVoice(voiceType, number);
            }

            if (numList == null || (numList.size() == 0))
                return;

            getSoundPlayer().playMultiSoundsByPath(numList, getTimeSpaceByPathRes(numList));
            numList.clear();
        }
    }

    //endregion ================================== 跳绳报数语音 =========================================

    //region  ================================== 数字语音拼接 =========================================

    /**
     * 根据语音播报语调、数字,从apk中自带的语音包中获取数字播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param number   数字,取值范围[0,9999]
     * @return 数字播报声音资源拼接集合, 如【1百 2 十】
     */
    private ArrayList<Integer> numberToVoiceMode1(int toneType, int number) {

        if ((number >= 10000) || (number < 0))
            return null;
        int number_voice[];
        int unit_voice[];

        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                number_voice = numberVoice_male;
//                unit_voice = unit_male;
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                number_voice = numberVoice_female;
                unit_voice = unit_female;
                break;
        }

        ArrayList<Integer> sounds = new ArrayList<>();

        int iBase = 1000;
        int iNumber = -1;
        int iLastNumber = iNumber;
        if ((number >= 10) && (number <= 19)) {
            sounds.add(unit_voice[2]);//十
            iNumber = number % 10;
            if (iNumber > 0) {
                sounds.add(number_voice[iNumber]);
            }
        } else {
            for (int i = 0; i < 4; i++, iBase /= 10) {
                iNumber = number / iBase;
                number %= iBase;

                if (iNumber == 0) {
                    if (iLastNumber < 0) {
                        if (number == 0) {
                            sounds.add(number_voice[iNumber]);//零
                            break;
                        }
                        continue;
                    } else if (iLastNumber == 0) {
                        continue;
                    } else {
                        sounds.add(number_voice[iNumber]);
                        iLastNumber = iNumber;
                        continue;
                    }
                }
                if ((iNumber == 2) && (iLastNumber == -1) && (i != 2)
                        && (number == 0)) {
                    switch (toneType) {
                        case Config.SIRI_TONE_TYPE_MALE:
//                            sounds.add(R.raw.male_chinese_two);
//                            break;
                        case Config.SIRI_TONE_TYPE_FEMALE:
                        default:
                            sounds.add(R.raw.female_chinese_two);//两
                            break;
                    }
                } else {
                    sounds.add(number_voice[iNumber]);
                }
                if (i < 3)
                    sounds.add(unit_voice[i]);
                iLastNumber = iNumber;
                if (number == 0)
                    break;
            }
        }
        return sounds;
    }

    /**
     * 根据语音播报语调、数字,从语音包中获取数字播报声音资源拼接集合（包括上万的情况）
     *
     * @param voiceType 语音包 dirname
     * @param number    数字
     * @return 数字播报声音资源拼接集合, 如【1百 2 十】
     */
    private ArrayList<String> numberToVoice(String voiceType, int number) {
        //1.数字有效性判断
        if (number < 0 || voiceType == null)
            return null;
        //2.获取当前语音包中的数字和单位信息
        String number_voice[];
        String unit_voice[];
        number_voice = getNumberVoiceByVoiceType();
        unit_voice = getUnitByVoiceType();
        if (number_voice == null || number_voice.length < 20) {
            return null;
        }

        if (unit_voice == null || unit_voice.length < 2) {
            return null;
        }

        ArrayList<String> sounds = new ArrayList<>();
        int iBase = 1000;
        int iNumber = -1;
        int iLastNumber = iNumber;

        if ((number >= 0) && (number <= 20)) {
            sounds.add(number_voice[number]);//0-20 直接播报
        } else {
            for (int i = 0; i < 4; i++, iBase /= 10) {
                iNumber = number / iBase;//商,取值范围为0-9
                number %= iBase;//余数

                if (iNumber == 0) {
                    if (iLastNumber < 0) {
                        if (number == 0) {
                            sounds.add(number_voice[iNumber]);//个位数
                            break;
                        }
                        if (number > 0 && number <= 19) {
                            sounds.add(number_voice[number]);
                            break;
                        } else {
                            continue;
                        }
                    } else if (iLastNumber == 0)//1001 //0059不存在
                        continue;
                    else {//iLastNumber>0
                        if (i == 1) {
                            sounds.add(unit_voice[2]);//1021,播and//1101
                        }
                        if (number > 0 && number <= 19) {
                            sounds.add(number_voice[number]);
                            break;
                        }
                        iLastNumber = iNumber;
                        continue;
                    }
                }

                if (i == 2) {
                    sounds.add(number_voice[18 + iNumber]);//范围为2-9,因此number_voice[20-27]
                    if (number > 0) {//number范围为1-9
                        sounds.add(number_voice[number]);
                        break;
                    }
                } else {
                    if (iNumber <= 10) {//商为个位数
                        sounds.add(number_voice[iNumber]);
                    } else {//商大于个位数
                        if (iNumber > 99) {//商超过十位数忽略
                            break;
                        }
                        if (iNumber > 10 && iNumber < 19) {
                            sounds.add(number_voice[iNumber]);
                        } else {
                            int a = iNumber / 10;//2-9
                            int b = iNumber % 10;//0-9
                            sounds.add(number_voice[18 + a]);
                            if (b != 0) {
                                sounds.add(number_voice[b]);
                            }
                        }
                    }

                }

                if (i < 2) {//千、百
                    sounds.add(unit_voice[i]);
                    if (i == 1 && number != 0) {//百后and
                        sounds.add(unit_voice[2]);//and
                        if (number > 0 && number <= 19) {//不包括0
                            sounds.add(number_voice[number]);
                            break;
                        }
                    }
                }
                iLastNumber = iNumber;
                if (number == 0)
                    break;
            }
        }
        if (sounds.size() == 0) {
            return null;
        }
        return sounds;
    }

    /**
     * 根据语音播报语调、数字,获取数字播报声音资源拼接集合（不包括上万的情况）
     *
     * @param voiceType 语音包 dirname
     * @param number    数字
     * @return 数字播报声音资源拼接集合, 如【1百 2 十】
     */
    private ArrayList<String> numberToVoiceMode1(String voiceType, String type, int number) {

        if ((number >= 10000) || (number < 0))
            return null;

        String number_voice[];
        String unit_voice[];
        number_voice = getNumberVoiceByVoiceType();
        unit_voice = getUnitByVoiceType();

        ArrayList<String> sounds = new ArrayList<>();

        int iBase = 1000;
        int iNumber = -1;
        int iLastNumber = iNumber;

        if (voiceType.equals("female")) {
            if ((number >= 10) && (number <= 19)) {
                sounds.add(unit_voice[2]);//
                iNumber = number % 10;
                if (iNumber > 0) {
                    sounds.add(number_voice[iNumber]);
                }
            } else {
                for (int i = 0; i < 4; i++, iBase /= 10) {
                    iNumber = number / iBase;
                    number %= iBase;

                    if (iNumber == 0) {
                        if (iLastNumber < 0) {
                            if (number == 0) {
                                sounds.add(number_voice[iNumber]);
                                break;
                            }
                            continue;
                        } else if (iLastNumber == 0)
                            continue;
                        else {//iLastNumber > 0
                            sounds.add(number_voice[iNumber]);//1021
                            iLastNumber = iNumber;
                            continue;
                        }
                    }
                    if ((iNumber == 2) && (iLastNumber == -1) && (i != 2)
                            && (number == 0)) {
                        sounds.add(Config.PATH_LOCAL_VOICE + voiceType + File.separator + type + "_chinese_two.mp3");//两
                    } else {
                        sounds.add(number_voice[iNumber]);
                    }
                    if (i < 3)
                        sounds.add(unit_voice[i]);
                    iLastNumber = iNumber;
                    if (number == 0)
                        break;
                }
            }
        } else if (voiceType.equals("female_en")) {//英文
            if ((number >= 0) && (number <= 19)) {
                sounds.add(number_voice[number]);//10-19
            } else {
                for (int i = 0; i < 4; i++, iBase /= 10) {
                    iNumber = number / iBase;//商,取值范围为0-9
                    number %= iBase;//余数

                    if (iNumber == 0) {
                        if (iLastNumber < 0) {
                            if (number == 0) {
                                sounds.add(number_voice[iNumber]);//个位数
                                break;
                            }
                            if (number > 0 && number <= 19) {
                                sounds.add(number_voice[number]);
                                break;
                            } else {
                                continue;
                            }
                        } else if (iLastNumber == 0)//1001 //0059不存在
                            continue;
                        else {//iLastNumber>0
                            if (i == 1) {
                                sounds.add(unit_voice[2]);//1021,播and//1101
                            }
                            if (number > 0 && number <= 19) {
                                sounds.add(number_voice[number]);
                                break;
                            }
                            iLastNumber = iNumber;
                            continue;
                        }
                    }

                    if (i == 2) {
                        sounds.add(number_voice[18 + iNumber]);//范围为2-9,因此number_voice[21-28]
                        if (number > 0) {//number范围为1-9
                            sounds.add(number_voice[number]);
                            break;
                        }
                    } else {
                        sounds.add(number_voice[iNumber]);
                    }

                    if (i < 2) {//千、百
                        sounds.add(unit_voice[i]);
                        if (i == 1 && number != 0) {//百后and
                            sounds.add(unit_voice[2]);//and
                            if (number > 0 && number <= 19) {//不包括0
                                sounds.add(number_voice[number]);
                                break;
                            }
                        }
                    }
                    iLastNumber = iNumber;
                    if (number == 0)
                        break;
                }
            }
        }
        if (sounds.size() == 0) {
            return null;
        }
        return sounds;
    }

    /**
     * 根据语音播报语调、小数点后数字字符串表示,从默认语音包中获取小数点后数字播报声音资源拼接集合
     *
     * @param toneType 语音播报语调,int型,0:男声,1:女声
     * @param sNumber  小数点后数字字符串表示
     * @return 小数点后数字播报声音资源拼接集合, 如【23】
     */
    private ArrayList<Integer> numberToVoiceMode2(int toneType, String sNumber) {
        if ((sNumber == null) || (sNumber.isEmpty()))
            return null;
        int number_voice[];
        switch (toneType) {
            case Config.SIRI_TONE_TYPE_MALE:
//                number_voice = numberVoice_male;
//                break;
            case Config.SIRI_TONE_TYPE_FEMALE:
            default:
                number_voice = numberVoice_female;
                break;
        }

        ArrayList<Integer> sounds = new ArrayList<>();
        int iLen = sNumber.length();
        char c;
        for (int i = 0; i < iLen; i++) {
            c = sNumber.charAt(i);
            if ((c < '0') || (c > '9')) {
                sounds.clear();
                return null;
            }
            sounds.add(number_voice[c - '0']);
        }
        return sounds;
    }

    /**
     * 根据语音播报语调、小数点后数字字符串表示,从语音包中获取小数点后数字播报声音资源拼接集合
     *
     * @param sNumber 小数点后数字字符串表示
     * @return 小数点后数字播报声音资源拼接集合, 如【23】
     */
    private ArrayList<String> numberToVoiceMode2(String sNumber) {
        if ((sNumber == null) || (sNumber.isEmpty()))
            return null;

        String number_voice[] = getNumberVoiceByVoiceType();
        ArrayList<String> sounds = new ArrayList<>();
        int iLen = sNumber.length();
        char c;
        for (int i = 0; i < iLen; i++) {
            c = sNumber.charAt(i);
            if ((c < '0') || (c > '9')) {
                sounds.clear();
                return null;
            }
            sounds.add(number_voice[c - '0']);
        }
        return sounds;
    }

    //endregion  ================================== 数字语音拼接 =========================================

    //region ===================== 获取播报每个声音后的需要等待的时间 =====================

    /**
     * 根据声音资源拼接的集合,获取播报每个声音后的需要添加的时间间隔集合,声音资源在apk包中
     *
     * @param sounds 声音资源拼接的集合
     * @return 播报每个声音后的需要添加的时间间隔集合
     */
    private long[] getTimeSpaceByRes(List<Integer> sounds) {
        if (sounds == null || sounds.size() < 1)
            return null;
        long spaceTime[] = new long[sounds.size()];
        for (int i = 0; i < spaceTime.length; i++) {
            spaceTime[i] = getSoundPlayer().getTimeSpaceById(sounds.get(i));
        }
        return spaceTime;
    }

    /**
     * 根据声音资源拼接的集合,获取播报每个声音后的需要添加的时间间隔集合,声音资源在apk包中
     *
     * @param sounds 声音资源拼接的集合
     * @return 播报每个声音后的需要添加的时间间隔集合
     */
    private long[] getRawTimeSpaceByRes(List<Integer> sounds) {
        if (sounds == null || sounds.size() < 1)
            return null;
        long spaceTime[] = new long[sounds.size()];
        for (int i = 0; i < spaceTime.length; i++) {
            spaceTime[i] = VoicePlayUtil.getRawVoiceEnDuration(sounds.get(i), MixApp.getContext());
        }
        return spaceTime;
    }

    /**
     * 根据声音资源拼接的集合,获取播报每个声音后的需要添加的时间间隔集合,声音资源在SD卡中
     *
     * @param sounds 声音资源拼接的集合
     * @return 播报每个声音后的需要添加的时间间隔集合
     */
    private long[] getTimeSpaceByPathRes(List<String> sounds) {
        if (sounds == null || sounds.size() < 1)
            return null;
        long spaceTime[] = new long[sounds.size()];
        for (int i = 0; i < spaceTime.length; i++) {
            spaceTime[i] = VoicePlayUtil.getVoiceEnDuration(sounds.get(i), MixApp.getContext());
        }
        return spaceTime;
    }

    //endregion ===================== 获取播报每个声音后的需要等待的时间 =====================

}
