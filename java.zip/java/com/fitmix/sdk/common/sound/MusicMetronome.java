package com.fitmix.sdk.common.sound;

import com.fitmix.sdk.common.Logger;

/**
 * 利用openSl es播放一个节拍
 */
public class MusicMetronome {

    /** so文件*/
    static {
        System.loadLibrary("metronome");
    }

    private boolean init;
    private int count;//循环播放次数

    /**
     * 设置节拍器bpm
     *
     * @param bpm 每分钟步频,范围[80,240].取0表示暂停
     */
    public void setBpm(int bpm) {
        if (bpm <= 0) {
            count = 0;
            playMetronome(0);
            return;
        }

        if (bpm < 80 || bpm > 240) {
            return;
        }
        if (count == 0) {
            count = 65536;
            playMetronome(count);
        }
        int rate = bpm * 1000 / 130;//step playrate = 1000 对应的bpm是130
        Logger.i(Logger.DEBUG_TAG, "MusicMetronome-->play rate: " + rate);
        if (init) {
            setRate(rate);
        }

    }

    /**
     * 开启节拍器
     */
    public void start() {
        createEngine();
        createBufferQueueAudioPlayer();
        init = true;
    }

    /**
     * 关闭节拍器,并释放资源
     */
    public void releaseResource() {
        init = false;
        shutdown();
    }

    public static native void createEngine();

    public static native void createBufferQueueAudioPlayer();

    public static native void setVolume(int milliBel);

    public static native void setMute(boolean mute);

    public static native void playMetronome(int count);

    public static native int getRate();

    public static native void setRate(int rate);

    public static native void shutdown();


}
