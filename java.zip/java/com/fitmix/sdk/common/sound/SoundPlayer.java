package com.fitmix.sdk.common.sound;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.Logger;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


/**
 * 音效播放器,适用于短小的音效文件播放
 */
public class SoundPlayer {
    private SoundPool mSoundPool;
    private Queue<Integer> mPlayedStreamId;//播放完成的资源序列
    private Queue<Integer> mPreparedSoundId;//加载完成的资源序列
    private ThreadPoolExecutor controlSoundExecutor;

    private long mSeparateTime[];

    private int iResIdCount;//资源的个数
    private int iPlayedIndex;//当前播放完成的资源position，从1开始
    private int iLoadIndex;//当前加载完成的资源position，从1开始

    private final int MAX_STREAMS = 1;// 能够同时播放的音效数量
    private final float lowMusicVolumeRatio = 0.1f;

    private Context getContext() {
        return MixApp.getContext();
    }

    private SoundPool getSoundPool() {
        if (mSoundPool == null)
            mSoundPool = new SoundPool(MAX_STREAMS, AudioManager.STREAM_MUSIC,
                    0);
        return mSoundPool;
    }

    private synchronized void addPreparedSoundId(int soundId) {
        try {
            getPreparedSoundQueue().offer(soundId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取已加载完成的声音队列
     */
    private Queue<Integer> getPreparedSoundQueue() {
        if (mPreparedSoundId == null)
            mPreparedSoundId = new LinkedList<>();
        return mPreparedSoundId;
    }

    /**
     * 获取已播放或正在播放的声音队列
     */
    private Queue<Integer> getPlayedSoundQueue() {
        if (mPlayedStreamId == null)
            mPlayedStreamId = new LinkedList<>();
        return mPlayedStreamId;
    }


    private ThreadPoolExecutor getThreadPoolExecutor() {
        if (controlSoundExecutor == null)
            controlSoundExecutor = new ThreadPoolExecutor(1, 1, 60,
                    TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        return controlSoundExecutor;
    }

    private synchronized void setLoadIndex(int iLoadIndex) {
        this.iLoadIndex = iLoadIndex;
    }

    /**
     * 获取下一个准备播放的声效ID(经过soundPool load)
     */
    private synchronized int getPreparedSoundId() {
        Integer id = getPreparedSoundQueue().poll();//移除并返回头部元素
        return (id == null) ? -1 : id;
    }

    private synchronized void setPlayedIndex(int iIndex) {
        iPlayedIndex = iIndex;
    }

    public SoundPlayer() {
        clear();
    }

    /**
     * 减小音乐播放器声音
     */
    private void lowMusicVolume() {
        PlayerController.getInstance().setVolume(lowMusicVolumeRatio);
    }

    /**
     * 恢复音乐播放器声音
     */
    private void resetMusicVolume() {
        PlayerController.getInstance().setVolume(1.0f);
    }

    private int getLoadIndex() {
        return iLoadIndex;
    }

    private int getPlayedIndex() {
        return iPlayedIndex;
    }

    private int getResIdCount() {
        return iResIdCount;
    }

    private void setResIdCount(int iCount) {
        iResIdCount = iCount;
    }

    private long[] getSeparateTime() {
        return mSeparateTime;
    }

    private final OnLoadCompleteListener loadCompleteListener = new OnLoadCompleteListener() {
        @Override
        public void onLoadComplete(final SoundPool sp, final int soundID,
                                   int status) {
            if (status != 0)
                return;
            addPreparedSoundId(soundID);
            setLoadIndex(getLoadIndex() + 1);
            if (getLoadIndex() >= getResIdCount()) {//如果全部资源播放完毕
                Logger.d(Logger.DEBUG_TAG, "onLoadComplete ready play");
                getThreadPoolExecutor().execute(myPlayRunnable);
            }
            Logger.d(Logger.DEBUG_TAG, "onLoadComplete soundID:" + soundID + ",status:" + status);
        }
    };

    /**
     * 设置需要播放的声效资源
     *
     * @param resIds       声效资源ID列表
     * @param separateTime 相邻声效间的静音时间列表
     * @return true:设置成功,false:设置失败
     */
    private synchronized boolean setPlayResources(int[] resIds,
                                                  long separateTime[]) {
        if ((resIds == null) || (separateTime == null))
            return false;
        if (resIds.length != separateTime.length)
            return false;
        stopAll();

        setResIdCount(resIds.length);
        mSeparateTime = separateTime.clone();
        getSoundPool().setOnLoadCompleteListener(loadCompleteListener);
        setLoadIndex(0);
        setPlayedIndex(0);
        return true;
    }

    /**
     * 设置需要播放的声效资源
     *
     * @param resPaths     声效资源文件路径列表
     * @param separateTime 相邻声效间的静音时间列表
     * @return true:设置成功,false:设置失败
     */
    private synchronized boolean setPlayResources(String[] resPaths,
                                                  long separateTime[]) {
        if ((resPaths == null) || (separateTime == null))
            return false;
        if (resPaths.length != separateTime.length)
            return false;
        stopAll();
        setResIdCount(resPaths.length);
        mSeparateTime = separateTime.clone();
        getSoundPool().setOnLoadCompleteListener(loadCompleteListener);
        setLoadIndex(0);
        setPlayedIndex(0);
        return true;
    }

    private void waitStoreStream(int streamId, long time) {
        getPlayedSoundQueue().offer(streamId);
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private final Runnable myPlayRunnable = new Runnable() {
        public void run() {
            while (true) {
                int soundID = getPreparedSoundId();
                if (soundID < 0) {
                    resetMusicVolume();
                    return;
                }
                if (getPlayedIndex() == 0)
                    lowMusicVolume();

                int streamId = getSoundPool().play(soundID, 1, 1, 1, 0, 1);//播放
                if (getSeparateTime() == null)
                    return;

                long time = 0;
                if (getPlayedIndex() < getSeparateTime().length) {
                    time = getSeparateTime()[getPlayedIndex()];
                }
                setPlayedIndex(getPlayedIndex() + 1);//设置播放完成的个数
                waitStoreStream(streamId, time);
            }
        }
    };

    private void clear() {
        iResIdCount = 0;
        iPlayedIndex = 0;
        iLoadIndex = 0;
    }

    public void releaseResource() {
        stopAll();
        if (mSoundPool != null) {
            mSoundPool.release();
        }
        mSoundPool = null;
        if (mPlayedStreamId != null)
            mPlayedStreamId.clear();
        mPlayedStreamId = null;
        if (mPreparedSoundId != null)
            mPreparedSoundId.clear();
        mPreparedSoundId = null;
        if (controlSoundExecutor != null)
            controlSoundExecutor.shutdown();
        controlSoundExecutor = null;
    }

    /**
     * 播报单个声效
     *
     * @param resId 单个声效资源ID
     */
    public void playSingleSound(int resId) {
        int resIds[] = new int[1];
        resIds[0] = resId;
        long separateTime[] = new long[1];
        separateTime[0] = getTimeSpaceById(resId);
        if (!setPlayResources(resIds, separateTime))
            return;
        getSoundPool().load(getContext(), resId, 1);
    }

    /**
     * 播报单个声效
     *
     * @param sFilename 单个资源文件绝对路径
     */
    public void playSingleSound(String sFilename) {
        if (sFilename == null || TextUtils.isEmpty(sFilename))
            return;
        int resIds[] = new int[1];
        resIds[0] = 0;
        long separateTime[] = new long[1];
        separateTime[0] = 100;
        if (!setPlayResources(resIds, separateTime))
            return;
        getSoundPool().load(sFilename, 1);
    }

    /**
     * 依次播报多个声效
     *
     * @param resIds       声效资源ID数组
     * @param separateTime 两两声效之间播报间隔
     */
    public void playMultiSounds(int resIds[], long separateTime[]) {
        if ((resIds == null) || (separateTime == null))
            return;
        if (resIds.length != separateTime.length)
            return;
        if (!setPlayResources(resIds, separateTime))
            return;
        for (int resId : resIds) {
            getSoundPool().load(getContext(), resId, 1);
        }
    }

    /**
     * 依次播报多个声效
     *
     * @param list         声效资源ID集合
     * @param separateTime 两两声效之间播报间隔
     */
    public void playMultiSounds(ArrayList<Integer> list, long separateTime[]) {
        if ((list == null) || list.isEmpty())
            return;
        if (separateTime == null)
            return;
        int[] result = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        list.clear();

        playMultiSounds(result, separateTime);
    }

    /**
     * 如果当前soundPool空闲则依次播报多个声效
     *
     * @param list         声效资源ID集合
     * @param separateTime 两两声效之间播报间隔
     */
    public void playMultiSoundsIfIdle(ArrayList<Integer> list, long separateTime[]) {
//        Logger.i(Logger.DEBUG_TAG,"playMultiSoundsIfIdle-->getPreparedSoundQueue().size():"+getPreparedSoundQueue().size());
        if (getPreparedSoundQueue().size() > 0) {
            return;
        }
        playMultiSounds(list, separateTime);
    }

    /**
     * 停止播放所有的声效资源
     */
    private void stopAll() {
        Integer id;
        try {
            while ((id = getPlayedSoundQueue().poll()) != null) {
                getSoundPool().stop(id);
            }
            while ((id = getPreparedSoundQueue().poll()) != null) {
                getSoundPool().unload(id);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        getPlayedSoundQueue().clear();
        getPreparedSoundQueue().clear();

        if (controlSoundExecutor != null)
            getThreadPoolExecutor().shutdownNow();
        controlSoundExecutor = null;
    }

    /**
     * 依次播报多个声效
     *
     * @param list         声效资源路径集合
     * @param separateTime 两两声效之间播报间隔
     */
    public void playMultiSoundsByPath(ArrayList<String> list, long separateTime[]) {
        if ((list == null) || list.isEmpty())
            return;
        if (separateTime == null)
            return;
        String[] result = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        list.clear();

        playMultiSounds(result, separateTime);
    }

    /**
     * 依次播报多个声效
     *
     * @param resPaths     声效资源路径数组
     * @param separateTime 两两声效之间播报间隔
     */
    public void playMultiSounds(String resPaths[], long separateTime[]) {
        if ((resPaths == null) || (separateTime == null))
            return;
        if (resPaths.length != separateTime.length)
            return;
        if (!setPlayResources(resPaths, separateTime))
            return;
        for (String resPath : resPaths) {
            getSoundPool().load(resPath, 1);
        }
    }

    /**
     * 根据声效资源文件ID,获取在播放此声效时需要添加的时间间隔
     *
     * @param ResId 声效资源文件ID
     * @return 需要添加的时间间隔, 单位为毫秒
     */
    public int getTimeSpaceById(int ResId) {
        int time;
        switch (ResId) {
            case R.raw.female_run_have_sport://您已运动
            case R.raw.female_sport_pause://运动暂停
            case R.raw.female_sport_continue://运动继续
            case R.raw.female_sport_finish://运动结束
                time = 1500;
                break;
            case R.raw.female_hour://小时
            case R.raw.female_minute://分
                time = 700;
                break;
            case R.raw.female_run_last_km_use_time://最近一公里耗时
                time = 2000;
                break;
            case R.raw.female_consume://消耗
                time = 1500;
                break;
            case R.raw.female_calories://卡路里
                time = 1300;
                break;
            case R.raw.female_run_improve://恭喜你,你今天的成绩超越了上一次,别忘了做好拉伸
            case R.raw.female_descendvoice://速度有所下降哦,调整步频你可以做得更好
                time = 5500;
                break;
            case R.raw.female_run_slogan_voice3://有目标才会有动力
            case R.raw.female_run_slogan_voice4://保持体力补充能量
            case R.raw.female_run_slogan_voice6://喝口水继续加油
                time = 2500;
                break;
            case R.raw.female_run_decline://今天跑得不错,保持下去
            case R.raw.female_run_marathon_voice2://非常棒,你已经是一名合格的跑者了
            case R.raw.female_run_slogan_voice9://熬过最难的部分,成功就在你眼前
            case R.raw.female_run_guide_voice4://控制身体惯速,专注内心目标
            case R.raw.female_run_marathon_voice1://很好,你完全具备了准跑者的潜质
            case R.raw.female_run_guide_voice3://目标就在前方,加速也别太快
            case R.raw.female_run_guide_voice6://控制好节奏,超越自己,你可以
            case R.raw.female_run_slogan_voice5://放空自己,专注你的目标
            case R.raw.female_run_ascendvoice://你已经找到自己的节奏,保持下去
            case R.raw.female_run_slogan_voice1://抛开杂念,享受每一步
            case R.raw.female_run_slogan_voice2://体能开始消耗,喝口水加油
            case R.raw.female_run_slogan_voice8://挑战,只为成为更好的自己
            case R.raw.female_run_guide_voice5://要来点挑战吗?相信你的能量
            case R.raw.female_run_guide_voice2://专注呼吸、节奏,调整好步伐
                time = 3500;
                break;
            case R.raw.female_run_marathon_voice9://非常棒,你已经成功进级全马阵营
            case R.raw.female_run_static_voice://注意跑姿、摆臂,保持身体的运动速度
            case R.raw.female_run_slogan_voice7://越上新的台阶,世界变得不一样了
            case R.raw.female_run_guide_voice1://注意聆听身体的声音,速度会主动来找你
            case R.raw.female_run_marathon_voice4://非常棒,你完全具备完成半马的水平
            case R.raw.female_run_marathon_voice6://非常棒,你完全具备挑战全马资格
            case R.raw.female_run_marathon_voice7://非常棒,还有5公里你就能完成全马了
            case R.raw.female_run_marathon_voice3://非常棒,还有5公里你就能挑战半马了
            case R.raw.female_run_marathon_voice5://非常棒,还有5公里你就能挑战全马了
            case R.raw.female_incream_speed://热情不能带你到终点,控制速度
                time = 4500;
                break;
            case R.raw.female_second://秒
            case R.raw.female_km://公里
            case R.raw.female_kcal://大卡
            case R.raw.female_use_time://用时
            case R.raw.female_run_speed_target://当前配速
                time = 1000;
                break;
            case R.raw.female_0://0
            case R.raw.female_1://1
            case R.raw.female_2://2
            case R.raw.female_3://3
            case R.raw.female_4://4
            case R.raw.female_5://5
            case R.raw.female_6://6
            case R.raw.female_7://7
            case R.raw.female_8://8
            case R.raw.female_9://9
            case R.raw.female_10://10
            case R.raw.female_chinese_one://幺
            case R.raw.female_chinese_two://两
                time = 400;
                break;
            case R.raw.female_long_minute://分钟
                time = 600;
                break;
            case R.raw.female_countdown://3 2 1 go
                time = 3000;
                break;
            //region ==========================与心率语音相关=================================
            //在任一心率区间运动了一分钟后，
            case R.raw.female_hr_fat_burn_1_header://太给力了
            case R.raw.female_hr_aerobic_1_header://太棒了
            case R.raw.female_hr_anaerobic_1_header://不可思议
                time = 700;
                break;
            case R.raw.female_hr_max_1_header://oh my god,难以置信
                time = 1800;
                break;

            case R.raw.female_hr_have_burned://你已燃烧
                time = 1500;
                break;
            case R.raw.female_hr_aerobic_now_vo2max://当前最大摄氧量
                time = 1700;
                break;

            case R.raw.female_hr_enhancecardiomode_1://已进入强化心肺区间，
            case R.raw.female_hr_enhancecardiomode_3://累计强化心肺训练
            case R.raw.female_hr_enhancemode_1://已进入强化机能区间
            case R.raw.female_hr_maxhrrange_1://累计极限强度训练
                time = 2000;
                break;
            case R.raw.female_hr_adduptraining://累计心率区间训练
            case R.raw.female_hr_maxhrrange://已进入极限强度区间
            case R.raw.female_hr_custommode_1://已进入自定义区间
                time = 1800;
                break;
            case R.raw.female_hr_aerobic_now_vo2max_higher://比正常人平均值高
            case R.raw.female_hr_aerobic_now_vo2max_lower://比正常人平均值低
                time = 1700;
                break;
            case R.raw.female_hr_aerobic_percent://百分之
                time = 900;
                break;
            case R.raw.female_hr_current_heartrate://当前心率
            case R.raw.female_hr_toohigh://心率过高
            case R.raw.female_hr_fatburningmode_1://已进入燃脂区间
            case R.raw.female_hr_currentheart://当前心率
            case R.raw.female_hr_fatburningmode_3://累计燃脂训练
            case R.raw.female_hr_enhancemode_3://累计强化机能训练
                time = 1000;
                break;
            //endregion ==========================与心率语音相关=================================
            default:
                time = 800;
                break;
        }
        return time;
    }

}
