package com.fitmix.sdk.common.sound;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.service.PlayerService;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 音乐播放控制
 */
public class PlayerController {

    public static final String ACTION_INTENT = "com.fitmix.sdk.service.PlayerService";

    public static final String ACTION_WHAT = "ACTION_WHAT";
    /**
     * 音乐播放
     */
    public static final String ACTION_PLAY_MUSIC = "PLAY";
    /**
     * 停止播放
     */
    public static final String ACTION_STOP = "STOP";
    /**
     * 暂停播放
     */
    public static final String ACTION_PAUSE = "PAUSE";
    /**
     * 继续播放
     */
    public static final String ACTION_RESUME = "RESUME";
    /**
     * 从指定时间播放
     */
    public static final String ACTION_SEEK_TIME = "SEEK";
    /**
     * 加载音乐
     */
    public static final String ACTION_LOAD_MUSIC = "LOAD_MUSIC";
    /**
     * 切换音乐播放状态,(暂停-->播放 或者 播放-->暂停)
     */
    public static final String ACTION_SWITCH = "SWITCH";
    /**
     * 播放mix音乐中上一个音乐片段或者普通音乐快退
     */
    public static final String ACTION_PREV = "PREV";
    /**
     * 播放mix音乐中下一个音乐片段或者普通音乐快进
     */
    public static final String ACTION_NEXT = "NEXT";
    /**
     * 音频文件资源URL
     */
    public static final String KEY_URL = "URL";
    /**
     * 音频url的类型
     */
    public static final String URL_TYPE = "URL_TYPE";
    public static final int URL_TYPE_ONLINE = 10;//url类型为网络url
    public static final int URL_TYPE_LOCAL = 11;//url类型为本地临时文件路径
    public static final int URL_TYPE_LOCAL_TEMP = 12;//url类型为本地完整文件路径
    /**
     * 指定时间键值
     */
    public static final String KEY_SEEK_TIME = "TIME";

    /**
     * 播放模式,单曲循环
     */
    public static final int MODE_REPEAT_ONE = 0;
    /**
     * 播放模式,全部循环
     */
    public static final int MODE_REPEAT_ALL = 1;
    /**
     * 播放模式,随机播放
     */
    public static final int MODE_RANDOM = 2;

    private PlayerService playerService;//音乐播放服务
    private Music musicInfo;//当前在播放器的音乐信息
    private int playMode = MODE_REPEAT_ONE;//播放模式
    /**
     * 音乐播放器是否正在播放
     */
    private boolean isActionPlay = false;
    //    private boolean bMusicLoaded = false;
    private List<Music> musicList;//歌曲列表

    private static PlayerController instance;

    public PlayerService getPlayerService() {
        if (playerService == null) {
            init();
        }
        return playerService;
    }

    /**
     * 设置当前播放器播放的音乐信息
     *
     * @param music 音乐信息
     */
    public void setCurrentMusic(Music music) {
        if (music != null) {
            musicInfo = music;
            //getPlayerService().setMusicInfo(musicInfo);
        }
    }

    /**
     * 获取当前播放器播放的音乐信息
     */
    public Music getCurrentMusic() {
//        if (getPlayerService() == null)
//            return null;
//        return getPlayerService().getMusicInfo();
        return musicInfo;
    }

    private Context getContext() {
        return MixApp.getContext();
    }

    public static PlayerController getInstance() {
        if (instance == null) {
            synchronized (PlayerController.class) {
                if (instance == null) {
                    instance = new PlayerController();
                    instance.init();
                }
            }
            Logger.i(Logger.DEBUG_TAG, "PlayerController--->getInstance");
        }
        return instance;
    }

    private void init() {
        getContext().bindService(new Intent(getContext(), PlayerService.class),
                connection, Context.BIND_AUTO_CREATE);
    }

    private final ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            getPlayerService().setOnMusicCompleteListener(null);
            playerService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (name != null && !name.getClassName().equals(PlayerService.SERVICE_NAME))
                return;
            playerService = ((PlayerService.MyBinder) service).getService();
            if (playerService == null)
                return;
            isActionPlay = getPlayerService().isPlaying();
//            if (isActionPlay)
//                bMusicLoaded = true;

            getPlayerService()
                    .setOnMusicCompleteListener(new PlayerService.OnMusicCompleteListener() {

                        @Override
                        public void onMusicComplete() {//歌曲播放完成事件
//							Log.d(FitmixConstant.TAG, "OnMusicCompleteListener:" + playMode);
                            switch (playMode) {
                                case MODE_REPEAT_ONE:
                                    playMusic(getCurrentMusic(), true);
                                    break;
                                case MODE_REPEAT_ALL:
                                    nextMusic();
                                    break;
                                case MODE_RANDOM:
                                    randomMusic();
                                    break;
                            }
                        }
                    });
        }
    };

    /**
     * 获取播放模式
     * <p>MODE_REPEAT_ONE:单曲循环</p>
     * <p>MODE_REPEAT_ALL:列表循环</p>
     * <p>MODE_RANDOM:随机循环</p>
     */
    public int getPlayMode() {
        return playMode;
    }

    /**
     * 设置播放模式
     *
     * @param mode 播放模式,以下模式之一:
     *             <p>MODE_REPEAT_ONE:单曲循环</p>
     *             <p>MODE_REPEAT_ALL:列表循环</p>
     *             <p>MODE_RANDOM:随机循环</p>
     */
    public void setPlayMode(int mode) {
        this.playMode = mode;
    }

    /**
     * 播放下一段
     */
    public void nextSegment() {
        operateMusic(ACTION_NEXT);
    }

    /**
     * 播放上一段
     */
    public void prevSegment() {
        operateMusic(ACTION_PREV);
    }

    /**
     * 音乐播放器是否播放中
     *
     * @return true:播放中,false:未播放
     */
    public boolean getIsActionPlay() {
        return isActionPlay;
    }

    /**
     * 设置音乐播放器当前播放状态
     *
     * @param isActionPlay true:播放中,false:暂停中
     */
    public void setIsActionPlay(boolean isActionPlay) {
        this.isActionPlay = isActionPlay;
    }

    /**
     * 获取音乐是否播放中
     *
     * @return true:是, false:否
     */
    public boolean isMusicPlaying() {
        if (getPlayerService() == null)
            return false;
        return getPlayerService().isPlaying();
    }

    /**
     * 获取音乐时长
     *
     * @return 音乐时长, 单位为毫秒
     */
    public int getDuration() {
        if (getPlayerService() == null)
            return 0;
        return getPlayerService().getDuration();
    }

    /**
     * 设置播放器音量
     *
     * @param volume 音量
     */
    public void setVolume(float volume) {
        if (getPlayerService() == null)
            return;
        getPlayerService().setVolume(volume);
    }

    /**
     * 获取当前音乐播放时间位置
     *
     * @return 当前音乐播放位置, 单位毫秒
     */
    public int getCurrentPosition() {
        if (getPlayerService() == null)
            return 0;
        return getPlayerService().getCurrentPosition();
    }

    /**
     * 设置播放列表
     *
     * @param list 音乐播放列表
     */
    public void setPlayList(List<Music> list) {
        if ((musicList != null) && (list != null) && (list != musicList)) {
            musicList.clear();
            musicList = null;
        }
        this.musicList = list;
        if (musicList != null && musicList.size() > 0) {
            OperateMusicUtils.setMusicPlayingList(musicList);
        }
    }

    /**
     * 获取播放列表
     */
    public List<Music> getPlayList() {
        if (musicList == null) {
            musicList = new ArrayList<>();
        }
        return musicList;
    }

    /**
     * 播放音乐
     *
     * @param music 要播放的音乐
     * @param bPlay 是否播放,true:播放音乐,false:加载音乐
     */
    public void playMusic(Music music, boolean bPlay) {
        if (music == null)
            return;
        OperateMusicUtils.setPlayingMusic(music);//设置播放音乐
        Intent intent = new Intent(getContext(), PlayerService.class);
        intent.setAction(ACTION_INTENT);
        intent.putExtra(ACTION_WHAT, bPlay ? ACTION_PLAY_MUSIC
                : ACTION_LOAD_MUSIC);
        String url = music.getUrl();
        int urlType = URL_TYPE_ONLINE;
        if (music.getLocalFlag() == 1) {//本地歌曲
            urlType = URL_TYPE_LOCAL;
        }
        String sLocalFile = FitmixUtil.getLocalFilePath(music.getUrl(),
                music.getId(), Config.DOWNLOAD_FORMAT_MUSIC);
        if ((sLocalFile != null) && (!sLocalFile.isEmpty())) {
            File file = new File(sLocalFile);
            if (file.exists()) {
                url = sLocalFile;
                urlType = URL_TYPE_LOCAL;
            } else if (!FitmixUtil.checkNetworkStateForMusic(music) && music.getLocalFlag() == 0) {//无网络情况下
                if (FitmixUtil.checkMusicDownloadParamValid(FitmixUtil.getTempMusicPath(music), true)) {//临时文件可播放情况下
                    url = sLocalFile + ".tmp";
                    urlType = URL_TYPE_LOCAL_TEMP;
                }
            }
        }
        intent.putExtra(URL_TYPE, urlType);//设置url类型为网络url
        intent.putExtra(KEY_URL, url);
        setCurrentMusic(music);
        getContext().startService(intent);
        setIsActionPlay(bPlay);
//        bMusicLoaded = true;
        //加入到最近播放
        addMusicToRecentList(music);
        //通知播放歌曲
        notifyChange(Config.MUSIC_PLAY_START);
        //每一次播放歌曲都要记录下来,统计到友盟
        sendUmengInfoAboutMusicPlay(music);
        uploadMusicAudition();
    }

    /**
     * 上传音乐收听数量+1
     */
    private void uploadMusicAudition() {
        getHandler().removeCallbacks(uploadMusicAuditionTask);
        getHandler().postDelayed(uploadMusicAuditionTask, 1000 * 10);

    }

    /**
     * 在数据库最近播放列表中添加音乐信息
     */
    private void addMusicToRecentList(Music music) {
        OperateMusicUtils.insertMusic(music, Config.LIST_TYPE_RECENT);
    }

    protected MyConfig getMyConfig() {
        return MyConfig.getInstance();
    }

    private WeakHandler mHandler;

    private Runnable uploadMusicAuditionTask = new Runnable() {
        @Override
        public void run() {
            if (getCurrentMusic() == null) return;
            MusicDataManager.getInstance().uploadMusicAudition(getCurrentMusic().getId(), true);//发送网络请求
            Music music = OperateMusicUtils.getMusicById(getCurrentMusic().getId());
            if (music != null) {
                music.setAuditionCount(music.getAuditionCount() + 1);
                OperateMusicUtils.insertMusic(music, Config.LIST_TYPE_SCENE);//把本地试听数量加一
            }
        }
    };

    public WeakHandler getHandler() {
        if (mHandler == null)
            mHandler = new WeakHandler(getContext());
        return mHandler;
    }

    /**
     * 关于歌曲播放的友盟统计
     *
     * @param music
     */
    public void sendUmengInfoAboutMusicPlay(Music music) {
        if (music != null) {
            UmengAnalysisHelper.getInstance().musicPlayReportPlus(getContext(), "音乐播放", music);
        }

//        userBehaviorStat(music);
//
//        UmengAnalysisHelper.getInstance().musicOnlinePlayReport(getContext(),
//                music.getName(),
//                music.getAuthor(),
//                music.getGenre(),
//                String.valueOf(music.getTrackLength()),
//                music.getScene());//友盟音乐在线播放统计
    }

//    /**
//     * 用户音乐播放行为报告
//     */
//    private void userBehaviorStat(Music music) {
//        if (music == null) return;
//        String sRequest = getRequestSynthesizer().getUserBehaviorString(getMyConfig()
//                .getPersonInfo().getId(), music.getId(), 1, 0, 0);
//        if (music.getLocalFlag() == 1) {
//            return;
//        }
//        if (checkMusicExist(music)) {
//            return;
//        }
//        sendNetRequest(sRequest);
//    }

//    /**
//     * 检查音乐是否存在
//     *
//     * @return
//     */
//    private boolean checkMusicExist(Music music) {
//        if (music == null) return false;
//        return FitmixUtil.isExistCacheFile(music.getUrl(), music.getId(),
//                Config.DOWNLOAD_FORMAT_MUSIC);
//    }

    /**
     * 播放音乐列表指定下标的音乐
     *
     * @param iIndex 音乐列表中的下标,以0为开始
     * @param bPlay  是否播放,true:播放音乐,false:加载音乐
     */
    public Music playListByIndex(int iIndex, boolean bPlay) {
        if ((iIndex < 0) || (iIndex >= getPlayList().size()))
            return null;
        Music music = getPlayList().get(iIndex);
        playMusic(music, bPlay);
        return music;
    }

    /**
     * 播放音乐列表下一首音乐
     */
    public Music nextMusic() {
        Music music = getCurrentMusic();
        if ((music == null) || (getPlayList().size() <= 0)) {
            return null;
        }
        int position = getPlayList().indexOf(music);
        position = (position + 1) % getPlayList().size();
        return playListByIndex(position, true);
    }

    /**
     * 播放音乐列表随机播放
     */
    public void randomMusic() {
        int iIndex = 0;
        if (getPlayList().size() > 1) {
            iIndex = (int) (Math.random() * getPlayList()
                    .size());
            if (iIndex < 0)
                iIndex = -iIndex;
        }
        Music music = getPlayList().get(iIndex);
        playMusic(music, true);

    }

    /**
     * 播放音乐列表上一首音乐
     */
    public Music prevMusic() {
        Music music = getCurrentMusic();
        if ((music == null) || (getPlayList().size() <= 0)) {
            return null;
        }
        int position = getPlayList().indexOf(music);
        position = (position - 1 + getPlayList().size()) % getPlayList().size();
        return playListByIndex(position, true);
    }

    /**
     * 播放音乐列表第一首音乐
     */
    public Music playHeadOfList(boolean bPlay) {
        return playListByIndex(0, bPlay);
    }

    /**
     * 根据操作类型不同发送不同的广播
     *
     * @param what
     */
    private void notifyChange(String what) {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
        Intent intent = new Intent();
        intent.setAction(what);
        lbm.sendBroadcast(intent);
    }

    //region ==============================音乐播放控制相关====================================

    /**
     * 向音乐播放服务发送指令
     *
     * @param sAction 播放指令
     */
    private void operateMusic(String sAction) {
        if (sAction == null || sAction.isEmpty())
            return;
        Intent intent = new Intent(getContext(), PlayerService.class);
        intent.setAction(ACTION_INTENT);
        intent.putExtra(ACTION_WHAT, sAction);
        getContext().startService(intent);
    }

    /**
     * 停止播放音乐
     */
    public void stopMusic() {
//        if (!bMusicLoaded)
//            return;
        isActionPlay = false;
//        bMusicLoaded = false;
        musicInfo = null;
        operateMusic(ACTION_STOP);
    }

    /**
     * 暂停播放音乐
     */
    public void pauseMusic() {
        isActionPlay = false;
        operateMusic(ACTION_PAUSE);
    }

    /**
     * 继续播放音乐
     */
    public void resumeMusic() {
        isActionPlay = true;
        operateMusic(ACTION_RESUME);
    }

    /**
     * 播放mix音乐中下一个音乐片段
     */
    public void playNextSegment() {
        operateMusic(ACTION_NEXT);
    }

    /**
     * 播放mix音乐中上一个音乐片段
     */
    public void playPrevSegment() {
        operateMusic(ACTION_PREV);
    }

    //endregion ==============================音乐播放控制相关====================================

    public void playNextSong() {
        nextMusic();
    }

    public void playPrevSong() {
        prevMusic();
    }

    /**
     * 停止音乐播放并销毁音乐播放器
     */
    public void stopPlayer() {
        if (getPlayerService() == null) return;
        stopMusic();
        getPlayerService().setOnMusicCompleteListener(null);

        getContext().unbindService(connection);
        getContext().stopService(new Intent(getContext(), PlayerService.class));
        playerService = null;
    }

    public void seekToTime(int time) {
        Intent intent = new Intent(getContext(), PlayerService.class);
        intent.setAction(ACTION_INTENT);
        intent.putExtra(ACTION_WHAT, ACTION_SEEK_TIME);
        intent.putExtra(KEY_SEEK_TIME, time);
        getContext().startService(intent);
    }

}
