package com.fitmix.sdk.common.maps;

import com.amap.api.maps.model.LatLng;
import com.amap.api.navi.AMapNavi;
import com.amap.api.navi.AMapNaviListener;
import com.amap.api.navi.enums.NaviType;
import com.amap.api.navi.model.AMapLaneInfo;
import com.amap.api.navi.model.AMapNaviCameraInfo;
import com.amap.api.navi.model.AMapNaviCross;
import com.amap.api.navi.model.AMapNaviInfo;
import com.amap.api.navi.model.AMapNaviLocation;
import com.amap.api.navi.model.AMapNaviTrafficFacilityInfo;
import com.amap.api.navi.model.AMapServiceAreaInfo;
import com.amap.api.navi.model.AimLessModeCongestionInfo;
import com.amap.api.navi.model.AimLessModeStat;
import com.amap.api.navi.model.NaviInfo;
import com.amap.api.navi.model.NaviLatLng;
import com.autonavi.tbt.TrafficFacilityInfo;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.Logger;

/**
 * 高德导航管理器
 */

public class AMapNavManager {
    private AMapNavi aMapNavi;//高德地图导航
    /**
     * 导航是否初始化成功
     */
    private boolean mInitSuccess;
    /**
     * 导航开始点
     */
    private NaviLatLng mNavStartPoint;
    /**
     * 导航结束点
     */
    private NaviLatLng mNavEndPoint;

    private OnAMapNavListener onAMapNavListener;

    public AMapNavManager() {
        if (aMapNavi == null) {
            aMapNavi = AMapNavi.getInstance(MixApp.getContext());
        }
        aMapNavi.addAMapNaviListener(mapNavListener);
    }

    /**
     * 高德地图导航事件回调
     */
    public interface OnAMapNavListener {
        /**
         * 导航初始化成功,开始计算导航路径
         */
        void navInitSuccess();

//        /**
//         * 计算导航路径成功
//         */
//        void calculateRouteSuccess();

        /**
         * 到达目的地事件
         */
        void arriveDestination();

    }

    /**
     * 高德地图导航事件
     */
    private AMapNaviListener mapNavListener = new AMapNaviListener() {
        @Override
        public void onInitNaviFailure() {

        }

        @Override
        public void onInitNaviSuccess() {
            //初始化成功后,调用路径规划方法计算路径
            //aMapNavi.calculateWalkRoute(new NaviLatLng(39.92, 116.43), new NaviLatLng(39.92, 116.53));
            mInitSuccess = true;
            if (onAMapNavListener != null) {
                onAMapNavListener.navInitSuccess();
            }
        }

        @Override
        public void onStartNavi(int i) {
            //开始导航回调
        }

        @Override
        public void onTrafficStatusUpdate() {

        }

        @Override
        public void onLocationChange(AMapNaviLocation aMapNaviLocation) {
            //当前位置回调
        }

        @Override
        public void onGetNavigationText(int i, String s) {

        }

        @Override
        public void onGetNavigationText(String s) {

        }

        @Override
        public void onEndEmulatorNavi() {
            //结束模拟导航
        }

        @Override
        public void onArriveDestination() {
            if (onAMapNavListener != null) {//通知
                onAMapNavListener.arriveDestination();
            }
        }

        @Override
        public void onCalculateRouteFailure(int errorCode) {
            //路线计算失败
            Logger.e("dm", "--------AMapNavManager-->onCalculateRouteFailure--------");
            Logger.i("dm", "路线计算失败：错误码=" + errorCode + ",Error Message= " + getError(errorCode));
            Logger.i("dm", "错误码详细链接见：http://lbs.amap.com/api/android-navi-sdk/guide/tools/errorcode/");
            Logger.e("dm", "--------------------------------------------");
//            Toast.makeText(this, "errorCode：" + errorCode + ",Message：" + getError(errorCode), Toast.LENGTH_LONG).show();
        }

        @Override
        public void onReCalculateRouteForYaw() {
            //偏航后重新计算路线回调
        }

        @Override
        public void onReCalculateRouteForTrafficJam() {
            //拥堵后重新计算路线回调
        }

        @Override
        public void onArrivedWayPoint(int i) {
            //到达途径点
        }

        @Override
        public void onGpsOpenStatus(boolean b) {
            //GPS开关状态回调
        }

        @Override
        public void onNaviInfoUpdate(NaviInfo naviInfo) {
            //导航过程中的信息更新，请看NaviInfo的具体说明
        }

        @Override
        public void onNaviInfoUpdated(AMapNaviInfo aMapNaviInfo) {

        }

        @Override
        public void updateCameraInfo(AMapNaviCameraInfo[] aMapNaviCameraInfos) {

        }

        @Override
        public void onServiceAreaUpdate(AMapServiceAreaInfo[] aMapServiceAreaInfos) {

        }

        @Override
        public void showCross(AMapNaviCross aMapNaviCross) {

        }

        @Override
        public void hideCross() {

        }

        @Override
        public void showLaneInfo(AMapLaneInfo[] aMapLaneInfos, byte[] bytes, byte[] bytes1) {
            //显示车道信息
        }

        @Override
        public void hideLaneInfo() {
            //隐藏车道信息
        }

        @Override
        public void onCalculateRouteSuccess(int[] ints) {
            //当路线规划成功时，会进 onCalculateRouteSuccess 回调
            if (aMapNavi != null) {//开始导航
                aMapNavi.startNavi(NaviType.GPS);
            }
            Logger.i(Logger.DEBUG_TAG, "AMapNavManager-->onCalculateRouteSuccess..");
//            if (onAMapNavListener != null) {//通知
//                onAMapNavListener.calculateRouteSuccess();
//            }
        }

        @Override
        public void notifyParallelRoad(int i) {

        }

        @Override
        public void OnUpdateTrafficFacility(AMapNaviTrafficFacilityInfo aMapNaviTrafficFacilityInfo) {
            //更新交通设施信息
        }

        @Override
        public void OnUpdateTrafficFacility(AMapNaviTrafficFacilityInfo[] aMapNaviTrafficFacilityInfos) {
            //更新交通设施信息
        }

        @Override
        public void OnUpdateTrafficFacility(TrafficFacilityInfo trafficFacilityInfo) {
            //更新交通设施信息
        }

        @Override
        public void updateAimlessModeStatistics(AimLessModeStat aimLessModeStat) {

        }

        @Override
        public void updateAimlessModeCongestionInfo(AimLessModeCongestionInfo aimLessModeCongestionInfo) {

        }

        @Override
        public void onPlayRing(int i) {

        }
    };

    /**
     * 根据onCalculateRouteFailure返回的错误码,获取相应的错误信息
     */
    private String getError(int errorInfo) {
        switch (errorInfo) {
            case -1:
                return "路径计算失败，在导航过程中调用calculateDriveRoute方法导致的失败，导航过程中只能用reCalculate方法进行路径计算";
            case 1:
                return "路径计算成功";
            case 2:
                return "网络超时或网络失败,请检查网络是否通畅，如网络没问题,查看Logcat输出是否出现鉴权错误信息，如有，说明SHA1与KEY不对应导致";
            case 3:
                return "路径规划起点经纬度不合法,请选择国内坐标点，确保经纬度格式正常";
            case 4:
                return "协议解析错误,请稍后再试";
            case 6:
                return "路径规划终点经纬度不合法,请选择国内坐标点，确保经纬度格式正常";
            case 7:
                return "算路服务端编码失败";
            case 10:
                return "起点附近没有找到可行道路,请对起点进行调整";
            case 11:
                return "终点附近没有找到可行道路,请对终点进行调整";
            case 12:
                return "途经点附近没有找到可行道路,请对途经点进行调整";
            case 13:
                return "key鉴权失败，请仔细检查key绑定的sha1值与apk签名sha1值是否对应，或通过;高频问题查找相关解决办法";
            case 14:
                return "请求的服务不存在,请稍后再试";
            case 15:
                return "请求服务响应错误,请检查网络状况，稍后再试";
            case 16:
                return "无权限访问此服务,请稍后再试";
            case 17:
                return "请求超出配额";
            case 18:
                return "请求参数非法,请检查传入参数是否符合要求";
            case 20:
                return "起点/终点/途经点的距离太长(距离>6000km)";
            case 21:
                return "途经点经纬度不合法,请选择国内坐标点，确保经纬度格式正常";
            case 22:
                return "MD5安全码验证未通过";
            case 23:
                return "单位时间内访问过于频繁";
            case 24:
                return "平台不匹配";
            case 25:
                return "规划点（包括起点、终点、途经点）不在中国陆地范围内";
            case 26:
                return "起点终点距离过长";

            default:
                return "未知错误";
        }
    }

    /**
     * 设置高德地图导航事件回调
     */
    public void setOnAMapNavListener(OnAMapNavListener listener) {
        onAMapNavListener = listener;
    }

    /**
     * 设置导航开始点和结束点
     *
     * @param start 起始点经纬度,要求在国内
     * @param end   结束点经纬度,要求在国内
     */
    public void setNavStartAndEndPoint(LatLng start, LatLng end) {
        if (start != null && end != null) {
            mNavStartPoint = new NaviLatLng(start.latitude, start.longitude);
            mNavEndPoint = new NaviLatLng(end.latitude, end.longitude);
            if (aMapNavi != null && mInitSuccess) {//重新计算路径,走路比较合适,开始有可能没有路,计算会失败?
                aMapNavi.calculateWalkRoute(mNavStartPoint, mNavEndPoint);
            }
        }

    }

    /**
     * 停止导航
     */
    public void stopNavigation() {
        if (aMapNavi != null) {
            aMapNavi.stopNavi();
            aMapNavi.removeAMapNaviListener(mapNavListener);
            aMapNavi.destroy();
        }
        aMapNavi = null;
        mInitSuccess = false;
    }


}
