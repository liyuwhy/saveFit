package com.fitmix.sdk.common.maps;

import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;

/**
 * 运动轨迹在高德地图上显示时对应的镜头信息
 */

public class TrailCameraInfo {

    private LatLng mTrailCenter;//轨迹中心点经纬度
    private LatLngBounds mTrailBounds;//轨迹显示范围
    private int mPaddingLeft;//轨迹最左边点与地图边缘的距离,单位为像素
    private int mPaddingTop;//轨迹最上边点与地图边缘的距离,单位为像素
    private int mPaddingRight;//轨迹最右边点与地图边缘的距离,单位为像素
    private int mPaddingBottom;//轨迹最下边点与地图边缘的距离,单位为像素


    public LatLng getTrailCenter() {
        return mTrailCenter;
    }

    public void setTrailCenter(LatLng trailCenter) {
        this.mTrailCenter = trailCenter;
    }

    public LatLngBounds getTrailBounds() {
        return mTrailBounds;
    }

    public void setTrailBounds(LatLngBounds trailBounds) {
        this.mTrailBounds = trailBounds;
    }

    public int getPaddingLeft() {
        return mPaddingLeft;
    }

    public void setPaddingLeft(int paddingLeft) {
        this.mPaddingLeft = paddingLeft;
    }

    public int getPaddingTop() {
        return mPaddingTop;
    }

    public void setPaddingTop(int paddingTop) {
        this.mPaddingTop = paddingTop;
    }

    public int getPaddingRight() {
        return mPaddingRight;
    }

    public void setPaddingRight(int paddingRight) {
        this.mPaddingRight = paddingRight;
    }

    public int getPaddingBottom() {
        return mPaddingBottom;
    }

    public void setPaddingBottom(int paddingBottom) {
        this.mPaddingBottom = paddingBottom;
    }
}
