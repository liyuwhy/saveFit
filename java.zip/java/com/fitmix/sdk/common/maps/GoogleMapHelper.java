package com.fitmix.sdk.common.maps;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.WindowManager;

import com.amap.api.location.AMapLocation;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.TrailInfo;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;


/**
 * 谷歌地图帮助类,负责地图显示,画轨迹,画标志等
 */
public class GoogleMapHelper {
    private final double SPEED_SLOW = 0;
    private final double SPEED_FAST = 6;
    private final int REFRESH_SPACE_TIME = 10 * 1000;

    private MapView mapView;
    private GoogleMap google_map;

    private AMapLocationManager locationManager;
    private GroundOverlay darkLayout;//地图暗色遮罩
    private BitmapDescriptor mMarkFlag;//标识点图标

    private int MarkFlag_width;
    private int MarkFlag_height;

    private Circle mLocatePointCenter;//定位中心点圆圈
    private Circle mLocatePointRange;//定位点80米范围圆圈
    private boolean bEnableLocate;
    private boolean bLocateOnlyOnce;

    private long lastLocateTime;
    private int iLocateIndex;
    private int colorPause;
    private int colorCenter;//定位中心点圆圈填充色
    private int colorRadius;//定位点80米范围圆圈填充色
    private int iScreenWidth;//屏幕像素宽
    private int iScreenHeight;//屏幕像素高
    private int iTrailLineWidth;//轨迹线条宽度

    private Context mContext;

    public interface GoogleMapReady {
        void onReady();
    }

    private GoogleMapReady googleMapReady;

    /**
     * 设置google map ready事件回调
     */
    public void setGoogleMapReady(GoogleMapReady googleMapReady) {
        this.googleMapReady = googleMapReady;
    }

    private AMapLocationManager.OnAMapLocationChangeListener locationChangeListener = new AMapLocationManager.OnAMapLocationChangeListener() {

        @Override
        public void onLocationChange(AMapLocation aLocation) {
            if ((aLocation == null) || (google_map == null))
                return;
            if ((aLocation.getLatitude() == 0)
                    && (aLocation.getLongitude() == 0))
                return;
            LatLng pos = new LatLng(aLocation.getLatitude(),
                    aLocation.getLongitude());
            if (iLocateIndex <= 0) {
                if (google_map != null) {
                    google_map.animateCamera(
                            CameraUpdateFactory.newCameraPosition(new CameraPosition(
                                    pos, Config.MAP_CAMERA_ZOOM, 0, 0)), 1000, null);

                }
                forceShowLocationPoint(pos);
                if (bLocateOnlyOnce)
                    setEnableLocate(false);

                if (aLocation.getAccuracy() > Config.GPS_AVAILABLE_ACCURACY)
                    return;
                if (aLocation.getSpeed() == 0)
                    return;
            }

            long now = System.currentTimeMillis();//Calendar.getInstance().getTimeInMillis();
            if (now - lastLocateTime < REFRESH_SPACE_TIME)
                return;
            float zoom = Config.MAP_CAMERA_ZOOM;
            if (google_map != null) {
                zoom = google_map.getCameraPosition().zoom;
            }

            if (iLocateIndex <= 0)
                zoom = Config.MAP_CAMERA_ZOOM;
            iLocateIndex++;
            lastLocateTime = now;

            if (google_map != null) {
                google_map.animateCamera(
                        CameraUpdateFactory.newCameraPosition(new CameraPosition(
                                pos, zoom, 0, 0)), 1000, null);
            }

            forceShowLocationPoint(pos);
        }

    };

    private void clear() {
        mContext = null;
        mapView = null;
        if (google_map != null) {
            google_map.clear();
        }
        google_map = null;
        locationManager = null;
        if (darkLayout != null)
            getDarkLayer().remove();
        darkLayout = null;
        mMarkFlag = null;
        mLocatePointCenter = null;
        mLocatePointRange = null;
        bEnableLocate = false;
        bLocateOnlyOnce = false;

        colorPause = 0;
        colorCenter = 0;
        colorRadius = 0;
        iLocateIndex = 0;
        lastLocateTime = 0;
    }

    /**
     * 创建google地图帮助
     *
     * @param mapView       谷歌地图view
     * @param bEnableLocate 是否需要定位,true:是,false:否
     */
    public GoogleMapHelper(MapView mapView, boolean bEnableLocate) {
        clear();
        this.bEnableLocate = bEnableLocate;
        this.mapView = mapView;
        init(MixApp.getContext());
    }

    /**
     * 地图初始化配置
     *
     * @param context 上下文
     */
    public void init(Context context) {
        if (context == null)
            return;
        mContext = context;
        colorPause = 0xFF808080;
        getMarkBitmap();

        iTrailLineWidth = (int) context.getResources().getDimension(
                R.dimen.fitmix_line_width);
        colorCenter = 0xFF99CC33;
        colorRadius = 0x20000000;

        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getMetrics(dm);
        iScreenWidth = dm.widthPixels;
        iScreenHeight = dm.heightPixels;
    }

    private Bitmap getMarkBitmap() {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(mContext.getResources(), R.drawable.run_flag, opts);
        opts.inSampleSize = 1;
        opts.inJustDecodeBounds = false;
        Bitmap mBitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.run_flag, opts);
        MarkFlag_width = opts.outWidth;
        MarkFlag_height = opts.outHeight;
        return mBitmap;
    }

    /**
     * 获取谷歌地图实例
     */
    public void getAMap() {
        if ((google_map == null) && (mapView != null)) {
//            google_map = mapView.getMap();
            mapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    google_map = googleMap;
                    setupMap();
                    if (googleMapReady != null) {
                        googleMapReady.onReady();
                    }
                }
            });
        }
    }

    /**
     * 查看手机是否安装了显示google地图所需要的google play service
     *
     * @return true:已安装,false:没有安装
     */
    public boolean isGooglePlayServiceInstalled(Context context) {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(context);
        return resultCode == ConnectionResult.SUCCESS;
    }


    /**
     * 获取谷歌地图View
     */
    public MapView getMapView() {
        return mapView;
    }

    //region =========================需要与Activity或Fragment生命周期绑定的方法======================

    /**
     * 地图创建,注意:一定要在Activity或Fragment onCreate方法中调用
     */
    public void onCreate(Bundle savedInstanceState) {
        if (!isMapViewValid())
            return;
        mapView.onCreate(savedInstanceState);
        getAMap();
    }

    /**
     * 暂停地图绘制,注意:一定要在Activity或Fragment onPause方法中调用
     */
    public void onPause() {
        if (!isMapViewValid())
            return;
        mapView.onPause();
    }

    /**
     * 恢复地图绘制,注意:一定要在Activity或Fragment onResume方法中调用
     */
    public void onResume() {
        if (!isMapViewValid())
            return;
        mapView.onResume();
    }

    /**
     * 地图销毁,注意:一定要在Activity或Fragment onDestroy方法中调用
     */
    public void onDestroy() {

        if (getLocationManager() != null) {
            getLocationManager().setOnAMapLocationChangeListener(null);
            getLocationManager().stopLocate();
        }
        locationChangeListener = null;
        locationManager = null;
        if (mapView != null) {
            mapView.onDestroy();
            mapView.removeAllViews();
        }
        clear();
    }

    /**
     * 地图状态保存,注意:如果需要保持地图状态则一定要在Activity或Fragment onSaveInstanceState方法中调用
     */
    public void onSaveInstanceState(Bundle outState) {
        if (!isMapViewValid())
            return;
        mapView.onSaveInstanceState(outState);
    }

    //endregion =========================需要与Activity或Fragment生命周期绑定的方法======================

    private boolean isMapViewValid() {
        return (mapView != null);
    }

    private void setupMap() {
        if (!isMapViewValid())
            return;
        try {
            MapsInitializer.initialize(mContext);
            mapView.setDrawingCacheEnabled(true);
            if (google_map != null) {
                google_map.getUiSettings().setZoomControlsEnabled(false);//隐藏地图缩放控件
            }
            mMarkFlag = BitmapDescriptorFactory.fromResource(R.drawable.run_flag);
            //   google_map = mapView.getMap();
            mapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googlemap) {
                    google_map = googlemap;
                    google_map.setTrafficEnabled(true);
                    google_map.getUiSettings().setZoomControlsEnabled(false);
                    google_map.getUiSettings().setCompassEnabled(false);
                    setEnableLocate(bEnableLocate);
                    if (googleMapReady != null) {
                        googleMapReady.onReady();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private AMapLocationManager getLocationManager() {
        if (locationManager == null)
            locationManager = new AMapLocationManager();
        return locationManager;
    }

    private GroundOverlay getDarkLayer() {
        return darkLayout;
    }

    private BitmapDescriptor getMarkFlag() {
        return mMarkFlag;
    }

    /**
     * 设置是否开启定位
     *
     * @param bEnableLocate true:是,false:否
     */
    private void setEnableLocate(boolean bEnableLocate) {
        this.bEnableLocate = bEnableLocate;
        if (bEnableLocate) {
            getLocationManager().startLocate();
            getLocationManager().setOnAMapLocationChangeListener(locationChangeListener);

        } else if (locationManager != null) {
            getLocationManager().stopLocate();
            getLocationManager().setOnAMapLocationChangeListener(null);
        }
    }

    /**
     * 获取定位点圆圈
     *
     * @param point  原圆圈
     * @param pos    经纬度点
     * @param radius 圆圈半径
     * @param color  圆圈填充色
     * @param zIndex 圆圈在地图上的显示层次,数字越大显示在上面
     */
    private Circle setLocatePoint(Circle point, LatLng pos, double radius,
                                  int color, int zIndex) {
        if (google_map == null)
            return null;

        if (point == null) {
            CircleOptions op = new CircleOptions();
            op.center(pos);
            op.fillColor(color);
            op.radius(radius);
            op.strokeWidth(0);
            op.zIndex(zIndex);
            op.strokeColor(color);
            return google_map.addCircle(op);
        } else {
            point.setCenter(pos);
            return point;
        }

    }

    /**
     * 根据速度获取轨迹线条颜色
     *
     * @param dSpeed 速度
     * @param bPause 是否运动暂停状态
     */
    private int getColorBySpeed(double dSpeed, boolean bPause) {
        if (bPause)
            return colorPause;
        if (dSpeed <= SPEED_SLOW)
            return 0xFF00FF00;//纯绿
        else if (dSpeed >= SPEED_FAST)
            return 0xFFFF0000;//纯红
        else if (dSpeed <= (SPEED_FAST + SPEED_SLOW) / 2) {
            int g = (int) (0xFF * (SPEED_FAST - dSpeed) / (SPEED_FAST - SPEED_SLOW));
            return 0xFFFF0000 | (g << 8);
        } else {
            int r = (int) (0xFF * (dSpeed - SPEED_SLOW) / (SPEED_FAST - SPEED_SLOW));
            return 0xFF00FF00 | (r << 16);
        }
    }


    /**
     * 添加暗色遮罩图层
     *
     * @param point 经纬度中心点
     */
    private void addDarkOverLay(LatLng point) {
        if (google_map == null || point == null)
            return;

        if (darkLayout != null) {
            getDarkLayer().remove();
        }
        darkLayout = null;
        GroundOverlayOptions overlayOptions = new GroundOverlayOptions();

        Bitmap bitmap = Bitmap.createBitmap(50, 50, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(0x32000000);
        canvas.save();
        canvas.restore();
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory
                .fromBitmap(bitmap);

        overlayOptions.anchor(0.5F, 0.5F);
        overlayOptions.zIndex(4.0F);
        overlayOptions.positionFromBounds(getWholeWordBounds(point));
        overlayOptions.image(bitmapDescriptor);
        if (bitmap != null)
            bitmap.recycle();
        if (google_map != null) {
            darkLayout = google_map.addGroundOverlay(overlayOptions);
        }
    }

    /**
     * 在地图上添加标识点
     *
     * @param point 标识点位置
     * @param sText 标识点文字
     */
    private void addMarkFlag(LatLng point, String sText) {
        if (google_map == null || sText == null || point == null
                || getMarkFlag() == null)
            return;
        double dRatioW = iScreenWidth * 2.0 / 3 / 720;
        double dRatioH = iScreenHeight * 2.0 / 3 / 1280;
        float dRatio = 1;
        if (iScreenWidth <= 1280) dRatio = (float) (dRatioW > dRatioH ? dRatioH : dRatioW);

        int width = (int) (MarkFlag_width * dRatio);
        int height = (int) (MarkFlag_height * dRatio);

        Bitmap bitmap = Bitmap.createBitmap(width,
                height, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();

        paint.setAntiAlias(true);
        Matrix matrix = new Matrix();
        matrix.postScale(dRatio, dRatio);
        canvas.drawBitmap(getMarkBitmap(), matrix, paint);

        paint.setColor(0xFFFFFFFF);
        paint.setTextSize((int) (36 * dRatio));
        float textWidth = paint.measureText(sText);

        canvas.drawText(sText, (width - textWidth) / 2,
                height / 2 + 2, paint);
        canvas.save();
        canvas.restore();
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory
                .fromBitmap(bitmap);

        MarkerOptions markFlag = new MarkerOptions();
        markFlag.icon(bitmapDescriptor).position(point);

        if (google_map != null) {
            google_map.addMarker(markFlag);//out of memory
        }
    }

    /**
     * 根据中心点获取一个很大的矩形区域
     *
     * @param center 经纬度中心点
     */
    private LatLngBounds getWholeWordBounds(LatLng center) {
        if (center == null)
            return null;
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        LatLng point1 = new LatLng(center.latitude + 10, center.longitude + 10);
        builder.include(point1);
        LatLng point2 = new LatLng(center.latitude - 10, center.longitude - 10);
        builder.include(point2);
        LatLng point3 = new LatLng(center.latitude - 10, center.longitude + 10);
        builder.include(point3);
        LatLng point4 = new LatLng(center.latitude + 10, center.longitude - 10);
        builder.include(point4);
        return builder.build();
    }

    /**
     * 获取轨迹的范围和轨迹中心点
     *
     * @param list   轨迹点集合
     * @param result 存储中心点信息的数组,index 0:lat,index 1:lng,index 2: zoom
     * @return true:成功,false失败
     */
    private boolean getTrailLineRect(List<TrailInfo> list,
                                     double[] result) {
        if (list == null || (list.size() == 0) || (result == null))
            return false;
        double left, top, right, bottom;
        left = right = list.get(0).getLng();
        top = bottom = list.get(0).getLat();
        int size = list.size();

        double lat, lng;
        for (int i = 1; i < size; i++) {
            lng = list.get(i).getLng();
            lat = list.get(i).getLat();
            if (lng < left)
                left = lng;
            else if (lng > right)
                right = lng;

            if (lat < top)
                top = lat;
            else if (lat > bottom)
                bottom = lat;
        }
        result[0] = (top + bottom) / 2;
        result[1] = (left + right) / 2;

        double distance = TrailManager.getShortDistance(left, top, right, bottom);
        final int DISTANCE_MIN = 300;
        final int DISTANCE_MAX = 10000;
        double zoom;
        if (distance <= DISTANCE_MIN)
            zoom = Config.MAP_CAMERA_ZOOM_MAX;
        else if (distance >= DISTANCE_MAX)
            zoom = Config.MAP_CAMERA_ZOOM_MIN;
        else
            zoom = (float) (Config.MAP_CAMERA_ZOOM_MAX + (Config.MAP_CAMERA_ZOOM_MIN - Config.MAP_CAMERA_ZOOM_MAX)
                    * (distance - DISTANCE_MIN) / (DISTANCE_MAX - DISTANCE_MIN));
        result[2] = zoom;
        return true;
    }

    //region ===============================对外公共方法======================================

    /**
     * 清除地图所有标识
     */
    public void clearTrail() {
        if (google_map != null) {
            google_map.clear();
        }
        mLocatePointCenter = null;
        mLocatePointRange = null;
    }

    /**
     * 在原有的地图上再添加轨迹
     *
     * @param list           轨迹点集合
     * @param bShowStartFlag 是否添加起始点标识并算上已有的距离来计算里程标识,true:是,false:否
     * @param oldDistance    已有的距离
     * @param bDistanceFlag  是否显示里程标识
     * @return 运动距离
     */
    public double addTrailToMap(List<TrailInfo> list, boolean bShowStartFlag,
                                double oldDistance, boolean bDistanceFlag) {
        if ((list == null) || (list.size() <= 0))
            return oldDistance;
        if (google_map == null)
            return oldDistance;
        if (list.get(0) == null) return oldDistance;
        //1.平滑处理
        bSpline(list);

        LatLng position;
        LatLng oldPosition;
        PolylineOptions option = null;

        //double dSpeed;
        int color = 0xFFFF8B22;//橙色
        double distance;
        long oldTime;
        boolean bPause;//是否运动暂停
        boolean bOldDotLine = false;
        boolean bOldPause = false;
        boolean bDotLine;//精度不够高的点画虚线
        boolean bNewLine;

        LatLng positionStart = new LatLng(list.get(0).getLat(), list.get(0)
                .getLng());

        oldPosition = positionStart;
        //List<LatLng> flagList = new ArrayList<>();
        SparseArray<LatLng> flagList = new SparseArray<>();
        distance = 0;
        if (bShowStartFlag)
            distance += oldDistance;
        oldTime = list.get(0).getTime();
        int mileStone = 0;
        //3.遍历所有点,得到每公里的速度和刚好在每个整数公里的点
        for (int i = 1; i < list.size(); i++) {
            position = new LatLng(list.get(i).getLat(), list.get(i).getLng());
            bPause = list.get(i).getSportState() != TrailInfo.SPORT_STATE_SPORT;
            bDotLine = list.get(i).getAccuracy() > Config.GPS_ACCURACY_DOT;
            //dSpeed = 0;
            bNewLine = (bPause != bOldPause) || (bDotLine != bOldDotLine);
            if (!bPause) {
                distance += TrailManager.getShortDistance(position.longitude,
                        position.latitude, oldPosition.longitude,
                        oldPosition.latitude);
                if (((int) (distance / 1000)) != mileStone && (list.get(i).getTime() > oldTime)) {
                    mileStone = (int) (distance / 1000);
                    flagList.put(mileStone, position);
                    bNewLine = true;
                }
                color = 0xFFFF8B22;//橙色
            } else {
                color = 0xFFCCCCCC;
            }

            if ((!bNewLine) && (option != null)) {
                oldPosition = position;
                option.add(position);
                continue;
            }

            if (option != null) {
                oldTime = list.get(i).getTime();
                option.color(color);
                if (google_map != null) {
                    google_map.addPolyline(option);
                }
            }

            option = new PolylineOptions();
            option.zIndex(5.0f);
            option.width(iTrailLineWidth);
            option.color(color);
            option.add(oldPosition);
            option.add(position);
            oldPosition = position;
            bOldDotLine = bDotLine;
            bOldPause = bPause;
        } //end for

        // 4.画轨迹
        if (option != null) {
            option.color(color);
            if (google_map != null) {
                google_map.addPolyline(option);
            }
        }
        // 5.根据是否需要显示起始点,添加起始点
        if (bShowStartFlag) {
            BitmapDescriptor bitmapStart = BitmapDescriptorFactory
                    .fromResource(R.drawable.run_start);
            MarkerOptions markStart = new MarkerOptions();
            markStart.icon(bitmapStart).position(positionStart);
            if (google_map != null) {
                google_map.addMarker(markStart);
            }
        }

        // 6.根据是否显示里程标识条件添加里程标识
        if (bDistanceFlag) {
            if (flagList.size() < 80) {//最多80个flag,防止oom
                for (int i = 0; i < flagList.size(); i++) {
                    addMarkFlag(flagList.get(i), String.valueOf(flagList.keyAt(i)));//"" + (i + 1));
                }
            }
        }
        // 7.清除地图marker资源,其实可以不调用
        flagList.clear();
        return distance;
    }

    /**
     * 重新移动地图镜头
     *
     * @param pos              定位点
     * @param bAnimateCamera   动画显示 true:是,false:否
     * @param bShowLocationPos 是否显示带圆圈效果定位点
     */
    public void relocatePosition(LatLng pos, boolean bAnimateCamera, boolean bShowLocationPos) {
        if (google_map == null)
            return;

        lastLocateTime = System.currentTimeMillis();
        try {
            MapsInitializer.initialize(mContext);
        } catch (Exception e) {
            e.printStackTrace();
        }

        float zoomIndex = Config.MAP_CAMERA_ZOOM;
        if (google_map != null) {
            if (google_map.getCameraPosition() != null) {
                zoomIndex = google_map.getCameraPosition().zoom;
                if (zoomIndex < Config.MAP_CAMERA_ZOOM_MIN) {
                    zoomIndex = Config.MAP_CAMERA_ZOOM;
                }
            }
        }

        if (bAnimateCamera) {
            if (google_map != null) {
                google_map.animateCamera(
                        CameraUpdateFactory.newCameraPosition(new CameraPosition(pos,
                                zoomIndex, 0, 0)), 1000, null);
            }
        } else {
            if (google_map != null) {
                google_map.moveCamera(CameraUpdateFactory.newCameraPosition(
                        new CameraPosition(pos, zoomIndex, 0, 0)));
            }
        }
        if (bShowLocationPos) forceShowLocationPoint(pos);
    }

    /**
     * 在地图显示带圆圈效果定位点
     *
     * @param pos 定位点
     */
    public void forceShowLocationPoint(LatLng pos) {
        mLocatePointCenter = setLocatePoint(mLocatePointCenter, pos, 10,
                colorCenter, 1);
        mLocatePointRange = setLocatePoint(mLocatePointRange, pos,
                Config.GPS_AVAILABLE_ACCURACY, colorRadius, 1);
    }


    /**
     * 在地图显示的轨迹
     *
     * @param list           轨迹点集合
     * @param bDistanceFlag  是否显示里程标识
     * @param bAnimateCamera 是否动画显示轨迹 true:是,false:否
     */
    public void setTrailOfMap(List<TrailInfo> list, boolean bDistanceFlag, boolean bAnimateCamera) {
        if ((list == null) || (list.size() <= 1))
            return;
        if (google_map == null)
            return;
        //1.清除地图所有标识
        clearTrail();
        //2.精简过滤不用在地图上显示的点,V2.0.4版本之后不再需要
        getLocationManager().filterTrailList(list, 1);
        //3.过滤后再判断轨迹点集合
        // 解决由于list元素被删除后的size为0 bug v2.0.2 java.lang.IndexOutOfBoundsException: Invalid index 0, size is 0
        if (list.size() <= 0) return;
        //4.获取每公里里程点
        SparseIntArray flagIndex = new SparseIntArray();//里程点下标
        LatLng positionStart = new LatLng(list.get(0).getLat(), list.get(0)
                .getLng());
        LatLng positionEnd = new LatLng(list.get(list.size() - 1).getLat(),
                list.get(list.size() - 1).getLng());
        double distance = 0;//当前段运动距离
        boolean bSporting;//是否运动中
        int mileStone = 0;
        for (int i = 1; i < list.size(); i++) {
            bSporting = list.get(i).getSportState() == TrailInfo.SPORT_STATE_SPORT;
            if (bSporting) {
                distance += TrailManager.getShortDistance(list.get(i).getLng(), list.get(i).getLat(),
                        list.get(i - 1).getLng(), list.get(i - 1).getLat());
                if (((int) (distance / 1000)) != mileStone && (list.get(i).getTime() > list.get(i - 1).getTime())) {
                    mileStone = (int) (distance / 1000);
                    flagIndex.put(mileStone, i);
                }
            }
        }
        //5.平滑处理
        bSpline(list);
        //6.获取里程点经纬点
        List<LatLng> flagList = new ArrayList<>();//里程点
        for (int i = 0; i < flagIndex.size(); i++) {
            int mile = flagIndex.valueAt(i);
            if (mile > 0 && mile < (list.size() - 1)) {
                TrailInfo info = list.get(mile);
                if (info != null) {
                    flagList.add(new LatLng(info.getLat(), info.getLng()));
                }
            }
        }
        //7.添加轨迹点
        LatLng position = null;//当前处理的点
        PolylineOptions option = null;
        //boolean bOldDotLine = false;
        boolean bOldPause = false;
        //boolean bDotLine;//是否画虚线(精度不高的有效定位路段画虚线)
        boolean bPause;
        boolean bNewLine;
        double dSpeed = 0;
        long duration;
        int color = 0xFF00FF00;//纯绿;
        for (int i = 1; i < list.size(); i++) {
            position = new LatLng(list.get(i).getLat(), list.get(i).getLng());
            bPause = list.get(i).getSportState() != TrailInfo.SPORT_STATE_SPORT;
            bNewLine = (bPause != bOldPause);// || (bDotLine != bOldDotLine);
            if (!bPause) {
                distance = TrailManager.getShortDistance(list.get(i).getLng(), list.get(i).getLat(),
                        list.get(i - 1).getLng(), list.get(i - 1).getLat());
                duration = list.get(i).getTime() - list.get(i - 1).getTime();
                if (duration > 0) {
                    dSpeed = distance * 1000 / duration;
                }
            } else {
                dSpeed = 0;
            }

            if (option == null) {
                option = new PolylineOptions();
                option.zIndex(5.0f);
                option.width(iTrailLineWidth);
            }

            if ((!bNewLine) && (option != null)) {
                color = getColorBySpeed(dSpeed, bOldPause);
                option.color(color);
                option.add(position);
                continue;
            } else {
                color = getColorBySpeed(dSpeed, bOldPause);
                option.color(color);
                option.add(position);
                if (google_map != null) {
                    google_map.addPolyline(option);
                }
                option.getPoints().clear();
                option.add(position);
            }
            bOldPause = bPause;
        } //end for
        // 8.添加轨迹线
        if (option != null) {
            option.color(color);
            if (google_map != null) {
                google_map.addPolyline(option);
            }
        }
        // 9.添加起始点和终点标识
        BitmapDescriptor bitmapStart = BitmapDescriptorFactory
                .fromResource(R.drawable.run_start);
        MarkerOptions markStart = new MarkerOptions();
        markStart.icon(bitmapStart).position(positionStart);
        if (google_map != null) {
            google_map.addMarker(markStart);
        }
        BitmapDescriptor bitmapEnd = BitmapDescriptorFactory
                .fromResource(R.drawable.run_end);
        MarkerOptions markEnd = new MarkerOptions();
        markEnd.icon(bitmapEnd).position(positionEnd);
        if (google_map != null) {
            google_map.addMarker(markEnd);
        }
        // 10.根据是否显示里程标识条件添加里程标识
        if (bDistanceFlag) {
            if (flagList.size() < 100) {//最多100公里,防止oom
                for (int i = 0; i < flagList.size(); i++) {
                    if (flagIndex != null && flagIndex.size() > i) {
                        addMarkFlag(flagList.get(i), String.valueOf(flagIndex.keyAt(i)));//"" + (i + 1));
                    }
                }
            }
        }
        // 11.根据轨迹形状决定轨迹边界,并添加地图暗色遮罩图层
        double zoom = Config.MAP_CAMERA_ZOOM;
        if (google_map != null) {
            zoom = google_map.getCameraPosition().zoom;
        }

        double[] map = new double[3];
        boolean bSuccess = getTrailLineRect(list, map);
        if (bSuccess) {
            double lat = map[0];//map.get("lat");
            double lng = map[1];//map.get("lng");
            zoom = map[2];//map.get("zoom");
            position = new LatLng(lat, lng);
            addDarkOverLay(position);
        }
        // 12.根据是否动画显示轨迹显示
        if (bAnimateCamera) {
            if (google_map != null && position != null) {
                google_map.animateCamera(
                        CameraUpdateFactory.newCameraPosition(new CameraPosition(
                                position, (float) zoom, 0, 0)), 1000, null);
            }
        }
        // 13.清除地图marker资源,其实可以不调用
        flagList.clear();
    }

    /**
     * b-spline 平滑轨迹线 http://www.maissan.net/articles/simulating-vines/2
     *
     * @param trailInfoList 要平滑处理的轨迹点集合
     * @return 平滑处理的结果集合
     */
    private List<TrailInfo> bSpline(List<TrailInfo> trailInfoList) {
        if (trailInfoList == null || trailInfoList.size() < 2)
            return trailInfoList;

        int iLen = trailInfoList.size();
        double t;
        double ax, bx, cx, lat;
        double ay, by, cy, lon;
        double dx, dy;
        // For every point
        for (int i = 2; i < iLen - 2; i++) {
            for (t = 0; t < 1; t += 0.2) {
                ax = (-1 * trailInfoList.get(i - 2).getLat() + 3 * trailInfoList.get(i - 1).getLat()
                        - 3 * trailInfoList.get(i).getLat() + trailInfoList.get(i + 1).getLat()) / 6;
                ay = (-1 * trailInfoList.get(i - 2).getLng() + 3 * trailInfoList.get(i - 1).getLng()
                        - 3 * trailInfoList.get(i).getLng() + trailInfoList.get(i + 1).getLng()) / 6;
                bx = (trailInfoList.get(i - 2).getLat() - 2 * trailInfoList.get(i - 1).getLat() + trailInfoList.get(i).getLat()) / 2;
                by = (trailInfoList.get(i - 2).getLng() - 2 * trailInfoList.get(i - 1).getLng() + trailInfoList.get(i).getLng()) / 2;
                cx = (-1 * trailInfoList.get(i - 2).getLat() + trailInfoList.get(i).getLat()) / 2;
                cy = (-1 * trailInfoList.get(i - 2).getLng() + trailInfoList.get(i).getLng()) / 2;
                dx = (trailInfoList.get(i - 2).getLat() + 4 * trailInfoList.get(i - 1).getLat() + trailInfoList.get(i).getLat()) / 6;
                dy = (trailInfoList.get(i - 2).getLng() + 4 * trailInfoList.get(i - 1).getLng() + trailInfoList.get(i).getLng()) / 6;
                lat = ax * Math.pow(t + 0.1, 3) + bx * Math.pow(t + 0.1, 2) + cx * (t + 0.1) + dx;
                lon = ay * Math.pow(t + 0.1, 3) + by * Math.pow(t + 0.1, 2) + cy * (t + 0.1) + dy;
                trailInfoList.get(i).setLat(lat);
                trailInfoList.get(i).setLng(lon);
            }
        }
        return trailInfoList;
    }

    //endregion ===============================对外公共方法======================================

}
