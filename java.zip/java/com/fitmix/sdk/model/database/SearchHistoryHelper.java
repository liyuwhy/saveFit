package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;

import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 数据库表(SearchHistory)帮助类
 */
public class SearchHistoryHelper {
    private static SearchHistoryHelper instance;
//    private Cursor cursor;

    public static SearchHistoryHelper getInstance() {
        if (instance == null) {
            instance = new SearchHistoryHelper();
        }
        return instance;
    }

    public SearchHistoryDao getSearchHistoryDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getSearchHistoryDao();
    }

    /**
     * 插入搜索记录
     *
     * @param uid  用户uid
     * @param text 搜索字段
     */
    public void insertRecentMusic(int uid, String text, long addTime) {
        SearchHistory used_history = checkTextExisted(text);
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        SearchHistory history = new SearchHistory();
        history.setUid(uid);
        history.setSearchText(text);
        history.setAddTime(addTime);
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        if (used_history == null) {
            asyncSession.insert(history);
        } else {
            used_history.setAddTime(addTime);
            asyncSession.update(used_history);
        }
    }

    /**
     * 判断是否已存在
     *
     * @param text
     * @return
     */
    private SearchHistory checkTextExisted(String text) {
        QueryBuilder<SearchHistory> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getSearchHistoryDao().queryBuilder();
        queryBuilder.where(SearchHistoryDao.Properties.SearchText.eq(text)).limit(1);
        return queryBuilder.unique();
    }

    public void cursorUpdate() {
//        if (cursor != null && !cursor.isClosed()) cursor.requery();
    }

    public List<SearchHistory> getHistoryList() {
        QueryBuilder<SearchHistory> queryBuilder = getSearchHistoryDao().queryBuilder();
        queryBuilder.orderDesc(SearchHistoryDao.Properties.AddTime);
        return queryBuilder.list();
    }

    /**
     * 获取搜索记录,升序
     *
     * @return
     */
    public List<SearchHistory> getHistoryListAsc() {
        QueryBuilder<SearchHistory> queryBuilder = getSearchHistoryDao().queryBuilder();
        queryBuilder.orderAsc(SearchHistoryDao.Properties.AddTime);
        return queryBuilder.list();
    }

    public void deleteHistory(SearchHistory history) {
        if (history == null) {
            return;
        }
        MixApp.getDaoSession(MixApp.getContext()).getSearchHistoryDao().delete(history);
    }

    public void deleteAllHistory() {
        List<SearchHistory> historyList = getHistoryList();
        if (historyList != null) {
            for (SearchHistory searchHistory : historyList) {
                deleteHistory(searchHistory);
            }
        }
    }

//    public DataReqStatus getDataReqStatusById(int RequestId) {
//        QueryBuilder<DataReqStatus> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao().queryBuilder();
//        queryBuilder.where(DataReqStatusDao.Properties.RequestId.eq(RequestId));
//        return queryBuilder.unique();
//    }
}
