package com.fitmix.sdk.model.database;

import android.content.Context;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.bean.RunRecordList;
import com.fitmix.sdk.watch.bean.WatchSportLog;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 手表运动记录表(WatchSportRecord)操作帮助类
 */

public class WatchSportDataHelper {
    /**
     * 异步获取指定用户所有的手表跑步记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncGetAllWatchRunRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跑步的记录
        final WatchSportRecordDao sportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
        QueryBuilder<WatchSportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
                .where(WatchSportRecordDao.Properties.Uploaded.lt(2))//已完成的记录
                .orderDesc(WatchSportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }


    /**
     * 从手表运动记录表(WatchSportRecord)中,异步获取用户尚未与服务器同步的运动记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncUnSyncWatchRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型但未同步的跑步记录
        final WatchSportRecordDao watchSportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
        QueryBuilder<WatchSportRecord> qb = watchSportRecordDao.queryBuilder();
        qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
                .where(WatchSportRecordDao.Properties.Uploaded.eq(0))//未同步
                .orderDesc(WatchSportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }
//
//    /**
//     * 异步搜索制定用户，制定开始日期、开始事件的手表运动记录
//     * @param context
//     * @param uid
//     * @param sportDate
//     * @param sportTime
//     * @param listener
//     */
//    public void getIdentifyWatchSportRecord(Context context ,int uid,long sportDate,long sportTime,AsyncOperationListener listener){
//        if(context == null){
//            return ;
//        }
//        final WatchSportRecordDao sportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
//        QueryBuilder<WatchSportRecord> qb = sportRecordDao.queryBuilder();
//        qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
//                .where(WatchSportRecordDao.Properties.StartDate.eq(sportDate))
//                .where(WatchSportRecordDao.Properties.StartTime.eq(sportTime))
//                .orderDesc(WatchSportRecordDao.Properties.StartDate,WatchSportRecordDao.Properties.StartTime)
//                .limit(1);//倒序排列
//
//        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
//        asyncSession.setListener(listener);
//        asyncSession.queryList(qb.build());
//    }
//    /**
//     * 获取指定用户，指定开始日期和开始时间的运动记录
//     */
//    public WatchSportRecord getIdentityWatchSportRecord(Context context, int uid, WatchSportRecordTransFinish finishItem){
//        if (context == null)
//            return null;
//        //查找指定用户的已完成的并且运动类型为跑步的运动记录
//        try {
//            final WatchSportRecordDao sportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
//            QueryBuilder<WatchSportRecord> qb = sportRecordDao.queryBuilder();
//            qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
//                    .where(WatchSportRecordDao.Properties.StartDate.eq(finishItem.getRecordDate()))
//                    .where(WatchSportRecordDao.Properties.StartTime.eq(finishItem.getRecordTime()))
//                    .orderDesc(WatchSportRecordDao.Properties.StartTime)//倒序排列
//                    .limit(1);
//            return qb.unique();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//
//    /**
//     * 更新运动信息到数据库表(SportRecord)中,指定用户特定跑步记录的同步状态
//     *
//     * @param uid          用户uid
//     * @param finishItem
//     * @param uploaded     运动记录是否已同步到服务器,0:未同步,1:已同步,2:记录未完成
//     */
//    public void updateWatchSportRecordSyncState(final int uid, final WatchSportRecordTransFinish finishItem, final int uploaded) {
//        try {
//            ThreadManager.executeOnSubThread1(new Runnable() {
//                @Override
//                public void run() {
//                    String updateQuery = "update " + WatchSportRecordDao.TABLENAME
//                            + " set " + WatchSportRecordDao.Properties.Uploaded.columnName + "=?"
//                            + " where " + WatchSportRecordDao.Properties.Uid.columnName + "=?"
//                            + " and " + WatchSportRecordDao.Properties.StartDate.columnName + "=?"
//                            + " and " + WatchSportRecordDao.Properties.StartTime.columnName + "=?";
//
//                    MixApp.getDaoMaster(MixApp.getContext()).getDatabase().execSQL(updateQuery,
//                            new Object[]{uploaded, uid, finishItem.getRecordDate(),finishItem.getRecordTime()});
//                    //重新刷新下状态
//                    final WatchSportRecordDao watchSportRecordDao = MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao();
//                    QueryBuilder<WatchSportRecord> qb = watchSportRecordDao.queryBuilder();
//                    qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
//                            .where(WatchSportRecordDao.Properties.StartTime.eq(finishItem.getRecordTime())
//                                    ,(WatchSportRecordDao.Properties.StartDate.eq(finishItem.getRecordDate()))).limit(1);
//                    /** 解决bug:java.lang.NullPointerException: Entity may not be null*/
//                    WatchSportRecord watchSportRecord = qb.build().unique();
//                    if (watchSportRecord != null) {
//                        try {
//                            MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao().refresh(watchSportRecord);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            });
//        } catch (Exception e) {
//            Logger.e(Logger.DEBUG_TAG, "updateWatchSportRecordSyncState error");
//            e.printStackTrace();
//        }
//    }
//

    /**
     * 更新手表运动记录表(WatchSportRecord)中,指定用户特定运动记录的同步状态
     *
     * @param uid       用户uid
     * @param startTime 用户开始运动的时间戳
     * @param zipFile   手表运动记录对应的文件压缩下载url
     * @param uploaded  运动记录是否已同步到服务器,0:未同步,1:已同步,2:记录未完成
     */
    public static void updateWatchSportRecordSyncState(final int uid, final long startTime, final String zipFile, final int uploaded) {
        try {
            ThreadManager.executeOnSubThread1(new Runnable() {
                @Override
                public void run() {
                    String updateQuery = "update " + WatchSportRecordDao.TABLENAME
                            + " set " + WatchSportRecordDao.Properties.Uploaded.columnName + "=? ,"
                            + WatchSportRecordDao.Properties.ZipFile.columnName + "=?"
                            + " where " + WatchSportRecordDao.Properties.Uid.columnName + "=?"
                            + " and " + WatchSportRecordDao.Properties.StartTime.columnName + "=?";

                    MixApp.getDaoMaster(MixApp.getContext()).getDatabase().execSQL(updateQuery,
                            new Object[]{uploaded, zipFile, uid, startTime});
                    //重新刷新下状态
                    final WatchSportRecordDao watchSportRecordDao = MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao();
                    QueryBuilder<WatchSportRecord> qb = watchSportRecordDao.queryBuilder();
                    qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
                            .where(WatchSportRecordDao.Properties.StartTime.eq(startTime)).limit(1);
                    WatchSportRecord watchSportRecord = qb.build().unique();
                    if (watchSportRecord != null) {
                        try {
                            MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao().refresh(watchSportRecord);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "updateWatchSportRecordSyncState error");
            e.printStackTrace();
        }
    }

    /**
     * 将手表的运动记录存数据库
     */
    public static boolean insertOrReplaceWatchSportRecord(WatchSportLog sportLog) {
        if (sportLog == null) {
            return false;
        }

        WatchSportRecord watchSportRecord = new WatchSportRecord();
        watchSportRecord.setUid(sportLog.getUid());
        watchSportRecord.setStartTime(sportLog.getStartTime());//运动开始时间戳
        watchSportRecord.setSportType(sportLog.getSportType());//运动类型，与枚举对应
        watchSportRecord.setSportDuration(sportLog.getSportDuration());//运动时长,单位为秒
        watchSportRecord.setSportTime(sportLog.getRealSportTime());//真正运动时长,单位为秒
        String pause = JsonHelper.createJsonString(sportLog.getPause_detail());
        if (pause != null) {
            watchSportRecord.setPauseDetail(pause);
        }

        watchSportRecord.setCalorie(sportLog.getTotalCalorie());//运动卡路里
        watchSportRecord.setFatBurn(sportLog.getFatBurst());//燃脂量,单位为克
        watchSportRecord.setLactateThreshold(sportLog.getLactateThreshold());//乳酸阈值
        watchSportRecord.setMaxSportHR(sportLog.getMaxSportHR());//最大运动心率
        watchSportRecord.setAvgSportHR(sportLog.getAvgSportHR());//平均运动心率
        watchSportRecord.setMaxHR(sportLog.getMaxHR());//最大心率,画图表用
        watchSportRecord.setRestHR(sportLog.getRestHR());//静息心率,画图表用
        String hrStatistics = JsonHelper.createJsonString(sportLog.getHrStatistics());
        if (hrStatistics != null) {
            watchSportRecord.setHrStatistics(hrStatistics);
        }

        watchSportRecord.setDistance(sportLog.getTotalDistance());//运动距离,单位为米
        watchSportRecord.setStep(sportLog.getTotalSteps());//运动步数
        watchSportRecord.setMaxPace(sportLog.getMaxPace());//最高配速,单位为秒
        watchSportRecord.setMaxFrequency(sportLog.getMaxFrequency());//最快步频
        watchSportRecord.setTotalDown(sportLog.getTotalDown()/ 10D);//下降高度 按照付工要求 /10
        watchSportRecord.setTotalUp(sportLog.getTotalUp()/ 10D);//上升高度 按照付工要求 /10
        watchSportRecord.setPeakAltitude(sportLog.getPeakAltitude());//峰值海拔
        watchSportRecord.setTroughAltitude(sportLog.getTroughAltitude());//波谷海拔
        String groupRecord = JsonHelper.createJsonString(sportLog.getGroupRecords());
        if (groupRecord != null) {//运动分组记录
            watchSportRecord.setGroupRecord(groupRecord);
        }

        watchSportRecord.setRunPower(sportLog.getRunPower());//跑力
        watchSportRecord.setRidePower(sportLog.getRidePower());//骑行功率

        watchSportRecord.setSwimPoolLength(sportLog.getSwimPoolLength());//泳池长度
        watchSportRecord.setSwimStyle(sportLog.getSwimStyle());//泳姿
        watchSportRecord.setSwimTrips(sportLog.getSwimTrips());//往返次数

        watchSportRecord.setStartAltitude(sportLog.getStartAltitude());//开始海拔
        watchSportRecord.setStartPressure(sportLog.getStartPressure());//开始气压
        watchSportRecord.setStartTemperature(sportLog.getStartTemperature());//开始温度

        if (sportLog.getOther() != null) {
            String other = JsonHelper.createJsonString(sportLog.getOther());
            watchSportRecord.setOther(other);
        }
        watchSportRecord.setUploaded(2);//记录未完成
        try {
            MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao().insertOrReplaceInTx(watchSportRecord);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 从手表运动记录表中,异步获取指定用户的指定记录
     *
     * @param uid       用户uid
     * @param startTime 运动开始时间戳,单位为毫秒
     * @param listener  异步查询回调监听
     */
    public static void asyncGetRecords(Context context, int uid, long startTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跑步的记录
        final WatchSportRecordDao watchSportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
        QueryBuilder<WatchSportRecord> qb = watchSportRecordDao.queryBuilder();
        qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
                .where(WatchSportRecordDao.Properties.StartTime.eq(startTime))
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(qb.build());
    }

    /**
     * 从手表运动记录表(WatchSportRecord)中,异步删除用户指定的运动记录
     *
     * @param context   上下文
     * @param uid       用户uid
     * @param startTime 运动开始时间戳,单位为毫秒
     * @param listener  异步删除回调监听
     */
    public static void asyncDeleteRecord(Context context, int uid, long startTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        try {
            //查找指定用户并且运动类型为跑步的特定记录
            final WatchSportRecordDao watchSportRecordDao = MixApp.getDaoSession(context).getWatchSportRecordDao();
            QueryBuilder<WatchSportRecord> qb = watchSportRecordDao.queryBuilder();
            qb.where(WatchSportRecordDao.Properties.Uid.eq(uid))
                    .where(WatchSportRecordDao.Properties.StartTime.eq(startTime));

            AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
            asyncSession.setListener(listener);
            asyncSession.delete(qb.build().unique());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 批量添加或更新记录到手表运动记录表(WatchSportRecord)中
     *
     * @param watchRecords 后台服务器返回的记录列表集合,type等于3
     * @return true:批量添加或更新成功,false:批量添加或更新失败
     */
    public static boolean bulkAddOrUpdateRecords(List<RunRecordList.RunRecord> watchRecords) {
        if (watchRecords == null || watchRecords.size() <= 0) {
            return true;
        }
        List<WatchSportRecord> sportRecords = new ArrayList<>();
        //后台服务器返回的跑步记录实体(RunRecord)转换为数据库运动记录实体(WatchSportRecord)
        WatchSportLog sportLog;
        for (RunRecordList.RunRecord runRecord : watchRecords) {
            sportLog = runRecord.getWatch();
            if (sportLog == null)
                continue;
            WatchSportRecord watchSportRecord = new WatchSportRecord();
            watchSportRecord.setUid(runRecord.getUid());//用户uid
            watchSportRecord.setStartTime(sportLog.getStartTime());//运动开始时间戳
            watchSportRecord.setSportType(sportLog.getSportType());//运动类型，与枚举对应
            watchSportRecord.setSportDuration(sportLog.getSportDuration());//运动时长,单位为秒
            watchSportRecord.setSportTime(sportLog.getRealSportTime());//真正运动时长,单位为秒
            String pause = JsonHelper.createJsonString(sportLog.getPause_detail());
            if (pause != null) {
                watchSportRecord.setPauseDetail(pause);
            }

            watchSportRecord.setCalorie(sportLog.getTotalCalorie());//运动卡路里
            watchSportRecord.setFatBurn(sportLog.getFatBurst());//燃脂量,单位为克
            watchSportRecord.setLactateThreshold(sportLog.getLactateThreshold());//乳酸阈值
            watchSportRecord.setMaxSportHR(sportLog.getMaxSportHR());//最大运动心率
            watchSportRecord.setAvgSportHR(sportLog.getAvgSportHR());//平均运动心率
            watchSportRecord.setMaxHR(sportLog.getMaxHR());//最大心率,画图表用
            watchSportRecord.setRestHR(sportLog.getRestHR());//静息心率,画图表用
            String hrStatistics = JsonHelper.createJsonString(sportLog.getHrStatistics());
            if (hrStatistics != null) {
                watchSportRecord.setHrStatistics(hrStatistics);
            }

            watchSportRecord.setDistance(sportLog.getTotalDistance());//运动距离,单位为米
            watchSportRecord.setStep(sportLog.getTotalSteps());//运动步数
            watchSportRecord.setMaxPace(sportLog.getMaxPace());//最高配速,单位为秒
            watchSportRecord.setMaxFrequency(sportLog.getMaxFrequency());//最快步频
            watchSportRecord.setTotalDown(sportLog.getTotalDown());//下降高度
            watchSportRecord.setTotalUp(sportLog.getTotalUp());//上升高度
            watchSportRecord.setPeakAltitude(sportLog.getPeakAltitude());//峰值海拔
            watchSportRecord.setTroughAltitude(sportLog.getTroughAltitude());//波谷海拔
            String groupRecord = JsonHelper.createJsonString(sportLog.getGroupRecords());
            if (groupRecord != null) {//运动分组记录
                watchSportRecord.setGroupRecord(groupRecord);
            }

            watchSportRecord.setRunPower(sportLog.getRunPower());//跑力
            watchSportRecord.setRidePower(sportLog.getRidePower());//骑行功率

            watchSportRecord.setSwimPoolLength(sportLog.getSwimPoolLength());//泳池长度
            watchSportRecord.setSwimStyle(sportLog.getSwimStyle());//泳姿
            watchSportRecord.setSwimTrips(sportLog.getSwimTrips());//往返次数

            watchSportRecord.setStartAltitude(sportLog.getStartAltitude());//开始海拔
            watchSportRecord.setStartPressure(sportLog.getStartPressure());//开始气压
            watchSportRecord.setStartTemperature(sportLog.getStartTemperature());//开始温度

//            if (sportLog.getOther() != null) {
//                String other = JsonHelper.createJsonString(sportLog.getOther());
//                watchSportRecord.setOther(other);
//            }
            watchSportRecord.setUploaded(1);//已同步
            watchSportRecord.setZipFile(runRecord.getWatchZipFile());//记录文件压缩包下载地址

            sportRecords.add(watchSportRecord);
        }
        try {
            MixApp.getDaoSession(MixApp.getContext()).getWatchSportRecordDao().insertOrReplaceInTx(sportRecords);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
