package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.model.manager.UserDataManager;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.query.QueryBuilder;

public class MessageHelper {
    private static MessageHelper instance;

    public static MessageHelper getInstance() {
        if (instance == null) {
            instance = new MessageHelper();
        }
        return instance;
    }

    public int getPersonUid() {
        return UserDataManager.getUid();
    }

    public MessageDao getMessageDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getMessageDao();
    }

    /**
     * 插入俱乐部的消息到数据库消息(Message)表
     *
     * @param clubId          俱乐部id
     * @param clubMessageType 设置俱乐部消息类型
     * @param number          消息数量
     */
    public void insertMessage(int clubId, int clubMessageType, int number) {
        Message message = new Message();
        if (getMessageByClubId(clubId) != null) {
            message = getMessageByClubId(clubId);
        } else {
            message.setUid(getPersonUid());
            message.setClubId(clubId);
            message.setType(4);
        }
        switch (clubMessageType) {
            case 1:
                message.setNews(number);
                break;
            case 2:
                message.setNotice(number);
                break;
            case 3:
                message.setRank(number);
                break;
            case 4:
                message.setMessage(number);
                break;
        }
        getMessageDao().insert(message);
    }

    /**
     * 插入消息到数据库消息(Message)表
     *
     * @param messageType 1 我的 2 音乐 3 赛事 4 俱乐部
     */
    public void insertMessage(int messageType) {
        Message message = new Message();
        if (getMessageByType(messageType) != null) {
            return;
        }
        message.setUid(getPersonUid());
        message.setType(messageType);
        getMessageDao().insert(message);
    }

    /**
     * 更改俱乐部的消息
     *
     * @param clubId          俱乐部id
     * @param clubMessageType 设置俱乐部消息类型
     */
    public void switchMessageState(int clubId, int clubMessageType) {
        Message message;
        if (getMessageByClubId(clubId) == null) {
            return;
        } else {
            message = getMessageByClubId(clubId);
        }
        switch (clubMessageType) {
            case 1:
                message.setNews(0);
                break;
            case 2:
                message.setNotice(0);
                break;
            case 3:
                message.setRank(0);
                break;
            case 4:
                message.setMessage(0);
                break;
        }
        getMessageDao().insertOrReplace(message);
        boolean hasNotice = message.getNotice() != null && message.getNotice() != 0;//该俱乐部没有新公告消息
        boolean hasMessage = message.getMessage() != null && message.getMessage() != 0;//该俱乐部有没有新留言消息
        if (!hasNotice && !hasMessage) {//如果该俱乐部信息的都为false 把它删掉
            getMessageDao().delete(message);
        }
    }

    /**
     * 某个俱乐部有没有新消息
     */
    public boolean clubHasMessage(int clubID) {
        return getMessageByClubId(clubID) != null;
    }

    /**
     * 获取所有有消息的俱乐部集合
     */
    public List<Integer> getClubIdList() {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.Type.eq(4), MessageDao.Properties.Uid.eq(getPersonUid()));
        List<Message> clubMessageList = queryBuilder.list();
        List<Integer> clubIdList = new ArrayList<>();
        if (clubMessageList != null && clubMessageList.size() > 0) {
            for (Message message : clubMessageList) {
                clubIdList.add(message.getClubId());
            }
        }
        return clubIdList;
    }

    /**
     * 删除某条俱乐部消息
     */
    public void deleteMessageByClubID(int clubID) {
        Message message = getMessageByClubId(clubID);
        if (message != null) {
            getMessageDao().delete(message);
        }
    }

    /**
     * 有没有俱乐部公告的消息
     *
     * @param clubID 俱乐部id
     */
    public boolean clubHasNotice(int clubID) {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.Uid.eq(getPersonUid()), MessageDao.Properties.ClubId.eq(clubID));
        Message message = queryBuilder.limit(1).unique();
        if (message == null) return false;
        return message.getNotice() != null && message.getNotice() > 0;
    }

    /**
     * 有没有俱乐部留言的消息
     *
     * @param clubID 俱乐部id
     */
    public boolean clubHasLiuYan(int clubID) {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.Uid.eq(getPersonUid()), MessageDao.Properties.ClubId.eq(clubID));
        Message message = queryBuilder.limit(1).unique();
        if (message == null) return false;
        return message.getMessage() != null && message.getMessage() > 0;
    }

    /**
     * 俱乐部模块有没有新消息
     */
    public boolean hasClubMessage() {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.Type.eq(4), MessageDao.Properties.Uid.eq(getPersonUid()));
        List<Message> clubMessageList = queryBuilder.list();
        return clubMessageList != null && clubMessageList.size() > 0;
    }

    /**
     * 赛事有没有新消息
     */
    public boolean hasCompetitionMessage() {
        return getMessageByType(3) != null;
    }

    /**
     * 把赛事信息的提示删掉
     */
    public void deleteCompetitionMessage() {
        Message message = getMessageByType(3);
        if (message != null)
            getMessageDao().delete(message);
    }

    /**
     * 根据俱乐部找到找到有没有消息
     *
     * @param clubID
     */
    public Message getMessageByClubId(int clubID) {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.ClubId.eq(clubID), MessageDao.Properties.Uid.eq(getPersonUid()));
        return queryBuilder.limit(1).unique();
    }

    /**
     * 根据消息类型 判断俱乐部有消息 或者赛事有新消息
     *
     * @param messageType 1 我的 2 音乐 3 赛事 4 俱乐部
     */
    public Message getMessageByType(int messageType) {
        QueryBuilder<Message> queryBuilder = getMessageDao().queryBuilder();
        queryBuilder.where(MessageDao.Properties.Type.eq(messageType), MessageDao.Properties.Uid.eq(getPersonUid()));
        return queryBuilder.limit(1).unique();
    }

}
