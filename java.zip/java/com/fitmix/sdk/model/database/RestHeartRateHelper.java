package com.fitmix.sdk.model.database;

import android.content.Context;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.bean.RestHeartRateBean;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

public class RestHeartRateHelper {

    private static RestHeartRateHelper instance;

    public static RestHeartRateHelper getInstance() {
        if (instance == null) {
            instance = new RestHeartRateHelper();
        }
        return instance;
    }

    public RestHeartRateDao getRestHeartRateDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao();
    }

    public boolean bulkAddOrUpdateRestHeartList(List<RestHeartRateBean> rhrList, int uploaded) {
        if (rhrList == null || rhrList.size() <= 0) {
            return true;
        }
//        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        List<RestHeartRate> records = new ArrayList<>();
        //后台服务器返回的跑步记录实体(RestHeartRateBean)转换为数据库运动记录实体(RestHeartRate)
        for (int i = 0; i < rhrList.size(); i++) {
            RestHeartRateBean bean = rhrList.get(i);
            RestHeartRate rhr = new RestHeartRate();
            rhr.setUid(bean.getUid());
            rhr.setTime(bean.getDetectTime());
            rhr.setId_start_time(bean.getDetectTime());
            rhr.setHeart_rate_record(bean.getHeartRateVal());
            rhr.setType(Config.HEART_RATE_REST_TYPE);
            rhr.setUploaded(uploaded);
            records.add(rhr);
        }
        try {
            MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao().insertOrReplaceInTx(records);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }

    public boolean ansyAddOrUpdateRestHeartList(List<RestHeartRateBean> rhrList, int uploaded) {
        if (rhrList == null || rhrList.size() <= 0) {
            return true;
        }
        final List<RestHeartRate> records = new ArrayList<>();
        //后台服务器返回的跑步记录实体(RestHeartRateBean)转换为数据库运动记录实体(RestHeartRate)
        for (int i = 0; i < rhrList.size(); i++) {
            RestHeartRateBean bean = rhrList.get(i);
            RestHeartRate rhr = new RestHeartRate();
            rhr.setUid(bean.getUid());
            rhr.setTime(bean.getDetectTime());
            rhr.setId_start_time(bean.getDetectTime());
            rhr.setHeart_rate_record(bean.getHeartRateVal());
            rhr.setType(Config.HEART_RATE_REST_TYPE);
            rhr.setUploaded(uploaded);
            records.add(rhr);
        }
        try {
            ThreadManager.executeOnSubThread1(new Runnable() {
                @Override
                public void run() {
                    MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao().insertOrReplaceInTx(records);
                }
            });
//            MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao().insertOrReplaceInTx(records);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;

    }


    /**
     * 根据 HeartRateInfo 插入(更新)检测的心率数据
     */
    public void insertRestHeartRateInfo(final RestHeartRate info) {
        if (info == null) return;
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
            }
        });
        asyncSession.insertOrReplace(info);

//            try {
//                ThreadManager.executeOnSubThread1(new Runnable() {
//                    @Override
//                    public void run() {
//                        MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao().insertOrReplace(info);
//                    }
//                });
//            }catch (Exception e){
//                e.printStackTrace();
//            }

    }

    /**
     * 搜索指定用户全部静息心率记录,按照降序
     *
     * @param uid
     * @return
     */
    public List<RestHeartRate> getRestHeartRateList(int uid) {

        QueryBuilder<RestHeartRate> queryBuilder = getRestHeartRateDao().queryBuilder();
        queryBuilder.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Type.eq(Config.HEART_RATE_REST_TYPE))
                .orderDesc(RestHeartRateDao.Properties.Id_start_time);
        return queryBuilder.list();
    }

    /**
     * 获取最新的一条静息心率数据
     *
     * @param uid
     * @return
     */
    public RestHeartRate getLatestHeartRateInfo(int uid) {
        QueryBuilder<RestHeartRate> queryBuilder = getRestHeartRateDao().queryBuilder();
        queryBuilder.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Type.eq(Config.HEART_RATE_REST_TYPE))
                .orderDesc(RestHeartRateDao.Properties.Id_start_time)
                .limit(1);
        return queryBuilder.unique();
    }

    /**
     * 异步获取最新的一条静息心率记录
     *
     * @param context
     * @param uid
     * @param listener
     */
    public void asyncGetLatestHeartRateInfo(Context context, int uid, AsyncOperationListener listener) {
        QueryBuilder<RestHeartRate> queryBuilder = getRestHeartRateDao().queryBuilder();
        queryBuilder.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Type.eq(Config.HEART_RATE_REST_TYPE))
                .orderDesc(RestHeartRateDao.Properties.Id_start_time)
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(queryBuilder.build());
    }

    /**
     * 从静息心率记录表(RestHeartRate)中,异步获取用户尚未与服务器同步的静息心率记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public void asyncUnSyncHeartRateRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型但未同步的跑步记录
        final RestHeartRateDao restHeartRateDao = MixApp.getDaoSession(context).getRestHeartRateDao();
        QueryBuilder<RestHeartRate> qb = restHeartRateDao.queryBuilder();
        qb.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Uploaded.eq(0))//未同步
                .orderDesc(RestHeartRateDao.Properties.Time)//倒序排列
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(qb.build());

    }

    public void updateRestHeartRateRecord(Context context, int uid, long startTime) {
        //查找指定用户的已完成的并且运动类型但未同步的跑步记录
        final RestHeartRateDao restHeartRateDao = MixApp.getDaoSession(context).getRestHeartRateDao();
        QueryBuilder<RestHeartRate> qb = restHeartRateDao.queryBuilder();
        qb.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Time.eq(startTime))
                .limit(1);
        RestHeartRate restHeartRate = qb.build().unique();
        if (restHeartRate != null) {
            restHeartRate.setUploaded(1);
            try {
                MixApp.getDaoSession(MixApp.getContext()).getRestHeartRateDao().insertOrReplace(restHeartRate);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 从心率信息表(RestHeartRate)中,异步获取指定用户指定心率类型指定开始时间下的心率记录
     *
     * @param uid
     * @param type
     * @param time
     * @return
     */
    public void asyncGetAllRestHeartRate(Context context, int uid, int type, long time, AsyncOperationListener listener) {
        //查找指定用户指定跑步记录的步数信息
        final RestHeartRateDao stepInfoDao = MixApp.getDaoSession(context).getRestHeartRateDao();

        QueryBuilder<RestHeartRate> queryBuilder = stepInfoDao.queryBuilder();
        queryBuilder.where(RestHeartRateDao.Properties.Uid.eq(uid))
                .where(RestHeartRateDao.Properties.Type.eq(type))
                .where(RestHeartRateDao.Properties.Id_start_time.eq(time));

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(queryBuilder.build());

    }

    /**
     * 删除指定用户，指定开始时间，指定心率类型的记录
     *
     * @param context
     * @param uid
     * @param runStartTime
     * @param type
     */
    public void deleteHeartRateInfo(Context context, int uid, long runStartTime, int type) {
        if (context == null)
            return;
        //查找指定用户指定跑步记录的步数信息
        try {
            final RestHeartRateDao restHeartRateDao = MixApp.getDaoSession(context).getRestHeartRateDao();
            QueryBuilder<RestHeartRate> qb = restHeartRateDao.queryBuilder();
            qb.where(RestHeartRateDao.Properties.Uid.eq(uid))
                    .where(RestHeartRateDao.Properties.Id_start_time.eq(runStartTime))
                    .where(RestHeartRateDao.Properties.Type.eq(type));

            restHeartRateDao.deleteInTx(qb.list());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
