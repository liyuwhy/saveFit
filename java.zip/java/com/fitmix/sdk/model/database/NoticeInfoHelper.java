package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 数据库表(NOTICE_INFO) 增、删、改、查帮助类
 */

public class NoticeInfoHelper {

    private static NoticeInfoHelper instance;

    //    private Cursor cursor;
    public static NoticeInfoHelper getInstance() {
        if (instance == null) {
            instance = new NoticeInfoHelper();
        }
        return instance;
    }

    public NoticeInfoDao getNoticeInfoDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getNoticeInfoDao();
    }

    public List<NoticeInfo> getNoticeInfoList() {
        QueryBuilder<NoticeInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getNoticeInfoDao().queryBuilder();
        queryBuilder.orderDesc(NoticeInfoDao.Properties.AddTime)
                .limit(30);

        List<NoticeInfo> noticeInfoList = queryBuilder.list();
        List<NoticeInfo> noticeInfoNewList = new ArrayList<>();
        if (noticeInfoList != null) {
            for (NoticeInfo messageInfo : noticeInfoList) {
                if (!checkNoticeExistInNoticeInfo(messageInfo.getNoticeId())) {
                    noticeInfoNewList.add(messageInfo);
                }
            }
        }
        return noticeInfoNewList;
    }

//    public Cursor getNoticeInfoCursor() {
//        if (cursor != null && !cursor.isClosed()) return cursor;
//        String[] columns = new String[]{"_id", "NOTICE_ID"};
//        String selection = "NOTICE_ID not in (" + getNoticeStringNotInDB() + ")";
//        String orderBy = "ADD_TIME DESC";
//        String limit = "30";
//        cursor = getNoticeInfoDao().getDatabase().query(getNoticeInfoDao().getTablename(), columns, selection, null, null, null, orderBy, limit);
//        return cursor;
//    }

//    /**
//     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的消息
//     */
//    private String getNoticeStringNotInDB() {
//        List<NoticeInfo>noticeInfoList = getNoticeInfoList();
//        StringBuilder sb = new StringBuilder();
//        if (noticeInfoList != null) {
//            for (int i = 0; i < noticeInfoList.size(); i++) {
//                if (checkNoticeExistInNoticeInfo(noticeInfoList.get(i).getNoticeId())) continue;
//                sb.append(noticeInfoList.get(i).getNoticeId());
//                sb.append(",");
//            }
//        }
//        if (sb.length() > 0) {
//            sb.deleteCharAt(sb.length() - 1);
//        }
//        return sb.toString();
//    }

    private boolean checkNoticeExistInNoticeInfo(long noticeId) {
        return NoticeInfoHelper.getInstance().checkNoticeInfoExist(noticeId);
    }

    public boolean checkNoticeInfoExist(long noticeId) {
        return getNoticeInfoByID(noticeId) == null;
    }

    /**
     * 根据noticeId删除消息
     *
     * @param noticeId 消息ID
     */
    public void deleteNoticeInfoByNoticeId(long noticeId) {
        asyncDeleteNoticeInfo(getNoticeInfoByID(noticeId));
    }


    /**
     * 根据Id在noticeInfo表中查找数据
     *
     * @param noticeId 消息ID
     */
    public NoticeInfo getNoticeInfoByID(long noticeId) {
        QueryBuilder<NoticeInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getNoticeInfoDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(NoticeInfoDao.Properties.NoticeId.eq(noticeId)).limit(1);
        return queryBuilder.unique();
    }

//    public void cursorUpdate() {
//        if (cursor != null && !cursor.isClosed()) cursor.requery();
//    }

    /**
     * 异步删除消息
     *
     * @param noticeInfo 消息
     */
    public void asyncDeleteNoticeInfo(NoticeInfo noticeInfo) {
        if (noticeInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
//                cursorUpdate();
            }
        });
        asyncSession.delete(noticeInfo);
    }

    /**
     * 异步添加或更新消息
     *
     * @param noticeInfo 消息
     */
    public void asyncWriteNoticeInfo(NoticeInfo noticeInfo) {
        if (noticeInfo == null) {
            return;
        }
        getNoticeInfoDao().insertOrReplace(noticeInfo);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param noticeInfoList 消息列表
     */
    public void asyncWriteNoticeInfoList(List<NoticeInfo> noticeInfoList) {
        if (noticeInfoList == null || noticeInfoList.isEmpty()) return;
        for (NoticeInfo messageInfo : noticeInfoList) {
            asyncWriteNoticeInfo(messageInfo);
        }
    }


}
