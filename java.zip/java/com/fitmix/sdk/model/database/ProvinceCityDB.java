package com.fitmix.sdk.model.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.SpinnerListItem;
import com.fitmix.sdk.common.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ProvinceCityDB {
    private static final int BUFFER_SIZE = 1024;
    public static final String DB_NAME = "mzk.db";
    public static final String PACKAGE_NAME = "com.fitmix.sdk";
    public static final String DB_PATH = "/data"
            + Environment.getDataDirectory().getAbsolutePath() + "/"
            + PACKAGE_NAME + "/databases";
    private SQLiteDatabase database;
    private static ProvinceCityDB instance;
    private File file = null;

    public ProvinceCityDB() {
        super();
    }

    public static ProvinceCityDB getInstance() {
        if (instance == null) {
            synchronized (ProvinceCityDB.class) {
                if (instance == null) {
                    instance = new ProvinceCityDB();
                }
            }
        }
        instance.openDatabase();
        return instance;
    }

    public void openDatabase() {
        this.database = this.openDatabase(DB_PATH + "/" + DB_NAME);
    }

    public SQLiteDatabase getDatabase() {
        return this.database;
    }

//    public String getProvinceName(int ProvinceId) {
//        openDatabase();
//        String sql_province = "select * from fs_province where ProvinceID = "
//                + ProvinceId;
//        Cursor cursor = getDatabase().rawQuery(sql_province, null);
//        String provinceName = null;
//        while (cursor.moveToNext()) {
//            provinceName = cursor.getString(cursor
//                    .getColumnIndex("ProvinceName"));
//        }
//        cursor.close();
//        closeDatabase();
//        return provinceName;
//    }

    /**
     * 获取省份列表
     */
    public List<SpinnerListItem> getProvinceList() {
        List<SpinnerListItem> list = new ArrayList<>();
        String sql = "select * from fs_province";
        Cursor cursor = null;
        try {
            cursor = getDatabase().rawQuery(sql, null);
            while (cursor.moveToNext()) {
                int provinceId = cursor.getInt(cursor.getColumnIndex("ProvinceID"));
                String ProvinceName = cursor.getString(cursor
                        .getColumnIndex("ProvinceName"));
                SpinnerListItem province = new SpinnerListItem();
                province.setName(ProvinceName);
                province.setId(provinceId);
                list.add(province);
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            closeDatabase();
        }
        return list;
    }

    /**
     * 根据省份ID,获取该省名下的城市列表
     */
    public List<SpinnerListItem> getCityList(int ProvinceId) {
        List<SpinnerListItem> list = new ArrayList<>();
        String sql = "select * from fs_city where ProvinceID=" + ProvinceId;
        Logger.i(Logger.DEBUG_TAG, "getCityList sql:" + sql);
        Cursor cursor = null;
        try {
            cursor = getDatabase().rawQuery(sql, null);
            while (cursor.moveToNext()) {
                int cityID = cursor.getInt(cursor.getColumnIndex("CityID"));
                String cityName = cursor.getString(cursor
                        .getColumnIndex("CityName"));
                String zipCode = cursor.getString(cursor
                        .getColumnIndex("ZipCode"));
                SpinnerListItem city = new SpinnerListItem();
                city.setName(cityName);
                city.setId(cityID);
                city.setZipCode(zipCode);
                list.add(city);
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            closeDatabase();
        }
        return list;
    }

//    public String getCityName(int CityId) {
//        openDatabase();
//        String sql_city = "select * from fs_city where CityID = " + CityId;
//        Cursor cursor = null;
//        String city = null;
//        try {
//            cursor = getDatabase().rawQuery(sql_city, null);
//            while (cursor.moveToNext()) {
//                city = cursor.getString(cursor.getColumnIndex("CityName"));
//            }
//        }finally {
//            if(cursor != null){
//                cursor.close();
//            }
//            closeDatabase();
//        }
//        return city;
//    }

    private SQLiteDatabase openDatabase(String dbFile) {
        try {
            file = new File(dbFile);
            if (!file.exists()) {
                InputStream is = MixApp.getContext().getResources()
                        .openRawResource(R.raw.mzk);
                if (is != null) {
                } else {
                }
                FileOutputStream fos = new FileOutputStream(dbFile);
                if (is != null) {

                } else {
                }
                byte[] buffer = new byte[BUFFER_SIZE];
                int count;
                while ((count = is.read(buffer)) > 0) {
                    fos.write(buffer, 0, count);
                    fos.flush();
                }
                fos.close();
                is.close();
            }
            database = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
            return database;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (Exception e2) {
        }
        return null;
    }

    public void closeDatabase() {
        if (this.database != null)
            this.database.close();
    }
}