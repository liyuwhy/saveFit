package com.fitmix.sdk.model.database;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;

import de.greenrobot.dao.query.QueryBuilder;

/**
 * 数据请求状态表(DataReqStatus)操作帮助类
 */
public class DataReqStatusHelper {
    private static DataReqStatusHelper instance;

    public static DataReqStatusHelper getInstance() {
        if (instance == null) {
            instance = new DataReqStatusHelper();
        }
        return instance;
    }

    /**
     * 根据数据请求编号获取数据请求状态
     *
     * @param requestId 数据请求编号
     * @return 数据请求状态实例
     */
    public DataReqStatus getDataReqStatusById(int requestId) {
        QueryBuilder<DataReqStatus> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao().queryBuilder();
        queryBuilder.where(DataReqStatusDao.Properties.RequestId.eq(requestId)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 更新数据请求状态表(DataReqStatus)中指定的数据请求状态信息
     *
     * @param dataReqStatus 要更新的数据请求状态信息
     * @return true:更新成功,false:更新失败
     */
    public boolean updateDataReqStatus(DataReqStatus dataReqStatus) {
        if (dataReqStatus == null) {
            return false;
        }
        try {
            MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao().update(dataReqStatus);
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    /**
     * 根据数据请求编号获取数据请求状态结果
     *
     * @param requestId 数据请求编号
     * @return 数据请求状态结果, 注意null值判断
     */
    public String getDataReqResult(int requestId) {
        DataReqStatus dataReqStatus = getDataReqStatusById(requestId);
        return dataReqStatus != null ? dataReqStatus.getResult() : "";
    }

    /**
     * 线程阻塞方式设置DataReqStatus表的某个条目缓存失效
     *
     * @param RequestId
     */
    public void setDataReqStatusCacheUseless(int RequestId) {
        DataReqStatus status = getDataReqStatusById(RequestId);
        if (status == null) {
            return;
        }
        status.setExpired(Config.CACHE_USELESS);
        MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao().insertOrReplace(status);
    }

}
