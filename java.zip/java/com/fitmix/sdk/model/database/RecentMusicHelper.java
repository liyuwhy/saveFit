package com.fitmix.sdk.model.database;

import android.database.Cursor;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.Logger;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


/**
 * 音乐信息帮助类 信息保存在MusicInfo中
 */
public class RecentMusicHelper {

    private static RecentMusicHelper instance;
    private Cursor cursor;

    public static RecentMusicHelper getInstance() {
        if (instance == null) {
            instance = new RecentMusicHelper();
        }
        return instance;
    }

    public RecentMusicDao getRecentMusicDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao();
    }

    public Cursor getRecentMusicCursor() {
        if (cursor != null && !cursor.isClosed()) return cursor;
        String[] columns = new String[]{"_id", "MUSIC_ID"};
        String selection = "MUSIC_ID not in (" + getMusicStringNotInDB() + ")";
        String orderBy = "ADD_TIME DESC";
        String limit = "30";
        cursor = getRecentMusicDao().getDatabase().query(getRecentMusicDao().getTablename(), columns, selection, null, null, null, orderBy, limit);
        return cursor;
    }

    public void cursorUpdate() {
        if (cursor != null && !cursor.isClosed()) cursor.requery();
    }

    /**
     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的歌曲
     */
    private String getMusicStringNotInDB() {
        List<RecentMusic> recentMusicList = getRecentMusicList();
        StringBuilder sb = new StringBuilder();
        if (recentMusicList != null) {
            for (int i = 0; i < recentMusicList.size(); i++) {
                if (checkMusicExistInMusicInfo(recentMusicList.get(i).getMusicID())) continue;
                sb.append(recentMusicList.get(i).getMusicID());
                sb.append(",");
            }
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * 根据 music 插入最近播放的数据
     *
     * @param musicID 进行操作的音乐ID
     */
    public void insertRecentMusic(int musicID) {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        RecentMusic recentMusic = new RecentMusic();
        recentMusic.setMusicID(musicID);
        recentMusic.setAddTime(System.currentTimeMillis());
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insert(recentMusic);
    }

    public boolean checkRecentMusicExist(int musicID) {
        return getRecentMusicByID(musicID) != null;
    }


    /**
     * 根据 musicID 更新最近播放的数据 只需要把加入的时间更新即可
     *
     * @param musicID 进行操作的音乐ID
     * @return boolean
     */
    public void updateRecentMusic(int musicID) {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        RecentMusic recentMusic = getRecentMusicByID(musicID);
        if (recentMusic == null) {
            return;
        }
        recentMusic.setAddTime(System.currentTimeMillis());
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.update(recentMusic);
    }

    /**
     * 当最近播放的音乐大于30条的时候 再次更新就把 addTime 最小的 即（最早播放的歌曲）用最新的歌曲信息 替代
     *
     * @param MusicID 进行操作的音乐ID
     * @return boolean
     */
    public void updateRecentMusicFar(int MusicID) {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        RecentMusic recentMusic = getLastRecentMusic();
        if (recentMusic == null) {
            return;
        }
        recentMusic.setMusicID(MusicID);
        recentMusic.setAddTime(System.currentTimeMillis());
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.update(recentMusic);
    }

    private RecentMusic getLastRecentMusic() {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        queryBuilder.orderDesc(RecentMusicDao.Properties.AddTime).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 根据 musicID 删除最近播放的音乐
     *
     * @param musicID 进行操作的音乐
     * @return boolean
     */
    public void deleteRecentMusic(int musicID) {
        asyncDeleteRecentMusic(getRecentMusicByID(musicID));
    }

    /**
     * 删除所有的最近播放的音乐
     */
    public void deleteAllRecentMusic() {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.deleteAll(RecentMusic.class);
    }

    /**
     * 获得最近播放的音乐数目
     *
     * @return 数量
     */
    public Long getRecentMusicNumber() {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        Logger.i(Logger.DEBUG_TAG, "getRecentMusicNumber ----- > count : " + queryBuilder.count());
        return queryBuilder.count();
    }

    /**
     * 获得最近播放的音乐列表
     *
     * @return 音乐列表
     */
    public List<Music> getRecentMusic() {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        queryBuilder
                .where(RecentMusicDao.Properties.MusicID.notIn(getMusicNotInDB()))
                .orderDesc(RecentMusicDao.Properties.AddTime)
                .limit(30)
                .buildCursor();
        List<RecentMusic> recentMusicList = queryBuilder.list();
        List<Integer> idList = new ArrayList<>();
        if (recentMusicList != null) {
            for (int i = 0; i < recentMusicList.size(); i++) {
                idList.add(recentMusicList.get(i).getMusicID());
                Logger.i(Logger.DEBUG_TAG, "getRecentMusic --- > musicId : " + recentMusicList.get(i).getMusicID());
            }
        }
        return MusicInfoHelper.getInstance().getMusicListByIdList(idList);
    }

    /**
     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的歌曲
     */
    private List<Integer> getMusicNotInDB() {
        List<Integer> musicIdList = getRecentMusicIDList();
        List<Integer> voidId = new ArrayList<>();
        if (musicIdList != null) {
            for (int i = 0; i < musicIdList.size(); i++) {
                Music music = MusicInfoHelper.getInstance().getMusicByID(musicIdList.get(i));
                if (music != null) continue;
                voidId.add(musicIdList.get(i));
            }
        }
        return voidId;
    }

    private boolean checkMusicExistInMusicInfo(int musicId) {
        return MusicInfoHelper.getInstance().checkFitmixMusicExist(musicId);
    }

    /**
     * 获得最近播放的音乐
     *
     * @return List<RecentMusic>
     */
    public List<RecentMusic> getRecentMusicList() {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        queryBuilder.orderDesc(RecentMusicDao.Properties.AddTime)
                .limit(30);
        List<RecentMusic> list = queryBuilder.list();
        if (list == null) list = new ArrayList<>();
        return list;
    }

    /**
     * 获得最近播放的音乐ID列表
     *
     * @return 数量
     */
    public List<Integer> getRecentMusicIDList() {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        queryBuilder.orderDesc(RecentMusicDao.Properties.AddTime)
                .limit(30);
        List<RecentMusic> recentMusicList = queryBuilder.list();
        List<Integer> musicIdList = new ArrayList<>();
        if (recentMusicList != null) {
            for (RecentMusic recentMusic : recentMusicList) {
                if (!checkMusicExistInMusicInfo(recentMusic.getMusicID())) continue;
                musicIdList.add(recentMusic.getMusicID());
                Logger.i(Logger.DEBUG_TAG, "getMusicByScene ----> musicId : " + recentMusic.getMusicID());
            }
        }
        return musicIdList;
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicID 音乐ID
     */
    public RecentMusic getRecentMusicByID(int musicID) {
        QueryBuilder<RecentMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getRecentMusicDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(RecentMusicDao.Properties.MusicID.eq(musicID)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param recentMusic 音乐信息
     */
    public void asyncWriteRecentMusic(RecentMusic recentMusic) {
        if (recentMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insertOrReplace(recentMusic);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param recentMusicList 音乐列表信息
     */
    public void asyncWriteRecentMusicList(List<RecentMusic> recentMusicList) {
        if (recentMusicList == null || recentMusicList.isEmpty()) return;
        for (RecentMusic recentMusic : recentMusicList) {
            asyncWriteRecentMusic(recentMusic);
        }
    }

    /**
     * 异步删除音乐信息
     *
     * @param recentMusic 音乐信息
     */
    public void asyncDeleteRecentMusic(RecentMusic recentMusic) {
        if (recentMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.delete(recentMusic);
    }
}
