package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 数据库表(CHAT_MESSAGE_INFO_LIST) 增、删、改、查帮助类
 */

public class ChatMessageInfoListHelper {

    private static ChatMessageInfoListHelper instance;

    public static ChatMessageInfoListHelper getInstance() {
        if (instance == null) {
            instance = new ChatMessageInfoListHelper();
        }
        return instance;
    }

    public ChatMessageInfoListDao getChatMessageInfoListDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getChatMessageInfoListDao();
    }

    public List<ChatMessageInfoList> getMessageInfoList() {
        QueryBuilder<ChatMessageInfoList> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getChatMessageInfoListDao().queryBuilder();
        queryBuilder.limit(30);


        List<ChatMessageInfoList> messageInfoList = queryBuilder.list();
        List<ChatMessageInfoList> messageInfoNewList = new ArrayList<>();
        if (messageInfoList != null) {
            messageInfoNewList.addAll(messageInfoList);
        }
        return messageInfoNewList;
    }

    /**
     * 根据Id在messageInfo表中查找数据
     *
     * @param groupId 聊天组ID
     */
    public ChatMessageInfoList getChatMessageInfoListByID(String groupId) {
        QueryBuilder<ChatMessageInfoList> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getChatMessageInfoListDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(ChatMessageInfoListDao.Properties.GroupId.eq(groupId)).limit(1);
        return queryBuilder.unique();
    }


    /**
     * 异步删除消息
     *
     * @param messageInfo 消息
     */
    public void asyncDeleteMessageInfoList(ChatMessageInfoList messageInfo) {
        if (messageInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {

            }
        });
        asyncSession.delete(messageInfo);
    }

    /**
     * 根据groupId删除消息
     *
     * @param groupId 组ID
     */
    public void deleteChatMessageInfoListByGroupId(String groupId) {
        asyncDeleteMessageInfoList(getChatMessageInfoListByID(groupId));
    }

    /**
     * 异步删除所有消息
     */
    public void asyncDeleteAllMessageInfoList() {
        List<ChatMessageInfoList> chatMessageInfoList = getMessageInfoList();
        if (chatMessageInfoList != null) {
            for (ChatMessageInfoList chatMessageInfo : chatMessageInfoList) {
                asyncDeleteMessageInfoList(chatMessageInfo);
            }
        }
    }

    /**
     * 查找是否存在
     */
    private boolean checkChatMessageInfoListExistInChatMessageInfoList(String groupId) {
        return ChatMessageInfoListHelper.getInstance().checkMessageInfoExist(groupId);
    }

    public boolean checkMessageInfoExist(String groupId) {
        return getChatMessageInfoListByID(groupId) == null;
    }

    /**
     * 异步添加或更新消息
     *
     * @param chatMessageInfoList 消息列表
     */
    public void asyncWriteChatMessageInfo(ChatMessageInfoList chatMessageInfoList) {
        if (chatMessageInfoList == null) {
            return;
        }
        getChatMessageInfoListDao().insertOrReplace(chatMessageInfoList);
    }

    /**
     * 异步添加或更新信息
     *
     * @param chatMessageInfoList 消息列表
     */
    public void asyncWriteChatMessageInfoList(List<ChatMessageInfoList> chatMessageInfoList) {
        if (chatMessageInfoList == null || chatMessageInfoList.isEmpty()) return;
        for (ChatMessageInfoList chatMessageInfo : chatMessageInfoList) {
            asyncWriteChatMessageInfo(chatMessageInfo);
        }
    }

}
