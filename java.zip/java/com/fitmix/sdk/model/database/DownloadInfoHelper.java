package com.fitmix.sdk.model.database;

import android.content.Context;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.download.DownloadStatus;
import com.fitmix.sdk.common.download.DownloadType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


/**
 * 资源下载帮助工具类,数据保存在DownloadInfo表中
 */
public class DownloadInfoHelper {

    /**
     * 从下载信息表(DownloadInfo)中,根据指定的资源类型异步获取所有等待中或暂停状态的下载任务,以下载编号倒序排序
     *
     * @param context                上下文
     * @param downloadType           指定的资源类型,参考 {@link com.fitmix.sdk.common.download.DownloadType }
     * @param asyncOperationListener 异步查询结果回调
     */
    public static void getDownloadInfoListAsync(Context context, int downloadType, AsyncOperationListener asyncOperationListener) {

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(context).getDownloadInfoDao().queryBuilder();
        //从数据库中加载等待或暂停的下载任务,以倒序排序
        if (downloadType == DownloadType.TYPE_ALL) {
            queryBuilder.where(
                    queryBuilder.or(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_WAITING),
                            DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_PAUSED)))
                    .orderDesc(DownloadInfoDao.Properties.DownloadId);
        } else {
            queryBuilder.where(DownloadInfoDao.Properties.Type.eq(downloadType),
                    queryBuilder.or(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_WAITING),
                            DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_PAUSED)))
                    .orderDesc(DownloadInfoDao.Properties.DownloadId);
        }
        if (asyncOperationListener != null) {
            asyncSession.setListener(asyncOperationListener);
        }
        asyncSession.queryList(queryBuilder.build());
    }

    public static List<DownloadInfo> getDownloadInfoListByUrl(String url) {
        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.RemoteUrl.eq(url));
        return queryBuilder.list();
    }

    /**
     * 根据资源url地址,获取下载信息
     *
     * @param url 资源url地址
     * @return 下载信息, 注意空值判断
     */
    public static DownloadInfo getDownloadInfoByUrl(String url) {
        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.RemoteUrl.eq(url)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 获取下载完成的DownloadInfo列表
     *
     * @return
     */
    public static List<DownloadInfo> getDownLoadInfoComplete() {
        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.Status.eq(DownloadStatus.STATUS_COMPLETED));
        List<DownloadInfo> list = queryBuilder.list();
        if (list == null) {
            list = new ArrayList<>();
        } else {
            List<DownloadInfo> ll = new ArrayList<>();
            for (DownloadInfo dd : list) {
                File file = new File(dd.getLocalPath() + File.separator + dd.getName());
                if (file.exists()) {
                    ll.add(dd);
                }
            }
            return ll;
        }
        return list;
    }

    public static DownloadInfo getDownloadInfoById(String Id) {
        QueryBuilder<DownloadInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().queryBuilder();
        queryBuilder.where(DownloadInfoDao.Properties.RemoteUrl.eq(Id)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 异步添加或更新下载信息
     *
     * @param downloadInfo 下载信息
     */
    public static void asyncWriteDownloadInfo(final DownloadInfo downloadInfo) {
        if (downloadInfo == null) {
            return;
        }
        DownloadInfo dd = DownloadInfoHelper.getDownloadInfoById(downloadInfo.getRemoteUrl());
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                // do whats needed
            }
        });
        if (dd != null) {
            asyncSession.insertOrReplace(dd);
        } else {
            asyncSession.insertOrReplace(downloadInfo);
        }
//        asyncSession.insertOrReplace(downloadInfo);
    }

    /**
     * 同步删除下载信息
     *
     * @param downloadInfo 下载信息
     */
    public static void asyncDeleteDownloadInfo(final DownloadInfo downloadInfo, AsyncOperationListener asyncOperationListener) {
        if (downloadInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        if (asyncOperationListener != null) {
            asyncSession.setListenerMainThread(asyncOperationListener);
        }
        asyncSession.delete(downloadInfo);
    }

    /**
     * 异步删除下载信息
     *
     * @param downloadInfo 下载信息
     */
    public static void asyncDeleteDownloadInfo(final DownloadInfo downloadInfo) {
        if (downloadInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {

            }
        });
        asyncSession.delete(downloadInfo);
    }

    /**
     * 异步删除下载信息列表
     */
    public static void asyncDeleteDownloadInfoList(final List<DownloadInfo> downloadInfoList, AsyncOperationListener asyncOperationListener) {
        if (downloadInfoList == null) {
            return;
        }
        for (DownloadInfo dd : downloadInfoList) {
            asyncDeleteDownloadInfo(dd, asyncOperationListener);
        }
    }
}
