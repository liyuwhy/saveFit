package com.fitmix.sdk.model.database;

import android.database.Cursor;

import com.fitmix.sdk.MixApp;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


public class LocalMusicHelper {
    private static LocalMusicHelper instance;
    private static Cursor cursor;

    public LocalMusicDao getLocalMusicDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getLocalMusicDao();
    }

    public static LocalMusicHelper getInstance() {
        if (instance == null) {
            instance = new LocalMusicHelper();
        }
        return instance;
    }

    /**
     * @return 本地歌曲列表的cursor
     */
    public Cursor getLocalMusicCursor() {
        if (cursor != null && !cursor.isClosed()) return cursor;
        String[] columns = new String[]{"_id", "MUSIC_ID"};
        String selection = "MUSIC_ID not in (" + getMusicStringNotInDB() + ")";
        String orderBy = "MUSIC_ID DESC";
        cursor = getLocalMusicDao().getDatabase().query(getLocalMusicDao().getTablename(), columns, selection, null, null, null, orderBy, null);
        return cursor;
    }

    public void cursorUpdate() {
        if (cursor != null && !cursor.isClosed()) cursor.requery();
    }

    /**
     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的歌曲
     */
    private String getMusicStringNotInDB() {
        List<LocalMusic> localMusicList = getLocalMusicList();
        StringBuilder sb = new StringBuilder();
        if (localMusicList != null) {
            for (int i = 0; i < localMusicList.size(); i++) {
                if (checkMusicExistInMusicInfo(localMusicList.get(i).getMusicID())) continue;
                sb.append(localMusicList.get(i).getMusicID());
                sb.append(",");
            }
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * 根据 musicID 插入本地歌曲的数据
     *
     * @param musicID 进行操作的音乐ID
     */
    public void insertLocalMusic(int musicID) {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        LocalMusic localMusic = new LocalMusic();
        localMusic.setMusicID(musicID);
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insertOrReplace(localMusic);
    }

    /**
     * 根据 musicID 删除本地歌曲的数据
     *
     * @param musicID 进行操作的音乐ID
     */
    public void deleteLocalMusic(int musicID) {
        asyncDeleteLocalMusic(getLocalMusicByID(musicID));
    }


    public void deleteAllLocalMusic() {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.deleteAll(LocalMusic.class);
    }

    /**
     * 获得最本地歌曲音乐数目
     *
     * @return 数量
     */
    public long getLocalMusicNumber() {
        QueryBuilder<LocalMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getLocalMusicDao().queryBuilder();
        return queryBuilder.count();
    }

    private boolean checkMusicExistInMusicInfo(int musicId) {
        return MusicInfoHelper.getInstance().checkFitmixMusicExist(musicId);
    }

    /**
     * 获得本地歌曲的音乐列表
     *
     * @return 列表
     */
    public List<LocalMusic> getLocalMusicList() {
        QueryBuilder<LocalMusic> queryBuilder = getLocalMusicDao().queryBuilder();
        queryBuilder.orderDesc(LocalMusicDao.Properties.MusicID);
        return queryBuilder.list();
    }

    /**
     * 获得本地歌曲的音乐id列表
     *
     * @return id列表
     */
    public List<Integer> getLocalMusicIDList() {
        QueryBuilder<LocalMusic> queryBuilder = getLocalMusicDao().queryBuilder();
        queryBuilder.orderDesc(LocalMusicDao.Properties.MusicID);
        List<LocalMusic> localMusicList = queryBuilder.list();
        List<Integer> musicIdList = new ArrayList<>();
        if (localMusicList != null) {
            for (LocalMusic localMusic : localMusicList) {
                if (!checkMusicExistInMusicInfo(localMusic.getMusicID())) continue;
                musicIdList.add(localMusic.getMusicID());
            }
        }
        return musicIdList;
    }

    public boolean checkLocalMusicExist(int musicID) {
        return getLocalMusicByID(musicID) != null;
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicID 音乐ID
     */
    public LocalMusic getLocalMusicByID(int musicID) {
        QueryBuilder<LocalMusic> queryBuilder = getLocalMusicDao().queryBuilder();
        queryBuilder.where(LocalMusicDao.Properties.MusicID.eq(musicID)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param localMusic 音乐信息
     */
    public void asyncWriteLocalMusic(LocalMusic localMusic) {
        if (localMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insertOrReplace(localMusic);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param localMusicList 音乐列表信息
     */
    public void asyncWriteLocalMusicList(List<LocalMusic> localMusicList) {
        if (localMusicList == null || localMusicList.isEmpty()) return;
        for (LocalMusic localMusic : localMusicList) {
            asyncWriteLocalMusic(localMusic);
        }
    }

    /**
     * 异步删除音乐信息
     *
     * @param localMusic 音乐信息
     */
    public void asyncDeleteLocalMusic(LocalMusic localMusic) {
        if (localMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.delete(localMusic);
    }

}
