package com.fitmix.sdk.model.database;

import android.database.Cursor;

import com.fitmix.sdk.MixApp;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * Created by yuanqiang on 2017/11/28. 保存发给屏蔽用户的用户信息
 */

public class ChatMessageResultBeanHelper {

    private static ChatMessageResultBeanHelper instance;
    private Cursor cursor;

    public static ChatMessageResultBeanHelper getInstance() {
        if (instance == null) {
            instance = new ChatMessageResultBeanHelper();
        }
        return instance;
    }

    public ChatMessageResultBeanDao getChatMessageResultBeanDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getChatMessageResultBeanDao();
    }

    public List<ChatMessageResultBean> getMessageInfoList() {
        QueryBuilder<ChatMessageResultBean> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getChatMessageResultBeanDao().queryBuilder();
        queryBuilder.orderAsc(ChatMessageResultBeanDao.Properties.AddTime).limit(30);


        List<ChatMessageResultBean> messageInfoList = queryBuilder.list();
        List<ChatMessageResultBean> messageInfoNewList = new ArrayList<>();
        if (messageInfoList != null) {
            messageInfoNewList.addAll(messageInfoList);
        }
        return messageInfoNewList;
    }


    public void cursorUpdate() {
        if (cursor != null && !cursor.isClosed()) cursor.requery();
    }

    /**
     * 异步删除消息
     *
     * @param messageInfo 消息
     */
    public void asyncDeleteMessageInfo(ChatMessageResultBean messageInfo) {
        if (messageInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.delete(messageInfo);
    }

    /**
     * 异步删除所有消息
     */
    public void asyncDeleteAllMessageInfo() {
        List<ChatMessageResultBean> chatMessageInfoList = getMessageInfoList();
        if (chatMessageInfoList != null) {
            for (ChatMessageResultBean chatMessageInfo : chatMessageInfoList) {
                asyncDeleteMessageInfo(chatMessageInfo);
            }
        }
    }

    /**
     * 异步添加或更新消息
     *
     * @param chatMessageInfo 消息
     */
    public void asyncWriteChatMessageInfo(ChatMessageResultBean chatMessageInfo) {
        if (chatMessageInfo == null) {
            return;
        }
        getChatMessageResultBeanDao().insertOrReplace(chatMessageInfo);
    }


    public boolean checkMessageInfoExist(String groupId) {
        return getChatMessageInfoListByID(groupId) == null;
    }

    /**
     * 根据groupId在messageInfo表中查找数据
     *
     * @param groupId 聊天组ID
     */
    public ChatMessageResultBean getChatMessageInfoListByID(String groupId) {
        QueryBuilder<ChatMessageResultBean> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getChatMessageResultBeanDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(ChatMessageResultBeanDao.Properties.GroupId.eq(groupId)).limit(1);
        return queryBuilder.unique();
    }


    /**
     * 异步添加或更新信息
     *
     * @param chatMessageInfoList 消息列表
     */
    public void asyncWriteChatMessageInfoList(List<ChatMessageResultBean> chatMessageInfoList) {
        if (chatMessageInfoList == null || chatMessageInfoList.isEmpty()) return;
        for (ChatMessageResultBean chatMessageInfo : chatMessageInfoList) {
            asyncWriteChatMessageInfo(chatMessageInfo);
        }
    }

}
