package com.fitmix.sdk.model.database;

import android.content.Context;
import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.bean.RunRecordList;
import com.fitmix.sdk.model.api.bean.SkipRecordList;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 运动记录帮助类,包括读写运动记录,读写运动中的轨迹记录,读写运动中的计步信息
 */
public class SportRecordsHelper {

//    private static SportRecordsHelper instance;
//
//    public static SportRecordsHelper getInstance() {
//        if (instance == null) {
//            instance = new SportRecordsHelper();
//        }
//        return instance;
//    }

    //region ================================== 跑步运动相关 ==================================

    /**
     * 从运动记录表(SportRecord)中,异步获取用户指定开始跑步时间的跑步记录
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     * @param listener     异步查询回调监听
     */
    public static void asyncGetRunRecords(Context context, int uid, long runStartTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跑步的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.StartTime.eq(runStartTime))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(qb.build());
    }

    /**
     * 从运动记录表(SportRecord)中,获取用户指定开始跑步时间的还未完成的跑步记录
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     * @return 满足条件的跑步记录
     */
    public static SportRecord getUncompletedRunRecords(Context context, int uid, long runStartTime) {
        //查找指定用户的未完成的并且运动类型为跑步的记录
        try {
            final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
            QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
            qb.where(SportRecordDao.Properties.Uid.eq(uid))
                    .where(SportRecordDao.Properties.StartTime.eq(runStartTime))
                    .where(SportRecordDao.Properties.Flag.eq(0))//未完成记录
                    .where(SportRecordDao.Properties.Type.eq(1))//1表示跑步
                    .limit(1);
            return qb.unique();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户所有的跑步记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncGetAllRunRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跑步的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户最近的n条的跑步记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param limit    限制的条数
     * @param listener 异步查询回调监听
     */
    public static void asyncGetLimitRunRecords(Context context, int uid, int limit, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跑步的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                .limit(limit)
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户尚未与服务器同步的跑步记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncUnSyncRunRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型但未同步的跑步记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                .where(SportRecordDao.Properties.Uploaded.eq(0))//未同步
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从运动记录表(SportRecord)中,同步获取用户上一次的跑步记录
     *
     * @param context 上下文
     * @param uid     用户uid
     * @return 上一次跑步记录
     */
    public static SportRecord getLastRunRecord(Context context, int uid) {
        if (context == null)
            return null;
        //查找指定用户的已完成的并且运动类型为跑步的运动记录
        try {
            final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
            QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
            qb.where(SportRecordDao.Properties.Uid.eq(uid))
                    .where(SportRecordDao.Properties.Flag.eq(1))
                    .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                    .orderDesc(SportRecordDao.Properties.StartTime)//倒序排列
                    .limit(1);
            return qb.unique();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户上一次的跑步记录
     *
     * @param context 上下文
     * @param uid     用户uid
     * @return 上一次跑步记录
     */
    public static void asyncGetLastRunRecord(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型但未同步的跑步记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                .orderDesc(SportRecordDao.Properties.StartTime)//倒序排列
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(qb.build());
    }


    /**
     * 批量添加或更新跑步记录到运动记录表(SportRecord)中
     *
     * @param runRecords 后台服务器返回的跑步记录列表集合
     * @return true:批量添加或更新成功,false:批量添加或更新失败
     */
    public static boolean bulkAddOrUpdateRunRecords(List<RunRecordList.RunRecord> runRecords) {
        if (runRecords == null || runRecords.size() <= 0) {
            return true;
        }
//        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        List<SportRecord> sportRecords = new ArrayList<>();
        //后台服务器返回的跑步记录实体(RunRecord)转换为数据库运动记录实体(SportRecord)
        for (RunRecordList.RunRecord runRecord : runRecords) {
            SportRecord sportRecord = new SportRecord();
            sportRecord.setUid(runRecord.getUid());//用户uid
            sportRecord.setStartTime(runRecord.getStartTime());//运动开始时间
            sportRecord.setEndTime(runRecord.getEndTime());//运动结束时间
            sportRecord.setFlag(1);//运动已结束,后台服务器给的都是
            sportRecord.setStartLat(runRecord.getStartLat());//开始点纬度
            sportRecord.setStartLng(runRecord.getStartLng());//开始点经度
            sportRecord.setEndLat(runRecord.getEndLat());//结束点纬度
            sportRecord.setEndLng(runRecord.getEndLng());//结束点经度
            sportRecord.setUploaded(1);//记录已同步,后台服务器给的都是
            sportRecord.setTrail(runRecord.getDetail());//轨迹文件下载路径
            sportRecord.setStepData(runRecord.getStepDetail());//计步文件下载url
            sportRecord.setLocationType(runRecord.getLocationType());//设置定位类型
            sportRecord.setDistance(runRecord.getDistance());//运动距离,单位米
            sportRecord.setRunTime(runRecord.getRunTime());//运动时长,单位为毫秒
            sportRecord.setMode(runRecord.getModel());//运动环境,1:室外,2:室内
            sportRecord.setStep(runRecord.getStep());//运动步数
            sportRecord.setCalorie(runRecord.getCalorie());//运动消耗卡路里
            sportRecord.setType(1);//运动类型为1表示跑步
            sportRecord.setBpm(runRecord.getBpm());//运动步频
            sportRecord.setBpmMatch(runRecord.getBpmMatch());//运动步频与运动音乐的匹配度
            sportRecord.setScore((int) runRecord.getMark());//运动成绩排名

            if (runRecord.getHeartRate() != null) {
                String heartRateString = JsonHelper.createJsonString(runRecord.getHeartRate());
                if (!TextUtils.isEmpty(heartRateString)) {
                    sportRecord.setHeartRateDate(heartRateString);//心率数据
                } else {
//                    Logger.e(Logger.DEBUG_TAG,"SportRecordsHelper-->heartRateString is empty");
                }
            }
            sportRecord.setConsumeFat(runRecord.getConsumeFat());//脂肪燃烧克数
            sportRecord.setElevation(runRecord.getElevation());//累积爬升

            sportRecords.add(sportRecord);
//            asyncSession.insertOrReplace(sportRecord);
        }
        try {
            MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao().insertOrReplaceInTx(sportRecords);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 从运动记录表(SportRecord)中,异步删除用户指定开始跑步时间的跑步记录
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     * @param listener     异步删除回调监听
     */
    public static void asyncDeleteRunRecord(Context context, int uid, long runStartTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        try {
            //查找指定用户并且运动类型为跑步的特定记录
            final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
            QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
            qb.where(SportRecordDao.Properties.Uid.eq(uid))
                    .where(SportRecordDao.Properties.Type.lt(2))//0或1表示跑步
                    .where(SportRecordDao.Properties.StartTime.eq(runStartTime));

            AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
            asyncSession.setListener(listener);
            asyncSession.delete(qb.build().unique());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加或更新运动信息到数据库表(SportRecord)中
     *
     * @param context     上下文
     * @param sportRecord 运动信息
     */
    public static void insertOrReplaceSportRecord(Context context, final SportRecord sportRecord) {
        if (context == null)
            return;
        if (sportRecord != null) {
            try {
                ThreadManager.executeOnSubThread1(new Runnable() {
                    @Override
                    public void run() {
                        MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao().insertOrReplace(sportRecord);
//                        Logger.i(Logger.DEBUG_TAG, "insertOrReplaceSportRecord uid:" + sportRecord.getUid() + " startTime:" + sportRecord.getStartTime()
//                                + " runTime:" + sportRecord.getRunTime() + " steps:" + sportRecord.getStep() + " distance:" + sportRecord.getDistance()
//                                + ",heartRateString:" + sportRecord.getHeartRateDate());
                    }
                });
            } catch (Exception e) {
                Logger.e(Logger.DEBUG_TAG, "SportRecordsHelper,insertOrReplaceSportRecord(),error-->" + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * 更新运动信息到数据库表(SportRecord)中,指定用户特定跑步记录的同步状态
     *
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     * @param uploaded     运动记录是否已同步到服务器,0:未同步,1:已同步,2:记录未完成
     */
    public static void updateSportRecordSyncState(final int uid, final long runStartTime, final int uploaded) {
        try {
            ThreadManager.executeOnSubThread1(new Runnable() {
                @Override
                public void run() {
                    String updateQuery = "update " + SportRecordDao.TABLENAME
                            + " set " + SportRecordDao.Properties.Uploaded.columnName + "=?"
                            + " where " + SportRecordDao.Properties.Uid.columnName + "=?"
                            + " and " + SportRecordDao.Properties.StartTime.columnName + "=?";

                    MixApp.getDaoMaster(MixApp.getContext()).getDatabase().execSQL(updateQuery,
                            new Object[]{uploaded, uid, runStartTime});
                    //重新刷新下状态
                    final SportRecordDao sportRecordDao = MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao();
                    QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
                    qb.where(SportRecordDao.Properties.Uid.eq(uid))
                            .where(SportRecordDao.Properties.StartTime.eq(runStartTime)).limit(1);
                    /** 解决bug:java.lang.NullPointerException: Entity may not be null*/
                    SportRecord sportRecord = qb.build().unique();
                    if (sportRecord != null) {
                        try {
                            MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao().refresh(sportRecord);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "updateSportRecordSyncState error");
            e.printStackTrace();
        }
    }

    /**
     * 从步数信息表(StepInfo)中,异步获取指定用户指定跑步记录的步数信息
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param startRunTime 运动开始时间,单位为毫秒
     * @param listener     异步查询回调监听
     */
    public static void asyncGetAllStepInfo(Context context, int uid, long startRunTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户指定跑步记录的步数信息
        final StepInfoDao stepInfoDao = MixApp.getDaoSession(context).getStepInfoDao();
        QueryBuilder<StepInfo> qb = stepInfoDao.queryBuilder();
        qb.where(StepInfoDao.Properties.Uid.eq(uid))
                .where(StepInfoDao.Properties.RunId.eq(startRunTime))
                .orderAsc(StepInfoDao.Properties.Time);//按时间戳顺序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从步数信息表(StepInfo)中,删除指定用户指定跑步记录的步数信息
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     */
    public static void deleteStepInfo(Context context, int uid, long runStartTime) {
        if (context == null)
            return;
        //查找指定用户指定跑步记录的步数信息
        try {
            final StepInfoDao stepInfoDao = MixApp.getDaoSession(context).getStepInfoDao();
            QueryBuilder<StepInfo> qb = stepInfoDao.queryBuilder();
            qb.where(StepInfoDao.Properties.Uid.eq(uid))
                    .where(StepInfoDao.Properties.RunId.eq(runStartTime));

            stepInfoDao.deleteInTx(qb.list());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 从步数信息表(StepInfo)中,删除全部步数信息
     *
     * @param context 上下文
     */
    public static void deleteStepInfo(Context context) {
        if (context == null)
            return;

        final StepInfoDao stepInfoDao = MixApp.getDaoSession(context).getStepInfoDao();
        ThreadManager.executeOnFileThread(new Runnable() {
            @Override
            public void run() {
                try {
                    stepInfoDao.deleteAll();
                } catch (Exception e) {
                    e.printStackTrace();
                    Logger.e(Logger.DEBUG_TAG, "deleteStepInfo e:" + e.getMessage());
                }
            }
        });

    }

    /**
     * 写入步数信息到数据库表(StepInfo)中
     *
     * @param context  上下文
     * @param stepInfo 步数信息
     */
    public static void writeStepInfo(Context context, final StepInfo stepInfo) {
        if (context == null)
            return;
        if (stepInfo != null) {
            ThreadManager.executeOnSubThread1(new Runnable() {
                @Override
                public void run() {
                    try {
//                        Logger.i(Logger.DEBUG_TAG, "writeStepInfo uid:" + stepInfo.getUid()
//                                + ",runId:" + stepInfo.getRunId() + ",steps:" + stepInfo.getSteps()
//                                + ",distance:" + stepInfo.getDistance() + ",time:" + stepInfo.getTime() + ",id:" + stepInfo.getId());
                        MixApp.getDaoSession(MixApp.getContext()).getStepInfoDao().insert(stepInfo);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Logger.e(Logger.DEBUG_TAG, "writeStepInfo error:" + e.getMessage());
                    }
                }
            });

        }
    }

    /**
     * 从轨迹点信息表(TrailPoint)中,异步获取指定用户指定跑步记录的轨迹信息
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param startRunTime 运动开始时间,单位为毫秒
     * @param listener     异步查询回调监听
     */
    public static void asyncGetAllTrailPoint(Context context, int uid, long startRunTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户指定跑步记录的轨迹点信息
        final TrailPointDao trailPointDao = MixApp.getDaoSession(context).getTrailPointDao();
        QueryBuilder<TrailPoint> qb = trailPointDao.queryBuilder();
        qb.where(TrailPointDao.Properties.Uid.eq(uid))
                .where(TrailPointDao.Properties.RunId.eq(startRunTime))
                .orderAsc(TrailPointDao.Properties.Time);//按时间戳顺序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从轨迹点信息表(TrailPoint)中,删除指定用户指定跑步记录的轨迹信息
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     */
    public static void deleteTrailPoints(Context context, int uid, long runStartTime) {
        if (context == null)
            return;
        //查找指定用户指定跑步记录的轨迹点信息
        final TrailPointDao trailPointDao = MixApp.getDaoSession(context).getTrailPointDao();
        QueryBuilder<TrailPoint> qb = trailPointDao.queryBuilder();
        qb.where(TrailPointDao.Properties.Uid.eq(uid))
                .where(TrailPointDao.Properties.RunId.eq(runStartTime))
                .orderAsc(TrailPointDao.Properties.Time);//按时间戳顺序排列

        trailPointDao.deleteInTx(qb.list());
    }

    /**
     * 从轨迹点信息表(TrailPoint)中,删除全部轨迹信息
     *
     * @param context 上下文
     */
    public static void deleteTrailPoints(Context context) {
        if (context == null)
            return;
        try {
            final TrailPointDao trailPointDao = MixApp.getDaoSession(context).getTrailPointDao();
            ThreadManager.executeOnFileThread(new Runnable() {
                @Override
                public void run() {
                    trailPointDao.deleteAll();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 写入轨迹点信息到数据库表(TrailPoint)中
     *
     * @param context    上下文
     * @param trailPoint 轨迹点信息
     */
    public static void writeTrailPoint(Context context, final TrailPoint trailPoint) {
        if (context == null)
            return;
        if (trailPoint != null) {
            try {
                ThreadManager.executeOnSubThread1(new Runnable() {
                    @Override
                    public void run() {
                        /** Bug:android.database.sqlite.SQLiteCantOpenDatabaseException: unable to open database file (code 14)
                         * at android.database.sqlite.SQLiteConnection.nativeExecute(Native Method)
                         * at android.database.sqlite.SQLiteConnection.execute(SQLiteConnection.java:552)
                         * at android.database.sqlite.SQLiteSession.beginTransactionUnchecked(SQLiteSession.java:323)
                         * at android.database.sqlite.SQLiteSession.beginTransaction(SQLiteSession.java:298)
                         * at android.database.sqlite.SQLiteDatabase.beginTransaction(SQLiteDatabase.java:505)
                         * at android.database.sqlite.SQLiteDatabase.beginTransaction(SQLiteDatabase.java:416)
                         * at de.greenrobot.dao.AbstractDao.executeInsert(AbstractDao.java:347)
                         * at de.greenrobot.dao.AbstractDao.insert(AbstractDao.java:294)
                         * at com.fitmix.sdk.model.database.SportRecordsHelper$6.run(SportRecordsHelper.java:496)
                         * at android.os.Handler.handleCallback(Handler.java:725)
                         * at android.os.Handler.dispatchMessage(Handler.java:92)
                         * at android.os.Looper.loop(Looper.java:153)
                         * at android.os.HandlerThread.run(HandlerThread.java:60)*/
                        try {
//                            Logger.i(Logger.DEBUG_TAG, "writeTrailPoint uid:" + trailPoint.getUid()
//                                    + ",runId:" + trailPoint.getRunId() + ",id:" + trailPoint.getId());
                            MixApp.getDaoSession(MixApp.getContext()).getTrailPointDao().insert(trailPoint);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Logger.e(Logger.DEBUG_TAG, "writeTrailPoint error:" + e.getMessage());
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //endregion ================================== 跑步运动相关 ==================================

    //region ================================== 跳绳运动相关 ==================================

    /**
     * 从运动记录表(SportRecord)中,异步删除用户指定开始跑步时间的跳绳记录
     *
     * @param context       上下文
     * @param uid           用户uid
     * @param skipStartTime 跳绳开始时间,单位为毫秒
     * @param listener      异步删除回调监听
     */
    public static void asyncDeleteSkipRecord(Context context, int uid, long skipStartTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        try {
            //查找指定用户并且运动类型为跳绳的特定记录
            final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
            QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
            qb.where(SportRecordDao.Properties.Uid.eq(uid))
                    .where(SportRecordDao.Properties.Type.eq(2))//2表示跳绳
                    .where(SportRecordDao.Properties.StartTime.eq(skipStartTime));

            AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
            asyncSession.setListener(listener);
            asyncSession.delete(qb.build().unique());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户指定开始跳绳时间的跳绳记录
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跳绳开始时间,单位为毫秒
     * @param listener     异步查询回调监听
     */
    public static void asyncGetSkipRecords(Context context, int uid, long runStartTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跳绳的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.StartTime.eq(runStartTime))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.eq(2))//2表示跳绳
                .limit(1);

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryUnique(qb.build());
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户最近的n条的跳绳记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param limit    限制的条数
     * @param listener 异步查询回调监听
     */
    public static void asyncGetLimitSkipRecords(Context context, int uid, int limit, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跳绳的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.eq(2))//2表示跳绳
                .limit(limit)
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从跳绳信息表(SkipInfo)中,删除指定用户指定跳绳记录的跳绳信息
     *
     * @param context       上下文
     * @param uid           用户uid
     * @param skipStartTime 跳绳开始时间,单位为毫秒
     */
    public static void deleteSkipInfo(Context context, int uid, long skipStartTime) {
        if (context == null)
            return;
        //查找指定用户指定跳绳记录的步数信息
        final SkipInfoDao skipInfoDao = MixApp.getDaoSession(context).getSkipInfoDao();
        QueryBuilder<SkipInfo> qb = skipInfoDao.queryBuilder();
        qb.where(SkipInfoDao.Properties.Uid.eq(uid))
                .where(SkipInfoDao.Properties.SkipId.eq(skipStartTime));

        skipInfoDao.deleteInTx(qb.list());
//        stepInfoDao.deleteAll();
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户尚未与服务器同步的跳绳记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncUnSyncSkipRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型但未同步的跳绳记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.eq(2))//2 表示跳绳
                .where(SportRecordDao.Properties.Uploaded.eq(0))//未同步
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 从跳绳信息表(SkipInfo)中,异步获取指定用户指定跳绳的计数信息
     *
     * @param context       上下文
     * @param uid           用户uid
     * @param startSkipTime 运动开始时间,单位为毫秒
     * @param listener      异步查询回调监听
     */
    public static void asyncGetAllSkipInfo(Context context, int uid, long startSkipTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户指定跳绳记录的步数信息
        final SkipInfoDao skipInfoDao = MixApp.getDaoSession(context).getSkipInfoDao();
        QueryBuilder<SkipInfo> qb = skipInfoDao.queryBuilder();
        qb.where(SkipInfoDao.Properties.Uid.eq(uid))
                .where(SkipInfoDao.Properties.SkipId.eq(startSkipTime))
                .orderAsc(SkipInfoDao.Properties.SkipNumber);//按时间戳顺序排列
        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 异步写入跳绳信息到数据库表(SkipInfo)中
     *
     * @param context  上下文
     * @param skipInfo 跳绳信息
     */
    public static void writeSkipInfo(Context context, final SkipInfo skipInfo) {
        if (context == null)
            return;
        if (skipInfo != null) {
            try {
                ThreadManager.executeOnSubThread1(new Runnable() {
                    @Override
                    public void run() {
                        Logger.i(Logger.DEBUG_TAG, "writeSkipInfo");
                        MixApp.getDaoSession(MixApp.getContext()).getSkipInfoDao().insert(skipInfo);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                Logger.e(Logger.DEBUG_TAG, "writeSkipInfo error:" + e.getMessage());
            }
        }
    }

    /**
     * 同步写入跳绳信息到数据库表(SkipInfo)中
     *
     * @param context  上下文
     * @param skipInfo 跳绳信息
     */
    public static void writeSkipInfoSync(Context context, final SkipInfo skipInfo) {
        if (context == null)
            return;
        if (skipInfo != null) {
            Logger.i(Logger.DEBUG_TAG, "SkipService --->writeSkipInfo");
            MixApp.getDaoSession(MixApp.getContext()).getSkipInfoDao().insert(skipInfo);
        }
    }

    /**
     * 从运动记录表(SportRecord)中,异步获取用户所有的跳绳记录
     *
     * @param context  上下文
     * @param uid      用户uid
     * @param listener 异步查询回调监听
     */
    public static void asyncGetAllSkipRecords(Context context, int uid, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户的已完成的并且运动类型为跳绳的记录
        final SportRecordDao sportRecordDao = MixApp.getDaoSession(context).getSportRecordDao();
        QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
        qb.where(SportRecordDao.Properties.Uid.eq(uid))
                .where(SportRecordDao.Properties.Flag.eq(1))
                .where(SportRecordDao.Properties.Type.eq(2))//2表示跳绳
                .orderDesc(SportRecordDao.Properties.StartTime);//倒序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());
    }

    /**
     * 更新运动信息到数据库表(SportRecord)中,指定用户特定跳绳记录的同步状态
     *
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     * @param uploaded     运动记录是否已同步到服务器,0:未同步,1:已同步,2:记录未完成
     */
    public static void updateSkipSportRecordSyncState(final int uid, final long runStartTime, final String skipDetail, final int uploaded) {
        try {
            ThreadManager.executeOnSubThread1(new Runnable() {
                @Override
                public void run() {
                    SportRecordDao sportRecordDao = MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao();
                    QueryBuilder<SportRecord> qb = sportRecordDao.queryBuilder();
                    qb.where(SportRecordDao.Properties.Uid.eq(uid))
                            .where(SportRecordDao.Properties.StartTime.eq(runStartTime))
                            .where(SportRecordDao.Properties.Type.eq(2))//2表示跳绳
                            .limit(1);
                    SportRecord sportRecord = qb.build().unique();
                    sportRecord.setUploaded(uploaded);
                    sportRecord.setStepData(skipDetail);
                    MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao().insertOrReplace(sportRecord);
                }
            });
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "updateSportRecordSyncState error");
            e.printStackTrace();
        }
    }

    /**
     * 批量添加或更新跳绳记录到运动记录表(SportRecord)中
     *
     * @param skipRecords 后台服务器返回的跳绳记录列表集合
     * @return true:批量添加或更新成功,false:批量添加或更新失败
     */
    public static boolean bulkAddOrUpdateSkipRecords(List<SkipRecordList.SkipRecord> skipRecords) {
        if (skipRecords == null || skipRecords.size() <= 0) {
            return true;
        }
//        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        List<SportRecord> sportRecords = new ArrayList<>();
        //后台服务器返回的跳绳记录实体(SkipRecord)转换为数据库运动记录实体(SportRecord)
        for (SkipRecordList.SkipRecord skipRecord : skipRecords) {
            SportRecord sportRecord = new SportRecord();
            sportRecord.setUid(skipRecord.getUid());//用户uid
            sportRecord.setStartTime(skipRecord.getStartTime());//运动开始时间
            sportRecord.setEndTime(skipRecord.getEndTime());//运动结束时间
            sportRecord.setFlag(1);//运动已结束,后台服务器给的都是
            sportRecord.setUploaded(1);//记录已同步,后台服务器给的都是
            sportRecord.setStepData(skipRecord.getSkipDetail());//跳绳计数文件下载url
            sportRecord.setRunTime((long) skipRecord.getRunTime());//运动时长,单位为毫秒
            sportRecord.setStep(skipRecord.getSkipNum());//设置跳绳个数
            sportRecord.setCalorie((long) skipRecord.getCalorie());//运动消耗卡路里
            sportRecord.setType(2);//运动类型为2表示跳绳
            sportRecord.setBpm(skipRecord.getBpm());//运动跳频
            sportRecords.add(sportRecord);

            if (skipRecord.getHeartRate() != null) {
                String heartRateString = JsonHelper.createJsonString(skipRecord.getHeartRate());
                if (!TextUtils.isEmpty(heartRateString)) {
                    sportRecord.setHeartRateDate(heartRateString);//心率数据
                }
            }

//            asyncSession.insertOrReplace(sportRecord);
        }
        try {
            MixApp.getDaoSession(MixApp.getContext()).getSportRecordDao().insertOrReplaceInTx(sportRecords);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    //endregion ================================== 跳绳运动相关 ==================================

    //region ================================== 心率运动相关 ==================================

    /**
     * 插入心率记录
     *
     * @param context
     * @param heartRateInfo
     */
    public static void writeHeartRateInfo(Context context, final HeartRateInfo heartRateInfo) {
        if (context == null)
            return;
        if (heartRateInfo != null) {
            try {
                ThreadManager.executeOnSubThread1(new Runnable() {
                    @Override
                    public void run() {
                        MixApp.getDaoSession(MixApp.getContext()).getHeartRateInfoDao().insert(heartRateInfo);
//                        Logger.i(Logger.DEBUG_TAG,"writeStepInfo uid:"+stepInfo.getUid() +" runId:"+ stepInfo.getRunId() + " steps:"+stepInfo.getSteps());
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                Logger.e(Logger.DEBUG_TAG, "writeStepInfo error:" + e.getMessage());
            }
        }
    }

    /**
     * 异步搜索心率数据
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param startRunTime 运动开始时间戳
     * @param listener     查询回调
     */
    public static void asyncGetAllHeartRateInfo(Context context, int uid, long startRunTime, AsyncOperationListener listener) {
        if (context == null)
            return;
        //查找指定用户指定心率记录的心率信息
        final HeartRateInfoDao heartRateInfoDao = MixApp.getDaoSession(context).getHeartRateInfoDao();
        QueryBuilder<HeartRateInfo> qb = heartRateInfoDao.queryBuilder();
        qb.where(HeartRateInfoDao.Properties.Uid.eq(uid))
                .where(HeartRateInfoDao.Properties.RunId.eq(startRunTime))
                .orderAsc(HeartRateInfoDao.Properties.Time);//按时间戳顺序排列

        AsyncSession asyncSession = MixApp.getDaoSession(context).startAsyncSession();
        asyncSession.setListener(listener);
        asyncSession.queryList(qb.build());

    }

    /**
     * 从运动心率信息表(HeartRateInfo)中,删除指定用户指定跑心率记录的心率信息
     *
     * @param context      上下文
     * @param uid          用户uid
     * @param runStartTime 跑步开始时间,单位为毫秒
     */
    public static void deleteHeartRateInfo(Context context, int uid, long runStartTime) {
        if (context == null)
            return;
        try {
            final HeartRateInfoDao heartRateInfoDao = MixApp.getDaoSession(context).getHeartRateInfoDao();
            QueryBuilder<HeartRateInfo> qb = heartRateInfoDao.queryBuilder();
            qb.where(HeartRateInfoDao.Properties.Uid.eq(uid))
                    .where(HeartRateInfoDao.Properties.RunId.eq(runStartTime));

            heartRateInfoDao.deleteInTx(qb.list());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 从运动心率信息表(HeartRateInfo)中,删除全部心率信息
     *
     * @param context 上下文
     */
    public static void deleteHeartRateInfo(Context context) {
        if (context == null)
            return;
        try {
            final HeartRateInfoDao heartRateInfoDao = MixApp.getDaoSession(context).getHeartRateInfoDao();
            ThreadManager.executeOnFileThread(new Runnable() {
                @Override
                public void run() {
                    heartRateInfoDao.deleteAll();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //endregion ================================== 心率运动相关 ==================================
}
