package com.fitmix.sdk.model.database;

import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.manager.UserDataManager;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.Query;


/**
 * 用户参数设置帮助工具类,数据保存在SettingConfigs表中
 */
public class SettingsHelper {

    /**
     * 参数值数据类型,布尔类型
     */
    public static final int VALUE_TYPE_BOOLEAN = 0;
    /**
     * 参数值数据类型,int类型
     */
    public static final int VALUE_TYPE_INT = 1;
    /**
     * 参数值数据类型,long类型
     */
    public static final int VALUE_TYPE_LONG = 2;
    /**
     * 参数值数据类型,float类型
     */
    public static final int VALUE_TYPE_FLOAT = 3;
    /**
     * 参数值数据类型,double类型
     */
    public static final int VALUE_TYPE_DOUBLE = 4;
    /**
     * 参数值数据类型,String类型
     */
    public static final int VALUE_TYPE_STRING = 5;

    /**
     * 根据用户uid和参数名,获取相应的用户参数配置信息
     *
     * @param uid 用户Uid
     * @param key 参数名
     * @return 用户参数配置信息, 注意null值判断
     */
    private static SettingConfigs getSettingsByUidAndKey(int uid, String key) {
        SettingConfigs settingConfigs = null;
        SettingConfigsDao settingConfigsDao = MixApp.getDaoSession(MixApp.getContext()).getSettingConfigsDao();
        Query query = settingConfigsDao.queryBuilder().where(
                SettingConfigsDao.Properties.Uid.eq(uid),
                SettingConfigsDao.Properties.Key.eq(key))
                .build();
        try {
            settingConfigs = (SettingConfigs) query.unique();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (ex.getMessage() != null) {
                Logger.e(Logger.DEBUG_TAG, "getSettingsByUidAndKey error" + ex.getMessage());
            }
        }
        return settingConfigs;
    }

    /**
     * 异步写用户参数配置信息
     *
     * @param settingConfigs 用户参数配置信息
     */
    private static void asyncWriteSettings(final SettingConfigs settingConfigs) {
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                // do whats needed
                String info = String.format(" %s: %s", settingConfigs.getKey(), settingConfigs.getValue());
                switch (settingConfigs.getType()) {
                    case VALUE_TYPE_BOOLEAN:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putBoolean onAsyncOperationCompleted" + info);
                        break;
                    case VALUE_TYPE_INT:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putInt onAsyncOperationCompleted" + info);
                        break;
                    case VALUE_TYPE_LONG:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putLong onAsyncOperationCompleted" + info);
                        break;
                    case VALUE_TYPE_FLOAT:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putFloat onAsyncOperationCompleted" + info);
                        break;
                    case VALUE_TYPE_DOUBLE:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putDouble onAsyncOperationCompleted" + info);
                        break;
                    case VALUE_TYPE_STRING:
                        Logger.i(Logger.DEBUG_TAG, "SettingsHelper-->putString onAsyncOperationCompleted" + info);
                        break;
                }
            }
        });
        asyncSession.insertOrReplace(settingConfigs);
    }
    //region ========================================== 读写Boolean型参数 ==========================================

    /**
     * 保存boolean型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putBoolean(int uid, String key, boolean value) {
        String valueStr = String.valueOf(value);
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_BOOLEAN, valueStr);
        } else {
            settingConfigs.setValue(valueStr);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存boolean型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putBoolean(String key, boolean value) {
        int uid = UserDataManager.getUid();
        putBoolean(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的boolean参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return boolean参数值
     */
    public static boolean getBoolean(int uid, String key, boolean defValue) {
        boolean ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = Boolean.parseBoolean(value);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的boolean参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return boolean参数值
     */
    public static boolean getBoolean(String key, boolean defValue) {
        int uid = UserDataManager.getUid();
        return getBoolean(uid, key, defValue);
    }

    //endregion ========================================== 读写Boolean型参数 ==========================================

    //region ========================================== 读写int型参数 ==========================================

    /**
     * 保存int型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putInt(int uid, String key, int value) {
        String valueStr = String.valueOf(value);
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_INT, valueStr);
        } else {
            settingConfigs.setValue(valueStr);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存int型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putInt(String key, int value) {
        int uid = UserDataManager.getUid();
        putInt(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的int参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return int参数值
     */
    public static int getInt(int uid, String key, int defValue) {
        int ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = Integer.parseInt(value);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的int参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return int参数值
     */
    public static int getInt(String key, int defValue) {
        int uid = UserDataManager.getUid();
        return getInt(uid, key, defValue);
    }

    //endregion ========================================== 读写int型参数 ==========================================

    //region ========================================== 读写long型参数 ==========================================

    /**
     * 保存long型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putLong(int uid, String key, long value) {
        String valueStr = String.valueOf(value);
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_LONG, valueStr);
        } else {
            settingConfigs.setValue(valueStr);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存long型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putLong(String key, long value) {
        int uid = UserDataManager.getUid();
        putLong(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的long参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return long参数值
     */
    public static long getLong(int uid, String key, long defValue) {
        long ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = Long.parseLong(value);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的long参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return long参数值
     */
    public static long getLong(String key, long defValue) {
        int uid = UserDataManager.getUid();
        return getLong(uid, key, defValue);
    }

    //endregion ========================================== 读写long型参数 ==========================================

    //region ========================================== 读写float型参数 ==========================================

    /**
     * 保存float型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putFloat(int uid, String key, float value) {
        String valueStr = String.valueOf(value);
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_FLOAT, valueStr);
        } else {
            settingConfigs.setValue(valueStr);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存float型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putFloat(String key, float value) {
        int uid = UserDataManager.getUid();
        putFloat(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的float参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return float参数值
     */
    public static float getFloat(int uid, String key, float defValue) {
        float ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = Float.parseFloat(value);
                } catch (NumberFormatException e) {
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的float参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return float参数值
     */
    public static float getFloat(String key, float defValue) {
        int uid = UserDataManager.getUid();
        return getFloat(uid, key, defValue);
    }

    //endregion ========================================== 读写float型参数 ==========================================

    //region ========================================== 读写double型参数 ==========================================

    /**
     * 保存double型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putDouble(int uid, String key, double value) {
        String valueStr = String.valueOf(value);
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_DOUBLE, valueStr);
        } else {
            settingConfigs.setValue(valueStr);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存double型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putDouble(String key, double value) {
        int uid = UserDataManager.getUid();
        putDouble(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的double参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return double参数值
     */
    public static double getDouble(int uid, String key, double defValue) {
        double ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = Double.parseDouble(value);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的double参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return double参数值
     */
    public static double getDouble(String key, double defValue) {
        int uid = UserDataManager.getUid();
        return getDouble(uid, key, defValue);
    }

    //endregion ========================================== 读写double型参数 ==========================================

    //region ========================================== 读写String型参数 ==========================================

    /**
     * 保存String型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param uid   用户Uid
     * @param key   参数名
     * @param value 参数值
     */
    public static void putString(int uid, String key, String value) {
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs == null) {
            settingConfigs = new SettingConfigs(null, uid, key, VALUE_TYPE_STRING, value);
        } else {
            settingConfigs.setValue(value);
        }
        asyncWriteSettings(settingConfigs);
    }

    /**
     * 保存String型参数到数据库用户参数配置表(SettingConfigs)
     *
     * @param key   参数名
     * @param value 参数值
     */
    public static void putString(String key, String value) {
        int uid = UserDataManager.getUid();
        putString(uid, key, value);
    }

    /**
     * 根据用户uid,参数名获取对应的String参数值
     *
     * @param uid      用户Uid
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return String参数值
     */
    public static String getString(int uid, String key, String defValue) {
        String ret = defValue;
        SettingConfigs settingConfigs = getSettingsByUidAndKey(uid, key);
        if (settingConfigs != null) {
            String value = settingConfigs.getValue();
            if (!TextUtils.isEmpty(value)) {
                try {
                    ret = value;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }

    /**
     * 根据参数名获取当前用户对应的String参数值
     *
     * @param key      参数名
     * @param defValue 默认的参数值
     * @return String参数值
     */
    public static String getString(String key, String defValue) {
        int uid = UserDataManager.getUid();
        return getString(uid, key, defValue);
    }

    //endregion ========================================== 读写String型参数 ==========================================

}
