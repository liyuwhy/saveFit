package com.fitmix.sdk.model.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.MusicParserUtil;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


/**
 * 音乐信息帮助类 信息保存在MusicInfo中
 */
public class MusicInfoHelper {
    public static final int MUSIC_LOCALE_START_ID = 100000;
    private static MusicInfoHelper instance;

    public static MusicInfoHelper getInstance() {
        if (instance == null) {
            instance = new MusicInfoHelper();
        }
        return instance;
    }

    public MusicInfoDao getMusicInfoDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao();
    }

    /**
     * 获取下一个自定义歌曲的id号
     *
     * @return 歌曲id号
     */
    public int getNextLocaleMusicId() {
        String sql = "select max(MUSIC_ID) as max_id from MUSIC_INFO";
        int max_id = getIntFiledBySql(sql, "max_id", 0);
        if (max_id < MUSIC_LOCALE_START_ID) max_id = MUSIC_LOCALE_START_ID;
        return max_id + 1;
    }

    private int getIntFiledBySql(String sSql, String sField, int defaultValue) {
        int iValue = defaultValue;
        if (sSql == null || sSql.isEmpty() || sField == null
                || sField.isEmpty())
            return iValue;
        Cursor cursor = null;
        SQLiteDatabase db;
        try {
            db = getMusicInfoDao().getDatabase();
            if (db != null) {
                cursor = db.rawQuery(sSql, null);
            }
            if (!(cursor == null || cursor.isClosed())) {
                if (cursor.moveToFirst())
                    iValue = cursor.getInt(cursor.getColumnIndex(sField));
            }
            if (cursor != null) {
                cursor.close();
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return iValue;

    }

    public boolean checkFitmixMusicExist(int musicID) {
        return getMusicByID(musicID) != null;
    }

    /**
     * 根据 music 插入最近播放的数据
     *
     * @param music 进行操作的音乐
     */
    public void insertMusic(Music music) {
        asyncWriteMusicInfo(music);
    }

    /**
     * 根据 musicID 删除本地歌曲的数据
     *
     * @param musicID 进行操作的音乐ID
     */
    public void deleteMusic(int musicID) {
        asyncDeleteMusicInfo(getMusicByID(musicID));
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicID 音乐ID
     * @return Music音乐信息, 注意空值判断
     */
    public Music getMusicByID(int musicID) {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.MusicID.eq(musicID)).limit(1);
        MusicInfo musicInfo = queryBuilder.unique();
        return MusicParserUtil.getInstance().getMusicByMusicInfo(musicInfo);
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicID 音乐ID
     * @return MusicInfo音乐信息, 注意空值判断
     */
    public MusicInfo getMusicInfoByID(int musicID) {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.MusicID.eq(musicID)).limit(1);
        return queryBuilder.unique();
    }

    /**
     * 根据Url在musicInfo表中查找数据
     *
     * @param Url 音乐路径
     */
    public Music getMusicByUrl(String Url) {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.Url.eq(Url)).limit(1);
        MusicInfo musicInfo = queryBuilder.unique();
        return MusicParserUtil.getInstance().getMusicByMusicInfo(musicInfo);
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicList 音乐列表
     * @return
     */
    public void setMusicList(List<Music> musicList) {
        asyncWriteMusicInfoList(musicList);
    }

    /**
     * 根据Id列表在musicInfo表中查找数据
     *
     * @param musicIdList 音乐ID列表
     * @return
     */
    public List<Music> getMusicListByIdList(List<Integer> musicIdList) {
        List<Music> musicList = new ArrayList<>();
        if (musicIdList == null || musicIdList.size() <= 0) return musicList;
        for (Integer musicID : musicIdList) {
            if (getMusicByID(musicID) == null) continue;
            musicList.add(getMusicByID(musicID));
        }
        return musicList;
    }

    /**
     * @return 本地音乐
     */
    public List<Music> getMusicByLocalFlag() {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.LocalFlag.eq(1));
        List<MusicInfo> musicInfoList = queryBuilder.list();
        return MusicParserUtil.getInstance().getMusicListByMusicInfoList(musicInfoList);
    }

    /**
     * 删除所有本地音乐
     */
    public void deleteMusicByLocalFlag() {
        String sSql = "DELETE FROM MUSIC_INFO WHERE LOCAL_FLAG = 1";
        MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().getDatabase().execSQL(sSql);
    }

    /**
     * 根据scene在musicInfo表中查找数据
     *
     * @param scene 音乐风格
     * @return 音乐列表
     */
    public List<Music> getMusicByScene(int scene) {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.Scene.eq("," + scene + ","));
        List<MusicInfo> musicInfoList = queryBuilder.list();
        return MusicParserUtil.getInstance().getMusicListByMusicInfoList(musicInfoList);
    }

    public List<MusicInfo> getMusicLocal() {
        QueryBuilder<MusicInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().queryBuilder();
        queryBuilder.where(MusicInfoDao.Properties.LocalFlag.eq(1));
        List<MusicInfo> list = queryBuilder.list();
        if (list == null) list = new ArrayList<>();
        return list;
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param music 音乐
     */
    public void asyncWriteMusicInfo(Music music) {
        if (music == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                // do whats needed
            }
        });
        MusicInfo musicInfo = MusicParserUtil.getInstance().getMusicInfoByMusic(music);
        if (musicInfo == null) {
            return;
        }
        if (musicInfo.getMusicID() == 0) {
            musicInfo.setMusicID(getNextLocaleMusicId());
        }
        asyncSession.insertOrReplace(musicInfo);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param musicList 音乐列表信息
     */
    public void asyncWriteMusicInfoList(List<Music> musicList) {
        if (musicList == null || musicList.isEmpty()) return;
        for (Music music : musicList) {
            asyncWriteMusicInfo(music);
        }
    }

    /**
     * 异步删除音乐信息
     *
     * @param music 音乐信息
     */
    public void asyncDeleteMusicInfo(Music music) {
        if (music == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                // do whats needed
            }
        });
        asyncSession.delete(MusicParserUtil.getInstance().getMusicInfoByMusic(music));
    }

    /**
     * 添加或更新音乐信息
     *
     * @param musicInfo 音乐信息
     */
    public void asyncWriteMusicInfo(MusicInfo musicInfo) {
        if (musicInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.insertOrReplace(musicInfo);
    }

    /**
     * 线程阻塞的方式更新
     *
     * @param musicInfo
     */
    public void writeMusicInfo(MusicInfo musicInfo) {
        if (musicInfo == null) {
            return;
        }
        MixApp.getDaoSession(MixApp.getContext()).getMusicInfoDao().insertOrReplace(musicInfo);
    }

    /**
     * 删除音乐信息
     *
     * @param musicInfo 音乐信息
     */
    public void asyncDeleteMusicInfo(MusicInfo musicInfo) {
        if (musicInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.delete(musicInfo);
    }

}
