package com.fitmix.sdk.model.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.view.bean.Album;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.CountQuery;
import de.greenrobot.dao.query.QueryBuilder;


public class CustomAlbumHelper {

    private static CustomAlbumHelper instance;

    public static CustomAlbumHelper getInstance() {
        if (instance == null) {
            instance = new CustomAlbumHelper();
        }
        return instance;
    }

    public CustomAlbumDao getCustomAlbumDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumDao();
    }

    public List<Album> getAlbumList() {
        QueryBuilder<CustomAlbum> queryBuilder = getCustomAlbumDao().queryBuilder();
        queryBuilder.orderDesc(CustomAlbumDao.Properties.AlbumID);
        List<CustomAlbum> customAlbumList = queryBuilder.list();
        List<Album> albumList = new ArrayList<>();
        if (customAlbumList != null && customAlbumList.size() > 0) {
            for (CustomAlbum customAlbum : customAlbumList) {
                albumList.add(customAlbumToAlbum(customAlbum));
            }
        }
        return albumList;
    }

    private Album customAlbumToAlbum(CustomAlbum customAlbum) {
        Album album = new Album();
        if (customAlbum != null) {
            album.setId(customAlbum.getAlbumID());
            album.setName(customAlbum.getAlbumName());
            Album.AlbumInfo albumInfo = new Album.AlbumInfo();
            albumInfo.setImage(customAlbum.getCorverPath());
            albumInfo.setDesc(customAlbum.getDescription());
            album.setAlbumInfo(albumInfo);
            album.setValue(customAlbum.getScene());
        }
        return album;
    }

    private CustomAlbum albumToCustomAlbum(Album album) {
        CustomAlbum customAlbum = new CustomAlbum();
        if (album != null) {
            customAlbum.setAlbumID(album.getId());
            customAlbum.setAlbumName(album.getName());
            customAlbum.setScene(album.getValue());
            if (album.getAlbumInfo() != null) {
                customAlbum.setCorverPath(album.getAlbumInfo().getImage());
                customAlbum.setDescription(album.getAlbumInfo().getDesc());
            }
        }
        return customAlbum;
    }

    /**
     * 插入一个新的自建专辑
     *
     * @param album 自建的专辑
     */
    public void insertCustomAlbum(Album album) {
        asyncWriteCustomAlbum(albumToCustomAlbum(album));
    }

    /**
     * 删除一个自建专辑
     *
     * @param albumID 自建的专辑的ID
     */
    public void deleteCustomAlbum(int albumID, AsyncOperationListener asyncOperationListener) {
        asyncDeleteAlbum(getAlbumByID(albumID), asyncOperationListener);
    }

    /**
     * 更新一个自建专辑的信息
     *
     * @param album 自建专辑
     */
    public void updateCustomAlbum(Album album, AsyncOperationListener asyncOperationListener) {
        if (album == null) {
            return;
        }
        CustomAlbum customAlbum = getAlbumByID(album.getId());
        if (customAlbum == null)
            return;
        if (!TextUtils.isEmpty(album.getName())) {
            customAlbum.setAlbumName(album.getName());
        }
        if (!TextUtils.isEmpty(album.getAlbumInfo().getImage())) {
            customAlbum.setCorverPath(album.getAlbumInfo().getImage());
        }
        if (!TextUtils.isEmpty(album.getAlbumInfo().getDesc())) {
            customAlbum.setDescription(album.getAlbumInfo().getDesc());
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(asyncOperationListener);
        asyncSession.update(customAlbum);
    }

    /**
     * 获得最近播放的音乐数目
     *
     * @return 数量
     */
    public long getCustomAlbumNumber() {
        QueryBuilder<CustomAlbum> queryBuilder = getCustomAlbumDao().queryBuilder();
        return queryBuilder.count();
    }

    /**
     * 获取下一个自定义专辑的id号
     *
     * @return 自定义专辑的id号
     */
    public int getNextLocaleAlbumId() {
        String sql = "select max(ALBUM_ID) as max_id from CUSTOM_ALBUM";
        int max_id = getIntFiledBySql(sql, "max_id", 0);
        return max_id + 1;
    }

    /**
     * 获取本地自创歌单专辑数量
     *
     * @return 本地自创歌单专辑数量
     */
    public long getCustomAlbumCount() {
        try {
            CustomAlbumDao customAlbumDao = MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumDao();
            CountQuery<CustomAlbum> countQuery = customAlbumDao.queryBuilder().buildCount();
            return countQuery.count();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private int getIntFiledBySql(String sSql, String sField, int defaultValue) {
        int iValue = defaultValue;
        if (sSql == null || sSql.isEmpty() || sField == null
                || sField.isEmpty())
            return iValue;
        Cursor cursor = null;
        SQLiteDatabase db;
        try {
            db = getCustomAlbumDao().getDatabase();
            if (db != null) {
                cursor = db.rawQuery(sSql, null);
            }
            if (!(cursor == null || cursor.isClosed())) {
                if (cursor.moveToFirst())
                    iValue = cursor.getInt(cursor.getColumnIndex(sField));
            }
            if (cursor != null) {
                cursor.close();
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return iValue;
    }

    /**
     * @param albumID 自建专辑的ID
     * @return 根基ID找到的自建专辑
     */
    public CustomAlbum getAlbumByID(int albumID) {
        QueryBuilder<CustomAlbum> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumDao().queryBuilder();
        queryBuilder.where(CustomAlbumDao.Properties.AlbumID.eq(albumID)).limit(1);
        return queryBuilder.unique();
    }

    public void asyncWriteCustomAlbum(CustomAlbum customAlbum) {
        if (customAlbum == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.insertOrReplace(customAlbum);
    }

    public void asyncDeleteAlbum(CustomAlbum customAlbum, AsyncOperationListener asyncOperationListener) {
        if (customAlbum == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListener(asyncOperationListener);
        asyncSession.delete(customAlbum);
    }
}
