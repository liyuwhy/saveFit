package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.Logger;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


/**
 * 音乐信息帮助类 信息保存在MusicInfo中
 */
public class CustomAlbumListHelper {

    private static CustomAlbumListHelper instance;

    public static CustomAlbumListHelper getInstance() {
        if (instance == null) {
            instance = new CustomAlbumListHelper();
        }
        return instance;
    }

    public CustomAlbumListDao getCustomAlbumListDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumListDao();
    }

    /**
     * 向自定义歌单中添加一首歌曲
     *
     * @param customAlbumId 自定义歌单id
     * @param musicId       歌曲id
     */
    public void addMusicInCustomAlbumList(int customAlbumId, int musicId) {
        if (checkCustomAlbumListExist(customAlbumId, musicId)) return;
        CustomAlbumList customAlbumList = new CustomAlbumList();
        customAlbumList.setCustomAlbumID(customAlbumId);
        customAlbumList.setMusicID(musicId);
        insertCustomAlbumList(customAlbumList);
    }

    private boolean checkCustomAlbumListExist(int customAlbumId, int musicId) {
        QueryBuilder<CustomAlbumList> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumListDao().queryBuilder();
        queryBuilder.where(CustomAlbumListDao.Properties.CustomAlbumID.eq(customAlbumId), (CustomAlbumListDao.Properties.MusicID.eq(musicId)));
        return queryBuilder.count() > 0;
    }

    /**
     * 向自定义歌单中添加歌曲列表
     *
     * @param customAlbumId 自定义歌单id
     * @param listMusicId   歌曲列表
     */
    public void addMusicListInCustomAlbum(int customAlbumId, ArrayList<Integer> listMusicId) {
        if ((listMusicId == null) || (listMusicId.size() == 0)) return;
        for (int i = 0; i < listMusicId.size(); i++) {
            addMusicInCustomAlbumList(customAlbumId, listMusicId.get(i));
        }
    }

    /**
     * @param customAlbumList 一条信息包括 专辑ID 和 歌曲ID
     */
    public void insertCustomAlbumList(CustomAlbumList customAlbumList) {
        asyncWriteCustomAlbumList(customAlbumList);
    }

    /**
     * 删除自定一个歌单中的一首歌曲
     *
     * @param albumID                自定义歌单id
     * @param musicID                歌曲id
     * @param asyncOperationListener 监听器
     * @return 成功与否
     */
    public void deleteMusicFromAlbum(int albumID, int musicID, AsyncOperationListener asyncOperationListener) {
        asyncDeleteCustomAlbumList(getAlbumListItemByID(albumID, musicID), asyncOperationListener);
    }

    /**
     * 删除自定一个歌单中的一首歌曲
     *
     * @param albumID 自定义歌单id
     * @param musicID 歌曲id
     * @return 成功与否
     */
    public void deleteMusicFromAlbum(int albumID, int musicID) {
        asyncDeleteCustomAlbumList(getAlbumListItemByID(albumID, musicID));
    }

    /**
     * 从自定义歌单中删除指定的歌曲列表
     *
     * @param customAlbumId 自定义歌单id
     * @param listMusicId   歌曲id列表
     * @return 成功与否
     */
    public boolean removeCustomAlbumList(int customAlbumId, ArrayList<Integer> listMusicId) {
        if ((listMusicId == null) || (listMusicId.size() == 0)) return false;
        for (int i = 0; i < listMusicId.size(); i++) {
            deleteMusicFromAlbum(customAlbumId, listMusicId.get(i));
        }
        return true;
    }

    /**
     * 通过自建歌单的id号得到音乐列表
     *
     * @param customAlbumId 自建歌单id号
     * @return 音乐列表
     */
    public List<Music> getAlbumMusicList(int customAlbumId) {
        return MusicInfoHelper.getInstance().getMusicListByIdList(getMusicsByCustomAlbumId(customAlbumId));
    }

    /**
     * 通过自定义歌单id清除该歌单下的所有歌曲
     *
     * @param customAlbumId 自定义歌单id
     */
    private void removeCustomAlbumListByCustomAlbumId(int customAlbumId) {
        List<CustomAlbumList> lists = getCustomAlbumList(customAlbumId);
        if (lists != null && lists.size() > 0) {
            for (CustomAlbumList customAlbumList : lists) {
                asyncDeleteCustomAlbumList(customAlbumList);
            }
        }
    }

    /**
     * 通过自建歌单的id号得到音乐列表
     *
     * @param customAlbumId 自建歌单id号
     */
    public List<CustomAlbumList> getCustomAlbumList(int customAlbumId) {
        QueryBuilder<CustomAlbumList> queryBuilder = getCustomAlbumListDao().queryBuilder();
        queryBuilder.where(CustomAlbumListDao.Properties.CustomAlbumID.eq(customAlbumId));
        return queryBuilder.list();
    }

    /**
     * 通过自建歌单的id号得到音乐列表
     *
     * @param customAlbumId 自建歌单id号
     * @return 音乐的id的列表
     */
    public List<Integer> getMusicsByCustomAlbumId(int customAlbumId) {
        QueryBuilder<CustomAlbumList> queryBuilder = getCustomAlbumListDao().queryBuilder();
        queryBuilder.where(CustomAlbumListDao.Properties.CustomAlbumID.eq(customAlbumId)).orderDesc(CustomAlbumListDao.Properties.MusicID);
        List<CustomAlbumList> customAlbumLists = queryBuilder.list();
        List<Integer> musicIdList = new ArrayList<>();
        if (customAlbumLists != null) {
            for (CustomAlbumList customAlbumList : customAlbumLists) {
                musicIdList.add(customAlbumList.getMusicID());
                Logger.i(Logger.DEBUG_TAG, "getMusicsByCustomAlbumId ----> musicId:" + customAlbumList.getMusicID());
            }
        }
        return musicIdList;
    }

    /**
     * @param albumID 专辑ID
     * @param musicID 歌曲ID
     * @return 一条信息 CustomAlbumList
     */
    public CustomAlbumList getAlbumListItemByID(int albumID, int musicID) {
        QueryBuilder<CustomAlbumList> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getCustomAlbumListDao().queryBuilder();
        queryBuilder.where(CustomAlbumListDao.Properties.CustomAlbumID.eq(albumID), (CustomAlbumListDao.Properties.MusicID.eq(musicID)))
                .limit(1);
        return queryBuilder.unique();
    }

    public void asyncWriteCustomAlbumList(CustomAlbumList customAlbumList) {
        if (customAlbumList == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.insertOrReplace(customAlbumList);
    }

    public void asyncDeleteCustomAlbumList(CustomAlbumList customAlbumList) {
        if (customAlbumList == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.delete(customAlbumList);
    }

    public void asyncDeleteCustomAlbumList(CustomAlbumList customAlbumList, AsyncOperationListener asyncOperationListener) {
        if (customAlbumList == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(asyncOperationListener);
        asyncSession.delete(customAlbumList);
    }
}
