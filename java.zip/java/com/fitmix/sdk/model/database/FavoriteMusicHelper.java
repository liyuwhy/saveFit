package com.fitmix.sdk.model.database;


import android.database.Cursor;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.manager.UserDataManager;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


/**
 * 音乐信息帮助类 信息保存在MusicInfo中
 */
public class FavoriteMusicHelper {

    private static FavoriteMusicHelper instance;
    private Cursor cursor;

    public static FavoriteMusicHelper getInstance() {
        if (instance == null) {
            instance = new FavoriteMusicHelper();
        }
        return instance;
    }

    public FavoriteMusicDao getFavoriteMusicDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao();
    }

    public int getPersonUid() {
        return UserDataManager.getUid();
    }

    /**
     * @return 收藏列表的cursor
     */
    public Cursor getFavoriteMusicCursor() {
        if (cursor != null && !cursor.isClosed()) return cursor;
        String[] columns = new String[]{"_id", "MUSIC_ID"};
        String selection = "UID = " + getPersonUid() + " AND MUSIC_ID not in (" + getMusicStringNotInDB() + ")";
        String orderBy = "MUSIC_ID DESC";
        cursor = getFavoriteMusicDao().getDatabase().query(getFavoriteMusicDao().getTablename(), columns, selection, null, null, null, orderBy, null);
        return cursor;
    }

    public void cursorUpdate() {
        if (cursor != null && !cursor.isClosed()) cursor.requery();
    }

    /**
     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的歌曲
     */
    private String getMusicStringNotInDB() {
        List<FavoriteMusic> favoriteMusicList = getFavoriteMusicList();
        StringBuilder sb = new StringBuilder();
        if (favoriteMusicList != null) {
            for (int i = 0; i < favoriteMusicList.size(); i++) {
                if (checkMusicExistInMusicInfo(favoriteMusicList.get(i).getMusicID())) continue;
                sb.append(favoriteMusicList.get(i).getMusicID());
                sb.append(",");
            }
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        Logger.i(Logger.DEBUG_TAG, "getFavoriteMusic --- > getMusicStringNotInDB : " + sb.toString());
        return sb.toString();
    }


    /**
     * @return 获得收藏的音乐列表
     */
    public List<Music> getFavoriteMusic(int uid) {
        QueryBuilder<FavoriteMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao().queryBuilder();
        queryBuilder
                .where(FavoriteMusicDao.Properties.Uid.eq(uid))
                .orderDesc(FavoriteMusicDao.Properties.MusicID)
                .buildCursor();
        List<FavoriteMusic> favoriteMusicList = queryBuilder.list();
        List<Integer> idList = new ArrayList<>();
        if (favoriteMusicList != null) {
            for (int i = 0; i < favoriteMusicList.size(); i++) {
                idList.add(favoriteMusicList.get(i).getMusicID());
                Logger.i(Logger.DEBUG_TAG, "getFavoriteMusic --- > musicId : " + favoriteMusicList.get(i).getMusicID());
            }
        }
        return MusicInfoHelper.getInstance().getMusicListByIdList(idList);
    }

    /**
     * 根据 music 插入收藏的数据
     *
     * @param musicList 进行操作的音乐ID列表
     */
    public void insertFavoriteMusicList(List<Integer> musicList) {
        if (musicList != null && musicList.size() > 0) {
            for (Integer musicId : musicList) {
                if (checkFavoriteMusicExist(musicId)) continue;
                insertFavoriteMusic(musicId);
            }
        }
    }

    /**
     * 根据 music 插入收藏的数据
     *
     * @param musicID 进行操作的音乐ID
     */
    public void insertFavoriteMusic(int musicID) {
        if (getPersonUid() < 0) return;
        FavoriteMusic favoriteMusic = new FavoriteMusic();
        favoriteMusic.setUid(getPersonUid());
        favoriteMusic.setMusicID(musicID);
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insertOrReplace(favoriteMusic);
    }

    /**
     * @param musicID 要进行操作的音乐ID
     * @return 歌曲在数据库中存不存在
     */
    public boolean checkFavoriteMusicExist(int musicID) {
        return getFavoriteMusicByID(musicID) != null;
    }

    /**
     * @param musicID 要进行操作的音乐ID
     */
    public void deleteFavoriteMusic(int musicID) {
        asyncDeleteFavoriteMusic(getFavoriteMusicByID(musicID));
    }


    /**
     * 获得收藏的音乐数目
     *
     * @return 数量
     */
    public long getFavoriteMusicNumber() {
        QueryBuilder<FavoriteMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao().queryBuilder();
        return queryBuilder.where(FavoriteMusicDao.Properties.Uid.eq(getPersonUid())).count();
    }

    private boolean checkMusicExistInMusicInfo(int musicId) {
        return MusicInfoHelper.getInstance().checkFitmixMusicExist(musicId);
    }

    /**
     * 获得收藏的音乐ID列表
     *
     * @return 数量
     */
    public List<FavoriteMusic> getFavoriteMusicList() {
        QueryBuilder<FavoriteMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao().queryBuilder();
        queryBuilder.where(FavoriteMusicDao.Properties.Uid.eq(getPersonUid())).orderDesc(FavoriteMusicDao.Properties.MusicID);
        List<FavoriteMusic> list = queryBuilder.list();
        if (list == null) list = new ArrayList<>();
        return list;
    }

    /**
     * 获得收藏的音乐ID列表
     *
     * @return 数量
     */
    public List<Integer> getFavoriteMusicIDList() {
        QueryBuilder<FavoriteMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao().queryBuilder();
        queryBuilder
                .where(FavoriteMusicDao.Properties.Uid.eq(getPersonUid()))
                .orderDesc(FavoriteMusicDao.Properties.MusicID);
        List<FavoriteMusic> favoriteMusicList = queryBuilder.list();
        List<Integer> musicIdList = new ArrayList<>();
        if (favoriteMusicList != null) {
            for (FavoriteMusic favoriteMusic : favoriteMusicList) {
                if (!checkMusicExistInMusicInfo(favoriteMusic.getMusicID())) continue;
                musicIdList.add(favoriteMusic.getMusicID());
                Logger.i(Logger.DEBUG_TAG, "getMusicByScene ----> musicId : " + favoriteMusic.getMusicID());
            }
        }
        return musicIdList;
    }

    /**
     * 根据Id在musicInfo表中查找数据
     *
     * @param musicID 音乐ID
     */
    public FavoriteMusic getFavoriteMusicByID(int musicID) {
        QueryBuilder<FavoriteMusic> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getFavoriteMusicDao().queryBuilder();
        queryBuilder.where(FavoriteMusicDao.Properties.MusicID.eq(musicID), FavoriteMusicDao.Properties.Uid.eq(getPersonUid()))
                .limit(1);
        return queryBuilder.unique();
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param favoriteMusic 音乐信息
     */
    public void asyncWriteFavoriteMusic(FavoriteMusic favoriteMusic) {
        if (favoriteMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.insertOrReplace(favoriteMusic);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param favoriteMusicList 音乐列表信息
     */
    public void asyncWriteFavoriteMusic(List<FavoriteMusic> favoriteMusicList) {
        if (favoriteMusicList == null || favoriteMusicList.isEmpty()) return;
        for (FavoriteMusic favoriteMusic : favoriteMusicList) {
            asyncWriteFavoriteMusic(favoriteMusic);
        }
    }

    /**
     * 异步删除音乐信息
     *
     * @param favoriteMusic 音乐信息
     */
    public void asyncDeleteFavoriteMusic(FavoriteMusic favoriteMusic) {
        if (favoriteMusic == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                cursorUpdate();
            }
        });
        asyncSession.delete(favoriteMusic);
    }


}
