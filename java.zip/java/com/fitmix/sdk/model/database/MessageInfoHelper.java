package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * 数据库表(MESSAGE_INFO)增、删、改、查帮助类
 */

public class MessageInfoHelper {

    private static MessageInfoHelper instance;

    //    private Cursor cursor;
    public static MessageInfoHelper getInstance() {
        if (instance == null) {
            instance = new MessageInfoHelper();
        }
        return instance;
    }

    public MessageInfoDao getMessageInfoDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getMessageInfoDao();
    }

    public List<MessageInfo> getMessageInfoList() {
        QueryBuilder<MessageInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMessageInfoDao().queryBuilder();
        queryBuilder.orderDesc(MessageInfoDao.Properties.LastUpdateTime)
                .limit(30);

        List<MessageInfo> messageInfoList = queryBuilder.list();
        List<MessageInfo> messageInfoNewList = new ArrayList<>();
        if (messageInfoList != null) {
            for (MessageInfo messageInfo : messageInfoList) {
                if (!checkMessageExistInMessageInfo(messageInfo.getMessageId())) {
                    messageInfoNewList.add(messageInfo);
                }
            }
        }
        return messageInfoNewList;
    }

//    public Cursor getMessageInfoCursor() {
//        if (cursor != null && !cursor.isClosed()) return cursor;
//        String[] columns = new String[]{"_id", "MESSAGE_ID"};
//        String selection = "MESSAGE_ID not in (" + getMessageStringNotInDB() + ")";
//        String orderBy = "ADD_TIME DESC";
//        String limit = "30";
//        cursor = getMessageInfoDao().getDatabase().query(getMessageInfoDao().getTablename(), columns, selection, null, null, null, orderBy, limit);
//        return cursor;
//    }

    /**
     * 防止有些数据在数据库中并不存在 所以需要去掉不存在数据库中的
     */
    private String getMessageStringNotInDB() {
        List<MessageInfo> messageInfoList = getMessageInfoList();
        StringBuilder sb = new StringBuilder();
        if (messageInfoList != null) {
            for (int i = 0; i < messageInfoList.size(); i++) {
                if (checkMessageExistInMessageInfo(messageInfoList.get(i).getMessageId())) continue;
                sb.append(messageInfoList.get(i).getMessageId());
                sb.append(",");
            }
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    private boolean checkMessageExistInMessageInfo(long messageId) {
        return MessageInfoHelper.getInstance().checkMessageInfoExist(messageId);
    }

    public boolean checkMessageInfoExist(long messageId) {
        return getMessageInfoByID(messageId) == null;
    }

    /**
     * 根据messageId删除消息
     *
     * @param messageId 消息ID
     */
    public void deleteMessageInfoByMessageId(long messageId) {
        asyncDeleteMessageInfo(getMessageInfoByID(messageId));
    }


    /**
     * 根据Id在messageInfo表中查找数据
     *
     * @param messageId 消息ID
     */
    public MessageInfo getMessageInfoByID(long messageId) {
        QueryBuilder<MessageInfo> queryBuilder = MixApp.getDaoSession(MixApp.getContext()).getMessageInfoDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(MessageInfoDao.Properties.MessageId.eq(messageId)).limit(1);
        return queryBuilder.unique();
    }

//    public void cursorUpdate() {
//        if (cursor != null && !cursor.isClosed()) cursor.requery();
//    }

    /**
     * 异步删除消息
     *
     * @param messageInfo 消息
     */
    public void asyncDeleteMessageInfo(MessageInfo messageInfo) {
        if (messageInfo == null) {
            return;
        }
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.setListenerMainThread(new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
//                cursorUpdate();
            }
        });
        asyncSession.delete(messageInfo);
    }

    /**
     * 异步添加或更新消息
     *
     * @param messageInfo 消息
     */
    public void asyncWriteMessageInfo(MessageInfo messageInfo) {
        if (messageInfo == null) {
            return;
        }
        getMessageInfoDao().insertOrReplace(messageInfo);
    }

    /**
     * 异步添加或更新音乐信息
     *
     * @param messageInfoList 消息列表
     */
    public void asyncWriteMessageInfoList(List<MessageInfo> messageInfoList) {
        if (messageInfoList == null || messageInfoList.isEmpty()) return;
        for (MessageInfo messageInfo : messageInfoList) {
            asyncWriteMessageInfo(messageInfo);
        }
    }

    //删除所有
    public void asyncDeleteAll() {
        List<MessageInfo> messageInfoList = getMessageInfoList();
        for (int i = 0; i < messageInfoList.size(); i++) {
            asyncDeleteMessageInfo(messageInfoList.get(i));
        }
    }

}
