package com.fitmix.sdk.model.database;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.Logger;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;


public class PlayingMusicHelper {

    private static PlayingMusicHelper instance;

    public static PlayingMusicHelper getInstance() {
        if (instance == null) {
            synchronized (PlayingMusicHelper.class) {
                if (instance == null) {
                    instance = new PlayingMusicHelper();
                }
            }
        }
        return instance;
    }

    public PlayingMusicDao getPlayingMusicDao() {
        return MixApp.getDaoSession(MixApp.getContext()).getPlayingMusicDao();
    }

    public PlayingMusic getPlayingMusicById(Music music) {
        QueryBuilder<PlayingMusic> queryBuilder = getPlayingMusicDao().queryBuilder();
        queryBuilder.where(PlayingMusicDao.Properties.MusicID.eq(music.getId()));
        /** 解决bug: java.lang.RuntimeException: Unable to start activity ComponentInfo{com.fitmix.sdk/com.fitmix.sdk.view.activity.PlayMusicActivity}:
         * de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.limit(1);
        return queryBuilder.unique();
    }

    public PlayingMusic getPlayingMusicById(int musicId) {
        QueryBuilder<PlayingMusic> queryBuilder = getPlayingMusicDao().queryBuilder();
        queryBuilder.where(PlayingMusicDao.Properties.MusicID.eq(musicId));
        queryBuilder.limit(1);
        return queryBuilder.unique();
    }

    /**
     * @return 最后一次播放的歌曲在最后一次的播放列表中的位置, 注意返回值为-1的情况
     */
    public int getIndexInPlayingList() {
        Logger.i(Logger.DEBUG_TAG, "getIndexInPlayingList() : " + " getPlayingMusicId() : " + getPlayingMusicId());
        return getPlayingMusicIdList().indexOf(getPlayingMusicId());
    }

    /**
     * @return 最后一次播放的歌曲Id
     */
    public int getPlayingMusicId() {
        QueryBuilder<PlayingMusic> queryBuilder = getPlayingMusicDao().queryBuilder();
        /** 解决bug:de.greenrobot.dao.DaoException: Expected unique result, but count was 2*/
        queryBuilder.where(PlayingMusicDao.Properties.PlayState.eq(1)).limit(1);
        PlayingMusic playingMusic = queryBuilder.unique();
        return playingMusic != null ? playingMusic.getMusicID() : -1;
    }

    /**
     * @return 获取上次播放列表的id 集合
     */
    public List<Integer> getPlayingMusicIdList() {
        QueryBuilder<PlayingMusic> queryBuilder = getPlayingMusicDao().queryBuilder();
        List<PlayingMusic> playingMusics = queryBuilder.list();
        List<Integer> musicIdList = new ArrayList<>();
        if (playingMusics != null && playingMusics.size() > 0) {
            for (PlayingMusic playingMusic : playingMusics) {
                musicIdList.add(playingMusic.getMusicID());
            }
        }
        return musicIdList;
    }

    /**
     * 插入音乐列表到数据库播放列表
     *
     * @param musics 音乐列表
     */
    public void setMusicPlayingList(List<Music> musics) {
        getPlayingMusicDao().deleteAll();
        if (musics != null && musics.size() > 0) {
            List<PlayingMusic> playingMusics = new ArrayList<>();
            for (Music music : musics) {
                PlayingMusic playingMusic = new PlayingMusic();
                playingMusic.setMusicID(music.getId());
                playingMusic.setPlayState(0);
                playingMusics.add(playingMusic);
            }
            MixApp.getDaoSession(MixApp.getContext()).getPlayingMusicDao().insertOrReplaceInTx(playingMusics);
        }
    }

    /**
     * 更新数据库播放列表(PlayingMusic)中音乐播放状态
     *
     * @param music 正在播放的音乐信息
     */
    public void setPlayingMusic(Music music) {
        PlayingMusic playingMusic = getPlayingMusicById(music);
        if (playingMusic == null) return;
        setMusicNoPlay();
        playingMusic.setPlayState(1);
        //asyncWriteReadyPlayMusic(playingMusic);
        MixApp.getDaoSession(MixApp.getContext()).getPlayingMusicDao().insertOrReplace(playingMusic);
    }

    /**
     * 更新数据库播放列表(PlayingMusic)中音乐播放状态
     *
     * @param musicId 正在播放的音乐信息
     */
    public void setPlayingMusic(int musicId) {
        PlayingMusic playingMusic = getPlayingMusicById(musicId);
        if (playingMusic == null) return;
        setMusicNoPlay();
        playingMusic.setPlayState(1);
        //asyncWriteReadyPlayMusic(playingMusic);
        MixApp.getDaoSession(MixApp.getContext()).getPlayingMusicDao().insertOrReplace(playingMusic);
    }

    /**
     * 把其他正在播放的歌曲状态置为未播放
     */
    public void setMusicNoPlay() {
        QueryBuilder<PlayingMusic> queryBuilder = getPlayingMusicDao().queryBuilder();
        queryBuilder.where(PlayingMusicDao.Properties.PlayState.eq(1));
        List<PlayingMusic> playingMusics = queryBuilder.list();
        if (playingMusics != null && playingMusics.size() > 0) {
            for (PlayingMusic playingMusic : playingMusics) {
                playingMusic.setPlayState(0);
                //asyncWriteReadyPlayMusic(playingMusic);
            }
        }
        MixApp.getDaoSession(MixApp.getContext()).getPlayingMusicDao().insertOrReplaceInTx(playingMusics);
    }

    public void asyncWriteReadyPlayMusic(PlayingMusic playingMusic) {
        if (playingMusic == null) return;
        AsyncSession asyncSession = MixApp.getDaoSession(MixApp.getContext()).startAsyncSession();
        asyncSession.insertOrReplace(playingMusic);
    }
}
