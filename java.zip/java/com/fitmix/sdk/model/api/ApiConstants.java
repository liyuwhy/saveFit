package com.fitmix.sdk.model.api;

import android.os.Build;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.model.manager.UserDataManager;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import okhttp3.FormBody;

/**
 * 获取后台API的请求url帮助类
 */
public final class ApiConstants {

    /**
     * URL encode格式,默认为utf-8
     */
    private static final String URL_ENCODE_FORMAT = "UTF-8";

    private ApiConstants() {
        // No public constructor
    }

    /**
     * 任意多个String依次拼接
     *
     * @param params 任意多个String
     * @return 拼接结果
     */
    public static String jointStrings(String... params) {
        StringBuilder sb = new StringBuilder();
        for (String str : params) {
            sb.append(str);
        }
        return sb.toString();
    }

    /**
     * 获取 App 默认token
     * 注意：
     * 1、	已登录用户,少任意一处 参数会被拦截
     * 2、	登录接口、注册接口和mix歌曲接口_k和_uid可以不传
     */
    public static String getApiToken() {
        // _terminal = 2 表示终端为android
        String token = String.format("&_product=fitmix&_terminal=2&_lan=%s&_ch=%s&_v=%s&_nw=%s&_sdk=%s",
                ApiUtils.getLanguage(),
                ApiUtils.getApkChannel(),
                ApiUtils.getApkVersionCode(),
                ApiUtils.getNetWorkType(),
                ApiUtils.getPhoneInfo()//
                //ApiUtils.getPhoneSdk()
        );
        //判断_k
        if (!TextUtils.isEmpty(ApiUtils.getApiToken())) {
            token = token + "&_k=" + ApiUtils.getApiToken();
        }
        if (UserDataManager.getUid() > 0) {
            token = token + "&uid=" + UserDataManager.getUid();
        }
        return token;
    }


    /**
     * 获得post请求基础请求体
     *
     * @return Builder 需要添加其他参数
     */
    public static FormBody.Builder getBaseBuilder() {
        FormBody.Builder builder = new FormBody.Builder()
                .add("_lan", ApiUtils.getLanguage())
                .add("_v", ApiUtils.getApkVersionCode() + "")//版本号
                .add("_ch", ApiUtils.getApkChannel())//渠道号
                .add("_nw", ApiUtils.getNetWorkType())
                .add("_sdk", Build.VERSION.SDK_INT + "")
                .add("_product", "fitmix")
                .add("_terminal", "2");//_terminal = 2 表示终端为android
        if (!TextUtils.isEmpty(ApiUtils.getApiToken())) {
            builder.add("_k", ApiUtils.getApiToken());
        }
        if (UserDataManager.getUid() > 0) {
            builder.add("uid", UserDataManager.getUid() + "");
        }
        return builder;
    }

    /**
     * App 初始化
     * <p/>
     * 描述：
     * 1、	版本升级检查,新版本时会提示升级和app升级地址,app 升级介绍
     * 2、	字典信息,产量信息初始化
     * 3、	Geekery 产品购买地址
     *
     * @param version app版本号,必需
     * @param lan     app语言类型,ch:中文,en:英文
     */
    public static String appInitUrl(int version, String lan) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/init.json?version=", String.valueOf(version),
                "&lan=", lan,
                getApiToken());
    }

    /**
     * 网络协议地址
     */
    public static String appPrivacyPolicy() {
        String lan = ApiUtils.getLanguage();
        if ("zh".equals(lan)) {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/PrivacyStripBox.jsp");
        } else {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/PrivacyStripBoxEn.jsp");
        }
    }

    /**
     *  帮助协议地址
     */
    /**
     * 网络协议地址
     */
    public static String appHelpUrl() {
        String lan = ApiUtils.getLanguage();
        if ("zh".equals(lan)) {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/handLook.jsp");
        } else {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/handLookEn.jsp");
        }
    }

    //region ============================== 用户信息模块 ==============================

    /**
     * 获取App邮箱账号登录请求地址
     *
     * @param email 邮箱账号
     * @param pwd   登录密码
     * @return App邮箱账号登录
     */
    public static String emailLogin(String email, String pwd) {
        String encodePwd = pwd;
        try {
            encodePwd = URLEncoder.encode(pwd, URL_ENCODE_FORMAT);
        } catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
        }
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/login.json?email=", email,
                "&password=", encodePwd,
                getApiToken());
    }

    /**
     * 获取QQ授权登录请求地址
     *
     * @param token  QQ授权登录的token
     * @param openid 乐享动 openId
     * @return QQ授权登录请求地址
     */
    public static String qqLogin(String token, String openid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/login-qq.json?token=", token,
                "&openid=", openid,
                "&channel=", ApiUtils.getApkChannel(),
                getApiToken());
    }

    /**
     * 获取新浪微博授权登录请求地址
     *
     * @param token  新浪微博授权登录的token
     * @param openid 乐享动 openId
     * @return 新浪微博授权登录请求地址
     */
    public static String weiBoLogin(String token, String openid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/login-wb.json?token=", token,
                "&openid=", openid,
                "&channel=", ApiUtils.getApkChannel(),
                getApiToken());
    }

    /**
     * 获取微信授权登录请求地址
     *
     * @param token  微信授权登录的token
     * @param openid 乐享动 openId
     * @return 微信授权登录请求地址
     */
    public static String weiXinLogin(String token, String openid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/login-wx.json?token=", token,
                "&openid=", openid,
                "&channel=", ApiUtils.getApkChannel(),
                getApiToken());
    }

    /**
     * 检测服务器上App最新版本信息
     *
     * @return 服务器上App最新版本信息请求地址
     */
    public static String checkAppVersion() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/check-version.json?",
                getApiToken());
    }

    /**
     * 上传设备信息
     */
    public static String uploadUserDeviceInfo(String deviceToken) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/stat/user-devices-info.json?",
                "udid=", ApiUtils.getUdid(),
                "&version=" + ApiUtils.getApkVersionCode(),
                "&sdk=", ApiUtils.getPhoneInfo(),//ApiUtils.getPhoneSdk(),
                "&channel=", ApiUtils.getApkChannel(),
                "&operators=", ApiUtils.getSimOperatorName(),
                "&mobileType=", Build.MODEL,
                "&deviceToken=", deviceToken,
                "&unionid=", ApiUtils.getWeChatUnionId(),//微信union id
                "&appid=", ApiUtils.getQqAppId(),//qq app id
                "&deviceTokenXG=", deviceToken,//信鸽推送
                getApiToken());
    }

    /**
     * 彩蛋
     *
     * @param city 城市名
     */
    public static FormBody getSurpriseInfo(String city) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("cityName", city);
        return baseBuilder.build();
    }

    /**
     * 修改用户信息
     *
     * @param id        用户uid
     * @param name      昵称
     * @param gender    性别,1:男,2:女
     * @param age       年龄
     * @param height    身高
     * @param weight    体重
     * @param type      身高体重单位制量,1:公制,2:英制
     * @param signature 个性签名
     */
    public static String updateUserInfo(int id, String name, int gender, int age, double height, double weight, int type, String signature) {
        String userName = name;
        try {
            userName = URLEncoder.encode(name, URL_ENCODE_FORMAT);
        } catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
        }

        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/user/modify-info.json?uid=", id + "",
                "/user/modify-info.json?gender=", gender + "",
                "&age=", age + "",
                "&height=", Double.toString(height),
                "&weight=", Double.toString(weight),
                "&type=", Integer.toString(type),
                "&signature=", signature,
                "&name=", userName,
                getApiToken());
    }

    /**
     * 获取绑定的字符串
     *
     * @param bindingContent 微信 微博 QQ （openid）,或者是手机或邮箱,如果是手机注册,则不可以绑定手机 等
     * @param bindingName    绑定的名称：第三方平台 给 用户姓名,手机 邮箱 直接填写手机 或邮箱
     * @param type           1、app注册 2、QQ 注册 3、微信注册  4、微博注册 5、手机
     * @return
     */
    public static String userBind(String bindingContent, String bindingName, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/binding.json?bindingContent=", bindingContent,
                "&bindingName=", bindingName,
                "&type=", Integer.toString(type),
                getApiToken());
    }

    public static String userBindWithPwd(String bindingContent, String bindingName, int type, String password) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/binding.json?bindingContent=", bindingContent,
                "&bindingName=", bindingName,
                "&type=", Integer.toString(type),
                "&password=", password,
                getApiToken());
    }

    /**
     * 获取手机验证码
     *
     * @param mobileNumber 接收验证码的手机
     * @return
     */
    public static String getAuthCode(String mobileNumber) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                //    "/get/mobile/verification/code.json?mobile=", // /user/user-verify-code.json
                "/get/mobile/verification/new-code-ssl.json?mobile=",
                mobileNumber.trim(),
                getApiToken());
    }


    /**
     * 获取邮箱验证码
     *
     * @param email 接收验证码的邮箱
     * @return
     */
    public static String getEmailAuthCode(String email) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/get/email/verification/code.json?email=",
                email.trim(),
                getApiToken());
    }

    /**
     * 获取解绑的字符串
     *
     * @param type 绑定的类型 1、app注册 2、QQ 注册 3、微信注册  4、微博注册 5、手机
     * @return
     */
    public static String userUnbind(int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/unbinding.json",
                "?type=", Integer.toString(type),
                getApiToken());
    }

    public static String changePwd(String sOldPassword, String sNewPassword) {
        if (sOldPassword == null || sOldPassword.isEmpty())
            return null;
        if (sNewPassword == null || sNewPassword.isEmpty())
            return null;
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/modify-password.json",
                "?oldPwd=", sOldPassword,
                "&nowPwd=", sNewPassword,
                getApiToken());
    }

    public static String modifyContestant(int uid, String contestantName, int gender,
                                          int age, String identity,
                                          String phoneNumber, String email, String province, String city,
                                          String address, String bloodType, String dressSize, String emergencyName,
                                          String emergencyNumber) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/modify-real-info.json",
                "?uid=", Integer.toString(uid),
                "&name=", contestantName,
                "&gender=", Integer.toString(gender),
                "&age=", Integer.toString(age),
                "&bloodType=", bloodType,
                "&clothesSize=", dressSize,
                "&idCard=", identity,
                "&email=", email,
                "&mobilePhone=", phoneNumber,
                "&emergencyPhone=", emergencyNumber,
                "&emergencyName=", emergencyName,
                "&&country=中国",
                "&region=", province,
                "&city=", city,
                "&detail=", address,
                getApiToken());
    }

    /**
     * 获取第三方绑定（QQ,微博,微信）的URL
     *
     * @param bindingContent
     * @param bindingName
     * @param type
     * @return
     */
    public static String getBindString(String bindingContent, String bindingName, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/binding.json",
                "?bindingContent=", bindingContent,
                "&bindingName=", bindingName,
                "&type=", Integer.toString(type),
                getApiToken());
    }

//    /**
//     * 邮箱注册
//     *
//     * @param email    注册邮箱地址
//     * @param name     用户昵称 但现在不填写 传email
//     * @param password 密码
//     */
//    public static String emailRegister(String email, String name, String password) {
//        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/user/register.json?",
//                "email=", email.trim(),
//                "&name=", name.trim(),
//                "&password=", password.trim(),
//                getApiToken());
//    }

    /**
     * 邮箱注册,V2.4.1之后新方式
     *
     * @param email      注册邮箱地址
     * @param verifyCode 验证码
     * @param password   密码
     */
    public static String emailRegister(String email, String verifyCode, String password) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/email/register.json?",
                "email=", email.trim(),
                "&verifyCode=", verifyCode.trim(),
                "&password=", password.trim(),
                getApiToken());
    }


//    /**
//     * 手机注册
//     *
//     * @param mobileNumber 注册手机
//     * @param password     密码
//     */
//    public static String mobileRegister(String mobileNumber, String password) {
//        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/user/mobile-register.json?",
//                "mobile=", mobileNumber.trim(),
//                "&password=", password.trim(),
//                getApiToken());
//    }

    /**
     * 手机注册,V2.4.1之后新方式
     *
     * @param mobileNumber 注册手机
     * @param verifyCode   验证码
     * @param password     密码
     */
    public static String mobileRegister(String mobileNumber, String verifyCode, String password) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/mobile/new-register-ssl.json?",
                "mobile=", mobileNumber.trim(),
                "&verifyCode=", verifyCode.trim(),
                "&password=", password.trim(),
                getApiToken());
    }

//    /**
//     * 找回邮箱注册密码
//     *
//     * @param email 注册邮箱地址
//     *
//     */
//    public static String forgetEmailPassword(String email) {
//        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/user/email-recovery-password.json?",
//                "email=", email.trim(),
//                getApiToken());
//    }

    /**
     * 邮箱找回密码,V2.4.1之后新方式
     *
     * @param email      注册邮箱地址
     * @param verifyCode 验证码
     * @param newPwd     新密码
     */
    public static String forgetEmailPassword(String email, String verifyCode, String newPwd) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/email/reset/password.json?",
                "email=", email.trim(),
                "&verifyCode=", verifyCode.trim(),
                "&newPwd=", newPwd.trim(),
                getApiToken());
    }

//    /**
//     * 找回手机注册密码
//     *
//     * @param mobileNumber 注册手机
//     * @param verifyCode   验证码
//     * @param newPassword  新密码
//     */
//    public static String forgetMobilePassword(String mobileNumber, String verifyCode, String newPassword) {
//        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/user/mobile-reset-password.json?",
//                "mobile=", mobileNumber.trim(),
//                "&verifyCode=", verifyCode.trim(),
//                "&newPassword=", newPassword.trim(),
//                getApiToken());
//    }


    /**
     * 手机找回密码,V2.4.1之后新方式
     *
     * @param mobileNumber 注册手机
     * @param verifyCode   验证码
     * @param newPassword  新密码
     */
    public static String forgetMobilePassword(String mobileNumber, String verifyCode, String newPassword) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/mobile/reset/new-password-ssl.json?",
                "mobile=", mobileNumber.trim(),
                "&verifyCode=", verifyCode.trim(),
                "&newPwd=", newPassword.trim(),
                getApiToken());
    }

    /**
     * 向后台服务器发送用户统计数据
     *
     * @param uid     用户uid
     * @param musicId 音乐id
     * @param type    信息类型,1:音乐,2:运动,3:直播
     * @param lng     经度
     * @param lat     纬度
     * @return 向后台服务器发送用户统计数据的请求地址
     */
    public static String reportUserBehavior(int uid, int musicId, int type, double lng, double lat) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/stat/user-behavior.json?uid=", String.valueOf(uid),
                "&mid=", String.valueOf(musicId),
                "&type=", String.valueOf(type),
                "&lng=", String.valueOf(lng),
                "&lat=", String.valueOf(lat),
                getApiToken());
    }

    /**
     * 修改消息状态(俱乐部)
     *
     * @param pushType   消息类型
     * @param businessId 如果是俱乐部消息就传俱乐部ID
     */
    public static String switchMessageState(int pushType, int businessId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/message/read-message.json?pushType=" + pushType,
                "&businessId=" + businessId,
                getApiToken());
    }

    /**
     * 修改消息状态（赛事）
     *
     * @param pushType 消息类型
     */
    public static String switchMessageState(int pushType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/message/read-message.json?pushType=" + pushType,
                getApiToken());
    }

    /**
     * 获取用户信息,如金币数量等
     *
     * @return 服务器上App用户信息(如金币数量等)请求地址
     */
    public static String getUserAccountInfo(int uid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/account/" + uid + ".json?",
                getApiToken());
    }

    /**
     * 获取用户金币记录
     *
     * @return 服务器上用户金币记录请求地址
     */
    public static String getUserCoinRecord(int uid, int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/account/" + uid + "/accountFlow.json?pageNo=", String.valueOf(pageNo),
                getApiToken());
    }

    /**
     * 完成金币任务
     *
     * @param uid        用户uid
     * @param taskType   任务类型,0:今日签到任务
     * @param taskKey    任务类型键值,"EVERY_DAY_SIGN_IN":表示今日签到
     * @param additionId 附加编号,例如完成每日三公里任务时,需要跑步编号验证任务的有效性
     * @return 完成金币任务请求表单
     */
    public static FormBody finishTask(int uid, int taskType, String taskKey, String additionId) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("uid", String.valueOf(uid));
        baseBuilder.add("taskType", String.valueOf(taskType));
        baseBuilder.add("taskKey", taskKey);
        if (!TextUtils.isEmpty(additionId)) {
            baseBuilder.add("additionId", additionId);
        }
        return baseBuilder.build();
    }

    /**
     * 获取流米流量套餐兑换信息
     *
     * @return 服务器上获取流米流量套餐兑换信息的请求地址
     */

    public static String getLiuMiProduct() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/product/get-liumi-product.json?",
                getApiToken());
    }

    /**
     * 兑换流量套餐
     *
     * @param uid       用户uid
     * @param phone     用户手机号码
     * @param productId 流量兑换套餐ID
     * @return 兑换流量请求表单
     */
    public static FormBody exchange(int uid, String phone, int productId) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("uid", String.valueOf(uid));
        baseBuilder.add("productId", String.valueOf(productId));
        baseBuilder.add("mobile", phone);
        return baseBuilder.build();
    }

    /**
     * 获取任务列表
     *
     * @param uid  用户uid
     * @param type 任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
     * @return 服务器上获取任务列表的请求地址
     */
    public static String getTask(int uid, int type) {
        if (type == -1) {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/task/task-list.json?uid=", String.valueOf(uid),
                    getApiToken());
        } else {
            return jointStrings(Config.API_HOST, Config.API_PORT,
                    "/task/task-list.json?uid=", String.valueOf(uid),
                    "&type=", String.valueOf(type),
                    getApiToken());
        }
    }

    /**
     * 根据任务键值获取金币任务信息
     *
     * @param taskKey 任务键值
     * @return 根据任务键值获取金币任务信息的请求地址
     */
    public static String getTaskInfoByKey(String taskKey) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/task/get-task.json?taskKey=", taskKey,
                getApiToken());
    }

    /**
     * 获取流量兑换成功后,分享用的网页地址
     *
     * @param uid     流量兑换的用户uid
     * @param orderNo 流量兑换订单编号
     * @return 流量兑换成功后, 分享用的网页地址
     */
    public static String getCoinExchangeShare(int uid, String orderNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/share-flow.htm?uid=", String.valueOf(uid),
                "&orderNo=", orderNo);
    }

    /**
     * 浏览个人主页
     *
     * @param targetUid 目标用户编号
     */
    public static String browseHomePage(int targetUid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/browse/homepage.json?",
                "targetUid=", String.valueOf(targetUid),
                getApiToken());
    }

    /**
     * 激活 取消用户app的活跃状态
     *
     * @param active 0 取消 1 激活
     */
    public static String uploadDeviceStatus(int active, String deviceToken) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/upload/device/status.json?",
                "active=", String.valueOf(active),
                "&deviceToken=", String.valueOf(deviceToken),
                getApiToken());
    }

    /**
     * 发送私信
     *
     * @param targetUid 目标用户uid
     * @param content   私信内容
     */
    public static String sendUserPrivateMsg(int targetUid, String content) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/send/private/msg.json?",
                "targetUid=", String.valueOf(targetUid),
                "&content=", String.valueOf(content),
                getApiToken());
    }

    /**
     * 查询私信列表
     */
    public static String getUserPrivateMsgList(int page) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/get/private/msg/list.json?",
                "page=", String.valueOf(page),
                getApiToken());
    }

    /**
     * 获取用户通知列表
     */
    public static String getUserNoticeList() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/get/user/notice.json?",
                getApiToken());
    }

    /**
     * 读取用户通知消息
     */
    public static String readUserNoticeMsg(int id) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/read/user/msg.json?",
                "id=", String.valueOf(id),
                getApiToken());
    }

    /**
     * 查询私信列表详情
     */
    public static String getUserPrivateMsgInfo(int groupId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/get/private/msg/info.json?",
                "groupId=", String.valueOf(groupId),
                getApiToken());
    }

    /**
     * 删除私信
     */
    public static String deleteUserPrivateMsg(int groupId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/del/private/msg.json?",
                "groupId=", String.valueOf(groupId),
                getApiToken());
    }

    /**
     * 私信关系设置
     */
    public static String setUserPrivateMsgReject(int groupId, int handleType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/set/private/msg/reject.json?",
                "groupId=", String.valueOf(groupId),
                "&handleType=", String.valueOf(handleType),
                getApiToken());
    }

    /**
     * 查找用户设备信息,例如用户购买的手表、耳机等等
     *
     * @param uid 乐享动uid
     */
    public static String findUserDevices(int uid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/get/smart/device.json?uid=", String.valueOf(uid),
                getApiToken());
    }


    /**
     * 上传设备信息给后台
     *
     * @param uid  乐享动uid
     * @param type 设备类型,1:手表
     * @param info 设备其它补充信息,json字符串
     * @param key  设备唯一标识属性，用于查询与修改
     */
    public static String uploadDeviceInfo(int uid, int type, String info, String key) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/upload/smart/device/info.json?",//uid=", String.valueOf(uid),
                "&type=", String.valueOf(type),
                "&info=", info,
                "&key=", key,
                getApiToken());
    }

    /**
     * 删除设备信息
     *
     * @param uid  乐享动uid
     * @param type 设备类型,1:手表
     * @param key  设备唯一标识属性，用于查询与修改
     */
    public static String deleteDeviceInfo(int uid, int type, String key) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user/remove/smart/device.json?uid=", String.valueOf(uid),
                "&type=", String.valueOf(type),
                "&key=", key,
                getApiToken());
    }


    //endregion ============================================================

    //region ============================== 音乐模块 ==============================

    /**
     * 上传音乐试听
     */
    public static String uploadMusicAudition(int musicID) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/inc-audition.json?",
                "mid=" + musicID,
                getApiToken());
    }

    /**
     * 根据id列表获取歌曲信息
     */
    public static String getMusicListInfo(String mids) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/find-mix-list.json?",
                "mids=" + mids,
                getApiToken());
    }

    /**
     * 获取音乐专辑列表
     */
    public static String getAlbumList() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/scene-list.json?",
                getApiToken());
    }

    /**
     * 调用获取列表接口（专辑列表或者电台列表）type=1为专辑列表,type=2为电台列表
     *
     * @param type
     * @return
     */
    public static String getAlbumList(int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/scene-list.json?",
                "type=" + type,
                getApiToken());
    }

    /**
     * 获取音乐专辑列表
     */
    public static String getBannerList() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix-banner/list.json?",
                getApiToken());
    }

    /**
     * 获取音乐详情列表
     *
     * @param index    页数
     * @param scene    曲风分页（value）
     * @param type     1代表音乐,2代表电台
     * @param sortType 排序（1最新/2最热）
     * @return
     */
    public static String getMusicListFromServerBySceneAndIndex(int scene, int index, int type, int sortType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/scene-page.json?",
                "scene=" + scene,
                "&index=" + index,
                "&type=" + type,
                "&sortType=" + sortType,
                getApiToken());
    }

    /**
     * 获取电台详情列表
     *
     * @param index    页数
     * @param scene    曲风分页（value）
     * @param type     1代表音乐,2代表电台
     * @param sortType 排序（1最新/2最热）
     * @return
     */
    public static String getRadioListFromServerBySceneAndIndex(int scene, int index, int type, int sortType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/radio/scene-page.json?",
                "scene=" + scene,
                "&index=" + index,
                "&type=" + type,
                "&sortType=" + sortType,
                getApiToken());
    }

    /**
     * 获取推荐专辑详情列表
     *
     * @param mixAlbumId 推荐专辑ID
     * @return
     */
    public static String getRadioListFromServerByAlbumId(int mixAlbumId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix-album/album.json?",
                "mixAlbumId=" + mixAlbumId,
                getApiToken());
    }

    /**
     * 获取分享歌曲地址
     */
    public static String getShareMusicUrl(int musicID) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/share-info.htm?",
                "mid=" + musicID);
    }

    /**
     * 获取分享视频地址
     */
    public static String getShareVideoUrl(int videoId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/video/share-video.htm?",
                "videoId=" + videoId,
                getApiToken());
    }

    /**
     * 获取收藏单首歌曲
     */
    public static String getFavoriteMusicChangeUrl(int uid, int musicID) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-collect/collect.json?",
                "uid=" + uid,
                "&mids=" + musicID,
                getApiToken());
    }

    /**
     * 获取收藏列表歌曲
     */
    public static String getFavoriteMusicListChangeUrl(int uid, String musicIdString) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-collect/collect.json?",
                "uid=" + uid,
                "&mids=" + musicIdString,
                getApiToken());
    }

    /**
     * 获取热词列表
     *
     * @param uid
     * @return
     */
    public static String getKeyWordList(int uid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/get-keyword-list.json?",
                "uid=" + uid,
                getApiToken());
    }

    public static String searchMusicByKey(int index, int bpm, int scene, int genre, int duration, String search) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/search-mix.json?",
                "index=", Integer.toString(index),
                "&dicBpm=", Integer.toString(bpm),
                "&scene=", Integer.toString(scene),
                "&genre=", Integer.toString(genre),
                "&dicTrackLength=", Integer.toString(duration),
                "&search=", search,
                getApiToken());
    }

    public static String searchMusicByKey(int index, String search) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/search-mix.json?",
                "index=", Integer.toString(index),
                "&search=", search,
                getApiToken());
    }

    /**
     * 获取推荐音乐
     */
    public static String getRecommendMusic() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/mix/recommend-mix.json?",
                getApiToken());
    }

    //endregion ============================================================

    //region ============================== 运动模块 ==============================

    public static String getSyncToQQSportUrl() {
        return "https://openmobile.qq.com/v3/health/report_steps";
    }

//    /**
//     * 上传今日步数到微信运动
//     *
//     * @param unionId    用户的微信unionId
//     * @param openId     乐享动APP在微信开发者平台的openId
//     * @param todaySteps 用户今日步数
//     * @return 上传今日步数到微信运动的请求地址
//     */
//    public static String setWeChatTodaySteps(String unionId, String openId, int todaySteps) {
//        return jointStrings(Config.API_HOST, Config.API_PORT,
//                "/wx-run/set-step.json?unionid=", unionId,
//                "&openid=", openId,
//                "&step=", String.valueOf(todaySteps),
//                getApiToken());
//    }

    /**
     * 上传今日步数到微信运动
     *
     * @param parameter 步数信息加密后的信息
     * @return 上传今日步数到微信运动的请求地址
     */
    public static String setWeChatTodaySteps(String parameter) {
        // _terminal = 2 表示终端为android
        String token = String.format("&_product=fitmix&_terminal=2&_lan=%s&_ch=%s&_v=%s&_nw=%s&_sdk=%s",
                ApiUtils.getLanguage(),
                ApiUtils.getApkChannel(),
                ApiUtils.getApkVersionCode(),
                ApiUtils.getNetWorkType(),
                ApiUtils.getPhoneInfo()//
                //ApiUtils.getPhoneSdk()
        );
        //判断_k
        if (!TextUtils.isEmpty(ApiUtils.getApiToken())) {
            token = token + "&_k=" + ApiUtils.getApiToken();
        }

        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/wx-run/set/step.json?parameter=", parameter,
                token);
    }

    /**
     * 同步步数到QQ运动
     *
     * @param access_token 同步到的用户token
     * @param openid       同步到的用户openid
     * @param time         运动结束运动时间 秒为单位
     * @param distance     运动距离
     * @param steps        当天运动步数
     * @param duration     运动时长
     * @param calories     运动消耗卡路里
     * @return FormBody
     */
    public static FormBody syncToQQSport(String access_token, String openid, long time, long distance, int steps, long duration, long calories) {
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("access_token", access_token)
                .add("openid", openid)
                .add("oauth_consumer_key", Config.QQ_APPID)
                .add("pf", "qzone")
                .add("time", time + "")
                .add("distance", distance + "")
                .add("steps", steps + "")
                .add("duration", duration + "")
                .add("calories", calories + "");
        return builder.build();
    }

    /**
     * 从后台服务器获取用户历史跑步记录
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @return 从后台服务器获取用户历史跑步记录的请求地址
     */
    public static String getHistoryRunRecords(int uid, long lastUpdateTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run/history-run.json?uid=", String.valueOf(uid),
                "&lastUpdateTime=", String.valueOf(lastUpdateTime),
                getApiToken());
    }

    /**
     * 获取用户月运动排行榜数据
     *
     * @param uid  用户uid
     * @param time 当前时间戳
     * @return 从后台服务器获取用户历史跑步记录的请求地址
     */
    public static String getRankListData(int uid, long time) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run/month/rank/get.json?uid=", String.valueOf(uid),
                "&time=", String.valueOf(time),
                getApiToken());
    }


    /**
     * 运动月排行榜用户PK
     *
     * @param uid       用户uid
     * @param time      当前时间戳
     * @param targetUid pk用户UID
     * @return 从后台服务器获取用户历史跑步记录的请求地址
     */
    public static String getRankListPKData(int uid, long time, int targetUid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run/month/rank/pk.json?uid=", String.valueOf(uid),
                "&time=", String.valueOf(time),
                "&targetUid=", String.valueOf(targetUid),
                getApiToken());
    }

    /**
     * 运动月排行榜各个层次的排名
     *
     * @param uid   用户uid
     * @param time  当前时间戳
     * @param level 各个层次level
     * @return 从后台服务器获取用户历史跑步记录的请求地址
     */
    public static String getRankListLevelData(int uid, long time, int level, int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run/month/rank.json?uid=", String.valueOf(uid),
                "&time=", String.valueOf(time),
                "&filter[level]=" + level,
                "&pageNo=", String.valueOf(pageNo),
                getApiToken());
    }


    /**
     * 分享跑步记录
     *
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @return 从后台服务器获取分享跑步记录的请求地址
     */
    public static String shareRunRecord(long lastUpdateTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run-share/add-new.json?startTime=", String.valueOf(lastUpdateTime),
                getApiToken());
    }

    /**
     * 添加运动记录
     *
     * @param uid          用户ID
     * @param type         运动类型(跑步,骑行),跑步运动为1
     * @param mode         运动环境(1:室外,2:室内)
     * @param locationType 定位类型,1:GPS定位,2:LBS定位
     * @param bpm          平均步频(每分钟步数)
     * @param bpmMatch     平均步频与音乐BPM匹配度 (平均步频/音乐BPM)*100%
     * @param step         步数
     * @param calorie      卡路里
     * @param runTime      运动时长,单位毫秒
     * @param startTime    开始时间,单位毫秒
     * @param endTime      结束时间,单位毫秒
     * @param distance     运动距离,单位米
     * @param startLng     开始点经度
     * @param startLat     开始点纬度
     * @param endLng       结束点经度
     * @param endLat       结束点纬度
     * @return 从后台服务器获取上传跑步记录的请求地址
     */
    public static String addSportRecord(int uid, int type, int mode, int locationType, int bpm, int bpmMatch, int step,
                                        long calorie, long runTime, long startTime, long endTime, long distance,
                                        double startLng, double startLat, double endLng, double endLat) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run/add-run.json?uid=", String.valueOf(uid),
                "&type=", String.valueOf(type),
                "&model=", String.valueOf(mode),
                "&locationType=", String.valueOf(locationType),
                "&bpm=", String.valueOf(bpm),
                "&bpmMatch=", String.valueOf(bpmMatch),
                "&step=", String.valueOf(step),
                "&calorie=", String.valueOf(calorie),
                "&runTime=", String.valueOf(runTime),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&distance=", String.valueOf(distance),
                "&startLng=", String.valueOf(startLng),
                "&startLat=", String.valueOf(startLat),
                "&endLng=", String.valueOf(endLng),
                "&endLat=", String.valueOf(endLat),
                getApiToken());
    }

    /**
     * 添加运动记录（包括心率）
     *
     * @param uid           用户ID
     * @param type          运动类型(跑步,骑行),跑步运动为1
     * @param mode          运动环境(1:室外,2:室内)
     * @param locationType  定位类型,1:GPS定位,2:LBS定位
     * @param bpm           平均步频(每分钟步数)
     * @param bpmMatch      平均步频与音乐BPM匹配度 (平均步频/音乐BPM)*100%
     * @param step          步数
     * @param calorie       卡路里
     * @param runTime       运动时长,单位毫秒
     * @param startTime     开始时间,单位毫秒
     * @param endTime       结束时间,单位毫秒
     * @param distance      运动距离,单位米
     * @param startLng      开始点经度
     * @param startLat      开始点纬度
     * @param endLng        结束点经度
     * @param endLat        结束点纬度
     * @param heartRateData 心率数据
     * @param consumeFat    燃脂量
     * @param elevation     累积爬升
     * @return 从后台服务器获取上传跑步记录的请求地址
     */
    public static String addSportRecordWithHeartRate(int uid, int type, int mode, int locationType, int bpm, int bpmMatch, int step,
                                                     long calorie, long runTime, long startTime, long endTime, long distance,
                                                     double startLng, double startLat, double endLng, double endLat, String heartRateData
            , double consumeFat, double elevation) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run/" + ApiUtils.getApkVersionCode() + "/add-run.json?uid=", String.valueOf(uid),
                "&type=", String.valueOf(type),
                "&model=", String.valueOf(mode),
                "&locationType=", String.valueOf(locationType),
                "&bpm=", String.valueOf(bpm),
                "&bpmMatch=", String.valueOf(bpmMatch),
                "&step=", String.valueOf(step),
                "&calorie=", String.valueOf(calorie),
                "&runTime=", String.valueOf(runTime),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&distance=", String.valueOf(distance),
                "&startLng=", String.valueOf(startLng),
                "&startLat=", String.valueOf(startLat),
                "&endLng=", String.valueOf(endLng),
                "&endLat=", String.valueOf(endLat),
                "&heartRate=", heartRateData,
                "&consumeFat=", String.valueOf(consumeFat),
                "&elevation=", String.valueOf(elevation),
                getApiToken());
    }

    /**
     * 获取删除后台服务器上的跑步记录的请求地址
     *
     * @param uid          跑步记录对应的用户uid
     * @param runStartTime 跑步记录的开始时间,单位为毫秒
     * @return 删除后台服务器上的跑步记录的请求地址
     */
    public static String deleteRunRecord(int uid, long runStartTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run/remove-run.json?uid=", String.valueOf(uid),
                "&startTime=", String.valueOf(runStartTime),
                getApiToken());
    }

    /**
     * 小清新方式分享跑步记录
     *
     * @param uid      用户编号
     * @param distance 运动距离,单位为米
     * @param runTime  运动时长,单位为秒
     * @param step     运动步数
     * @param bpm      运动步频,单位公里/分钟
     * @param calorie  消耗卡路里,单位大卡
     * @return 从后台服务器获取小清新分享跑步记录的请求地址
     */
    public static String shareRunRecordLite(int uid, long distance, long runTime, long step, long bpm, long calorie) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run-share/add.json?uid=", String.valueOf(uid),
                "&distance=", String.valueOf(distance),
                "&runTime=", String.valueOf(runTime),
                "&step=", String.valueOf(step),
                "&matchingSpeed=", String.valueOf(bpm),
                "&calorie=", String.valueOf(calorie),
                getApiToken());
    }


    /**
     * 获取语音包列表信息
     */
    public static String getVoicePackageInfo(int voiceType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/voice/packets.json?voiceType=", String.valueOf(voiceType),
                getApiToken());
    }

    /**
     * 获取语音包下载信息
     */
    public static String getVoicePackageUrlInfo(int voiceId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/voice/get/file.json?voiceId=", String.valueOf(voiceId),
                getApiToken());
    }

    public static String addRestHeartRateInfo(int uid, int heartRateVal, long time) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/rest-heart-rate/add.json?uid=", String.valueOf(uid),
                "&heartRateVal=", Integer.toString(heartRateVal),
                "&detectTime=", Long.toString(time),
                getApiToken());
    }

    public static String getAllRestHeartRateHistory(int uid, int index, int isAll) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/rest-heart-rate/list.json?uid=", String.valueOf(uid),
                "&index=", String.valueOf(index),
                "&isAll=", String.valueOf(isAll),
                getApiToken());
    }

    /**
     * 从后台服务器获取用户历史跳绳记录
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @return 从后台服务器获取用户历史跳绳记录的请求地址
     */
    public static String getHistorySkipRecords(int uid, long lastUpdateTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/history.json?uid=", String.valueOf(uid),
                "&lastAddTime=", String.valueOf(lastUpdateTime),
                getApiToken());
    }

    /**
     * 添加跳绳记录到服务器
     *
     * @param uid        用户id
     * @param bpm        跳绳平均跳频
     * @param runTime    跳绳持续时间
     * @param startTime  跳绳开始时间
     * @param endTime    跳绳结束时间
     * @param type       类型
     * @param bpmMatch   与歌曲匹配度
     * @param skipNumber 跳绳个数
     * @param calorie    跳绳消耗卡路里
     * @param heartRate  心率
     * @return
     */
    public static String addSkipSportRecord(int uid, int bpm, long runTime, long startTime, long endTime, int type,
                                            int bpmMatch, int skipNumber,
                                            long calorie, double heartRate) {

        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/add.json?uid=", String.valueOf(uid),
                "&bpm=", String.valueOf(bpm),
                "&runTime=", String.valueOf(runTime),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&type=", String.valueOf(type),
                "&bpmMatch=", String.valueOf(bpmMatch),
                "&skipNum=", String.valueOf(skipNumber),
                "&calorie=", String.valueOf(calorie),
                "&heartRate=", String.valueOf(heartRate),
                getApiToken());
    }

    /**
     * 添加跳绳记录到服务器
     *
     * @param uid        用户id
     * @param bpm        跳绳平均跳频
     * @param runTime    跳绳持续时间
     * @param startTime  跳绳开始时间
     * @param endTime    跳绳结束时间
     * @param type       类型
     * @param bpmMatch   与歌曲匹配度
     * @param skipNumber 跳绳个数
     * @param calorie    跳绳消耗卡路里
     * @return
     */
    public static String addSkipSportRecordWithHeartRate(int uid, int bpm, long runTime, long startTime, long endTime, int type,
                                                         int bpmMatch, int skipNumber, long calorie, String heartRateData) {


        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/", String.valueOf(ApiUtils.getApkVersionCode()), "/add.json?uid=", String.valueOf(uid),
                "&bpm=", String.valueOf(bpm),
                "&runTime=", String.valueOf(runTime),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&type=", String.valueOf(type),
                "&bpmMatch=", String.valueOf(bpmMatch),
                "&skipNum=", String.valueOf(skipNumber),
                "&calorie=", String.valueOf(calorie),
                "&heartRate=", TextUtils.isEmpty(heartRateData) ? "" : heartRateData,
                getApiToken());
    }

    /**
     * 添加跳绳记录到服务器
     *
     * @param uid                  用户id
     * @param bpm                  跳绳平均跳频
     * @param runTime              跳绳持续时间
     * @param startTime            跳绳开始时间
     * @param endTime              跳绳结束时间
     * @param type                 类型
     * @param bpmMatch             与歌曲匹配度
     * @param skipNumber           跳绳个数
     * @param calorie              跳绳消耗卡路里
     * @param heartRateAvg         心率平均值
     * @param maxHeartRate         最大心率
     * @param minHeartRate         最小心率
     * @param consumptionSpendTime 燃脂时长
     * @return
     */
    public static String addSkipSportRecordWithHeartRate(int uid, int bpm, long runTime, long startTime, long endTime, int type,
                                                         int bpmMatch, int skipNumber, long calorie, double heartRateAvg,
                                                         double maxHeartRate, double minHeartRate, double consumptionSpendTime) {

        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/", String.valueOf(ApiUtils.getApkVersionCode()), "/add.json?uid=", String.valueOf(uid),
                "&bpm=", String.valueOf(bpm),
                "&runTime=", String.valueOf(runTime),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&type=", String.valueOf(type),
                "&bpmMatch=", String.valueOf(bpmMatch),
                "&skipNum=", String.valueOf(skipNumber),
                "&calorie=", String.valueOf(calorie),
                "&heartRateAvg=", String.valueOf(heartRateAvg),
                "&maxHeartRate=", String.valueOf(maxHeartRate),
                "&minHeartRate=", String.valueOf(minHeartRate),
                "&consumptionSpendTime=", String.valueOf(consumptionSpendTime),
                getApiToken());
    }

    /**
     * 获取删除后台服务器上的跳绳记录的请求地址
     *
     * @param uid           跳绳记录对应的用户uid
     * @param skipStartTime 跳绳记录的开始时间,单位为毫秒
     * @return 删除后台服务器上的跳绳记录的请求地址
     */
    public static String deleteSkipRecord(int uid, long skipStartTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/remove.json?uid=", String.valueOf(uid),
                "&startTime=", String.valueOf(skipStartTime),
                getApiToken());
    }

    /**
     * 分享跑步记录
     *
     * @param startTime 跳绳开始的时间戳
     * @return 从后台服务器获取分享跑步记录的请求地址
     */
    public static String shareSkipRecord(long startTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-skip-rope/add-share-new.json?startTime=", String.valueOf(startTime),
                getApiToken());
    }

    /**
     * 生成训练计划
     */
    public static String createTrainingPlan(int runDistance, long competitionTime, long planTime, long projectTime, int runProject, int gender, int age) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/generating-plan.json?",
                "runDistance=", String.valueOf(runDistance),
                "&competitionTime=", String.valueOf(competitionTime),
                "&planTime=", String.valueOf(planTime),
                "&projectTime=", String.valueOf(projectTime),
                "&runProject=", String.valueOf(runProject),
                "&gender=", String.valueOf(gender),
                "&age=", String.valueOf(age),
                getApiToken());
    }

    /**
     * 获取进行中的计划
     */
    public static String getTrainingPlan() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/get-user-plan.json?",
                getApiToken());
    }

    /**
     * 获取结束的计划
     */
    public static String getTrainedPlan() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/get-past-plan.json?",
                getApiToken());
    }

    /**
     * 计划延期
     *
     * @param delayDay 最大值为7
     */
    public static String delayTrainPlan(int delayDay) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/delay-user-plan.json?",
                "delayDay=", String.valueOf(delayDay),
                getApiToken());
    }

    /**
     * 删除计划
     */
    public static String deleteTrainPlan() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/give-up-plan.json?",
                getApiToken());
    }

    /**
     * 获取当天训练计划
     */
    public static String getTodayStages() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/run-plan/get-today-stages.json?",
                getApiToken());
    }

    /**
     * 向后台上传用户传感器异常错误日志
     *
     * @return 向后台上传用户传感器异常错误日志的请求地址
     */
    public static String uploadErrorLog() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/app-error-upload.json?",
                getApiToken());
    }

    /**
     * 生成向后台上传用户传感器异常错误日志接口所需要的请求体
     *
     * @param content 自定义的错误日志
     * @param other   错误简述
     * @return FormBody
     */
    public static FormBody getErrorBody(String content, String other) {
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("content", content)
                .add("other", other);
        return builder.build();
    }


    /**
     * 添加手表运动记录
     *
     * @param uid        用户ID
     * @param type       运动类型 0或1:乐享动跑步 2:跳绳  3:手表运动记录
     * @param startTime  开始时间,单位毫秒
     * @param endTime    结束时间,单位毫秒
     * @param duration   运动时长,单位毫秒
     * @param calorie    卡路里,单位为大卡
     * @param consumeFat 脂肪燃烧量,单位为克
     * @param detail     手表运动数据
     * @return 从后台服务器获取上传手表运动记录的请求地址
     */
    public static String addWatchSportRecord(int uid, int type, long startTime, long endTime, long duration, int calorie, double consumeFat, String detail) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-run/add/watch/run.json?uid=", String.valueOf(uid),
                "&type=", String.valueOf(type),
                "&startTime=", String.valueOf(startTime),
                "&endTime=", String.valueOf(endTime),
                "&runTime=", String.valueOf(duration),
                "&calorie=", String.valueOf(calorie),
                "&watchData=", detail,
                "&consumeFat=", String.valueOf(consumeFat),
                getApiToken());
    }


    /**
     * 从后台服务器获取手表的运动记录
     *
     * @param uid
     * @param lastUpdateTime
     * @return 从后台服务器获取手表的运动记录的请求地址
     */
    public static String getWatchSportRecord(int uid, long lastUpdateTime) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/user-sport-watch/history.json?uid=", String.valueOf(uid),
                "&sportBTime=", String.valueOf(lastUpdateTime),
                getApiToken());
    }

    //endregion ============================================================

    //region ============================== 俱乐部模块 ==============================

    /**
     * 获取俱乐部列表
     */
    public static String getClubList(int Uid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/list.json?",
                "uid=" + Uid,
                getApiToken());
    }

    /**
     * 获取俱乐部最新动态
     */
    public static String getClubDynamicUrl(int clubId, int index) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/dynamic.json?",
                "clubId=" + clubId,
                "&index=" + index,
                getApiToken());
    }

    /**
     * 获取俱乐部公告
     */
    public static String getClubNoticeUrl(int clubId, int index) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-notice/page.json?",
                "clubId=" + clubId,
                "&index=" + index,
                getApiToken());
    }

    /**
     * 获取俱乐部排行列表
     */
    public static String getClubRankList(int clubId, int index, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-ranking/user-ranking.json?",
                "clubId=" + clubId,
                "&index=" + index,
                "&type=" + type,
                getApiToken());
    }

    /**
     * 获取俱乐部排行静态信息
     */
    public static String getClubRankInfo(int clubId, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-ranking/ranking.json?",
                "clubId=" + clubId,
                "&type=" + type,
                getApiToken());
    }

    /**
     * 获取俱乐部留言
     */
    public static String getClubMessage(int clubId, int index) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-message/page.json?",
                "clubId=" + clubId,
                "&index=" + index,
                getApiToken());
    }

    /**
     * 获取俱乐部活跃信息
     */
    public static String getClubActiveInfo(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/active.json?",
                "clubId=" + clubId,
                getApiToken());
    }

    /**
     * 获取俱乐部活跃用户信息
     */
    public static String getClubActiveUser(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/active-user.json?",
                "clubId=" + clubId,
                getApiToken());
    }

    /**
     * 获取俱乐部成员列表
     */
    public static String getClubMemberList(int clubId, int index) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-member/list.json?",
                "clubId=" + clubId,
                "&index=" + index,
                getApiToken());
    }


    /**
     * 删除俱乐部成员
     */
    public static String deleteClubMember(int clubId, int quitUid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-member/forced-quit.json?",
                "clubId=" + clubId,
                "&quitUid=" + quitUid,
                getApiToken());
    }

    /**
     * 获取最后一次运动记录
     *
     * @param uid 用户ID
     */
    public static String getLastRunLogInfo(int uid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-member/last-run.json?",
                "targetUid=" + uid,
                getApiToken());
    }

    /**
     * 退出俱乐部
     *
     * @param clubId 俱乐部ID
     */
    public static String quitClub(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-member/quit.json?",
                "clubId=" + clubId,
                getApiToken());
    }

    /**
     * 获取分享俱乐部地址
     *
     * @param clubId 俱乐部ID
     */
    public static String getShareClubUrl(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/share-url.json?",
                "clubId=" + clubId,
                getApiToken());
    }

    /**
     * 创建俱乐部
     *
     * @param clubName 俱乐部名称
     * @param clubDesc 俱乐部描述
     */
    public static String createClub(String clubName, String clubDesc) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/add.json?",
                "name=" + clubName,
                "&desc=" + clubDesc,
                getApiToken());
    }

    /**
     * 更改俱乐部
     *
     * @param clubId   俱乐部ID
     * @param clubName 俱乐部名称
     * @param clubDesc 俱乐部描述
     */
    public static String modifyClub(int clubId, String clubName, String clubDesc) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/modify.json?",
                "clubId=" + clubId,
                "&name=" + clubName,
                "&desc=" + clubDesc,
                getApiToken());
    }

    /**
     * 删除俱乐部
     *
     * @param clubId 俱乐部ID
     */
    public static String deleteClub(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/remove.json?",
                "clubId=" + clubId,
                getApiToken());
    }

    /**
     * 创建俱乐部公告
     *
     * @param clubId    俱乐部Id
     * @param name      公告主题
     * @param content   FIXME 不知这个字段什么用 传""???
     * @param address   活动地点
     * @param beginTime 开始时间
     * @param endTime   结束时间
     * @param desc      活动描述
     */
    public static String createClubNotice(int clubId, String name, String content, String address, long beginTime, long endTime, String desc) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-notice/add.json?",
                "clubId=" + clubId,
                "&beginTime=" + beginTime,
                "&endTime=" + endTime,
                "&name=" + getEncodedString(name),
                "&content=" + getEncodedString(content),
                "&address=" + getEncodedString(address),
                "&desc=" + getEncodedString(desc),
                getApiToken());
    }

    /**
     * 获得utf-8编码的字符串
     */
    private static String getEncodedString(String string) {
        try {
            return URLEncoder.encode(string, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 更改俱乐部公告
     *
     * @param noticeId  公告Id
     * @param clubId    俱乐部Id
     * @param name      公告主题
     * @param content   FIXME 不知这个字段什么用 传""???
     * @param address   活动地点
     * @param beginTime 开始时间
     * @param endTime   结束时间
     * @param desc      活动描述
     */
    public static String modifyClubNotice(int noticeId, int clubId, String name, String content, String address, long beginTime, long endTime, String desc) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-notice/modify.json?",
                "id=" + noticeId,
                "&clubId=" + clubId,
                "&beginTime=" + beginTime,
                "&endTime=" + endTime,
                "&name=" + getEncodedString(name),
                "&content=" + getEncodedString(content),
                "&address=" + getEncodedString(address),
                "&desc=" + getEncodedString(desc),
                getApiToken());
    }

    /**
     * 删除俱乐部
     *
     * @param noticeId 公告Id
     * @param clubId   俱乐部ID
     */
    public static String deleteClubNotice(int noticeId, int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-notice/remove.json?",
                "id=" + noticeId,
                "&clubId=" + clubId,
                getApiToken());
    }

    /**
     * 查找俱乐部
     *
     * @param clubId 俱乐部ID
     */
    public static String findClub(int clubId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club/find.json?",
                "&clubId=" + clubId,
                getApiToken());
    }

    /**
     * 添加俱乐部留言
     *
     * @param clubId  俱乐部ID
     * @param content 留言内容
     */
    public static String addClubMessage(int clubId, String content) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-message/add.json?",
                "clubId=" + clubId,
                "&content=" + getEncodedString(content),
                getApiToken());
    }


    /**
     * 添加俱乐部留言
     *
     * @param clubId 俱乐部ID
     * @param addUid 加入俱乐部的成员Id
     */
    public static String joinClub(String clubId, int addUid) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/club-member/add.json?",
                "clubId=" + clubId,
                "&addUid=" + addUid,
                getApiToken());
    }

    //endregion ============================================================

    //region ============================== 赛事模块 ==============================

    /**
     * 赛事详情
     *
     * @param activityID 详情页对应的ID //FIXME 不知道还要传其他参数不,后台还没给结果
     * @return 赛事详情的url
     */
    public static String getCompetitionDetailUrl(int activityID) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/activity/to-activity.htm?",
                "activityId=" + activityID);
    }

    /**
     * 获取赛事列表
     *
     * @param pageNo 分页编号
     */
    public static String getCompetitionList(int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/activity/get-activity-list.json?",
                "pageNo=" + pageNo,
                getApiToken());
    }

    /**
     * 获取视频列表
     *
     * @param pageNo 分页编号
     */
    public static String getVideoList(int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/video/get-video-list.json?",
                "pageNo=" + pageNo,
                getApiToken());
    }

    /**
     * 获取视频详情信息
     *
     * @param videoId 视频id
     */
    public static String getVideoDetail(int videoId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/video/get-video-details.json?",
                "videoId=", String.valueOf(videoId),
                getApiToken());
    }

    /**
     * 获取话题列表
     *
     * @param pageNo    分页编号
     * @param orderType 结果排序类型,1:根据添加时间排序,2:根据回答数排序,3:根据点赞数排序
     */
    public static String getTopicList(int pageNo, int orderType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/list.json?",
                "pageNo=" + pageNo,
                "&filter[searchType]=" + orderType,
                getApiToken());
    }

    /**
     * 获取精选话题列表
     */
    public static String getHandPickTopicList() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/banners.json?",
                getApiToken());
    }

    /**
     * 获取话题的回答列表
     *
     * @param topicId  话题编号
     * @param pageNo   分页编号
     * @param getTheme 是否获取话题详情内容,0:否,1:是
     */
    // filter[getTheme]
    public static String getTopicAnswerList(int topicId, int orderType, int getTheme, int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/answer/list.json?",
                "themeId=" + topicId,
                "&filter[searchType]=" + orderType,
                "&filter[getTheme]=" + getTheme,
                "&pageNo=" + pageNo,
                getApiToken());
    }

    /**
     * 获取话题的讨论列表
     *
     * @param topicId 话题编号
     * @param pageNo  分页编号
     */
    public static String getTopicDiscussList(int topicId, int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/discuss/list.json?",
                "themeId=", String.valueOf(topicId),
                "&pageNo=", String.valueOf(pageNo),
                getApiToken());
    }

    /**
     * 搜索话题
     *
     * @param searchText 搜索关键字
     * @param pageNo     页码
     */
    public static String searchTopic(String searchText, int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/list.json?",
                "filter[searchText]=" + searchText,
                "&pageNo=", String.valueOf(pageNo),
                getApiToken());
    }

    /**
     * 获取我的回答列表
     *
     * @param pageNo 页码
     */
    public static String getMyAnswerList(int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/my/answer/list.json?",
                "pageNo=", String.valueOf(pageNo),
                getApiToken());
    }

    /**
     * 获取我的提问列表
     *
     * @param pageNo 页码
     */
    public static String getMyQuestionList(int pageNo) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/my/theme/list.json?",
                "pageNo=", String.valueOf(pageNo),
                getApiToken());
    }

    /**
     * 添加话题
     *
     * @param title   话题标题
     * @param content 话题内容
     * @return 添加话题请求表单
     */
    public static FormBody addTopic(String title, String content) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("title", title);
//        if (!TextUtils.isEmpty(content)) {
        baseBuilder.add("content", content);
//        }
        return baseBuilder.build();
    }

    /**
     * 添加话题答案
     *
     * @param topicId 话题编号
     * @param content 答案内容
     * @return 添加话题答案请求表单
     */
    public static FormBody addTopicAnswer(int topicId, String content) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("parentThemeId", String.valueOf(topicId));
        baseBuilder.add("content", content);
        return baseBuilder.build();
    }


    /**
     * 添加话题答案的评论
     *
     * @param answerId 答案编号
     * @param content  答案内容
     * @return 添加话题答案的评论请求表单
     */
    public static FormBody addTopicAnswerDiscuss(int answerId, int discussId, int discussUid, String content) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        if (discussId == 0 && discussUid == 0) {
            baseBuilder.add("themeId", String.valueOf(answerId));
            baseBuilder.add("content", content);
        } else if (discussId != 0 && discussUid != 0) {
            baseBuilder.add("themeId", String.valueOf(answerId));
            baseBuilder.add("discussId", String.valueOf(discussId));
            baseBuilder.add("discussUid", String.valueOf(discussUid));
            baseBuilder.add("content", content);
        }

        return baseBuilder.build();
    }

    /**
     * 话题答案点赞
     *
     * @param answerId 答案编号
     * @param type     观点类型,1:点赞,0:中立不操作
     */
    public static String likeTopicAnswer(int answerId, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/opinion.json?",
                "themeId=", String.valueOf(answerId),
                "&type=", String.valueOf(type),
                getApiToken());
    }

    /**
     * 评论点赞
     *
     * @param discussId 评论编号
     * @param type      观点类型,1:点赞,0:中立不操作
     */
    public static String likeTopicDiscuss(int discussId, int type) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/discuss/opinion.json?",
                "discussId=", String.valueOf(discussId),
                "&type=", String.valueOf(type),
                getApiToken());
    }

    /**
     * 上传图片
     */
    public static String uploadImage() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/upload/img.json?",
                getApiToken());
    }

    /**
     * 根据话题答案编号,获取话题答案
     *
     * @param answerId 话题答案编号
     */
    public static String getTopicAnswerByAnswerId(int answerId) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/theme/answer/get.json?themeId=" + answerId,
                getApiToken());
    }

    /**
     * 编辑话题答案
     *
     * @param answerId 话题答案编号
     * @param content  答案内容
     * @return 编辑话题答案请求表单
     */
    public static FormBody editTopicAnswer(int answerId, String content) {
        FormBody.Builder baseBuilder = getBaseBuilder();
        baseBuilder.add("themeId", String.valueOf(answerId));
        baseBuilder.add("content", content);
        return baseBuilder.build();
    }

    /**
     * 获取与自己相关的最新话题回答消息
     */
    public static String getNewAnswerMessage() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/my/new/theme/msg.json?", getApiToken());
    }

    /**
     * 获取与自己相关的最新话题讨论消息
     */
    public static String getNewDiscussMessage() {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/my/new/discuss/msg.json?", getApiToken());
    }

    /**
     * 检测服务器上心率耳机固件最新版本信息
     *
     * @return 服务器上心率耳机最新固件版本信息请求地址
     */
    public static String checkFirmwareVersion(String version) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/headset/upgrade.json?version=",
                version,
                getApiToken());
    }

    /**
     * 检测服务器上手表固件最新版本信息
     *
     * @param version      手表本地当前版本号
     * @param firmwareType 固件类型 21:手表、22:阿波罗
     * @return 服务器上最新手表固件信息请求地址
     */
    public static String watchFirmwareVersion(String version, String firmwareType) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/watch/upgrade.json?version=", version,
                "&fileType=", firmwareType,
                getApiToken());
    }

    /**
     * 获取城市天气信息接口
     *
     * @param location 城市位置信息,格式为 经度,纬度
     */
    public static String getCityWeather(String location) {
        return jointStrings(Config.API_HOST, Config.API_PORT,
                "/surprise/get-weather.json?lonlat=", location,
                getApiToken());
    }

    /**
     * 上传错误报告
     *
     * @param uid
     * @param chipId
     */
    public static String uploadErrorReport(String uid, String chipId){
        return jointStrings(Config.API_HOST,  Config.API_PORT,
                "/watch/log.json?",getApiToken(),"&chipID=",chipId);
    }

    //endregion ============================================================

}
