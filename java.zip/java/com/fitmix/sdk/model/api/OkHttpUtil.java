package com.fitmix.sdk.model.api;


import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.common.Logger;
import com.parkingwang.okhttp3.LogInterceptor.LogInterceptor;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManagerFactory;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;

public class OkHttpUtil {

    /**
     * http MIME json头
     */
    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");

    /**
     * https证书信息
     */
    private String CER_FITMIX = "-----BEGIN CERTIFICATE-----\n" +
            "MIIGITCCBQmgAwIBAgIQB052rGPllhZaFyKtuwa6VjANBgkqhkiG9w0BAQsFADBe\n" +
            "MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3\n" +
            "d3cuZGlnaWNlcnQuY29tMR0wGwYDVQQDExRHZW9UcnVzdCBSU0EgQ0EgMjAxODAe\n" +
            "Fw0xODA0MTgwMDAwMDBaFw0xOTA0MTgxMjAwMDBaMIGNMQswCQYDVQQGEwJDTjES\n" +
            "MBAGA1UECAwJ5bm/5Lic55yBMRIwEAYDVQQHDAnmt7HlnLPluIIxLTArBgNVBAoM\n" +
            "JOa3seWcs+esrOS4gOiTneetueenkeaKgOaciemZkOWFrOWPuDELMAkGA1UECxMC\n" +
            "SVQxGjAYBgNVBAMTEWFwcHQuaWdlZWtlcnkuY29tMIIBIjANBgkqhkiG9w0BAQEF\n" +
            "AAOCAQ8AMIIBCgKCAQEAragaJeciqKk5eRt76TcbdXAfIei08gKg5ll0FBUSSpV+\n" +
            "0LWVedfRuULXCuA3CkdDPxn4BcG4xq23iVCwYMgm7ZeTsyangUApuyRwS92iCLGT\n" +
            "esfrJ1lpkiNa1y59bBQg3JprxF2V3kW67/vNLh8xQ6Txd7UW8/lbRcNdGrImGkpP\n" +
            "JCAQF8Rm2pwm+H6EpcoCs6Wk3WNobhByGDVoLyppauoiTHYiZ6PO2BFaEklvrenh\n" +
            "K1lmLbi7/sTtyREOSxy9F0/1EXSrjNawFgP8oBmvN9KrZMgxA/8dYXlF5WroAi6C\n" +
            "zHjl+SrJDuIS0wFfbzlzBV8KEyQgY4h79sqPB5E/VQIDAQABo4ICqTCCAqUwHwYD\n" +
            "VR0jBBgwFoAUkFj/sJx1qFFUd7Ht8qNDFjiebMUwHQYDVR0OBBYEFCG1iBz6FZ/0\n" +
            "GcCC+V6WsXMUwE7fMBwGA1UdEQQVMBOCEWFwcHQuaWdlZWtlcnkuY29tMA4GA1Ud\n" +
            "DwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwPgYDVR0f\n" +
            "BDcwNTAzoDGgL4YtaHR0cDovL2NkcC5nZW90cnVzdC5jb20vR2VvVHJ1c3RSU0FD\n" +
            "QTIwMTguY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9bAEBMCowKAYIKwYBBQUHAgEW\n" +
            "HGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQICMHUGCCsGAQUF\n" +
            "BwEBBGkwZzAmBggrBgEFBQcwAYYaaHR0cDovL3N0YXR1cy5nZW90cnVzdC5jb20w\n" +
            "PQYIKwYBBQUHMAKGMWh0dHA6Ly9jYWNlcnRzLmdlb3RydXN0LmNvbS9HZW9UcnVz\n" +
            "dFJTQUNBMjAxOC5jcnQwCQYDVR0TBAIwADCCAQQGCisGAQQB1nkCBAIEgfUEgfIA\n" +
            "8AB1AKS5CZC0GFgUh7sTosxncAo8NZgE+RvfuON3zQ7IDdwQAAABYtbAbLIAAAQD\n" +
            "AEYwRAIgMnHuKGLz/OEZgLBsXuuWCm2OPyFdRO03Lq0UX+eIUgMCIB3yEYgETtoF\n" +
            "3AL9kKU5MRXU6dAXBt6O/OYd1Ri7vT4fAHcAb1N2rDHwMRnYmQCkURX/dxUcEdkC\n" +
            "wQApBo2yCJo32RMAAAFi1sBtwAAABAMASDBGAiEA/zC8O/ov6VsTuPrOSrGxrJZ5\n" +
            "NmBByiIIkhjSSr8EplICIQCfdh0Yi7u9NWgYqfPn3j9/eV1T1tkBkvE1v4VZe5A2\n" +
            "hjANBgkqhkiG9w0BAQsFAAOCAQEAhil0PgX8wyWMmi1IXYZcQenIWPiS3u7Mt69I\n" +
            "yo1WBH+PZyNRTMYFGXfDhOb4UmO6KhelHZ6mEEeQBRfQRBv0C5v9B5V3P6/Fhv9/\n" +
            "aj/PUK+noZ15Mr9kxx7XR5daUjaUZ3m7SwvkR89wa7ARAv4OEZYB5BrhzuXQASb/\n" +
            "RzLDJG/LdCxjf7zn6C+kLtQNILrLxcmFGNQG7CDSNG2/e1xSuCwfkPzzGxb1+QCe\n" +
            "dOEoCiR/akk2pRrqekkboc7OuTYThbIxGYml48QTD3bHIUwxymfBpI4hTTcgaS77\n" +
            "sYPrw55zqA4c8cCuIIht1Zslnjv3zfCih8caPBw3234dDcrz1A==\n" +
            "-----END CERTIFICATE-----";

    private static OkHttpUtil instance;
    private OkHttpClient mOkHttpClient;

    public static OkHttpUtil getInstance() {
        if (instance == null) {
            instance = new OkHttpUtil();
        }
        return instance;
    }

    public OkHttpClient getClient() {
        if (mOkHttpClient == null) {
            if (Config.USE_HTTPS) {
                SSLContext sslContext = null;
                try {
                    CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
                    KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                    keyStore.load(null);
//                    InputStream certificate = MixApp.getContext().getAssets().open("test.cer");
                    InputStream certificate = new Buffer().writeUtf8(CER_FITMIX).inputStream();
                    if (certificate != null) {
                        String certificateAlias = "mixHttps";
                        keyStore.setCertificateEntry(certificateAlias, certificateFactory.generateCertificate(certificate));
                        try {
                            if (certificate != null)
                                certificate.close();
                        } catch (IOException e) {
                        }
                    }

                    sslContext = SSLContext.getInstance("TLS");
                    TrustManagerFactory trustManagerFactory =
                            TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

                    trustManagerFactory.init(keyStore);
                    sslContext.init(null, trustManagerFactory.getTrustManagers(), new SecureRandom());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                mOkHttpClient = new OkHttpClient.Builder()
                        .connectTimeout(90, TimeUnit.SECONDS)
                        .writeTimeout(90, TimeUnit.SECONDS)
                        .readTimeout(90, TimeUnit.SECONDS)
                        .hostnameVerifier(new HostnameVerifier() {
                            @Override
                            public boolean verify(String hostname, SSLSession session) {
//                                Logger.i(Logger.DEBUG_TAG, "hostnameVerifier-->hostname:" + hostname);
                                return Config.API_HOST.contains(hostname);//主机验证
                            }
                        })
                        .sslSocketFactory(sslContext.getSocketFactory())//https
                        .build();
            } else {
                mOkHttpClient = new OkHttpClient.Builder()
                        .addInterceptor(new LogInterceptor(new LogInterceptor.Logger() {
                            @Override
                            public void log(String message) {
                                Logger.d("okhttp",message);
                            }
                        }))
                        .connectTimeout(90, TimeUnit.SECONDS)
                        .writeTimeout(90, TimeUnit.SECONDS)
                        .readTimeout(90, TimeUnit.SECONDS)
                        .build();
            }
        }

        return mOkHttpClient;
    }

    /**
     * 阻塞方式http请求。
     *
     * @param request http请求实体
     * @return http响应实体
     */
    public Response execute(Request request) {
        if (request == null)
            return null;
        Response response = null;
        try {
            response = getClient().newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
            Logger.e(Logger.DATA_FLOW_TAG, "execute error:" + e.getMessage());
        }
        if (response == null)
            return null;
        return response;
    }

    /**
     * 异步方式http请求。
     *
     * @param request          http请求实体
     * @param responseCallback http请求回调
     */
    public void enqueue(Request request, Callback responseCallback) {
        if (request == null)
            return;
        getClient().newCall(request).enqueue(responseCallback);
    }

    /**
     * 异步方式http请求,且不在意返回结果（实现空callback）
     *
     * @param request http请求实体
     */
    public void enqueue(Request request) {
        if (request == null)
            return;
        Callback callback = new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

            }
        };
        enqueue(request, callback);
    }

    /**
     * 阻塞方式http请求。
     *
     * @param url http请求url
     * @return http响应实体
     */
    public Response getResponseFromServer(String url) {
        if (url == null || url.isEmpty())
            return null;
        Request request = new Request.Builder().url(url)
                .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                        ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                        ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                .build();
        return execute(request);
    }

    /**
     * 阻塞方式http请求
     *
     * @param url http请求url
     * @return 字符串结果
     */
    public String getStringFromServer(String url) {
        Response response = getResponseFromServer(url);
        if (response == null)
            return null;
        if (response.isSuccessful()) {
            String responseUrl = null;
            try {
                responseUrl = response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return responseUrl;
        }
        return "{code:" + response.code() + "}";

    }

    /**
     * 上传单个文件请求
     *
     * @param url   http请求url
     * @param sFile 要上传的文件的本地绝对路径
     * @param sTag  要上传的文件标签
     * @return
     */
    public String uploadToServer(String url, String sFile, String sTag) {
        if (url == null || url.isEmpty())
            return null;
        if (sFile == null || sFile.isEmpty())
            return null;
        if (sTag == null || sTag.isEmpty())
            return null;

        File file = new File(sFile);
        Request request;
        if (file.exists()) {
            String sString = "form-data; name=\"" + sTag + "\";filename=\""
                    + file.getName() + "\"";

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(sTag, file.getName(),
                            RequestBody.create(null, file))
                    .addPart(
                            Headers.of("Content-Disposition", sString),
                            RequestBody.create(
                                    MediaType.parse("application/octet-stream"),
                                    file)).build();
            request = new Request.Builder().url(url)
                    .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                            ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                            ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                    .post(requestBody).build();
        } else {
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addPart(Headers.of("Content-Disposition", "form-data; name=\"" + sTag + "\""),
                            RequestBody.create(null, ""))
                    .build();
            request = new Request.Builder().url(url)
                    .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                            ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                            ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                    .post(requestBody).build();
        }
        try {
            OkHttpClient client =  new OkHttpClient.Builder()
                    .connectTimeout(60,TimeUnit.SECONDS)
                    .addInterceptor(new LogInterceptor(new LogInterceptor.Logger() {
                        @Override
                        public void log(String message) {
                            Logger.d("okhttp",message);
                        }
                    }))
                    .build();//TODO
            Response response = client.newCall(request).execute();
            if (response == null)
                return null;
            if (response.isSuccessful()) {
                String responseUrl = null;
                try {
                    responseUrl = response.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return responseUrl;
            }
            return "{code:" + response.code() + "}";
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "{code:" + ApiUtils.HTTP_REQUEST_EXCEPTION + "}";
    }

    /**
     * 上传多个文件请求
     *
     * @param url   http请求url
     * @param files 要上传的文件的本地绝对路径集合
     * @param tags  要上传的文件标签集合
     * @return
     */
    public String uploadToServer(String url, List<String> files, List<String> tags) {
        if (url == null || url.isEmpty())
            return null;
        if (files == null || tags == null) return null;
        if (files.size() != tags.size()) return null;

        boolean bExist = false;
        List<File> listFiles = new ArrayList<>();
        for (String fileName : files) {
            if (TextUtils.isEmpty(fileName))
                continue;
            File file = new File(fileName);
            if (file.exists()) {
                bExist = true;
            } else {
                file = null;
            }
            listFiles.add(file);
        }

        Request request;
        if (bExist) {
            MultipartBody.Builder builder = new MultipartBody.Builder();
            for (int i = 0; i < files.size(); i++) {
                if (listFiles.get(i) == null) continue;
                String sString = "form-data;name=\"" + tags.get(i) + "\";filename=\""
                        + listFiles.get(i).getName() + "\"";
                builder.addPart(
                        Headers.of("Content-Disposition", sString),
                        RequestBody.create(
                                MediaType.parse("application/octet-stream"),
                                listFiles.get(i)));
            }
            RequestBody requestBody = builder.setType(MultipartBody.FORM).build();
            request = new Request.Builder().url(url)
                    .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                            ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                            ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                    .post(requestBody)
                    .build();
        } else {
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addPart(Headers.of("Content-Disposition", "form-data; name=\"" + tags.get(0) + "\""),
                            RequestBody.create(null, ""))
                    .build();
            request = new Request.Builder().url(url)
                    .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                            ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                            ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                    .post(requestBody).build();
        }

        try {

            OkHttpClient client =  new OkHttpClient.Builder()
                    .addInterceptor(new LogInterceptor(new LogInterceptor.Logger() {
                        @Override
                        public void log(String message) {
                            Logger.d("okhttp",message);
                        }
                    }))
                    .build();
            Response response = client.newCall(request).execute();

            if (response != null && response.isSuccessful()) {
                String responseUrl;
                try {
                    responseUrl = response.body().string();
                    if (responseUrl != null) {
//                        Logger.i(Logger.DATA_FLOW_TAG,"uploadToServer responseUrl:"+responseUrl);
                        return responseUrl;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    if (!TextUtils.isEmpty(e.getMessage())) {
                        Logger.e(Logger.DATA_FLOW_TAG, "uploadToServer error:" + e.getMessage());
                    }
                }
                return "{code:" + response.code() + "}";
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "{code:" + ApiUtils.HTTP_REQUEST_EXCEPTION + "}";
    }

}