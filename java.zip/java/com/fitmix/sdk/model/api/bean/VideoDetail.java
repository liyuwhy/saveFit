package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.Video;

/**
 * 获取视频详情信息(/video/get-video-details.json)接口返回的结果
 */

public class VideoDetail extends BaseBean {

    /**
     * video : {"addTime":1465183809135,"content":"哈哈最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜最梦幻的山地自行车之夜","id":8,"posterName":"258973379c7b97d356ba9875ce988aeb.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/693583cae8b44e4b934cd8eee6de6447.jpg","shareCount":47,"sort":5,"status":0,"title":"最梦幻的山地自行车之夜","trackLength":454,"videoName":"最梦幻的山地自行车之夜.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/517311eb7e214d48ab2c786fec70a5ad.mp4"}
     */

    private Video video;

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }
}
