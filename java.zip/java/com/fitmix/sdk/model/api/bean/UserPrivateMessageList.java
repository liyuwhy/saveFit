package com.fitmix.sdk.model.api.bean;

import android.support.annotation.NonNull;

import java.util.List;

/**
 * 获取用户私信列表接口(/get/private/msg/list.json)返回的结果
 */

public class UserPrivateMessageList {


    /**
     * st : 1511432654524
     * page : {"filter":{"type":1,"uid":1340266,"groupIds":[43,44]},"hasNext":false,"hasPre":false,"index":0,"nextPage":1,"offset":0,"pageNo":1,"prePage":1,"result":[{"addTime":1511429426215,"id":44,"lastContent":"连接","lastMsgUid":1340266,"lastUpdateTime":1511430956597,"member":[1340266,0],"reject":0,"type":1},{"addTime":1511346342454,"id":43,"lastContent":"一个 v感觉","lastMsgUid":3901312,"lastUpdateTime":1511429218226,"member":[1340266,3901312],"reject":0,"type":1,"user":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"}}],"size":20,"total":2,"totalPages":1}
     * code : 0
     * k : 68ee380a1df444ed85310b22d138f49c
     */

    private long st;
    private PageBean page;
    private int code;
    private String k;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public static class PageBean {
        /**
         * filter : {"type":1,"uid":1340266,"groupIds":[43,44]}
         * hasNext : false
         * hasPre : false
         * index : 0
         * nextPage : 1
         * offset : 0
         * pageNo : 1
         * prePage : 1
         * result : [{"addTime":1511429426215,"id":44,"lastContent":"连接","lastMsgUid":1340266,"lastUpdateTime":1511430956597,"member":[1340266,0],"reject":0,"type":1},{"addTime":1511346342454,"id":43,"lastContent":"一个 v感觉","lastMsgUid":3901312,"lastUpdateTime":1511429218226,"member":[1340266,3901312],"reject":0,"type":1,"user":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"}}]
         * size : 20
         * total : 2
         * totalPages : 1
         */

        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int offset;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        private List<ResultBean> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getOffset() {
            return offset;
        }

        public void setOffset(int offset) {
            this.offset = offset;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<ResultBean> getResult() {
            return result;
        }

        public void setResult(List<ResultBean> result) {
            this.result = result;
        }

        public static class FilterBean {
            /**
             * type : 1
             * uid : 1340266
             * groupIds : [43,44]
             */

            private int type;
            private int uid;
            private List<Integer> groupIds;

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getUid() {
                return uid;
            }

            public void setUid(int uid) {
                this.uid = uid;
            }

            public List<Integer> getGroupIds() {
                return groupIds;
            }

            public void setGroupIds(List<Integer> groupIds) {
                this.groupIds = groupIds;
            }
        }

        public static class ResultBean implements Comparable<ResultBean> {
            /**
             * addTime : 1511429426215
             * id : 44
             * lastContent : 连接
             * lastMsgUid : 1340266
             * lastUpdateTime : 1511430956597
             * member : [1340266,0]
             * reject : 0
             * type : 1
             * memberString:[1340266,0]字符串
             * user : {"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"}
             */

            private long addTime;
            private int id;
            private String lastContent;
            private int lastMsgUid;
            private long lastUpdateTime;
            private int reject;
            private int type;
            private UserBean user;
            private List<Integer> member;
            private String memberString;

            public String getMemberString() {
                return memberString;
            }

            public void setMemberString(String memberString) {
                this.memberString = memberString;
            }

            public long getAddTime() {
                return addTime;
            }

            public void setAddTime(long addTime) {
                this.addTime = addTime;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getLastContent() {
                return lastContent;
            }

            public void setLastContent(String lastContent) {
                this.lastContent = lastContent;
            }

            public int getLastMsgUid() {
                return lastMsgUid;
            }

            public void setLastMsgUid(int lastMsgUid) {
                this.lastMsgUid = lastMsgUid;
            }

            public long getLastUpdateTime() {
                return lastUpdateTime;
            }

            public void setLastUpdateTime(long lastUpdateTime) {
                this.lastUpdateTime = lastUpdateTime;
            }

            public int getReject() {
                return reject;
            }

            public void setReject(int reject) {
                this.reject = reject;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public List<Integer> getMember() {
                return member;
            }

            public void setMember(List<Integer> member) {
                this.member = member;
            }

            @Override
            public int compareTo(@NonNull ResultBean another) {
                return (int) (another.getLastUpdateTime() / 1000 - this.getLastUpdateTime() / 1000);
            }

            public static class UserBean {
                /**
                 * avatar : http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg
                 * id : 3901312
                 * name : 运动爱好者
                 */

                private String avatar;
                private int id;
                private String name;

                public String getAvatar() {
                    return avatar;
                }

                public void setAvatar(String avatar) {
                    this.avatar = avatar;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }
            }
        }
    }
}
