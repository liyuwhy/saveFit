package com.fitmix.sdk.model.api.bean;

/**
 * 网络请求结果实体基类
 */
public class BaseBean {

    /**
     * 举例
     * code : 0
     * k : 4baebe3dafd14e86bb5716c9610de56e
     * st : 1463710710781
     */

    /**
     * 网络请求结果代码,0表示成功,其它表示错误
     */
    protected int code;
    /**
     * 服务器返回的token值,后续请求附加此值,用于认证
     */
    protected String k;
    /**
     * 请求时间
     */
    protected long st;
    /**
     * 网络请求结果错误信息
     */
    protected String msg;

    public void setCode(int code) {
        this.code = code;
    }

    public void setK(String k) {
        this.k = k;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public int getCode() {
        return code;
    }

    public String getK() {
        return k;
    }

    public long getSt() {
        return st;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
