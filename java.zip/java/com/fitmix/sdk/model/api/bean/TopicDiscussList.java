package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.TopicDiscuss;

import java.util.List;

/**
 * 获取话题或者回答的评论列表(/theme/answer/list.json?)接口返回的结果
 */
public class TopicDiscussList extends BaseBean {


    /**
     * filter : {"themeId":7}
     * hasNext : false
     * hasPre : false
     * index : 0
     * nextPage : 1
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1499421138531,"content":"讨论","id":31,"themeId":7,"uid":12,"upNum":1,"upUserIds":[8],"userName":"sjun"},{"addTime":1499422479330,"avatar":"http://yyssb.ifitmix.com/1002/9b1e1f92c3ad48fb82695295d00aa8e8.jpg","content":"哈哈哈","discussUName":"sjun","discussUid":12,"id":32,"themeId":7,"uid":15,"upNum":1,"upUserIds":[8],"userName":"打你家玻璃"},{"addTime":1499423104012,"avatar":"http://yyssb.ifitmix.com/1002/c0bfd00858714371a166e3be013903b8.jpg","content":"讨论","discussUName":"打你家玻璃","discussUid":15,"id":33,"themeId":7,"uid":5,"upNum":1,"upUserIds":[8],"userName":"fanny"},{"addTime":1499675774959,"avatar":"http://ww3.sinaimg.cn/crop.0.0.512.512.1024/67e1dea5jw8epjoqb3iztj20e80e83z5.jpg","content":"fhjfh","discussUName":"fanny","discussUid":5,"id":35,"themeId":7,"uid":17,"upNum":1,"upUserIds":[8],"userName":"高妮娜"}]
     * size : 20
     * total : 4
     * totalPages : 1
     */

    private PageEntity page;

    public PageEntity getPage() {
        return page;
    }

    public void setPage(PageEntity page) {
        this.page = page;
    }

    public static class PageEntity {
        /**
         * themeId : 7
         */
        private FilterEntity filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        /**
         * addTime : 1499421138531
         * content : 讨论
         * id : 31
         * themeId : 7
         * uid : 12
         * upNum : 1
         * upUserIds : [8]
         * userName : sjun
         */

        private List<TopicDiscuss> result;

        public FilterEntity getFilter() {
            return filter;
        }

        public void setFilter(FilterEntity filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<TopicDiscuss> getResult() {
            return result;
        }

        public void setResult(List<TopicDiscuss> result) {
            this.result = result;
        }

        public static class FilterEntity {
            private int themeId;

            public int getThemeId() {
                return themeId;
            }

            public void setThemeId(int themeId) {
                this.themeId = themeId;
            }
        }


    }
}
