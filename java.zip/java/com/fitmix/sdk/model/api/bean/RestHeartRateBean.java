package com.fitmix.sdk.model.api.bean;

/**
 * 获取全部静息心率记录接口(/rest-heart-rate/list.json),返回的结果实体
 */
public class RestHeartRateBean extends BaseBean {

    /**
     * detectTime : 1473070158273
     * heartRateVal : 46
     * id : 2
     * uid : 163468
     */

    private long detectTime;
    private int heartRateVal;
    private int id;
    private int uid;

    public long getDetectTime() {
        return detectTime;
    }

    public void setDetectTime(long detectTime) {
        this.detectTime = detectTime;
    }

    public int getHeartRateVal() {
        return heartRateVal;
    }

    public void setHeartRateVal(int heartRateVal) {
        this.heartRateVal = heartRateVal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
