package com.fitmix.sdk.model.api.bean;

/**
 * 获得语音包下载的链接地址url列表信息(/voice/get/file.json)接口返回的结果
 */

public class VoicePackageFileInfo extends BaseBean {

    /**
     * file : {"addTime":1507543483776,"des":"标准女生英文版","fileLink":"http://yyssb.ifitmix.com/2014/3f4d39b47b4e493d94a01a22a7fe04f8.zip","fileType":1,"id":134,"other":{"dirName":"femaleVoiceEn","size":"5.3","targetApp":"I-13、A-60","version":"4","voiceId":"1"},"status":0}
     */

    private FileBean file;

    public FileBean getFile() {
        return file;
    }

    public void setFile(FileBean file) {
        this.file = file;
    }

    public static class FileBean {
        /**
         * addTime : 1507543483776
         * des : 标准女生英文版
         * fileLink : http://yyssb.ifitmix.com/2014/3f4d39b47b4e493d94a01a22a7fe04f8.zip
         * fileType : 1
         * id : 134
         * other : {"dirName":"femaleVoiceEn","size":"5.3","targetApp":"I-13、A-60","version":"4","voiceId":"1"}
         * status : 0
         */

        private long addTime;
        private String des;
        private String fileLink;
        private int fileType;
        private int id;
        private OtherBean other;
        private int status;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getFileLink() {
            return fileLink;
        }

        public void setFileLink(String fileLink) {
            this.fileLink = fileLink;
        }

        public int getFileType() {
            return fileType;
        }

        public void setFileType(int fileType) {
            this.fileType = fileType;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public OtherBean getOther() {
            return other;
        }

        public void setOther(OtherBean other) {
            this.other = other;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public static class OtherBean {
            /**
             * dirName : femaleVoiceEn
             * size : 5.3
             * targetApp : I-13、A-60
             * version : 4
             * voiceId : 1
             */

            private String dirName;
            private String size;
            private String targetApp;
            private int version;
            private int voiceId;

            public String getDirName() {
                return dirName;
            }

            public void setDirName(String dirName) {
                this.dirName = dirName;
            }

            public String getSize() {
                return size;
            }

            public void setSize(String size) {
                this.size = size;
            }

            public String getTargetApp() {
                return targetApp;
            }

            public void setTargetApp(String targetApp) {
                this.targetApp = targetApp;
            }

            public int getVersion() {
                return version;
            }

            public void setVersion(int version) {
                this.version = version;
            }

            public int getVoiceId() {
                return voiceId;
            }

            public void setVoiceId(int voiceId) {
                this.voiceId = voiceId;
            }
        }
    }
}
