package com.fitmix.sdk.model.api.bean;


import com.fitmix.sdk.view.bean.ClubRank;

import java.util.List;

/**
 * 获取俱乐部排名列表的结果
 */
public class ClubRankList extends BaseBean {

    /**
     * addTime : 1464871611540
     * addTimeStr : 2016-06-02
     * calorie : 747
     * distance : 10050
     * id : 529583
     * runTime : 4311000
     * step : 9747
     * type : 3
     * uid : 97010
     * user : {"avatar":"http://yyssb.ifitmix.com/1002/2b384fcfcc264ac7bde27a0b0dcfe29f.jpg","id":97010,"name":"锋子"}
     */

    private List<ClubRank> userRanking;

    public List<ClubRank> getUserRanking() {
        return userRanking;
    }

    public void setUserRanking(List<ClubRank> userRanking) {
        this.userRanking = userRanking;
    }

}
