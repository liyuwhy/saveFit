package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取城市天气信息接口(surprise/get-weather.json)返回的结果
 */

public class Weather extends BaseBean {


    /**
     * surprise : {"update":{"utc":"2018-06-27 02:48","loc":"2018-06-27 10:48"},"alarm":[{"title":"山东省青岛市气象台发布大雾橙色预警","level":"橙色","type":"大雾","txt":"青岛市气象台2018年06月27日04时30分将大雾黄色预警信号升级为大雾橙色预警信号：目前，我市大部及沿海地区能见度已降至200米以下，局部能见度小于100米。预计今天上午，我市的大雾天气仍将持续，请注意防范。（预警信息来源：国家预警信息发布中心）","stat":"预警中"}],"basic":{"admin_area":"山东","lon":"120.39596558","tz":"+8.00","parent_city":"青岛","location":"市南","cnty":"中国","cid":"CN101120203","lat":"36.07089233"},"lifestyle":[{"type":"comf","brf":"较舒适","txt":"白天天气晴好，同时较大的空气湿度，会使您在午后略感闷热，但早晚仍很凉爽、舒适。"},{"type":"drsg","brf":"舒适","txt":"建议着长袖T恤、衬衫加单裤等服装。年老体弱者宜着针织长袖衬衫、马甲和长裤。"},{"type":"flu","brf":"少发","txt":"各项气象条件适宜，无明显降温过程，发生感冒机率较低。"},{"type":"sport","brf":"较不宜","txt":"有雾或霾天气，建议适当停止户外运动，选择在室内进行运动，以避免吸入过多雾中有害物质，损害健康。"},{"type":"trav","brf":"较不宜","txt":"空气质量差，不适宜旅游"},{"type":"uv","brf":"最弱","txt":"属弱紫外线辐射天气，无需特别防护。若长期在户外，建议涂擦SPF在8-12之间的防晒护肤品。"},{"type":"cw","brf":"不宜","txt":"不宜洗车，未来24小时内有雾，如果在此期间洗车，会弄脏您的爱车。"},{"type":"air","brf":"很差","txt":"气象条件不利于空气污染物稀释、扩散和清除，请尽量避免在室外长时间活动。"}],"airNowCity":{"pub_time":"2018-06-27 10:00","co":"0.83","so2":"7","o3":"82","no2":"20","aqi":"38","pm10":"37","pm25":"12","qlty":"优","main":"-"},"dailyForecast":[{"tmp_max":"27","cond_code_n":"101","hum":"86","uv_index":"2","pcpn":"0.0","mr":"18:28","sr":"04:43","tmp_min":"22","ms":"03:57","wind_dir":"南风","pop":"3","date":"2018-06-27","pres":"1002","vis":"16","wind_spd":"23","cond_code_d":"501","wind_sc":"3-4","ss":"19:20","wind_deg":"187","cond_txt_d":"雾","cond_txt_n":"多云"},{"tmp_max":"32","cond_code_n":"100","hum":"74","uv_index":"6","pcpn":"0.0","mr":"19:19","sr":"04:44","tmp_min":"21","ms":"04:41","wind_dir":"南风","pop":"0","date":"2018-06-28","pres":"998","vis":"12","wind_spd":"15","cond_code_d":"101","wind_sc":"3-4","ss":"19:20","wind_deg":"176","cond_txt_d":"多云","cond_txt_n":"晴"},{"tmp_max":"27","cond_code_n":"100","hum":"63","uv_index":"9","pcpn":"0.0","mr":"20:06","sr":"04:44","tmp_min":"21","ms":"05:29","wind_dir":"北风","pop":"0","date":"2018-06-29","pres":"1002","vis":"20","wind_spd":"23","cond_code_d":"100","wind_sc":"3-4","ss":"19:20","wind_deg":"6","cond_txt_d":"晴","cond_txt_n":"晴"}]}
     */

    private SurpriseBean surprise;

    public SurpriseBean getSurprise() {
        return surprise;
    }

    public void setSurprise(SurpriseBean surprise) {
        this.surprise = surprise;
    }

    public static class SurpriseBean {
        /**
         * update : {"utc":"2018-06-27 02:48","loc":"2018-06-27 10:48"}
         * alarm : [{"title":"山东省青岛市气象台发布大雾橙色预警","level":"橙色","type":"大雾","txt":"青岛市气象台2018年06月27日04时30分将大雾黄色预警信号升级为大雾橙色预警信号：目前，我市大部及沿海地区能见度已降至200米以下，局部能见度小于100米。预计今天上午，我市的大雾天气仍将持续，请注意防范。（预警信息来源：国家预警信息发布中心）","stat":"预警中"}]
         * basic : {"admin_area":"山东","lon":"120.39596558","tz":"+8.00","parent_city":"青岛","location":"市南","cnty":"中国","cid":"CN101120203","lat":"36.07089233"}
         * lifestyle : [{"type":"comf","brf":"较舒适","txt":"白天天气晴好，同时较大的空气湿度，会使您在午后略感闷热，但早晚仍很凉爽、舒适。"},{"type":"drsg","brf":"舒适","txt":"建议着长袖T恤、衬衫加单裤等服装。年老体弱者宜着针织长袖衬衫、马甲和长裤。"},{"type":"flu","brf":"少发","txt":"各项气象条件适宜，无明显降温过程，发生感冒机率较低。"},{"type":"sport","brf":"较不宜","txt":"有雾或霾天气，建议适当停止户外运动，选择在室内进行运动，以避免吸入过多雾中有害物质，损害健康。"},{"type":"trav","brf":"较不宜","txt":"空气质量差，不适宜旅游"},{"type":"uv","brf":"最弱","txt":"属弱紫外线辐射天气，无需特别防护。若长期在户外，建议涂擦SPF在8-12之间的防晒护肤品。"},{"type":"cw","brf":"不宜","txt":"不宜洗车，未来24小时内有雾，如果在此期间洗车，会弄脏您的爱车。"},{"type":"air","brf":"很差","txt":"气象条件不利于空气污染物稀释、扩散和清除，请尽量避免在室外长时间活动。"}]
         * airNowCity : {"pub_time":"2018-06-27 10:00","co":"0.83","so2":"7","o3":"82","no2":"20","aqi":"38","pm10":"37","pm25":"12","qlty":"优","main":"-"}
         * dailyForecast : [{"tmp_max":"27","cond_code_n":"101","hum":"86","uv_index":"2","pcpn":"0.0","mr":"18:28","sr":"04:43","tmp_min":"22","ms":"03:57","wind_dir":"南风","pop":"3","date":"2018-06-27","pres":"1002","vis":"16","wind_spd":"23","cond_code_d":"501","wind_sc":"3-4","ss":"19:20","wind_deg":"187","cond_txt_d":"雾","cond_txt_n":"多云"},{"tmp_max":"32","cond_code_n":"100","hum":"74","uv_index":"6","pcpn":"0.0","mr":"19:19","sr":"04:44","tmp_min":"21","ms":"04:41","wind_dir":"南风","pop":"0","date":"2018-06-28","pres":"998","vis":"12","wind_spd":"15","cond_code_d":"101","wind_sc":"3-4","ss":"19:20","wind_deg":"176","cond_txt_d":"多云","cond_txt_n":"晴"},{"tmp_max":"27","cond_code_n":"100","hum":"63","uv_index":"9","pcpn":"0.0","mr":"20:06","sr":"04:44","tmp_min":"21","ms":"05:29","wind_dir":"北风","pop":"0","date":"2018-06-29","pres":"1002","vis":"20","wind_spd":"23","cond_code_d":"100","wind_sc":"3-4","ss":"19:20","wind_deg":"6","cond_txt_d":"晴","cond_txt_n":"晴"}]
         */

        private UpdateBean update;
        private BasicBean basic;
        private AirNowCityBean airNowCity;
        private List<AlarmBean> alarm;
        private List<LifestyleBean> lifestyle;
        private List<DailyForecastBean> dailyForecast;

        public UpdateBean getUpdate() {
            return update;
        }

        public void setUpdate(UpdateBean update) {
            this.update = update;
        }

        public BasicBean getBasic() {
            return basic;
        }

        public void setBasic(BasicBean basic) {
            this.basic = basic;
        }

        public AirNowCityBean getAirNowCity() {
            return airNowCity;
        }

        public void setAirNowCity(AirNowCityBean airNowCity) {
            this.airNowCity = airNowCity;
        }

        public List<AlarmBean> getAlarm() {
            return alarm;
        }

        public void setAlarm(List<AlarmBean> alarm) {
            this.alarm = alarm;
        }

        public List<LifestyleBean> getLifestyle() {
            return lifestyle;
        }

        public void setLifestyle(List<LifestyleBean> lifestyle) {
            this.lifestyle = lifestyle;
        }

        public List<DailyForecastBean> getDailyForecast() {
            return dailyForecast;
        }

        public void setDailyForecast(List<DailyForecastBean> dailyForecast) {
            this.dailyForecast = dailyForecast;
        }

        public static class UpdateBean {
            /**
             * utc : 2018-06-27 02:48
             * loc : 2018-06-27 10:48
             */

            private String utc;
            private String loc;

            public String getUtc() {
                return utc;
            }

            public void setUtc(String utc) {
                this.utc = utc;
            }

            public String getLoc() {
                return loc;
            }

            public void setLoc(String loc) {
                this.loc = loc;
            }
        }

        public static class BasicBean {
            /**
             * admin_area : 山东
             * lon : 120.39596558
             * tz : +8.00
             * parent_city : 青岛
             * location : 市南
             * cnty : 中国
             * cid : CN101120203
             * lat : 36.07089233
             */

            private String admin_area;
            private String lon;
            private String tz;
            private String parent_city;
            private String location;
            private String cnty;
            private String cid;
            private String lat;

            public String getAdmin_area() {
                return admin_area;
            }

            public void setAdmin_area(String admin_area) {
                this.admin_area = admin_area;
            }

            public String getLon() {
                return lon;
            }

            public void setLon(String lon) {
                this.lon = lon;
            }

            public String getTz() {
                return tz;
            }

            public void setTz(String tz) {
                this.tz = tz;
            }

            public String getParent_city() {
                return parent_city;
            }

            public void setParent_city(String parent_city) {
                this.parent_city = parent_city;
            }

            public String getLocation() {
                return location;
            }

            public void setLocation(String location) {
                this.location = location;
            }

            public String getCnty() {
                return cnty;
            }

            public void setCnty(String cnty) {
                this.cnty = cnty;
            }

            public String getCid() {
                return cid;
            }

            public void setCid(String cid) {
                this.cid = cid;
            }

            public String getLat() {
                return lat;
            }

            public void setLat(String lat) {
                this.lat = lat;
            }
        }

        public static class AirNowCityBean {
            /**
             * pub_time : 2018-06-27 10:00
             * co : 0.83
             * so2 : 7
             * o3 : 82
             * no2 : 20
             * aqi : 38
             * pm10 : 37
             * pm25 : 12
             * qlty : 优
             * main : -
             */

            private String pub_time;
            private String co;
            private String so2;
            private String o3;
            private String no2;
            private String aqi;
            private String pm10;
            private String pm25;
            private String qlty;
            private String main;

            public String getPub_time() {
                return pub_time;
            }

            public void setPub_time(String pub_time) {
                this.pub_time = pub_time;
            }

            public String getCo() {
                return co;
            }

            public void setCo(String co) {
                this.co = co;
            }

            public String getSo2() {
                return so2;
            }

            public void setSo2(String so2) {
                this.so2 = so2;
            }

            public String getO3() {
                return o3;
            }

            public void setO3(String o3) {
                this.o3 = o3;
            }

            public String getNo2() {
                return no2;
            }

            public void setNo2(String no2) {
                this.no2 = no2;
            }

            public String getAqi() {
                return aqi;
            }

            public void setAqi(String aqi) {
                this.aqi = aqi;
            }

            public String getPm10() {
                return pm10;
            }

            public void setPm10(String pm10) {
                this.pm10 = pm10;
            }

            public String getPm25() {
                return pm25;
            }

            public void setPm25(String pm25) {
                this.pm25 = pm25;
            }

            public String getQlty() {
                return qlty;
            }

            public void setQlty(String qlty) {
                this.qlty = qlty;
            }

            public String getMain() {
                return main;
            }

            public void setMain(String main) {
                this.main = main;
            }
        }

        public static class AlarmBean {
            /**
             * title : 山东省青岛市气象台发布大雾橙色预警
             * level : 橙色
             * type : 大雾
             * txt : 青岛市气象台2018年06月27日04时30分将大雾黄色预警信号升级为大雾橙色预警信号：目前，我市大部及沿海地区能见度已降至200米以下，局部能见度小于100米。预计今天上午，我市的大雾天气仍将持续，请注意防范。（预警信息来源：国家预警信息发布中心）
             * stat : 预警中
             */

            private String title;
            private String level;
            private String type;
            private String txt;
            private String stat;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLevel() {
                return level;
            }

            public void setLevel(String level) {
                this.level = level;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTxt() {
                return txt;
            }

            public void setTxt(String txt) {
                this.txt = txt;
            }

            public String getStat() {
                return stat;
            }

            public void setStat(String stat) {
                this.stat = stat;
            }
        }

        public static class LifestyleBean {
            /**
             * type : comf
             * brf : 较舒适
             * txt : 白天天气晴好，同时较大的空气湿度，会使您在午后略感闷热，但早晚仍很凉爽、舒适。
             */

            private String type;
            private String brf;
            private String txt;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getBrf() {
                return brf;
            }

            public void setBrf(String brf) {
                this.brf = brf;
            }

            public String getTxt() {
                return txt;
            }

            public void setTxt(String txt) {
                this.txt = txt;
            }
        }

        public static class DailyForecastBean {
            /**
             * tmp_max : 27
             * cond_code_n : 101
             * hum : 86
             * uv_index : 2
             * pcpn : 0.0
             * mr : 18:28
             * sr : 04:43
             * tmp_min : 22
             * ms : 03:57
             * wind_dir : 南风
             * pop : 3
             * date : 2018-06-27
             * pres : 1002
             * vis : 16
             * wind_spd : 23
             * cond_code_d : 501
             * wind_sc : 3-4
             * ss : 19:20
             * wind_deg : 187
             * cond_txt_d : 雾
             * cond_txt_n : 多云
             */

            private String tmp_max;
            private String cond_code_n;
            private String hum;
            private String uv_index;
            private String pcpn;
            private String mr;
            private String sr;
            private String tmp_min;
            private String ms;
            private String wind_dir;
            private String pop;
            private String date;
            private String pres;
            private String vis;
            private String wind_spd;
            private String cond_code_d;
            private String wind_sc;
            private String ss;
            private String wind_deg;
            private String cond_txt_d;
            private String cond_txt_n;

            public String getTmp_max() {
                return tmp_max;
            }

            public void setTmp_max(String tmp_max) {
                this.tmp_max = tmp_max;
            }

            public String getCond_code_n() {
                return cond_code_n;
            }

            public void setCond_code_n(String cond_code_n) {
                this.cond_code_n = cond_code_n;
            }

            public String getHum() {
                return hum;
            }

            public void setHum(String hum) {
                this.hum = hum;
            }

            public String getUv_index() {
                return uv_index;
            }

            public void setUv_index(String uv_index) {
                this.uv_index = uv_index;
            }

            public String getPcpn() {
                return pcpn;
            }

            public void setPcpn(String pcpn) {
                this.pcpn = pcpn;
            }

            public String getMr() {
                return mr;
            }

            public void setMr(String mr) {
                this.mr = mr;
            }

            public String getSr() {
                return sr;
            }

            public void setSr(String sr) {
                this.sr = sr;
            }

            public String getTmp_min() {
                return tmp_min;
            }

            public void setTmp_min(String tmp_min) {
                this.tmp_min = tmp_min;
            }

            public String getMs() {
                return ms;
            }

            public void setMs(String ms) {
                this.ms = ms;
            }

            public String getWind_dir() {
                return wind_dir;
            }

            public void setWind_dir(String wind_dir) {
                this.wind_dir = wind_dir;
            }

            public String getPop() {
                return pop;
            }

            public void setPop(String pop) {
                this.pop = pop;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getPres() {
                return pres;
            }

            public void setPres(String pres) {
                this.pres = pres;
            }

            public String getVis() {
                return vis;
            }

            public void setVis(String vis) {
                this.vis = vis;
            }

            public String getWind_spd() {
                return wind_spd;
            }

            public void setWind_spd(String wind_spd) {
                this.wind_spd = wind_spd;
            }

            public String getCond_code_d() {
                return cond_code_d;
            }

            public void setCond_code_d(String cond_code_d) {
                this.cond_code_d = cond_code_d;
            }

            public String getWind_sc() {
                return wind_sc;
            }

            public void setWind_sc(String wind_sc) {
                this.wind_sc = wind_sc;
            }

            public String getSs() {
                return ss;
            }

            public void setSs(String ss) {
                this.ss = ss;
            }

            public String getWind_deg() {
                return wind_deg;
            }

            public void setWind_deg(String wind_deg) {
                this.wind_deg = wind_deg;
            }

            public String getCond_txt_d() {
                return cond_txt_d;
            }

            public void setCond_txt_d(String cond_txt_d) {
                this.cond_txt_d = cond_txt_d;
            }

            public String getCond_txt_n() {
                return cond_txt_n;
            }

            public void setCond_txt_n(String cond_txt_n) {
                this.cond_txt_n = cond_txt_n;
            }
        }
    }
}
