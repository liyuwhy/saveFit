package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Music;


public class RecommendMusic extends BaseBean {

    private Music currentMix;

    public Music getCurrentMix() {
        return currentMix;
    }

    public void setCurrentMix(Music currentMix) {
        this.currentMix = currentMix;
    }

}
