package com.fitmix.sdk.model.api.bean;

/**
 * 浏览个人主页接口(/user/browse/homepage.json)返回的结果
 */

public class PersonalHomePageBean extends BaseBean {


    /**
     * targetUser : {"avatar":"http://yyssb.ifitmix.com/1002/21a9814cd1bc487e9a49c894503e77e3.jpg","gender":1,"id":27,"name":"Barnaby","signature":"Thug life","taoBaoIp":{"city":"深圳市","region":"广东省"}}
     * month : {"id":22485222,"runDay":5,"runNum":5,"runTime":10067566,"statTime":"2018-01-01","sumCalorie":1152,"sumConsumeFat":56.348052978515625,"sumDistance":20930,"sumStep":20964,"type":3,"uid":27}
     * group : {"id":25,"lastContent":"hi","reject":0}
     * all : {"id":20192095,"runDay":181,"runNum":553,"runTime":877650214,"statTime":"--","sumCalorie":274768943,"sumConsumeFat":1711.1947729853268,"sumDistance":1930896,"sumStep":1103801,"type":1,"uid":27}
     */

    private TargetUserBean targetUser;
    private MonthBean month;
    private GroupBean group;
    private AllBean all;

    public TargetUserBean getTargetUser() {
        return targetUser;
    }

    public void setTargetUser(TargetUserBean targetUser) {
        this.targetUser = targetUser;
    }

    public MonthBean getMonth() {
        return month;
    }

    public void setMonth(MonthBean month) {
        this.month = month;
    }

    public GroupBean getGroup() {
        return group;
    }

    public void setGroup(GroupBean group) {
        this.group = group;
    }

    public AllBean getAll() {
        return all;
    }

    public void setAll(AllBean all) {
        this.all = all;
    }

    public static class TargetUserBean {
        /**
         * avatar : http://yyssb.ifitmix.com/1002/21a9814cd1bc487e9a49c894503e77e3.jpg
         * gender : 1
         * id : 27
         * name : Barnaby
         * signature : Thug life
         * taoBaoIp : {"city":"深圳市","region":"广东省"}
         */

        private String avatar;
        private int gender;
        private int id;
        private String name;
        private String signature;
        private TaoBaoIpBean taoBaoIp;

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSignature() {
            return signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public TaoBaoIpBean getTaoBaoIp() {
            return taoBaoIp;
        }

        public void setTaoBaoIp(TaoBaoIpBean taoBaoIp) {
            this.taoBaoIp = taoBaoIp;
        }

        public static class TaoBaoIpBean {
            /**
             * city : 深圳市
             * region : 广东省
             */

            private String city;
            private String region;

            public String getCity() {
                return city;
            }

            public void setCity(String city) {
                this.city = city;
            }

            public String getRegion() {
                return region;
            }

            public void setRegion(String region) {
                this.region = region;
            }
        }
    }

    public static class MonthBean {
        /**
         * id : 22485222
         * runDay : 5
         * runNum : 5
         * runTime : 10067566
         * statTime : 2018-01-01
         * sumCalorie : 1152
         * sumConsumeFat : 56.348052978515625
         * sumDistance : 20930
         * sumStep : 20964
         * type : 3
         * uid : 27
         */

        private int id;
        private int runDay;
        private int runNum;
        private long runTime;
        private String statTime;
        private int sumCalorie;
        private double sumConsumeFat;
        private int sumDistance;
        private int sumStep;
        private int type;
        private int uid;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getRunDay() {
            return runDay;
        }

        public void setRunDay(int runDay) {
            this.runDay = runDay;
        }

        public int getRunNum() {
            return runNum;
        }

        public void setRunNum(int runNum) {
            this.runNum = runNum;
        }

        public long getRunTime() {
            return runTime;
        }

        public void setRunTime(long runTime) {
            this.runTime = runTime;
        }

        public String getStatTime() {
            return statTime;
        }

        public void setStatTime(String statTime) {
            this.statTime = statTime;
        }

        public int getSumCalorie() {
            return sumCalorie;
        }

        public void setSumCalorie(int sumCalorie) {
            this.sumCalorie = sumCalorie;
        }

        public double getSumConsumeFat() {
            return sumConsumeFat;
        }

        public void setSumConsumeFat(double sumConsumeFat) {
            this.sumConsumeFat = sumConsumeFat;
        }

        public int getSumDistance() {
            return sumDistance;
        }

        public void setSumDistance(int sumDistance) {
            this.sumDistance = sumDistance;
        }

        public int getSumStep() {
            return sumStep;
        }

        public void setSumStep(int sumStep) {
            this.sumStep = sumStep;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }

    public static class GroupBean {
        /**
         * id : 25
         * lastContent : hi
         * reject : 0
         */

        private int id;
        private String lastContent;
        private int reject;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getLastContent() {
            return lastContent;
        }

        public void setLastContent(String lastContent) {
            this.lastContent = lastContent;
        }

        public int getReject() {
            return reject;
        }

        public void setReject(int reject) {
            this.reject = reject;
        }
    }

    public static class AllBean {
        /**
         * id : 20192095
         * runDay : 181
         * runNum : 553
         * runTime : 877650214
         * statTime : --
         * sumCalorie : 274768943
         * sumConsumeFat : 1711.1947729853268
         * sumDistance : 1930896
         * sumStep : 1103801
         * type : 1
         * uid : 27
         */

        private int id;
        private int runDay;
        private int runNum;
        private long runTime;
        private String statTime;
        private int sumCalorie;
        private double sumConsumeFat;
        private int sumDistance;
        private int sumStep;
        private int type;
        private int uid;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getRunDay() {
            return runDay;
        }

        public void setRunDay(int runDay) {
            this.runDay = runDay;
        }

        public int getRunNum() {
            return runNum;
        }

        public void setRunNum(int runNum) {
            this.runNum = runNum;
        }

        public long getRunTime() {
            return runTime;
        }

        public void setRunTime(long runTime) {
            this.runTime = runTime;
        }

        public String getStatTime() {
            return statTime;
        }

        public void setStatTime(String statTime) {
            this.statTime = statTime;
        }

        public int getSumCalorie() {
            return sumCalorie;
        }

        public void setSumCalorie(int sumCalorie) {
            this.sumCalorie = sumCalorie;
        }

        public double getSumConsumeFat() {
            return sumConsumeFat;
        }

        public void setSumConsumeFat(double sumConsumeFat) {
            this.sumConsumeFat = sumConsumeFat;
        }

        public int getSumDistance() {
            return sumDistance;
        }

        public void setSumDistance(int sumDistance) {
            this.sumDistance = sumDistance;
        }

        public int getSumStep() {
            return sumStep;
        }

        public void setSumStep(int sumStep) {
            this.sumStep = sumStep;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }
}
