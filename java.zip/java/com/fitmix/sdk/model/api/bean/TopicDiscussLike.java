package com.fitmix.sdk.model.api.bean;

/**
 * 话题评论点赞或取消点赞(/discuss/opinion.json)接口返回的结果
 */

public class TopicDiscussLike extends BaseBean {

    /**
     * upNum : 1
     */

    private int upNum;//当前总点赞数

    public int getUpNum() {
        return upNum;
    }

    public void setUpNum(int upNum) {
        this.upNum = upNum;
    }
}
