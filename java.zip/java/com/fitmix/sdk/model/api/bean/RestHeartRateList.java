package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取全部静息心率记录接口(/rest-heart-rate/list.json),返回的结果列表
 */
public class RestHeartRateList extends BaseBean {

    /**
     * detectTime : 1473132430438
     * heartRateVal : 80
     * id : 3
     * uid : 163468
     */

    private List<RestHeartRateBean> list;

    public List<RestHeartRateBean> getList() {
        return list;
    }

    public void setList(List<RestHeartRateBean> list) {
        this.list = list;
    }
}
