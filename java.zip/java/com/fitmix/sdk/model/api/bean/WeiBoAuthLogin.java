package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 新浪微博授权登录(login-wb.json)返回结果
 */
public class WeiBoAuthLogin extends BaseBean {

    /**
     * age : 32
     * avatar :
     * calorie : 0
     * distance : 0
     * email : 15907016098@139.com
     * gender : 1
     * height : 175
     * id : 69161
     * loginType : 4
     * name : 15907016098
     * openid :
     * registerType : 1
     * runTime : 0
     * state : 1
     * step : 0
     * type : 1
     * wbOpenid :
     * weight : 88
     */
    private UserEntity user;
    /**
     * collectIds : [489]
     * user : {"age":32,"avatar":"","calorie":0,"distance":0,"email":"15907016098@139.com","gender":1,"height":175,"id":69161,"loginType":4,"name":"15907016098","openid":"","registerType":1,"runTime":0,"state":1,"step":0,"type":1,"wbOpenid":"","weight":88}
     */

    private List<Integer> collectIds;

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public void setCollectIds(List<Integer> collectIds) {
        this.collectIds = collectIds;
    }

    public UserEntity getUser() {
        return user;
    }

    public List<Integer> getCollectIds() {
        return collectIds;
    }

    public static class UserEntity {
        private int age;
        private String avatar;
        private int calorie;
        private int distance;
        private String email;
        private int gender;
        private int height;
        private int id;
        private int loginType;
        private String name;
        private String openid;
        private int registerType;
        private int runTime;
        private int state;
        private int step;
        private int type;
        private String wbOpenid;
        private int weight;

        public void setAge(int age) {
            this.age = age;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setLoginType(int loginType) {
            this.loginType = loginType;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setOpenid(String openid) {
            this.openid = openid;
        }

        public void setRegisterType(int registerType) {
            this.registerType = registerType;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setStep(int step) {
            this.step = step;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setWbOpenid(String wbOpenid) {
            this.wbOpenid = wbOpenid;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public int getAge() {
            return age;
        }

        public String getAvatar() {
            return avatar;
        }

        public int getCalorie() {
            return calorie;
        }

        public int getDistance() {
            return distance;
        }

        public String getEmail() {
            return email;
        }

        public int getGender() {
            return gender;
        }

        public int getHeight() {
            return height;
        }

        public int getId() {
            return id;
        }

        public int getLoginType() {
            return loginType;
        }

        public String getName() {
            return name;
        }

        public String getOpenid() {
            return openid;
        }

        public int getRegisterType() {
            return registerType;
        }

        public int getRunTime() {
            return runTime;
        }

        public int getState() {
            return state;
        }

        public int getStep() {
            return step;
        }

        public int getType() {
            return type;
        }

        public String getWbOpenid() {
            return wbOpenid;
        }

        public int getWeight() {
            return weight;
        }
    }
}
