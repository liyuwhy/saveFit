package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.Album;

import java.util.List;

/**
 * 获取专辑列表的结果
 */
public class AlbumList extends BaseBean {

    private List<Album> list;

    public List<Album> getList() {
        return list;
    }

    public void setList(List<Album> list) {
        this.list = list;
    }
}
