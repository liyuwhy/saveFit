package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 查询私信列表(/get/private/msg/info.json)接口返回的结果
 */

public class ChatActivityMessageBeanList {

    /**
     * st : 1511429236679
     * page : {"filter":{"groupId":"43","selectChannel":"19"},"hasNext":false,"hasPre":false,"index":0,"nextPage":1,"offset":0,"pageNo":1,"prePage":1,"result":[{"addTime":1511429218245,"fromUser":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"},"id":2829,"msgBody":{"fromUid":"3901312","groupId":"43","content":"一个 v感觉"},"selectChannel":"19","status":0},{"addTime":1511429209894,"fromUser":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"},"id":2828,"msgBody":{"fromUid":"3901312","groupId":"43","content":"反季节ｖ"},"selectChannel":"19","status":0}],"size":2,"total":-1,"totalPages":-1}
     * code : 0
     * k : e5ee122330ec40e8848423bcd60bda16
     */

    private long st;
    private PageBean page;
    private int code;
    private String k;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public static class PageBean {
        /**
         * filter : {"groupId":"43","selectChannel":"19"}
         * hasNext : false
         * hasPre : false
         * index : 0
         * nextPage : 1
         * offset : 0
         * pageNo : 1
         * prePage : 1
         * result : [{"addTime":1511429218245,"fromUser":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"},"id":2829,"msgBody":{"fromUid":"3901312","groupId":"43","content":"一个 v感觉"},"selectChannel":"19","status":0},{"addTime":1511429209894,"fromUser":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"},"id":2828,"msgBody":{"fromUid":"3901312","groupId":"43","content":"反季节ｖ"},"selectChannel":"19","status":0}]
         * size : 2
         * total : -1
         * totalPages : -1
         */

        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int offset;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        private List<ResultBean> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getOffset() {
            return offset;
        }

        public void setOffset(int offset) {
            this.offset = offset;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<ResultBean> getResult() {
            return result;
        }

        public void setResult(List<ResultBean> result) {
            this.result = result;
        }

        public static class FilterBean {
            /**
             * groupId : 43
             * selectChannel : 19
             */

            private String groupId;
            private String selectChannel;

            public String getGroupId() {
                return groupId;
            }

            public void setGroupId(String groupId) {
                this.groupId = groupId;
            }

            public String getSelectChannel() {
                return selectChannel;
            }

            public void setSelectChannel(String selectChannel) {
                this.selectChannel = selectChannel;
            }
        }

        public static class ResultBean {
            /**
             * addTime : 1511429218245
             * fromUser : {"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"}
             * id : 2829
             * msgBody : {"fromUid":"3901312","groupId":"43","content":"一个 v感觉"}
             * selectChannel : 19
             * status : 0
             * reject:0   TODO 自己私自添加用于区分是否屏蔽的消息  0：未屏蔽消息  1：屏蔽消息
             */

            private long addTime;
            private FromUserBean fromUser;
            private int id;
            private MsgBodyBean msgBody;
            private String selectChannel;
            private int status;
            private int reject;

            public int getReject() {
                return reject;
            }

            public void setReject(int reject) {
                this.reject = reject;
            }

            public long getAddTime() {
                return addTime;
            }

            public void setAddTime(long addTime) {
                this.addTime = addTime;
            }

            public FromUserBean getFromUser() {
                return fromUser;
            }

            public void setFromUser(FromUserBean fromUser) {
                this.fromUser = fromUser;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public MsgBodyBean getMsgBody() {
                return msgBody;
            }

            public void setMsgBody(MsgBodyBean msgBody) {
                this.msgBody = msgBody;
            }

            public String getSelectChannel() {
                return selectChannel;
            }

            public void setSelectChannel(String selectChannel) {
                this.selectChannel = selectChannel;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public static class FromUserBean {
                /**
                 * avatar : http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg
                 * id : 3901312
                 * name : 运动爱好者
                 */

                private String avatar;
                private int id;
                private String name;

                public String getAvatar() {
                    return avatar;
                }

                public void setAvatar(String avatar) {
                    this.avatar = avatar;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }
            }

            public static class MsgBodyBean {
                /**
                 * fromUid : 3901312
                 * groupId : 43
                 * content : 一个 v感觉
                 */

                private String fromUid;
                private String groupId;
                private String content;

                public String getFromUid() {
                    return fromUid;
                }

                public void setFromUid(String fromUid) {
                    this.fromUid = fromUid;
                }

                public String getGroupId() {
                    return groupId;
                }

                public void setGroupId(String groupId) {
                    this.groupId = groupId;
                }

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }
            }
        }
    }
}
