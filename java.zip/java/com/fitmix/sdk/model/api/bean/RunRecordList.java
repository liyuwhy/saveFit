package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.watch.bean.WatchSportLog;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 从后台服务器获取用户历史跑步记录(history-run.json)返回的结果
 */
public class RunRecordList extends BaseBean {

    /**
     * lastAddTime : 1458113452325
     * new : [{"addTime":1450354361222,
     * "bpm":165,"bpmMatch":100,"calorie":604,
     * "detail":"http://yyssb.ifitmix.com/1003/6b79f11281d840a097a3f26130fb0790.json",
     * "distance":10090,
     * "endLat":0,"endLng":0,
     * "endTime":1450354315000,
     * "id":40874,"locationType":1,"mark":85,"model":1,"runTime":3352000,
     * "startLat":0,"startLng":0,"startTime":1450350946000,"state":1,"step":9241,
     * "type":0,"uid":27,
     * "updateTime":1450354361222,
     * "userBpmMatch":100}]
     */

    /**
     * 最近一次拉取记录的时间
     */
    private long lastAddTime;
    /**
     * addTime : 1450354361222
     * bpm : 165
     * bpmMatch : 100
     * calorie : 604
     * detail : http://yyssb.ifitmix.com/1003/6b79f11281d840a097a3f26130fb0790.json
     * distance : 10090
     * endLat : 0
     * endLng : 0
     * endTime : 1450354315000
     * id : 40874
     * locationType : 1
     * mark : 85
     * model : 1
     * runTime : 3352000
     * startLat : 0
     * startLng : 0
     * startTime : 1450350946000
     * state : 1
     * step : 9241
     * type : 0
     * uid : 27
     * updateTime : 1450354361222
     * userBpmMatch : 100
     */

    @SerializedName("new")
    private List<RunRecord> runRecords;

    public void setLastAddTime(long lastAddTime) {
        this.lastAddTime = lastAddTime;
    }

    public void setRunRecords(List<RunRecord> runRecords) {
        this.runRecords = runRecords;
    }

    /**
     * 获取最近一次拉取跑步记录的时间
     */
    public long getLastAddTime() {
        return lastAddTime;
    }

    /**
     * 获取跑步记录列表
     */
    public List<RunRecord> getRunRecords() {
        return runRecords;
    }

    /**
     * 单个跑步记录
     */
    public static class RunRecord {
        private long addTime;//服务器添加记录时间
        private int bpm;//每分钟步数,步频
        private int bpmMatch;
        private long calorie;//运动消耗卡路里,单位为大卡
        private String detail;//轨迹文件下载url
        private long distance;//跑步距离,单位为米
        private double endLat;//结束点纬度
        private double endLng;//结束点经度
        private long endTime;//运动结束时间
        private int id;//跑步编号
        private int locationType;//定位类型,1:GPS定位,2:LBS定位
        private float mark;//超越了多少用户
        private int model;//运动环境,1:室外,2:室内
        private long runTime;//运动时长,单位为毫秒
        private double startLat;//起始点纬度
        private double startLng;//起始点经度
        private long startTime;//开始运动时间
        private int state;//服务器返回的结果是否有效,1表示有效.客户端可以不管
        private int step;//运动步数
        private String stepDetail;//计步文件下载url
        private int type;//运动类型,0、1:表示跑步,2:跳绳,3:手表
        private int uid;//用户uid
        private long updateTime;//服务器更新记录时间
        private int userBpmMatch;
        private UserHeartRate heartRate;//心率数据，由UserHeartRate类转为的json字符串
        private double consumeFat;//脂肪燃烧数，克
        private double elevation;//累积爬升

        private WatchSportLog watch;//手表运动记录
        private String watchZipFile;//手表运动记录对应的文件压缩包

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public void setBpm(int bpm) {
            this.bpm = bpm;
        }

        public void setBpmMatch(int bpmMatch) {
            this.bpmMatch = bpmMatch;
        }

        public void setCalorie(long calorie) {
            this.calorie = calorie;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public void setDistance(long distance) {
            this.distance = distance;
        }

        public void setEndLat(double endLat) {
            this.endLat = endLat;
        }

        public void setEndLng(double endLng) {
            this.endLng = endLng;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setLocationType(int locationType) {
            this.locationType = locationType;
        }

        public void setMark(int mark) {
            this.mark = mark;
        }

        public void setModel(int model) {
            this.model = model;
        }

        public void setRunTime(long runTime) {
            this.runTime = runTime;
        }

        public void setStartLat(double startLat) {
            this.startLat = startLat;
        }

        public void setStartLng(double startLng) {
            this.startLng = startLng;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setStep(int step) {
            this.step = step;
        }

        public void setStepDetail(String stepDetail) {
            this.stepDetail = stepDetail;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }

        public void setUserBpmMatch(int userBpmMatch) {
            this.userBpmMatch = userBpmMatch;
        }

        public long getAddTime() {
            return addTime;
        }

        public int getBpm() {
            return bpm;
        }

        public int getBpmMatch() {
            return bpmMatch;
        }

        public long getCalorie() {
            return calorie;
        }

        public String getDetail() {
            return detail;
        }

        public long getDistance() {
            return distance;
        }

        public double getEndLat() {
            return endLat;
        }

        public double getEndLng() {
            return endLng;
        }

        public long getEndTime() {
            return endTime;
        }

        public int getId() {
            return id;
        }

        public int getLocationType() {
            return locationType;
        }

        public float getMark() {
            return mark;
        }

        public int getModel() {
            return model;
        }

        public long getRunTime() {
            return runTime;
        }

        public double getStartLat() {
            return startLat;
        }

        public double getStartLng() {
            return startLng;
        }

        public long getStartTime() {
            return startTime;
        }

        public int getState() {
            return state;
        }

        public int getStep() {
            return step;
        }

        public String getStepDetail() {
            return stepDetail;
        }

        public int getType() {
            return type;
        }

        public int getUid() {
            return uid;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public int getUserBpmMatch() {
            return userBpmMatch;
        }

        public UserHeartRate getHeartRate() {
            return heartRate;
        }

        public void setHeartRateData(UserHeartRate heartRate) {
            this.heartRate = heartRate;
        }

        public double getConsumeFat() {
            return consumeFat;
        }

        public void setConsumeFat(double consumeFat) {
            this.consumeFat = consumeFat;
        }

        public double getElevation() {
            return elevation;
        }

        public void setElevation(double elevation) {
            this.elevation = elevation;
        }

        public WatchSportLog getWatch() {
            return watch;
        }

        public void setWatch(WatchSportLog watch) {
            this.watch = watch;
        }

        public String getWatchZipFile() {
            return watchZipFile;
        }

        public void setWatchZipFile(String watchZipFile) {
            this.watchZipFile = watchZipFile;
        }
    }

}
