package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.widget.trainingplan.StagesBean;

public class TodayTrain extends BaseBean {

    /**
     * contentDescription : 与跑步一样，休息也是训练中的重要部分。它可让您的身体恢复，使您在下一次跑步中变得更强。休息能够提高当前训练的效果。
     * date : 1
     * dateLong : 1479139200000
     * dateTime : 2016-11-15
     * distance : 0
     * stageContent : 休息
     * stageName : 预备
     * stageType : 0
     * state : 0
     */

    private StagesBean stages;

    public StagesBean getStages() {
        return stages;
    }

    public void setStages(StagesBean stages) {
        this.stages = stages;
    }
}
