package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * QQ授权登录(login-qq.json)返回的结果
 */
public class QqAuthLogin extends BaseBean {


    /**
     * age : 0
     * avatar : http://q.qlogo.cn/qqapp/1104452331/A4A136FB7A4652F97BA3ABB23F3B7249/100
     * calorie : 0
     * distance : 0
     * email :
     * gender : 1
     * height : 0
     * id : 372489
     * loginType : 2
     * mobile :
     * name : so easy
     * openid : A4A136FB7A4652F97BA3ABB23F3B7249
     * qqName : so easy
     * qqOpenid : A4A136FB7A4652F97BA3ABB23F3B7249
     * registerType : 2
     * runTime : 0
     * state : 1
     * step : 0
     * type : 1
     * wbName :
     * wbOpenid :
     * weight : 0
     * wxName :
     * wxOpenid :
     */

    private UserEntity user;
    /**
     * collectIds : []
     * user : {"age":0,"avatar":"http://q.qlogo.cn/qqapp/1104452331/A4A136FB7A4652F97BA3ABB23F3B7249/100","calorie":0,"distance":0,"email":"","gender":1,"height":0,"id":372489,"loginType":2,"mobile":"","name":"so easy","openid":"A4A136FB7A4652F97BA3ABB23F3B7249","qqName":"so easy","qqOpenid":"A4A136FB7A4652F97BA3ABB23F3B7249","registerType":2,"runTime":0,"state":1,"step":0,"type":1,"wbName":"","wbOpenid":"","weight":0,"wxName":"","wxOpenid":""}
     */

    private List<Integer> collectIds;

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public void setCollectIds(List<Integer> collectIds) {
        this.collectIds = collectIds;
    }

    public UserEntity getUser() {
        return user;
    }

    public List<Integer> getCollectIds() {
        return collectIds;
    }

    public static class UserEntity {
        private int age;
        private String avatar;
        private int calorie;
        private int distance;
        private String email;
        private int gender;
        private int height;
        private int id;
        private int loginType;
        private String mobile;
        private String name;
        private String openid;
        private String qqName;
        private String qqOpenid;
        private int registerType;
        private int runTime;
        private int state;
        private int step;
        private int type;
        private String wbName;
        private String wbOpenid;
        private int weight;
        private String wxName;
        private String wxOpenid;

        public void setAge(int age) {
            this.age = age;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setLoginType(int loginType) {
            this.loginType = loginType;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setOpenid(String openid) {
            this.openid = openid;
        }

        public void setQqName(String qqName) {
            this.qqName = qqName;
        }

        public void setQqOpenid(String qqOpenid) {
            this.qqOpenid = qqOpenid;
        }

        public void setRegisterType(int registerType) {
            this.registerType = registerType;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setStep(int step) {
            this.step = step;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setWbName(String wbName) {
            this.wbName = wbName;
        }

        public void setWbOpenid(String wbOpenid) {
            this.wbOpenid = wbOpenid;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public void setWxName(String wxName) {
            this.wxName = wxName;
        }

        public void setWxOpenid(String wxOpenid) {
            this.wxOpenid = wxOpenid;
        }

        public int getAge() {
            return age;
        }

        public String getAvatar() {
            return avatar;
        }

        public int getCalorie() {
            return calorie;
        }

        public int getDistance() {
            return distance;
        }

        public String getEmail() {
            return email;
        }

        public int getGender() {
            return gender;
        }

        public int getHeight() {
            return height;
        }

        public int getId() {
            return id;
        }

        public int getLoginType() {
            return loginType;
        }

        public String getMobile() {
            return mobile;
        }

        public String getName() {
            return name;
        }

        public String getOpenid() {
            return openid;
        }

        public String getQqName() {
            return qqName;
        }

        public String getQqOpenid() {
            return qqOpenid;
        }

        public int getRegisterType() {
            return registerType;
        }

        public int getRunTime() {
            return runTime;
        }

        public int getState() {
            return state;
        }

        public int getStep() {
            return step;
        }

        public int getType() {
            return type;
        }

        public String getWbName() {
            return wbName;
        }

        public String getWbOpenid() {
            return wbOpenid;
        }

        public int getWeight() {
            return weight;
        }

        public String getWxName() {
            return wxName;
        }

        public String getWxOpenid() {
            return wxOpenid;
        }
    }
}
