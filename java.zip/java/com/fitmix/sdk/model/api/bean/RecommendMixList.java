package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Music;

import java.util.List;

//推荐专辑结果列表
public class RecommendMixList extends BaseBean {

    /**
     * addTime : 1457515475233
     * backImage : http://yyssb.ifitmix.com/2009/9df727a563414d93be6b66efb14156e9.jpg
     * desc : 给力专辑给力专辑给力专辑给力专辑
     * id : 1
     * mixIds : [690,691,692,693]
     * mixList : [{"addTime":1453175301968,"albumUrl":"http://yyssb.ifitmix.com/1001/8391f91026aa44648c3ba770c3f66823.jpg","albumUrl_2":"http://yyssb.ifitmix.com/1001/48b316357878416d909bb235fdf620da.jpg","auditionCount":2,"author":"DJ Ohly","baseAuditionCount":16605,"bpm":"106","bpmType":1,"bpmVariableBegin":106,"bpmVariableEnd":106,"collectNumber":102,"customIdentification":"1100191","downloadCount":1443,"genre":[23],"id":690,"introduce":"100分钟健走,bpm106,步频约每分钟106步,速度约为5km/h。Rock风格的混音。","maid":141,"mixMusics":[],"name":"健走摇滚100分钟","scene":[4],"shareCount":33,"shelvesTime":1454398573254,"state":2,"trackLength":6240,"url":"http://yyssb.ifitmix.com/1000/b90211fad5cf43c6abbae0415656e09e.m4a"},{"addTime":1453181329172,"albumUrl":"http://yyssb.ifitmix.com/1001/a5ed523ab16c49a68523219d5b9dc5a1.jpg","albumUrl_2":"http://yyssb.ifitmix.com/1001/b74521a3c3c34367b18912a680aea106.jpg","author":"DJ Ohly","baseAuditionCount":19978,"bpm":"108","bpmType":1,"bpmVariableBegin":108,"bpmVariableEnd":108,"collectNumber":93,"customIdentification":"1100192","downloadCount":1820,"genre":[23],"id":691,"introduce":"30分钟健走,bpm108,步频约每分钟108步,速度约为5km/h。Rock风格的混音。","maid":141,"mixMusics":[],"name":"健走的摇滚动力","scene":[4],"shareCount":21,"shelvesTime":1454398650484,"state":2,"trackLength":1920,"url":"http://yyssb.ifitmix.com/1000/be6ae846e3804f6fbc59625114f05a1b.m4a"},{"addTime":1453181477969,"albumUrl":"http://yyssb.ifitmix.com/1001/b708f36fb91d41c18b8188ee140cc4e3.jpg","albumUrl_2":"http://yyssb.ifitmix.com/1001/51fc0630df5f450da9364bf465e89ffd.jpg","author":"DJ Ollie","baseAuditionCount":2872,"bpm":"160","bpmType":1,"bpmVariableBegin":160,"bpmVariableEnd":160,"collectNumber":3,"customIdentification":"1100193","downloadCount":74,"genre":[29],"id":692,"introduce":"80分钟中速跑,bpm160,步频约每分钟160步,速度约10km/h。Drum&Bass风格的混音。","maid":142,"mixMusics":[],"name":"轻快中速跑电音混音","scene":[2],"shareCount":0,"shelvesTime":1453802790325,"state":2,"trackLength":5040,"url":"http://yyssb.ifitmix.com/1000/35acaed565894458ba9495ac231d0c61.m4a"}]
     * sort : 0
     * status : 0
     * title : 测试专辑
     */

    private RecommendList data;

    public RecommendList getData() {
        return data;
    }

    public void setData(RecommendList data) {
        this.data = data;
    }

    public static class RecommendList {
        private long addTime;
        private String backImage;
        private String desc;
        private int id;
        private int sort;
        private int status;
        private String title;
        private List<Integer> mixIds;
        /**
         * addTime : 1453175301968
         * albumUrl : http://yyssb.ifitmix.com/1001/8391f91026aa44648c3ba770c3f66823.jpg
         * albumUrl_2 : http://yyssb.ifitmix.com/1001/48b316357878416d909bb235fdf620da.jpg
         * auditionCount : 2
         * author : DJ Ohly
         * baseAuditionCount : 16605
         * bpm : 106
         * bpmType : 1
         * bpmVariableBegin : 106
         * bpmVariableEnd : 106
         * collectNumber : 102
         * customIdentification : 1100191
         * downloadCount : 1443
         * genre : [23]
         * id : 690
         * introduce : 100分钟健走,bpm106,步频约每分钟106步,速度约为5km/h。Rock风格的混音。
         * maid : 141
         * mixMusics : []
         * name : 健走摇滚100分钟
         * scene : [4]
         * shareCount : 33
         * shelvesTime : 1454398573254
         * state : 2
         * trackLength : 6240
         * url : http://yyssb.ifitmix.com/1000/b90211fad5cf43c6abbae0415656e09e.m4a
         */

        private List<Music> mixList;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public String getBackImage() {
            return backImage;
        }

        public void setBackImage(String backImage) {
            this.backImage = backImage;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getSort() {
            return sort;
        }

        public void setSort(int sort) {
            this.sort = sort;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<Integer> getMixIds() {
            return mixIds;
        }

        public void setMixIds(List<Integer> mixIds) {
            this.mixIds = mixIds;
        }

        public List<Music> getMixList() {
            return mixList;
        }

        public void setMixList(List<Music> mixList) {
            this.mixList = mixList;
        }
    }
}
