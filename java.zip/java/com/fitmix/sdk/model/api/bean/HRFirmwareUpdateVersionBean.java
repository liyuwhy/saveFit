package com.fitmix.sdk.model.api.bean;

/**
 * 检测服务器上心率耳机固件最新版本信息(/headset/upgrade.json?)接口返回的结果
 */

public class HRFirmwareUpdateVersionBean {

    /*{"st":1506392658828,"des":"eee","code":0,"k":"4adcaa159d9244cca9a97a14c1efa413",
            "url":"http://yyssb.ifitmix.com/2014/02d90ac8bc2b4356aebe6d6aafa509cb.zip",
            "newVersion":201}*/
    private String url;
    private int newVersion;
    private String des;

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getNewVersion() {
        return newVersion;
    }

    public void setNewVersion(int newVersion) {
        this.newVersion = newVersion;
    }
}
