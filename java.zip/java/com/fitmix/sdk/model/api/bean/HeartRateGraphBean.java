package com.fitmix.sdk.model.api.bean;

/**
 * 用于绘制静息静息图表的Bean类
 */
public class HeartRateGraphBean {
    private int restHR;
    private int year;//年份
    private int month;//月份
    private int day;//当月的日期（天）

    public HeartRateGraphBean(int restHR, int year, int month, int day) {
        this.restHR = restHR;
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public int getRestHR() {
        return restHR;
    }

    public void setRestHR(int restHR) {
        this.restHR = restHR;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }
}
