package com.fitmix.sdk.model.api.bean;

/**
 * 获取俱乐部获取信息的结果
 */
public class ClubActive extends BaseBean {
    /**
     * memberCount : 24
     * activeCount : 0
     */
    private ActiveBean active;

    public ActiveBean getActive() {
        return active;
    }

    public void setActive(ActiveBean active) {
        this.active = active;
    }

    public static class ActiveBean {
        private int memberCount;
        private int activeCount;

        public int getMemberCount() {
            return memberCount;
        }

        public void setMemberCount(int memberCount) {
            this.memberCount = memberCount;
        }

        public int getActiveCount() {
            return activeCount;
        }

        public void setActiveCount(int activeCount) {
            this.activeCount = activeCount;
        }
    }
}
