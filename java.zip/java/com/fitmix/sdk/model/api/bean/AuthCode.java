package com.fitmix.sdk.model.api.bean;

/**
 * 获取手机验证码(user-verify-code.json)接口返回的接口
 */
public class AuthCode extends BaseBean {


    /**
     * 验证码
     * data : 122638
     */
    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
