package com.fitmix.sdk.model.api.bean;

/**
 * 上传图片接口(/upload/img.json)返回的结果
 */

public class UploadImage extends BaseBean {


    /**
     * link : http://yyssb.ifitmix.com/1003/3bde4b0672934628a8c2a77f489c1a35.jpg
     */
    private String link;//图片资源地址

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
