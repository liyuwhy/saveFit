package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.ClubNotice;

import java.util.List;

/**
 * 获取俱乐部公告的列表结果
 */
public class ClubNoticeList extends BaseBean {


    /**
     * filter : {}
     * hasNext : false
     * hasPre : false
     * index : 0
     * nextPage : 1
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1457681624691,"address":"自选","backImageUrl":"http://yyssb.ifitmix.com/2003/f8cc5178a1724431856c70241c6a6d20.jpg","beginTime":1457681580,"clubId":527,"content":"蓝筹科技第四期跑步活动3.8 -4.8","desc":"蓝筹科技第四期跑步活动3.8 -4.8","endTime":1460044800,"id":27,"modifyCount":0,"name":"第四期跑步3.8-4.8","status":0,"uid":34051,"user":{"id":34051,"name":"stzh"}},{"addTime":1460104884711,"address":"自选","backImageUrl":"http://yyssb.ifitmix.com/2003/6fb08fe278cd4264b153d62eaa0b8a0c.jpg","beginTime":1460104800,"clubId":527,"content":"第五期跑步活动","desc":"第五期跑步活动","endTime":1462696800,"id":56,"modifyCount":0,"name":"第5期跑步活动","status":0,"uid":34051,"user":{"id":34051,"name":"stzh"}}]
     * size : 20
     * total : 2
     * totalPages : 1
     */

    private PageBean page;

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public static class PageBean {
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;

        private List<ClubNotice> result;

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<ClubNotice> getResult() {
            return result;
        }

        public void setResult(List<ClubNotice> result) {
            this.result = result;
        }

    }
}
