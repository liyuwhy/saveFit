package com.fitmix.sdk.model.api.bean;

/**
 * 登录接口login.json返回结果中的LastRun实体,表示用户上一次的跑步记录
 */
public class LastRun {

    /**
     * addTime : 1463645994408
     * bpm : 28
     * bpmMatch : 20
     * calorie : 12
     * detail : 1003/58038afc45b44892b55afe1f62d2436f.json
     * distance : 513
     * endLat : 22.522549
     * endLng : 113.937204
     * endTime : 1463630412783
     * id : 459834
     * locationType : 1
     * mark : 28.000000000000004
     * model : 1
     * runTime : 444427
     * startLat : 22.52240071614583
     * startLng : 113.93809163411458
     * startTime : 1463629968000
     * state : 1
     * step : 208
     * stepDetail : 2004/f2508629552e44debebf4917eeddeb95.step
     * type : 1
     * uid : 27
     * updateTime : 1463645994408
     * userBpmMatch : 80
     */
    /**
     * 运动记录添加时间
     */
    private long addTime;
    /**
     * 每分钟配速
     */
    private int bpm;
    private int bpmMatch;
    /**
     * 消耗卡路里,单位为卡路里
     */
    private int calorie;
    /**
     * 轨迹文件下载路径
     */
    private String detail;
    /**
     * 跑步距离,单位为米
     */
    private int distance;
    /**
     * 结束点纬度
     */
    private double endLat;
    /**
     * 结束点经度
     */
    private double endLng;
    /**
     * 跑步结束时间
     */
    private long endTime;
    /** */
    private int id;
    /**
     * 定位类型,1:表示GPS,2:表示LBS
     */
    private int locationType;
    /** */
    private double mark;
    /**
     * 运动环境,1:表示室外,2:表示室内
     */
    private int model;
    /**
     * 运动时长,单位为毫秒
     */
    private int runTime;
    /**
     * 开始点纬度
     */
    private double startLat;
    /**
     * 开始点经度
     */
    private double startLng;
    /**
     * 跑步开始时间
     */
    private long startTime;
    /** */
    private int state;
    /**
     * 运动步数
     */
    private int step;
    /**
     * 计步文件下载路径
     */
    private String stepDetail;
    /**
     * 运动类型,表示跑步,骑行等
     */
    private int type;
    /**
     * 用户uid
     */
    private int uid;
    /**
     * 跑步记录更新时间
     */
    private long updateTime;
    private int userBpmMatch;

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public void setBpm(int bpm) {
        this.bpm = bpm;
    }

    public void setBpmMatch(int bpmMatch) {
        this.bpmMatch = bpmMatch;
    }

    public void setCalorie(int calorie) {
        this.calorie = calorie;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public void setEndLat(double endLat) {
        this.endLat = endLat;
    }

    public void setEndLng(double endLng) {
        this.endLng = endLng;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLocationType(int locationType) {
        this.locationType = locationType;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public void setModel(int model) {
        this.model = model;
    }

    public void setRunTime(int runTime) {
        this.runTime = runTime;
    }

    public void setStartLat(double startLat) {
        this.startLat = startLat;
    }

    public void setStartLng(double startLng) {
        this.startLng = startLng;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setState(int state) {
        this.state = state;
    }

    public void setStep(int step) {
        this.step = step;
    }

    public void setStepDetail(String stepDetail) {
        this.stepDetail = stepDetail;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public void setUserBpmMatch(int userBpmMatch) {
        this.userBpmMatch = userBpmMatch;
    }

    public long getAddTime() {
        return addTime;
    }

    public int getBpm() {
        return bpm;
    }

    public int getBpmMatch() {
        return bpmMatch;
    }

    /**
     * 获取消耗卡路里,单位为卡路里
     */
    public int getCalorie() {
        return calorie;
    }

    /**
     * 获取运动轨迹文件下载地址
     */
    public String getDetail() {
        return detail;
    }

    /**
     * 获取跑步距离,单位为米
     */
    public int getDistance() {
        return distance;
    }

    public double getEndLat() {
        return endLat;
    }

    public double getEndLng() {
        return endLng;
    }

    public long getEndTime() {
        return endTime;
    }

    public int getId() {
        return id;
    }

    /**
     * 获取定位类型,1:表示GPS,2:表示LBS
     */
    public int getLocationType() {
        return locationType;
    }

    public double getMark() {
        return mark;
    }

    /**
     * 获取运动环境,1:表示室外,2:表示室内
     */
    public int getModel() {
        return model;
    }

    public int getRunTime() {
        return runTime;
    }

    public double getStartLat() {
        return startLat;
    }

    public double getStartLng() {
        return startLng;
    }

    public long getStartTime() {
        return startTime;
    }

    public int getState() {
        return state;
    }

    public int getStep() {
        return step;
    }

    public String getStepDetail() {
        return stepDetail;
    }

    /**
     * 获取运动类型,如跑步、骑行等
     */
    public int getType() {
        return type;
    }

    public int getUid() {
        return uid;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public int getUserBpmMatch() {
        return userBpmMatch;
    }
}
