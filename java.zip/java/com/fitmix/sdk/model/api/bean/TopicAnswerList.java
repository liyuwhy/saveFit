package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.bean.TopicAnswer;

import java.util.List;

/**
 * 获取话题的回答列表(/theme/answer/list.json?)接口返回的结果
 */
public class TopicAnswerList extends BaseBean {

    /**
     * filter : {}
     * hasNext : false
     * hasPre : false
     * index : 0
     * nextPage : 1
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1498532823980,"avatar":"http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100","content":"%0A++++++++++++++++++++%3Cp%3E%E8%AF%B7%E8%BE%93%E5%85%A5%E5%86%85%E5%AE%B9...%3C%2Fp%3E%0A++++++++++++++++%3Cp%3Eko%3C%2Fp%3E","discussInfo":[],"floor":1,"id":5,"isConfirmed":1,"themeId":3,"type":1,"uid":1,"userName":"qzuser"},{"addTime":1498544083120,"avatar":"http://yyssb.ifitmix.com/1002/51dc2b11a5ea4e18bbdd020dd24b737e.jpg","content":"content","discussInfo":[],"floor":2,"id":6,"isConfirmed":1,"themeId":3,"type":1,"uid":8,"userName":"我说我叫ZZZ"},{"addTime":1498544197553,"avatar":"http://yyssb.ifitmix.com/1002/51dc2b11a5ea4e18bbdd020dd24b737e.jpg","content":"content","discussInfo":[],"floor":3,"id":7,"isConfirmed":1,"themeId":3,"type":1,"uid":8,"userName":"我说我叫ZZZ"}]
     * size : 20
     * total : 3
     * totalPages : 1
     */

    private PageEntity page;

    private Topic theme;

    public Topic getTheme() {
        return theme;
    }

    public void setTheme(Topic theme) {
        this.theme = theme;
    }


    public PageEntity getPage() {
        return page;
    }

    public void setPage(PageEntity page) {
        this.page = page;
    }

    /*public static class Topic {
        */

    /**
     * addTime : 1503898502661
     * avatar : http://wx.qlogo.cn/mmopen/JpZAqmTvW1qzgicUadvRPaH0lUyjiaz7NHm2IgAIYdCPtvRmgHww4vhngC925M7oX9KHO0Am1dw2n4wSsLfOKsdchFZepv6DY7/0
     * backImage : http://yyssb.ifitmix.com/2014/497aadc593b3425cacb5ea14bfbcfd4d.jpg
     * bannerSort : 1
     * categoryId : 5
     * clickNum : 0
     * content :
     * discussNum : 2
     * id : 428
     * isConfirmed : 1
     * isReply : 1
     * isSensitive : 1
     * name :
     * taoLunNum : 0
     * themeType : 1
     * title : 如何成为一个合格的跑者？
     * uid : 1254063
     * upNum : 0
     *//*

        private long addTime;
        private String avatar;
        private String backImage;
        private int bannerSort;
        private int categoryId;
        private int clickNum;
        private String content;
        private int discussNum;
        private int id;
        private int isConfirmed;
        private int isReply;
        private int isSensitive;
        private String name;
        private int taoLunNum;
        private int themeType;
        private String title;
        private int uid;
        private int upNum;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public String getBackImage() {
            return backImage;
        }

        public void setBackImage(String backImage) {
            this.backImage = backImage;
        }

        public int getBannerSort() {
            return bannerSort;
        }

        public void setBannerSort(int bannerSort) {
            this.bannerSort = bannerSort;
        }

        public int getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(int categoryId) {
            this.categoryId = categoryId;
        }

        public int getClickNum() {
            return clickNum;
        }

        public void setClickNum(int clickNum) {
            this.clickNum = clickNum;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getDiscussNum() {
            return discussNum;
        }

        public void setDiscussNum(int discussNum) {
            this.discussNum = discussNum;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getIsConfirmed() {
            return isConfirmed;
        }

        public void setIsConfirmed(int isConfirmed) {
            this.isConfirmed = isConfirmed;
        }

        public int getIsReply() {
            return isReply;
        }

        public void setIsReply(int isReply) {
            this.isReply = isReply;
        }

        public int getIsSensitive() {
            return isSensitive;
        }

        public void setIsSensitive(int isSensitive) {
            this.isSensitive = isSensitive;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getTaoLunNum() {
            return taoLunNum;
        }

        public void setTaoLunNum(int taoLunNum) {
            this.taoLunNum = taoLunNum;
        }

        public int getThemeType() {
            return themeType;
        }

        public void setThemeType(int themeType) {
            this.themeType = themeType;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public int getUpNum() {
            return upNum;
        }

        public void setUpNum(int upNum) {
            this.upNum = upNum;
        }

    }*/

    public static class PageEntity {

        private FilterEntity filter;
        private boolean hasNext;//是否有下一页,true:是,false:否
        private boolean hasPre;//是否有上一页,true:是,false:否
        private int index;//页码
        private int nextPage;//下一页序号
        private int pageNo;//当前页序号
        private int prePage;//上一页序号
        private int size;//每页最大记录数,默认为20
        private int total;//TopicAnswer列表总记录数
        private int totalPages;//总页数
        /**
         * addTime : 1498532823980
         * avatar : http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100
         * content : %0A++++++++++++++++++++%3Cp%3E%E8%AF%B7%E8%BE%93%E5%85%A5%E5%86%85%E5%AE%B9...%3C%2Fp%3E%0A++++++++++++++++%3Cp%3Eko%3C%2Fp%3E
         * discussInfo : []
         * floor : 1
         * id : 5
         * isConfirmed : 1
         * themeId : 3
         * type : 1
         * uid : 1
         * userName : qzuser
         */

        private List<TopicAnswer> result;

        public FilterEntity getFilter() {
            return filter;
        }

        public void setFilter(FilterEntity filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<TopicAnswer> getResult() {
            return result;
        }

        public void setResult(List<TopicAnswer> result) {
            this.result = result;
        }


        public static class FilterEntity {
            private int parentThemeId;
            private int themeType;

            public int getParentThemeId() {
                return parentThemeId;
            }

            public void setParentThemeId(int parentThemeId) {
                this.parentThemeId = parentThemeId;
            }

            public int getThemeType() {
                return themeType;
            }

            public void setThemeType(int themeType) {
                this.themeType = themeType;
            }
        }
    }
}
