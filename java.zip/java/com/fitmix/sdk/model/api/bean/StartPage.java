package com.fitmix.sdk.model.api.bean;

/**
 * Splash广告开始页信息
 */
public class StartPage {

    /**
     * backgroundImg : http://yyssb.ifitmix.com/2010/02400b65dc794e02a3981e43eaeb5cc4.jpg
     * countdown : 2
     * id : 1
     * title : 测试
     */

    private String backgroundImg;
    private int countdown;
    private int id;
    private String title;

    public String getBackgroundImg() {
        return backgroundImg;
    }

    public void setBackgroundImg(String backgroundImg) {
        this.backgroundImg = backgroundImg;
    }

    public int getCountdown() {
        return countdown;
    }

    public void setCountdown(int countdown) {
        this.countdown = countdown;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}