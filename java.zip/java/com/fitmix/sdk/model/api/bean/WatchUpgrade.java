package com.fitmix.sdk.model.api.bean;

/**
 * 手表固件升级接口(watch/upgrade.json)返回的结果
 */

public class WatchUpgrade extends BaseBean {


    /**
     * des : 手表升级包
     * isForce : 1
     * version : c0.0.68
     * fileType : 21
     * url : http://yyssb.ifitmix.com/2014/1637a47b420a4ede975420946053b83b.bin
     * newVersion : 68
     */

    private String des;
    private String isForce;
    private String version;
    private int fileType;
    private String url;
    private String newVersion;

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getIsForce() {
        return isForce;
    }

    public void setIsForce(String isForce) {
        this.isForce = isForce;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getFileType() {
        return fileType;
    }

    public void setFileType(int fileType) {
        this.fileType = fileType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNewVersion() {
        return newVersion;
    }

    public void setNewVersion(String newVersion) {
        this.newVersion = newVersion;
    }
}
