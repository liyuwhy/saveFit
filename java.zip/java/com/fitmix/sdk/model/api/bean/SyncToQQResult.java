package com.fitmix.sdk.model.api.bean;

/**
 * 同步到qq运动返回的结果
 */
public class SyncToQQResult {

    /**
     * data : {}
     * ecode : 0
     * msg :
     * ret : 0
     */

    private int ecode;
    private String msg;
    private int ret;

    public int getEcode() {
        return ecode;
    }

    public void setEcode(int ecode) {
        this.ecode = ecode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getRet() {
        return ret;
    }

    public void setRet(int ret) {
        this.ret = ret;
    }
}
