package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Topic;

/**
 * 添加话题(/theme/add.json)接口返回的结果
 */

public class AddTopic extends BaseBean {

    /**
     * addTime : 1500014521615
     * categoryId : 5
     * clickNum : 0
     * content : %E6%90%9E%E4%BB%80%E4%B9%88%E9%AC%BC%EF%BC%9F
     * id : 39
     * isConfirmed : 1
     * isReply : 1
     * themeType : 1
     * title : 今天晚上我去看电视了
     * uid : 27
     * upNum : 0
     */

    private Topic theme;

    public Topic getTheme() {
        return theme;
    }

    public void setTheme(Topic theme) {
        this.theme = theme;
    }

}
