package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Topic;

import java.util.List;

/**
 * 获取与自己相关的最新话题回答消息(/my/new/theme/msg.json)接口返回的结果
 */

public class TopicAnswerMessage extends BaseBean {


    /**
     * addTime : 1502264226641
     * avatar : http://yyssb.ifitmix.com//1002/18cc7c37f4d241c8814b908f4742ae6e.jpg
     * categoryId : 5
     * clickNum : 0
     * content : 肚子饿死了，还没有人接我们回去。
     * discussNum : 2
     * id : 156
     * isConfirmed : 1
     * isReply : 1
     * name : Barnaby
     * taoLunNum : 0
     * themeType : 1
     * title : 我们的饭什么时候到
     * uid : 209
     * upNum : 0
     */

    private List<Topic> themes;

    public List<Topic> getThemes() {
        return themes;
    }

    public void setThemes(List<Topic> themes) {
        this.themes = themes;
    }

}
