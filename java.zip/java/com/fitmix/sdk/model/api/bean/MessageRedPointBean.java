package com.fitmix.sdk.model.api.bean;

/**
 * 激活 取消用户app的活跃状态(user/upload/device/status.json)接口返回的结果
 */

public class MessageRedPointBean {

    /**
     * st : 1513856860973
     * noticeNum : 1
     * code : 0
     * k : 6aa2ced6e0664dcb8f36a53859777cbf
     */

    private long st;
    private int noticeNum;
    private int code;
    private String k;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public int getNoticeNum() {
        return noticeNum;
    }

    public void setNoticeNum(int noticeNum) {
        this.noticeNum = noticeNum;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }
}
