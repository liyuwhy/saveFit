package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取热词列表接口(get-keyword-list.json)返回的结果
 */
public class KeyWord extends BaseBean {

    /**
     * addTime : 1465328131319
     * id : 1
     * name : 节拍
     * sort : 1
     * state : 2
     * type : 2
     */

    private List<TheKeyWord> result;

    public List<TheKeyWord> getResult() {
        return result;
    }

    public void setResult(List<TheKeyWord> result) {
        this.result = result;
    }

    public static class TheKeyWord {
        private long addTime;
        private int id;
        private String name;
        private int sort;
        private int state;
        private int type;//1是搜索栏显示的,2代表热词

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getSort() {
            return sort;
        }

        public void setSort(int sort) {
            this.sort = sort;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }
    }
}
