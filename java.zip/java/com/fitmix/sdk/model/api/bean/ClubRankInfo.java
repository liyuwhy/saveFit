package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取俱乐部排名信息结果
 */
public class ClubRankInfo extends BaseBean {

    /**
     * calorie : 1549
     * distance : 26576
     * id : 13234
     * step : 23118
     */

    private TotalCountBean totalCount;
    /**
     * statView : [110,10160,0,0,9266,7040,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
     * totalCount : {"calorie":1549,"distance":26576,"id":13234,"step":23118}
     */

    private List<Integer> statView;

    public TotalCountBean getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(TotalCountBean totalCount) {
        this.totalCount = totalCount;
    }

    public List<Integer> getStatView() {
        return statView;
    }

    public void setStatView(List<Integer> statView) {
        this.statView = statView;
    }

    public static class TotalCountBean {
        private int calorie;
        private int distance;
        private int id;
        private int step;

        public int getCalorie() {
            return calorie;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public int getDistance() {
            return distance;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getStep() {
            return step;
        }

        public void setStep(int step) {
            this.step = step;
        }
    }
}
