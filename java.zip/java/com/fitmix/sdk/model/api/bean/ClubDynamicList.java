package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.ClubNews;

import java.util.List;

/**
 * 获取俱乐部动态列表结果
 */
public class ClubDynamicList extends BaseBean {

    /**
     * bpm : 166
     * calorie : 350
     * distance : 4040
     * id : 565388
     * model : 1
     * runTime : 1860000
     * startTime : 1465215590000
     * step : 5148
     * uid : 192057
     * user : {"avatar":"http://tva1.sinaimg.cn/crop.0.0.640.640.1024/6d853dd9jw8eoxr1up16tj20hs0hsgmt.jpg","id":192057,"name":"心想事成万事如意的少女P"}
     * userBpmMatch : 100
     */

    private List<ClubNews> list;

    public List<ClubNews> getList() {
        return list;
    }

    public void setList(List<ClubNews> list) {
        this.list = list;
    }

}
