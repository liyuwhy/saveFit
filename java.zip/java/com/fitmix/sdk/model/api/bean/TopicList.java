package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Topic;

import java.util.List;

/**
 * 获取话题列表(/theme/list.json)接口返回的结果
 */
public class TopicList extends BaseBean {

    /**
     * filter : {"isConfirmed":1}
     * hasNext : false
     * hasPre : false
     * index : 0
     * nextPage : 1
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1498528601135,"avatar":"http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100","categoryId":5,"discussNum":2,"id":3,"isConfirmed":0,"isReply":1,"name":"qzuser","title":"4444444","uid":1,"upNum":0},{"addTime":1496304638665,"avatar":"http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100","categoryId":5,"content":"%3Ch2%3E%E8%B7%91%E6%AD%A5%E6%97%85%E8%A1%8C%3C%2Fh2%3E%3Ch2%3E2017%E4%B8%BA%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE40%E5%B2%81%E5%BA%86%E7%94%9F%3C%2Fh2%3E%3Cp%3E%3Cimg+src%3D%22http%3A%2F%2Fyyssb.ifitmix.com%2F2008%2F9a1d7e1a360b45bf900b6877fe5c2e4b.jpeg%22%3E%3C%2Fp%3E%3Cp%3E%E2%96%A0%3C%2Fp%3E%3Cp%3E%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B+%E5%AF%B9%E4%BA%8E%E6%89%80%E6%9C%89%E9%A9%AC%E6%8B%89%E6%9D%BE%E7%9A%84%E7%88%B1%E5%A5%BD%E8%80%85%E6%9D%A5%E8%AF%B4%EF%BC%8C%E5%85%AD%E5%A4%A7%E6%BB%A1%E8%B4%AF%E4%B8%AD%E2%80%9C%E4%BD%93%E9%AA%8C%E6%9C%80%E4%BD%B3%E2%80%9D%E7%9A%84%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE%E7%BB%9D%E5%AF%B9%E6%98%AF%E4%B8%80%E5%9C%BA%E6%9C%9F%E5%BE%85%E5%B7%B2%E4%B9%85%E7%9A%84%E6%97%85%E7%A8%8B%E3%80%82%3C%2Fp%3E%3Cp%3E%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B+%E5%9B%9E%E7%9C%8B%E4%BB%8A%E5%B9%B4%E7%9A%84%E8%8A%9D%E9%A9%AC%EF%BC%8C%E9%98%BF%E8%B4%9D%E5%B0%94%E2%80%A2%E5%9F%BA%E9%B2%81%E4%BC%8A%E4%BB%A52%EF%BC%9A11%EF%BC%9A23%E7%9A%84%E6%88%90%E7%BB%A9%E5%A4%BA%E5%86%A0%EF%BC%8C%E7%94%B1%E4%BA%8E%E4%B8%BB%E5%8A%9E%E6%96%B9%E5%8F%96%E6%B6%88%E4%BA%86%E7%B2%BE%E8%8B%B1%E5%85%94%E5%AD%90%EF%BC%8C%E6%89%80%E4%BB%A5%E8%AF%9E%E7%94%9F%E4%BA%86%E8%BF%99%E4%B8%AA2007%E5%B9%B4%E4%BB%A5%E6%9D%A5%E2%80%9C%E8%8A%9D%E9%A9%AC%E2%80%9D%E6%9C%80%E6%85%A2%E7%9A%84%E6%88%90%E7%BB%A9%E3%80%82%E4%BD%86%E5%AF%B9%E4%BA%8E%E5%A4%A7%E4%BC%97%E9%80%89%E6%89%8B%E6%9D%A5%E8%AF%B4%EF%BC%8C%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE%E4%BB%A5%E5%B9%B3%E5%9D%A6%E7%9A%84%E8%B5%9B%E9%81%93%E4%B8%BA%E8%AE%B8%E5%A4%9A%E8%B7%91%E8%80%85%E5%88%9B%E9%80%A0%E4%BA%86%E6%96%B0%E7%9A%84PB%EF%BC%8C%E5%90%8C%E6%97%B66%E4%B8%AA%E5%8D%8A%E5%B0%8F%E6%97%B6%E7%9A%84%E5%85%B3%E9%97%A8%E6%97%B6%E9%97%B4%E4%B9%9F%E8%AE%A9%E4%BC%97%E5%A4%9A%E5%8F%82%E8%B5%9B%E9%80%89%E6%89%8B%E9%A1%BA%E5%88%A9%E5%AE%8C%E8%B5%9B%E5%8F%96%E5%BE%97%E5%A5%96%E7%89%8C%E3%80%82%3Cimg+src%3D%22file%3A%2F%2F%2FC%3A%2FUsers%2Flenovo%2FAppData%2FLocal%2FTemp%2Fksohtml%2Fwps583D.tmp.png%22%3E%3C%2Fp%3E%3Cp%3E%E2%96%A0%3C%2Fp%3E%3Cp%3E%3Cimg+src%3D%22http%3A%2F%2Fyyssb.ifitmix.com%2F2008%2F53ba6317145947ffa34d38f3be9a72c7.jpeg%22%3E%3C%2Fp%3E%3Cp%3E%E2%96%A0%3C%2Fp%3E%3Cp%3E%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B%26nbsp%3B+%E5%AF%B9%E4%BA%8E%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE%E6%9D%A5%E8%AF%B42017%E5%B9%B4%E7%BB%9D%E5%AF%B9%E6%98%AF%E4%B8%AA%E7%89%B9%E5%88%AB%E7%9A%84%E6%97%A5%E5%AD%90%EF%BC%8C%E2%80%9C%E8%8A%9D%E9%A9%AC%E2%80%9D%E4%B9%9F%E5%B0%86%E8%BF%8E%E6%9D%A5%E5%AE%8340%E8%80%8C%E7%AB%8B%E7%9A%84%E9%87%8D%E8%A6%81%E6%97%A5%E5%AD%90%E3%80%82%E8%BF%99%E4%B8%AA%E7%9C%8B%E4%BC%BC%E6%88%90%E7%86%9F%E5%8F%88%E7%A8%B3%E9%87%8D%E7%9A%84%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE%E8%B5%9B%E4%BA%8B%EF%BC%8C%E5%9B%A0%E7%8E%B0%E5%9C%BA%E8%93%9D%E8%B0%83%E3%80%81%E7%88%B5%E5%A3%AB%E3%80%81%E6%91%87%E6%BB%9A%E7%AD%89%E5%A4%9A%E7%A7%8D%E9%A3%8E%E6%A0%BC%E7%9A%84%E9%9F%B3%E4%B9%90%E5%90%A7%E4%BB%A5%E5%8F%8A%E8%B7%AF%E6%97%81%E4%B8%8A%E7%99%BE%E4%B8%87%E6%9D%A5%E8%87%AA%E4%B8%8D%E5%90%8C%E6%97%8F%E8%A3%94%E7%9A%84%E5%B8%82%E6%B0%91%E5%96%9D%E5%BD%A9%EF%BC%8C%E4%BD%BF%E5%BE%97%E8%8A%9D%E5%8A%A0%E5%93%A5%E9%A9%AC%E6%8B%89%E6%9D%BE%E5%85%85%E6%BB%A1%E9%9D%92%E6%98%A5%E6%B4%8B%E6%BA%A2%EF%BC%8C%E5%85%85%E6%BB%A1%E4%BA%86%E6%BF%80%E6%83%85%E4%B8%8E%E6%B4%BB%E5%8A%9B%E3%80%82%3C%2Fp%3E%3Cp%3E%E2%96%A0%3C%2Fp%3E%3Cp%3E%3Cbr%3E%3C%2Fp%3E","id":2,"isConfirmed":0,"name":"qzuser","title":"今天的天气真好","uid":1,"upNum":0}]
     * size : 20
     * total : 2
     * totalPages : 1
     */

    private PageEntity page;

    public PageEntity getPage() {
        return page;
    }

    public void setPage(PageEntity page) {
        this.page = page;
    }

    public static class PageEntity {
        /**
         * isConfirmed : 1
         */
        private FilterEntity filter;
        private boolean hasNext;//是否有下一页,true:是,false:否
        private boolean hasPre;//是否有上一页,true:是,false:否
        private int index;//页码
        private int nextPage;//下一页序号
        private int pageNo;//当前页序号
        private int prePage;//上一页序号
        private int size;//每页最大记录数,默认为20
        private int total;//Topic列表总记录数
        private int totalPages;//总页数
        /**
         * addTime : 1498528601135
         * avatar : http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100
         * categoryId : 5
         * discussNum : 2
         * id : 3
         * isConfirmed : 0
         * isReply : 1
         * name : qzuser
         * title : 4444444
         * themeVip:1
         * uid : 1
         * upNum : 0
         */

        private List<Topic> result;//话题列表

        public FilterEntity getFilter() {
            return filter;
        }

        public void setFilter(FilterEntity filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<Topic> getResult() {
            return result;
        }

        public void setResult(List<Topic> result) {
            this.result = result;
        }

        public static class FilterEntity {
            private int isConfirmed;
            private int themeType;
            private String searchText;//搜索关键字

            public int getIsConfirmed() {
                return isConfirmed;
            }

            public void setIsConfirmed(int isConfirmed) {
                this.isConfirmed = isConfirmed;
            }

            public int getThemeType() {
                return themeType;
            }

            public void setThemeType(int themeType) {
                this.themeType = themeType;
            }

            public String getSearchText() {
                return searchText;
            }

            public void setSearchText(String searchText) {
                this.searchText = searchText;
            }
        }


    }
}
