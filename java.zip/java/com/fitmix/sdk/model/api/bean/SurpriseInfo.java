package com.fitmix.sdk.model.api.bean;


public class SurpriseInfo extends BaseBean {

    private Surprise surprise;

    public void setSurprise(Surprise surprise) {
        this.surprise = surprise;
    }

    public Surprise getSurprise() {
        return surprise;
    }

    public static class Surprise {
        /**
         * 名称
         */
        private String name;
        /**
         * 类型 0:默认 1：静态图片 2：文字 3：天气
         */
        private int type;
        /**
         * 上架状态 1.未上架 2.已上架
         */
        private int state;
        /**
         * 图片链接
         */
        private String imgUrl;
        /**
         * 标题
         */
        private String title;
        /**
         * 内容
         */
        private String content;
        /**
         * 开始时间
         */
        private long startTime;
        /**
         * 结束时间
         */
        private long endTime;
        /**
         * 添加时间
         */
        private long addTime;

        /**
         * 天气预报信息
         */
        private BaiduWeather baiduWeather;


        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }


        public Integer getType() {
            return type;
        }

        public void setType(Integer type) {
            this.type = type;
        }

        public Integer getState() {
            return state;
        }

        public void setState(Integer state) {
            this.state = state;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public Long getStartTime() {
            return startTime;
        }

        public void setStartTime(Long startTime) {
            this.startTime = startTime;
        }

        public Long getEndTime() {
            return endTime;
        }

        public void setEndTime(Long endTime) {
            this.endTime = endTime;
        }

        public Long getAddTime() {
            return addTime;
        }

        public void setAddTime(Long addTime) {
            this.addTime = addTime;
        }

        public BaiduWeather getBaiduWeather() {
            return baiduWeather;
        }

        public void setBaiduWeather(BaiduWeather baiduWeather) {
            this.baiduWeather = baiduWeather;
        }
    }
}
