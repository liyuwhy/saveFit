package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.widget.trainingplan.StagesBean;

import java.util.List;

/**
 * 获取正在训练中的训练计划 (run-plan/get-user-plan.json)接口返回的结果
 */
public class Training extends BaseBean {

    /**
     * ability : 3
     * abilityTime : 83.05
     * beginTime : 1
     * competitionTime : 1478534400000
     * completedDistance : 0
     * completedRunDay : 0
     * distance : 198
     * endTime : 1487001600000
     * executeNo : 1
     * executeStage : 1
     * id : 30
     * planTime : 1478588067306
     * plan_state : 1
     * resultTime : 1963
     * resultTimeStr : 0:32:43
     * runDay : 40
     * type : 0
     * typeName : 5公里
     * uid : 315798
     */

    private UserPlanBean user_plan;

    public UserPlanBean getUserPlan() {
        return user_plan;
    }

    public void setUserPlan(UserPlanBean user_plan) {
        this.user_plan = user_plan;
    }

    public static class UserPlanBean {
        private int ability;
        private double abilityTime;
        private int beginTime;
        private long competitionTime;
        private double completedDistance;
        private int completedRunDay;
        private double distance;
        private long endTime;
        private int executeNo;
        private int executeStage;
        private int id;
        private long planTime;
        private int plan_state;
        private int planType;
        private int resultTime;
        private String resultTimeStr;
        private int runDay;
        private int type;
        private String typeName;
        private int uid;

        /**
         * contentDescription : 与跑步一样，休息也是训练中的重要部分。它可让您的身体恢复，使您在下一次跑步中变得更强。休息能够提高当前训练的效果。
         * date : 0
         * dateLong : 1478534400000
         * dateTime : 2016-11-08
         * distance : 0
         * stageContent : 休息
         * stageName : 预备
         * stageType : 0
         * state : -1
         */

        private List<List<StagesBean>> stagesList;
        /**
         * contentDescription : 与跑步一样，休息也是训练中的重要部分。它可让您的身体恢复，使您在下一次跑步中变得更强。休息能够提高当前训练的效果。
         * date : 0
         * dateLong : 1478534400000
         * dateTime : 2016-11-08
         * distance : 0
         * stageContent : 休息
         * stageName : 预备
         * stageType : 0
         * state : -1
         */

        private List<StagesBean> stagesLists;

        public int getAbility() {
            return ability;
        }

        public void setAbility(int ability) {
            this.ability = ability;
        }

        public double getAbilityTime() {
            return abilityTime;
        }

        public void setAbilityTime(double abilityTime) {
            this.abilityTime = abilityTime;
        }

        public int getBeginTime() {
            return beginTime;
        }

        public void setBeginTime(int beginTime) {
            this.beginTime = beginTime;
        }

        public long getCompetitionTime() {
            return competitionTime;
        }

        public void setCompetitionTime(long competitionTime) {
            this.competitionTime = competitionTime;
        }

        public double getCompletedDistance() {
            return completedDistance;
        }

        public void setCompletedDistance(int completedDistance) {
            this.completedDistance = completedDistance;
        }

        public int getCompletedRunDay() {
            return completedRunDay;
        }

        public void setCompletedRunDay(int completedRunDay) {
            this.completedRunDay = completedRunDay;
        }

        public double getDistance() {
            return distance;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public long getEndTime() {
            return endTime;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public int getExecuteNo() {
            return executeNo;
        }

        public void setExecuteNo(int executeNo) {
            this.executeNo = executeNo;
        }

        public int getExecuteStage() {
            return executeStage;
        }

        public void setExecuteStage(int executeStage) {
            this.executeStage = executeStage;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public long getPlanTime() {
            return planTime;
        }

        public void setPlanTime(long planTime) {
            this.planTime = planTime;
        }

        public int getPlanState() {
            return plan_state;
        }

        public void setPlanState(int plan_state) {
            this.plan_state = plan_state;
        }

        public int getPlanType() {
            return planType;
        }

        public void setPlanType(int planType) {
            this.planType = planType;
        }


        public int getResultTime() {
            return resultTime;
        }

        public void setResultTime(int resultTime) {
            this.resultTime = resultTime;
        }

        public String getResultTimeStr() {
            return resultTimeStr;
        }

        public void setResultTimeStr(String resultTimeStr) {
            this.resultTimeStr = resultTimeStr;
        }

        public int getRunDay() {
            return runDay;
        }

        public void setRunDay(int runDay) {
            this.runDay = runDay;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public String getTypeName() {
            return typeName;
        }

        public void setTypeName(String typeName) {
            this.typeName = typeName;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public List<List<StagesBean>> getStagesList() {
            return stagesList;
        }

        public void setStagesList(List<List<StagesBean>> stagesList) {
            this.stagesList = stagesList;
        }

        public List<StagesBean> getStagesLists() {
            return stagesLists;
        }

        public void setStagesLists(List<StagesBean> stagesLists) {
            this.stagesLists = stagesLists;
        }
    }
}
