package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 添加运动信息接口(add-run.json)返回的结果
 */
public class AddRunRecord extends BaseBean {

    /**
     * lastAddTime : 1466848493195
     * userRun : {"addTime":1466848493195,"bpm":257,"bpmMatch":-1,"calorie":8,"detail":"","distance":131,"endLat":0,"endLng":0,"endTime":1466848404383,"id":699482,"locationType":0,"mark":96,"model":1,"runTime":30303,"startLat":0,"startLng":0,"startTime":1466848374000,"state":1,"step":130,"stepDetail":"http://yyssb.ifitmix.com/2004/c907f7a6a9e14148a19b5e0dfc8d21f1.step","type":1,"uid":27,"updateTime":1466848493195,"userBpmMatch":101}
     */

    /**
     * 服务器最后一次添加运动记录的时间
     */
    private long lastAddTime;

    /**
     * 用户跑步等级是否升级
     */
    private int levelUp;
    /**
     * addTime : 1466848493195
     * bpm : 257
     * bpmMatch : -1
     * calorie : 8
     * detail :
     * distance : 131
     * endLat : 0
     * endLng : 0
     * endTime : 1466848404383
     * id : 699482
     * locationType : 0
     * mark : 96
     * model : 1
     * runTime : 30303
     * startLat : 0
     * startLng : 0
     * startTime : 1466848374000
     * state : 1
     * step : 130
     * stepDetail : http://yyssb.ifitmix.com/2004/c907f7a6a9e14148a19b5e0dfc8d21f1.step
     * type : 1
     * uid : 27
     * updateTime : 1466848493195
     * userBpmMatch : 101
     */

    private UserRunEntity userRun;

    /**
     * "addTime" : 1482344171406,
     * "distance" : 3237,
     * "halfMarathonAbility" : 0,
     * "id" : 870,
     * "modifyTime" : 1482431537772,
     * "runLevel" : "RUN_LEVEL_9",
     * "tenMileAbility" : 0,
     * "uid" : 27
     */
    private UserRunStatistics userRunStatistics;

    /**
     * [{"addTime":1482917285101,"aid":678885,"coin":10,"description":"达到-中级跑者 I","flowType":0,"id":61990,"modifyTime":1482917285101,"uid":918504}
     * , {"addTime":1482917285132,"aid":678885,"coin":20,"description":"达到-中级跑者 II","flowType":0,"id":61991,"modifyTime":1482917285132,"uid":918504}]
     */
    private List<CoinReward> accountFlowList;

    public void setLastAddTime(long lastAddTime) {
        this.lastAddTime = lastAddTime;
    }

    public void setUserRun(UserRunEntity userRun) {
        this.userRun = userRun;
    }

    /**
     * 获取用户跑步等级是否升级
     *
     * @return 0:表示未升级,1:表示升级
     */
    public int getLevelUp() {
        return levelUp;
    }

    public void setLevelUp(int levelUp) {
        this.levelUp = levelUp;
    }

    public long getLastAddTime() {
        return lastAddTime;
    }

    public UserRunEntity getUserRun() {
        return userRun;
    }

    public UserRunStatistics getUserRunStatistics() {
        return userRunStatistics;
    }

    public void setUserRunStatistics(UserRunStatistics userRunStatistics) {
        this.userRunStatistics = userRunStatistics;
    }

    public List<CoinReward> getAccountFlowList() {
        return accountFlowList;
    }

    public void setAccountFlowList(List<CoinReward> accountFlowList) {
        this.accountFlowList = accountFlowList;
    }

    /**
     * 各字段的含义参考{@link com.fitmix.sdk.bean.RunLogInfo}
     */
    public static class UserRunEntity {
        private long addTime;//记录添加时间
        private int bpm;
        private int bpmMatch;
        private long calorie;
        private String detail;
        private int distance;
        private double endLat;
        private double endLng;
        private long endTime;
        private long id;//后台服务器生成的跑步记录编号
        private int locationType;//定位类型,1:GPS定位,2:LBS定位
        private int mark;
        private int model;//运动环境(1:室外,2:室内)
        private long runTime;//运动时长,单位毫秒
        private double startLat;
        private double startLng;
        private long startTime;
        private int state;
        private int step;
        private String stepDetail;
        private int type;
        private int uid;
        private long updateTime;
        private int userBpmMatch;

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public void setBpm(int bpm) {
            this.bpm = bpm;
        }

        public void setBpmMatch(int bpmMatch) {
            this.bpmMatch = bpmMatch;
        }

        public void setCalorie(long calorie) {
            this.calorie = calorie;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public void setEndLat(double endLat) {
            this.endLat = endLat;
        }

        public void setEndLng(double endLng) {
            this.endLng = endLng;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public void setId(long id) {
            this.id = id;
        }

        public void setLocationType(int locationType) {
            this.locationType = locationType;
        }

        public void setMark(int mark) {
            this.mark = mark;
        }

        public void setModel(int model) {
            this.model = model;
        }

        public void setRunTime(long runTime) {
            this.runTime = runTime;
        }

        public void setStartLat(double startLat) {
            this.startLat = startLat;
        }

        public void setStartLng(double startLng) {
            this.startLng = startLng;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setStep(int step) {
            this.step = step;
        }

        public void setStepDetail(String stepDetail) {
            this.stepDetail = stepDetail;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }

        public void setUserBpmMatch(int userBpmMatch) {
            this.userBpmMatch = userBpmMatch;
        }

        public long getAddTime() {
            return addTime;
        }

        public int getBpm() {
            return bpm;
        }

        public int getBpmMatch() {
            return bpmMatch;
        }

        public long getCalorie() {
            return calorie;
        }

        public String getDetail() {
            return detail;
        }

        public int getDistance() {
            return distance;
        }

        public double getEndLat() {
            return endLat;
        }

        public double getEndLng() {
            return endLng;
        }

        public long getEndTime() {
            return endTime;
        }

        public long getId() {
            return id;
        }

        public int getLocationType() {
            return locationType;
        }

        public int getMark() {
            return mark;
        }

        public int getModel() {
            return model;
        }

        public long getRunTime() {
            return runTime;
        }

        public double getStartLat() {
            return startLat;
        }

        public double getStartLng() {
            return startLng;
        }

        public long getStartTime() {
            return startTime;
        }

        public int getState() {
            return state;
        }

        public int getStep() {
            return step;
        }

        public String getStepDetail() {
            return stepDetail;
        }

        public int getType() {
            return type;
        }

        public int getUid() {
            return uid;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public int getUserBpmMatch() {
            return userBpmMatch;
        }
    }
}
