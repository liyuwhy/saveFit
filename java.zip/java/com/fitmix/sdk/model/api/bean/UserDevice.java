package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 查找用户智能设备接口(/user/get/smart/device.json)返回的结果
 */

public class UserDevice extends BaseBean {


    private List<SmartDevicesBean> smartDevices;

    public List<SmartDevicesBean> getSmartDevices() {
        return smartDevices;
    }

    public void setSmartDevices(List<SmartDevicesBean> smartDevices) {
        this.smartDevices = smartDevices;
    }

    public static class SmartDevicesBean {
        /**
         * addTime : 1517815059445
         * deviceInfo : {"IRONCLOUD_CHIPID":"74B5E7EEB1E5AA55","IRONCLOUD_SN":"A1AX0100HPHH000057"}
         * id : 37
         * key : 27_IRONCLOUDT1_74B5E7EEB1E5AA55
         * status : 1
         * type : 1
         * uid : 27
         */

        private long addTime;
        private DeviceInfoBean deviceInfo;
        private int id;
        private String key;
        private int status;
        private int type;//设备类型,1:手表
        private int uid;//对应的乐享动uid

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public DeviceInfoBean getDeviceInfo() {
            return deviceInfo;
        }

        public void setDeviceInfo(DeviceInfoBean deviceInfo) {
            this.deviceInfo = deviceInfo;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public static class DeviceInfoBean {
            /**
             * IRONCLOUD_MAC: XXXX
             * IRONCLOUD_CHIPID : 74B5E7EEB1E5AA55
             * IRONCLOUD_SN : A1AX0100HPHH000057
             */

            private String IRONCLOUD_MAC;
            private String IRONCLOUD_CHIPID;
            private String IRONCLOUD_SN;

            public String getIRONCLOUD_MAC() {
                return IRONCLOUD_MAC;
            }

            public void setIRONCLOUD_MAC(String IRONCLOUD_MAC) {
                this.IRONCLOUD_MAC = IRONCLOUD_MAC;
            }

            public String getIRONCLOUD_CHIPID() {
                return IRONCLOUD_CHIPID;
            }

            public void setIRONCLOUD_CHIPID(String IRONCLOUD_CHIPID) {
                this.IRONCLOUD_CHIPID = IRONCLOUD_CHIPID;
            }

            public String getIRONCLOUD_SN() {
                return IRONCLOUD_SN;
            }

            public void setIRONCLOUD_SN(String IRONCLOUD_SN) {
                this.IRONCLOUD_SN = IRONCLOUD_SN;
            }
        }
    }
}
