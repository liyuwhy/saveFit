package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.Banner;

import java.util.List;

/**
 * 获取banner列表接口(/mix-banner/list.json)返回的结果
 */
public class BannerList extends BaseBean {

    private List<Banner> data;

    public List<Banner> getData() {
        return data;
    }

    public void setData(List<Banner> data) {
        this.data = data;
    }
}
