package com.fitmix.sdk.model.api.bean;

/**
 * 登录接口login.json返回结果中的SumSkipRope实体,表示用户
 * 里面的卡路里 跳绳个数 跳绳时间为总数
 */
public class SumSkipRope {
    private long calorie;
    private long runTime;
    private long skipNum;

    public long getCalorie() {
        return calorie;
    }

    public void setCalorie(long calorie) {
        this.calorie = calorie;
    }

    public long getRunTime() {
        return runTime;
    }

    public void setRunTime(long runTime) {
        this.runTime = runTime;
    }

    public long getSkipNum() {
        return skipNum;
    }

    public void setSkipNum(long skipNum) {
        this.skipNum = skipNum;
    }
}
