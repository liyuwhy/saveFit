package com.fitmix.sdk.model.api.bean;

import android.text.TextUtils;

import com.fitmix.sdk.common.Logger;

/**
 * 登录接口login.json或添加运动信息接口(add-run.json)返回结果中的UserRunStatistics实体
 */
public class UserRunStatistics {

    /**
     * addTime : 1480588104883
     * distance : 230275
     * halfMarathonAbility : 0
     * id : 11346
     * modifyTime : 1480588104883
     * runLevel : RUN_LEVEL_9
     * tenMileAbility : 0
     * uid : 27
     */

    private long addTime;//
    private int distance;//有效总里程,单位为米
    private int halfMarathonAbility;//半马能力
    private int id;
    private long modifyTime;
    private String runLevel;//跑者等级
    private int tenMileAbility;//十公里能力
    private int uid;

    public long getAddTime() {
        return addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getHalfMarathonAbility() {
        return halfMarathonAbility;
    }

    public void setHalfMarathonAbility(int halfMarathonAbility) {
        this.halfMarathonAbility = halfMarathonAbility;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(long modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getRunLevel() {
        return runLevel;
    }

    public void setRunLevel(String runLevel) {
        this.runLevel = runLevel;
    }

    public int getTenMileAbility() {
        return tenMileAbility;
    }

    public void setTenMileAbility(int tenMileAbility) {
        this.tenMileAbility = tenMileAbility;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    /**
     * 获取用户等级,由runLevel 解析出来的数字等级
     *
     * @return 1:初入跑坛,2:初级跑者I,3:初级跑者II,4:初级跑者III,5:中级跑者I,6:中级跑者II,7:中级跑者III,
     * 8:高级跑者I,9:高级跑者II,10:高级跑者III,
     * 11:顶级跑者I,12:顶级跑者II,13:顶级跑者III,14:神级跑者I,15:神级跑者II,16:神级跑者III
     */
    public int getUserLevel() {
        int userLevel = 0;
        if (TextUtils.isEmpty(runLevel))
            return userLevel;
        if (runLevel.contains("RUN_LEVEL_")) {
            try {
                userLevel = Integer.parseInt(runLevel.substring(10));
            } catch (Exception e) {
                Logger.e(Logger.DEBUG_TAG, "setUserLevel error:" + e.getMessage() + runLevel);
            }

        }
        return userLevel;
    }

}
