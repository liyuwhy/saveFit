package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.model.api.ApiUtils;

/**
 * 登录接口login.json返回结果中的User实体
 */
public class User {

    /**
     * age : 24
     * avatar : http://yyssb.ifitmix.com/1002/f896b9264a0b489ea3fbd4ede1a17882.jpg
     * calorie : 15079
     * distance : 468660
     * email : 398135219@qq.com
     * gender : 1
     * height : 170
     * id : 27
     * lastRun : {"addTime":1463645994408,"bpm":28,"bpmMatch":20,"calorie":12,"detail":"1003/58038afc45b44892b55afe1f62d2436f.json","distance":513,"endLat":22.522549,"endLng":113.937204,"endTime":1463630412783,"id":459834,"locationType":1,"mark":28.000000000000004,"model":1,"runTime":444427,"startLat":22.52240071614583,"startLng":113.93809163411458,"startTime":1463629968000,"state":1,"step":208,"stepDetail":"2004/f2508629552e44debebf4917eeddeb95.step","type":1,"uid":27,"updateTime":1463645994408,"userBpmMatch":80}
     * loginType : 1
     * name : Barnaby
     * password : 123456
     * runTime : 4704
     * signature : 联想
     * state : 1
     * step : 279903
     * type : 1
     * userRealInfo : {}
     * weight : 55
     */
    /**
     * 年龄
     */
    private int age;
    /**
     * 头像地址
     */
    private String avatar;
    /**
     * 运动总消耗卡路里,单位大卡
     */
    private long calorie;
    /**
     * 运动总距离,单位米
     */
    private long distance;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 性别,1:男,2:女
     */
    private int gender;
    /**
     * 身高,单位厘米
     */
    private int height;
    /**
     * 用户uid
     */
    private int id;
    /**
     * 上一次的跑步记录
     */
    private LastRun lastRun;
    /**
     * 上一次的跳绳记录
     */
    private SumSkipRope sumSkipRope;
    /**
     * 登录类型,1:表示邮箱账号登录,2:表示,3:表示,4:表示,5:表示手机登录
     */
    private int loginType;
    /**
     * 用户昵称
     */
    private String name;
//    /** 登录密码,后台接口不再返回*/
//    private String password;
    /**
     * 运动总时长,单位为分钟
     */
    private long runTime;
    /**
     * 个性签名
     */
    private String signature;
    /** */
    private int state;
    /**
     * 运动总步数
     */
    private long step;
    /**
     * 计量单位类型,1:公制,2:英制
     */
    private int type;
    /**
     * 用户真实信息
     */
    private UserRealInfo userRealInfo;
    /**
     * 体重,单位为千克
     */
    private int weight;
    /**
     * 总的跑步心率总汇
     */
    private UserHeartRate lastRunHeartRate;
    /**
     * 总的跳绳心率总汇
     */
    private UserHeartRate lastSkipRopeHeartRate;
    /**
     * 脂肪总量（运动消耗的脂肪总数量）
     */
    private double consumeFatSum;

    //其他三种登录类型返回的零碎结果集
    private String mobile;
    private String openid;
    private String qqName;
    private String qqOpenid;
    private int registerType;
    private String wbName;
    private String wbOpenid;
    private String wxName;
    private String wxOpenid;

    public void setAge(int age) {
        this.age = age;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public void setCalorie(long calorie) {
        this.calorie = calorie;
    }

    /**
     * 设置运动总距离,单位米
     */
    public void setDistance(long distance) {
        this.distance = distance;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLastRun(LastRun lastRun) {
        this.lastRun = lastRun;
    }

    public void setLoginType(int loginType) {
        this.loginType = loginType;
    }

    public void setName(String name) {
        this.name = name;
    }

//    public void setPassword(String password) {
//        this.password = password;
//    }

    /**
     * 设置运动总时长,单位为分钟
     */
    public void setRunTime(long runTime) {
        this.runTime = runTime;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public void setState(int state) {
        this.state = state;
    }

    public void setStep(long step) {
        this.step = step;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setUserRealInfo(UserRealInfo userRealInfo) {
        this.userRealInfo = userRealInfo;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getAge() {
        return age;
    }

    public String getAvatar() {
        return avatar;
    }

    public long getCalorie() {
        return calorie;
    }

    /**
     * 获取运动总距离,单位米
     */
    public long getDistance() {
        return distance;
    }

    public String getEmail() {
        return email;
    }

    public int getGender() {
        return gender;
    }

    public int getHeight() {
        return height;
    }

    public int getId() {
        return id;
    }

    public LastRun getLastRun() {
        return lastRun;
    }

    public int getLoginType() {
        return loginType;
    }

    public String getName() {
        return name;
    }

//    public String getPassword() {
//        return password;
//    }

    /**
     * 获取运动总时长,单位为分钟
     */
    public long getRunTime() {
        return runTime;
    }

    public String getSignature() {
        if( !ApiUtils.isZhLanguage() &&signature != null && signature.contains("把握你节奏,跃动乐享动")){
            return "Enjoy your rhythm";
        }
        return signature;
    }

    public int getState() {
        return state;
    }

    public long getStep() {
        return step;
    }

    /**
     * 获取计量单位类型,1:公制,2:英制
     */
    public int getType() {
        return type;
    }

    public UserRealInfo getUserRealInfo() {
        return userRealInfo;
    }

    public int getWeight() {
        return weight;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getQqName() {
        return qqName;
    }

    public void setQqName(String qqName) {
        this.qqName = qqName;
    }

    public String getQqOpenid() {
        return qqOpenid;
    }

    public void setQqOpenid(String qqOpenid) {
        this.qqOpenid = qqOpenid;
    }

    public int getRegisterType() {
        return registerType;
    }

    public void setRegisterType(int registerType) {
        this.registerType = registerType;
    }

    public String getWbName() {
        return wbName;
    }

    public void setWbName(String wbName) {
        this.wbName = wbName;
    }

    public String getWbOpenid() {
        return wbOpenid;
    }

    public void setWbOpenid(String wbOpenid) {
        this.wbOpenid = wbOpenid;
    }

    public String getWxName() {
        return wxName;
    }

    public void setWxName(String wxName) {
        this.wxName = wxName;
    }

    public String getWxOpenid() {
        return wxOpenid;
    }

    public void setWxOpenid(String wxOpenid) {
        this.wxOpenid = wxOpenid;
    }

    public void setSumSkipRope(SumSkipRope sumSkipRope) {
        this.sumSkipRope = sumSkipRope;
    }

    public SumSkipRope getSumSkipRope() {
        return sumSkipRope;
    }

    public UserHeartRate getLastRunHeartRate() {
        return lastRunHeartRate;
    }

    public void setLastRunHeartRate(UserHeartRate lastRunHeartRate) {
        this.lastRunHeartRate = lastRunHeartRate;
    }

    public UserHeartRate getLastSkipRopeHeartRate() {
        return lastSkipRopeHeartRate;
    }

    public void setLastSkipRopeHeartRate(UserHeartRate lastSkipRopeHeartRate) {
        this.lastSkipRopeHeartRate = lastSkipRopeHeartRate;
    }

    public double getConsumeFatSum() {
        return consumeFatSum;
    }

    public void setConsumeFatSum(double consumeFatSum) {
        this.consumeFatSum = consumeFatSum;
    }
}
