package com.fitmix.sdk.model.api.bean;

import java.util.List;

public class VoicePackageInfo extends BaseBean {
    private List<VoicesBean> voices;

    public List<VoicesBean> getVoices() {
        return voices;
    }

    public void setVoices(List<VoicesBean> voices) {
        this.voices = voices;
    }

    public static class VoicesBean {
        /**
         * addTime : 1505372337206
         * coverLink : http://yyssb.ifitmix.com/2016/017683368e35453989c5f9e94b0ac35e.png
         * des : 标准女声英文
         * iconLink : http://yyssb.ifitmix.com/2015/729da02206914a75b9442cc43e356135.jpg
         * id : 1
         * status : 1
         * tagList : ["林俊杰","大明星"]
         * title : 标准女声英文
         */

        private long addTime;
        private String coverLink;
        private String des;
        private String iconLink;
        private int id;
        private int status;
        private String title;
        private List<String> tagList;

        private String fileLink;
        private int fileType;
        private String size;
        private String dirName;
        private int version;

        public int getVersion() {
            return version;
        }

        public void setVersion(int version) {
            this.version = version;
        }

        public int getFileType() {
            return fileType;
        }

        public void setFileType(int fileType) {
            this.fileType = fileType;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getDirName() {
            return dirName;
        }

        public void setDirName(String dirName) {
            this.dirName = dirName;
        }

        public String getFileLink() {
            return fileLink;
        }

        public void setFileLink(String fileLink) {
            this.fileLink = fileLink;
        }

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public String getCoverLink() {
            return coverLink;
        }

        public void setCoverLink(String coverLink) {
            this.coverLink = coverLink;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getIconLink() {
            return iconLink;
        }

        public void setIconLink(String iconLink) {
            this.iconLink = iconLink;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getTagList() {
            return tagList;
        }

        public void setTagList(List<String> tagList) {
            this.tagList = tagList;
        }
    }

}
