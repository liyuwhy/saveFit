package com.fitmix.sdk.model.api.bean;

/**
 * 上传静息心率记录返回
 */
public class AddRestHeartRateRecord extends BaseBean {

    /**
     * detectTime : 1475140957
     */

    private long detectTime;

    public long getDetectTime() {
        return detectTime;
    }

    public void setDetectTime(long detectTime) {
        this.detectTime = detectTime;
    }
}
