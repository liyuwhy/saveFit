package com.fitmix.sdk.model.api.bean;

/**
 * 分享跑步记录接口(user-run-share/add-new.json),返回的结果
 */
public class RunRecordShare extends BaseBean {

    /**
     * share : http://appt.igeekery.com:80/user-run-share/share-new.htm?startTime=1450350946000&uid=27
     */

    private String share;

    public void setShare(String share) {
        this.share = share;
    }

    public String getShare() {
        return share;
    }
}
