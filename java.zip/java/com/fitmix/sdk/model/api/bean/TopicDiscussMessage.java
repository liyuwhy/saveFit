package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.TopicDiscuss;

import java.util.List;

/**
 * 获取与自己相关的最新话题讨论消息(/my/new/discuss/msg.json)接口返回的结果
 */

public class TopicDiscussMessage extends BaseBean {

    private List<TopicDiscuss> discuss;

    public List<TopicDiscuss> getDiscuss() {
        return discuss;
    }

    public void setDiscuss(List<TopicDiscuss> discuss) {
        this.discuss = discuss;
    }
}
