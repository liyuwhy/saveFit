package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.TopicAnswer;

/**
 * 根据话题答案编号获取话题答案(/theme/answer/get.json)接口返回的结果
 */

public class TopicAnswerById extends BaseBean {

    /**
     * addTime : 1501472114899
     * avatar : http://yyssb.ifitmix.com/1002/44e369673cdd4f5b99405e272753fdde.jpg
     * categoryId : 5
     * clickNum : 0
     * content : setUploadStatus(true);<br><img src="http://yyssb.ifitmix.com/1003/e75cdc45dfa34d7b8d87d14ddb4d2d47.jpg"><br><br>
     * id : 58
     * isConfirmed : 1
     * isReply : 1
     * name : Barnaby
     * parentThemeId : 6
     * signature : Android is awesome.
     * taoLunNum : 37
     * themeType : 2
     * uid : 27
     * upNum : 0
     * upUserIds : []
     */

    private TopicAnswer answer;

    public TopicAnswer getAnswer() {
        return answer;
    }

    public void setAnswer(TopicAnswer answer) {
        this.answer = answer;
    }

}
