package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.PushMessageBody;

import java.util.List;

/**
 * 登录接口login.json返回的结果
 */
public class Login extends BaseBean {

    private PushMessageBody bodys;//随登录信息附带的消息体
    private User user;
    private int dayNum;//运动天数,用于图片分享
    private UserRunStatistics userRunStatistics;
    /**
     * collectIds : [485,469,392,589,741]
     * user : {"age":24,"avatar":"http://yyssb.ifitmix.com/1002/f896b9264a0b489ea3fbd4ede1a17882.jpg","calorie":15079,"distance":468660,"email":"398135219@qq.com","gender":1,"height":170,"id":27,"lastRun":{"addTime":1463645994408,"bpm":28,"bpmMatch":20,"calorie":12,"detail":"1003/58038afc45b44892b55afe1f62d2436f.json","distance":513,"endLat":22.522549,"endLng":113.937204,"endTime":1463630412783,"id":459834,"locationType":1,"mark":28.000000000000004,"model":1,"runTime":444427,"startLat":22.52240071614583,"startLng":113.93809163411458,"startTime":1463629968000,"state":1,"step":208,"stepDetail":"2004/f2508629552e44debebf4917eeddeb95.step","type":1,"uid":27,"updateTime":1463645994408,"userBpmMatch":80},"loginType":1,"name":"Barnaby","password":"123456","runTime":4704,"signature":"联想","state":1,"step":279903,"type":1,
     * "userRealInfo":{"age":29,"bloodType":"O 型","city":"深圳市","clothesSize":"L 码","country":"中国","detail":"滨海大道三诺大厦11楼蓝筹科技","email":"398135219@qq.com","emergencyName":"朱林清","emergencyPhone":"15712166807","gender":1,"idCard":"431026198711040019","mobilePhone":"15712166807","name":"朱丹","region":"广东省"},"weight":55}
     */

    private List<Integer> collectIds;

    public void setUser(User user) {
        this.user = user;
    }

    public void setCollectIds(List<Integer> collectIds) {
        this.collectIds = collectIds;
    }

    public User getUser() {
        return user;
    }

    public PushMessageBody getBodys() {
        return bodys;
    }

    public void setBodys(PushMessageBody bodys) {
        this.bodys = bodys;
    }

    public List<Integer> getCollectIds() {
        return collectIds;
    }

    public UserRunStatistics getUserRunStatistics() {
        return userRunStatistics;
    }

    public void setUserRunStatistics(UserRunStatistics userRunStatistics) {
        this.userRunStatistics = userRunStatistics;
    }

    public int getDayNum() {
        return dayNum;
    }

    public void setDayNum(int dayNum) {
        this.dayNum = dayNum;
    }

}
