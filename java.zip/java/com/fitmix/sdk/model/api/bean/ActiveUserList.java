package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.ActiveUser;

import java.util.List;

/**
 * 获取活跃用户的结果
 */
public class ActiveUserList extends BaseBean {
    /**
     * avatar : http://yyssb.ifitmix.com/1002/08621b854e204ee1897f7859c784af60.jpg
     * id : 5
     * name : fanny
     */
    private List<ActiveUser> activeUser;

    public List<ActiveUser> getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(List<ActiveUser> activeUser) {
        this.activeUser = activeUser;
    }

}
