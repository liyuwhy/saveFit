package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.model.api.ApiUtils;

/**
 * 完成任务接口(task-finish.json),返回的结果
 */

public class FinishTask extends BaseBean {


    /**
     * addTime : 1480922822930
     * aid : 8783
     * coin : 10
     * description : 完成-每日签到任务
     * flowType : 0
     * id : 61381
     * modifyTime : 1480922822930
     * uid : 27
     */

    private AccountFlowEntity accountFlow;

    public AccountFlowEntity getAccountFlow() {
        return accountFlow;
    }

    public void setAccountFlow(AccountFlowEntity accountFlow) {
        this.accountFlow = accountFlow;
    }

    public static class AccountFlowEntity {
        private long addTime;//完成时间
        private int aid;
        private int coin;//完成任务奖励金币数量
        private String description;//任务描述
        private int flowType;
        private int id;
        private long modifyTime;
        private int uid;//用户uid

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getAid() {
            return aid;
        }

        public void setAid(int aid) {
            this.aid = aid;
        }

        public int getCoin() {
            return coin;
        }

        public void setCoin(int coin) {
            this.coin = coin;
        }

        public String getDescription() {
            if( !ApiUtils.isZhLanguage() &&description != null && description.contains("完成-每日签到任务")){
                return "Complete - daily check-in task";
            }
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getFlowType() {
            return flowType;
        }

        public void setFlowType(int flowType) {
            this.flowType = flowType;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public long getModifyTime() {
            return modifyTime;
        }

        public void setModifyTime(long modifyTime) {
            this.modifyTime = modifyTime;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }
}
