package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取用户通知列表(/get/user/notice.json)接口返回的结果
 */

public class NoticeFragmentListBean {

    /**
     * notices : [{"addTime":1511779495897,"fromUser":{"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"},"id":142305,"msgBody":{"answerId":"553","discussId":"355","fromUid":"3901312","targetUid":"1340266","content":"太阳花更好"},"selectChannel":"21","status":0}]
     * st : 1511779506175
     * code : 0
     * k : ccb317d86f17438ca998e1beaca371c5
     */

    private long st;
    private int code;
    private String k;
    private List<NoticesBean> notices;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public List<NoticesBean> getNotices() {
        return notices;
    }

    public void setNotices(List<NoticesBean> notices) {
        this.notices = notices;
    }

    public static class NoticesBean {
        /**
         * addTime : 1511779495897
         * fromUser : {"avatar":"http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg","id":3901312,"name":"运动爱好者"}
         * id : 142305
         * msgBody : {"answerId":"553","discussId":"355","fromUid":"3901312","targetUid":"1340266","content":"太阳花更好"}
         * selectChannel : 21
         * status : 0
         */

        private long addTime;
        private FromUserBean fromUser;
        private int id;
        private MsgBodyBean msgBody;
        private String selectChannel;
        private int status;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public FromUserBean getFromUser() {
            return fromUser;
        }

        public void setFromUser(FromUserBean fromUser) {
            this.fromUser = fromUser;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public MsgBodyBean getMsgBody() {
            return msgBody;
        }

        public void setMsgBody(MsgBodyBean msgBody) {
            this.msgBody = msgBody;
        }

        public String getSelectChannel() {
            return selectChannel;
        }

        public void setSelectChannel(String selectChannel) {
            this.selectChannel = selectChannel;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public static class FromUserBean {
            /**
             * avatar : http://yyssb.ifitmix.com/1002/4caa7fc635114e97a535cde660386f80.jpg
             * id : 3901312
             * name : 运动爱好者
             */

            private String avatar;
            private int id;
            private String name;

            public String getAvatar() {
                return avatar;
            }

            public void setAvatar(String avatar) {
                this.avatar = avatar;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }
        }

        public static class MsgBodyBean {
            /**
             * answerId : 553
             * discussId : 355
             * fromUid : 3901312
             * targetUid : 1340266
             * content : 太阳花更好
             * themeId:555
             */

            private String answerId;
            private String discussId;
            private String fromUid;
            private String targetUid;
            private String content;
            private String themeId;

            public String getThemeId() {
                return themeId;
            }

            public void setThemeId(String themeId) {
                this.themeId = themeId;
            }

            public String getAnswerId() {
                return answerId;
            }

            public void setAnswerId(String answerId) {
                this.answerId = answerId;
            }

            public String getDiscussId() {
                return discussId;
            }

            public void setDiscussId(String discussId) {
                this.discussId = discussId;
            }

            public String getFromUid() {
                return fromUid;
            }

            public void setFromUid(String fromUid) {
                this.fromUid = fromUid;
            }

            public String getTargetUid() {
                return targetUid;
            }

            public void setTargetUid(String targetUid) {
                this.targetUid = targetUid;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }
    }
}
