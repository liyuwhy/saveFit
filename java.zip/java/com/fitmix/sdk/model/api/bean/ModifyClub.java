package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Club;

public class ModifyClub extends BaseBean {
    private Club club;

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }
}
