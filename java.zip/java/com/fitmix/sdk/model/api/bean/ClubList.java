package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Club;

import java.util.List;

/**
 * 获取俱乐部列表的结果
 */
public class ClubList extends BaseBean {

    private List<Club> list;

    public List<Club> getList() {
        return list;
    }

    public void setList(List<Club> list) {
        this.list = list;
    }
}
