package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.UserHeartRate;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 从后台服务器获取用户历史跑步记录(history-run.json)返回的结果
 */
public class SkipRecordList extends BaseBean {

    /**
     * lastAddTime : 1469618893014
     * new : [{"addTime":1469618893014,"bpm":0,"calorie":37,"endTime":1469618864429,"heartRate":0,"id":973843,"runTime":46605,"skipDetail":"http://yyssb.ifitmix.com/2100/85a9ed44ca1a4a36b017ac0775b29d1c.skip","skipNum":181,"startTime":1469618817824,"state":1,"type":2,"uid":315798,"updateTime":1469618893014},{"addTime":1469527986221,"bpm":0,"calorie":1,"endTime":1469527982440,"heartRate":0,"id":965404,"runTime":16285,"skipDetail":"http://yyssb.ifitmix.com/2100/aae751a5a43b457bb4efd4cafce9fe4a.skip","skipNum":31,"startTime":1469527966155,"state":1,"type":2,"uid":315798,"updateTime":1469527986221},{"addTime":1469527735097,"bpm":0,"calorie":1,"endTime":1469527730236,"heartRate":0,"id":965387,"runTime":19604,"skipDetail":"http://yyssb.ifitmix.com/2100/ff2ee119da83405082daee948229ef20.skip","skipNum":26,"startTime":1469527710632,"state":1,"type":2,"uid":315798,"updateTime":1469527735097},{"addTime":1469527410721,"bpm":0,"calorie":1,"endTime":1469527406870,"heartRate":0,"id":965368,"runTime":16135,"skipDetail":"http://yyssb.ifitmix.com/2100/50afa53a85134f9486d1b34925645708.skip","skipNum":31,"startTime":1469527390735,"state":1,"type":2,"uid":315798,"updateTime":1469527410721},{"addTime":1469527212575,"bpm":0,"calorie":1,"endTime":1469527207919,"heartRate":0,"id":965342,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/7dd982b1d54741399f512ce7409dba4b.skip","skipNum":38,"startTime":1469527180630,"state":1,"type":2,"uid":315798,"updateTime":1469527212575},{"addTime":1469525029573,"bpm":0,"calorie":1,"endTime":1469525017193,"heartRate":0,"id":965190,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/48ab99180143406f856c3b5b723503b3.skip","skipNum":158,"startTime":1469524958522,"state":1,"type":2,"uid":315798,"updateTime":1469525029573},{"addTime":1469523977139,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":965131,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/7a912190ee744f8f93f852ae34eb79fc.skip","skipNum":0,"startTime":1469523935056,"state":1,"type":2,"uid":315798,"updateTime":1469523977139},{"addTime":1469519996011,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":964953,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/e091366cb1dc4e548850898979afeda7.skip","skipNum":0,"startTime":1469519959442,"state":1,"type":2,"uid":315798,"updateTime":1469519996011},{"addTime":1469517671088,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":964861,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/ce1fa92126574b4986279f2378b8b998.skip","skipNum":0,"startTime":1469517510331,"state":1,"type":2,"uid":315798,"updateTime":1469517671088},{"addTime":1469517284536,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":964848,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/7fc8ebb197fa4d3faae52b45cdaf335d.skip","skipNum":0,"startTime":1469517225683,"state":1,"type":2,"uid":315798,"updateTime":1469517284536},{"addTime":1469516820561,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":964830,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/d0552381e731470a8abb6ea3aa8aec4a.skip","skipNum":0,"startTime":1469516758089,"state":1,"type":2,"uid":315798,"updateTime":1469516820561},{"addTime":1469513618930,"bpm":0,"calorie":1,"endTime":0,"heartRate":0,"id":964706,"runTime":0,"skipDetail":"http://yyssb.ifitmix.com/2100/2c702690846c4f1b9a8df1902657408c.skip","skipNum":0,"startTime":1469513535258,"state":1,"type":2,"uid":315798,"updateTime":1469513618930}]
     * remove : []
     */

    private long lastAddTime;
    /**
     * addTime : 1469618893014
     * bpm : 0
     * calorie : 37
     * endTime : 1469618864429
     * heartRate : 0
     * id : 973843
     * runTime : 46605
     * skipDetail : http://yyssb.ifitmix.com/2100/85a9ed44ca1a4a36b017ac0775b29d1c.skip
     * skipNum : 181
     * startTime : 1469618817824
     * state : 1
     * type : 2
     * uid : 315798
     * updateTime : 1469618893014
     */

    @SerializedName("new")
    private List<SkipRecord> newX;
    private List<SkipRecord> remove;

    public long getLastAddTime() {
        return lastAddTime;
    }

    public void setLastAddTime(long lastAddTime) {
        this.lastAddTime = lastAddTime;
    }

    public List<SkipRecord> getNewX() {
        return newX;
    }

    public void setNewX(List<SkipRecord> newX) {
        this.newX = newX;
    }

    public List<SkipRecord> getRemove() {
        return remove;
    }

    public void setRemove(List<SkipRecord> remove) {
        this.remove = remove;
    }

    public static class SkipRecord {
        private long addTime;
        private int bpm;
        private int calorie;
        private long endTime;
        private int id;
        private int runTime;
        private String skipDetail;
        private int skipNum;
        private long startTime;
        private int state;
        private int type;
        private int uid;
        private long updateTime;
        private UserHeartRate heartRate;//心率数据，由UserHeartRate类转为的json字符串

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getBpm() {
            return bpm;
        }

        public void setBpm(int bpm) {
            this.bpm = bpm;
        }

        public int getCalorie() {
            return calorie;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public long getEndTime() {
            return endTime;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public UserHeartRate getHeartRate() {
            return heartRate;
        }

        public void setHeartRate(UserHeartRate heartRate) {
            this.heartRate = heartRate;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getRunTime() {
            return runTime;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public String getSkipDetail() {
            return skipDetail;
        }

        public void setSkipDetail(String skipDetail) {
            this.skipDetail = skipDetail;
        }

        public int getSkipNum() {
            return skipNum;
        }

        public void setSkipNum(int skipNum) {
            this.skipNum = skipNum;
        }

        public long getStartTime() {
            return startTime;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }
    }
}
