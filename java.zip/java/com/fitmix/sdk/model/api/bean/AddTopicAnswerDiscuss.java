package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.TopicDiscuss;

/**
 * 添加话题答案评论(/theme/add/discuss.json)接口返回的结果
 */
public class AddTopicAnswerDiscuss extends BaseBean {


    /**
     * addTime : 1501472511006
     * avatar : 1002/44e369673cdd4f5b99405e272753fdde.jpg
     * content : 2
     * id : 80
     * themeId : 58
     * uid : 27
     * userName : Barnaby
     */

    private TopicDiscuss discuss;

    public TopicDiscuss getDiscuss() {
        return discuss;
    }

    public void setDiscuss(TopicDiscuss discuss) {
        this.discuss = discuss;
    }

}
