package com.fitmix.sdk.model.api.bean;

import java.io.Serializable;


/**
 * APP初始化接口(init.json)返回结果中的弹窗广告
 */

public class Announcements implements Serializable {

    /**
     * bTime : 1507791600000
     * body : http://baidu.com
     * displayNum : 200
     * eTime : 1508774400000
     * id : 9
     * imgLink : http://yyssb.ifitmix.com/2014/618be52678764cab9c6f35358b758d9a.jpeg
     * type : 2
     */

    private long bTime;//
    private String body;//内容,跳转类型为2时是网址,为3时是话题编号,为4时是MIX编号,为5时是赛事编号
    private int displayNum;//需要展示的次数
    private long eTime;//
    private int id;//
    private String imgLink;//弹窗图片网址
    private int type;//弹窗跳转类型,2:网页,3:话题,4:MIX音乐,5:赛事

    public Announcements(long bTime, String body, int displayNum, long eTime, int id, String imgLink, int type) {
        this.bTime = bTime;
        this.body = body;
        this.displayNum = displayNum;
        this.eTime = eTime;
        this.id = id;
        this.imgLink = imgLink;
        this.type = type;
    }

    public long getBTime() {
        return bTime;
    }

    public void setBTime(long bTime) {
        this.bTime = bTime;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public int getDisplayNum() {
        return displayNum;
    }

    public void setDisplayNum(int displayNum) {
        this.displayNum = displayNum;
    }

    public long getETime() {
        return eTime;
    }

    public void setETime(long eTime) {
        this.eTime = eTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImgLink() {
        return imgLink;
    }

    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
