package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.watch.bean.WatchSportLog;

/**
 * 上传手表运动记录(/user-run/add/watch/run.json)返回的bean类
 */

public class UserSportsWatch extends BaseBean {


    /**
     * lastAddTime : 1517897664047
     * userRun : {"addTime":1517897664047,"calorie":124,"consumeFat":5,"deviceType":2,"endTime":1517857029000,"runTime":626000,"startTime":1517856403000,"state":1,"type":3,"uid":27,"updateTime":1517897664047,"watch":{"avgSportHR":157,"maxHR":198,"startPressure":105680,"totalSteps":806,"sportTime":590,"lactateThreshold":0,"startAltitude":190.1,"restHR":60,"ridePower":0,"totalDown":2927,"swimPoolLength":0,"startTemperature":19.559998,"maxPace":412,"startTime":1517856403000,"totalDistance":994,"totalCalorie":124,"pause_detail":[{"duration":36,"time":252}],"maxFrequency":125,"sportType":0,"swimStyle":0,"swimTrips":0,"maxSportHR":194,"totalUp":2939,"runPower":0,"fatBurst":5,"sportDuration":626,"hrStatistics":[{"time":162},{"time":24},{"time":128},{"time":160},{"time":52}],"troughAltitude":-14.5,"peakAltitude":-1.5},"watchZipFile":"1016/cc35e079446c4a35b7b5da6bbc22bc50.zip"}
     */

    private long lastAddTime;
    private UserRunBean userRun;

    public long getLastAddTime() {
        return lastAddTime;
    }

    public void setLastAddTime(long lastAddTime) {
        this.lastAddTime = lastAddTime;
    }

    public UserRunBean getUserRun() {
        return userRun;
    }

    public void setUserRun(UserRunBean userRun) {
        this.userRun = userRun;
    }

    public static class UserRunBean {
        /**
         * addTime : 1517897664047
         * calorie : 124
         * consumeFat : 5.0
         * deviceType : 2
         * endTime : 1517857029000
         * runTime : 626000
         * startTime : 1517856403000
         * state : 1
         * type : 3
         * uid : 27
         * updateTime : 1517897664047
         * watch : {"avgSportHR":157,"maxHR":198,"startPressure":105680,"totalSteps":806,"sportTime":590,"lactateThreshold":0,"startAltitude":190.1,"restHR":60,"ridePower":0,"totalDown":2927,"swimPoolLength":0,"startTemperature":19.559998,"maxPace":412,"startTime":1517856403000,"totalDistance":994,"totalCalorie":124,"pause_detail":[{"duration":36,"time":252}],"maxFrequency":125,"sportType":0,"swimStyle":0,"swimTrips":0,"maxSportHR":194,"totalUp":2939,"runPower":0,"fatBurst":5,"sportDuration":626,"hrStatistics":[{"time":162},{"time":24},{"time":128},{"time":160},{"time":52}],"troughAltitude":-14.5,"peakAltitude":-1.5}
         * watchZipFile : 1016/cc35e079446c4a35b7b5da6bbc22bc50.zip
         */

        private long addTime;
        private int calorie;
        private double consumeFat;
        private int deviceType;
        private long endTime;
        private int runTime;
        private long startTime;
        private int state;
        private int type;
        private int uid;
        private long updateTime;
        private WatchSportLog watch;
        private String watchZipFile;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getCalorie() {
            return calorie;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public double getConsumeFat() {
            return consumeFat;
        }

        public void setConsumeFat(double consumeFat) {
            this.consumeFat = consumeFat;
        }

        public int getDeviceType() {
            return deviceType;
        }

        public void setDeviceType(int deviceType) {
            this.deviceType = deviceType;
        }

        public long getEndTime() {
            return endTime;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public int getRunTime() {
            return runTime;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public long getStartTime() {
            return startTime;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }

        public WatchSportLog getWatch() {
            return watch;
        }

        public void setWatch(WatchSportLog watch) {
            this.watch = watch;
        }

        public String getWatchZipFile() {
            return watchZipFile;
        }

        public void setWatchZipFile(String watchZipFile) {
            this.watchZipFile = watchZipFile;
        }
    }


}
