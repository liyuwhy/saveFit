package com.fitmix.sdk.model.api.bean;


import com.fitmix.sdk.view.bean.ClubMessage;

import java.util.List;

/**
 * 获取俱乐部留言列表的结果
 */
public class ClubMessageList extends BaseBean {

    /**
     * addTime : 1463723973456
     * clubId : 527
     * content :   发送留言
     * id : 1929
     * uid : 33
     * user : {"avatar":"http://wx.qlogo.cn/mmopen/DpDWxM6CCag4kUvW8g27YI9nN0HnVr0RKX00JWZ9vocuZhA8Y7AtUiaCT5HIDc7hxxwwBGY5GnVlicTibh2UqnRHX9ial5RiaecB1/0","id":33,"name":"胡宜平"}
     */

    private List<ClubMessage> page;

    public List<ClubMessage> getPage() {
        return page;
    }

    public void setPage(List<ClubMessage> page) {
        this.page = page;
    }

}
