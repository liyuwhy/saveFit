package com.fitmix.sdk.model.api.bean;

/**
 * 登录接口login.json返回结果中的userRealInfo实体,表示用户真实信息
 */
public class UserRealInfo {

    /**
     * age : 29
     * bloodType : O 型
     * city : 深圳市
     * clothesSize : L 码
     * country : 中国
     * detail : 滨海大道三诺大厦11楼蓝筹科技
     * email : 398135219@qq.com
     * emergencyName : 朱林清
     * emergencyPhone : 15712166807
     * gender : 1
     * idCard : 431026198711040019
     * mobilePhone : 15712166807
     * name : 朱丹
     * region : 广东省
     */
    /**
     * 年龄
     */
    private int age;
    /**
     * 血型
     */
    private String bloodType;
    /**
     * 城市
     */
    private String city;
    /**
     * 衣服尺码
     */
    private String clothesSize;
    /**
     * 国籍
     */
    private String country;
    /**
     * 详细地址
     */
    private String detail;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 紧急联系人姓名
     */
    private String emergencyName;
    /**
     * 紧急联系人手机
     */
    private String emergencyPhone;
    /**
     * 性别,1:男,2:女
     */
    private int gender;
    /**
     * 身份证号码
     */
    private String idCard;
    /**
     * 手机号码
     */
    private String mobilePhone;
    /**
     * 真实姓名
     */
    private String name;
    /**
     * 地区
     */
    private String region;

    public void setAge(int age) {
        this.age = age;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setClothesSize(String clothesSize) {
        this.clothesSize = clothesSize;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEmergencyName(String emergencyName) {
        this.emergencyName = emergencyName;
    }

    public void setEmergencyPhone(String emergencyPhone) {
        this.emergencyPhone = emergencyPhone;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public int getAge() {
        return age;
    }

    public String getBloodType() {
        return bloodType;
    }

    public String getCity() {
        return city;
    }

    public String getClothesSize() {
        return clothesSize;
    }

    public String getCountry() {
        return country;
    }

    public String getDetail() {
        return detail;
    }

    public String getEmail() {
        return email;
    }

    public String getEmergencyName() {
        return emergencyName;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    /**
     * 获取用户性别,1:男,2:女
     */
    public int getGender() {
        return gender;
    }

    public String getIdCard() {
        return idCard;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public String getName() {
        return name;
    }

    public String getRegion() {
        return region;
    }
}
