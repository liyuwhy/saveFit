package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取用户金币记录明细接口(accountFlow.json),返回的实体
 */

public class AccountFlow extends BaseBean {


    /**
     * endRow : 1
     * firstPage : 1
     * hasNextPage : false
     * hasPreviousPage : false
     * isFirstPage : true
     * isLastPage : true
     * lastPage : 1
     * list : [{"addTime":1480588104987,"aid":8783,"coin":45,"description":"达到-高级跑者**","flowType":0,"id":11357,"modifyTime":1480588104987},{"addTime":1480922822930,"aid":8783,"coin":10,"description":"完成-每日签到任务","flowType":0,"id":61381,"modifyTime":1480922822930}]
     * navigatePages : 8
     * navigatepageNums : [1]
     * nextPage : 0
     * pageNum : 1
     * pageSize : 2
     * pages : 1
     * prePage : 0
     * size : 2
     * startRow : 0
     * total : 2
     */

    private PageEntity page;

    public PageEntity getPage() {
        return page;
    }

    public void setPage(PageEntity page) {
        this.page = page;
    }

    public static class PageEntity {
        private int endRow;
        private int firstPage;
        private boolean hasNextPage;
        private boolean hasPreviousPage;
        private boolean isFirstPage;
        private boolean isLastPage;
        private int lastPage;
        private int navigatePages;
        private int nextPage;
        private int pageNum;
        private int pageSize;
        private int pages;
        private int prePage;
        private int size;
        private int startRow;
        private int total;
        /**
         * addTime : 1480588104987
         * aid : 8783
         * coin : 45
         * description : 达到-高级跑者**
         * flowType : 0
         * id : 11357
         * modifyTime : 1480588104987
         */

        private List<CoinReward> list;
        private List<Integer> navigatepageNums;

        public int getEndRow() {
            return endRow;
        }

        public void setEndRow(int endRow) {
            this.endRow = endRow;
        }

        public int getFirstPage() {
            return firstPage;
        }

        public void setFirstPage(int firstPage) {
            this.firstPage = firstPage;
        }

        public boolean isHasNextPage() {
            return hasNextPage;
        }

        public void setHasNextPage(boolean hasNextPage) {
            this.hasNextPage = hasNextPage;
        }

        public boolean isHasPreviousPage() {
            return hasPreviousPage;
        }

        public void setHasPreviousPage(boolean hasPreviousPage) {
            this.hasPreviousPage = hasPreviousPage;
        }

        public boolean isIsFirstPage() {
            return isFirstPage;
        }

        public void setIsFirstPage(boolean isFirstPage) {
            this.isFirstPage = isFirstPage;
        }

        public boolean isIsLastPage() {
            return isLastPage;
        }

        public void setIsLastPage(boolean isLastPage) {
            this.isLastPage = isLastPage;
        }

        public int getLastPage() {
            return lastPage;
        }

        public void setLastPage(int lastPage) {
            this.lastPage = lastPage;
        }

        public int getNavigatePages() {
            return navigatePages;
        }

        public void setNavigatePages(int navigatePages) {
            this.navigatePages = navigatePages;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNum() {
            return pageNum;
        }

        public void setPageNum(int pageNum) {
            this.pageNum = pageNum;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getPages() {
            return pages;
        }

        public void setPages(int pages) {
            this.pages = pages;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getStartRow() {
            return startRow;
        }

        public void setStartRow(int startRow) {
            this.startRow = startRow;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<CoinReward> getList() {
            return list;
        }

        public void setList(List<CoinReward> list) {
            this.list = list;
        }

        public List<Integer> getNavigatepageNums() {
            return navigatepageNums;
        }

        public void setNavigatepageNums(List<Integer> navigatepageNums) {
            this.navigatepageNums = navigatepageNums;
        }

//        public static class CoinRecordEntity {
//            private long addTime;
//            private int aid;
//            private int coin;
//            private String description;
//            private int flowType;
//            private int id;
//            private long modifyTime;
//
//            public long getAddTime() {
//                return addTime;
//            }
//
//            public void setAddTime(long addTime) {
//                this.addTime = addTime;
//            }
//
//            public int getAid() {
//                return aid;
//            }
//
//            public void setAid(int aid) {
//                this.aid = aid;
//            }
//
//            public int getCoin() {
//                return coin;
//            }
//
//            public void setCoin(int coin) {
//                this.coin = coin;
//            }
//
//            public String getDescription() {
//                return description;
//            }
//
//            public void setDescription(String description) {
//                this.description = description;
//            }
//
//            public int getFlowType() {
//                return flowType;
//            }
//
//            public void setFlowType(int flowType) {
//                this.flowType = flowType;
//            }
//
//            public int getId() {
//                return id;
//            }
//
//            public void setId(int id) {
//                this.id = id;
//            }
//
//            public long getModifyTime() {
//                return modifyTime;
//            }
//
//            public void setModifyTime(long modifyTime) {
//                this.modifyTime = modifyTime;
//            }
//        }
    }
}
