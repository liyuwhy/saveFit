package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.TopicAnswer;

/**
 * 添加话题答案(/theme/add/answer.json)接口返回的结果
 */
public class AddTopicAnswer extends BaseBean {

    /**
     * addTime : 1500022650274
     * avatar : 1002/44e369673cdd4f5b99405e272753fdde.jpg
     * categoryId : 5
     * clickNum : 0
     * content : %E8%BF%98%E6%9C%89%E5%BE%88%E9%95%BF%E7%9A%84%E8%B7%AF%E8%A6%81%E8%B5%B0
     * id : 41
     * isConfirmed : 1
     * isReply : 1
     * parentThemeId : 40
     * themeType : 2
     * uid : 27
     * upNum : 0
     */

    private TopicAnswer theme;

    public TopicAnswer getTheme() {
        return theme;
    }

    public void setTheme(TopicAnswer theme) {
        this.theme = theme;
    }

}
