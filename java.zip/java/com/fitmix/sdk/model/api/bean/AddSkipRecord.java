package com.fitmix.sdk.model.api.bean;

/**
 * 添加跳绳运动信息接口返回的结果
 */
public class AddSkipRecord extends BaseBean {

    /**
     * lastAddTime : 1469527735097
     * userSkipRope : {"addTime":1469527735097,"bpm":0,"calorie":1,"endTime":1469527730236,"heartRate":0,"id":965387,"runTime":19604,"skipDetail":"2100/ff2ee119da83405082daee948229ef20.skip","skipNum":26,"startTime":1469527710632,"state":1,"type":2,"uid":315798,"updateTime":1469527735097}
     */

    private long lastAddTime;
    /**
     * addTime : 1469527735097
     * bpm : 0
     * calorie : 1
     * endTime : 1469527730236
     * heartRate : 0
     * id : 965387
     * runTime : 19604
     * skipDetail : 2100/ff2ee119da83405082daee948229ef20.skip
     * skipNum : 26
     * startTime : 1469527710632
     * state : 1
     * type : 2
     * uid : 315798
     * updateTime : 1469527735097
     */

    private UserSkipRopeBean userSkipRope;

    public long getLastAddTime() {
        return lastAddTime;
    }

    public void setLastAddTime(long lastAddTime) {
        this.lastAddTime = lastAddTime;
    }

    public UserSkipRopeBean getUserSkipRope() {
        return userSkipRope;
    }

    public void setUserSkipRope(UserSkipRopeBean userSkipRope) {
        this.userSkipRope = userSkipRope;
    }

    public static class UserSkipRopeBean {
        private long addTime;
        private int bpm;
        private int calorie;
        private long endTime;
        private int heartRate;
        private int id;
        private int runTime;
        private String skipDetail;
        private int skipNum;
        private long startTime;
        private int state;
        private int type;
        private int uid;
        private long updateTime;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getBpm() {
            return bpm;
        }

        public void setBpm(int bpm) {
            this.bpm = bpm;
        }

        public int getCalorie() {
            return calorie;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public long getEndTime() {
            return endTime;
        }

        public void setEndTime(long endTime) {
            this.endTime = endTime;
        }

        public int getHeartRate() {
            return heartRate;
        }

        public void setHeartRate(int heartRate) {
            this.heartRate = heartRate;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getRunTime() {
            return runTime;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public String getSkipDetail() {
            return skipDetail;
        }

        public void setSkipDetail(String skipDetail) {
            this.skipDetail = skipDetail;
        }

        public int getSkipNum() {
            return skipNum;
        }

        public void setSkipNum(int skipNum) {
            this.skipNum = skipNum;
        }

        public long getStartTime() {
            return startTime;
        }

        public void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public int getState() {
            return state;
        }

        public void setState(int state) {
            this.state = state;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public long getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(long updateTime) {
            this.updateTime = updateTime;
        }
    }
}
