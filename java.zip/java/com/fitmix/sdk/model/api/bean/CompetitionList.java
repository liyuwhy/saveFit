package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.Competition;

import java.util.List;

public class CompetitionList extends BaseBean {
    /**
     * 服务器返回的时间 用来做判断 防止用户修改本地时间
     */
    private long SYSTIME;
    private PageBean page;

    public long getSYSTIME() {
        return SYSTIME;
    }

    public void setSYSTIME(long SYSTIME) {
        this.SYSTIME = SYSTIME;
    }

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public static class PageBean {
        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;

        /**
         * activityBeginTime : 1464710400000
         * activityEndTime : 1475164800000
         * activityFalseNumber : 6311
         * activityMaxNumber : 100000
         * activityMoney : 0
         * addTime : 1464838563804
         * desc : “优”走上海--百万市民健步走
         * endDiffHour : 2593
         * id : 34
         * register : false
         * registerCount : 0
         * releaseStatus : 0
         * signUpBeginTime : 1464710400000
         * signUpEndTime : 1475164800000
         * signUpMode : [1,5,6]
         * signUpModeWitch : 1
         * sort : 4
         * startDiffHour : -311
         * status : 0
         * themeImage : http://yyssb.ifitmix.com/2007/5285a83975fb48f09cebf052797967b5.jpg
         * themeName : “优”走上海--百万市民健步走
         * type : 1
         */

        private List<Competition> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<Competition> getResult() {
            return result;
        }

        public void setResult(List<Competition> result) {
            this.result = result;
        }

        public static class FilterBean {
            private int releaseStatus;
            private int status;

            public int getReleaseStatus() {
                return releaseStatus;
            }

            public void setReleaseStatus(int releaseStatus) {
                this.releaseStatus = releaseStatus;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }
    }
}
