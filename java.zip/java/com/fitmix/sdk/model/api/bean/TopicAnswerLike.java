package com.fitmix.sdk.model.api.bean;

/**
 * 话题答案点赞或取消点赞(/theme/opinion.json)接口返回的结果
 */

public class TopicAnswerLike extends BaseBean {

    /**
     * upNum : 1
     */

    private int upNum;//当前总点赞数

    public int getUpNum() {
        return upNum;
    }

    public void setUpNum(int upNum) {
        this.upNum = upNum;
    }
}
