package com.fitmix.sdk.model.api.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * App 初始化接口init.json返回的结果
 */
public class Init extends BaseBean {

    /**
     * 举例
     * APPLoginQQKey : 1104452331
     * APPLoginWBKey : 1415931559
     * APPLoginWXKey : wx523eacdfe8922b80
     * BAGPayAddress : http://item.jd.com/1912580.html
     * BOLTPayAddress : https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-13723299869.4.FUrGIo&id=528759752172
     * LIGHTPayAddress : http://item.jd.com/1912580.html
     * SHINEPayAddress : https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-13723299869.6.FUrGIo&id=528746026773
     * WATCHPayAddress : http://item.jd.com/1912580.html
     * adverts :  [
     {
     "advertImg": "http://yyssb.ifitmix.com/2011/612cb00bbed347e395810515f967578e.jpg",
     "id": 1,
     "operationType": 1,
     "title": "测试",
     "toUrl": ""
     }
     ]
     * androidUpgradeUrl : http://f.igeekery.com/mix/fitmix_lanchou.apk
     * androidVersion : 30
     * androidVersionIntroduction : 优化内存占用问题,增强稳定性。
     * androidVersionView : V2.0.1
     * dic : [{"id":72,"name":"官网","sort":0,"type":8,"value":0},
     * {"id":73,"name":"应用宝","sort":1,"type":8,"value":1},
     * {"id":74,"name":"360手机助手","sort":2,"type":8,"value":2},
     * {"id":75,"name":"百度手机助手","sort":3,"type":8,"value":3},
     * {"id":76,"name":"小米应用商城","sort":4,"type":8,"value":4},
     * {"id":9,"name":"HOUSE","sort":1,"type":7,"value":1},{"id":10,"name":"EDM","sort":2,"type":7,"value":2},{"id":11,"name":"TRAP","sort":3,"type":7,"value":3},{"id":12,"name":"TECHNO","sort":4,"type":7,"value":4},{"id":13,"name":"TRANCE","sort":5,"type":7,"value":5},{"id":14,"name":"HIP HOP","sort":6,"type":7,"value":6},{"id":16,"name":"POP","sort":7,"type":7,"value":7},{"id":17,"name":"HARD ROCK","sort":8,"type":7,"value":8},{"id":19,"name":"POP PUNK","sort":9,"type":7,"value":9},{"id":20,"name":"INDIE ROCK","sort":10,"type":7,"value":10},{"id":26,"name":"R&B","sort":11,"type":7,"value":11},{"id":27,"name":"DUBSTEP","sort":12,"type":7,"value":12},{"id":28,"name":"FUNKY","sort":13,"type":7,"value":13},{"id":29,"name":"METAL","sort":14,"type":7,"value":14},{"id":31,"name":"POP ROCK","sort":15,"type":7,"value":15},{"id":32,"name":"TECHOUSE","sort":16,"type":7,"value":16},{"id":55,"name":"REGGAE","sort":17,"type":7,"value":17},{"id":56,"name":"CLASSIC POP","sort":18,"type":7,"value":18},{"id":57,"name":"OLDIES","sort":19,"type":7,"value":19},{"id":58,"name":"COUNTRY","sort":20,"type":7,"value":20},{"id":59,"name":"LATIN POP","sort":21,"type":7,"value":21},{"id":60,"name":"FOLK","sort":22,"type":7,"value":22},{"id":61,"name":"ROCK","sort":23,"type":7,"value":23},{"id":62,"name":"PUNK","sort":24,"type":7,"value":24},{"id":63,"name":"BRITPOP","sort":25,"type":7,"value":25},{"id":64,"name":"EMO","sort":26,"type":7,"value":26},{"id":65,"name":"HARDCORE","sort":27,"type":7,"value":27},{"id":66,"name":"GRUNGE","sort":28,"type":7,"value":28},{"id":67,"name":"DRUM&BASS","sort":29,"type":7,"value":29},{"id":68,"name":"DEEP HOUSE","sort":30,"type":7,"value":30},{"id":69,"name":"RAP","sort":31,"type":7,"value":31},{"id":102,"name":"World Music","sort":32,"type":7,"value":32},{"id":103,"name":"Breakbeats","sort":33,"type":7,"value":33},{"id":104,"name":"Electro Swing ","sort":34,"type":7,"value":34},{"id":105,"name":"Glitch hop","sort":35,"type":7,"value":35},{"id":106,"name":"Chillstep","sort":36,"type":7,"value":36},{"id":107,"name":"Goa Trance","sort":37,"type":7,"value":37},{"id":108,"name":"Disco","sort":38,"type":7,"value":38},{"id":109,"name":"Mashup","sort":39,"type":7,"value":39},{"id":110,"name":"Soca","sort":40,"type":7,"value":40},{"id":111,"name":"Reggaeton","sort":41,"type":7,"value":41},{"id":112,"name":"Britpop","sort":42,"type":7,"value":42},{"id":113,"name":"New Wave","sort":43,"type":7,"value":43},{"id":114,"name":"Acid Jazz","sort":44,"type":7,"value":44},{"id":115,"name":"Jazz","sort":45,"type":7,"value":45},{"id":116,"name":"Swing","sort":46,"type":7,"value":46},{"id":117,"name":"Classical","sort":47,"type":7,"value":47},{"id":42,"name":"<30分钟","sort":1,"type":6,"value":1},{"id":43,"name":"30-59分钟","sort":2,"type":6,"value":2},{"id":44,"name":"60-89分钟","sort":3,"type":6,"value":3},{"id":45,"name":"90-119分钟","sort":4,"type":6,"value":4},{"id":46,"name":">=120分钟","sort":5,"type":6,"value":5},{"id":33,"name":"<120","sort":1,"type":5,"value":1},{"id":34,"name":"120-129","sort":2,"type":5,"value":2},{"id":35,"name":"130-139","sort":3,"type":5,"value":3},{"id":36,"name":"140-149","sort":4,"type":5,"value":4},{"id":37,"name":"150-159","sort":5,"type":5,"value":5},{"id":38,"name":"160-169","sort":6,"type":5,"value":6},{"id":39,"name":"170-179","sort":7,"type":5,"value":7},{"id":40,"name":">=180","sort":8,"type":5,"value":8},{"id":21,"name":"kg/cm","sort":1,"type":4,"value":1},{"id":22,"name":"ib/in","sort":2,"type":4,"value":2},{"id":52,"name":"流行","sort":1,"type":3,"value":1},{"id":51,"name":"摇滚","sort":2,"type":3,"value":2},{"id":53,"name":"电子","sort":3,"type":3,"value":3},{"id":54,"name":"嘻哈","sort":4,"type":3,"value":4},{"id":120,"name":"世界音乐","sort":5,"type":3,"value":7},{"id":119,"name":"古典","sort":6,"type":3,"value":6},{"id":118,"name":"爵士","sort":7,"type":3,"value":5},{"id":23,"name":"慢跑","other":{"image":"http://yyssb.ifitmix.com/2002/d10442ceb8784584b1eb1dc8756f5a40.jpg","paceSpeed":"6-9min/km","rhythm":"120-140","desc":"感受汗珠细腻沁出的轻松畅快"},"sort":1,"type":2,"value":3},{"id":7,"name":"中跑","other":{"image":"http://yyssb.ifitmix.com/2002/0900a09ea3b2462b886405145fb77f77.jpg","paceSpeed":"5-6min/km","rhythm":"140-180","desc":"积蓄的能量源源不断地释放\t"},"sort":2,"type":2,"value":2},{"id":6,"name":"快跑","other":{"image":"http://yyssb.ifitmix.com/2002/c5de81d57dc9462f800dd9aa472519f6.jpg","paceSpeed":"3-5min/km","rhythm":"180+","desc":"不断超越 爆发急速力量"},"sort":3,"type":2,"value":1},{"id":24,"name":"健走","other":{"image":"http://yyssb.ifitmix.com/2002/121962d2ce8b44a5b75ccbceb1a67f72.jpg","paceSpeed":"9-12min/km","rhythm":"120-","desc":"健走一种生活态度"},"sort":4,"type":2,"value":4},{"id":47,"name":"热身","other":{"image":"http://yyssb.ifitmix.com/2002/7fffe69971964d8d9cfd225d2ba1b57a.jpg","paceSpeed":"自由","rhythm":"自由","desc":"感受毛孔散发的热量与活力"},"sort":5,"type":2,"value":5},{"id":48,"name":"放松","other":{"image":"http://yyssb.ifitmix.com/2002/6937015a2e3c4ce9950533c9a5831ac3.jpg","paceSpeed":"自由","rhythm":"自由","desc":"放松\t舒张每寸肌肤和筋骨"},"sort":6,"type":2,"value":6},{"id":93,"name":"街舞音乐","other":{"image":"http://yyssb.ifitmix.com/2002/45b6f426e04845e98618f6647ca5d265.jpg","paceSpeed":"自由","rhythm":"自由","desc":"街舞音乐\t释放能量,酣畅淋漓"},"sort":7,"type":2,"value":7},{"id":1,"name":"男","sort":1,"type":1,"value":1},{"id":2,"name":"女","sort":2,"type":1,"value":2}]
     * homeBackgroundImage : http://yyssb.ifitmix.com/1008/6bedb4f2b8e346878f87080a5520ec75.jpg
     * iosUpgradeUrl : itms-services://?action=download-manifest&url=https://dn-igeekery.qbox.me/GEEKERY.plist
     * iosVersion : 4
     * iosVersionIntroduction : 优化内存占用问题,增强稳定性。
     * iosVersionView : 1.1.6
     * startPage:{"backgroundImg":"http://yyssb.ifitmix.com/2010/02400b65dc794e02a3981e43eaeb5cc4.jpg","countdown":2,"id":1,"title":"测试"}}
     */

    /**
     * QQ开发者平台 乐享动APP id
     */
    private String APPLoginQQKey;
    /**
     * 新浪微博开发者平台 乐享动APP id
     */
    private String APPLoginWBKey;
    /**
     * 微信开发者平台 乐享动APP id
     */
    private String APPLoginWXKey;
    private String BAGPayAddress;//运动背包网店地址
    private String BOLTPayAddress;//运动耳机网店地址
    private String LIGHTPayAddress;//灯网店地址
    private String SHINEPayAddress;//发光耳机网店地址
    private String WATCHPayAddress;//运动手表网店地址
    /**
     * Android升级包下载地址
     */
    private String androidUpgradeUrl;
    /**
     * Android升级包版本
     */
    private int androidVersion;
    /**
     * Android升级说明
     */
    private String androidVersionIntroduction;
    private String androidVersionView;
    /**
     * 应用启动页面背景图片
     */
    private String homeBackgroundImage;
    private String iosUpgradeUrl;
    private int iosVersion;
    private String iosVersionIntroduction;
    private String iosVersionView;
    private List<Adverts> adverts;
    private List<Announcements> announcements;

    public List<Announcements> getAnnouncements() {
        return announcements;
    }

    public void setAnnouncements(List<Announcements> announcements) {
        this.announcements = announcements;
    }

    private StartPage startPage;
    /**
     * 运动记录分享基础网址
     */
    private String AppUserRunShareLink;
    /**
     * 运动记录图片分享用的二维码地址
     */
    private String AppDownloadQRCodeLink;

    /**
     * 加密公钥下载地址
     */
    private String keyUrl1;

    /**
     * 话题分享基础网址
     */
    private String AppThemeAnswerShareLink;

    public StartPage getPage() {
        return startPage;
    }

    public void setPage(StartPage page) {
        this.startPage = page;
    }

    /**
     * id : 72
     * name : 官网
     * sort : 0
     * type : 8
     * value : 0
     */

    private List<DicEntity> dic;

    public void setAPPLoginQQKey(String APPLoginQQKey) {
        this.APPLoginQQKey = APPLoginQQKey;
    }

    public void setAPPLoginWBKey(String APPLoginWBKey) {
        this.APPLoginWBKey = APPLoginWBKey;
    }

    public void setAPPLoginWXKey(String APPLoginWXKey) {
        this.APPLoginWXKey = APPLoginWXKey;
    }

    public void setBAGPayAddress(String BAGPayAddress) {
        this.BAGPayAddress = BAGPayAddress;
    }

    public void setBOLTPayAddress(String BOLTPayAddress) {
        this.BOLTPayAddress = BOLTPayAddress;
    }

    public void setLIGHTPayAddress(String LIGHTPayAddress) {
        this.LIGHTPayAddress = LIGHTPayAddress;
    }

    public void setSHINEPayAddress(String SHINEPayAddress) {
        this.SHINEPayAddress = SHINEPayAddress;
    }

    public void setWATCHPayAddress(String WATCHPayAddress) {
        this.WATCHPayAddress = WATCHPayAddress;
    }

    public void setAndroidUpgradeUrl(String androidUpgradeUrl) {
        this.androidUpgradeUrl = androidUpgradeUrl;
    }

    public void setAndroidVersion(int androidVersion) {
        this.androidVersion = androidVersion;
    }

    public void setAndroidVersionIntroduction(String androidVersionIntroduction) {
        this.androidVersionIntroduction = androidVersionIntroduction;
    }

    public void setAndroidVersionView(String androidVersionView) {
        this.androidVersionView = androidVersionView;
    }

    public void setHomeBackgroundImage(String homeBackgroundImage) {
        this.homeBackgroundImage = homeBackgroundImage;
    }

    public void setIosUpgradeUrl(String iosUpgradeUrl) {
        this.iosUpgradeUrl = iosUpgradeUrl;
    }

    public void setIosVersion(int iosVersion) {
        this.iosVersion = iosVersion;
    }

    public void setIosVersionIntroduction(String iosVersionIntroduction) {
        this.iosVersionIntroduction = iosVersionIntroduction;
    }

    public void setIosVersionView(String iosVersionView) {
        this.iosVersionView = iosVersionView;
    }

    public void setAdverts(List<Adverts> adverts) {
        this.adverts = adverts;
    }

    public void setDic(List<DicEntity> dic) {
        this.dic = dic;
    }

    public String getAPPLoginQQKey() {
        return APPLoginQQKey;
    }

    public String getAPPLoginWBKey() {
        return APPLoginWBKey;
    }

    public String getAPPLoginWXKey() {
        return APPLoginWXKey;
    }

    public String getBAGPayAddress() {
        return BAGPayAddress;
    }

    public String getBOLTPayAddress() {
        return BOLTPayAddress;
    }

    public String getLIGHTPayAddress() {
        return LIGHTPayAddress;
    }

    public String getSHINEPayAddress() {
        return SHINEPayAddress;
    }

    public String getWATCHPayAddress() {
        return WATCHPayAddress;
    }

    public String getAndroidUpgradeUrl() {
        return androidUpgradeUrl;
    }

    public int getAndroidVersion() {
        return androidVersion;
    }

    public String getAndroidVersionIntroduction() {
        return androidVersionIntroduction;
    }

    public String getAndroidVersionView() {
        return androidVersionView;
    }

    public String getHomeBackgroundImage() {
        return homeBackgroundImage;
    }

    public String getIosUpgradeUrl() {
        return iosUpgradeUrl;
    }

    public int getIosVersion() {
        return iosVersion;
    }

    public String getIosVersionIntroduction() {
        return iosVersionIntroduction;
    }

    public String getIosVersionView() {
        return iosVersionView;
    }

    public String getAppUserRunShareLink() {
        return AppUserRunShareLink;
    }

    public void setAppUserRunShareLink(String appUserRunShareLink) {
        AppUserRunShareLink = appUserRunShareLink;
    }

    public String getAppDownloadQRCodeLink() {
        return AppDownloadQRCodeLink;
    }

    public void setAppDownloadQRCodeLink(String appDownloadQRCodeLink) {
        AppDownloadQRCodeLink = appDownloadQRCodeLink;
    }

    public String getKeyUrl1() {
        return keyUrl1;
    }

    public void setKeyUrl1(String keyUrl) {
        this.keyUrl1 = keyUrl;
    }

    public String getAppThemeAnswerShareLink() {
        return AppThemeAnswerShareLink;
    }

    public void setAppThemeAnswerShareLink(String appThemeAnswerShareLink) {
        AppThemeAnswerShareLink = appThemeAnswerShareLink;
    }

    public List<Adverts> getAdverts() {
        if (adverts == null)
            adverts = new ArrayList<>();
        return adverts;
    }

    public List<DicEntity> getDic() {
        return dic;
    }

    /**
     * 字典定义
     */
    public static class DicEntity {
        /**
         * 字典编号
         */
        private int id;
        private String name;
        private int sort;
        private int type;
        private int value;

        public void setId(int id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setSort(int sort) {
            this.sort = sort;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getSort() {
            return sort;
        }

        public int getType() {
            return type;
        }

        public int getValue() {
            return value;
        }
    }
}
