package com.fitmix.sdk.model.api.bean;

/**
 * 流量兑换接口(liumi/exchange.json)返回的结果
 */
public class CoinExchange extends BaseBean {

    /**
     * addTime : 1483688217877
     * coin : 10
     * id : 32
     * liumiOrderNo : 951201701061536494742
     * mobile : 15712166807
     * modifyTime : 1483688217877
     * orderNo : 14836882177447402122265
     * postpackage : YD10
     * productId : 2
     * result : {"code":"000","data":{"orderNO":"951201701061536494742","extNO":"14836882177447402122265"}}
     * <p>
     * status : CREATED
     * uid : 918504
     */

    private LiumiOrderEntity liumiOrder;

    public LiumiOrderEntity getLiumiOrder() {
        return liumiOrder;
    }

    public void setLiumiOrder(LiumiOrderEntity liumiOrder) {
        this.liumiOrder = liumiOrder;
    }

    public static class LiumiOrderEntity {
        private long addTime;
        private int coin;//消耗金币数量
        private int id;
        private String liumiOrderNo;
        private String mobile;//兑换流量手机号码
        private long modifyTime;
        /**
         * 乐享动订单号
         */
        private String orderNo;
        private String postpackage;//套餐类型
        private int productId;
        private String result;
        private String status;
        /**
         * 乐享动用户uid
         */
        private int uid;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getCoin() {
            return coin;
        }

        public void setCoin(int coin) {
            this.coin = coin;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getLiumiOrderNo() {
            return liumiOrderNo;
        }

        public void setLiumiOrderNo(String liumiOrderNo) {
            this.liumiOrderNo = liumiOrderNo;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public long getModifyTime() {
            return modifyTime;
        }

        public void setModifyTime(long modifyTime) {
            this.modifyTime = modifyTime;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getPostpackage() {
            return postpackage;
        }

        public void setPostpackage(String postpackage) {
            this.postpackage = postpackage;
        }

        public int getProductId() {
            return productId;
        }

        public void setProductId(int productId) {
            this.productId = productId;
        }

        public String getResult() {
            return result;
        }

        public void setResult(String result) {
            this.result = result;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }
}
