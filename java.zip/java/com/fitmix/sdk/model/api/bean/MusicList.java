package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Music;

import java.util.List;

/**
 * 通过id集合获取的歌曲列表
 */
public class MusicList extends BaseBean {

    /**
     * addTime : 1437392699603
     * albumUrl : http://yyssb.ifitmix.com/1001/9a83b8ff44ac4903a774505b41e5dd6e.jpg
     * albumUrl_2 : http://yyssb.ifitmix.com/1001/4dbae6a5b3af4ccb9d809591637991d6.jpg
     * auditionCount : 7
     * author : DJ Jasonlee
     * baseAuditionCount : 4346
     * bpm : 126
     * bpmType : 1
     * bpmVariableBegin : 126
     * bpmVariableEnd : 126
     * collectNumber : 4
     * customIdentification : 0500005
     * downloadCount : 199
     * genre : [16]
     * id : 138
     * introduce : 55分钟椭圆机或慢跑,bpm126,techouse风格的电音舞曲混音。椭圆机建议使用范围：阻力设置为6-14。慢跑时建议跑步机设置为6-7km/h。
     * maid : 10
     * mixMusics : []
     * name : 从椭圆机到另一片宇宙
     * scene : [3]
     * shareCount : 6
     * shelvesTime : 1454575454683
     * sort : 50
     * state : 2
     * trackLength : 3420
     * url : http://yyssb.ifitmix.com//1000/0a9f0138b04c4b5886415c256ab6e1f9.m4a
     */
    private List<Music> mixList;

    public List<Music> getMixList() {
        return mixList;
    }

    public void setMixList(List<Music> mixList) {
        this.mixList = mixList;
    }
}
