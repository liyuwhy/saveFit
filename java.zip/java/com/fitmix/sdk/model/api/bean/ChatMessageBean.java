package com.fitmix.sdk.model.api.bean;

/**
 * 发送私信接口(/send/private/msg.json)返回的结果
 */

public class ChatMessageBean {

    /**
     * st : 1511417730086
     * code : 0
     * k : 72d2d7eb2e50413e844db30bd7819af6
     * message : {"addTime":1511417730081,"id":2707,"msgBody":{"fromUid":"1340266","groupId":"43","content":"骨头汤"},"selectChannel":"19","status":0}
     * groupId : 43
     */

    private long st;
    private int code;
    private String k;
    private MessageBean message;
    private int groupId;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public MessageBean getMessage() {
        return message;
    }

    public void setMessage(MessageBean message) {
        this.message = message;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public static class MessageBean {
        /**
         * addTime : 1511417730081
         * id : 2707
         * msgBody : {"fromUid":"1340266","groupId":"43","content":"骨头汤"}
         * selectChannel : 19
         * status : 0
         */

        private long addTime;
        private int id;
        private MsgBodyBean msgBody;
        private String selectChannel;
        private int status;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public MsgBodyBean getMsgBody() {
            return msgBody;
        }

        public void setMsgBody(MsgBodyBean msgBody) {
            this.msgBody = msgBody;
        }

        public String getSelectChannel() {
            return selectChannel;
        }

        public void setSelectChannel(String selectChannel) {
            this.selectChannel = selectChannel;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public static class MsgBodyBean {
            /**
             * fromUid : 1340266
             * groupId : 43
             * content : 骨头汤
             */

            private String fromUid;
            private String groupId;
            private String content;

            public String getFromUid() {
                return fromUid;
            }

            public void setFromUid(String fromUid) {
                this.fromUid = fromUid;
            }

            public String getGroupId() {
                return groupId;
            }

            public void setGroupId(String groupId) {
                this.groupId = groupId;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }
    }
}
