package com.fitmix.sdk.model.api.bean;

/**
 * 金币任务信息,根据任务键值获取任务信息接口(/task/get-task.json)返回的结果
 */

public class CoinTask extends BaseBean {

    /**
     * addTime : 1483668325545
     * coin : 10
     * description : 分享流量兑换页面
     * id : 67
     * modifyTime : 1483668325545
     * status : 0
     * taskKey : SHARE_FLOW
     * taskType : 3
     */

    private CoinTaskInfo taskInfo;

    public CoinTaskInfo getTaskInfo() {
        return taskInfo;
    }

    public void setTaskInfo(CoinTaskInfo taskInfo) {
        this.taskInfo = taskInfo;
    }

}
