package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Topic;

import java.util.List;

/**
 * 获取精选话题列表(/theme/banners.json)接口返回的结果
 */
public class HandPickTopicList extends BaseBean {

    /**
     * addTime : 1502182762827
     * answerId : 152
     * avatar : http://q.qlogo.cn/qqapp/111111/942FEA70050EEAFBD4DCE2C1FC775E56/100
     * backImage : http://yyssb.ifitmix.com/2014/f21b129089234c94a3ce4915ed75cac4.jpeg
     * bannerSort : 10
     * categoryId : 5
     * clickNum : 0
     * content :
     * discussNum : 1
     * id : 151
     * isConfirmed : 0
     * isReply : 1
     * name : qzuser
     * selectNodeTheme : {"addTime":1502183993485,"avatar":"http://yyssb.ifitmix.com/1002/44e369673cdd4f5b99405e272753fdde.jpg","categoryId":5,"clickNum":0,"content":"%E6%88%91%E7%9C%8B%E6%98%AF%E4%BB%80%E4%B9%88%E4%BA%8B%EF%BC%9F","discussNum":0,"id":152,"isConfirmed":1,"isReply":1,"name":"Barnaby","parentThemeId":151,"signature":"Android is awesome.","taoLunNum":2,"themeType":2,"uid":27,"upNum":0}
     * taoLunNum : 0
     * themeType : 1
     * title : 第一个话题
     * uid : 1
     * upNum : 0
     */

    private List<Topic> banners;

    public List<Topic> getBanners() {
        return banners;
    }

    public void setBanners(List<Topic> banners) {
        this.banners = banners;
    }
}
