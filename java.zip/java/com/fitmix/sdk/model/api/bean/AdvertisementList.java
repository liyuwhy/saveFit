package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 闪频广告列表
 */
public class AdvertisementList extends BaseBean {
    private List<Adverts> list;

    public List<Adverts> getList() {
        return list;
    }

    public void setList(List<Adverts> list) {
        this.list = list;
    }
}
