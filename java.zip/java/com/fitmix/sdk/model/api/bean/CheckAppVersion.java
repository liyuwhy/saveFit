package com.fitmix.sdk.model.api.bean;

/**
 * App 检查版本接口check-version.json返回的结果
 */
public class CheckAppVersion extends BaseBean {

    /**
     * androidUpgradeUrl : http://f.igeekery.com/mix/fitmix_lanchou.apk
     * androidVersion : 30
     * androidVersionIntroduction : 优化内存占用问题,增强稳定性。
     * androidVersionView : V2.0.1
     * iosUpgradeUrl : itms-services://?action=download-manifest&url=https://dn-igeekery.qbox.me/GEEKERY.plist
     * iosVersion : 4
     * iosVersionIntroduction : 优化内存占用问题,增强稳定性。
     * iosVersionView : 1.1.6
     * <p>
     * {"st":1500535095249,"code":0,
     * "k":"1ca376911dca476986d90ec547668a20","upgrade":1,
     * "content":{"appDisplay":0,"id":146,"name":"app需要升级，更新的内容为xxxx","nameEn":"app需要升级，更新的内容为xxxx","sort":2,"type":11,"value":2}}
     */

    private int upgrade;//是否需要强制升级,1:是,0:否
    private String content;//升级说明
    private String androidUpgradeUrl;
    private int androidVersion;
    private String androidVersionIntroduction;
    private String androidVersionView;
    private String iosUpgradeUrl;
    private int iosVersion;
    private String iosVersionIntroduction;
    private String iosVersionView;

    /**
     * 是否需要强制升级,1:是,0:否
     */
    public int getUpgrade() {
        return upgrade;
    }

    public void setUpgrade(int upgrade) {
        this.upgrade = upgrade;
    }

    /**
     * 升级说明
     */
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setAndroidUpgradeUrl(String androidUpgradeUrl) {
        this.androidUpgradeUrl = androidUpgradeUrl;
    }

    public void setAndroidVersion(int androidVersion) {
        this.androidVersion = androidVersion;
    }

    public void setAndroidVersionIntroduction(String androidVersionIntroduction) {
        this.androidVersionIntroduction = androidVersionIntroduction;
    }

    public void setAndroidVersionView(String androidVersionView) {
        this.androidVersionView = androidVersionView;
    }

    public void setIosUpgradeUrl(String iosUpgradeUrl) {
        this.iosUpgradeUrl = iosUpgradeUrl;
    }

    public void setIosVersion(int iosVersion) {
        this.iosVersion = iosVersion;
    }

    public void setIosVersionIntroduction(String iosVersionIntroduction) {
        this.iosVersionIntroduction = iosVersionIntroduction;
    }

    public void setIosVersionView(String iosVersionView) {
        this.iosVersionView = iosVersionView;
    }

    public String getAndroidUpgradeUrl() {
        return androidUpgradeUrl;
    }

    public int getAndroidVersion() {
        return androidVersion;
    }

    public String getAndroidVersionIntroduction() {
        return androidVersionIntroduction;
    }

    public String getAndroidVersionView() {
        return androidVersionView;
    }

    public String getIosUpgradeUrl() {
        return iosUpgradeUrl;
    }

    public int getIosVersion() {
        return iosVersion;
    }

    public String getIosVersionIntroduction() {
        return iosVersionIntroduction;
    }

    public String getIosVersionView() {
        return iosVersionView;
    }
}
