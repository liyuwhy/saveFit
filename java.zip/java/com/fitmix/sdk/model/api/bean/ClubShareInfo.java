package com.fitmix.sdk.model.api.bean;

/**
 * 获取俱乐部分享地址的结果
 */
public class ClubShareInfo extends BaseBean {

    /**
     * shareUrl : http://appt.igeekery.com:80/club/share-info.htm?clubId=1834
     */
    private String shareUrl;

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }
}
