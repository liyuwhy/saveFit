package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Music;

import java.util.List;

/**
 * 获取热词列表(search-mix.json)接口返回的结果
 */
public class SearchMusicList extends BaseBean {

    /**
     * addTime : 1447850426859
     * albumUrl : http://yyssb.ifitmix.com/1001/4e25e153bfe54432b4c3b28f2446ca68.jpg
     * albumUrl_2 : http://yyssb.ifitmix.com/1001/9cc3960069bc40288c0b7ec8084a960b.jpg
     * auditionCount : 1
     * author : 街舞音乐
     * baseAuditionCount : 18893
     * bpm : 115
     * bpmType : 1
     * bpmVariableBegin : 115
     * bpmVariableEnd : 115
     * collectNumber : 221
     * customIdentification : 1101
     * downloadCount : 1611
     * genre : [6]
     * id : 458
     * introduce : 街舞音乐
     * maid : 73
     * mixMusics : []
     * name : 你能赶上节拍么
     * scene : [7]
     * shareCount : 39
     * shelvesTime : 1447921424056
     * sort : 1
     * state : 2
     * trackLength : 300
     * url : http://yyssb.ifitmix.com/1000/c9b5ca6dbe274143a2b5ffcb0b2d28f9.m4a
     */

    private List<Music> mix;

    public List<Music> getMix() {
        return mix;
    }

    public void setMix(List<Music> mix) {
        this.mix = mix;
    }

}
