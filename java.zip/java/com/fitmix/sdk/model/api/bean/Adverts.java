package com.fitmix.sdk.model.api.bean;

import java.io.Serializable;

/**
 * APP初始化接口(init.json)返回结果中的广告信息列表
 */
public class Adverts implements Serializable {
    private int id;
    private int operationType;//广告可以操作的类型
    private String title;//广告标题
    private String advertImg;//广告的url
    private String toUrl;//广告跳转的url

//    public Adverts() {
//        clear();
//    }

    public Adverts(int id, int operationType, String title, String advertImg, String toUrl) {
        this.id = id;
        this.operationType = operationType;
        this.title = title;
        this.advertImg = advertImg;
        this.toUrl = toUrl;
    }

    //    private void clear(){
//        id = 0;
//        operationType = 0;
//        title = "";
//        advertImg = "";
//        toUrl = "";
//    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAdvertImg() {
        return advertImg;
    }

    public void setAdvertImg(String advertImg) {
        this.advertImg = advertImg;
    }

    public String getToUrl() {
        return toUrl;
    }

    public void setToUrl(String toUrl) {
        this.toUrl = toUrl;
    }
}
