package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取任务列表接口(/task/task-list.json),返回的结果
 */

public class TaskList extends BaseBean {


    /**
     * addTime : 1479376594226
     * coin : 4
     * description : 每日登陆任务
     * finishStatus : 1
     * id : 34
     * modifyTime : 1479376594226
     * status : 0
     * taskKey : EVERY_DAY_LOGIN
     * taskType : 0
     */

    private List<CoinTaskInfo> taskList;

    public List<CoinTaskInfo> getTaskList() {
        return taskList;
    }

    public void setTaskList(List<CoinTaskInfo> taskList) {
        this.taskList = taskList;
    }

//    public static class TaskEntity {
//        private long addTime;
//        private int coin;//完成任务奖励的金币数
//        private String description;//任务描述
//        private int finishStatus;//完成状态,1:未完成,0:已完成
//        private int id;
//        private long modifyTime;
//        private int status;//任务有效状态,0:有效,1:无效.无效任务不用在界面显示
//        private String taskKey;//任务关键字
//        private int taskType;//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,3:流量兑换结果分享,-1:所有类型
//
//        public long getAddTime() {
//            return addTime;
//        }
//
//        public void setAddTime(long addTime) {
//            this.addTime = addTime;
//        }
//
//        public int getCoin() {
//            return coin;
//        }
//
//        public void setCoin(int coin) {
//            this.coin = coin;
//        }
//
//        public String getDescription() {
//            return description;
//        }
//
//        public void setDescription(String description) {
//            this.description = description;
//        }
//
//        /**
//         * 完成状态,1:未完成,0:已完成
//         * */
//        public int getFinishStatus() {
//            return finishStatus;
//        }
//
//        public void setFinishStatus(int finishStatus) {
//            this.finishStatus = finishStatus;
//        }
//
//        public int getId() {
//            return id;
//        }
//
//        public void setId(int id) {
//            this.id = id;
//        }
//
//        public long getModifyTime() {
//            return modifyTime;
//        }
//
//        public void setModifyTime(long modifyTime) {
//            this.modifyTime = modifyTime;
//        }
//
//        /**
//         * 任务有效状态,0:有效,1:无效.无效任务不用在界面显示
//         * */
//        public int getStatus() {
//            return status;
//        }
//
//        public void setStatus(int status) {
//            this.status = status;
//        }
//
//        public String getTaskKey() {
//            return taskKey;
//        }
//
//        public void setTaskKey(String taskKey) {
//            this.taskKey = taskKey;
//        }
//
//        /**
//         * 任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,3:流量兑换结果分享,-1:所有类型
//         * */
//        public int getTaskType() {
//            return taskType;
//        }
//
//        public void setTaskType(int taskType) {
//            this.taskType = taskType;
//        }
//    }
}
