package com.fitmix.sdk.model.api.bean;

/**
 * 获取用户信息(如金币数量等)接口,account/uid.json返回的结果
 */
public class AccountInfo extends BaseBean {


    /**
     * addTime : 1480474204466
     * coin : 10
     * description : 每日签到任务
     * finishStatus : 1
     * id : 66
     * modifyTime : 1480474204466
     * status : 0
     * taskKey : EVERY_DAY_SIGN_IN
     * taskType : 0
     */

    private EVERYDAYSIGNINEntity EVERY_DAY_SIGN_IN;//每日签到
    /**
     * addTime : 1480326416601
     * coin : 45
     * id : 8783
     * modifyTime : 1480326416601
     * uid : 27
     */

    private AccountEntity account;

    public EVERYDAYSIGNINEntity getEVERY_DAY_SIGN_IN() {
        return EVERY_DAY_SIGN_IN;
    }

    public void setEVERY_DAY_SIGN_IN(EVERYDAYSIGNINEntity EVERY_DAY_SIGN_IN) {
        this.EVERY_DAY_SIGN_IN = EVERY_DAY_SIGN_IN;
    }

    public AccountEntity getAccount() {
        return account;
    }

    public void setAccount(AccountEntity account) {
        this.account = account;
    }

    public static class EVERYDAYSIGNINEntity {
        private long addTime;
        private int coin;//签到奖励的金币数量
        private String description;
        private int finishStatus;//签到状态,0表示已签到,1表示未签到
        private int id;
        private long modifyTime;
        private int status;
        private String taskKey;//任务类型键值,EVERY_DAY_SIGN_IN表示今日签到
        private int taskType;//任务类型,0表示今日签到

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getCoin() {
            return coin;
        }

        public void setCoin(int coin) {
            this.coin = coin;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getFinishStatus() {
            return finishStatus;
        }

        public void setFinishStatus(int finishStatus) {
            this.finishStatus = finishStatus;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public long getModifyTime() {
            return modifyTime;
        }

        public void setModifyTime(long modifyTime) {
            this.modifyTime = modifyTime;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTaskKey() {
            return taskKey;
        }

        public void setTaskKey(String taskKey) {
            this.taskKey = taskKey;
        }

        public int getTaskType() {
            return taskType;
        }

        public void setTaskType(int taskType) {
            this.taskType = taskType;
        }
    }

    public static class AccountEntity {
        private long addTime;
        private int coin;
        private int id;
        private long modifyTime;
        private int uid;

        public long getAddTime() {
            return addTime;
        }

        public void setAddTime(long addTime) {
            this.addTime = addTime;
        }

        public int getCoin() {
            return coin;
        }

        public void setCoin(int coin) {
            this.coin = coin;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public long getModifyTime() {
            return modifyTime;
        }

        public void setModifyTime(long modifyTime) {
            this.modifyTime = modifyTime;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }


}
