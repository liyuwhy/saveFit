package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 微信授权登录(login-wx.json)返回结果
 */
public class WeiXinAuthLogin extends BaseBean {


    /**
     * age : 32
     * avatar :
     * calorie : 0
     * distance : 0
     * email : 15907016098@139.com
     * gender : 1
     * height : 175
     * id : 69161
     * loginType : 3
     * name : 15907016098
     * openid :
     * registerType : 1
     * runTime : 0
     * state : 1
     * step : 0
     * type : 1
     * wbOpenid :
     * weight : 88
     * wxOpenid :
     */

    private UserEntity user;
    /**
     * collectIds : [489]
     * user : {"age":32,"avatar":"","calorie":0,"distance":0,"email":"15907016098@139.com","gender":1,"height":175,"id":69161,"loginType":3,"name":"15907016098","openid":"","registerType":1,"runTime":0,"state":1,"step":0,"type":1,"wbOpenid":"","weight":88,"wxOpenid":""}
     */

    private List<Integer> collectIds;

    public void setUser(UserEntity user) {
        this.user = user;
    }

    public void setCollectIds(List<Integer> collectIds) {
        this.collectIds = collectIds;
    }

    public UserEntity getUser() {
        return user;
    }

    public List<Integer> getCollectIds() {
        return collectIds;
    }

    /**
     * 微信授权登录(login-wx.json)返回结果中用户信息实体
     */
    public static class UserEntity {
        /**
         * 年龄
         */
        private int age;
        /**
         * 头像地址
         */
        private String avatar;
        /**
         * 运动总消耗卡路里
         */
        private int calorie;
        /**
         * 运动总距离
         */
        private int distance;
        /**
         * 用户
         */
        private String email;
        /**
         * 年龄
         */
        private int gender;
        /**
         * 年龄
         */
        private int height;
        /**
         * 年龄
         */
        private int id;
        /**
         * 年龄
         */
        private int loginType;
        /**
         * 年龄
         */
        private String name;
        /**
         * 年龄
         */
        private String openid;
        /**
         * 年龄
         */
        private int registerType;
        /**
         * 年龄
         */
        private int runTime;
        /**
         * 年龄
         */
        private int state;
        /**
         * 年龄
         */
        private int step;
        /**
         * 年龄
         */
        private int type;
        /**
         * 年龄
         */
        private String wbOpenid;
        /**
         * 年龄
         */
        private int weight;
        /**
         * 年龄
         */
        private String wxOpenid;

        public void setAge(int age) {
            this.age = age;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public void setCalorie(int calorie) {
            this.calorie = calorie;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setLoginType(int loginType) {
            this.loginType = loginType;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setOpenid(String openid) {
            this.openid = openid;
        }

        public void setRegisterType(int registerType) {
            this.registerType = registerType;
        }

        public void setRunTime(int runTime) {
            this.runTime = runTime;
        }

        public void setState(int state) {
            this.state = state;
        }

        public void setStep(int step) {
            this.step = step;
        }

        public void setType(int type) {
            this.type = type;
        }

        public void setWbOpenid(String wbOpenid) {
            this.wbOpenid = wbOpenid;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public void setWxOpenid(String wxOpenid) {
            this.wxOpenid = wxOpenid;
        }

        public int getAge() {
            return age;
        }

        public String getAvatar() {
            return avatar;
        }

        public int getCalorie() {
            return calorie;
        }

        public int getDistance() {
            return distance;
        }

        public String getEmail() {
            return email;
        }

        public int getGender() {
            return gender;
        }

        public int getHeight() {
            return height;
        }

        public int getId() {
            return id;
        }

        public int getLoginType() {
            return loginType;
        }

        public String getName() {
            return name;
        }

        public String getOpenid() {
            return openid;
        }

        public int getRegisterType() {
            return registerType;
        }

        public int getRunTime() {
            return runTime;
        }

        public int getState() {
            return state;
        }

        public int getStep() {
            return step;
        }

        public int getType() {
            return type;
        }

        public String getWbOpenid() {
            return wbOpenid;
        }

        public int getWeight() {
            return weight;
        }

        public String getWxOpenid() {
            return wxOpenid;
        }
    }
}
