package com.fitmix.sdk.model.api.bean;


import com.fitmix.sdk.view.bean.ClubMember;

import java.util.List;

/**
 * 获取俱乐部成员列表的结果
 */
public class ClubMemberList extends BaseBean {

    /**
     * filter : {"clubId":527}
     * hasNext : true
     * hasPre : false
     * index : 0
     * nextPage : 2
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1457681198684,"clubId":527,"id":760,"status":0,"type":0,"uid":34051,"user":{"avatar":"http://yyssb.ifitmix.com/1002/63a8e94a90504ef48232b11869b1211e.jpg","id":34051,"name":"stzh"}},{"addTime":1457681439485,"clubId":527,"id":761,"status":0,"type":1,"uid":90987,"user":{"avatar":"http://yyssb.ifitmix.com/1002/ecccfe4503fe44e08a14b3a7b84f0ceb.jpg","id":90987,"name":"JUNBAI"}},{"addTime":1457681471667,"clubId":527,"id":762,"status":0,"type":1,"uid":33,"user":{"avatar":"http://wx.qlogo.cn/mmopen/DpDWxM6CCag4kUvW8g27YI9nN0HnVr0RKX00JWZ9vocuZhA8Y7AtUiaCT5HIDc7hxxwwBGY5GnVlicTibh2UqnRHX9ial5RiaecB1/0","id":33,"name":"胡宜平"}},{"addTime":1457681489637,"clubId":527,"id":763,"status":0,"type":1,"uid":14576,"user":{"avatar":"http://yyssb.ifitmix.com/1002/933e926fb6a940f6a50cfb0940a5cd98.jpg","id":14576,"name":"NAM"}},{"addTime":1457681673536,"clubId":527,"id":764,"status":0,"type":1,"uid":525,"user":{"avatar":"http://yyssb.ifitmix.com/1002/dbe0af975e604713956d2201c1ada49b.jpg","id":525,"name":"Carol?"}},{"addTime":1457681692291,"clubId":527,"id":765,"status":0,"type":1,"uid":232274,"user":{"avatar":"http://yyssb.ifitmix.com/1002/bf52f430dbfa489bba728fdebdefb1f1.jpg","id":232274,"name":"lkobe"}},{"addTime":1457681831119,"clubId":527,"id":766,"status":0,"type":1,"uid":208601,"user":{"avatar":"http://yyssb.ifitmix.com/1002/e0cca8a97d244302aa2c2c08e1dd0d2b.jpg","id":208601,"name":"阿P"}},{"addTime":1457681917171,"clubId":527,"id":767,"status":0,"type":1,"uid":10,"user":{"avatar":"http://wx.qlogo.cn/mmopen/Q3auHgzwzM6vVQ6cAPffSmxr8KRBSm37SUtt1RbL4DSO98MzKakXX3wdQr1xXAGN85ecSx3td4l864qZUUcktMfAOfic79sSNOvpm2vG7S3g/0","id":10,"name":"快乐使者"}},{"addTime":1457681917721,"clubId":527,"id":768,"status":0,"type":1,"uid":5,"user":{"avatar":"http://yyssb.ifitmix.com/1002/08621b854e204ee1897f7859c784af60.jpg","id":5,"name":"fanny "}},{"addTime":1457682156792,"clubId":527,"id":769,"status":0,"type":1,"uid":97010,"user":{"avatar":"http://yyssb.ifitmix.com/1002/2b384fcfcc264ac7bde27a0b0dcfe29f.jpg","id":97010,"name":"锋子"}},{"addTime":1457682269931,"clubId":527,"id":771,"status":0,"type":1,"uid":8,"user":{"avatar":"http://yyssb.ifitmix.com/1002/5b82292ffc564e81afb11cd05db67da5.jpg","id":8,"name":"我说我叫ZZ"}},{"addTime":1457682383085,"clubId":527,"id":772,"status":0,"type":1,"uid":189002,"user":{"avatar":"http://yyssb.ifitmix.com/1002/68fd82f5b78741db942cec38b85a6b6a.jpg","id":189002,"name":"乐享动_189002"}},{"addTime":1457682986741,"clubId":527,"id":774,"status":0,"type":1,"uid":165717,"user":{"avatar":"http://tp2.sinaimg.cn/5786285001/180/0/0","id":165717,"name":"神一样的蛇蛇"}},{"addTime":1457684484800,"clubId":527,"id":775,"status":0,"type":1,"uid":55700,"user":{"avatar":"http://yyssb.ifitmix.com/1002/d187498856bb413d8bf418ae98de4620.jpg","id":55700,"name":"坦坦"}},{"addTime":1457688361510,"clubId":527,"id":779,"status":0,"type":1,"uid":110563,"user":{"avatar":"http://yyssb.ifitmix.com/1002/42960e4df9ec4419b073483857229a01.jpg","id":110563,"name":"Yen"}},{"addTime":1457689057948,"clubId":527,"id":781,"status":0,"type":1,"uid":1235,"user":{"avatar":"http://yyssb.ifitmix.com/1002/59d0113a1247434ea06966cf211856c8.jpg","id":1235,"name":"cheny"}},{"addTime":1457760505650,"clubId":527,"id":817,"status":0,"type":1,"uid":192057,"user":{"avatar":"http://tva1.sinaimg.cn/crop.0.0.640.640.1024/6d853dd9jw8eoxr1up16tj20hs0hsgmt.jpg","id":192057,"name":"心想事成万事如意的少女P"}},{"addTime":1457925000939,"clubId":527,"id":896,"status":0,"type":1,"uid":18535,"user":{"avatar":"","id":18535,"name":"superearn"}},{"addTime":1458229060804,"clubId":527,"id":1027,"status":0,"type":1,"uid":378,"user":{"avatar":"http://yyssb.ifitmix.com/1002/63c8ab5e04744960b9eb1268344966d0.tmp","id":378,"name":"晓锋"}},{"addTime":1459263327379,"clubId":527,"id":1316,"status":0,"type":1,"uid":15,"user":{"avatar":"http://yyssb.ifitmix.com/1002/9b1e1f92c3ad48fb82695295d00aa8e8.jpg","id":15,"name":"打你家玻璃"}}]
     * size : 20
     * total : 24
     * totalPages : 2
     */

    private PageBean list;

    public PageBean getList() {
        return list;
    }

    public void setList(PageBean list) {
        this.list = list;
    }

    public static class PageBean {
        /**
         * clubId : 527
         */
        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        /**
         * addTime : 1457681198684
         * clubId : 527
         * id : 760
         * status : 0
         * type : 0
         * uid : 34051
         * user : {"avatar":"http://yyssb.ifitmix.com/1002/63a8e94a90504ef48232b11869b1211e.jpg","id":34051,"name":"stzh"}
         */

        private List<ClubMember> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<ClubMember> getResult() {
            return result;
        }

        public void setResult(List<ClubMember> result) {
            this.result = result;
        }

        public static class FilterBean {
            private int clubId;

            public int getClubId() {
                return clubId;
            }

            public void setClubId(int clubId) {
                this.clubId = clubId;
            }
        }

    }
}
