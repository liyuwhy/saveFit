package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Club;

/**
 * 查找俱乐部(/club/find.json)接口返回的结果
 */

public class ClubDetail extends BaseBean {

    /**
     * detail : {"addTime":1508901433084,"backImageUrl":"http://yyssb.ifitmix.com/2001/ed5b31a3781f4ed58d547daee026206f.jpg","desc":"测试俱乐部消息和活动推送","id":2546,"maxMember":50,"memberCount":2,"memberUidSet":[1340266,209],"name":"测试俱乐部推送","status":0,"uid":1340266,"user":{"blackList":[],"id":1340266,"name":"tovh"}}
     */

    private Club detail;

    public Club getDetail() {
        return detail;
    }

    public void setDetail(Club detail) {
        this.detail = detail;
    }

}
