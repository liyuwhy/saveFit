package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.bean.Music;

import java.util.List;

public class MixPageInfo extends BaseBean {

    private PageInfo page;
    /**
     * addTime : 1445336962833
     * albumUrl : http://yyssb.ifitmix.com/1001/47cd891e92364480ada10809e164fcd9.jpg
     * albumUrl_2 : http://yyssb.ifitmix.com/1001/a6f48a3553f742fa80273c4d5e368491.jpg
     * auditionCount : 5
     * baseAuditionCount : 6925
     * bpm : 130
     * bpmType : 1
     * bpmVariableBegin : 130
     * bpmVariableEnd : 130
     * collectNumber : 196
     * customIdentification : 2100171
     * downloadCount : 2976
     * genre : [1,2]
     * id : 325
     * introduce : 55分钟慢跑,bpm130,步频约每分钟130步,速度约为7km/h。pop house edm风格的电音流行舞曲混音。慢跑40分钟以上减小肚子,一周跑5次左右。
     * maid : 56
     * mixMusics : []
     * name : 每天坚持慢跑减掉小肚子
     * scene : [3]
     * shareCount : 203
     * shelvesTime : 1454483641799
     * sort : 50
     * state : 2
     * trackLength : 3420
     * url : http://yyssb.ifitmix.com//1000/db46cffdc23b49e5a22b58a9853c30e2.m4a
     */

    private List<Music> list;

    public PageInfo getPage() {
        return page;
    }

    public void setPage(PageInfo page) {
        this.page = page;
    }

    public List<Music> getList() {
        return list;
    }

    public void setList(List<Music> list) {
        this.list = list;
    }

    public static class PageInfo {
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        /**
         * addTime : 1463643895029
         * albumUrl : http://yyssb.ifitmix.com/1001/fb25c58d2037448784c4f8349a232a80.jpg
         * albumUrl_2 : http://yyssb.ifitmix.com/1001/39675f52955646c897dad07cfc60d6f7.jpg
         * author : DJ Shine
         * bpm : 140
         * bpmType : 1
         * bpmVariableBegin : 140
         * bpmVariableEnd : 140
         * collectNumber : 88
         * customIdentification : 0110004
         * downloadCount : 1366
         * genre : [15]
         * id : 745
         * introduce : 时长47分钟,适合中速跑,推荐步频约每分钟140步,速度约为8km/h。Pop Rock风格的混音,为你加满能量,跑出你爱的轨迹。
         * maid : 37
         * mixMusics : []
         * name : 520跑出表白的勇气
         * scene : [2]
         * shareCount : 117
         * shelvesTime : 1463648339077
         * sort : 50
         * state : 2
         * trackLength : 2820
         * url : http://yyssb.ifitmix.com/1000/6968ce3c98de45cca50102127f9b8c73.m4a
         */

        private List<Music> result;

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<Music> getResult() {
            return result;
        }

        public void setResult(List<Music> result) {
            this.result = result;
        }
    }

//	public static class ListBean {
//		private long addTime;
//		private String albumUrl;
//		private String albumUrl_2;
//		private int auditionCount;
//		private int baseAuditionCount;
//		private String bpm;
//		private int bpmType;
//		private int bpmVariableBegin;
//		private int bpmVariableEnd;
//		private int collectNumber;
//		private String customIdentification;
//		private int downloadCount;
//		private int id;
//		private String introduce;
//		private int maid;
//		private String name;
//		private int shareCount;
//		private long shelvesTime;
//		private int sort;
//		private int state;
//		private int trackLength;
//		private String url;
//		private List<Integer> genre;
//		private List<?> mixMusics;
//		private List<Integer> scene;
//
//		public long getAddTime() {
//			return addTime;
//		}
//
//		public void setAddTime(long addTime) {
//			this.addTime = addTime;
//		}
//
//		public String getAlbumUrl() {
//			return albumUrl;
//		}
//
//		public void setAlbumUrl(String albumUrl) {
//			this.albumUrl = albumUrl;
//		}
//
//		public String getAlbumUrl_2() {
//			return albumUrl_2;
//		}
//
//		public void setAlbumUrl_2(String albumUrl_2) {
//			this.albumUrl_2 = albumUrl_2;
//		}
//
//		public int getAuditionCount() {
//			return auditionCount;
//		}
//
//		public void setAuditionCount(int auditionCount) {
//			this.auditionCount = auditionCount;
//		}
//
//		public int getBaseAuditionCount() {
//			return baseAuditionCount;
//		}
//
//		public void setBaseAuditionCount(int baseAuditionCount) {
//			this.baseAuditionCount = baseAuditionCount;
//		}
//
//		public String getBpm() {
//			return bpm;
//		}
//
//		public void setBpm(String bpm) {
//			this.bpm = bpm;
//		}
//
//		public int getBpmType() {
//			return bpmType;
//		}
//
//		public void setBpmType(int bpmType) {
//			this.bpmType = bpmType;
//		}
//
//		public int getBpmVariableBegin() {
//			return bpmVariableBegin;
//		}
//
//		public void setBpmVariableBegin(int bpmVariableBegin) {
//			this.bpmVariableBegin = bpmVariableBegin;
//		}
//
//		public int getBpmVariableEnd() {
//			return bpmVariableEnd;
//		}
//
//		public void setBpmVariableEnd(int bpmVariableEnd) {
//			this.bpmVariableEnd = bpmVariableEnd;
//		}
//
//		public int getCollectNumber() {
//			return collectNumber;
//		}
//
//		public void setCollectNumber(int collectNumber) {
//			this.collectNumber = collectNumber;
//		}
//
//		public String getCustomIdentification() {
//			return customIdentification;
//		}
//
//		public void setCustomIdentification(String customIdentification) {
//			this.customIdentification = customIdentification;
//		}
//
//		public int getDownloadCount() {
//			return downloadCount;
//		}
//
//		public void setDownloadCount(int downloadCount) {
//			this.downloadCount = downloadCount;
//		}
//
//		public int getId() {
//			return id;
//		}
//
//		public void setId(int id) {
//			this.id = id;
//		}
//
//		public String getIntroduce() {
//			return introduce;
//		}
//
//		public void setIntroduce(String introduce) {
//			this.introduce = introduce;
//		}
//
//		public int getMaid() {
//			return maid;
//		}
//
//		public void setMaid(int maid) {
//			this.maid = maid;
//		}
//
//		public String getName() {
//			return name;
//		}
//
//		public void setName(String name) {
//			this.name = name;
//		}
//
//		public int getShareCount() {
//			return shareCount;
//		}
//
//		public void setShareCount(int shareCount) {
//			this.shareCount = shareCount;
//		}
//
//		public long getShelvesTime() {
//			return shelvesTime;
//		}
//
//		public void setShelvesTime(long shelvesTime) {
//			this.shelvesTime = shelvesTime;
//		}
//
//		public int getSort() {
//			return sort;
//		}
//
//		public void setSort(int sort) {
//			this.sort = sort;
//		}
//
//		public int getState() {
//			return state;
//		}
//
//		public void setState(int state) {
//			this.state = state;
//		}
//
//		public int getTrackLength() {
//			return trackLength;
//		}
//
//		public void setTrackLength(int trackLength) {
//			this.trackLength = trackLength;
//		}
//
//		public String getUrl() {
//			return url;
//		}
//
//		public void setUrl(String url) {
//			this.url = url;
//		}
//
//		public List<Integer> getGenre() {
//			return genre;
//		}
//
//		public void setGenre(List<Integer> genre) {
//			this.genre = genre;
//		}
//
//		public List<?> getMixMusics() {
//			return mixMusics;
//		}
//
//		public void setMixMusics(List<?> mixMusics) {
//			this.mixMusics = mixMusics;
//		}
//
//		public List<Integer> getScene() {
//			return scene;
//		}
//
//		public void setScene(List<Integer> scene) {
//			this.scene = scene;
//		}
//	}
}
