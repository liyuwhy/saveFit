package com.fitmix.sdk.model.api.bean;

import com.fitmix.sdk.view.bean.Video;

import java.util.List;

/**
 * 运动视频列表(get-video-list.json)接口返回的结果
 */
public class VideoList extends BaseBean {

    /**
     * filter : {"status":0}
     * hasNext : false
     * hasPre : false
     * index : 0
     * nextPage : 1
     * pageNo : 1
     * prePage : 1
     * result : [{"addTime":1465785891697,"content":"你曾想过这样的美妙场景吗?\r\n静谧的夜,漫天星空\r\n绚烂的灯光,一人一车\r\n尽情在林间、坡道、山地驰骋,享受山地自行车的魅力\r\n来自：Philips Ambilight TV","id":4,"posterName":"视频封面.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/57a84692973d4aba9271c50b20fba582.jpg","shareCount":8,"sort":2,"status":0,"title":"奇妙夜遇山地自行车历险","trackLength":"451","videoName":"奇妙夜遇山地自行车历险.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/382b5984ea2e4b55ae609cec7ed2a242.mp4"},{"addTime":1465799634318,"content":"跑酷\r\n现代城市炫酷的行走方式\r\n长城\r\n中国古代文明的宏伟象征\r\n跑酷VS长城\r\nHERE WE GO!\r\n来自：红牛运动世界","id":8,"posterName":"封面5.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/518be753cc904eea8f6cc5c76f705c25.jpg","shareCount":2,"sort":1,"status":0,"title":"俄罗斯跑酷达人挑战长城","trackLength":"223","videoName":"俄罗斯跑酷大神挑战长城.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/2e46e7c03e534f18b85097625a2bc805.mp4"},{"addTime":1465797994923,"content":"运动并没有那么难\r\n给你介绍15种随时随地都可以做的锻炼\r\n无论在家还是在公司\r\n抽空动起来吧\r\n来自：BUZZFEED","id":7,"posterName":"封面4.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/99496a1b1b0e4754bdb1af53bcafdc33.jpg","shareCount":3,"sort":1,"status":0,"title":"15种随时随地都可以做的锻炼","trackLength":"240","videoName":"15 种易学锻炼姿势.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/75a9a82e2a424875ac22b9a9f2126645.mp4"},{"addTime":1465797607918,"content":"穿上跑鞋,任何人都可以开始一场路跑\r\n然而,曾经\r\n世界上最知名的路跑赛事拒绝女性参加\r\n甚至把女性当场驱逐\r\n幸好,一切都在超好的方向改变着\r\n来自：xczonetv & o2films","id":6,"posterName":"封面3.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/ee1526cc545f429eba5c271f4f090491.jpg","shareCount":2,"sort":1,"status":0,"title":"氧气计划|路跑,你不知道的事","trackLength":"110","videoName":"Oxygen Project - Scene 004- Road Running.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/5dabd55fb24e4034a064638e373c5635.mp4"},{"addTime":1465789510978,"content":"你在健身房是哪种人?\r\n总之\r\n别成为这样的人\r\n菜鸟?炫耀者?\u201c教练\u201d?表情达人?\r\nNO!\r\n来自：Don't be that Guy","id":5,"posterName":"封面1.jpg","posterUrl":"http://yyssb.ifitmix.com/1011/37a9d72518584b2c8a72fb32fbe05d9a.jpg","shareCount":4,"sort":1,"status":0,"title":"趣谈运动|在健身房别做这样的人","trackLength":"193","videoName":"在健身房别做这样的人.mp4","videoUrl":"http://yyssb.ifitmix.com/1010/e77a4f35687e45dba33b8ec249876927.mp4"}]
     * size : 20
     * total : 5
     * totalPages : 1
     */

    private PageBean page;

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public static class PageBean {
        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        private List<Video> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<Video> getResult() {
            return result;
        }

        public void setResult(List<Video> result) {
            this.result = result;
        }

        public static class FilterBean {
            private int status;

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }

    }
}
