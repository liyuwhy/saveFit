package com.fitmix.sdk.model.api.bean;

import java.util.List;

/**
 * 获取流米流量套餐兑换信息接口(product/get-liumi-product.json),返回的结果实体
 */

public class LiuMi extends BaseBean {


    private ProductEntity product;

    public ProductEntity getProduct() {
        return product;
    }

    public void setProduct(ProductEntity product) {
        this.product = product;
    }

    public static class ProductEntity {
        /**
         * addTime : 1479782994098
         * coin : 100
         * id : 1
         * modifyTime : 1479782994098
         * name : 电信5M流量
         * quantity : 23
         * status : 0
         * type : 0
         * virtualKey : DX5
         */

        private List<FlowEntity> DX;
        /**
         * addTime : 1480927409233
         * coin : 100
         * id : 4
         * modifyTime : 1480927409233
         * name : 联通20M流量
         * quantity : 10
         * status : 0
         * type : 0
         * virtualKey : LT20
         */

        private List<FlowEntity> LT;
        /**
         * addTime : 1479799871983
         * coin : 100
         * id : 2
         * modifyTime : 1479799871983
         * name : 移动10M流量
         * quantity : 20
         * status : 0
         * type : 0
         * virtualKey : YD10
         */

        private List<FlowEntity> YD;

        public List<FlowEntity> getDX() {
            return DX;
        }

        public void setDX(List<FlowEntity> DX) {
            this.DX = DX;
        }

        public List<FlowEntity> getLT() {
            return LT;
        }

        public void setLT(List<FlowEntity> LT) {
            this.LT = LT;
        }

        public List<FlowEntity> getYD() {
            return YD;
        }

        public void setYD(List<FlowEntity> YD) {
            this.YD = YD;
        }

        public static class FlowEntity {//流量兑换套餐
            private long addTime;
            /**
             * 需要金币
             */
            private int coin;
            private int id;
            private long modifyTime;

            private String name;
            private int quantity;//库存
            private int status;
            private int type;
            private String virtualKey;

            public long getAddTime() {
                return addTime;
            }

            public void setAddTime(long addTime) {
                this.addTime = addTime;
            }

            public int getCoin() {
                return coin;
            }

            public void setCoin(int coin) {
                this.coin = coin;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public long getModifyTime() {
                return modifyTime;
            }

            public void setModifyTime(long modifyTime) {
                this.modifyTime = modifyTime;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public int getQuantity() {
                return quantity;
            }

            public void setQuantity(int quantity) {
                this.quantity = quantity;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public String getVirtualKey() {
                return virtualKey;
            }

            public void setVirtualKey(String virtualKey) {
                this.virtualKey = virtualKey;
            }
        }

    }
}
