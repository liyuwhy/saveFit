package com.fitmix.sdk.model.api.bean;

/**
 * 俱乐部用户的最后一次运动记录
 */
public class LastRunlogInfo extends BaseBean {

    private UserInfo user;

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }

    public static class UserInfo {
        private String avatar;
        private int id;
        private LastRun lastRun;
        private String name;

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public LastRun getLastRun() {
            return lastRun;
        }

        public void setLastRun(LastRun lastRun) {
            this.lastRun = lastRun;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
