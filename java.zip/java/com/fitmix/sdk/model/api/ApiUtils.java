package com.fitmix.sdk.model.api;

import android.Manifest;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;

import java.util.Calendar;
import java.util.UUID;

/**
 * 网络请求API帮助类
 */
public class ApiUtils {

    /**
     * 自定义数据请求异常状态码,表示网络不可用
     */
    public static final int HTTP_NETWORK_FAIL = 600;
    /**
     * 自定义数据请求异常状态码,表示http请求异常
     */
    public static final int HTTP_REQUEST_EXCEPTION = 700;
    /**
     * 自定义数据请求异常状态码,表示添加或更新据请求状态表失败
     */
    public static final int ADD_OR_UPDATE_REQ_STATUS_FAIL = 800;
    /**
     * 自定义数据请求异常状态码,表示请求的参数无效
     */
    public static final int HTTP_REQUEST_INPUT_INVALID = 900;

    /**
     * 服务器返回的token值
     */
    private static String API_TOKEN;

    /**
     * 获取服务器返回的k值
     */
    public static String getApiToken() {
        if (TextUtils.isEmpty(API_TOKEN)) {
            API_TOKEN = PrefsHelper.with(MixApp.getContext(), Config.PREFS_USER).read(Config.SP_KEY_API_TOKEN);
        }
        return API_TOKEN;
    }

    /**
     * 保存服务器返回的token值
     *
     * @param token 服务器返回的token值,即返回结果中的字段k
     */
    public static void setApiToken(String token) {
        if (!TextUtils.isEmpty(token)) {
            if (!token.equals(API_TOKEN)) {
                API_TOKEN = token;
                PrefsHelper.with(MixApp.getContext(), Config.PREFS_USER).write(Config.SP_KEY_API_TOKEN, token);
            }
        }
    }

    /**
     * 获取手机当前设置的语言
     */
    public static String getLanguage() {
        return MixApp.getContext().getResources().getConfiguration().locale.getLanguage();
    }

    public static  boolean isZhLanguage(){
        String appLan = ApiUtils.getLanguage();
        if (appLan == null || appLan.endsWith("zh")) {
            return true;
        }
        return false;
    }

    /**
     * 获取APK友盟统计渠道号
     */
    public static String getApkChannel() {
        int channel = 0;
        try {
            ApplicationInfo appInfo = MixApp.getContext().getPackageManager()
                    .getApplicationInfo(MixApp.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            channel = appInfo.metaData.getInt("UMENG_CHANNEL");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return String.valueOf(channel);
    }

    /**
     * 获取APK版本名称,gradle适用,快速
     */
    public static String getApkVersionName() {
        return com.fitmix.sdk.BuildConfig.VERSION_NAME;
    }

    /**
     * 获取APK版本名称
     */
    public static String getApkVersionNameFromPi() {
        String versionName = null;
        try {
            PackageInfo packInfo = MixApp.getContext().getPackageManager().getPackageInfo(
                    MixApp.getContext().getPackageName(), 0);
            versionName = packInfo.versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionName;
    }

    /**
     * 获取APK版本编号,gradle适用,快速
     */
    public static int getApkVersionCode() {
//        long now = System.currentTimeMillis();
        //        Logger.i(Logger.DEBUG_TAG,"getApkVersionCode time:"+(System.currentTimeMillis() - now) + ",versionCode:"+versionCode);
        return com.fitmix.sdk.BuildConfig.VERSION_CODE;
    }

    /**
     * 获取APK版本编号
     */
    public static int getApkVersionCodeFromPi() {
        int versionCode = 0;
        try {
            PackageInfo packInfo = MixApp.getContext().getPackageManager().getPackageInfo(
                    MixApp.getContext().getPackageName(), 0);
            versionCode = packInfo.versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionCode;
    }

    /**
     * 获取手机当前网络类型
     *
     * @return "2G" 或 "Wifi"
     */
    public static String getNetWorkType() {
        ConnectivityManager connectivity = (ConnectivityManager) MixApp.getContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        String type = "";
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null) {
                for (NetworkInfo ni : info) {
                    if (ni.getTypeName().equalsIgnoreCase("WIFI")
                            && ni.isConnected()) {
                        type = "wifi";
                        break;
                    } else if (ni.getTypeName().equalsIgnoreCase("MOBILE")
                            && ni.isConnected()) {
                        type = "2G";
                        break;
                    }
                }
            }
        }
        return type;
    }

    /**
     * 获取手机信息:手机型号+手机版本号
     */
    public static String getPhoneInfo() {
        return String.format("%s %s %s", getPhoneName() != null ? getPhoneName() : "",
                getPhoneModel() != null ? getPhoneModel() : "",
                getPhoneSdk() != null ? getPhoneSdk() : "");
    }

    /**
     * 获取手机SDK版本号
     */
    public static String getPhoneSdk() {
        return android.os.Build.VERSION.RELEASE;
//        return String.valueOf(Build.VERSION.SDK_INT);
    }

    /**
     * 获取手机生产商
     */
    public static String getManufacturer() {
        return Build.MANUFACTURER;
    }

    /**
     * 获取手机品牌
     */
    public static String getPhoneName() {
        return android.os.Build.BRAND;
    }

    /**
     * 获取手机型号
     */
    public static String getPhoneModel() {
        return android.os.Build.MODEL;
    }

    /**
     * 获取设备编号
     */
    public static String getUdid() {
        final TelephonyManager tm = (TelephonyManager) MixApp.getContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        final String tmDevice, tmSerial, timeId;
        String random = "" + ((Math.random() * 0xFFFFFFFF) % 0xFFFFFFFF);
        timeId = "" + Calendar.getInstance().getTimeInMillis();

        if (ActivityCompat.checkSelfPermission(MixApp.getContext(), Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            tmDevice = (tm != null && tm.getDeviceId() != null) ? tm.getDeviceId() : "";
            tmSerial = (tm != null && tm.getSimSerialNumber() != null) ? tm.getSimSerialNumber() : "";
            UUID deviceUuid = new UUID(((long) timeId.hashCode() << 32) | random.hashCode(),
                    ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
            return deviceUuid.toString();
        } else {
            UUID deviceUuid = new UUID(((long) timeId.hashCode() << 32) | random.hashCode(),
                    0);
            return deviceUuid.toString();
        }
    }

    /**
     * 运营商
     */
    public static String getSimOperatorName() {
        TelephonyManager tm = (TelephonyManager) MixApp.getContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        return tm.getSimOperatorName();
    }

    /**
     * 判断当前手机网络是否可用
     *
     * @return true:是,false:否
     */
    public static boolean isNetWorkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) MixApp.getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isAvailable();
        } else {
            return false;
        }
    }

    /**
     * 获取网络类型
     *
     * @return 0:无网络,1:手机网络类型,2:wifi网络类型
     */
    public static int getNetworkType() {
        int network = Config.NETWORK_TYPE_NONE;
        ConnectivityManager connectivity = (ConnectivityManager) MixApp.getContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] infos = connectivity.getAllNetworkInfo();
            if (infos != null) {
                for (NetworkInfo ni : infos) {
                    if (ni.getTypeName().equalsIgnoreCase("WIFI")
                            && ni.isConnected()) {
                        network = Config.NETWORK_TYPE_WIFI;
                        break;
                    } else if (ni.getTypeName().equalsIgnoreCase("MOBILE")
                            && ni.isConnected()) {
                        network = Config.NETWORK_TYPE_MOBILE;
                        break;
                    }
                }
            }
        }
        return network;
    }

    /**
     * 获取用户QQ APP id
     *
     * @return 用户QQ APP id
     */
    public static String getQqAppId() {//FIXME
//        String appId = null;
//                //PrefsHelper.with(MixApp.getContext(), AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);//TODO
//        if(TextUtils.isEmpty(appId)){
//            return "";
//        }
//        return appId;

        return "";
    }

    /**
     * 获取用户微信 union id
     *
     * @return 用户微信 union id
     */
    public static String getWeChatUnionId() {
        String unionId = PrefsHelper.with(MixApp.getContext(), AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_UNION_ID, "");
        if (TextUtils.isEmpty(unionId)) {
            return "";
        }
        return unionId;
    }


}
