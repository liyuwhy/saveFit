package com.fitmix.sdk.model.manager;

import com.fitmix.sdk.Config;

/**
 * 俱乐部数据,包括的数据接口有获取俱乐部列表等,用于开放与俱乐部有关的数据接口给UI层
 */
public class ClubDataManager extends BaseDataManager {

    /**
     * 本模块的ID编号
     */
    private static final int MODULE_ID = Config.MODULE_CLUB;
//    private static ClubDataManager mInstance;

    /**
     * 私有
     */
    private ClubDataManager() {
    }

    /**
     * 获取俱乐部数据实例
     */
    public static ClubDataManager getInstance() {
//        if (mInstance == null) {
//            mInstance = new ClubDataManager();
//        }
//        return mInstance;
        return new ClubDataManager();
    }


    @Override
    public int generateRequestId(int interfaceId) {
        return MODULE_ID + interfaceId;
    }

    /**
     * 获取俱乐部列表
     *
     * @param uid            用户ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400001
     */
    public int getClubList(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(1);
        makeRequest(requestId, ignorePreCache)
                .putInt("Uid", uid)
                .startService();
        return requestId;
    }

    /**
     * 获取俱乐部动态
     *
     * @param clubId         俱乐部ID
     * @param index          动态页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400002
     */
    public int getClubDynamic(int clubId, int index, boolean ignorePreCache) {
        int requestId = generateRequestId(2);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取俱乐部公告
     *
     * @param clubId         俱乐部ID
     * @param index          公告页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400003
     */
    public int getClubNotice(int clubId, int index, boolean ignorePreCache) {
        int requestId = generateRequestId(3);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取俱乐部排行
     *
     * @param clubId         俱乐部ID
     * @param index          排行页数
     * @param type           类型
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400004
     */
    public int getClubRankList(int clubId, int type, int index, boolean ignorePreCache) {
        int requestId = generateRequestId(4);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("index", index)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 获取俱乐部排行静态信息
     *
     * @param clubId         俱乐部ID
     * @param type           类型
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400005
     */
    public int getClubRankInfo(int clubId, int type, boolean ignorePreCache) {
        int requestId = generateRequestId(5);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 获取俱乐部留言
     *
     * @param clubId         俱乐部ID
     * @param index          留言页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400006
     */
    public int getClubMessage(int clubId, int index, boolean ignorePreCache) {
        int requestId = generateRequestId(6);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取获取活跃信息
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400007
     */
    public int getClubActiveInfo(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(7);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }

    /**
     * 获取活跃用户
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400008
     */
    public int getClubActiveUser(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(8);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)

                .startService();
        return requestId;
    }

    /**
     * 获取成员列表
     *
     * @param clubId         俱乐部ID
     * @param index          成员列表的页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400009
     */
    public int getClubMemberList(int clubId, int index, boolean ignorePreCache) {
        int requestId = generateRequestId(9);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 删除成员
     *
     * @param clubId         俱乐部ID
     * @param quitUid        删除成员的ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400010
     */
    public int deleteClubMember(int clubId, int quitUid, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putInt("quitUid", quitUid)
                .startService();
        return requestId;
    }

    /**
     * 获取最后一次运动记录
     *
     * @param uid            成员的ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400011
     */
    public int getLastRunlogInfo(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(11);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .startService();
        return requestId;
    }

    /**
     * 获取最后一次运动记录
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400012
     */
    public int quitClub(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(12);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }

    /**
     * 获取分享俱乐部的分享地址
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400013
     */
    public int getShareClubUrl(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(13);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }

    /**
     * 创建俱乐部
     *
     * @param clubName       俱乐部名称
     * @param clubDesc       俱乐部描述
     * @param fileName       上传的文件
     * @param tag            tag
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400014
     */
    public int createClub(String clubName, String clubDesc, String fileName, String tag, boolean ignorePreCache) {
        int requestId = generateRequestId(14);
        makeRequest(requestId, ignorePreCache)
                .putString("clubName", clubName)
                .putString("clubDesc", clubDesc)
                .putString("fileName", fileName)
                .putString("tag", tag)
                .startService();
        return requestId;
    }

    /**
     * 更改俱乐部
     *
     * @param clubId         俱乐部ID
     * @param clubName       俱乐部名称
     * @param clubDesc       俱乐部描述
     * @param fileName       上传的文件
     * @param tag            tag
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400015
     */
    public int modifyClub(int clubId, String clubName, String clubDesc, String fileName, String tag, boolean ignorePreCache) {
        int requestId = generateRequestId(15);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putString("clubName", clubName)
                .putString("clubDesc", clubDesc)
                .putString("fileName", fileName)
                .putString("tag", tag)
                .startService();
        return requestId;
    }

    /**
     * 更改俱乐部
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400016
     */
    public int deleteClub(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(16);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }

    /**
     * 创建俱乐部公告
     *
     * @param clubId         俱乐部Id
     * @param name           公告主题
     * @param content        FIXME 不知这个字段什么用 传""???
     * @param address        活动地点
     * @param beginTime      开始时间
     * @param endTime        结束时间
     * @param desc           活动描述
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return 400017
     */
    public int createClubNotice(int clubId, String name, String content, String address, long beginTime, long endTime, String desc, String fileName, String tag, boolean ignorePreCache) {
        int requestId = generateRequestId(17);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putString("name", name)
                .putString("content", content)
                .putString("address", address)
                .putLong("beginTime", beginTime)
                .putLong("endTime", endTime)
                .putString("desc", desc)
                .putString("fileName", fileName)
                .putString("tag", tag)
                .startService();
        return requestId;
    }

    /**
     * 更改俱乐部公告
     *
     * @param noticeId       公告ID
     * @param clubId         俱乐部Id
     * @param name           公告主题
     * @param content        FIXME 不知这个字段什么用 传""???
     * @param address        活动地点
     * @param beginTime      开始时间
     * @param endTime        结束时间
     * @param desc           活动描述
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400018
     */
    public int modifyClubNotice(int noticeId, int clubId, String name, String content, String address, long beginTime, long endTime, String desc, String fileName, String tag, boolean ignorePreCache) {
        int requestId = generateRequestId(18);
        makeRequest(requestId, ignorePreCache)
                .putInt("noticeId", noticeId)
                .putInt("clubId", clubId)
                .putString("name", name)
                .putString("content", content)
                .putString("address", address)
                .putLong("beginTime", beginTime)
                .putLong("endTime", endTime)
                .putString("desc", desc)
                .putString("fileName", fileName)
                .putString("tag", tag)
                .startService();
        return requestId;
    }

    /**
     * 更改俱乐部
     *
     * @param noticeId       公告Id
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400019
     */
    public int deleteClubNotice(int noticeId, int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(19);
        makeRequest(requestId, ignorePreCache)
                .putInt("noticeId", noticeId)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }

    /**
     * 添加俱乐部留言
     *
     * @param clubId         俱乐部ID
     * @param content        留言内容
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400020
     */
    public int addClubMessage(int clubId, String content, boolean ignorePreCache) {
        int requestId = generateRequestId(20);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .putString("content", content)
                .startService();
        return requestId;
    }

    /**
     * 邀请加入俱乐部
     *
     * @param clubId         俱乐部ID
     * @param addUid         加入人员Id
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400021
     */
    public int joinClub(String clubId, int addUid, boolean ignorePreCache) {
        int requestId = generateRequestId(21);
        makeRequest(requestId, ignorePreCache)
                .putString("clubId", clubId)
                .putInt("addUid", addUid)
                .startService();
        return requestId;
    }

    /**
     * 查找俱乐部
     *
     * @param clubId         俱乐部ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 400022
     */
    public int findClub(int clubId, boolean ignorePreCache) {
        int requestId = generateRequestId(22);
        makeRequest(requestId, ignorePreCache)
                .putInt("clubId", clubId)
                .startService();
        return requestId;
    }
}
