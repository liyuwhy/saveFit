package com.fitmix.sdk.model.manager;

import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.services.DataHandleService;

/**
 * 数据访问基类,作为其它数据访问类的基类,
 * 用于View层的网络数据请求管理
 */
public abstract class BaseDataManager {

    /**
     * 数据请求Intent
     */
    private Intent mIntent;
    /**
     * 数据请求参数bundle
     */
    private Bundle mBundle;
//    /** 目前处于未完成状态的数据请求编号 */ //FIXME
//    private SparseIntArray pendingRequests = new SparseIntArray();

    /**
     * 生成数据请求的ID,每一个ID对应一个数据请求接口,前两位表示模块,
     * 后四位表示该模块下的接口编号
     * 如用户信息管理模块下的登录接口为100001,表示由模块编号10和接口编号0001组成
     *
     * @param interfaceId 接口编号,数值取值0到9999
     * @return 数据请求的ID
     */
    protected abstract int generateRequestId(int interfaceId);

    /**
     * 创建数据访问帮助类实例,默认不忽略之前的请求结果
     *
     * @param requestId 数据请求编号
     */
    protected BaseDataManager makeRequest(int requestId) {
        return makeRequest(requestId, false);
    }

    /**
     * 创建数据访问帮助类实例
     *
     * @param requestId      数据请求编号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    protected BaseDataManager makeRequest(int requestId, boolean ignorePreCache) {
        mIntent = new Intent();
        mBundle = new Bundle();
        // 如果之前的请求还未完成,则直接返回不再受理
//        Logger.e(Logger.DATA_FLOW_TAG,"makeRequest--> isRequestPending("+requestId+"):"+isRequestPending(requestId));
//        if(isRequestPending(requestId)){
//            return this;
//        }else{
//            pendingRequests.put(requestId,requestId);//设置请求为忙碌状态
//        }
        mIntent.setClass(MixApp.getContext(), DataHandleService.class);
        mIntent.putExtra(DataHandleService.EXTRA_REQUEST_ID, requestId);
        mIntent.putExtra(DataHandleService.EXTRA_REQUEST_IGNORE_CACHE, ignorePreCache);
        ResultReceiver serviceCallback = new ResultReceiver(null) {

            @Override
            protected void onReceiveResult(int resultCode, Bundle resultData) {
                handleResponse(resultCode, resultData);
            }

        };
        mIntent.putExtra(DataHandleService.EXTRA_SERVICE_CALLBACK, serviceCallback);
        return this;
    }

//    /**
//     * 取消指定的数据请求
//     *
//     * @param requestId 要取消的数据编号
//     * */
//    public BaseDataManager cancelRequest(int requestId){
//        if(isRequestPending(requestId)){
//            pendingRequests.delete(requestId);
//            return this;
//        }
//        return this;
//    }

//    /**
//     * 获取指定的数据请求是否处于未完成状态
//     *
//     * @return true:是,false:否
//     * */
//    public boolean isRequestPending(int requestId){
//        return (pendingRequests.get(requestId,-1) == requestId);
//    }

    /**
     * 处理数据请求结果响应
     *
     * @param resultCode
     * @param resultData
     */
    private void handleResponse(int resultCode, Bundle resultData) {
        if (resultData != null) {
            int requestId = resultData.getInt(DataHandleService.EXTRA_REQUEST_ID, -1);
//            pendingRequests.delete(requestId);//清除请求忙碌状态
            String resultStr = resultData.getString(DataHandleService.EXTRA_BROADCAST_RESULT_STR, "");
            Intent resultBroadcast = new Intent(DataHandleService.ACTION_REQUEST_RESULT);
            resultBroadcast.putExtra(DataHandleService.EXTRA_REQUEST_ID, requestId);
            resultBroadcast.putExtra(DataHandleService.EXTRA_BROADCAST_RESULT_CODE, resultCode);
            resultBroadcast.putExtra(DataHandleService.EXTRA_BROADCAST_RESULT_STR, resultStr);
            MixApp.getContext().sendBroadcast(resultBroadcast);
            Logger.i(Logger.DATA_FLOW_TAG, "handleResponse requestId:" + requestId + ",resultCode:" + resultCode + ",result:" + resultStr);
        } else {
            Logger.e(Logger.DATA_FLOW_TAG, "handleResponse resultData is null,resultCode:" + resultCode);
        }
    }

    /**
     * 添加int型参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putInt(String key, int value) {
        mBundle.putInt(key, value);
        return this;
    }

    /**
     * 添加布尔型参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putBoolean(String key, boolean value) {
        mBundle.putBoolean(key, value);
        return this;
    }

    /**
     * 添加double型参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putDouble(String key, double value) {
        mBundle.putDouble(key, value);
        return this;
    }

    /**
     * 添加String参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putString(String key, String value) {
        mBundle.putString(key, value);
        return this;
    }

    /**
     * 添加float型参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putFloat(String key, float value) {
        mBundle.putFloat(key, value);
        return this;
    }

    /**
     * 添加long型参数到传递给DataHandleService的bundle中
     *
     * @param key   参数名
     * @param value 参数值
     */
    protected BaseDataManager putLong(String key, long value) {
        mBundle.putLong(key, value);
        return this;
    }

    /**
     * 开启DataHandleService数据处理
     */
    protected void startService() {
        mIntent.putExtra(DataHandleService.EXTRA_REQUEST_BUNDLE, mBundle);
        if (mIntent.getComponent() != null) {
            if (DataHandleService.SERVICE_NAME.equals(mIntent.getComponent().getClassName())) {
                try {//http://bbs.coloros.com/thread-174655-3-1.html
                    MixApp.getContext().startService(mIntent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
