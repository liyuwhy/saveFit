package com.fitmix.sdk.model.manager;

import com.fitmix.sdk.Config;

import java.util.List;

/**
 * 音乐数据,包括的数据接口有获取音乐列表等,用于开放与音乐有关的数据接口给UI层
 */
public class MusicDataManager extends BaseDataManager {

    /**
     * 本模块的ID编号
     */
    private static final int MODULE_ID = Config.MODULE_MUSIC;
//    private static MusicDataManager mInstance;

    /**
     * 私有
     */
    private MusicDataManager() {
    }

    /**
     * 获取音乐数据实例
     */
    public static MusicDataManager getInstance() {
//        if (mInstance == null) {
//            mInstance = new MusicDataManager();
//        }
//        return mInstance;
        return new MusicDataManager();
    }


    @Override
    public int generateRequestId(int interfaceId) {
        return MODULE_ID + interfaceId;
    }

    /**
     * 获取album列表
     *
     * @param requestType
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200001
     */
    public int getAlbumList(int requestType, boolean ignorePreCache) {
        int requestId = generateRequestId(1);
        makeRequest(requestId, ignorePreCache)
                .putInt("type", requestType)
                .startService();
        return requestId;
    }

    /**
     * 获取banner列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200002
     */
    public int getBannerList(boolean ignorePreCache) {
        int requestId = generateRequestId(2);
        makeRequest(requestId, ignorePreCache).startService();
        return requestId;
    }

    /**
     * 获取音乐列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200003
     */
    public int getMusicListFromServerBySceneAndIndex(int scene, int index, int type, int sortType, boolean ignorePreCache) {
        int requestId = generateRequestId(3);
        makeRequest(requestId, ignorePreCache)
                .putInt("scene", scene)
                .putInt("index", index)
                .putInt("type", type)
                .putInt("sortType", sortType)
                .startService();
        return requestId;
    }

    /**
     * 音乐或者取消收藏
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200004
     */
    public int favoriteMusicChange(int uid, int msuicId, boolean ignorePreCache) {
        int requestId = generateRequestId(4);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("musicId", msuicId)
                .startService();
        return requestId;
    }

    /**
     * 用户收藏音乐或者取消收藏id集合
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200005
     */
    public int favoriteMusicListChange(int uid, List<Integer> musicIdList, boolean ignorePreCache) {
        int requestId = generateRequestId(5);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putString("musicIdList", getStringFromList(musicIdList))
                .startService();
        return requestId;
    }

    private String getStringFromList(List<Integer> musicIdList) {
        if (musicIdList == null || musicIdList.size() <= 0)
            return null;
        StringBuilder muiscIDs = new StringBuilder();
        muiscIDs.append(musicIdList.get(0));
        for (int i = 1; i < musicIdList.size(); i++) {
            muiscIDs.append(",").append(musicIdList.get(i));
        }
        return muiscIDs.toString();
    }

    /**
     * 获取电台列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200006
     */
    public int getAlbumRadioList(int requestType, boolean ignorePreCache) {
        int requestId = generateRequestId(6);
        makeRequest(requestId, ignorePreCache)
                .putInt("type", requestType)
                .startService();
        return requestId;
    }

    /**
     * 获取电台详情列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200007
     */
    public int getRadioListFromServerBySceneAndIndex(int scene, int index, int type, int sortType, boolean ignorePreCache) {
        int requestId = generateRequestId(7);
        makeRequest(requestId, ignorePreCache)
                .putInt("scene", scene)
                .putInt("index", index)
                .putInt("type", type)
                .putInt("sortType", sortType)
                .startService();
        return requestId;
    }

    /**
     * 后去热词列表
     *
     * @param userId         用户id
     * @param ignorePreCache
     * @return requestId 200008
     */
    public int getKeyWordList(int userId, boolean ignorePreCache) {
        int requestId = generateRequestId(8);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", userId)
                .startService();
        return requestId;
    }

    /**
     * 搜索音乐列表
     *
     * @param index
     * @param bpm
     * @param scene
     * @param genre
     * @param duration
     * @param search         关键字
     * @param ignorePreCache
     * @return requestId 200009
     */
    public int searchMusic(int index, int bpm, int scene, int genre, int duration, String search, boolean ignorePreCache) {
        int requestId = generateRequestId(9);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", index)
                .putInt("bpm", bpm)
                .putInt("scene", scene)
                .putInt("genre", genre)
                .putInt("duration", duration)
                .putString("search", search)
                .startService();
        return requestId;
    }

    /**
     * 搜索音乐列表
     *
     * @param index
     * @param search         搜索词
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200009
     */
    public int searchMusic(int index, String search, boolean ignorePreCache) {
        int requestId = generateRequestId(9);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", index)
                .putString("search", search)
                .startService();
        return requestId;
    }

    /**
     * 获取推荐专辑详情列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200010
     */
    public int getRadioListFromServerByAlbumId(int mixAlbumId, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putInt("mixAlbumId", mixAlbumId)
                .startService();
        return requestId;
    }

    /**
     * 上传音乐试听
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200011
     */
    public int uploadMusicAudition(int musicID, boolean ignorePreCache) {
        int requestId = generateRequestId(11);
        makeRequest(requestId, ignorePreCache)
                .putInt("mid", musicID)
                .startService();
        return requestId;
    }

    /**
     * 根据id列表获取歌曲信息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200012
     */
    public int getMusicListInfo(List<Integer> musicID, boolean ignorePreCache) {
        StringBuilder stringBuilder = new StringBuilder();
        for (Integer integer : musicID) {
            stringBuilder.append(integer).append(",");
        }
        int requestId = generateRequestId(12);
        makeRequest(requestId, ignorePreCache)
                .putString("mids", stringBuilder.toString())
                .startService();
        return requestId;
    }

    /**
     * 获取推荐的音乐
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 200013
     */
    public int getRecommendMusic(boolean ignorePreCache) {
        int requestId = generateRequestId(13);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }
}
