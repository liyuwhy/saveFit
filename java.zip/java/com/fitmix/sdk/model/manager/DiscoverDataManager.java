package com.fitmix.sdk.model.manager;

import com.fitmix.sdk.Config;

/**
 * 发现数据,包括的数据接口有获取赛事列表等,用于开放与赛事有关的数据接口给UI层
 */
public class DiscoverDataManager extends BaseDataManager {

    /**
     * 本模块的ID编号
     */
    private static final int MODULE_ID = Config.MODULE_COMPETITION;
//    private static DiscoverDataManager mInstance;

    /**
     * 私有
     */
    private DiscoverDataManager() {
    }

    /**
     * 获取赛事数据实例
     */
    public static DiscoverDataManager getInstance() {
//        if(mInstance == null){
//            mInstance = new DiscoverDataManager();
//        }
//        return mInstance;
        return new DiscoverDataManager();
    }


    @Override
    public int generateRequestId(int interfaceId) {
        return MODULE_ID + interfaceId;
    }

//    /**
//     * 获取运动赛事列表
//     *
//     * @param index          列表页数
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     * @return requestId 500001
//     */
//    public int getCompetitionList(int index, boolean ignorePreCache) {
//        int requestId = generateRequestId(1);
//        makeRequest(requestId, ignorePreCache)
//                .putInt("index", index)
//                .startService();
//        return requestId;
//    }

    /**
     * 获取运动视频列表
     *
     * @param index          列表页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500002
     */
    public int getVideoList(int index, boolean ignorePreCache) {
        int requestId = generateRequestId(2);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取运动赛事列表
     *
     * @param index          列表页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500003
     */
    public int getCompetitionListForLoadMore(int index, boolean ignorePreCache) {
        int requestId = generateRequestId(3);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取运动视频列表
     *
     * @param index          列表页数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500004
     */
    public int getVideoListForLoadMore(int index, boolean ignorePreCache) {
        int requestId = generateRequestId(4);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", index)
                .startService();
        return requestId;
    }

    /**
     * 获取话题列表
     *
     * @param pageNo         列表页数
     * @param orderType      结果排序类型,1:根据添加时间排序,2:根据回答数排序,3:根据点赞数排序
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500005
     */
    public int getTopicList(int pageNo, int orderType, boolean ignorePreCache) {
        int requestId = generateRequestId(5);
        makeRequest(requestId, ignorePreCache)
                .putInt("index", pageNo)
                .putInt("orderType", orderType)
                .startService();
        return requestId;
    }

    /**
     * 根据话题编号,获取该话题的回答列表
     *
     * @param topicId        话题编号
     * @param orderType      结果排序类型,1:根据添加时间排序,2:根据回答数排序,3:根据点赞数排序,4:根据综合质量排序
     * @param pageNo         列表页数
     * @param getTheme       是否获取话题详情内容,0:否,1:是
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500006
     */
    public int getTopicAnswerList(int topicId, int orderType, int getTheme, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(6);
        makeRequest(requestId, ignorePreCache)
                .putInt("topicId", topicId)
                .putInt("orderType", orderType)
                .putInt("pageNo", pageNo)
                .putInt("getTheme", getTheme)
                .startService();
        return requestId;
    }

    /**
     * 根据话题编号或答案编号,获取该话题或答案的评论列表
     *
     * @param topicId        话题编号或答案编号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500007
     */
    public int getTopicDiscussList(int topicId, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(7);
        makeRequest(requestId, ignorePreCache)
                .putInt("topicId", topicId)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 搜索话题
     *
     * @param sSearch        搜索关键字
     * @param pageNo         页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500008
     */
    public int searchTopic(String sSearch, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(8);
        makeRequest(requestId, ignorePreCache)
                .putString("searchText", sSearch)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取我的回答列表
     *
     * @param answerPageNo   页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500009
     */
    public int getMyAnswerList(int answerPageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(9);
        makeRequest(requestId, ignorePreCache)
                .putInt("pageNo", answerPageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取我的提问列表
     *
     * @param questionPageNo 页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500010
     */

    public int getMyQuestionList(int questionPageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putInt("pageNo", questionPageNo)
                .startService();
        return requestId;
    }

    /**
     * 添加话题
     *
     * @param topicTitle     话题标题
     * @param contentKey     话题补充内容保存在MemExchange的key
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500011
     */
    public int addTopic(String topicTitle, String contentKey, boolean ignorePreCache) {
        int requestId = generateRequestId(11);
        makeRequest(requestId, ignorePreCache)
                .putString("title", topicTitle)
                .putString("contentKey", contentKey)
                .startService();
        return requestId;
    }

    /**
     * 添加话题答案
     *
     * @param topicId        话题编号
     * @param contentKey     答案内容保存在MemExchange的key
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500012
     */
    public int addTopicAnswer(int topicId, String contentKey, boolean ignorePreCache) {
        int requestId = generateRequestId(12);
        makeRequest(requestId, ignorePreCache)
                .putInt("parentThemeId", topicId)
                .putString("contentKey", contentKey)
                .startService();
        return requestId;
    }

    /**
     * 添加话题答案的评论
     *
     * @param answerId          答案编号
     * @param commentContentKey 评论内容保存在MemExchange的key
     * @param ignorePreCache    数据请求是否忽略之前的缓存结果
     * @param discussId         回复的讨论编号  回复时才用
     * @param discussUid        回复的用户编号  回复时才用
     * @return requestId 500013
     */
    public int addTopicAnswerDiscussToOne(int answerId, int discussId, int discussUid, String commentContentKey, boolean ignorePreCache) {
        int requestId = generateRequestId(13);
        makeRequest(requestId, ignorePreCache)
                .putInt("themeId", answerId)
                .putString("contentKey", commentContentKey)
                .putInt("discussId", discussId)
                .putInt("discussUid", discussUid)
                .startService();
        return requestId;
    }


    /**
     * 话题答案点赞
     *
     * @param answerId       答案编号
     * @param type           观点类型,1:点赞,0:中立不操作
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500014
     */
    public int likeTopicAnswer(int answerId, int type, boolean ignorePreCache) {
        int requestId = generateRequestId(14);
        makeRequest(requestId, ignorePreCache)
                .putInt("themeId", answerId)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 上传图片
     *
     * @param fileName       本地图片文件名
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500015
     */
    public int uploadImage(String fileName, boolean ignorePreCache) {
        int requestId = generateRequestId(15);
        makeRequest(requestId, ignorePreCache)
                .putString("fileName", fileName)
                .startService();
        return requestId;
    }

    /**
     * 根据话题答案编号,获取话题答案
     *
     * @param answerId       话题答案编号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500016
     */
    public int getTopicAnswerByAnswerId(int answerId, boolean ignorePreCache) {
        int requestId = generateRequestId(16);
        makeRequest(requestId, ignorePreCache)
                .putInt("answerId", answerId)
                .startService();
        return requestId;
    }

    /**
     * 编辑话题答案
     *
     * @param answerId       话题答案编号
     * @param contentKey     答案内容保存在MemExchange的key
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500017
     */
    public int editTopicAnswer(int answerId, String contentKey, boolean ignorePreCache) {
        int requestId = generateRequestId(17);
        makeRequest(requestId, ignorePreCache)
                .putInt("answerId", answerId)
                .putString("contentKey", contentKey)
                .startService();
        return requestId;
    }

    /**
     * 获取与自己相关的最新话题回答消息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500018
     */
    public int getNewAnswerMessage(boolean ignorePreCache) {
        int requestId = generateRequestId(18);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }

    /**
     * 获取与自己相关的最新话题讨论消息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500019
     */
    public int getNewDiscussMessage(boolean ignorePreCache) {
        int requestId = generateRequestId(19);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }

    /**
     * 获取精选话题列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500020
     */
    public int getHandPickTopicList(boolean ignorePreCache) {
        int requestId = generateRequestId(20);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }

    /**
     * 获取精选话题列表
     *
     * @param videoId        视频id
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500021
     */
    public int getVideoDetail(int videoId, boolean ignorePreCache) {
        int requestId = generateRequestId(21);
        makeRequest(requestId, ignorePreCache)
                .putInt("videoId", videoId)
                .startService();
        return requestId;
    }

    /**
     * 话题答案点赞
     *
     * @param discussId      评论答案编号
     * @param type           观点类型,1:点赞,0:中立不操作
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 500022
     */
    public int likeTopicDiscuss(int discussId, int type, boolean ignorePreCache) {
        int requestId = generateRequestId(22);
        makeRequest(requestId, ignorePreCache)
                .putInt("discussId", discussId)
                .putInt("type", type)
                .startService();
        return requestId;
    }

}
