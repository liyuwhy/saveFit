package com.fitmix.sdk.model.manager;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.view.activity.EmailBindActivity;
import com.fitmix.sdk.view.activity.PhoneBindActivity;

/**
 * 用户信息数据,包括的数据接口有用户登录,注册等,用于开放与用户信息有关的数据接口给UI层
 */
public class UserDataManager extends BaseDataManager {

    /**
     * 本模块的ID编号
     */
    private static final int MODULE_ID = Config.MODULE_USER;
//    private static UserDataManager mInstance;
    /**
     * 当前用户的用户编号,默认是匿名登录
     */
    private static int mUid = Config.ANONYMOUS_UID;

    /**
     * 私有
     */
    private UserDataManager() {
    }

    /**
     * 获取用户信息数据管理实例
     */
    public static UserDataManager getInstance() {
//        if (mInstance == null) {
//            synchronized (UserDataManager.class) {
//                if (mInstance == null) {
//                    mInstance = new UserDataManager();
//                }
//            }
//        }
//        Logger.i(Logger.DATA_FLOW_TAG, "UserDataManager-->getInstance:" + mInstance + ",threadId:" + Thread.currentThread().getId());
//        return mInstance;

//        UserDataManager userDataManager =  new UserDataManager();
//        Logger.i(Logger.DATA_FLOW_TAG, "UserDataManager-->getInstance:" + userDataManager + ",threadId:" + Thread.currentThread().getId());
//        return userDataManager;

        return new UserDataManager();

    }

    @Override
    public int generateRequestId(int interfaceId) {
        return MODULE_ID + interfaceId;
    }

    /**
     * 获取当前登录的用户ID
     */
    public static int getUid() {
        // 当用户uid为匿名时,需要查看是否由于内存回收引起
        if (mUid == Config.ANONYMOUS_UID) {
            mUid = PrefsHelper.with(MixApp.getContext(), Config.PREFS_USER)
                    .readInt(Config.SP_KEY_UID, Config.ANONYMOUS_UID);
        }
        return mUid;
    }

    /**
     * 保存当前登录的用户ID
     *
     * @param uid 当前登录的用户uid
     */
    public static void setUid(int uid) {
        mUid = uid;
        PrefsHelper.with(MixApp.getContext(), Config.PREFS_USER)
                .writeInt(Config.SP_KEY_UID, mUid);
    }


    /**
     * App初始化
     *
     * @param version        当前APP版本号
     * @param lan            app语言类型,ch:中文,en:英文
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100001
     */
    public int appInit(int version, String lan, boolean ignorePreCache) {
        int requestId = generateRequestId(1);
        makeRequest(requestId, ignorePreCache)
                .putInt("version", version)
                .putString("lan", lan)
                .startService();
        return requestId;
    }

    /**
     * App初始化,不忽略之前的缓存结果
     *
     * @param version 当前APP版本号
     * @param lan     app语言类型,ch:中文,en:英文
     * @return requestId 100001
     */
    public int appInit(int version, String lan) {
        return appInit(version, lan, true);
    }

    /**
     * 用户邮箱账号登录
     *
     * @param email          邮箱账号名
     * @param password       登录密码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100002
     */
    public int emailLogin(String email, String password, boolean ignorePreCache) {
        int requestId = generateRequestId(2);
        makeRequest(requestId, ignorePreCache)
                .putString("email", email)
                .putString("password", password)
                .startService();
        return requestId;
    }

    /**
     * 用户邮箱账号登录,不忽略之前的缓存结果
     *
     * @param email    邮箱账号名
     * @param password 登录密码
     * @return requestId 100002
     */
    public int emailLogin(String email, String password) {
        return emailLogin(email, password, false);
    }

    /**
     * QQ授权登录
     *
     * @param token          QQ授权登录的token
     * @param openid         乐享动 openId
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100003
     */
    public int qqLogin(String token, String openid, boolean ignorePreCache) {
        int requestId = generateRequestId(3);
        makeRequest(requestId, ignorePreCache)
                .putString("token", token)
                .putString("openid", openid)
                .startService();
        return requestId;
    }

    /**
     * QQ授权登录,不忽略之前的缓存结果
     *
     * @param token  QQ授权登录的token
     * @param openid 乐享动 openId
     * @return requestId 100003
     */
    public int qqLogin(String token, String openid) {
        return qqLogin(token, openid, false);
    }

    /**
     * 新浪微博授权登录
     *
     * @param token          新浪微博授权登录的token
     * @param openid         乐享动 openId
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100004
     */
    public int weiBoLogin(String token, String openid, boolean ignorePreCache) {
        int requestId = generateRequestId(4);
        makeRequest(requestId, ignorePreCache)
                .putString("token", token)
                .putString("openid", openid)
                .startService();
        return requestId;
    }

    /**
     * 新浪微博授权登录,不忽略之前的缓存结果
     *
     * @param token  新浪微博授权登录的token
     * @param openid 乐享动 openId
     * @return requestId 100004
     */
    public int weiBoLogin(String token, String openid) {
        return weiBoLogin(token, openid, false);
    }

    /**
     * 微信授权登录
     *
     * @param token          微信授权登录的token
     * @param openid         乐享动 openId
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100005
     */
    public int weiXinLogin(String token, String openid, boolean ignorePreCache) {
        int requestId = generateRequestId(5);
        makeRequest(requestId, ignorePreCache)
                .putString("token", token)
                .putString("openid", openid)
                .startService();
        return requestId;
    }

    /**
     * 微信授权登录,不忽略之前的缓存结果
     *
     * @param token  微信授权登录的token
     * @param openid 乐享动 openId
     * @return requestId 100005
     */
    public int weiXinLogin(String token, String openid) {
        return weiXinLogin(token, openid, false);
    }


    /**
     * 检测服务器上App最新版本信息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100006
     */
    public int checkAppVersion(boolean ignorePreCache) {
        int requestId = generateRequestId(6);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }


    /**
     * 检测服务器上App最新版本信息,不忽略之前的缓存结果
     *
     * @return requestId 100006
     */
    public int checkAppVersion() {
        return checkAppVersion(true);
    }

    /**
     * 个人信息修改,忽略之前的缓存结果
     *
     * @param name      姓名
     * @param male      性别,1:男,2:女
     * @param age       年龄
     * @param height    　身高
     * @param weight    　体重
     * @param language  　身高体重单位制量,1:公制,2:英制
     * @param signature 　签名
     * @param sFilename 上传的文件
     * @param stag      stag
     * @return requestId 100007
     */
    public int updateUserInfo(int id, String name, int male, int age, double height, double weight, int language, String signature, String sFilename, String stag) {
        return updateUserInfo(true, id, name, male, age, height, weight, language, signature, sFilename, stag);
    }

    /**
     * 个人信息修改
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @param name           姓名
     * @param male           性别,1:男,2:女
     * @param age            年龄
     * @param height         　身高
     * @param weight         　体重
     * @param language       　身高体重单位制量,1:公制,2:英制
     * @param signature      　签名
     * @param sFilename      上传的文件
     * @param stag           stag
     * @return requestId 100007
     */
    public int updateUserInfo(boolean ignorePreCache, int id, String name, int male, int age, double height, double weight, int language, String signature, String sFilename, String stag) {
        int requestId = generateRequestId(7);
        makeRequest(requestId, ignorePreCache)
                .putInt("id", id)
                .putString("name", name)
                .putInt("male", male)
                .putInt("age", age)
                .putDouble("height", height)
                .putDouble("weight", weight)
                .putInt("language", language)
                .putString("signature", signature)
                .putString("fileName", sFilename)
                .putString("tag", stag)
                .startService();
        return requestId;
    }


    /**
     * 绑定手机号时获取验证码
     *
     * @param mobileNumber   接收验证码的手机号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100010
     */
    public int getAuthCode(String mobileNumber, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putString("mobileNumber", mobileNumber)
                .startService();
        return requestId;
    }

    /**
     * 获取验证码(邮箱接收)
     *
     * @param email          接收验证码的邮箱
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100011
     */
    public int getEmailAuthCode(String email, boolean ignorePreCache) {
        int requestId = generateRequestId(11);
        makeRequest(requestId, ignorePreCache)
                .putString("email", email)
                .startService();
        return requestId;
    }


    /**
     * 修改密码
     *
     * @param sOldPassword   旧密码
     * @param sNewPassword   新密码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100012
     */
    public int changePassword(String sOldPassword, String sNewPassword, boolean ignorePreCache) {
        int requestId = generateRequestId(12);
        makeRequest(requestId, ignorePreCache)
                .putString("oldPwd", sOldPassword)
                .putString("nowPwd", sNewPassword)
                .startService();
        return requestId;
    }

    /**
     * 个人真实信息修改
     *
     * @param contestantName  真实姓名
     * @param gender          性别
     * @param age             年龄
     * @param identity        身份证号码
     * @param phoneNumber     手机号码
     * @param email           邮箱
     * @param province        所在省份
     * @param city            所在城市
     * @param address         所在详细地址
     * @param bloodType       血型
     * @param dressSize       衣服尺寸
     * @param emergencyName   紧急联系人姓名
     * @param emergencyNumber 紧急联系人手机号码
     * @param ignorePreCache  数据请求是否忽略之前的缓存结果
     * @return requestId 100013
     */
    public int modifyContestant(int uid, String contestantName, int gender,
                                int age, String identity,
                                String phoneNumber, String email, String province, String city,
                                String address, String bloodType, String dressSize, String emergencyName,
                                String emergencyNumber, boolean ignorePreCache) {
        int requestId = generateRequestId(13);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putString("contestantName", contestantName)
                .putInt("gender", gender)
                .putInt("age", age)
                .putString("identity", identity)
                .putString("phoneNumber", phoneNumber)
                .putString("email", email)
                .putString("province", province)
                .putString("city", city)
                .putString("address", address)
                .putString("bloodType", bloodType).putString("dressSize", dressSize).putString("emergencyName", emergencyName)
                .putString("emergencyNumber", emergencyNumber)
                .startService();
        return requestId;
    }

//    /**
//     * 邮箱注册
//     *
//     * @param email          邮箱账号
//     * @param name           昵称
//     * @param password       密码
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     * @return requestId 100020
//     */
//    public int emailRegister(String email, String name, String password, boolean ignorePreCache) {
//        int requestId = generateRequestId(20);
//        makeRequest(requestId, ignorePreCache)
//                .putString("email", email)
//                .putString("name", name)
//                .putString("password", password)
//                .startService();
//        return requestId;
//    }

    /**
     * 邮箱注册,V2.4.1之后新的邮箱注册方式
     *
     * @param email          邮箱账号
     * @param verifyCode     验证码
     * @param password       密码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100020
     */
    public int emailRegister(String email, String verifyCode, String password, boolean ignorePreCache) {
        int requestId = generateRequestId(20);
        makeRequest(requestId, ignorePreCache)
                .putString("email", email)
                .putString("verifyCode", verifyCode)
                .putString("password", password)
                .startService();
        return requestId;
    }

//    /**
//     * 手机注册
//     *
//     * @param mobileNumber
//     * @param password
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     * @return requestId 1000021
//     */
//    public int mobileRegister(String mobileNumber, String password, boolean ignorePreCache) {
//        int requestId = generateRequestId(21);
//        makeRequest(requestId, ignorePreCache)
//                .putString("mobileNumber", mobileNumber)
//                .putString("password", password)
//                .startService();
//        return requestId;
//    }

    /**
     * 手机注册,V2.4.1之后新的手机注册方式
     *
     * @param mobileNumber
     * @param password
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000021
     */
    public int mobileRegister(String mobileNumber, String verifyCode, String password, boolean ignorePreCache) {
        int requestId = generateRequestId(21);
        makeRequest(requestId, ignorePreCache)
                .putString("mobileNumber", mobileNumber)
                .putString("verifyCode", verifyCode)
                .putString("password", password)
                .startService();
        return requestId;
    }

//    /**
//     * 邮箱找回密码
//     *
//     * @param email          接收密码的邮箱账号
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     * @return requestId 100022
//     */
//    public int forgetEmailPassword(String email, boolean ignorePreCache) {
//        int requestId = generateRequestId(22);
//        makeRequest(requestId, ignorePreCache)
//                .putString("email", email)
//                .startService();
//        return requestId;
//    }

    /**
     * 邮箱找回密码,V2.4.1之后新方式
     *
     * @param email          接收密码的邮箱账号
     * @param verifyCode     验证码
     * @param newPwd         新密码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100022
     */
    public int forgetEmailPassword(String email, String verifyCode, String newPwd, boolean ignorePreCache) {
        int requestId = generateRequestId(22);
        makeRequest(requestId, ignorePreCache)
                .putString("email", email)
                .putString("verifyCode", verifyCode)
                .putString("newPwd", newPwd)
                .startService();
        return requestId;
    }

    /**
     * 忘记手机密码
     *
     * @param mobileNumber   手机号
     * @param verifyCode     验证码
     * @param newPassword    密码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100023
     */
    public int forgetMobilePassword(String mobileNumber, String verifyCode, String newPassword, boolean ignorePreCache) {
        int requestId = generateRequestId(23);
        makeRequest(requestId, ignorePreCache)
                .putString("mobileNumber", mobileNumber)
                .putString("verifyCode", verifyCode)
                .putString("newPassword", newPassword)
                .startService();
        return requestId;
    }

    /**
     * 向后台服务器发送用户统计数据,不考虑之前的缓存结果
     *
     * @param uid     用户uid
     * @param musicId 音乐id
     * @param type    信息类型,1:音乐,2:运动,3:直播
     * @param lng     经度
     * @param lat     纬度
     * @return requestId 100024
     */
    public int reportUserBehavior(int uid, int musicId, int type, double lng, double lat) {
        int requestId = generateRequestId(24);
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putInt("musicId", musicId)
                .putInt("type", type)
                .putDouble("lng", lng)
                .putDouble("lat", lat)
                .startService();
        return requestId;
    }

    /**
     * 修改消息状态
     *
     * @param pushType   消息类型
     * @param businessId 如果是俱乐部消息就传俱乐部ID
     * @return requestId 100025
     */
    public int switchMessageState(int pushType, int businessId) {
        int requestId = generateRequestId(25);
        makeRequest(requestId, true)
                .putInt("pushType", pushType)
                .putInt("businessId", businessId)
                .startService();
        return requestId;
    }

    /**
     * 检测服务器上心率耳机固件最新版本信息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000028
     */
    public int checkHRFirmwareVersion(String version, boolean ignorePreCache) {
        int requestId = generateRequestId(28);
        makeRequest(requestId, ignorePreCache)
                .putString("version", version)
                .startService();
        return requestId;
    }

    /**
     * 检测服务器上手表固件最新版本信息
     *
     * @param version        手表本地当前版本号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000029
     */
    public int watchFirmwareVersion(String version, boolean ignorePreCache) {
        int requestId = generateRequestId(29);
        makeRequest(requestId, ignorePreCache)
                .putString("version", version)
                .putString("firmwareType", "21")
                .startService();
        return requestId;
    }


    /**
     * 账号解绑,
     *
     * @param type           解绑类型,
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 邮箱解绑:100030,QQ解绑:100031,手机解绑:100032,微博解绑:100033,微信解绑:100034
     */
    public int unBindString(int type, boolean ignorePreCache) {

        int requestId = -1;
        if (type == Config.UNBIND_TYPE_BY_EMAIL - 5) {
            requestId = generateRequestId(30);
        } else if (type == Config.UNBIND_TYPE_BY_QQ - 5) {
            requestId = generateRequestId(31);
        } else if (type == Config.UNBIND_TYPE_BY_PHONE - 5) {
            requestId = generateRequestId(32);
        } else if (type == Config.UNBIND_TYPE_BY_SINA - 5) {
            requestId = generateRequestId(33);
        } else if (type == Config.UNBIND_TYPE_BY_WECHAT - 5) {
            requestId = generateRequestId(34);
        }
        makeRequest(requestId, ignorePreCache)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 手机绑定或者邮箱绑定,（绑定不带密码参数）
     *
     * @param bindingContent
     * @param bindingName
     * @param type           绑定类型
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 邮箱绑定:100035,手机绑定:100036
     */
    public int userBind(String bindingContent, String bindingName, int type, boolean ignorePreCache) {
        int requestId = -1;
        if (type == EmailBindActivity.BIND_TYPE_BY_EMAIL) {
            requestId = generateRequestId(35);
        } else if (type == PhoneBindActivity.BIND_TYPE_BY_PHONE) {
            requestId = generateRequestId(36);
        }
        makeRequest(requestId, ignorePreCache)
                .putString("bindingContent", bindingContent)
                .putString("bindingName", bindingName)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 手机绑定或者邮箱绑定,（绑定带密码参数）
     *
     * @param bindingContent
     * @param bindingName
     * @param type
     * @param password
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 邮箱绑定:100037,手机绑定:100038
     */
    public int userBindWithPWD(String bindingContent, String bindingName, int type, String password, boolean ignorePreCache) {
        int requestId = -1;
        if (type == EmailBindActivity.BIND_TYPE_BY_EMAIL_WITH_PWD) {
            requestId = generateRequestId(37);
            type = EmailBindActivity.BIND_TYPE_BY_EMAIL;
        } else if (type == PhoneBindActivity.BIND_TYPE_BY_PHONE_WITH_PWD) {
            requestId = generateRequestId(38);
            type = PhoneBindActivity.BIND_TYPE_BY_PHONE;
        }
        makeRequest(requestId, ignorePreCache)
                .putString("bindingContent", bindingContent)
                .putString("bindingName", bindingName)
                .putInt("type", type)
                .putString("password", password)
                .startService();
        return requestId;
    }

    /**
     * 获取绑定的字符串
     *
     * @param bindingContent 微信 微博 QQ （openid）,或者是手机或邮箱,如果是手机注册,则不可以绑定手机 等
     * @param bindingName    绑定的名称：第三方平台 给 用户姓名,手机 邮箱 直接填写手机 或邮箱
     * @param type           1、app注册 2、QQ 注册 3、微信注册  4、微博注册 5、手机
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId QQ绑定:100039,微博绑定:100040,微信绑定:100041
     */
    public int getBind(String bindingContent, String bindingName, int type, boolean ignorePreCache) {
        int requestId = -1;
        if (type == Config.BIND_TYPE_BY_QQ) {
            requestId = generateRequestId(39);
        } else if (type == Config.BIND_TYPE_BY_SINA) {
            requestId = generateRequestId(40);
        } else if (type == Config.BIND_TYPE_BY_WECHAT) {
            requestId = generateRequestId(41);
        }
        makeRequest(requestId, ignorePreCache)
                .putString("bindingContent", bindingContent)
                .putString("bindingName", bindingName)
                .putInt("type", type)
                .startService();
        return requestId;
    }

    /**
     * 查找用户设备信息,例如用户购买的手表、耳机等等
     *
     * @param uid            乐享动uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000047
     */
    public int findUserDevices(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(47);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .startService();
        return requestId;
    }

    /**
     * 上传设备信息给后台
     *
     * @param uid            乐享动uid
     * @param type           设备类型,1:手表
     * @param info           设备其它补充信息,json字符串
     * @param key            设备唯一标识属性,用于查询与修改目,前规则为uid_产品系列名_chipid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000048
     */
    public int uploadDeviceInfo(int uid, int type, String info, String key, boolean ignorePreCache) {
        int requestId = generateRequestId(48);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", type)
                .putString("info", info)
                .putString("key", key)
                .startService();
        return requestId;
    }


    /**
     * 删除设备信息
     *
     * @param uid            乐享动uid
     * @param type           设备类型,1:手表
     * @param key            设备唯一标识属性，用于查询与修改
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000049
     */
    public int deleteDeviceInfo(int uid, int type, String key, boolean ignorePreCache) {
        int requestId = generateRequestId(49);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", type)
                .putString("key", key)
                .startService();
        return requestId;
    }

    /**
     * 获取用户信息,如金币数量等
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100050
     */
    public int getUserAccountInfo(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(50);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .startService();
        return requestId;
    }


    /**
     * 获取用户金币明细记录
     *
     * @param uid            用户uid
     * @param pageNo         分页页码,大于等于1
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100051
     */
    public int getUserCoinRecord(int uid, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(51);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 完成任务接口
     *
     * @param uid            用户uid
     * @param taskType       任务类型 0:每日任务,1:一次性任务(荣誉任务),2:等级任务
     * @param taskKey        任务类型键值,比如"EVERY_DAY_SIGN_IN":表示今日签到,参考{@link Config }金币任务部分
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100052
     */
    public int finishTask(int uid, int taskType, String taskKey, boolean ignorePreCache) {
        int requestId = generateRequestId(52);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", taskType)
                .putString("taskKey", taskKey)
                .startService();
//        Logger.i(Logger.DATA_FLOW_TAG,"finishTask taskType:"+taskType +",taskKey:"+taskKey);
        return requestId;
    }

    /**
     * 获取流米流量套餐兑换信息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100053
     */
    public int getLiuMiProduct(boolean ignorePreCache) {
        int requestId = generateRequestId(53);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }

    /**
     * 兑换流量套餐
     *
     * @param uid            用户uid
     * @param phone          用户手机号码
     * @param productId      流量兑换套餐ID
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100054
     */
    public int exchange(int uid, String phone, int productId, boolean ignorePreCache) {
        int requestId = generateRequestId(54);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("productId", productId)
                .putString("phone", phone)
                .startService();
        return requestId;
    }

    /**
     * 获取所有任务列表
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100055
     */
    public int getAllTaskList(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(55);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", -1)//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
                .startService();
        return requestId;
    }

    /**
     * 获取今日任务列表
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100056
     */
    public int getTodayTaskList(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(56);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", 0)//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
                .startService();
        return requestId;
    }

    /**
     * 获取荣誉任务列表
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100057
     */
    public int getHonorTaskList(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(57);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", 1)//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
                .startService();
        return requestId;
    }

    /**
     * 获取等级任务列表
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100058
     */
    public int getLevelTaskList(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(58);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("type", 2)//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
                .startService();
        return requestId;
    }

    /**
     * 完成每日分享音乐金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100059
     */
    public int finishShareMixCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(59);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_EVERYDAY)
                .putString("taskKey", Config.COIN_TASK_SHARE_MIX_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成每日分享运动视频金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100060
     */
    public int finishShareVideoCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(60);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_EVERYDAY)
                .putString("taskKey", Config.COIN_TASK_SHARE_VIDEO_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成每日分享运动记录金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100061
     */
    public int finishShareRecordCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(61);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_EVERYDAY)
                .putString("taskKey", Config.COIN_TASK_SHARE_RECORD_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成每日播放音乐金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100062
     */
    public int finishPlayMixCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(62);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_EVERYDAY)
                .putString("taskKey", Config.COIN_TASK_PLAY_MIX_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成邮箱绑定或注册金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100063
     */
    public int finishEmailBindCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(63);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_ONCE)
                .putString("taskKey", Config.COIN_TASK_EMAIL_BIND_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成手机绑定或注册金币任务接口
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100064
     */
    public int finishPhoneBindCoinTask(int uid, boolean ignorePreCache) {
        int requestId = generateRequestId(64);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", Config.COIN_TASK_TYPE_ONCE)
                .putString("taskKey", Config.COIN_TASK_PHONE_BIND_KEY)
                .startService();
        return requestId;
    }

    /**
     * 完成分享流量兑换金币任务
     *
     * @param uid            用户uid
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100065
     */
    public int finishShareExchangeCoinTask(int uid, String orderNo, boolean ignorePreCache) {
        int requestId = generateRequestId(65);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putInt("taskType", 3)
                .putString("taskKey", Config.COIN_TASK_SHARE_FLOW)
                .putString("verifyId", orderNo)
                .startService();
        return requestId;
    }

    /**
     * 浏览个人主页
     *
     * @param targetUid 目标用户uid
     * @return requestId 100066
     */
    public int browseHomePage(int targetUid, boolean ignorePreCache) {
        int requestId = generateRequestId(66);
        makeRequest(requestId, ignorePreCache)
                .putInt("targetUid", targetUid)
                .startService();
        return requestId;
    }

    /**
     * 更新app的活跃状态
     *
     * @param active         app活跃状态,0:app休眠,1:app活跃
     * @param deviceToken    信鸽deviceToken
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100067
     */
    public int uploadDeviceStatus(int active, String deviceToken, boolean ignorePreCache) {
        int requestId = generateRequestId(67);
        makeRequest(requestId, ignorePreCache)
                .putInt("active", active)
                .putString("deviceToken", deviceToken)
                .startService();
        return requestId;
    }

    /**
     * 发送私信
     *
     * @param targetUid 目标用户uid
     * @param content   私信内容
     * @return requestId 1000068
     */
    public int sendUserPrivateMsg(int targetUid, String content, boolean ignorePreCache) {
        int requestId = generateRequestId(68);
        makeRequest(requestId, ignorePreCache)
                .putInt("targetUid", targetUid)
                .putString("content", content)
                .startService();
        return requestId;
    }

    /**
     * 查询私信列表
     *
     * @param page 页数
     * @return requestId 1000069
     */
    public int getUserPrivateMsgList(int page, boolean ignorePreCache) {
        int requestId = generateRequestId(69);
        makeRequest(requestId, ignorePreCache)
                .putInt("page", page)
                .startService();
        return requestId;
    }

    /**
     * 获取分享兑换流量结果金币任务信息
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100070
     */
    public int getShareFlowExchangeTask(boolean ignorePreCache) {
        int requestId = generateRequestId(70);
        makeRequest(requestId, ignorePreCache)
                .putString("taskKey", Config.COIN_TASK_SHARE_FLOW)
                .startService();
        return requestId;
    }

    /**
     * 查询用户通知列表
     *
     * @return requestId 1000071
     */
    public int getUserNoticeList(boolean ignorePreCache) {
        int requestId = generateRequestId(71);
        makeRequest(requestId, ignorePreCache)
                .startService();
        return requestId;
    }

    /**
     * 读取用户通知消息
     *
     * @return requestId 1000075
     */
    public int readUserNoticeMsg(int id, boolean ignorePreCache) {
        int requestId = generateRequestId(75);
        makeRequest(requestId, ignorePreCache)
                .putInt("id", id)
                .startService();
        return requestId;
    }

    /**
     * 查询私信列表详情
     *
     * @param groupId 群组编号
     * @return requestId 1000072
     */
    public int getUserPrivateMsgInfo(int groupId, boolean ignorePreCache) {
        int requestId = generateRequestId(72);
        makeRequest(requestId, ignorePreCache)
                .putInt("groupId", groupId)
                .startService();
        return requestId;
    }

    /**
     * 删除私信
     *
     * @param groupId 群组编号
     * @return requestId 1000073
     */
    public int deleteUserPrivateMsg(int groupId, boolean ignorePreCache) {
        int requestId = generateRequestId(73);
        makeRequest(requestId, ignorePreCache)
                .putInt("groupId", groupId)
                .startService();
        return requestId;
    }

    /**
     * 屏蔽用户
     *
     * @param groupId    群组编号
     * @param handleType 关系类型 1 黑名单  0 正常关系
     * @return requestId 1000074
     */
    public int setUserPrivateMsgReject(int groupId, int handleType, boolean ignorePreCache) {
        int requestId = generateRequestId(74);
        makeRequest(requestId, ignorePreCache)
                .putInt("groupId", groupId)
                .putInt("handleType", handleType)
                .startService();
        return requestId;
    }

    /**
     * 检测服务器上手表阿波罗固件最新版本信息
     *
     * @param version        手表本地当前阿波罗版本号
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 1000080
     */
    public int watchApolloVersion(String version, boolean ignorePreCache) {
        int requestId = generateRequestId(80);
        makeRequest(requestId, ignorePreCache)
                .putString("version", version)
                .putString("firmwareType", "22")
                .startService();
        return requestId;
    }

    /**
     * 获取加密公钥
     *
     * @param url            加密公钥地址
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 100100
     */
    public int getPublicKey(String url, boolean ignorePreCache) {
        int requestId = generateRequestId(100);
        makeRequest(requestId, ignorePreCache)
                .putString("url", url)
                .startService();
        return requestId;
    }

    /**
     * 获取彩蛋信息
     *
     * @param cityName       所在城市
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 获取彩蛋信息,100200
     */
    public int getSurpriseInfo(String cityName, boolean ignorePreCache) {
        int requestId = generateRequestId(200);
        makeRequest(requestId, ignorePreCache)
                .putString("cityName", cityName)
                .startService();
        return requestId;
    }

    /**
     * 上传手机信息
     *
     * @param deviceToken    友盟设备token
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果e
     * @return requestId 上传设备信息 100201
     */
    public int uploadUserDeviceInfo(String deviceToken, boolean ignorePreCache) {
        int requestId = generateRequestId(201);
        makeRequest(requestId, ignorePreCache)
                .putString("deviceToken", deviceToken)
                .startService();
        return requestId;
    }

    /**
     * 获取城市天气
     *
     * @param location       所在城市经纬度,格式为 经度,纬度
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 获取城市天气,100202
     */
    public int getCityWeather(String location, boolean ignorePreCache) {
        int requestId = generateRequestId(202);
        makeRequest(requestId, ignorePreCache)
                .putString("location", location)
                .startService();
        return requestId;
    }


    /**
     *  上传手表传送过来的错误日志
     * @param uid  用户id
     * @param chipId  手表可以
     * @param fileName
     * @return
     */
    public int uploadUserErrorLog(String uid,String chipId,String fileName){
         int requestId = generateRequestId(203);
         makeRequest(requestId)
                 .putString("uid",uid)
                 .putString("chipId",chipId)
                 .putString("filaName",fileName)
                 .startService();
         return requestId;
    }


    /**
     * 在数据请求状态结果表(DataReqStatus)中,清空指定数据请求编号的结果字段(result),
     * 注意:这个请求不会改变数据请求状态结果表中的有效期
     *
     * @param requestId 要清空结果字段的数据请求编号
     * @return requestId 101000
     */
    public int emptyDataReqResult(int requestId) {
        int reqId = generateRequestId(1000);
        makeRequest(reqId)
                .putInt("requestId", requestId)
                .startService();
        return requestId;
    }

    /**
     * 在数据请求状态结果表(DataReqStatus)中,更改指定数据请求编号的结果有效期字段(expired)
     *
     * @param requestId 要清空结果字段的数据请求编号
     * @param expired   要重新设置的结果有效期时间戳
     * @return requestId 101001
     */
    public int setDataReqExpired(int requestId, long expired) {
        int reqId = generateRequestId(1001);
        makeRequest(reqId)
                .putInt("requestId", requestId)
                .putLong("expired", expired)
                .startService();
        return requestId;
    }


}
