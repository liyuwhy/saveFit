package com.fitmix.sdk.model.manager;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.SkipLogInfo;

/**
 * 运动数据,包括的数据接口有获取运动记录等,用于开放与运动有关的数据接口给UI层
 */
public class SportDataManager extends BaseDataManager {

    /**
     * 本模块的ID编号
     */
    private static final int MODULE_ID = Config.MODULE_SPORT;
//    private static SportDataManager mInstance;

    /**
     * 私有
     */
    private SportDataManager() {
    }

    /**
     * 获取运动数据实例
     */
    public static SportDataManager getInstance() {
//        if (mInstance == null) {
//            mInstance = new SportDataManager();
//        }
//        return mInstance;
        return new SportDataManager();
    }

    @Override
    public int generateRequestId(int interfaceId) {
        return MODULE_ID + interfaceId;
    }

    /**
     * 上传今日步数到微信运动
     *
     * @param unionId        用户的微信unionId
     * @param openId         乐享动APP在微信开发者平台的openId
     * @param todaySteps     用户今日步数
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 300001
     */
    public int setWeChatTodaySteps(String unionId, String openId, int todaySteps, boolean ignorePreCache) {
        int requestId = generateRequestId(1);
        makeRequest(requestId, ignorePreCache)
                .putString("unionid", unionId)
                .putString("openid", openId)
                .putInt("step", todaySteps)
                .startService();
        return requestId;
    }


    /**
     * 从后台服务器获取用户历史跑步记录
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 300002
     */
    public int getHistoryRunRecords(int uid, long lastUpdateTime, boolean ignorePreCache) {
        int requestId = generateRequestId(2);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("lastUpdateTime", lastUpdateTime)
                .startService();
        return requestId;
    }

    /**
     * 从后台服务器获取用户历史跑步记录,不忽略之前的缓存结果
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @return requestId 300002
     */
    public int getHistoryRunRecords(int uid, long lastUpdateTime) {
        return getHistoryRunRecords(uid, lastUpdateTime, false);
    }

    /**
     * 分享跑步记录,统一忽略之前的缓存结果
     *
     * @param startTime 要分享的跑步记录,运动开始时间,单位为毫秒
     * @return requestId 300003
     */
    public int shareRunRecord(long startTime) {
        int requestId = generateRequestId(3);
        makeRequest(requestId, true)
                .putLong("startTime", startTime)
                .startService();
        return requestId;
    }

//    /**
//     * 添加运动记录到后台服务器,V2.3.8之后不再使用
//     *
//     * @param sportRecord    要添加的运动记录
//     * @param files          与运动记录一起要上传的所有本地文件(多个文件之间用英文逗号隔开)
//     * @param fileTags       与运动记录一起要上传的所有本地文件标签(多个标签之间用英文逗号隔开),数量和顺序需要与files保持一致
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     * @return requestId 300004
//     */
//    public int addSportRecord(RunLogInfo sportRecord, String files, String fileTags, boolean ignorePreCache) {
//        int requestId = generateRequestId(4);
//        makeRequest(requestId, ignorePreCache)
//                .putInt("uid", sportRecord.getUid())
//                .putInt("type", sportRecord.getType())
//                .putInt("mode", sportRecord.getMode())
//                .putInt("locationType", sportRecord.getLocationType())
//                .putInt("bpm", sportRecord.getBpm())
//                .putInt("bpmMatch", sportRecord.getBpmMatch())
//                .putInt("step", sportRecord.getStep())
//                .putLong("calorie", sportRecord.getCalorie())
//                .putLong("runTime", sportRecord.getRunTime())
//                .putLong("startTime", sportRecord.getStartTime())
//                .putLong("endTime", sportRecord.getEndTime())
//                .putLong("distance", sportRecord.getDistance())
//                .putDouble("startLng", sportRecord.getStartLng())
//                .putDouble("startLat", sportRecord.getStartLat())
//                .putDouble("endLng", sportRecord.getEndLng())
//                .putDouble("endLat", sportRecord.getEndLat())
//                .putString("files", files)
//                .putString("fileTags", fileTags)
//                .startService();
//        return requestId;
//    }
//
//    /**
//     * 添加运动记录到后台服务器,不忽略之前的缓存结果,V2.3.8之后不再使用
//     *
//     * @param sportRecord 要添加的运动记录
//     * @param files       与运动记录一起要上传的所有本地文件(多个文件之间用英文逗号隔开)
//     * @param fileTags    与运动记录一起要上传的所有本地文件标签(多个标签之间用英文逗号隔开),数量和顺序需要与files保持一致
//     * @return requestId 300004
//     */
//    public int addSportRecord(RunLogInfo sportRecord, String files, String fileTags) {
//        return addSportRecord(sportRecord, files, fileTags, false);
//    }

    /**
     * 删除后台服务器上的跑步记录,统一忽略之前的缓存结果
     *
     * @param uid          跑步记录对应的用户uid
     * @param runStartTime 跑步记录的开始时间,单位为毫秒
     * @return requestId 300005
     */
    public int deleteRunRecord(int uid, long runStartTime) {
        int requestId = generateRequestId(5);
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putLong("runStartTime", runStartTime)
                .startService();
        return requestId;
    }

    /**
     * 同步步数到QQ运动
     *
     * @param access_token 同步到的用户token
     * @param openid       同步到的用户openid
     * @param log          跑步信息
     * @return requestId 300006
     */
    public int syncToQQSport(String access_token, String openid, RunLogInfo log) {
        int requestId = generateRequestId(6);
        makeRequest(requestId, true)
                .putString("access_token", access_token)
                .putString("openid", openid)
                .putLong("time", log.getEndTime() / 1000)
                .putLong("distance", log.getDistance())
                .putInt("steps", log.getStep())
                .putLong("duration", log.getRunTime())
                .putLong("calories", log.getCalorie())
                .startService();
        return requestId;
    }

    /**
     * 小清新方式分享跑步记录,统一忽略之前的缓存结果
     *
     * @param uid      用户编号
     * @param distance 运动距离,单位为米
     * @param runTime  运动时长,单位为秒
     * @param step     运动步数
     * @param bpm      运动步频,单位公里/分钟
     * @param calorie  消耗卡路里,单位大卡
     * @return requestId 300007
     */
    public int shareRunRecordLite(int uid, long distance, long runTime, long step, long bpm, long calorie) {
        int requestId = generateRequestId(7);
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putLong("distance", distance)
                .putLong("runTime", runTime)
                .putLong("step", step)
                .putLong("bpm", bpm)
                .putLong("calorie", calorie)
                .startService();
        return requestId;
    }

    /**
     * 获得语音包的列表信息
     *
     * @return requestId 300008
     */
    public int getVoicePackageInfo(int voiceType) {
        int requestId = generateRequestId(8);
        makeRequest(requestId, true)
                .putInt("voiceType", voiceType)
                .startService();
        return requestId;
    }


    /**
     * 获得语音包下载的链接地址URL信息
     *
     * @return requestId 300009
     */
    public int getVoicePackageUrlInfo(int voiceId) {
        int requestId = generateRequestId(9);
        makeRequest(requestId, true)
                .putInt("voiceId", voiceId)
                .startService();
        return requestId;
    }


    /**
     * 添加跳绳运动记录到后台服务器
     *
     * @param skipLogInfo    要添加的跳绳运动记录
     * @param files          与跳绳运动记录一起要上传的所有本地文件(多个文件之间用英文逗号隔开)
     * @param fileTags       与跳绳运动记录一起要上传的所有本地文件标签(多个标签之间用英文逗号隔开),数量和顺序需要与files保持一致
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 300010
     */
    public int addSkipSportRecord(SkipLogInfo skipLogInfo, String files, String fileTags, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", skipLogInfo.getUid())
                .putInt("type", 2)
                .putInt("bpm", skipLogInfo.getBpm())
                .putInt("bpmMatch", skipLogInfo.getBpmMatch())
                .putInt("skipNumber", skipLogInfo.getSkipNumber())
                .putLong("calorie", (int) skipLogInfo.getCalorie())
                .putLong("runTime", skipLogInfo.getSkipTime())
                .putLong("startTime", skipLogInfo.getStartTime())
                .putLong("endTime", skipLogInfo.getEndTime())
                .putString("files", files)
                .putString("fileTags", fileTags)
                .startService();
        return requestId;
    }

    /**
     * 添加跳绳运动记录到后台服务器
     *
     * @param skipLogInfo    要添加的跳绳运动记录
     * @param files          与跳绳运动记录一起要上传的所有本地文件(多个文件之间用英文逗号隔开)
     * @param fileTags       与跳绳运动记录一起要上传的所有本地文件标签(多个标签之间用英文逗号隔开),数量和顺序需要与files保持一致
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 300010
     */
    public int addSkipSportRecordWithHeartRate(SkipLogInfo skipLogInfo, String files, String fileTags, boolean ignorePreCache) {
        int requestId = generateRequestId(10);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", skipLogInfo.getUid())
                .putInt("type", 2)
                .putInt("bpm", skipLogInfo.getBpm())
                .putInt("bpmMatch", skipLogInfo.getBpmMatch())
                .putInt("skipNumber", skipLogInfo.getSkipNumber())
                .putLong("runTime", skipLogInfo.getSkipTime())
                .putLong("startTime", skipLogInfo.getStartTime())
                .putLong("endTime", skipLogInfo.getEndTime())
                .putLong("calorie", (long) skipLogInfo.getCalorie())
                .putDouble("heartRateAvg", skipLogInfo.getHeartRateAvg())
                .putDouble("maxHeartRate", skipLogInfo.getMaxHeartRate())
                .putDouble("minHeartRate", skipLogInfo.getMinHeartRate())
                .putDouble("consumptionSpendTime", skipLogInfo.getConsumptionSpendTime())
                .putString("files", files)
                .putString("fileTags", fileTags)
                .startService();
        return requestId;
    }

    /**
     * 删除后台服务器上的跳绳记录,统一忽略之前的缓存结果
     *
     * @param uid           跳绳记录对应的用户uid
     * @param skipStartTime 跳绳记录的开始时间,单位为毫秒
     * @return requestId 300011
     */
    public int deleteSkipRecord(int uid, long skipStartTime) {
        int requestId = generateRequestId(11);
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putLong("skipStartTime", skipStartTime)
                .startService();
        return requestId;
    }

    /**
     * 从后台服务器获取用户历史跳绳记录,不忽略之前的缓存结果
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @return requestId 300012
     */
    public int getHistorySkipRecords(int uid, long lastUpdateTime) {
        return getHistorySkipRecords(uid, lastUpdateTime, false);
    }

    /**
     * 从后台服务器获取用户历史跳绳记录
     *
     * @param uid            用户uid
     * @param lastUpdateTime 最近一次获取记录的时间戳,用于减少返回的数据量大小
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 300012
     */
    public int getHistorySkipRecords(int uid, long lastUpdateTime, boolean ignorePreCache) {
        int requestId = generateRequestId(12);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("lastUpdateTime", lastUpdateTime)
                .startService();
        return requestId;
    }

    /**
     * 分享跳绳记录,统一忽略之前的缓存结果
     *
     * @param startTime 要分享的跳绳记录,跳绳开始时间,单位为毫秒
     * @param file      要分享的跳绳记录,截屏本地文件
     * @param fileTag   file 标签字段
     * @return requestId 300013
     */
    public int shareSkipRecord(long startTime, String file, String fileTag) {
        int requestId = generateRequestId(13);
        makeRequest(requestId, true)
                .putLong("startTime", startTime)
                .putString("file", file)
                .putString("fileTag", fileTag)
                .startService();
        return requestId;
    }

    /**
     * 上传静息心率记录
     *
     * @param uid          用户uid
     * @param heartRateVal
     * @param detectTime
     * @return requestId 300015
     */
    public int uploadRestHeartRate(int uid, int heartRateVal, long detectTime) {
        int requestId = generateRequestId(15);
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putInt("heartRateVal", heartRateVal)
                .putLong("detectTime", detectTime)
                .startService();
        return requestId;
    }

    /**
     * 获取全部静息心率记录的列表
     *
     * @param uid 用户uid
     * @return requestId 300016
     */
    public int getAllRestHeartRateHistory(int uid) {
        int requestId = generateRequestId(16);
        //index仅仅在分页获取时有意义
        makeRequest(requestId, true)
                .putInt("uid", uid)
                .putInt("index", 0)
                .putInt("isAll", 1)
                .startService();
        return requestId;
    }

    /**
     * 向后台上传用户传感器异常错误日志
     *
     * @param error 自定义的错误日志
     * @param other 错误简述
     * @return requestId 300017
     */
    public int uploadSensorAbnormalError(String error, String other) {
        int requestId = generateRequestId(17);
        makeRequest(requestId, true)
                .putString("content", error)
                .putString("other", other)
                .startService();
        return requestId;
    }

    /**
     * 生成训练计划
     *
     * @param runDistance     计划目标
     * @param planTime        计划开始时间
     * @param competitionTime 比赛时间
     * @param projectTime     选择的能跑项目用时
     * @param runProject      选择的能跑项目
     * @param gender          性别
     * @param age             年龄
     * @return requestId 300030
     */
    public int createTrainingPlan(int runDistance, long planTime, long competitionTime, long projectTime, int runProject, int gender, int age, boolean ignorePreCache) {
        int requestId = generateRequestId(30);
        makeRequest(requestId, ignorePreCache)
                .putInt("runDistance", runDistance)
                .putLong("competitionTime", competitionTime)
                .putLong("planTime", planTime)
                .putLong("projectTime", projectTime)
                .putInt("runProject", runProject)
                .putInt("gender", gender)
                .putInt("age", age)
                .startService();
        return requestId;
    }

    /**
     * 获取进行中的计划
     *
     * @return requestId 300031
     */
    public int getTrainingPlan() {
        int requestId = generateRequestId(31);
        makeRequest(requestId, true)
                .startService();
        return requestId;
    }

    /**
     * 获取结束的计划
     *
     * @return requestId 300032
     */
    public int getTrainedPlan() {
        int requestId = generateRequestId(32);
        makeRequest(requestId, true)
                .startService();
        return requestId;
    }

    /**
     * 设置训练计划延期
     *
     * @param delayDay 延期值,最大值为7
     * @return requestId 300033
     */
    public int delayTrainPlan(int delayDay) {
        int requestId = generateRequestId(33);
        makeRequest(requestId, true)
                .putInt("delayDay", delayDay)
                .startService();
        return requestId;
    }

    /**
     * 删除训练计划
     *
     * @return requestId 300034
     */
    public int deleteTrainPlan() {
        int requestId = generateRequestId(34);
        makeRequest(requestId, true)
                .startService();
        return requestId;
    }

    /**
     * 获取当天训练计划
     *
     * @return requestId 300035
     */
    public int getTodayStages() {
        int requestId = generateRequestId(35);
        makeRequest(requestId, true)
                .startService();
        return requestId;
    }


    /**
     * 获取用户月运动排行榜数据
     *
     * @param uid  用户uid
     * @param time 当前时间戳
     * @return requestId 3000036
     */
    public int getRankListData(int uid, long time, boolean ignorePreCache) {
        int requestId = generateRequestId(36);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .startService();
        return requestId;
    }

    /**
     * 获取用户月运动排行榜PK数据
     *
     * @param uid       用户uid
     * @param time      当前时间戳
     * @param targetUid pk目标用户
     * @return requestId 3000037
     */
    public int getRankListPKData(int uid, long time, int targetUid, boolean ignorePreCache) {
        int requestId = generateRequestId(37);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("targetUid", targetUid)
                .startService();
        return requestId;
    }

    /**
     * 获取当月青铜级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000038
     */
    public int getBronzeRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(38);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 1)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取当月白银级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000039
     */
    public int getSilverRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(39);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 2)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取当月黄金级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000040
     */
    public int getGoldRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(40);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 3)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取当月铂金级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000041
     */
    public int getPlatinumRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(41);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 4)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取当月钻石级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000042
     */
    public int getDiamondRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(42);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 5)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取上一个月青铜级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000043
     */
    public int getLastBronzeRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(43);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 1)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取上一个月白银级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000044
     */
    public int getLastSilverRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(44);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 2)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取上一个月黄金级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000045
     */
    public int getLastGoldRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(45);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 3)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取上一个月铂金级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000046
     */
    public int getLastPlatinumRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(46);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 4)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }

    /**
     * 获取上一个月钻石级别用户运动排行榜数据
     *
     * @param uid            用户uid
     * @param time           当前时间戳
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     * @return requestId 3000047
     */
    public int getLastDiamondRankListLevelData(int uid, long time, int pageNo, boolean ignorePreCache) {
        int requestId = generateRequestId(47);
        makeRequest(requestId, ignorePreCache)
                .putInt("uid", uid)
                .putLong("time", time)
                .putInt("level", 5)
                .putInt("pageNo", pageNo)
                .startService();
        return requestId;
    }


}
