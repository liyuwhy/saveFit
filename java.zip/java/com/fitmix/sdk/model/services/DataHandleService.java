package com.fitmix.sdk.model.services;

import android.content.Intent;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.process.ClubDataProcessor;
import com.fitmix.sdk.model.process.DiscoverDataProcessor;
import com.fitmix.sdk.model.process.MusicDataProcessor;
import com.fitmix.sdk.model.process.SportDataProcessor;
import com.fitmix.sdk.model.process.UserDataProcessor;

/**
 * 数据处理服务
 */
public class DataHandleService extends MultiThreadedIntentService {

    /**
     * DataHandleService 名称
     */
    public static final String SERVICE_NAME = DataHandleService.class.getName();

    /**
     * 数据请求结果广播
     */
    public static final String ACTION_REQUEST_RESULT = "ACTION_REQUEST_RESULT";
    /**
     * 数据请求编号键名
     */
    public static final String EXTRA_REQUEST_ID = "EXTRA_REQUEST_ID";
    /**
     * 数据请求是否忽略之前的缓存结果
     */
    public static final String EXTRA_REQUEST_IGNORE_CACHE = "EXTRA_REQUEST_IGNORE_CACHE";
    /**
     * 数据请求参数Bundle键名
     */
    public static final String EXTRA_REQUEST_BUNDLE = "EXTRA_REQUEST_BUNDLE";
    /**
     * 数据请求结果回调键名
     */
    public static final String EXTRA_SERVICE_CALLBACK = "EXTRA_SERVICE_CALLBACK";
    /**
     * 数据请求结果状态编号键名
     */
    public static final String EXTRA_BROADCAST_RESULT_CODE = "EXTRA_BROADCAST_RESULT_CODE";
    /**
     * 数据请求结果键名
     */
    public static final String EXTRA_BROADCAST_RESULT_STR = "EXTRA_BROADCAST_RESULT_STR";
    /**
     * 数据请求结果状态成功
     */
    public static final int RESULT_BROADCAST_CODE_SUCCESS = 200;
    /**
     * 数据请求结果状态失败
     */
    public static final int RESULT_BROADCAST_CODE_FAIL = 400;

    @Override
    protected int getMaximumNumberOfThreads() {
        int cpuCore = FitmixUtil.getPhoneCpuCoreNum();
        return 2 * cpuCore;//
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent == null) {
            return;
        }
        int requestId = intent.getIntExtra(DataHandleService.EXTRA_REQUEST_ID, -1);
        Logger.i(Logger.DATA_FLOW_TAG, "DataHandleService-->onHandleIntent requestId:" + requestId);
        // Processor中处理数据请求的缓存、网络请求或数据库请求
        switch (requestId) {
            //region =============================== 用户信息管理 ==================================
            case Config.MODULE_USER + 1://APP初始化
                UserDataProcessor.getInstance().appInit(intent);
                break;
            case Config.MODULE_USER + 2://用户登录
                UserDataProcessor.getInstance().emailLogin(intent);
                break;
            case Config.MODULE_USER + 3://QQ授权登录
                UserDataProcessor.getInstance().qqLogin(intent);
                break;
            case Config.MODULE_USER + 4://新浪微博授权登录
                UserDataProcessor.getInstance().weiBoLogin(intent);
                break;
            case Config.MODULE_USER + 5://微信授权登录
                UserDataProcessor.getInstance().weiXinLogin(intent);
                break;
            case Config.MODULE_USER + 6://检测服务器上App最新版本信息
                UserDataProcessor.getInstance().checkAppVersion(intent);
                break;
            case Config.MODULE_USER + 7://上传用户个人信息
                UserDataProcessor.getInstance().updateUserInfo(intent);
                break;
            case Config.MODULE_USER + 10://用户绑定手机时获取验证码
                UserDataProcessor.getInstance().getAuthCode(intent);
                break;
            case Config.MODULE_USER + 11://获取邮箱接收验证码
                UserDataProcessor.getInstance().getEmailAuthCode(intent);
                break;
            case Config.MODULE_USER + 12://更改密码操作
                UserDataProcessor.getInstance().changePwd(intent);
                break;
            case Config.MODULE_USER + 13://更改用户信息资料
                UserDataProcessor.getInstance().modifyContestant(intent);
                break;
            case Config.MODULE_USER + 20://邮箱注册
                UserDataProcessor.getInstance().emailRegister(intent);
                break;
            case Config.MODULE_USER + 21://手机注册
                UserDataProcessor.getInstance().mobileRegister(intent);
                break;
            case Config.MODULE_USER + 22://获取邮箱注册密码发送到邮箱
                UserDataProcessor.getInstance().forgetEmailPassword(intent);
                break;
            case Config.MODULE_USER + 23://忘记手机注册密码
                UserDataProcessor.getInstance().forgetMobilePassword(intent);
                break;
            case Config.MODULE_USER + 24://向后台服务器发送用户统计数据
                UserDataProcessor.getInstance().reportUserBehavior(intent);
                break;
            case Config.MODULE_USER + 25://修改消息状态(赛事)
                UserDataProcessor.getInstance().switchMessageState(intent);
                break;
            case Config.MODULE_USER + 26://修改消息状态(俱乐部)
                UserDataProcessor.getInstance().switchMessageState(intent);
                break;
            case Config.MODULE_USER + 28://检测服务器上心率耳机最新版本信息
                UserDataProcessor.getInstance().checkHRFirmwareVersion(intent);
                break;
            case Config.MODULE_USER + 29://检测服务器上手表固件最新版本信息
            case Config.MODULE_USER + 80://检测服务器上手表阿波罗固件最新版本信息
                UserDataProcessor.getInstance().watchFirmwareVersion(intent);
                break;
            case Config.MODULE_USER + 30://用户解绑操作,UNBIND_TYPE_BY_EMAIL
            case Config.MODULE_USER + 31://用户解绑操作,qq
            case Config.MODULE_USER + 32://用户解绑操作,phone
            case Config.MODULE_USER + 33://用户解绑操作,sina
            case Config.MODULE_USER + 34://用户解绑操作,wechat
                UserDataProcessor.getInstance().userUnbind(intent);
                break;
            case Config.MODULE_USER + 35://用户绑定资料（不包括密码）email
            case Config.MODULE_USER + 36://用户绑定资料（不包括密码）phone
            case Config.MODULE_USER + 37://用户绑定资料（包括密码）email
            case Config.MODULE_USER + 38://用户绑定资料（包括密码）phone
                UserDataProcessor.getInstance().userBind(intent);
                break;
            case Config.MODULE_USER + 39://QQ绑定
            case Config.MODULE_USER + 40://微博绑定
            case Config.MODULE_USER + 41://微信绑定
                UserDataProcessor.getInstance().getBind(intent);
                break;
            case Config.MODULE_USER + 47://查找用户设备信息,例如用户购买的手表、耳机等等
                UserDataProcessor.getInstance().findUserDevices(intent);
                break;
            case Config.MODULE_USER + 48://上传设备信息给后台
                UserDataProcessor.getInstance().uploadDeviceInfo(intent);
                break;
            case Config.MODULE_USER + 49://删除设备信息
                UserDataProcessor.getInstance().deleteDeviceInfo(intent);
                break;
            case Config.MODULE_USER + 50://获取用户信息,如金币数量等
                UserDataProcessor.getInstance().getUserAccountInfo(intent);
                break;
            case Config.MODULE_USER + 51://获取用户金币明细
                UserDataProcessor.getInstance().getUserCoinRecord(intent);
                break;
            case Config.MODULE_USER + 52://完成任务
                UserDataProcessor.getInstance().finishTask(intent);
                break;
            case Config.MODULE_USER + 53://获取流米流量套餐兑换信息
                UserDataProcessor.getInstance().getLiuMiProduct(intent);
                break;
            case Config.MODULE_USER + 54://兑换流量套餐
                UserDataProcessor.getInstance().exchange(intent);
                break;
            case Config.MODULE_USER + 55://获取所有任务列表
            case Config.MODULE_USER + 56://获取今日任务列表
            case Config.MODULE_USER + 57://获取荣誉任务列表
            case Config.MODULE_USER + 58://获取等级任务列表
                UserDataProcessor.getInstance().getTask(intent);
                break;
            case Config.MODULE_USER + 59://完成每日分享音乐金币任务接口
            case Config.MODULE_USER + 60://完成每日分享运动视频金币任务接口
            case Config.MODULE_USER + 61://完成每日分享运动记录金币任务
            case Config.MODULE_USER + 62://完成每日播放音乐金币任务接口
            case Config.MODULE_USER + 63://完成邮箱绑定或注册金币任务接口
            case Config.MODULE_USER + 64://完成手机绑定或注册金币任务接口
            case Config.MODULE_USER + 65://完成分享流量兑换金币任务
                UserDataProcessor.getInstance().finishTask(intent);
                break;
            case Config.MODULE_USER + 66://浏览个人主页
                UserDataProcessor.getInstance().browseHomePage(intent);
                break;

            case Config.MODULE_USER + 67://更新用户app的活跃状态
                UserDataProcessor.getInstance().uploadDeviceStatus(intent);
                break;

            case Config.MODULE_USER + 68://发送私信
                UserDataProcessor.getInstance().sendUserPrivateMsg(intent);
                break;

            case Config.MODULE_USER + 69://查询私信列表
                UserDataProcessor.getInstance().getUserPrivateMsgList(intent);
                break;

            case Config.MODULE_USER + 70://获取分享兑换流量结果金币任务信息
                UserDataProcessor.getInstance().getTaskInfoByKey(intent);
                break;
            case Config.MODULE_USER + 71://获取用户通知列表
                UserDataProcessor.getInstance().getUserNoticeList(intent);
                break;

            case Config.MODULE_USER + 72://获取用户消息列表详情
                UserDataProcessor.getInstance().getUserPrivateMsgInfo(intent);
                break;
            case Config.MODULE_USER + 73://删除用户私信
                UserDataProcessor.getInstance().deleteUserPrivateMsg(intent);
                break;
            case Config.MODULE_USER + 74://用户私信关系设置 屏蔽 取消屏蔽
                UserDataProcessor.getInstance().setUserPrivateMsgReject(intent);
                break;
            case Config.MODULE_USER + 75://读取用户通知消息
                UserDataProcessor.getInstance().readUserNoticeMsg(intent);
                break;

            case Config.MODULE_USER + 100://获取加密公钥
                UserDataProcessor.getInstance().getPublicKey(intent);
                break;

            case Config.MODULE_USER + 200://彩蛋
                UserDataProcessor.getInstance().getSurpriseInfo(intent);
                break;
            case Config.MODULE_USER + 201://上传设备信息
                UserDataProcessor.getInstance().uploadUserDeviceInfo(intent);
                break;
            case Config.MODULE_USER + 202://获取城市天气
                UserDataProcessor.getInstance().getCityWeather(intent);
                break;
            case Config.MODULE_USER+203: // 上传错误日志
                UserDataProcessor.getInstance().uploadUserErrorLog(intent);
                break;

            case Config.MODULE_USER + 1000://在数据请求状态结果表(DataReqStatus)中,清空指定数据请求编号的结果字段(result)
                UserDataProcessor.getInstance().emptyDataReqResult(this, intent);
                break;
            case Config.MODULE_USER + 1001://在数据请求状态结果表(DataReqStatus)中,更改指定数据请求编号的结果有效期字段(expired)
                UserDataProcessor.getInstance().setDataReqExpired(this, intent);
                break;
            //endregion ============================ 用户信息管理 ==================================

            //region ============================ 运动信息管理 ==================================
            case Config.MODULE_SPORT + 1://上传今日步数到微信运动
                SportDataProcessor.getInstance().setWeChatTodayStepsNew(intent);
                break;
            case Config.MODULE_SPORT + 2://从后台服务器获取用户历史跑步记录
                SportDataProcessor.getInstance().getHistoryRunRecords(intent);
                break;
            case Config.MODULE_SPORT + 3://分享跑步记录
                SportDataProcessor.getInstance().shareRunRecord(intent);
                break;
//            case Config.MODULE_SPORT + 4://添加运动记录,V2.3.8之后不再使用
//                SportDataProcessor.getInstance().addSportRecord(intent);
//                break;
            case Config.MODULE_SPORT + 5://删除后台服务器上的跑步记录
                SportDataProcessor.getInstance().deleteRunRecord(intent);
                break;
            case Config.MODULE_SPORT + 6://同步数据到QQ运动
                SportDataProcessor.getInstance().syncToQQSport(intent);
                break;
            case Config.MODULE_SPORT + 7://小清新分享运动
                SportDataProcessor.getInstance().shareRunRecordLite(intent);
                break;
            case Config.MODULE_SPORT + 8://获得语音包的列表信息
                SportDataProcessor.getInstance().getVoicePackageInfo(intent);
                break;
            case Config.MODULE_SPORT + 9://获得语音包下载的链接地址url列表信息
                SportDataProcessor.getInstance().getVoicePackageUrlInfo(intent);
                break;
            case Config.MODULE_SPORT + 10://添加跳绳运动记录
                SportDataProcessor.getInstance().addSkipSportRecordWithHeartRate(intent);
                break;
            case Config.MODULE_SPORT + 11://删除后台服务器上的跳绳记录
                SportDataProcessor.getInstance().deleteSkipRecord(intent);
                break;
            case Config.MODULE_SPORT + 12://从后台服务器获取用户历史跳绳记录
                SportDataProcessor.getInstance().getHistorySkipRecords(intent);
                break;
            case Config.MODULE_SPORT + 13://分享跳绳记录
                SportDataProcessor.getInstance().shareSkipRecord(intent);
                break;
            case Config.MODULE_SPORT + 15://上传静息心率记录
                SportDataProcessor.getInstance().uploadRestHeartRateInfo(intent);
                break;
            case Config.MODULE_SPORT + 16://获取全部静息心率记录
                SportDataProcessor.getInstance().getAllRestHeartRateHistory(intent);
                break;
            case Config.MODULE_SPORT + 17://向后台上传用户传感器异常错误日志
                SportDataProcessor.getInstance().uploadSensorAbnormalError(intent);
                break;
            case Config.MODULE_SPORT + 30://创建训练计划
                SportDataProcessor.getInstance().createTrainingPlan(intent);
                break;
            case Config.MODULE_SPORT + 31://获取正在进行中的训练计划
                SportDataProcessor.getInstance().getTrainingPlan(intent);
                break;
            case Config.MODULE_SPORT + 32://获取已经结束的训练计划
                SportDataProcessor.getInstance().getTrainedPlan(intent);
                break;
            case Config.MODULE_SPORT + 33://训练计划延期
                SportDataProcessor.getInstance().delayTrainPlan(intent);
                break;
            case Config.MODULE_SPORT + 34://删除训练计划
                SportDataProcessor.getInstance().deleteTrainPlan(intent);
                break;
            case Config.MODULE_SPORT + 35://获取当天训练计划
                SportDataProcessor.getInstance().getTodayStages(intent);
                break;
            case Config.MODULE_SPORT + 36://获取用户月运动排行榜数据
                SportDataProcessor.getInstance().getRankListData(intent);
                break;
            case Config.MODULE_SPORT + 37:///获取用户月运动排行榜PK数据
                SportDataProcessor.getInstance().getRankListPKData(intent);
                break;
            case Config.MODULE_SPORT + 38://获取用户本月运动排行榜各个层次的排名  青铜
            case Config.MODULE_SPORT + 39://获取用户本月运动排行榜各个层次的排名  白银
            case Config.MODULE_SPORT + 40://获取用户本月运动排行榜各个层次的排名  黄金
            case Config.MODULE_SPORT + 41://获取用户本月运动排行榜各个层次的排名  铂金
            case Config.MODULE_SPORT + 42://获取用户本月运动排行榜各个层次的排名  钻石
                SportDataProcessor.getInstance().getRankListLevelData(intent);
                break;

            case Config.MODULE_SPORT + 43://获取用户上月运动排行榜各个层次的排名  青铜
            case Config.MODULE_SPORT + 44://获取用户上月运动排行榜各个层次的排名  白银
            case Config.MODULE_SPORT + 45://获取用户上月运动排行榜各个层次的排名  黄金
            case Config.MODULE_SPORT + 46://获取用户上月运动排行榜各个层次的排名  铂金
            case Config.MODULE_SPORT + 47://获取用户上月运动排行榜各个层次的排名  钻石
                SportDataProcessor.getInstance().getRankListLevelData(intent);
                break;

            case Config.MODULE_SPORT + 51://从后台服务器获取手表运动记录
                SportDataProcessor.getInstance().getWatchSportRecord(intent);
                break;

            //endregion ============================ 运动信息管理 ==================================

            //region =============================== 音乐模块 ==================================

            case Config.MODULE_MUSIC + 1://获取albumList
                MusicDataProcessor.getInstance().getAlbumList(intent);
                break;
            case Config.MODULE_MUSIC + 2://获取bannerList
                MusicDataProcessor.getInstance().getBannerList(intent);
                break;
            case Config.MODULE_MUSIC + 3://获取音乐列表
                MusicDataProcessor.getInstance().getMusicListFromServerBySceneAndIndex(intent);
                break;
            case Config.MODULE_MUSIC + 4://收藏音乐
                MusicDataProcessor.getInstance().favoriteMusicChange(intent);
                break;
            case Config.MODULE_MUSIC + 5://批量收藏音乐
                MusicDataProcessor.getInstance().favoriteMusicListChange(intent);
                break;
            case Config.MODULE_MUSIC + 6://获取album电台列表
                MusicDataProcessor.getInstance().getAlbumList(intent);
                break;
            case Config.MODULE_MUSIC + 7://获取电台详情列表
                MusicDataProcessor.getInstance().getMusicListFromServerBySceneAndIndex(intent);
                break;
            case Config.MODULE_MUSIC + 8://获取热词列表
                MusicDataProcessor.getInstance().getKeyWordList(intent);
                break;
            case Config.MODULE_MUSIC + 9://根据关键字搜索歌曲列表
                MusicDataProcessor.getInstance().searchMusicByKey(intent);
                break;
            case Config.MODULE_MUSIC + 10://根据banner获取推荐专辑
                MusicDataProcessor.getInstance().getRadioListFromServerByAlbumId(intent);
                break;
            case Config.MODULE_MUSIC + 11://上传音乐试听
                MusicDataProcessor.getInstance().uploadMusicAudition(intent);
                break;
            case Config.MODULE_MUSIC + 12://获取歌曲列表信息（通过歌曲ID列表）
                MusicDataProcessor.getInstance().getMusicListInfo(intent);
                break;
            case Config.MODULE_MUSIC + 13://获取推荐歌曲
                MusicDataProcessor.getInstance().getRecommendMusic(intent);
                break;
            //endregion ============================ 音乐模块 ==================================

            //region =============================== 俱乐部模块 ==================================

            case Config.MODULE_CLUB + 1://获取俱乐部列表
                ClubDataProcessor.getInstance().getClubList(intent);
                break;
            case Config.MODULE_CLUB + 2://获取俱乐部动态
                ClubDataProcessor.getInstance().getClubDynamicList(intent);
                break;
            case Config.MODULE_CLUB + 3://获取俱乐部公告
                ClubDataProcessor.getInstance().getClubNoticeList(intent);
                break;
            case Config.MODULE_CLUB + 4://获取俱乐部排行列表
                ClubDataProcessor.getInstance().getClubRankList(intent);
                break;
            case Config.MODULE_CLUB + 5://获取俱乐部排行信息
                ClubDataProcessor.getInstance().getClubRankInfo(intent);
                break;
            case Config.MODULE_CLUB + 6://获取俱乐部留言
                ClubDataProcessor.getInstance().getClubMessage(intent);
                break;
            case Config.MODULE_CLUB + 7://获取俱乐部活跃信息
                ClubDataProcessor.getInstance().getClubActiveInfo(intent);
                break;
            case Config.MODULE_CLUB + 8://获取俱乐部活跃成员
                ClubDataProcessor.getInstance().getClubActiveUser(intent);
                break;
            case Config.MODULE_CLUB + 9://获取俱乐部成员列表
                ClubDataProcessor.getInstance().getClubMemberList(intent);
                break;
            case Config.MODULE_CLUB + 10://删除俱乐部成员
                ClubDataProcessor.getInstance().deleteClubMember(intent);
                break;
            case Config.MODULE_CLUB + 11://获取俱乐部成员的最后一次运动记录
                ClubDataProcessor.getInstance().getLastRunlogInfo(intent);
                break;
            case Config.MODULE_CLUB + 12://退出俱乐部
                ClubDataProcessor.getInstance().quitClub(intent);
                break;
            case Config.MODULE_CLUB + 13://分享俱乐部
                ClubDataProcessor.getInstance().getShareClubUrl(intent);
                break;
            case Config.MODULE_CLUB + 14://创建俱乐部
                ClubDataProcessor.getInstance().createClub(intent);
                break;
            case Config.MODULE_CLUB + 15://更改俱乐部
                ClubDataProcessor.getInstance().modifyClub(intent);
                break;
            case Config.MODULE_CLUB + 16://删除俱乐部
                ClubDataProcessor.getInstance().deleteClub(intent);
                break;
            case Config.MODULE_CLUB + 17://创建俱乐部公告
                ClubDataProcessor.getInstance().createClubNotice(intent);
                break;
            case Config.MODULE_CLUB + 18://更改俱乐部公告
                ClubDataProcessor.getInstance().modifyClubNotice(intent);
                break;
            case Config.MODULE_CLUB + 19://删除俱乐部公告
                ClubDataProcessor.getInstance().deleteClubNotice(intent);
                break;
            case Config.MODULE_CLUB + 20://添加俱乐部留言
                ClubDataProcessor.getInstance().addClubMessage(intent);
                break;
            case Config.MODULE_CLUB + 21://邀请加入俱乐部
                ClubDataProcessor.getInstance().joinClub(intent);
                break;
            case Config.MODULE_CLUB + 22://查找俱乐部
                ClubDataProcessor.getInstance().findClub(intent);
                break;

            //endregion ============================俱乐部模块==================================

            //region ============================ 发现模块 ==================================

            case Config.MODULE_COMPETITION + 1://运动赛事列表
                DiscoverDataProcessor.getInstance().getCompetitionList(intent);
                break;
            case Config.MODULE_COMPETITION + 2://运动视频列表
                DiscoverDataProcessor.getInstance().getVideoList(intent);
                break;
            case Config.MODULE_COMPETITION + 3://运动赛事列表加载更多
                DiscoverDataProcessor.getInstance().getCompetitionList(intent);
                break;
            case Config.MODULE_COMPETITION + 4://运动视频列表加载更多
                DiscoverDataProcessor.getInstance().getVideoList(intent);
                break;
            case Config.MODULE_COMPETITION + 5://话题列表
                DiscoverDataProcessor.getInstance().getTopicList(intent);
                break;
            case Config.MODULE_COMPETITION + 6://根据话题编号,获取该话题的回答列表
                DiscoverDataProcessor.getInstance().getTopicAnswerList(intent);
                break;
            case Config.MODULE_COMPETITION + 7://根据话题编号,获取该话题的讨论列表
                DiscoverDataProcessor.getInstance().getTopicDiscussList(intent);
                break;
            case Config.MODULE_COMPETITION + 8://搜索话题
                DiscoverDataProcessor.getInstance().searchTopic(intent);
                break;
            case Config.MODULE_COMPETITION + 9://获取我的回答列表
                DiscoverDataProcessor.getInstance().getMyAnswerList(intent);
                break;
            case Config.MODULE_COMPETITION + 10://获取我的提问列表
                DiscoverDataProcessor.getInstance().getMyQuestionList(intent);
                break;
            case Config.MODULE_COMPETITION + 11://添加话题
                DiscoverDataProcessor.getInstance().addTopic(intent);
                break;
            case Config.MODULE_COMPETITION + 12://添加话题答案
                DiscoverDataProcessor.getInstance().addTopicAnswer(intent);
                break;
            case Config.MODULE_COMPETITION + 13://添加话题答案的评论
                DiscoverDataProcessor.getInstance().addTopicAnswerDiscuss(intent);
                break;
            case Config.MODULE_COMPETITION + 14://话题答案点赞
                DiscoverDataProcessor.getInstance().likeTopicAnswer(intent);
                break;
            case Config.MODULE_COMPETITION + 15://上传图片
                DiscoverDataProcessor.getInstance().uploadImage(intent);
                break;
            case Config.MODULE_COMPETITION + 16://根据话题答案编号,获取话题答案
                DiscoverDataProcessor.getInstance().getTopicAnswerByAnswerId(intent);
                break;
            case Config.MODULE_COMPETITION + 17://编辑话题答案
                DiscoverDataProcessor.getInstance().editTopicAnswer(intent);
                break;
            case Config.MODULE_COMPETITION + 18://获取与自己相关的最新话题回答消息
                DiscoverDataProcessor.getInstance().getNewAnswerMessage(intent);
                break;
            case Config.MODULE_COMPETITION + 19://获取与自己相关的最新话题讨论消息
                DiscoverDataProcessor.getInstance().getNewDiscussMessage(intent);
                break;
            case Config.MODULE_COMPETITION + 20://获取精选话题列表
                DiscoverDataProcessor.getInstance().getHandPickTopicList(intent);
                break;
            case Config.MODULE_COMPETITION + 21://获取视频详情
                DiscoverDataProcessor.getInstance().getVideoDetail(intent);
                break;
            case Config.MODULE_COMPETITION + 22://话题评论点赞
                DiscoverDataProcessor.getInstance().likeTopicDiscuss(intent);
                break;
            //endregion ============================ 发现模块 ==================================
            default:
                break;
        }
//        Logger.i(Logger.DATA_FLOW_TAG, "DataHandleService-->onHandleIntent mFutureList.size():" + mFutureList.size());
    }

}
