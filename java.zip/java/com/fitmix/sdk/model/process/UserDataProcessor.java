package com.fitmix.sdk.model.process;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.encrypt.AppPublicKey;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.OkHttpUtil;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusDao;
import com.fitmix.sdk.model.database.SettingsHelper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.security.Key;

import de.greenrobot.dao.query.QueryBuilder;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.Response;


/**
 * 用户信息数据处理工作类
 */
public class UserDataProcessor extends BaseProcessor {

    private static UserDataProcessor mInstance;

    private UserDataProcessor() {
    }

    /**
     * 获取用户信息数据处理工作类实例
     */
    public static UserDataProcessor getInstance() {
        if (mInstance == null) {
            mInstance = new UserDataProcessor();
        }
        return mInstance;
    }

    /**
     * APP初始化处理
     */
    public void appInit(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int version = bundle.getInt("version");
        String lan = bundle.getString("lan", "ch");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.appInitUrl(version, lan);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * APP 邮箱账号登录
     */
    public void emailLogin(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String email = bundle.getString("email");
        String password = bundle.getString("password");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.emailLogin(email, password);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * QQ授权登录
     */
    public void qqLogin(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String token = bundle.getString("token");
        String openid = bundle.getString("openid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.qqLogin(token, openid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 新浪微博授权登录
     */
    public void weiBoLogin(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String token = bundle.getString("token");
        String openid = bundle.getString("openid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.weiBoLogin(token, openid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 微信授权登录
     */
    public void weiXinLogin(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String token = bundle.getString("token");
        String openid = bundle.getString("openid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.weiXinLogin(token, openid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 检测服务器上App最新版本信息
     */
    public void checkAppVersion(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }

        // 2.网络请求、文件请求或数据库请求
        String url = ApiConstants.checkAppVersion();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 邮箱注册
     */
    public void emailRegister(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String email = bundle.getString("email");
        String verifyCode = bundle.getString("verifyCode");
        String password = bundle.getString("password");
        // 2.网络请求、文件请求或数据库请求
        String url = ApiConstants.emailRegister(email, verifyCode, password);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }

    /**
     * 上传（更新）用户基本信息
     *
     * @param intent
     */
    public void updateUserInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int id = bundle.getInt("id");
        String name = bundle.getString("name");
        int male = bundle.getInt("male");
        int age = bundle.getInt("age");
        double height = bundle.getDouble("height");
        double weight = bundle.getDouble("weight");
        int language = bundle.getInt("language");
        String signature = bundle.getString("signature");
        String fileName = bundle.getString("fileName");
        String tag = bundle.getString("tag");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.updateUserInfo(id, name, male, age, height, weight, language, signature);
        String result;
        if (FileUtils.isFileExist(fileName)) {//本地有头像文件时上传
            result = uploadDataToServer(url, fileName, tag);
        } else {
            result = getDataFromApi(url);
        }
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_FOREVER);
    }

    /**
     * 手机注册
     */
    public void mobileRegister(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String mobile = bundle.getString("mobileNumber");
        String verifyCode = bundle.getString("verifyCode");
        String password = bundle.getString("password");
        // 2.网络请求、文件请求或数据库请求
        String url = ApiConstants.mobileRegister(mobile, verifyCode, password);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }

    /**
     * 忘记邮箱密码
     */
    public void forgetEmailPassword(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String email = bundle.getString("email");
        String verifyCode = bundle.getString("verifyCode");
        String newPwd = bundle.getString("newPwd");
        // 2.网络请求、文件请求或数据库请求
        String url = ApiConstants.forgetEmailPassword(email, verifyCode, newPwd);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }

    /**
     * 忘记手机注册密码
     */
    public void forgetMobilePassword(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String mobileNumber = bundle.getString("mobileNumber");
        String verifyCode = bundle.getString("verifyCode");
        String newPassword = bundle.getString("newPassword");
        // 2.网络请求、文件请求或数据库请求
        String url = ApiConstants.forgetMobilePassword(mobileNumber, verifyCode, newPassword);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }


    public void getSurpriseInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String cityName = bundle.getString("cityName");
        String url = Config.API_HOST + Config.API_PORT +
                "/surprise/get-surprise.json";
        FormBody body = ApiConstants.getSurpriseInfo(cityName);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存一个小时
    }

    /**
     * 用户绑定资料（）
     *
     * @param intent
     */
    public void userBind(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String bindingContent = bundle.getString("bindingContent");
        String bindingName = bundle.getString("bindingName");
        int type = bundle.getInt("type");
        String password = bundle.getString("password");
        String url;
        // 3.网络请求、文件请求或数据库请求
        if (TextUtils.isEmpty(password)) {
            url = ApiConstants.userBind(bindingContent, bindingName, type);
        } else {
            url = ApiConstants.userBindWithPwd(bindingContent, bindingName, type, password);
        }
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    /**
     * 绑定手机时获取手机验证码
     *
     * @param intent
     */
    public void getAuthCode(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String mobileNumber = bundle.getString("mobileNumber");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getAuthCode(mobileNumber);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }


    /**
     * 获取邮箱接收验证码
     *
     * @param intent
     */
    public void getEmailAuthCode(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String email = bundle.getString("email");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getEmailAuthCode(email);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }


    public void userUnbind(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int type = bundle.getInt("type");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.userUnbind(type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    public void changePwd(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String oldPwd = bundle.getString("oldPwd");
        String nowPwd = bundle.getString("nowPwd");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.changePwd(oldPwd, nowPwd);
        //        String result = getDataFromApi(url);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    public void modifyContestant(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        String currentContestantName = bundle.getString("contestantName");
        int gender = bundle.getInt("gender");
        int age = bundle.getInt("age");
        String identity = bundle.getString("identity");
        String phoneNumber = bundle.getString("phoneNumber");
        String email = bundle.getString("email");
        String province = bundle.getString("province");
        String city = bundle.getString("city");
        String address = bundle.getString("address");
        String bloodType = bundle.getString("bloodType");
        String dressSize = bundle.getString("dressSize");
        String emergencyName = bundle.getString("emergencyName");
        String emergencyNumber = bundle.getString("emergencyNumber");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.modifyContestant(uid, currentContestantName, gender, age, identity, phoneNumber, email, province,
                city, address, bloodType, dressSize, emergencyName, emergencyNumber);

        //        String result = getDataFromApi(url);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    public void getBind(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String bindingContent = bundle.getString("bindingContent");
        String bindingName = bundle.getString("bindingName");
        int type = bundle.getInt("type");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getBindString(bindingContent, bindingName, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    public void uploadUserDeviceInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String deviceToken = bundle.getString("deviceToken");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.uploadUserDeviceInfo(deviceToken);
        String result = getDataFromApi(url);
        Logger.i(Logger.DATA_FLOW_TAG, "推送上传设备token--->url:" + url + ",deviceToken:" + deviceToken + ",result:" + result);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 向后台服务器发送用户统计数据
     */
    public void reportUserBehavior(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        int musicId = bundle.getInt("musicId");
        int type = bundle.getInt("type");
        double lng = bundle.getDouble("lng");
        double lat = bundle.getDouble("lat");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.reportUserBehavior(uid, musicId, type, lng, lat);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 向后台服务器发送用户统计数据
     */
    public void switchMessageState(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int pushType = bundle.getInt("pushType");
        int businessId = bundle.getInt("businessId");
        // 3.网络请求、文件请求或数据库请求
        String url;
        if (businessId > 0) {
            url = ApiConstants.switchMessageState(pushType, businessId);
        } else {
            url = ApiConstants.switchMessageState(pushType);
        }
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }


    /**
     * 在数据请求状态结果表(DataReqStatus)中,清空指定数据请求编号的结果字段(result)
     *
     * @param context 上下文
     * @param intent  包含额外信息的intent
     */
    public void emptyDataReqResult(Context context, Intent intent) {
        //1.解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        //2.查询出符合条件的结果,更改结果字段并更新到数据库
        try {
            int requestId = bundle.getInt("requestId");
            DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(context).getDataReqStatusDao();
            QueryBuilder<DataReqStatus> qb = dataReqStatusDao.queryBuilder();
            qb.where(DataReqStatusDao.Properties.RequestId.eq(requestId));
            DataReqStatus dataReqStatus = qb.unique();
            if (dataReqStatus != null) {
                dataReqStatus.setResult("");
                dataReqStatusDao.insertOrReplace(dataReqStatus);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 在数据请求状态结果表(DataReqStatus)中,更改指定数据请求编号的结果有效期字段(expired)
     *
     * @param context 上下文
     * @param intent  包含额外信息的intent
     */
    public void setDataReqExpired(Context context, Intent intent) {
        //1.解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        //2.查询出符合条件的结果,更改结果字段并更新到数据库
        try {
            int requestId = bundle.getInt("requestId");
            long expired = bundle.getLong("expired");
            DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(context).getDataReqStatusDao();
            QueryBuilder<DataReqStatus> qb = dataReqStatusDao.queryBuilder();
            qb.where(DataReqStatusDao.Properties.RequestId.eq(requestId));
            DataReqStatus dataReqStatus = qb.unique();
            if (dataReqStatus != null) {
                dataReqStatus.setExpired(expired);
                dataReqStatusDao.insertOrReplace(dataReqStatus);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取用户信息,如金币数量等
     *
     * @param intent 包含额外信息的intent
     */
    public void getUserAccountInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getUserAccountInfo(uid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_5_MINUTE);//5分钟
    }

    /**
     * 获取用户金币明细
     *
     * @param intent 包含额外信息的intent
     */
    public void getUserCoinRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        int pageNo = bundle.getInt("pageNo");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getUserCoinRecord(uid, pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);

    }

    /**
     * 完成任务
     *
     * @param intent 包含额外信息的intent
     */
    public void finishTask(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        int taskType = bundle.getInt("taskType");
        String verifyId = bundle.getString("verifyId");
        String taskKey = bundle.getString("taskKey");
        // 3.网络请求、文件请求或数据库请求
        String url = Config.API_HOST + Config.API_PORT + "/task/task-finish.json?";
        FormBody body = ApiConstants.finishTask(uid, taskType, taskKey, verifyId);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);

    }

    /**
     * 获取流米流量套餐兑换信息
     *
     * @param intent 包含额外信息的intent
     */
    public void getLiuMiProduct(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 网络请求、文件请求或数据库请求
        String url = ApiConstants.getLiuMiProduct();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_15_MINUTE);//15分钟
    }

    /**
     * 兑换流米流量套餐
     *
     * @param intent 包含额外信息的intent
     */
    public void exchange(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        int productId = bundle.getInt("productId");
        String phone = bundle.getString("phone");
        // 3.网络请求、文件请求或数据库请求
        String url = Config.API_HOST + Config.API_PORT + "/liumi/exchange.json?";
        FormBody body = ApiConstants.exchange(uid, phone, productId);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取任务列表
     *
     * @param intent 包含额外信息的intent
     */
    public void getTask(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        int type = bundle.getInt("type");//任务类型,0:每日任务,1:一次性任务(荣誉任务),2:等级任务,-1:所有类型
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getTask(uid, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 根据任务键值获取金币任务信息
     *
     * @param intent 包含额外信息的intent
     */
    public void getTaskInfoByKey(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        String taskKey = bundle.getString("taskKey");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getTaskInfoByKey(taskKey);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }

    /**
     * 获取加密公钥
     *
     * @param intent 包含额外信息的intent
     */
    public void getPublicKey(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        String url = bundle.getString("url");
        // 3.网络请求、文件请求或数据库请求
        Request request = new Request.Builder()
                .url(url)
                .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                        ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                        ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                .build();
        String result = null;
        //4.判断当前网络状态
        if (ApiUtils.isNetWorkAvailable()) {
            try {
                Response response = OkHttpUtil.getInstance().execute(request);
                if (response != null) {
                    Logger.i("加密", "getPublicKey-->response.isSuccessful():" + response.isSuccessful()
                            + " response.code():" + response.code());
                    if (response.isSuccessful()) {
                        int length = (int) response.body().contentLength();
                        byte[] buffer = new byte[length];//设置缓存大小
                        InputStream inputStream = response.body().byteStream();
                        OutputStream outPutStream = new ByteArrayOutputStream();
                        while ((length = inputStream.read(buffer)) != -1) {//读写内容
                            outPutStream.write(buffer, 0, length);
                        }
                        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(buffer));//(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
                        Key key = (Key) ois.readObject();
                        if (key != null) {
                            String publicK = Base64.encodeToString(key.getEncoded(), Base64.DEFAULT);
                            AppPublicKey myPublicKey = new AppPublicKey(key.getAlgorithm(), key.getFormat(), publicK);
                            result = JsonHelper.createJsonString(myPublicKey);//key.toString();
                            Logger.i("加密", "getPublicKey keyStr:" + result + "\npublicK:" + publicK);
                            SettingsHelper.putString(-1, Config.SETTING_PUBLIC_KEY, result);
                        }
                        //清空缓冲区
                        outPutStream.flush();
                        outPutStream.close();
                        inputStream.close();
                        response.body().close();
                    } else {
                        result = getHttpExceptionString(response.code());//http
                    }
                } else {
                    result = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                }
            } catch (Exception ex) {
                result = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                Logger.e("加密", "getPublicKey-->Exception:" + ex.getMessage());
            }
        } else {
            result = getHttpExceptionString(ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
            Logger.e("加密", "getPublicKey-->Exception net work not available");
        }
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天

    }

    /**
     * 检测服务器上心率耳机固件最新版本信息
     *
     * @param intent 包含额外信息的intent
     */
    public void checkHRFirmwareVersion(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }

        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String version = bundle.getString("version");
        String url = ApiConstants.checkFirmwareVersion(version);
        Logger.d(Logger.DEBUG_TAG, "checkUrl:" + url);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 浏览个人主页
     */
    public void browseHomePage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int targetUid = bundle.getInt("targetUid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.browseHomePage(targetUid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 更新用户app的活跃状态
     */
    public void uploadDeviceStatus(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int active = bundle.getInt("active");
        String deviceToken = bundle.getString("deviceToken");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.uploadDeviceStatus(active, deviceToken);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 发送私信
     */
    public void sendUserPrivateMsg(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int targetUid = bundle.getInt("targetUid");
        String content = bundle.getString("content");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.sendUserPrivateMsg(targetUid, content);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 查询私信列表
     */
    public void getUserPrivateMsgList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int page = bundle.getInt("page");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getUserPrivateMsgList(page);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 获取用户通知列表
     */
    public void getUserNoticeList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getUserNoticeList();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 读取用户通知消息
     */
    public void readUserNoticeMsg(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int id = bundle.getInt("id");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.readUserNoticeMsg(id);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 查询私信列表详情
     */
    public void getUserPrivateMsgInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int groupId = bundle.getInt("groupId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getUserPrivateMsgInfo(groupId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 删除私信
     */
    public void deleteUserPrivateMsg(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int groupId = bundle.getInt("groupId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteUserPrivateMsg(groupId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }

    /**
     * 私信关系设置
     */
    public void setUserPrivateMsgReject(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int groupId = bundle.getInt("groupId");
        int handleType = bundle.getInt("handleType");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.setUserPrivateMsgReject(groupId, handleType);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);//忽略缓存
    }


    /**
     * 检测服务器上手表固件最新版本信息
     *
     * @param intent 包含额外信息的intent
     */
    public void watchFirmwareVersion(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String version = bundle.getString("version");
        String firmwareType = bundle.getString("firmwareType");
        String url = ApiConstants.watchFirmwareVersion(version, firmwareType);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存1天
    }

    /**
     * 查找用户设备信息,例如用户购买的手表、耳机等等
     */
    public void findUserDevices(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        int uid = bundle.getInt("uid");
        String url = ApiConstants.findUserDevices(uid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_FOREVER);
    }

    /**
     * 上传设备信息给后台
     */
    public void uploadDeviceInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        int uid = bundle.getInt("uid");
        int type = bundle.getInt("type");
        String info = bundle.getString("info");
        String key = bundle.getString("key");
        String url = ApiConstants.uploadDeviceInfo(uid, type, info, key);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 删除设备信息
     */
    public void deleteDeviceInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        int uid = bundle.getInt("uid");
        int type = bundle.getInt("type");
        String key = bundle.getString("key");
        String url = ApiConstants.deleteDeviceInfo(uid, type, key);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取城市天气
     */
    public void getCityWeather(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String location = bundle.getString("location");
        String url = ApiConstants.getCityWeather(location);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);//缓存一天
    }


    /**
     *  上传手表传送过来的错误日志
     *
     */
    public void uploadUserErrorLog(Intent intent){
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String uid = bundle.getString("uid");
        String chipId = bundle.getString("chipId");
        String fileName = bundle.getString("filaName");
        String url  = ApiConstants.uploadErrorReport(uid,chipId);
        String result = uploadDataToServer(url,fileName,"uploadFile");
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }




}
