package com.fitmix.sdk.model.process;

import android.content.Intent;
import android.os.Bundle;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.ApiConstants;

import okhttp3.FormBody;

/**
 * 运动信息数据处理工作类
 */
public class DiscoverDataProcessor extends BaseProcessor {
    private static DiscoverDataProcessor mInstance;

    private DiscoverDataProcessor() {
    }

    /**
     * 获取运动信息数据处理工作类实例
     */
    public static DiscoverDataProcessor getInstance() {
        if (mInstance == null) {
            mInstance = new DiscoverDataProcessor();
        }
        return mInstance;
    }


    /**
     * 获取运动赛事列表
     */
    public void getCompetitionList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int index = bundle.getInt("index");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getCompetitionList(index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_FOREVER);//赛事已下架
    }

    /**
     * 获取运动视频列表
     */
    public void getVideoList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int index = bundle.getInt("index");
        String url = ApiConstants.getVideoList(index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }

    /**
     * 获取话题列表
     */
    public void getTopicList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int index = bundle.getInt("index");
        int orderType = bundle.getInt("orderType", 2);
        String url = ApiConstants.getTopicList(index, orderType);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getTopicList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_15_MINUTE);//15分钟
    }

    /**
     * 获取话题的回答列表
     */
    public void getTopicAnswerList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int topicId = bundle.getInt("topicId");
        int orderType = bundle.getInt("orderType", 4);
        int pageNo = bundle.getInt("pageNo");
        int getTheme = bundle.getInt("getTheme");
        String url = ApiConstants.getTopicAnswerList(topicId, orderType, getTheme, pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getTopicAnswerList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_5_MINUTE);//5分钟
    }

    /**
     * 获取话题的讨论列表
     */
    public void getTopicDiscussList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int topicId = bundle.getInt("topicId");
        int pageNo = bundle.getInt("pageNo");
        String url = ApiConstants.getTopicDiscussList(topicId, pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getTopicDiscussList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);
    }

    /**
     * 搜索话题
     */
    public void searchTopic(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int pageNo = bundle.getInt("pageNo");
        String searchText = bundle.getString("searchText");
        String url = ApiConstants.searchTopic(searchText, pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "searchTopic-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取我的回答列表
     */
    public void getMyAnswerList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int pageNo = bundle.getInt("pageNo");
        String url = ApiConstants.getMyAnswerList(pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getMyAnswerList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取我的提问列表
     */
    public void getMyQuestionList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int pageNo = bundle.getInt("pageNo");
        String url = ApiConstants.getMyQuestionList(pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getMyQuestionList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 添加话题
     */
    public void addTopic(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String title = bundle.getString("title");
        String contentKey = bundle.getString("contentKey");
        String content = MyConfig.getInstance().getMemExchange().getTopicContent(contentKey);
        Logger.i(Logger.DATA_FLOW_TAG, "addTopic-->title:" + title + ",content:" + content);
        String url = Config.API_HOST + Config.API_PORT + "/theme/add.json";
        FormBody body = ApiConstants.addTopic(title, content);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "addTopic-->result:" + result);
        MyConfig.getInstance().getMemExchange().removeTopicContent(contentKey);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 添加话题答案
     */
    public void addTopicAnswer(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int topicId = bundle.getInt("parentThemeId");
        String contentKey = bundle.getString("contentKey");
        String content = MyConfig.getInstance().getMemExchange().getTopicContent(contentKey);
        Logger.i(Logger.DATA_FLOW_TAG, "addTopicAnswer-->topicId:" + topicId + ",content:" + content);
        String url = Config.API_HOST + Config.API_PORT + "/theme/add/answer.json";
        FormBody body = ApiConstants.addTopicAnswer(topicId, content);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "addTopicAnswer-->result:" + result);
        MyConfig.getInstance().getMemExchange().removeTopicContent(contentKey);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 添加话题答案的评论
     */
    public void addTopicAnswerDiscuss(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int answerId = bundle.getInt("themeId");
        int discussId = bundle.getInt("discussId");
        int discussUid = bundle.getInt("discussUid");
        String contentKey = bundle.getString("contentKey");
        String content = MyConfig.getInstance().getMemExchange().getTopicContent(contentKey);
        String url = Config.API_HOST + Config.API_PORT + "/theme/add/discuss.json";
        FormBody body = ApiConstants.addTopicAnswerDiscuss(answerId, discussId, discussUid, content);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "addTopicAnswerDiscuss-->result:" + result);
        MyConfig.getInstance().getMemExchange().removeTopicContent(contentKey);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 话题答案点赞
     */
    public void likeTopicAnswer(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int answerId = bundle.getInt("themeId");
        int type = bundle.getInt("type");
        String url = ApiConstants.likeTopicAnswer(answerId, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "likeTopicAnswer-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 评论答案点赞
     */
    public void likeTopicDiscuss(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int discussId = bundle.getInt("discussId");
        int type = bundle.getInt("type");
        String url = ApiConstants.likeTopicDiscuss(discussId, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "likeTopicDiscuss-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 上传图片
     */
    public void uploadImage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // .网络请求、文件请求或数据库请求
        String fileName = bundle.getString("fileName");
        String url = ApiConstants.uploadImage();
        String result = uploadDataToServer(url, fileName, "img");
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "uploadImage-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 根据话题答案编号,获取话题答案
     */
    public void getTopicAnswerByAnswerId(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // .网络请求、文件请求或数据库请求
        int answerId = bundle.getInt("answerId");
        String url = ApiConstants.getTopicAnswerByAnswerId(answerId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getTopicAnswerByAnswerId-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 编辑话题答案
     */
    public void editTopicAnswer(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        int answerId = bundle.getInt("answerId");
        String contentKey = bundle.getString("contentKey");
        String content = MyConfig.getInstance().getMemExchange().getTopicContent(contentKey);
        Logger.i(Logger.DATA_FLOW_TAG, "editTopicAnswer-->answerId:" + answerId + ",content:" + content);
        String url = Config.API_HOST + Config.API_PORT + "/theme/modify/answer.json";
        FormBody body = ApiConstants.editTopicAnswer(answerId, content);
        String result = postRequestBodyToApi(url, body);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "editTopicAnswer-->result:" + result);
        MyConfig.getInstance().getMemExchange().removeTopicContent(contentKey);
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取与自己相关的最新话题回答消息
     */
    public void getNewAnswerMessage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // .网络请求、文件请求或数据库请求
        String url = ApiConstants.getNewAnswerMessage();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getNewAnswerMessage-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_5_MINUTE);//缓存5分钟
    }

    /**
     * 获取与自己相关的最新话题讨论消息
     */
    public void getNewDiscussMessage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // .网络请求、文件请求或数据库请求
        String url = ApiConstants.getNewDiscussMessage();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getNewDiscussMessage-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_5_MINUTE);//缓存5分钟

    }

    /**
     * 获取精选话题
     */
    public void getHandPickTopicList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getHandPickTopicList();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.i(Logger.DATA_FLOW_TAG, "getHandPickTopicList-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_15_MINUTE);//15分钟
    }

    /**
     * 获取视频详情
     */
    public void getVideoDetail(Intent intent) {

        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int videoId = bundle.getInt("videoId");
        // .网络请求、文件请求或数据库请求
        String url = ApiConstants.getVideoDetail(videoId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        Logger.d(Logger.DATA_FLOW_TAG, "getNewDiscussMessage-->result:" + result);
        saveAndBroadcastResult(intent, result, Config.CACHE_5_MINUTE);//缓存5分钟
    }
}
