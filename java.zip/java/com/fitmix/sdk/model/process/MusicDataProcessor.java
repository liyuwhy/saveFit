package com.fitmix.sdk.model.process;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.model.api.ApiConstants;

/**
 * 用户信息数据处理工作类
 */
public class MusicDataProcessor extends BaseProcessor {

    private static MusicDataProcessor mInstance;

    private MusicDataProcessor() {
    }

    /**
     * 获取用户信息数据处理工作类实例
     */
    public static MusicDataProcessor getInstance() {
        if (mInstance == null) {
            mInstance = new MusicDataProcessor();
        }
        return mInstance;
    }

    /**
     * 获取专辑列表
     */
    public void getAlbumList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int type = bundle.getInt("type");
        // 3.网络请求、文件请求或数据库请求
//        String url = ApiConstants.getAlbumList();
        String url = ApiConstants.getAlbumList(type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }

    /**
     * 获取banner列表
     */
    public void getBannerList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getBannerList();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }

    /**
     * 获取歌曲列表
     */
    public void getMusicListFromServerBySceneAndIndex(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int scene = bundle.getInt("scene");
        int index = bundle.getInt("index");
        int type = bundle.getInt("type");
        int sort_type = bundle.getInt("sortType");
        // 3.网络请求、文件请求或数据库请求
        String url = "";
        switch (type) {
            case Config.REQUEST_MUSIC_ALBUM:
                url = ApiConstants.getMusicListFromServerBySceneAndIndex(scene, index, type, sort_type);
                break;
            case Config.REQUEST_RADIO_ALBUM:
                url = ApiConstants.getRadioListFromServerBySceneAndIndex(scene, index, type, sort_type);
                break;
        }
        if (TextUtils.isEmpty(url)) return;
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 根据banner获取推荐专辑
     */
    public void getRadioListFromServerByAlbumId(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int mixAlbumId = bundle.getInt("mixAlbumId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getRadioListFromServerByAlbumId(mixAlbumId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 收藏单首歌曲
     */
    public void favoriteMusicChange(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        int musicId = bundle.getInt("musicId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getFavoriteMusicChangeUrl(uid, musicId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 收藏歌曲列表
     */
    public void favoriteMusicListChange(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        String musicIdList = bundle.getString("musicIdList");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getFavoriteMusicListChangeUrl(uid, musicIdList);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取热词列表
     *
     * @param intent
     */
    public void getKeyWordList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getKeyWordList(uid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 根据关键字搜索歌曲列表
     */
    public void searchMusicByKey(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int index = bundle.getInt("index");
//        int bpm = bundle.getInt("bpm");
//        int scene = bundle.getInt("scene");
//        int genre = bundle.getInt("genre");
//        int duration = bundle.getInt("duration");
        String search = bundle.getString("search");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.searchMusicByKey(index, search);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }


    public void uploadMusicAudition(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int mid = bundle.getInt("mid");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.uploadMusicAudition(mid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    public void getMusicListInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String mids = bundle.getString("mids");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getMusicListInfo(mids);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取推荐的音乐
     */
    public void getRecommendMusic(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getRecommendMusic();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_DAY);
    }
}
