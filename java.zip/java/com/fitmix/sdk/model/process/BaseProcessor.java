package com.fitmix.sdk.model.process;

import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.text.TextUtils;

import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.OkHttpUtil;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusDao;
import com.fitmix.sdk.model.services.DataHandleService;
import com.google.gson.JsonSyntaxException;

import java.util.Date;
import java.util.List;

import de.greenrobot.dao.query.QueryBuilder;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 数据处理类基础,
 */
public class BaseProcessor {

    /**
     * 从Intent中的获取数据请求编号
     *
     * @param intent
     * @return 数据请求编号,
     */
    protected int getRequestId(Intent intent) {
        int requestId = -1;
        if (intent == null) {
            return requestId;
        }
        requestId = intent.getIntExtra(DataHandleService.EXTRA_REQUEST_ID, -1);
        return requestId;
    }

    /**
     * 获取数据请求是否忽略上一次的缓存结果
     *
     * @param intent
     * @return true:忽略,false:不忽略
     */
    protected boolean requestIgnorePreCache(Intent intent) {
        if (intent == null) {
            return false;
        }
        return intent.getBooleanExtra(DataHandleService.EXTRA_REQUEST_IGNORE_CACHE, false);
    }

    /**
     * 从Intent中的获取存储请求参数的Bundle
     *
     * @param intent 数据请求的intent
     * @return 存储请求参数的Bundle
     */
    protected Bundle getRequestBundle(Intent intent) {
        if (intent == null) {
            return null;
        }
        return intent.getBundleExtra(DataHandleService.EXTRA_REQUEST_BUNDLE);
    }

    /**
     * 判断数据请求状态表里的缓存结果是否有效
     *
     * @param intent 数据请求的intent
     * @return true:有效,false:无效
     */
    protected boolean cacheDataIsValid(Intent intent) {
        // 判断是否需要从缓存获取结果,如果需要从缓存获取结果并且存在有效缓存,直接回发通知,
        // 否则返回null表示继续从网络或数据库获取结果
        int requestId = getRequestId(intent);
        boolean ignoreCache = requestIgnorePreCache(intent);
        ResultReceiver callback = intent.getParcelableExtra(DataHandleService.EXTRA_SERVICE_CALLBACK);
        if (ignoreCache) {//忽略缓存
            return false;
        } else {
            try {
                DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao();
                QueryBuilder<DataReqStatus> qb = dataReqStatusDao.queryBuilder();
                qb.where(DataReqStatusDao.Properties.RequestId.eq(requestId));
                if (qb.list().size() > 0) {
                    DataReqStatus dataReqStatus = qb.list().get(0);
                    if (dataReqStatus != null) {
                        long cur = System.currentTimeMillis();
                        long expired = dataReqStatus.getExpired();
                        Date now = new Date(cur);
                        if (now.after(new Date(expired))) {//之前的缓存结果已失效
                            return false;
                        }
                        String ret = dataReqStatus.getResult();
                        if (ret != null) {
                            Logger.i(Logger.DATA_FLOW_TAG, "BaseProcessor-->cacheDataIsValid cache requestId:" + requestId + ",result:" + ret);
                            if (callback != null) {
                                Bundle resultData = new Bundle();
                                resultData.putInt(DataHandleService.EXTRA_REQUEST_ID, requestId);
                                callback.send(DataHandleService.RESULT_BROADCAST_CODE_SUCCESS, resultData);
                            }
                            return true;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                return false;
            }
        }
        return false;
    }

    /**
     * http get方式从后台api获取数据
     *
     * @param url url地址
     * @return 结果字符串
     */
    public String getDataFromApi(String url) {
        Logger.i(Logger.DATA_FLOW_TAG, "getDataFromApi-->url:" + url);
        Request request = new Request.Builder()
                .url(url)
                .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                        ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                        ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                .build();
        String ret;
        //1.判断当前网络状态
        if (ApiUtils.isNetWorkAvailable()) {
            try {
                Response response = OkHttpUtil.getInstance().execute(request);
                if (response != null) {
                    Logger.i(Logger.DATA_FLOW_TAG, "getDataFromApi-->response.isSuccessful():" + response.isSuccessful()
                            + " response.code():" + response.code());
                    if (response.isSuccessful()) {
                        ret = response.body().string();
                    } else {
                        ret = getHttpExceptionString(response.code());//http
                    }
                } else {
                    ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                }
                return ret;
            } catch (Exception ex) {
                ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception:" + ex.getMessage());
            }
        } else {
            ret = getHttpExceptionString(ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
            Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception net work not available");

        }
        return ret;
    }

    /**
     * 上传数据
     *
     * @param url       url地址
     * @param sFilename 上传的文件名
     * @param sTag      上传的文件标签名
     * @return 结果字符串
     */
    public String uploadDataToServer(final String url, final String sFilename, final String sTag) {
        String ret;
        //1.判断当前网络状态
        if (ApiUtils.isNetWorkAvailable()) {
            try {
                ret = OkHttpUtil.getInstance().uploadToServer(url, sFilename, sTag);
                return ret;
            } catch (Exception ex) {
                ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception:" + ex.getMessage());
            }
        } else {
            ret = getHttpExceptionString(ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
            Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception net work not available");
        }
        return ret;
    }

    /**
     * 上传数据
     *
     * @param url       url地址
     * @param sFilename 上传的文件名集合,以英文逗号分隔
     * @param sTag      上传的文件标签名集合,以英文逗号分隔
     * @return 结果字符串
     */
    public String uploadDataToServer(final String url, List<String> sFilename, List<String> sTag) {
        String ret;
//        long now = System.currentTimeMillis();
        //1.判断当前网络状态
        if (ApiUtils.isNetWorkAvailable()) {
            try {
                Logger.i(Logger.DATA_FLOW_TAG, "uploadDataToServer-->url:" + url);
                ret = OkHttpUtil.getInstance().uploadToServer(url, sFilename, sTag);
            } catch (Exception ex) {
                ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                Logger.e(Logger.DATA_FLOW_TAG, "uploadDataToServer-->Exception:" + ex.getMessage());
            }
        } else {
            ret = getHttpExceptionString(ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
            Logger.e(Logger.DATA_FLOW_TAG, "uploadDataToServer-->Exception net work not available");
        }
//        Logger.i(Logger.DATA_FLOW_TAG,"uploadDataToServer time:"+(System.currentTimeMillis() - now));
        return ret;
    }

    /**
     * http post方式从后台api获取数据
     *
     * @param url  url地址
     * @param json post提交的json字符串
     * @return 结果字符串
     */
    protected String postDataToApi(String url, String json) {
        RequestBody body = RequestBody.create(OkHttpUtil.JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                        ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                        ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                .post(body)
                .build();
        try {
            Response response = OkHttpUtil.getInstance().execute(request);
            return response.body().string();
        } catch (Exception e) {

        }
        return null;
    }

    /**
     * post方式从后台api获取数据
     *
     * @param url  url地址
     * @param body post请求体
     * @return 结果字符串
     */
    public String postRequestBodyToApi(String url, RequestBody body) {
        String ret;
        //1.判断当前网络状态
        if (ApiUtils.isNetWorkAvailable()) {
            try {
                Request request = new Request.Builder()
                        .url(url)
                        .addHeader("User-Agent", String.format("Fitmix/%s/%s (Android %s)",
                                ApiUtils.getApkVersionCode(), ApiUtils.getApkVersionName(),
                                ApiUtils.getPhoneSdk() != null ? ApiUtils.getPhoneSdk() : ""))//如Fitmix/44/2.3.0 (Android 4.0)"
                        .post(body)
                        .build();
                Response response = OkHttpUtil.getInstance().execute(request);

                if (response != null) {
                    Logger.i(Logger.DATA_FLOW_TAG, "postRequestBodyToApi-->response.isSuccessful():" + response.isSuccessful()
                            + " response.code():" + response.code());
                    if (response.isSuccessful()) {
                        ret = response.body().string();
                    } else {
                        ret = getHttpExceptionString(response.code());//http
                    }
                } else {
                    ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                }
                return ret;
            } catch (Exception ex) {
                ret = getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION);//http请求异常
                Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception:" + ex.getMessage());
            }
        } else {
            ret = getHttpExceptionString(ApiUtils.HTTP_NETWORK_FAIL);//网络不可用
            Logger.e(Logger.DATA_FLOW_TAG, "getDataFromApi-->Exception net work not available");
        }
        return ret;


    }

    /**
     * 保存并广播数据请求结果
     *
     * @param intent  要保存并广播的数据请求编号
     * @param result  要保存并广播的数据请求结果
     * @param expired 数据请求结果有效期,单位为毫秒
     */
    protected void saveAndBroadcastResult(Intent intent, String result, long expired) {
        if (intent == null) {
            return;
        }
        int requestId = getRequestId(intent);
        ResultReceiver callback = intent.getParcelableExtra(DataHandleService.EXTRA_SERVICE_CALLBACK);
        //如果数据请求结果有效,保存到数据请求状态表并广播成功通知,否则附上失败信息广播失败通知
        if (isHttpResultValid(result)) {
            if (addOrUpdateRequestStatus(requestId, expired, result)) {
                sendRequestSuccessNotify(requestId, callback);//结果成功通知
            } else {
                //通知添加或更新据请求状态表失败
                sendRequestFailNotify(requestId, getHttpExceptionString(ApiUtils.ADD_OR_UPDATE_REQ_STATUS_FAIL), callback);
            }
        } else {
            sendRequestFailNotify(requestId, result, callback);//结果失败通知
        }
    }

    /**
     * 从网络数据结果JSON字符串判断http请求是否成功
     *
     * @param jsonStr 网络数据结果JSON字符串
     * @return true:请求成功,false:请求失败或者异常
     */
    public boolean isHttpResultValid(String jsonStr) {
        /***
         * 1xx Informational
         *    100 Continue
         *    101 Switching Protocols
         *    102 Processing (WebDAV)
         * 2xx Success
         *    200 OK
         *    201 Created
         *    202 Accepted
         *    203 Non-Authoritative Information
         *    204 No Content
         *    205 Reset Content
         *    206 Partial Content
         *    207 Multi-Status (WebDAV)
         *    208 Already Reported (WebDAV)
         *    226 IM Used
         * 3xx Redirection
         *    300 Multiple Choices
         *    301 Moved Permanently
         *    302 Found
         *    303 See Other
         *    304 Not Modified
         *    305 Use Proxy
         *    306 (Unused)
         *    307 Temporary Redirect
         *    308 Permanent Redirect (experiemental)
         * 4xx Client Error
         *    400 Bad Request
         *    401 Unauthorized
         *    402 Payment Required
         *    403 Forbidden
         *    404 Not Found
         *    405 Method Not Allowed
         *    406 Not Acceptable
         *    407 Proxy Authentication Required
         *    408 Request Timeout
         *    409 Conflict
         *    410 Gone
         *    411 Length Required
         *    412 Precondition Failed
         *    413 Request Entity Too Large
         *    414 Request-URI Too Long
         *    415 Unsupported Media Type
         *    416 Requested Range Not Satisfiable
         *    417 Expectation Failed
         *    418 I'm a teapot (RFC 2324)
         *    420 Enhance Your Calm (Twitter)
         *    422 Unprocessable Entity (WebDAV)
         *    423 Locked (WebDAV)
         *    424 Failed Dependency (WebDAV)
         *    425 Reserved for WebDAV
         *    426 Upgrade Required
         *    428 Precondition Required
         *    429 Too Many Requests
         *    431 Request Header Fields Too Large
         *    444 No Response (Nginx)
         *    449 Retry With (Microsoft)
         *    450 Blocked by Windows Parental Controls (Microsoft)
         *    451 Unavailable For Legal Reasons
         *    499 Client Closed Request (Nginx)
         * 5xx Server Error
         *    500 Internal Server Error
         *    501 Not Implemented
         *    502 Bad Gateway
         *    503 Service Unavailable
         *    504 Gateway Timeout
         *    505 HTTP Version Not Supported
         *    506 Variant Also Negotiates (Experimental)
         *    507 Insufficient Storage (WebDAV)
         *    508 Loop Detected (WebDAV)
         *    509 Bandwidth Limit Exceeded (Apache)
         *    510 Not Extended
         *    511 Network Authentication Required
         *    598 Network read timeout error
         *    599 Network connect timeout error
         * */
        Logger.i(Logger.DATA_FLOW_TAG, "isHttpResultValid jsonStr:" + jsonStr);
        try {
            BaseBean baseBean = JsonHelper.getObject(jsonStr, BaseBean.class);
//            Logger.e(Logger.DATA_FLOW_TAG, "isHttpResultValid baseBean is null:" + (baseBean == null));
            if (baseBean != null) {
                int code = baseBean.getCode();
                String token = baseBean.getK();//获取从服务器得到的k值
//                Logger.i(Logger.DATA_FLOW_TAG, "isHttpResultValid code:" + code + " token is null:" + (token == null));
                if (!TextUtils.isEmpty(token)) {
                    ApiUtils.setApiToken(token);
//                    Logger.i(Logger.DATA_FLOW_TAG, "isHttpResultValid token:" + token);
                }
                // code == 0 也表示成功,因为请求成功后,服务器返回的code为0
                if (code == 0 || (code >= 200 && code < 300)) {
                    return true;
                }
            } else {
                return false;
            }
        } catch (JsonSyntaxException ex) {
            Logger.e(Logger.DATA_FLOW_TAG, "isHttpResultValid JsonSyntaxException:" + ex.getMessage());
        }
        return false;
    }

    /**
     * 同步方式添加或更新数据请求状态
     *
     * @param requestId 要添加或更新的数据请求编号
     * @param expired   数据请求结果有效期,单位为毫秒
     * @param result    数据请求结果
     * @return true:添加或更新数据请求状态成功,false:添加或更新数据请求状态失败
     */
    public boolean addOrUpdateRequestStatus(int requestId, long expired, String result) {
        DataReqStatus dataReqStatus = new DataReqStatus(null, requestId, expired, result);
        try {
//            Logger.i(Logger.DATA_FLOW_TAG, "BaseProcessor-->addOrUpdateRequestStatus current Thread:" + Thread.currentThread().getId() + ",requestId:"+requestId
//            +",result:"+result);
            DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao();
            dataReqStatusDao.insertOrReplace(dataReqStatus);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            Logger.e(Logger.DATA_FLOW_TAG, "addOrUpdateRequestStatus exception:" + ex.getMessage());
        }
        Logger.i(Logger.DATA_FLOW_TAG, "greenDao addOrUpdateRequestStatus");
        return false;
    }

    /**
     * 回发数据请求结果成功的通知
     *
     * @param requestId 数据请求编号
     * @param callback  数据请求结果通知回调
     */
    private void sendRequestSuccessNotify(int requestId, ResultReceiver callback) {
        if (callback != null) {
            Bundle resultBundle = new Bundle();
            resultBundle.putInt(DataHandleService.EXTRA_REQUEST_ID, requestId);
            callback.send(DataHandleService.RESULT_BROADCAST_CODE_SUCCESS, resultBundle);
        }
    }

    /**
     * 回发数据请求结果失败的通知
     *
     * @param requestId 数据请求编号
     * @param result    数据请求失败结果
     * @param callback  数据请求结果通知回调
     */
    private void sendRequestFailNotify(int requestId, String result, ResultReceiver callback) {
        if (callback != null) {
            Bundle resultBundle = new Bundle();
            resultBundle.putInt(DataHandleService.EXTRA_REQUEST_ID, requestId);
            if (!TextUtils.isEmpty(result)) {
                resultBundle.putString(DataHandleService.EXTRA_BROADCAST_RESULT_STR, result);
            } else {
                resultBundle.putString(DataHandleService.EXTRA_BROADCAST_RESULT_STR, getHttpExceptionString(ApiUtils.HTTP_REQUEST_EXCEPTION));
            }
            callback.send(DataHandleService.RESULT_BROADCAST_CODE_FAIL, resultBundle);
        }
    }

    /**
     * 根据http状态码,生成http异常结果JSON字符串,形式如{'code':404}
     *
     * @param httpCode http状态码,各个数字的意义参考HTTP协议,自定义部分参考 {@link com.fitmix.sdk.model.api.ApiUtils }
     * @return 生成异常结果JSON字符串, 形式如{'code':404}
     */
    protected String getHttpExceptionString(int httpCode) {
        return String.format("{ 'code':%s }", httpCode);
    }


}
