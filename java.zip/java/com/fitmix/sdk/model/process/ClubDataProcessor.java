package com.fitmix.sdk.model.process;

import android.content.Intent;
import android.os.Bundle;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.model.api.ApiConstants;

/**
 * 用户信息数据处理工作类
 */
public class ClubDataProcessor extends BaseProcessor {

    private static ClubDataProcessor mInstance;

    private ClubDataProcessor() {
    }

    /**
     * 获取用户信息数据处理工作类实例
     */
    public static ClubDataProcessor getInstance() {
        if (mInstance == null) {
            mInstance = new ClubDataProcessor();
        }
        return mInstance;
    }

    /**
     * 获取俱乐部列表
     */
    public void getClubList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("Uid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubList(uid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 获取俱乐部动态
     */
    public void getClubDynamicList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int index = bundle.getInt("index");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubDynamicUrl(clubId, index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部公告
     */
    public void getClubNoticeList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int index = bundle.getInt("index");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubNoticeUrl(clubId, index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部排行列表
     */
    public void getClubRankList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int index = bundle.getInt("index");
        int type = bundle.getInt("type");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubRankList(clubId, index, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部排行信息
     */
    public void getClubRankInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int type = bundle.getInt("type");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubRankInfo(clubId, type);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部留言
     */
    public void getClubMessage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int index = bundle.getInt("index");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubMessage(clubId, index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部活跃信息
     */
    public void getClubActiveInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubActiveInfo(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部活跃用户信息
     */
    public void getClubActiveUser(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubActiveUser(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部成员列表
     */
    public void getClubMemberList(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int index = bundle.getInt("index");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getClubMemberList(clubId, index);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部成员列表
     */
    public void deleteClubMember(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        int quitUid = bundle.getInt("quitUid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteClubMember(clubId, quitUid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部成员列表
     */
    public void getLastRunlogInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getLastRunLogInfo(uid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取俱乐部成员列表
     */
    public void quitClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.quitClub(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 获取分享俱乐部的分享地址
     */
    public void getShareClubUrl(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getShareClubUrl(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 创建俱乐部
     */
    public void createClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String clubName = bundle.getString("clubName");
        String clubDesc = bundle.getString("clubDesc");
        String fileName = bundle.getString("fileName");
        String tag = bundle.getString("tag");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.createClub(clubName, clubDesc);
        String result = uploadDataToServer(url, fileName, tag);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 更改俱乐部
     */
    public void modifyClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        String clubName = bundle.getString("clubName");
        String clubDesc = bundle.getString("clubDesc");
        String fileName = bundle.getString("fileName");
        String tag = bundle.getString("tag");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.modifyClub(clubId, clubName, clubDesc);
        String result = uploadDataToServer(url, fileName, tag);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 更改俱乐部
     */
    public void deleteClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteClub(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 创建俱乐部
     */
    public void createClubNotice(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        String name = bundle.getString("name");
        String content = bundle.getString("content");
        String address = bundle.getString("address");
        long beginTime = bundle.getLong("beginTime");
        long endTime = bundle.getLong("endTime");
        String desc = bundle.getString("desc");
        String fileName = bundle.getString("fileName");
        String tag = bundle.getString("tag");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.createClubNotice(clubId, name, content, address, beginTime, endTime, desc);
        String result = uploadDataToServer(url, fileName, tag);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 更改俱乐部
     */
    public void modifyClubNotice(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int noticeId = bundle.getInt("noticeId");
        int clubId = bundle.getInt("clubId");
        String name = bundle.getString("name");
        String content = bundle.getString("content");
        String address = bundle.getString("address");
        long beginTime = bundle.getLong("beginTime");
        long endTime = bundle.getLong("endTime");
        String desc = bundle.getString("desc");
        String fileName = bundle.getString("fileName");
        String tag = bundle.getString("tag");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.modifyClubNotice(noticeId, clubId, name, content, address, beginTime, endTime, desc);
        String result = uploadDataToServer(url, fileName, tag);
//        Logger.i(Logger.DATA_FLOW_TAG, "modifyClubNotice-->url : " + url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 更改俱乐部
     */
    public void deleteClubNotice(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int noticeId = bundle.getInt("noticeId");
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteClubNotice(noticeId, clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 查找俱乐部
     */
    public void findClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.findClub(clubId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 添加留言
     */
    public void addClubMessage(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int clubId = bundle.getInt("clubId");
        String content = bundle.getString("content");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.addClubMessage(clubId, content);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

    /**
     * 邀请加入俱乐部
     */
    public void joinClub(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String clubId = bundle.getString("clubId");
        int addUid = bundle.getInt("addUid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.joinClub(clubId, addUid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }

}
