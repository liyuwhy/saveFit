package com.fitmix.sdk.model.process;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.encrypt.Base64Util;
import com.fitmix.sdk.common.encrypt.KeyRSAUtil;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.manager.UserDataManager;

import okhttp3.FormBody;

/**
 * 运动信息数据处理工作类
 */
public class SportDataProcessor extends BaseProcessor {
    private static SportDataProcessor mInstance;

    private SportDataProcessor() {
    }

    /**
     * 获取运动信息数据处理工作类实例
     */
    public static SportDataProcessor getInstance() {
        if (mInstance == null) {
            mInstance = new SportDataProcessor();
        }
        return mInstance;
    }

//    /**
//     * 上传今日步数到微信运动
//     */
//    public void setWeChatTodaySteps(Intent intent) {
//        // 1.判断上一次请求的结果是否有效
//        if (cacheDataIsValid(intent)) {
//            return;
//        }
//        // 2. 解出参数
//        Bundle bundle = getRequestBundle(intent);
//        if (bundle == null) {
//            return;
//        }
//        String unionId = bundle.getString("unionid");
//        String openId = bundle.getString("openid");
//        int todaySteps = bundle.getInt("step");
//        // 3.网络请求、文件请求或数据库请求
//        String url = ApiConstants.setWeChatTodaySteps(unionId, openId, todaySteps);
//        String result = getDataFromApi(url);
//        Logger.i(Logger.DATA_FLOW_TAG, "setWeChatTodaySteps unionId:" + unionId + " \n openId:" + openId
//                + " \n todaySteps:" + todaySteps
//                + " \n result:" + result);
//        //4.保存并广播数据请求结果
//        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
//
//        //5.保存到sp
//        if(result != null) {
//            PrefsHelper.with(MixApp.getContext(), Config.PREFS_SPORT).write(Config.SP_KEY_SYNC_WECHAT_STEP,result);
//        }
//    }

    /**
     * 上传今日步数到微信运动,新接口加密
     */
    public void setWeChatTodayStepsNew(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String unionId = bundle.getString("unionid");
        String openId = bundle.getString("openid");
        int todaySteps = bundle.getInt("step");
        String source = String.format("_tp==%s^^uid==%s^^unionid==%s^^openid==%s^^step==%s", System.currentTimeMillis(), UserDataManager.getUid(), unionId, openId, todaySteps);
//        String source = String.format("_tp==%s^^uid==92366556^^unionid==oIoQTs_12mO0gNPEVKfOYV1zjC2g^^openid==oBmGhuCuJ64liZgaHjZA3riLL2I8^^step==50000457", System.currentTimeMillis());
        Logger.i(Logger.DATA_FLOW_TAG, "setWeChatTodaySteps source:" + source);
        String result = "";
        try {
            String rsa = KeyRSAUtil.encrypt(source);
            String parameter = Base64Util.IBase64.encode(rsa.getBytes());
            Logger.i(Logger.DATA_FLOW_TAG, "source:" + source + "\nrsa:" + rsa + "\nparameter:" + parameter);
            // 3.网络请求、文件请求或数据库请求
            String url = ApiConstants.setWeChatTodaySteps(parameter);
            result = getDataFromApi(url);
            Logger.i(Logger.DATA_FLOW_TAG, "setWeChatTodaySteps unionId:" + unionId + " \n openId:" + openId
                    + " \n todaySteps:" + todaySteps
                    + " \n result:" + result);
            //4.保存并广播数据请求结果
            saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
            //5.保存到sp
            if (result != null) {
                PrefsHelper.with(MixApp.getContext(), Config.PREFS_SPORT).write(Config.SP_KEY_SYNC_WECHAT_STEP, result);
            }
        } catch (Exception e) {
            if (!TextUtils.isEmpty(e.getMessage())) {
                result = String.format("{ 'code':%s,'msg':%s}", 700, e.getMessage());
            }
            Logger.e(Logger.DEBUG_TAG, "setWeChatTodaySteps Exception e:" + e.getMessage());
        }
        Logger.d(Logger.DEBUG_TAG, "setWeChatTodaySteps result:" + result);
    }

    /**
     * 从后台服务器获取用户历史跑步记录
     */
    public void getHistoryRunRecords(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long lastUpdateTime = bundle.getLong("lastUpdateTime");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getHistoryRunRecords(uid, lastUpdateTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }

    /**
     * 获取用户月运动排行榜数据
     */
    public void getRankListData(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long time = bundle.getLong("time");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getRankListData(uid, time);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);
    }

    /**
     * 运动月排行榜用户PK
     */
    public void getRankListPKData(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long time = bundle.getLong("time");
        int targetUid = bundle.getInt("targetUid");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getRankListPKData(uid, time, targetUid);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_IGNORE);
    }


    /**
     * 运动月排行榜  各个level
     */
    public void getRankListLevelData(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int pageNo = bundle.getInt("pageNo");
        int uid = bundle.getInt("uid");
        long time = bundle.getLong("time");
        int level = bundle.getInt("level");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getRankListLevelData(uid, time, level, pageNo);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }


    /**
     * 分享跑步记录
     */
    public void shareRunRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        long startTime = bundle.getLong("startTime");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.shareRunRecord(startTime);
        Logger.i(Logger.DATA_FLOW_TAG, "url : " + url);
        String result = getDataFromApi(url);
        Logger.i(Logger.DATA_FLOW_TAG, "result : " + result);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

//    /**
//     * 添加运动记录,V2.3.8之后不再使用
//     */
//    public void addSportRecord(Intent intent) {
//        // 1.判断上一次请求的结果是否有效
//        if (cacheDataIsValid(intent)) {
//            return;
//        }
//        // 2. 解出参数
//        Bundle bundle = getRequestBundle(intent);
//        if (bundle == null) {
//            return;
//        }
//
//        int uid = bundle.getInt("uid");
//        int type = bundle.getInt("type");
//        int mode = bundle.getInt("mode");
//        int locationType = bundle.getInt("locationType");
//        int bpm = bundle.getInt("bpm");
//        int bpmMatch = bundle.getInt("bpmMatch");
//        int step = bundle.getInt("step");
//        long calorie = bundle.getLong("calorie");
//        long runTime = bundle.getLong("runTime");
//        long startTime = bundle.getLong("startTime");
//        long endTime = bundle.getLong("endTime");
//        long distance = bundle.getLong("distance");
//        double startLng = bundle.getDouble("startLng");
//        double startLat = bundle.getDouble("startLat");
//        double endLng = bundle.getDouble("endLng");
//        double endLat = bundle.getDouble("endLat");
//
//        //3.获取要上传的文件列表和标签
//        String files = bundle.getString("files");
//        String fileTags = bundle.getString("fileTags");
//        List<String> fileNames = new ArrayList<>();
//        List<String> fileTagList = new ArrayList<>();
//
//        try {
//            if (!TextUtils.isEmpty(files)) {
//                String[] names = files.split(",");
//                Collections.addAll(fileNames, names);
//            }
//            if (!TextUtils.isEmpty(fileTags)) {
//                String[] tags = fileTags.split(",");
//                Collections.addAll(fileTagList, tags);
//            }
//        } catch (Exception e) {
//
//        }
//
//        // 4.网络请求、文件请求或数据库请求
//        String url = ApiConstants.addSportRecord(uid, type, mode, locationType, bpm, bpmMatch, step,
//                calorie, runTime, startTime, endTime, distance,
//                startLng, startLat, endLng, endLat);
//        String result;
//        if(fileNames.size() > 0) {//有文件时,调用带上传文件的接口
//            result = uploadDataToServer(url, fileNames, fileTagList);
//        }else{//调用
//            result = getDataFromApi(url);
//        }
//        Logger.i(Logger.DATA_FLOW_TAG, "addSportRecord result:" + result);
//        // 4.保存并广播数据请求结果
//        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
//    }

//    /**
//     * 添加运动记录
//     */
//    public void addSkipSportRecord(Intent intent) {
//        // 1.判断上一次请求的结果是否有效
//        if (cacheDataIsValid(intent)) {
//            return;
//        }
//        // 2. 解出参数
//        Bundle bundle = getRequestBundle(intent);
//        if (bundle == null) {
//            return;
//        }
//
//        int uid = bundle.getInt("uid");
//        int type = bundle.getInt("type");
//        int bpm = bundle.getInt("bpm");
//        int bpmMatch = bundle.getInt("bpmMatch");
//        int skipNumber = bundle.getInt("skipNumber");
//        long calorie = bundle.getLong("calorie");
//        long runTime = bundle.getLong("runTime");
//        long startTime = bundle.getLong("startTime");
//        long endTime = bundle.getLong("endTime");
//
//        //3.获取要上传的文件列表和标签
//        String files = bundle.getString("files");
//        String fileTags = bundle.getString("fileTags");
//
//        // 4.网络请求、文件请求或数据库请求
//        String url = ApiConstants.addSkipSportRecord(uid, bpm, runTime, startTime, endTime, type,bpmMatch, skipNumber,calorie, 0);
//        String result = uploadDataToServer(url, files, fileTags);
//
//        // 4.保存并广播数据请求结果
//        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
//    }

    /**
     * 添加跳绳运动记录
     */
    public void addSkipSportRecordWithHeartRate(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        int type = bundle.getInt("type");
        int bpm = bundle.getInt("bpm");
        int bpmMatch = bundle.getInt("bpmMatch");
        int skipNumber = bundle.getInt("skipNumber");
        long calorie = bundle.getLong("calorie");
        long runTime = bundle.getLong("runTime");
        long startTime = bundle.getLong("startTime");
        long endTime = bundle.getLong("endTime");
        String heartRateData = bundle.getString("heartRate");
        //3.获取要上传的文件列表和标签
        String files = bundle.getString("files");
        String fileTags = bundle.getString("fileTags");
//        List<String> fileNames = new ArrayList<>();
//        List<String> fileTagList = new ArrayList<>();
//
//        try {
//            if (!TextUtils.isEmpty(files)) {
//                String[] names = files.split(",");
//                Collections.addAll(fileNames, names);
//            }
//            if (!TextUtils.isEmpty(fileTags)) {
//                String[] tags = fileTags.split(",");
//                Collections.addAll(fileTagList, tags);
//            }
//        } catch (Exception e) {
//
//        }

        // 4.网络请求、文件请求或数据库请求
        String url = ApiConstants.addSkipSportRecordWithHeartRate(uid, bpm, runTime, startTime, endTime, type, bpmMatch, skipNumber, calorie, heartRateData);
        String result = uploadDataToServer(url, files, fileTags);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 删除后台服务器上的跳绳记录
     */
    public void deleteSkipRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long skipStartTime = bundle.getLong("skipStartTime");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteSkipRecord(uid, skipStartTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    /**
     * 删除后台服务器上的跑步记录
     */
    public void deleteRunRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long runStartTime = bundle.getLong("runStartTime");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteRunRecord(uid, runStartTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    /**
     * 从后台服务器获取用户历史跳绳记录
     */
    public void getHistorySkipRecords(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long lastUpdateTime = bundle.getLong("lastUpdateTime");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getHistorySkipRecords(uid, lastUpdateTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }

    /**
     * 同步步数到QQ运动
     */
    public void syncToQQSport(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String access_token = bundle.getString("access_token");
        String openid = bundle.getString("openid");
        long time = bundle.getLong("time");
        long distance = bundle.getLong("distance");
        int steps = bundle.getInt("steps");
        long duration = bundle.getLong("duration");
        long calories = bundle.getLong("calories");

        // 3.网络请求、文件请求或数据库请求
        FormBody postBody = ApiConstants.syncToQQSport(access_token, openid, time, distance, steps, duration, calories);
        String url = ApiConstants.getSyncToQQSportUrl();
        String result = postRequestBodyToApi(url, postBody);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);
    }

    /**
     * 分享跑步记录
     */
    public void shareRunRecordLite(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long distance = bundle.getLong("distance");
        long runTime = bundle.getLong("runTime");
        long step = bundle.getLong("step");
        long bpm = bundle.getLong("bpm");
        long calorie = bundle.getLong("calorie");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.shareRunRecordLite(uid, distance, runTime, step, bpm, calorie);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 获得语音包下载的列表信息
     */
    public void getVoicePackageInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int voiceType = bundle.getInt("voiceType");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getVoicePackageInfo(voiceType);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1分钟
    }

    /**
     * 获得语音包下载的链接地址url列表信息
     */
    public void getVoicePackageUrlInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int voiceId = bundle.getInt("voiceId");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getVoicePackageUrlInfo(voiceId);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1分钟
    }


    public void uploadRestHeartRateInfo(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        int heartRateVal = bundle.getInt("heartRateVal");
        long detectTime = bundle.getLong("detectTime");
        String url = ApiConstants.addRestHeartRateInfo(uid, heartRateVal, detectTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_USELESS);//不缓存
    }

    public void getAllRestHeartRateHistory(Intent intent) {
        if (cacheDataIsValid(intent)) {
            return;
        }
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int uid = bundle.getInt("uid");
        int index = bundle.getInt("index");
        int isAll = bundle.getInt("isAll");
        String url = ApiConstants.getAllRestHeartRateHistory(uid, index, isAll);
        String result = getDataFromApi(url);
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);
    }

    /**
     * 分享跳绳记录
     */
    public void shareSkipRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        long startTime = bundle.getLong("startTime");
        String file = bundle.getString("file");
        String fileTag = bundle.getString("fileTag");
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.shareSkipRecord(startTime);
        Logger.i(Logger.DATA_FLOW_TAG, "url : " + url);
        String result = uploadDataToServer(url, file, fileTag);
        Logger.i(Logger.DATA_FLOW_TAG, "result : " + result);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 生成训练计划
     */
    public void createTrainingPlan(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int runDistance = bundle.getInt("runDistance");
        long competitionTime = bundle.getLong("competitionTime");
        long planTime = bundle.getLong("planTime");
        long projectTime = bundle.getLong("projectTime");
        int runProject = bundle.getInt("runProject");
        int gender = bundle.getInt("gender");
        int age = bundle.getInt("age");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.createTrainingPlan(runDistance, competitionTime, planTime, projectTime, runProject, gender, age);
        Logger.i(Logger.DATA_FLOW_TAG, "createTrainingPlan --- > url : " + url);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 获取进行中的计划
     */
    public void getTrainingPlan(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getTrainingPlan();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 获取结束的计划
     */
    public void getTrainedPlan(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getTrainedPlan();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 计划延期
     */
    public void delayTrainPlan(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        int delayDay = bundle.getInt("delayDay");

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.delayTrainPlan(delayDay);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 计划延期
     */
    public void deleteTrainPlan(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.deleteTrainPlan();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 获取当天训练计划
     */
    public void getTodayStages(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getTodayStages();
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }

    /**
     * 向后台上传用户传感器异常错误日志
     */
    public void uploadSensorAbnormalError(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }
        String content = bundle.getString("content");
        String other = bundle.getString("other");

        // 3.网络请求、文件请求或数据库请求
        FormBody postBody = ApiConstants.getErrorBody(content, other);
        String url = ApiConstants.uploadErrorLog();
        String result = postRequestBodyToApi(url, postBody);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_HOUR);//缓存1小时
    }

    /**
     * 从后台服务器获取手表运动记录
     */
    public void getWatchSportRecord(Intent intent) {
        // 1.判断上一次请求的结果是否有效
        if (cacheDataIsValid(intent)) {
            return;
        }
        // 2. 解出参数
        Bundle bundle = getRequestBundle(intent);
        if (bundle == null) {
            return;
        }

        int uid = bundle.getInt("uid");
        long lastUpdateTime = bundle.getLong("lastUpdateTime", 0);

        // 3.网络请求、文件请求或数据库请求
        String url = ApiConstants.getWatchSportRecord(uid, lastUpdateTime);
        String result = getDataFromApi(url);
        // 4.保存并广播数据请求结果
        saveAndBroadcastResult(intent, result, Config.CACHE_1_MINUTE);//缓存1分钟
    }


}


