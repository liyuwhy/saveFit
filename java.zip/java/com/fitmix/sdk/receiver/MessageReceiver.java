package com.fitmix.sdk.receiver;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyLifecycleHandler;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.MessageHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.view.activity.ClubDetailActivity;
import com.fitmix.sdk.view.activity.MainActivity;
import com.fitmix.sdk.view.activity.PlayMusicActivity;
import com.fitmix.sdk.view.activity.TopicDetailActivity;
import com.fitmix.sdk.view.activity.VideoDetailActivity;
import com.fitmix.sdk.view.activity.WebViewActivity;
import com.tencent.android.tpush.XGPushBaseReceiver;
import com.tencent.android.tpush.XGPushClickedResult;
import com.tencent.android.tpush.XGPushRegisterResult;
import com.tencent.android.tpush.XGPushShowedResult;
import com.tencent.android.tpush.XGPushTextMessage;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * 信鸽推送 提供<b>透传消息</b>的接收和操作结果的反馈
 * <p>
 * 透传消息指的是下发的消息默认是不会展示在通知栏的，信鸽只负责将消息从信鸽服务器下发到APP这个过程，不负责消息的处理逻辑，需要APP自己实现
 */
public class MessageReceiver extends XGPushBaseReceiver {

    @Override
    public void onRegisterResult(Context context, int errorCode,
                                 XGPushRegisterResult message) {//注册结果
        if (context == null || message == null) {
            return;
        }
        String text;
        if (errorCode == XGPushBaseReceiver.SUCCESS) {
            // 在这里拿token
//            String token = message.getToken();
            text = message + "注册成功";
        } else {
            text = message + "注册失败，错误码：" + errorCode;
        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onRegisterResult:" + text);
    }

    @Override
    public void onUnregisterResult(Context context, int errorCode) {//反注册结果
        if (context == null) {
            return;
        }
        String text;
        if (errorCode == XGPushBaseReceiver.SUCCESS) {
            text = "反注册成功";
        } else {
            text = "反注册失败" + errorCode;
        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onUnregisterResult:" + text);
    }

    @Override
    public void onSetTagResult(Context context, int errorCode, String tagName) {//设置标签结果,暂时不考虑
        if (context == null) {
            return;
        }
        String text;
        if (errorCode == XGPushBaseReceiver.SUCCESS) {
            text = "\"" + tagName + "\"设置成功";
        } else {
            text = "\"" + tagName + "\"设置失败,错误码：" + errorCode;
        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onSetTagResult:" + text);
    }

    @Override
    public void onDeleteTagResult(Context context, int errorCode, String tagName) {//删除标签结果,暂时不考虑
        if (context == null) {
            return;
        }
        String text;
        if (errorCode == XGPushBaseReceiver.SUCCESS) {
            text = "\"" + tagName + "\"删除成功";
        } else {
            text = "\"" + tagName + "\"删除失败,错误码：" + errorCode;
        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onDeleteTagResult:" + text);

    }


    // 通知被展示触发的结果，可以在此保存APP收到的通知
    @Override
    public void onNotifactionShowedResult(Context context,
                                          XGPushShowedResult result) {
        if (context == null || result == null) {
            return;
        }

        //notificationActionType==1为Activity，2为url，3为intent
        String text = "id:" + result.getMsgId() + ",title:" + result.getTitle()
                + ",content:" + result.getContent() + ",custom content:" + result.getCustomContent()
                + ",NotificationActionType:" + result.getNotificationActionType()
                + ",activity:" + result.getActivity();
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onNotifactionShowedResult " + text);

        // 保存自定义的消息到数据库消息表(Message)
        try {
            JSONObject custom = new JSONObject(result.getCustomContent());
            //  parserCustomMessage(custom);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    // 通知点击回调 actionType=1为该消息被清除，actionType=0为该消息被点击
    @Override
    public void onNotifactionClickedResult(Context context,
                                           XGPushClickedResult message) {//通知被打开触发的结果
        if (context == null || message == null) {
            return;
        }
        String text = "";

//        String title = message.getTitle();

        if (message.getActionType() == XGPushClickedResult.NOTIFACTION_CLICKED_TYPE) {
            // 通知在通知栏被点击啦。。。。。
            // APP自己处理点击的相关动作
            // 这个动作可以在activity的onResume也能监听，请看第3点相关内容
            text = "通知被打开 :" + message;

            // 获取自定义key-value
            String customContent = message.getCustomContent();
            if (customContent != null && customContent.length() != 0) {
                Logger.i(Logger.XG_TAG, "MessageReceiver-->onNotifactionClickedResult customContent:" + customContent);
                try {
                    JSONObject obj = new JSONObject(customContent);// customContent={"channel":"14","msgBody":"{\"id\":447,\"title\":\"好的吧喜不喜欢\"}"}
                    int channel = Integer.parseInt(obj.getString("channel"));
                    String msgBody = obj.getString("msgBody");
                    JSONObject msgObj = new JSONObject(msgBody);
                    String link = "";
                    if (msgObj.has("link")) {
                        link = msgObj.getString("link");
                    }
                    int id = 0;
                    if (msgObj.has("id")) {
                        id = msgObj.getInt("id");
                    }
                    int clubId = 0;
                    if (msgObj.has("clubId")) {
                        clubId = msgObj.getInt("clubId");
                    }

                    Intent intent = new Intent();
                    switch (channel) {
                        case 2://发送短信
                            break;
                        case 10://俱乐部消息 推送
                            intent.setClass(context, ClubDetailActivity.class);
                            intent.putExtra("isFromXgNotify", true);
                            intent.putExtra("isMessage", true);
                            intent.putExtra("clubId", clubId);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 11://俱乐部通知 推送
                            intent.setClass(context, ClubDetailActivity.class);
                            intent.putExtra("isFromXgNotify", true);
                            intent.putExtra("clubId", clubId);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 12://训练计划消息 推送

                            break;
                        case 13://赛事消息 推送
                            intent.setClass(context, WebViewActivity.class);
                            intent.putExtra("competitionString", String.valueOf(id));
                            intent.putExtra("title", context.getResources().getString(R.string.activity_main_competitions_detail));
                            intent.putExtra("isCanShare", true);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 14://话题推荐 推送
                            intent.setClass(context, TopicDetailActivity.class);
                            intent.putExtra("isFromXgNotify", true);
                            intent.putExtra("topicId", id);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 15://Mix推荐 推送
                            intent.setClass(context, PlayMusicActivity.class);
                            intent.putExtra("isFromXinGe", true);
                            intent.putExtra("musicId", id);
                            intent.putExtra("index", 0);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 16://电台推荐 推送
                            intent.setClass(context, PlayMusicActivity.class);
                            intent.putExtra("isFromXinGe", true);
                            intent.putExtra("musicId", id);
                            intent.putExtra("index", 0);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 17://视频推荐 推送
                            intent.setClass(context, VideoDetailActivity.class);
                            intent.putExtra("isFromXinGe", true);
                            intent.putExtra("videoId", id);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);

                            break;
                        case 18://外链  推送
                            intent.setClass(context, WebViewActivity.class);
                            intent.putExtra("url", link);
                            intent.putExtra("title", message.getTitle());
                            intent.putExtra("fromSplashActivity", false);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                        case 19://私信  推送
                        case 20://话题  被回答了
                        case 21://话题回答  被讨论了
                            intent.setClass(context, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                            break;
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        } else if (message.getActionType() == XGPushClickedResult.NOTIFACTION_DELETED_TYPE) {
            // 通知被清除啦。。。。
            // APP自己处理通知被清除后的相关动作
            text = "通知被清除 :" + message;
        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onNotifactionClickedResult " + text);


        //APP自主处理的过程...

    }


    @Override
    public void onTextMessage(Context context, XGPushTextMessage message) {//消息透传
        String text = "收到消息:" + message.toString();
        // 获取自定义key-value
        String customContent = message.getCustomContent();
        if (customContent != null && customContent.length() != 0) {
            try {
                JSONObject obj = new JSONObject(customContent);// customContent={"channel":"14","msgBody":"{\"id\":447,\"title\":\"好的吧喜不喜欢\"}"}
                int channel = Integer.parseInt(obj.getString("channel"));
//                String msgBody = obj.getString("msgBody");
//                JSONObject msgObj = new JSONObject(msgBody);

//                String link = "";
//                if (msgObj.has("link")) {
//                    link = msgObj.getString("link");
//                }
//                int id = 0;
//                if (msgObj.has("id")) {
//                    id = msgObj.getInt("id");
//                }
//                int clubId = 0;
//                if (msgObj.has("clubId")) {
//                    clubId = msgObj.getInt("clubId");
//                }

                Intent intent = new Intent();
                switch (channel) {
                    case 19://私信  推送
                    case 20://话题  被回答了
                    case 21://话题回答  被讨论了
                        SettingsHelper.putBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, true);
                        if (MyLifecycleHandler.isApplicationInForeground()) {
                            Intent intent1 = new Intent("com.fitmix.broadcasttest.LOCAL_BROADCAST");
                            intent1.putExtra("showRedPoint", true);
                            LocalBroadcastManager.getInstance(context).sendBroadcast(intent1);
                        } else {
                            intent.setClass(context, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intent);
                        }
                        break;
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        Logger.i(Logger.XG_TAG, "MessageReceiver-->onTextMessage:" + text);
    }

    //region ================================ 解析自定义消息 ================================

    /**
     * 解析自定义消息
     */
    private void parserCustomMessage(JSONObject json) throws Exception {
        int pushType = json.getInt("pushType");
        switch (pushType) {
            case 1://赛事类型
                onDiscoveryMessagePush();
                break;
            case 2://俱乐部消息
                String otherInfo = json.getString("otherInfo");
                if (TextUtils.isEmpty(otherInfo)) return;
                JSONObject json1 = new JSONObject(otherInfo);
                int clubId = json1.getInt("clubId");
                int type = json1.getInt("type");
                if (type == 11) {
                    setClubHaveNewMessage(clubId, 4, 1);
                } else if (type == 12) {
                    setClubHaveNewMessage(clubId, 2, 1);
                }
                break;
        }
    }

    /**
     * 有新赛事消息的通知
     */
    protected void onDiscoveryMessagePush() {
        //保存有新赛事的信息
        MessageHelper.getInstance().insertMessage(3);
    }

    /**
     * @param clubID 有新消息的俱乐部ID
     * @param type   2、该俱乐部有新的活动公告 4、该俱乐部有新留言
     * @param number 消息数量
     */
    private void setClubHaveNewMessage(int clubID, int type, int number) {
        MessageHelper.getInstance().insertMessage(clubID, type, number);
    }

    //endregion ================================ 解析自定义消息 ================================

}
