package com.fitmix.sdk.bean;

/**
 * 省市spinner选项
 */
public class SpinnerListItem {
    private String name;
    private int id;
    private String zipCode;

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int Id) {
        this.id = Id;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    @Override
    public String toString() {
        return name;
    }
}
