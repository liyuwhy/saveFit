package com.fitmix.sdk.bean;

import java.io.Serializable;

/**
 * 运动记录信息
 */
public class RunLogInfo implements Serializable, Comparable<RunLogInfo> {

    /**
     * 运动环境,室外
     */
    public static final int SPORT_MODE_OUTDOOR = 1;
    /**
     * 运动环境,室内
     */
    public static final int SPORT_MODE_INDOOR = 2;
//	/** 定位类型,GPS*/
//	public static final int LOCATION_GPS = 1;
//	/** 定位类型,LBS*/
//	public static final int LOCATION_LBS = 2;
//	/** 运动记录与服务器状态,未同步*/
//	public static final int RECORD_SYNC = 1;
//	/** 运动记录与服务器状态,已同步*/
//	public static final int RECORD_NOT_SYNC = 0;

    private String trail;//轨迹文件路径
    private String stepData;//计步文件路径
    private int uid;//用户ID
    private int type;//运动类型(0跑步,骑行),跑步运动为1, 跳绳：2 手表：3
    private int mode;//运动环境(1:室外,2:室内)
    private int bpm;//平均步频(每分钟步数)
    private int bpmMatch;//平均步频与音乐BPM匹配度 (平均步频/音乐BPM)*100%
    private int uploaded;//是否已同步到服务器,1:已同步,0:未同步
    private int score;//运动成绩
    private int locationType;//定位类型,1:GPS定位,2:LBS定位
    private long distance;//运动距离,单位米
    private long runTime;//运动时长,单位毫秒
    private long realRunTime;//真正有效的运动时长，单位毫秒
    private long startTime;//开始时间,单位毫秒
    private long endTime;//结束时间,单位毫秒
    private double startLng;//开始点经度
    private double endLng;//结束点经度
    private double startLat;//开始点纬度
    private double endLat;//结束点纬度
    private int step;//步数
    private long calorie;//卡路里
    private double mostHigh;//最高海拔
    private double troughAltitude;//波谷海拔

    private String heartRateData;//心率数据相关，由UserHeartRate类转为的json字符串
    private double consumeFat;//燃烧脂肪量
    private double elevation;//累积爬升

    private int dataSource;//数据来源,0:乐享动app 1:手表
    private int watchSportType;//手表运动数据类型,与WatchDataProtocol SPORTS_TYPE_RUN_OUTDOOR等等对应

    private int swimPoolLength;//泳池长度,单位为米
    private int swimStyle;//泳姿
    private int swimTrips;//往返次数
    @Override
    public String toString() {
        return String.format("uid:%s,mode:%s,bpm:%s,uploaded:%s,locationType:%s,distance:%s,runTime:%s,\n" +
                        "startTime:%s,endTime:%s,startLat:%s,startLng:%s,endLat:%s,endLng:%s,\nheartRateData:%s,consumeFat:%s,elevation:%s",
                uid, mode, bpm, uploaded, locationType, distance, runTime,
                startTime, endTime, startLat, startLng, endLat, endLng, heartRateData, consumeFat, elevation);
    }

    public RunLogInfo() {
        clear();
    }

    public void clear() {
        uid = -1;
        type = 0;
        mode = 0;
        bpm = 0;
        bpmMatch = 0;
        uploaded = 0;
        score = 0;
        locationType = 0;
        runTime = 0;
        realRunTime = 0;
        startTime = 0;
        endTime = 0;
        distance = 0;
        startLat = 0;
        endLat = 0;
        startLng = 0;
        endLng = 0;
        step = 0;
        calorie = 0;
        trail = null;
        stepData = null;

        heartRateData = "";
        consumeFat = 0;
    }

    public double getTroughAltitude() {
        return troughAltitude;
    }

    public void setTroughAltitude(double troughAltitude) {
        this.troughAltitude = troughAltitude;
    }

    public int getSwimPoolLength() {
        return swimPoolLength;
    }

    public void setSwimPoolLength(int swimPoolLength) {
        this.swimPoolLength = swimPoolLength;
    }

    public int getSwimStyle() {
        return swimStyle;
    }

    public void setSwimStyle(int swimStyle) {
        this.swimStyle = swimStyle;
    }

    public int getSwimTrips() {
        return swimTrips;
    }

    public void setSwimTrips(int swimTrips) {
        this.swimTrips = swimTrips;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public double getMostHigh() {
        return mostHigh;
    }

    public void setMostHigh(double mostHigh) {
        this.mostHigh = mostHigh;
    }

    /**
     * 获取运动类型(跑步,骑行),目前没有用到,默认0
     */
    public int getType() {
        return type;
    }

    /**
     * 设置运动类型(跑步,骑行)
     *
     * @param type 运动类型,目前没有用到,默认0即可
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * 获取运动环境
     *
     * @return 1:室外,2:室内
     */
    public int getMode() {
        return mode;
    }

    /**
     * 设置运动环境
     *
     * @param mode 1:室外,2:室内
     */
    public void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * 获取运动步数
     *
     * @return 运动步数
     */
    public int getStep() {
        return step;
    }

    /**
     * 设置运动步数
     *
     * @return 运动步数
     */
    public void setStep(int step) {
        this.step = step;
    }

    /**
     * 获取运动消耗卡路里,单位卡路里
     */
    public long getCalorie() {
        return calorie;
    }

    /**
     * 设置运动消耗卡路里
     *
     * @param calorie 运动消耗卡路里,单位卡路里
     */
    public void setCalorie(long calorie) {
        this.calorie = calorie;
    }

    /**
     * 获取运动平均步频
     */
    public int getBpm() {
        return bpm;
    }

    /**
     * 设置运动平均步频
     */
    public void setBpm(int bpm) {
        this.bpm = bpm;
    }

    /**
     * 获取步频与音乐匹配度,V2.0改版后废弃,V2.3.0之后,如果值为-2表示跑步过程中传感器有异常,界面上要加个异常提示
     */
    public int getBpmMatch() {
        return bpmMatch;
    }

    /**
     * 设置步频与音乐匹配度,V2.0改版后废弃,V2.3.0之后,设置值为-2表示跑步过程中传感器有异常,界面上要加个异常提示
     */
    public void setBpmMatch(int bpmMatch) {
        this.bpmMatch = bpmMatch;
    }

    /**
     * 记录是否已同步到服务器,1:已同步,0:未同步
     */
    public int getUploaded() {
        return uploaded;
    }

    /**
     * 设置记录与服务器同步状态
     *
     * @param uploaded 1:已同步,0:未同步,2:记录未完成
     */
    public void setUploaded(int uploaded) {
        this.uploaded = uploaded;
    }

    /**
     * 获取定位类型
     *
     * @return 1:GPS定位,2:LBS定位
     */
    public int getLocationType() {
        return locationType;
    }

    /**
     * 设置定位类型
     *
     * @param locationType 定位类型,1:GPS定位,2:LBS定位
     */
    public void setLocationType(int locationType) {
        this.locationType = locationType;
    }

    /**
     * 获取运动时长
     *
     * @return 真正运动时长, 单位毫秒
     */
    public long getRealRunTime() {
        return realRunTime;
    }

    /**
     * 设置运动时长
     *
     * @param realRunTime 真正运动时长,单位毫秒
     */
    public void setRealRunTime(long realRunTime) {
        this.realRunTime = realRunTime;
    }

    /**
     * 获取运动时长
     *
     * @return 运动时长, 单位毫秒
     */
    public long getRunTime() {
        return runTime;
    }

    /**
     * 设置运动时长
     *
     * @param runTime 运动时长,单位毫秒
     */
    public void setRunTime(long runTime) {
        this.runTime = runTime;
    }

    /**
     * 获取运动开始时间
     *
     * @return 运动开始时间, 单位毫秒
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * 设置运动开始时间
     *
     * @param startTime 运动开始时间,单位毫秒
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取运动结束时间
     *
     * @return 运动结束时间, 单位毫秒
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * 设置运动结束时间
     *
     * @param endTime 运动结束时间,单位毫秒
     */
    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取运动距离
     *
     * @return 运动距离, 单位米
     */
    public long getDistance() {
        return distance;
    }

    /**
     * 设置运动距离
     *
     * @param distance 运动距离,单位米
     */
    public void setDistance(long distance) {
        this.distance = distance;
    }

    /**
     * 获取跑步运动轨迹文件下载url
     *
     * @return 跑步运动轨迹文件下载url
     */
    public String getTrail() {
        return trail;
    }

    /**
     * 设置跑步运动轨迹文件下载url
     *
     * @param trail 跑步运动轨迹文件下载url
     */
    public void setTrail(String trail) {
        this.trail = trail;
    }

    /**
     * 获取跑步运动计步文件下载url
     *
     * @return 跑步运动计步文件下载url
     */
    public String getStepData() {
        return stepData;
    }

    /**
     * 设置跑步运动计步文件下载url
     *
     * @param stepData 跑步运动计步文件下载url
     */
    public void setStepData(String stepData) {
        this.stepData = stepData;
    }

    /**
     * 获取开始点经度
     */
    public double getStartLng() {
        return startLng;
    }

    /**
     * 设置开始点经度
     */
    public void setStartLng(double startLng) {
        this.startLng = startLng;
    }

    /**
     * 获取结束点经度
     */
    public double getEndLng() {
        return endLng;
    }

    /**
     * 设置结束点经度
     */
    public void setEndLng(double startLng) {
        this.endLng = startLng;
    }

    /**
     * 获取开始点纬度
     */
    public double getStartLat() {
        return startLat;
    }

    /**
     * 设置开始点纬度
     */
    public void setStartLat(double startLat) {
        this.startLat = startLat;
    }

    /**
     * 获取结束点纬度
     */
    public double getEndLat() {
        return endLat;
    }

    /**
     * 设置结束点纬度
     */
    public void setEndLat(double endLat) {
        this.endLat = endLat;
    }

    /**
     * 获取心率数据(UserHeartRate)实体json字符串
     */
    public String getHeartRateDate() {
        return heartRateData;
    }

    /**
     * 设置心率数据(UserHeartRate)实体json字符串
     */
    public void setHeartRateDate(String heartRateData) {
        this.heartRateData = heartRateData;
    }

    /**
     * 获取燃脂量,单位为克
     */
    public double getConsumeFat() {
        return consumeFat;
    }

    /**
     * 设置燃脂量,单位为克
     */
    public void setConsumeFat(double consumeFat) {
        this.consumeFat = consumeFat;
    }

    /**
     * 室外模式下,累积爬升,单位为米
     */
    public double getElevation() {
        return elevation;
    }

    /**
     * 室外模式下,累积爬升,单位为米
     */
    public void setElevation(double elevation) {
        this.elevation = elevation;
    }

    /**
     * 运动记录来源,0:乐享动app,1:手表
     */
    public int getDataSource() {
        return dataSource;
    }

    /**
     * 设置运动记录来源,0:乐享动app,1:手表
     */
    public void setDataSource(int dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * 获取手表运动记录运动类型,具体含义参考{@link com.fitmix.sdk.watch.WatchDataProtocol#SPORTS_TYPE_RUN_OUTDOOR} 等
     */
    public int getWatchSportType() {
        return watchSportType;
    }

    /**
     * 设置手表运动记录运动类型
     *
     * @param watchSportType 手表运动记录运动类型,具体含义参考{@link com.fitmix.sdk.watch.WatchDataProtocol#SPORTS_TYPE_RUN_OUTDOOR} 等
     */
    public void setWatchSportType(int watchSportType) {
        this.watchSportType = watchSportType;
    }

    @Override
    public int compareTo(RunLogInfo another) {
        if (another == null) {
            return -1;
        }

        long diff = this.startTime - another.getStartTime();
        if (diff < 0) {//时间越大的,排序越前
            return 1;
        } else {
            return -1;
        }
    }
}
