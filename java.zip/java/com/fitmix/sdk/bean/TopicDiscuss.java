package com.fitmix.sdk.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 话题或话题答案的评论
 */

public class TopicDiscuss {
    private long addTime;//评论时间
    private String avatar;//评论者头像
    private String content;//评论内容
    private int id;//评论ID
    private int themeId;//评论相关联的主题ID(即话题ID或答案ID)
    private int uid;//评论者uid
    private int upNum;//评论点赞数
    private String userName;//评论者用户名
    private List<Integer> upUserIds;//评论点赞用户ID列表
    private String discussUName;//回复的目标用户的名称(我讨论的谁的回复、讨论)
    private int discussUid;//回复的用户Uid(说明:讨论才有回复的编号)
    private int themeVip;

    public int getThemeVip() {
        return themeVip;
    }

    public void setThemeVip(int themeVip) {
        this.themeVip = themeVip;
    }

    public long getAddTime() {
        return addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getThemeId() {
        return themeId;
    }

    public void setThemeId(int themeId) {
        this.themeId = themeId;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getUpNum() {
        return upNum;
    }

    public void setUpNum(int upNum) {
        this.upNum = upNum;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Integer> getUpUserIds() {
        if (upUserIds == null) {
            upUserIds = new ArrayList<>();
        }
        return upUserIds;
    }

    public void setUpUserIds(List<Integer> upUserIds) {
        this.upUserIds = upUserIds;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getDiscussUName() {
        return discussUName;
    }

    public void setDiscussUName(String discussUName) {
        this.discussUName = discussUName;
    }

    public int getDiscussUid() {
        return discussUid;
    }

    public void setDiscussUid(int discussUid) {
        this.discussUid = discussUid;
    }
}
