package com.fitmix.sdk.bean;

/**
 * 话题
 */
public class Topic {
    private long addTime;//添加时间
    private String avatar;//头像图片地址
    private int categoryId;//板块编号
    private int discussNum;//回答数
    private int id;//话题编号
    private int isConfirmed;//审核状态,0:未审核,1:审核通过,2:审核未通过
    private int isReply;//是否关闭回复,0:关闭回复,1:开启回复
    private String name;//用户名称
    private String title;//标题
    private String content;//内容
    private int uid;//用户id
    private int upNum;//点赞数量
    private int themeType;//主题帖类型,1:问题,2:回答
    private int clickNum;//点击数量
    private String signature;//签名
    private TopicAnswer selectNodeTheme;//最好的答案,用于首页展示
    private int answerId;//如果当前用户回答了该话题,则该字段不为空,表示回答编号
    private String backImage;//精选话题的banner
    private int bannerSort;//精选话题的顺序
    private int fine;//突出、精华贴
    private int themeVip;

    public int getThemeVip() {
        return themeVip;
    }

    public void setThemeVip(int themeVip) {
        this.themeVip = themeVip;
    }

    public long getAddTime() {
        return addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getDiscussNum() {
        return discussNum;
    }

    public void setDiscussNum(int discussNum) {
        this.discussNum = discussNum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsConfirmed() {
        return isConfirmed;
    }

    public void setIsConfirmed(int isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    public int getIsReply() {
        return isReply;
    }

    public void setIsReply(int isReply) {
        this.isReply = isReply;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getUpNum() {
        return upNum;
    }

    public void setUpNum(int upNum) {
        this.upNum = upNum;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getThemeType() {
        return themeType;
    }

    public void setThemeType(int themeType) {
        this.themeType = themeType;
    }

    public int getClickNum() {
        return clickNum;
    }

    public void setClickNum(int clickNum) {
        this.clickNum = clickNum;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public TopicAnswer getSelectNodeTheme() {
        return selectNodeTheme;
    }

    public void setSelectNodeTheme(TopicAnswer selectNodeTheme) {
        this.selectNodeTheme = selectNodeTheme;
    }

    public int getAnswerId() {
        return answerId;
    }

    public void setAnswerId(int answerId) {
        this.answerId = answerId;
    }

    public String getBackImage() {
        return backImage;
    }

    public void setBackImage(String backImage) {
        this.backImage = backImage;
    }

    public int getBannerSort() {
        return bannerSort;
    }

    public void setBannerSort(int bannerSort) {
        this.bannerSort = bannerSort;
    }

    public int getFine() {
        return fine;
    }

    public void setFine(int fine) {
        this.fine = fine;
    }
}
