package com.fitmix.sdk.bean;

/**
 * 测量的心率记录
 */
public class HeartRateInfo {
    private int uid;//用户ID
    private int record;//测量的心率
    private long startTime;//开始时间,单位毫秒,即为时间戳*1000
    private long detectTime;//该数据检测的时间,单位毫秒,即为时间戳*1000
    private int type;
    private int uploaded;//0代表未同步，1代表已同步

    public HeartRateInfo(int uid, int record, long startTime, int type, long detectTime, int uploaded) {
        this.uid = uid;
        this.record = record;
        this.startTime = startTime;
        this.type = type;
        this.detectTime = detectTime;
        this.uploaded = uploaded;
    }

    public HeartRateInfo() {
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getRecord() {
        return record;
    }

    public void setRecord(int record) {
        this.record = record;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getDetectTime() {
        return detectTime;
    }

    public void setDetectTime(long detectTime) {
        this.detectTime = detectTime;
    }

    public int getUploaded() {
        return uploaded;
    }

    public void setUploaded(int uploaded) {
        this.uploaded = uploaded;
    }

}
