package com.fitmix.sdk.bean;

/**
 * 心率数据点
 */
public class HeartRate {
    private long time;
    private long heart_rate_record;

    public HeartRate() {
    }

    public HeartRate(long time, long heart_rate_record) {
        this.time = time;
        this.heart_rate_record = heart_rate_record;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public long getHeart_rate_record() {
        return heart_rate_record;
    }

    public void setHeart_rate_record(long heart_rate_record) {
        this.heart_rate_record = heart_rate_record;
    }
}
