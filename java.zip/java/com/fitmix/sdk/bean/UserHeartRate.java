package com.fitmix.sdk.bean;

/**
 * 用户心率数据
 */
public class UserHeartRate {

    /**
     * 最大心率上限（默认是220-年龄）
     */
    private double hrMax;

    /**
     * 运动的时候，作为参考的年龄 (default = 24)
     */
    private int currentAge;
    /**
     * 运动的时候，作为参考的静息心率(default = 80)
     */
    private int currentRestHeartRate;

    /**
     * 平均心率
     */
    private double heartRateAvg;//服务器返回double类型
    /**
     * 最大心率
     */
    private double maxHeartRate;//服务器返回double类型
    /**
     * 最小心率
     */
    private double minHeartRate;//服务器返回double类型
    /**
     * 本次运动 燃脂运动 花费的时长
     */
    private long consumptionSpendTime;
//    /**
//     * 心率文件
//     */
//    private String heartRateFileLink;

    /**
     * 最大摄氧量
     */
    private double voMax;

    ///=====================================心率区间数=========================================
    /**
     * 有氧区间(数)
     */
    private int aerobicNum;
    /**
     * 无氧区间(数)
     */
    private int anaerobicNum;
    /**
     * 热身区间(数)
     */
    private int warmNum;
    /**
     * 燃脂区间(数)
     */
    private int fatBurningNum;
    /**
     * 最大区间(数)
     */
    private int maxNum;
    /**
     * 最后一次更新的时间
     */
    private long lastUpdated;

    /**
     * 获取平均心率
     */
    public double getHeartRateAvg() {
        return heartRateAvg;
    }

    /**
     * 设置平均心率
     */
    public void setHeartRateAvg(double heartRateAvg) {
        this.heartRateAvg = heartRateAvg;
    }

    /**
     * 获取最大心率
     */
    public double getMaxHeartRate() {
        return maxHeartRate;
    }

    /**
     * 设置最大心率
     */
    public void setMaxHeartRate(double maxHeartRate) {
        this.maxHeartRate = maxHeartRate;
    }

    /**
     * 获取最小心率
     */
    public double getMinHeartRate() {
        return minHeartRate;
    }

    /**
     * 设置最小心率
     */
    public void setMinHeartRate(double minHeartRate) {
        this.minHeartRate = minHeartRate;
    }

    /**
     * 获取本次运动燃脂时长,单位为毫秒
     */
    public long getConsumptionSpendTime() {
        return consumptionSpendTime;
    }

    /**
     * 设置本次运动燃脂时长,单位为毫秒
     */
    public void setConsumptionSpendTime(long consumptionSpendTime) {
        this.consumptionSpendTime = consumptionSpendTime;
    }

//    public String getHeartRateFileLink() {
//        return heartRateFileLink;
//    }
//
//    public void setHeartRateFileLink(String heartRateFileLink) {
//        this.heartRateFileLink = heartRateFileLink;
//    }

    /**
     * 获取有氧区间数,秒数
     */
    public int getAerobicNum() {
        return aerobicNum;
    }

    /**
     * 设置有氧区间数,秒数
     */
    public void setAerobicNum(int aerobicNum) {
        this.aerobicNum = aerobicNum;
    }

    /**
     * 获取无氧区间数,秒数
     */
    public int getAnaerobicNum() {
        return anaerobicNum;
    }

    /**
     * 设置无氧区间数,秒数
     */
    public void setAnaerobicNum(int anaerobicNum) {
        this.anaerobicNum = anaerobicNum;
    }

    /**
     * 获取热身区间数,秒数
     */
    public int getWarmNum() {
        return warmNum;
    }

    /**
     * 设置热身区间数,秒数
     */
    public void setWarmNum(int warmNum) {
        this.warmNum = warmNum;
    }

    /**
     * 获取燃脂区间数,秒数
     */
    public int getFatBurningNum() {
        return fatBurningNum;
    }

    /**
     * 设置燃脂区间数,秒数
     */
    public void setFatBurningNum(int fatBurningNum) {
        this.fatBurningNum = fatBurningNum;
    }

    /**
     * 获取最大区间数,秒数
     */
    public int getMaxNum() {
        return maxNum;
    }

    /**
     * 设置最大区间数,秒数
     */
    public void setMaxNum(int maxNum) {
        this.maxNum = maxNum;
    }

    /**
     * 最后一次更新的时间
     */
    public long getLastUpdated() {
        return lastUpdated;
    }

    /**
     * 设置最后一次更新的时间戳
     */
    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**
     * 获取当前年龄
     */
    public int getCurrentAge() {
        return currentAge;
    }

    /**
     * 设置当前年龄
     */
    public void setCurrentAge(int currentAge) {
        this.currentAge = currentAge;
    }

    /**
     * 获取当前静息心率
     */
    public int getCurrentRestHeartRate() {
        return currentRestHeartRate;
    }

    /**
     * 设置当前静息心率
     */
    public void setCurrentRestHeartRate(int currentRestHeartRate) {
        this.currentRestHeartRate = currentRestHeartRate;
    }

    /**
     * 获取最大摄氧量,单位ml/kg/min
     */
    public double getVoMax() {
        return voMax;
    }

    /**
     * 设置最大摄氧量,单位ml/kg/min
     */
    public void setVoMax(double voMax) {
        this.voMax = voMax;
    }

    /**
     * 获取最大心率上限
     */
    public double getHrMax() {
        return hrMax;
    }

    /**
     * 设置最大心率上限
     */
    public void setHrMax(double hrMax) {
        this.hrMax = hrMax;
    }
}
