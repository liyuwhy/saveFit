package com.fitmix.sdk.bean;

/**
 * 金币记录项目
 */

public class CoinRecord {

    /**
     * 记录产生时间
     */
    public long time;
    /**
     * 记录内容
     */
    public String description;
    /**
     * 数量
     */
    public int quantity;
    /**
     * 类型,0:表示收入,1:表示消费
     */
    public int type;
    /**
     * 数据显示类型,用于布局显示,0:显示明细,1:显示月份
     */
    public int dataType;

    /**
     * 创建金币记录项目实体
     *
     * @param time        记录产生时间,单位为毫秒
     * @param description 记录内容
     * @param quantity    数量
     * @param type        类型,0:表示收入,1:表示消费
     */
    public CoinRecord(long time, String description, int quantity, int type) {
        this.time = time;
        this.description = description;
        this.quantity = quantity;
        this.type = type;
    }

    /**
     * 创建金币记录项目实体
     *
     * @param time        记录产生时间,单位为毫秒
     * @param description 记录内容
     * @param quantity    数量
     * @param type        类型,0:表示收入,1:表示消费
     * @param dataType    数据显示类型,用于布局显示,0:显示明细,1:显示月份
     */
    public CoinRecord(long time, String description, int quantity, int type, int dataType) {
        this.time = time;
        this.description = description;
        this.quantity = quantity;
        this.type = type;
        this.dataType = dataType;
    }

}
