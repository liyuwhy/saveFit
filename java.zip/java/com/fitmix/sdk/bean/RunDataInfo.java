package com.fitmix.sdk.bean;

/**
 * 图表数据点
 */
public class RunDataInfo {
    private long time;//距离运动开始时间的毫秒数
    private double data;//值

    public RunDataInfo() {
        clear();
    }

    public void clear() {
        time = 0;
        data = 0;
    }

    public double getData() {
        return data;
    }

    public void setData(double data) {
        this.data = data;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }


    @Override
    public String toString() {
        return "RunDataInfo{" +
                "time=" + time +
                ", data=" + data +
                '}';
    }
}
