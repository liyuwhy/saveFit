package com.fitmix.sdk.bean;

/**
 * 用户等级实体,用于LevelAdapter
 */

public class LevelEntity {

    /**
     * 分组标题
     */
    public String title;
    /**
     * 图片资源ID,只显示分组标题时,值为0
     */
    public int imgResId;
    /**
     * 内容
     */
    public String explain;

    /**
     * 创建用户等级实体
     *
     * @param title    分组标题
     * @param imgResId 图片资源ID,只显示分组标题时,值为0
     * @param explain  内容
     */
    public LevelEntity(String title, int imgResId, String explain) {
        this.title = title;
        this.imgResId = imgResId;
        this.explain = explain;
    }

}
