package com.fitmix.sdk.bean;

import com.fitmix.sdk.model.api.ApiUtils;

import java.util.List;

public class Club {

    /**
     * backImageUrl : http://yyssb.ifitmix.com/2001/1a1efac3277a4fca93f51573b956388c.jpg
     * desc : 蓝筹全员俱乐部
     * haveMember : 0
     * id : 527
     * memberCount : 22
     * memberUidSet : [34051,90987,33,14576,525,232274,208601,10,5,97010,8,189002,165717,55700,110563,1235,192057,18535,378,15,23,183135]
     * name : 乐享动俱乐部
     * type : 2
     * uid : 34051
     */

    private String backImageUrl;//俱乐部背景图片
    private String desc;//俱乐部描述
    private int haveMember;//???
    private int id;//俱乐部ID
    private int memberCount;//俱乐部成员数量
    private String name;//俱乐部名称
    private int type;//俱乐部是否为开发俱乐部的标识  开放俱乐部 2 其他 1
    private int uid;//俱乐部创建者ID
    private List<Integer> memberUidSet;//俱乐部含有成员的集合

    public String getBackImageUrl() {
        return backImageUrl;
    }

    public void setBackImageUrl(String backImageUrl) {
        this.backImageUrl = backImageUrl;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getHaveMember() {
        return haveMember;
    }

    public void setHaveMember(int haveMember) {
        this.haveMember = haveMember;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public String getName() {
        if(!ApiUtils.isZhLanguage() && name!= null && name.equals("乐享动俱乐部")){
            return "Fitmix Club";
        }
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public List<Integer> getMemberUidSet() {
        return memberUidSet;
    }

    public void setMemberUidSet(List<Integer> memberUidSet) {
        this.memberUidSet = memberUidSet;
    }
}

