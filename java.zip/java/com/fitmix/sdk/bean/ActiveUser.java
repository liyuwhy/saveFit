package com.fitmix.sdk.bean;

import java.io.Serializable;

public class ActiveUser implements Serializable {
    /**
     * avatar : http://yyssb.ifitmix.com/1002/08621b854e204ee1897f7859c784af60.jpg
     * id : 5
     * name : fanny
     */
    private String avatar;//俱乐部成员头像
    private int id;//俱乐部成员ID
    private String name;//俱乐部成员名称

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
