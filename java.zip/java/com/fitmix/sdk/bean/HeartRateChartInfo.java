package com.fitmix.sdk.bean;

/**
 * 心率图表数据点
 */
public class HeartRateChartInfo {
    private long time;
    private int heartRate;

    public HeartRateChartInfo() {
    }

    public HeartRateChartInfo(int heartRate, long time) {
        this.time = time;
        this.heartRate = heartRate;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heart_rate) {
        this.heartRate = heart_rate;
    }
}
