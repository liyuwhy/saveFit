package com.fitmix.sdk.bean;

import java.util.List;

/**
 * 获取排行榜数据接口(run/month/rank.json)返回的结果
 */

public class RankListLevelData {


    /**
     * st : 1513736647575
     * code : 0
     * k : 9a36dc92bb7a4aa59267620196e64561
     * page : {"filter":{"level":1,"statTime":"2017-12-01"},"hasNext":true,"hasPre":false,"index":0,"nextPage":2,"offset":0,"pageNo":1,"prePage":1,"result":[{"addTime":1513085828611,"id":22454498,"level":1,"modifyTime":1513713932000,"modifyTimeValid":1513713932000,"pace":3243201,"rank":1,"runDay":20,"runDayValid":20,"runNum":96,"runNumValid":70,"runTime":945193809,"runTimeValid":758815250,"statTime":"2017-12-01","sumCalorie":94339,"sumCalorieValid":85124,"sumDistance":2023532,"sumDistanceValid":1780037,"sumStep":2254223,"sumStepValid":1953125,"type":3,"uid":3930978,"user":{"avatar":"http://yyssb.ifitmix.com/1002/da63ab25cd94434cbe42feb077bea0ca.jpg","gender":1,"id":3930978,"name":"杨子"}},{"addTime":1513085825566,"id":22454285,"level":1,"modifyTime":1513251931000,"modifyTimeValid":1513251931000,"pace":99274121,"rank":2,"runDay":14,"runDayValid":14,"runNum":46,"runNumValid":44,"runTime":240153187,"runTimeValid":238254324,"statTime":"2017-12-01","sumCalorie":36559,"sumCalorieValid":36481,"sumDistance":610082,"sumDistanceValid":608123,"sumStep":639282,"sumStepValid":637167,"type":3,"uid":1193438,"user":{"avatar":"http://wx.qlogo.cn/mmopen/DpDWxM6CCagzAms6GwDZibKrk7W4ia0uTCxzC9eFWr74fmDdhia7VJOEgwaA5GV9rhG6VL56P0r5L8n5zBagYtwmIF7qmhwQmMh/0","gender":1,"id":1193438,"name":"有缘人"}},{"addTime":1513085822430,"id":22454037,"level":1,"modifyTime":1513728167000,"modifyTimeValid":1513691234000,"pace":260075959,"rank":3,"runDay":20,"runDayValid":19,"runNum":140,"runNumValid":85,"runTime":411491848,"runTimeValid":156045599,"statTime":"2017-12-01","sumCalorie":36287,"sumCalorieValid":30706,"sumDistance":643244,"sumDistanceValid":527465,"sumStep":703791,"sumStepValid":548713,"type":3,"uid":936826,"user":{"avatar":"","gender":1,"id":936826,"name":"13707410367"}},{"addTime":1513085823164,"id":22454096,"level":1,"modifyTime":1513243607000,"modifyTimeValid":1513222840000,"pace":10087114,"rank":4,"runDay":14,"runDayValid":14,"runNum":39,"runNumValid":37,"runTime":134176555,"runTimeValid":127054555,"statTime":"2017-12-01","sumCalorie":23038,"sumCalorieValid":22075,"sumDistance":537816,"sumDistanceValid":521296,"sumStep":389755,"sumStepValid":376321,"type":3,"uid":3929116,"user":{"avatar":"http://yyssb.ifitmix.com/1002/eaced2f834964fed97d03bb1311a685f.jpg","gender":2,"id":3929116,"name":"黑山老腰"}},{"addTime":1513085835293,"id":22454881,"level":1,"modifyTime":1513655236000,"modifyTimeValid":1513655236000,"pace":17834234,"rank":5,"runDay":16,"runDayValid":15,"runNum":31,"runNumValid":29,"runTime":151398508,"runTimeValid":139100006,"statTime":"2017-12-01","sumCalorie":29132,"sumCalorieValid":27443,"sumDistance":467592,"sumDistanceValid":443926,"sumStep":442491,"sumStepValid":419766,"type":3,"uid":3931714,"user":{"avatar":"http://yyssb.ifitmix.com/1002/c3296eba79734402949c13e062a0897b.jpg","gender":1,"id":3931714,"name":"吴煥臣"}},{"addTime":1513085817453,"id":22453655,"level":1,"modifyTime":1513723888000,"modifyTimeValid":1513723888000,"pace":3624034,"rank":6,"runDay":20,"runDayValid":20,"runNum":24,"runNumValid":21,"runTime":62789153,"runTimeValid":47837566,"statTime":"2017-12-01","sumCalorie":11267,"sumCalorieValid":10921,"sumDistance":450409,"sumDistanceValid":432968,"sumStep":206483,"sumStepValid":196337,"type":3,"uid":3905796,"user":{"avatar":"http://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eq08HWMmQZVvb4x86SGzdP25yY4A0HTxBydN1kVaE2Xibq6EJqkfYUJV5zI6I3iaNWPjFlHDV9UZ3icA/0","gender":2,"id":3905796,"name":"宏伟的理想"}},{"addTime":1513085820793,"id":22453910,"level":1,"modifyTime":1513253124000,"modifyTimeValid":1513253124000,"pace":14321659,"rank":7,"runDay":14,"runDayValid":14,"runNum":34,"runNumValid":30,"runTime":157384837,"runTimeValid":146052525,"statTime":"2017-12-01","sumCalorie":23969,"sumCalorieValid":23501,"sumDistance":428857,"sumDistanceValid":407359,"sumStep":484106,"sumStepValid":466333,"type":3,"uid":3909313,"user":{"avatar":"http://yyssb.ifitmix.com/1002/dae19595e6a2476ca84a971cd1c5c199.jpg","gender":2,"id":3909313,"name":"观海听涛"}},{"addTime":1513085817941,"id":22453684,"level":1,"modifyTime":1513719017000,"modifyTimeValid":1513719017000,"pace":40538758,"rank":8,"runDay":20,"runDayValid":23,"runNum":152,"runNumValid":53,"runTime":630184742,"runTimeValid":145925272,"statTime":"2017-12-01","sumCalorie":51042,"sumCalorieValid":27439,"sumDistance":907272,"sumDistanceValid":404895,"sumStep":989237,"sumStepValid":412978,"type":3,"uid":1113340,"user":{"avatar":"","gender":1,"id":1113340,"name":"13082410387"}},{"addTime":1513085836527,"id":22454932,"level":1,"modifyTime":1513660136000,"modifyTimeValid":1513436801000,"pace":81694544,"rank":9,"runDay":19,"runDayValid":15,"runNum":39,"runNumValid":29,"runTime":179404892,"runTimeValid":147046634,"statTime":"2017-12-01","sumCalorie":24639,"sumCalorieValid":23367,"sumDistance":443616,"sumDistanceValid":400518,"sumStep":444131,"sumStepValid":405790,"type":3,"uid":179864,"user":{"avatar":"http://q.qlogo.cn/qqapp/1104452331/FF89D582D0CFB343388901C7531CA1F2/100","gender":1,"id":179864,"name":"麦子"}},{"addTime":1513085853357,"id":22455849,"level":1,"modifyTime":1513247615000,"modifyTimeValid":1513247615000,"pace":6959218,"rank":10,"runDay":14,"runDayValid":14,"runNum":29,"runNumValid":25,"runTime":117893536,"runTimeValid":116871877,"statTime":"2017-12-01","sumCalorie":30050,"sumCalorieValid":29936,"sumDistance":397702,"sumDistanceValid":395057,"sumStep":437596,"sumStepValid":435368,"type":3,"uid":3920068,"user":{"avatar":"http://wx.qlogo.cn/mmhead/Q3auHgzwzM6iajZKbOjsf0sHTSfPpPBBg1JYlRH1x4ibVutY48TcxNibg/0","gender":1,"id":3920068,"name":"啊生呀"}}],"size":10,"total":3272,"totalPages":328}
     */

    private long st;
    private int code;
    private String k;
    private PageBean page;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public PageBean getPage() {
        return page;
    }

    public void setPage(PageBean page) {
        this.page = page;
    }

    public static class PageBean {
        /**
         * filter : {"level":1,"statTime":"2017-12-01"}
         * hasNext : true
         * hasPre : false
         * index : 0
         * nextPage : 2
         * offset : 0
         * pageNo : 1
         * prePage : 1
         * result : [{"addTime":1513085828611,"id":22454498,"level":1,"modifyTime":1513713932000,"modifyTimeValid":1513713932000,"pace":3243201,"rank":1,"runDay":20,"runDayValid":20,"runNum":96,"runNumValid":70,"runTime":945193809,"runTimeValid":758815250,"statTime":"2017-12-01","sumCalorie":94339,"sumCalorieValid":85124,"sumDistance":2023532,"sumDistanceValid":1780037,"sumStep":2254223,"sumStepValid":1953125,"type":3,"uid":3930978,"user":{"avatar":"http://yyssb.ifitmix.com/1002/da63ab25cd94434cbe42feb077bea0ca.jpg","gender":1,"id":3930978,"name":"杨子"}},{"addTime":1513085825566,"id":22454285,"level":1,"modifyTime":1513251931000,"modifyTimeValid":1513251931000,"pace":99274121,"rank":2,"runDay":14,"runDayValid":14,"runNum":46,"runNumValid":44,"runTime":240153187,"runTimeValid":238254324,"statTime":"2017-12-01","sumCalorie":36559,"sumCalorieValid":36481,"sumDistance":610082,"sumDistanceValid":608123,"sumStep":639282,"sumStepValid":637167,"type":3,"uid":1193438,"user":{"avatar":"http://wx.qlogo.cn/mmopen/DpDWxM6CCagzAms6GwDZibKrk7W4ia0uTCxzC9eFWr74fmDdhia7VJOEgwaA5GV9rhG6VL56P0r5L8n5zBagYtwmIF7qmhwQmMh/0","gender":1,"id":1193438,"name":"有缘人"}},{"addTime":1513085822430,"id":22454037,"level":1,"modifyTime":1513728167000,"modifyTimeValid":1513691234000,"pace":260075959,"rank":3,"runDay":20,"runDayValid":19,"runNum":140,"runNumValid":85,"runTime":411491848,"runTimeValid":156045599,"statTime":"2017-12-01","sumCalorie":36287,"sumCalorieValid":30706,"sumDistance":643244,"sumDistanceValid":527465,"sumStep":703791,"sumStepValid":548713,"type":3,"uid":936826,"user":{"avatar":"","gender":1,"id":936826,"name":"13707410367"}},{"addTime":1513085823164,"id":22454096,"level":1,"modifyTime":1513243607000,"modifyTimeValid":1513222840000,"pace":10087114,"rank":4,"runDay":14,"runDayValid":14,"runNum":39,"runNumValid":37,"runTime":134176555,"runTimeValid":127054555,"statTime":"2017-12-01","sumCalorie":23038,"sumCalorieValid":22075,"sumDistance":537816,"sumDistanceValid":521296,"sumStep":389755,"sumStepValid":376321,"type":3,"uid":3929116,"user":{"avatar":"http://yyssb.ifitmix.com/1002/eaced2f834964fed97d03bb1311a685f.jpg","gender":2,"id":3929116,"name":"黑山老腰"}},{"addTime":1513085835293,"id":22454881,"level":1,"modifyTime":1513655236000,"modifyTimeValid":1513655236000,"pace":17834234,"rank":5,"runDay":16,"runDayValid":15,"runNum":31,"runNumValid":29,"runTime":151398508,"runTimeValid":139100006,"statTime":"2017-12-01","sumCalorie":29132,"sumCalorieValid":27443,"sumDistance":467592,"sumDistanceValid":443926,"sumStep":442491,"sumStepValid":419766,"type":3,"uid":3931714,"user":{"avatar":"http://yyssb.ifitmix.com/1002/c3296eba79734402949c13e062a0897b.jpg","gender":1,"id":3931714,"name":"吴煥臣"}},{"addTime":1513085817453,"id":22453655,"level":1,"modifyTime":1513723888000,"modifyTimeValid":1513723888000,"pace":3624034,"rank":6,"runDay":20,"runDayValid":20,"runNum":24,"runNumValid":21,"runTime":62789153,"runTimeValid":47837566,"statTime":"2017-12-01","sumCalorie":11267,"sumCalorieValid":10921,"sumDistance":450409,"sumDistanceValid":432968,"sumStep":206483,"sumStepValid":196337,"type":3,"uid":3905796,"user":{"avatar":"http://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eq08HWMmQZVvb4x86SGzdP25yY4A0HTxBydN1kVaE2Xibq6EJqkfYUJV5zI6I3iaNWPjFlHDV9UZ3icA/0","gender":2,"id":3905796,"name":"宏伟的理想"}},{"addTime":1513085820793,"id":22453910,"level":1,"modifyTime":1513253124000,"modifyTimeValid":1513253124000,"pace":14321659,"rank":7,"runDay":14,"runDayValid":14,"runNum":34,"runNumValid":30,"runTime":157384837,"runTimeValid":146052525,"statTime":"2017-12-01","sumCalorie":23969,"sumCalorieValid":23501,"sumDistance":428857,"sumDistanceValid":407359,"sumStep":484106,"sumStepValid":466333,"type":3,"uid":3909313,"user":{"avatar":"http://yyssb.ifitmix.com/1002/dae19595e6a2476ca84a971cd1c5c199.jpg","gender":2,"id":3909313,"name":"观海听涛"}},{"addTime":1513085817941,"id":22453684,"level":1,"modifyTime":1513719017000,"modifyTimeValid":1513719017000,"pace":40538758,"rank":8,"runDay":20,"runDayValid":23,"runNum":152,"runNumValid":53,"runTime":630184742,"runTimeValid":145925272,"statTime":"2017-12-01","sumCalorie":51042,"sumCalorieValid":27439,"sumDistance":907272,"sumDistanceValid":404895,"sumStep":989237,"sumStepValid":412978,"type":3,"uid":1113340,"user":{"avatar":"","gender":1,"id":1113340,"name":"13082410387"}},{"addTime":1513085836527,"id":22454932,"level":1,"modifyTime":1513660136000,"modifyTimeValid":1513436801000,"pace":81694544,"rank":9,"runDay":19,"runDayValid":15,"runNum":39,"runNumValid":29,"runTime":179404892,"runTimeValid":147046634,"statTime":"2017-12-01","sumCalorie":24639,"sumCalorieValid":23367,"sumDistance":443616,"sumDistanceValid":400518,"sumStep":444131,"sumStepValid":405790,"type":3,"uid":179864,"user":{"avatar":"http://q.qlogo.cn/qqapp/1104452331/FF89D582D0CFB343388901C7531CA1F2/100","gender":1,"id":179864,"name":"麦子"}},{"addTime":1513085853357,"id":22455849,"level":1,"modifyTime":1513247615000,"modifyTimeValid":1513247615000,"pace":6959218,"rank":10,"runDay":14,"runDayValid":14,"runNum":29,"runNumValid":25,"runTime":117893536,"runTimeValid":116871877,"statTime":"2017-12-01","sumCalorie":30050,"sumCalorieValid":29936,"sumDistance":397702,"sumDistanceValid":395057,"sumStep":437596,"sumStepValid":435368,"type":3,"uid":3920068,"user":{"avatar":"http://wx.qlogo.cn/mmhead/Q3auHgzwzM6iajZKbOjsf0sHTSfPpPBBg1JYlRH1x4ibVutY48TcxNibg/0","gender":1,"id":3920068,"name":"啊生呀"}}]
         * size : 10
         * total : 3272
         * totalPages : 328
         */

        private FilterBean filter;
        private boolean hasNext;
        private boolean hasPre;
        private int index;
        private int nextPage;
        private int offset;
        private int pageNo;
        private int prePage;
        private int size;
        private int total;
        private int totalPages;
        private List<ResultBean> result;

        public FilterBean getFilter() {
            return filter;
        }

        public void setFilter(FilterBean filter) {
            this.filter = filter;
        }

        public boolean isHasNext() {
            return hasNext;
        }

        public void setHasNext(boolean hasNext) {
            this.hasNext = hasNext;
        }

        public boolean isHasPre() {
            return hasPre;
        }

        public void setHasPre(boolean hasPre) {
            this.hasPre = hasPre;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public int getNextPage() {
            return nextPage;
        }

        public void setNextPage(int nextPage) {
            this.nextPage = nextPage;
        }

        public int getOffset() {
            return offset;
        }

        public void setOffset(int offset) {
            this.offset = offset;
        }

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPrePage() {
            return prePage;
        }

        public void setPrePage(int prePage) {
            this.prePage = prePage;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<ResultBean> getResult() {
            return result;
        }

        public void setResult(List<ResultBean> result) {
            this.result = result;
        }

        public static class FilterBean {
            /**
             * level : 1
             * statTime : 2017-12-01
             */

            private int level;
            private String statTime;

            public int getLevel() {
                return level;
            }

            public void setLevel(int level) {
                this.level = level;
            }

            public String getStatTime() {
                return statTime;
            }

            public void setStatTime(String statTime) {
                this.statTime = statTime;
            }
        }

        public static class ResultBean {
            /**
             * addTime : 1513085828611
             * id : 22454498
             * level : 1
             * modifyTime : 1513713932000
             * modifyTimeValid : 1513713932000
             * pace : 3243201
             * rank : 1
             * runDay : 20
             * runDayValid : 20
             * runNum : 96
             * runNumValid : 70
             * runTime : 945193809
             * runTimeValid : 758815250
             * statTime : 2017-12-01
             * sumCalorie : 94339
             * sumCalorieValid : 85124
             * sumDistance : 2023532
             * sumDistanceValid : 1780037
             * sumStep : 2254223
             * sumStepValid : 1953125
             * type : 3
             * uid : 3930978
             * user : {"avatar":"http://yyssb.ifitmix.com/1002/da63ab25cd94434cbe42feb077bea0ca.jpg","gender":1,"id":3930978,"name":"杨子"}
             */

            private long addTime;
            private int id;
            private int level;
            private long modifyTime;
            private long modifyTimeValid;
            private int pace;
            private int rank;
            private int runDay;
            private int runDayValid;
            private int runNum;
            private int runNumValid;
            private int runTime;
            private int runTimeValid;
            private String statTime;
            private int sumCalorie;
            private int sumCalorieValid;
            private int sumDistance;
            private int sumDistanceValid;
            private int sumStep;
            private int sumStepValid;
            private int type;
            private int uid;
            private UserBean user;

            private RankListPkData pkData;

            public RankListPkData getPkData() {
                return pkData;
            }

            public void setPkData(RankListPkData pkData) {
                this.pkData = pkData;
            }

            public long getAddTime() {
                return addTime;
            }

            public void setAddTime(long addTime) {
                this.addTime = addTime;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getLevel() {
                return level;
            }

            public void setLevel(int level) {
                this.level = level;
            }

            public long getModifyTime() {
                return modifyTime;
            }

            public void setModifyTime(long modifyTime) {
                this.modifyTime = modifyTime;
            }

            public long getModifyTimeValid() {
                return modifyTimeValid;
            }

            public void setModifyTimeValid(long modifyTimeValid) {
                this.modifyTimeValid = modifyTimeValid;
            }

            public int getPace() {
                return pace;
            }

            public void setPace(int pace) {
                this.pace = pace;
            }

            public int getRank() {
                return rank;
            }

            public void setRank(int rank) {
                this.rank = rank;
            }

            public int getRunDay() {
                return runDay;
            }

            public void setRunDay(int runDay) {
                this.runDay = runDay;
            }

            public int getRunDayValid() {
                return runDayValid;
            }

            public void setRunDayValid(int runDayValid) {
                this.runDayValid = runDayValid;
            }

            public int getRunNum() {
                return runNum;
            }

            public void setRunNum(int runNum) {
                this.runNum = runNum;
            }

            public int getRunNumValid() {
                return runNumValid;
            }

            public void setRunNumValid(int runNumValid) {
                this.runNumValid = runNumValid;
            }

            public int getRunTime() {
                return runTime;
            }

            public void setRunTime(int runTime) {
                this.runTime = runTime;
            }

            public int getRunTimeValid() {
                return runTimeValid;
            }

            public void setRunTimeValid(int runTimeValid) {
                this.runTimeValid = runTimeValid;
            }

            public String getStatTime() {
                return statTime;
            }

            public void setStatTime(String statTime) {
                this.statTime = statTime;
            }

            public int getSumCalorie() {
                return sumCalorie;
            }

            public void setSumCalorie(int sumCalorie) {
                this.sumCalorie = sumCalorie;
            }

            public int getSumCalorieValid() {
                return sumCalorieValid;
            }

            public void setSumCalorieValid(int sumCalorieValid) {
                this.sumCalorieValid = sumCalorieValid;
            }

            public int getSumDistance() {
                return sumDistance;
            }

            public void setSumDistance(int sumDistance) {
                this.sumDistance = sumDistance;
            }

            public int getSumDistanceValid() {
                return sumDistanceValid;
            }

            public void setSumDistanceValid(int sumDistanceValid) {
                this.sumDistanceValid = sumDistanceValid;
            }

            public int getSumStep() {
                return sumStep;
            }

            public void setSumStep(int sumStep) {
                this.sumStep = sumStep;
            }

            public int getSumStepValid() {
                return sumStepValid;
            }

            public void setSumStepValid(int sumStepValid) {
                this.sumStepValid = sumStepValid;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getUid() {
                return uid;
            }

            public void setUid(int uid) {
                this.uid = uid;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public static class UserBean {
                /**
                 * avatar : http://yyssb.ifitmix.com/1002/da63ab25cd94434cbe42feb077bea0ca.jpg
                 * gender : 1
                 * id : 3930978
                 * name : 杨子
                 */

                private String avatar;
                private int gender;
                private int id;
                private String name;

                public String getAvatar() {
                    return avatar;
                }

                public void setAvatar(String avatar) {
                    this.avatar = avatar;
                }

                public int getGender() {
                    return gender;
                }

                public void setGender(int gender) {
                    this.gender = gender;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }
            }
        }
    }
}
