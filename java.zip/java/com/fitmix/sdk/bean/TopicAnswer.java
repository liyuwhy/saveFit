package com.fitmix.sdk.bean;

import java.util.List;

/**
 * 话题的回答
 */
public class TopicAnswer {
    private long addTime;//添加时间
    private String avatar;//头像图片地址
    private String content;//回答内容
    private int id;//答案编号
    private int isConfirmed;//0:未审核 1:审核通过(默认) 2:审核不通过
    private int uid;//用户id
    private String name;//用户名
    private int upNum;//点赞数
    private int categoryId;
    private int clickNum;//点击数
    private int isReply;//0:关闭回复,1:开启回复(默认)
    private int parentThemeId;//父级主题帖编号
    private int themeType;//主题帖类型,1:问题,2:回答
    private String signature;//用户签名
    private List<Integer> upUserIds;//点赞用户uid列表
    private int taoLunNum;//讨论数量
    private Topic parentTheme;//回答对应的话题信息
    private int themeVip;

    public int getThemeVip() {
        return themeVip;
    }

    public void setThemeVip(int themeVip) {
        this.themeVip = themeVip;
    }

    public long getAddTime() {
        return addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * 审核状态,
     * 0:未审核 1:审核通过(默认)
     */
    public int getIsConfirmed() {
        return isConfirmed;
    }

    public void setIsConfirmed(int isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String userName) {
        this.name = userName;
    }

    public int getUpNum() {
        return upNum;
    }

    public void setUpNum(int upNum) {
        this.upNum = upNum;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getClickNum() {
        return clickNum;
    }

    public void setClickNum(int clickNum) {
        this.clickNum = clickNum;
    }

    public int getIsReply() {
        return isReply;
    }

    public void setIsReply(int isReply) {
        this.isReply = isReply;
    }

    public int getParentThemeId() {
        return parentThemeId;
    }

    public void setParentThemeId(int parentThemeId) {
        this.parentThemeId = parentThemeId;
    }

    public int getThemeType() {
        return themeType;
    }

    public void setThemeType(int themeType) {
        this.themeType = themeType;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public List<Integer> getUpUserIds() {
        return upUserIds;
    }

    public void setUpUserIds(List<Integer> upUserIds) {
        this.upUserIds = upUserIds;
    }

    public int getTaoLunNum() {
        return taoLunNum;
    }

    public void setTaoLunNum(int taoLunNum) {
        this.taoLunNum = taoLunNum;
    }

    public Topic getParentTheme() {
        return parentTheme;
    }

    public void setParentTheme(Topic parentTheme) {
        this.parentTheme = parentTheme;
    }
}
