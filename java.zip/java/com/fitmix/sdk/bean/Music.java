package com.fitmix.sdk.bean;

import java.util.List;

/**
 * 音乐信息类
 */
public class Music {
    private long addTime;//添加时间
    private String albumUrl;//缩略图
    private String albumUrl_2;//大图
    private int baseAuditionCount;//基础（虚假）试听数量
    private int auditionCount;//试听数量
    private String bpm;//音频
    private String author;//作者
    private int bpmType;//音频类型
    private int bpmVariableBegin;//开始音频
    private int bpmVariableEnd;//结束音频
    private int collectNumber;//收藏数量
    private String customIdentification;
    private int downloadCount;//下载数量
    private int id;//歌曲Id
    private String introduce;//歌曲描述
    private int maid;// ???
    private String name;//歌曲名称
    private int shareCount;//分享数量
    private long shelvesTime;//上架时间
    private int sort;//排序
    private int state;//状态
    private int trackLength;//geq长度
    private int localFlag;//本地音乐的标识 本地音乐为1 fitmix 音乐为 0
    private String url;//歌曲播放地址
    private List<Integer> genre;//流派
    private List<?> mixMusics;//??
    private List<Integer> scene;//风格
    private int type;//音乐类型,1或者null为普通歌曲,2为电台

    public long getAddTime() {
        return addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public String getAlbumUrl() {
        return albumUrl;
    }

    public void setAlbumUrl(String albumUrl) {
        this.albumUrl = albumUrl;
    }

    public String getAlbumUrl_2() {
        return albumUrl_2;
    }

    public void setAlbumUrl_2(String albumUrl_2) {
        this.albumUrl_2 = albumUrl_2;
    }

    public String getBpm() {
        return bpm;
    }

    public void setBpm(String bpm) {
        this.bpm = bpm;
    }

    public int getBpmType() {
        return bpmType;
    }

    public void setBpmType(int bpmType) {
        this.bpmType = bpmType;
    }

    public int getBpmVariableBegin() {
        return bpmVariableBegin;
    }

    public void setBpmVariableBegin(int bpmVariableBegin) {
        this.bpmVariableBegin = bpmVariableBegin;
    }

    public int getBpmVariableEnd() {
        return bpmVariableEnd;
    }

    public void setBpmVariableEnd(int bpmVariableEnd) {
        this.bpmVariableEnd = bpmVariableEnd;
    }

    public int getCollectNumber() {
        return collectNumber;
    }

    public void setCollectNumber(int collectNumber) {
        this.collectNumber = collectNumber;
    }

    public String getCustomIdentification() {
        return customIdentification;
    }

    public void setCustomIdentification(String customIdentification) {
        this.customIdentification = customIdentification;
    }

    public int getDownloadCount() {
        return downloadCount;
    }

    public void setDownloadCount(int downloadCount) {
        this.downloadCount = downloadCount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIntroduce() {
        return introduce;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }

    public int getMaid() {
        return maid;
    }

    public void setMaid(int maid) {
        this.maid = maid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBaseAuditionCount() {
        return baseAuditionCount;
    }

    public void setBaseAuditionCount(int baseAuditionCount) {
        this.baseAuditionCount = baseAuditionCount;
    }

    public int getAuditionCount() {
        return auditionCount;
    }

    public void setAuditionCount(int auditionCount) {
        this.auditionCount = auditionCount;
    }

    public int getShareCount() {
        return shareCount;
    }

    public void setShareCount(int shareCount) {
        this.shareCount = shareCount;
    }

    public long getShelvesTime() {
        return shelvesTime;
    }

    public void setShelvesTime(long shelvesTime) {
        this.shelvesTime = shelvesTime;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getTrackLength() {
        return trackLength;
    }

    public void setTrackLength(int trackLength) {
        this.trackLength = trackLength;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<Integer> getGenre() {
        return genre;
    }

    public void setGenre(List<Integer> genre) {
        this.genre = genre;
    }

    public List<?> getMixMusics() {
        return mixMusics;
    }

    public void setMixMusics(List<?> mixMusics) {
        this.mixMusics = mixMusics;
    }

    public List<Integer> getScene() {
        return scene;
    }

    public void setScene(List<Integer> scene) {
        this.scene = scene;
    }

    public int getLocalFlag() {
        return localFlag;
    }

    public void setLocalFlag(int localFlag) {
        this.localFlag = localFlag;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 音乐类型,1或者null为普通歌曲,2为电台
     */
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
