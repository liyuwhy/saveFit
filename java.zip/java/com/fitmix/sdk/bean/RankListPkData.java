package com.fitmix.sdk.bean;

/**
 * 排行榜获取两两PK数据接口(run/month/rank/pk.json)返回的结果
 */

public class RankListPkData {


    /**
     * st : 1514968579311
     * stat : {"id":4596691,"level":5,"pace":411,"runNumValid":3,"runTimeValid":2726702,"statTime":"2018-01-01","sumCalorieValid":518,"sumDistanceValid":10820,"sumStepValid":11967,"type":3,"uid":3901312}
     * code : 0
     * k : a8b806a206684abd9abbbee0c7b0d9ef
     * targetStat : {"id":4596691,"level":5,"pace":411,"runNumValid":3,"runTimeValid":2726702,"statTime":"2018-01-01","sumCalorieValid":518,"sumDistanceValid":10820,"sumStepValid":11967,"type":3,"uid":3901312}
     */

    private long st;
    private PkData stat;
    private int code;
    private String k;
    private PkData targetStat;

    public long getSt() {
        return st;
    }

    public void setSt(long st) {
        this.st = st;
    }

    public PkData getStat() {
        return stat;
    }

    public void setStat(PkData stat) {
        this.stat = stat;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public PkData getTargetStat() {
        return targetStat;
    }

    public void setTargetStat(PkData targetStat) {
        this.targetStat = targetStat;
    }

    public static class PkData {
        /**
         * id : 4596691
         * level : 5
         * pace : 411
         * runNumValid : 3
         * runTimeValid : 2726702
         * statTime : 2018-01-01
         * sumCalorieValid : 518
         * sumDistanceValid : 10820
         * sumStepValid : 11967
         * type : 3
         * uid : 3901312
         */

        private int id;
        private int level;//当前等级
        private int pace;//配速,单位为秒
        private int runNumValid;//有效总运动次数
        private int runTimeValid;//有效总运动时长,单位为毫秒
        private String statTime;
        private int sumCalorieValid;//有效总卡路里,单位为大卡
        private int sumDistanceValid;//有效总距离,单位为米
        private int sumStepValid;//有效总步数
        private int type;
        private int uid;//用户uid

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }

        public int getPace() {
            return pace;
        }

        public void setPace(int pace) {
            this.pace = pace;
        }

        public int getRunNumValid() {
            return runNumValid;
        }

        public void setRunNumValid(int runNumValid) {
            this.runNumValid = runNumValid;
        }

        public int getRunTimeValid() {
            return runTimeValid;
        }

        public void setRunTimeValid(int runTimeValid) {
            this.runTimeValid = runTimeValid;
        }

        public String getStatTime() {
            return statTime;
        }

        public void setStatTime(String statTime) {
            this.statTime = statTime;
        }

        public int getSumCalorieValid() {
            return sumCalorieValid;
        }

        public void setSumCalorieValid(int sumCalorieValid) {
            this.sumCalorieValid = sumCalorieValid;
        }

        public int getSumDistanceValid() {
            return sumDistanceValid;
        }

        public void setSumDistanceValid(int sumDistanceValid) {
            this.sumDistanceValid = sumDistanceValid;
        }

        public int getSumStepValid() {
            return sumStepValid;
        }

        public void setSumStepValid(int sumStepValid) {
            this.sumStepValid = sumStepValid;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }
    }
}
