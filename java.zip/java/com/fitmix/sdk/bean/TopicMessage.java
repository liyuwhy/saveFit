package com.fitmix.sdk.bean;

/**
 * 话题消息
 */

public class TopicMessage {

    /**
     * 问题被回答的消息
     */
    public static final int TYPE_THEME_ANSWER = 1;
    /**
     * 回答被讨论的消息
     */
    public static final int TYPE_THEME_DISCUSS = 2;
    /**
     * 讨论被@ 如:张三 @ 李四
     */
    public static final int TYPE_THEME_TO_DISCUSS = 3;
    /**
     * 消息类型
     * 1、话题相关消息
     * 2、回答相关消息
     */
    private int type;

    /**
     * 消息类型为问题被回答的消息时对应的话题
     */
    private Topic topic;

    /**
     * 消息类型为回答被讨论的消息时对应的评论
     */
    private TopicDiscuss topicDiscuss;

    /**
     * @param type  消息类型 1:问题被回答的消息,2:回答被讨论的消息
     * @param topic 消息类型为问题被回答的消息时对应的话题
     */
    public TopicMessage(int type, Topic topic) {
        this.type = type;
        this.topic = topic;
    }

    /**
     * @param type         消息类型 1:问题被回答的消息,2:回答被讨论的消息
     * @param topicDiscuss 消息类型为回答被讨论的消息时对应的评论
     */
    public TopicMessage(int type, TopicDiscuss topicDiscuss) {
        this.type = type;
        this.topicDiscuss = topicDiscuss;
    }


    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Topic getTopic() {
        return topic;
    }

    public void setTopic(Topic topic) {
        this.topic = topic;
    }

    public TopicDiscuss getTopicDiscuss() {
        return topicDiscuss;
    }

    public void setTopicDiscuss(TopicDiscuss topicDiscuss) {
        this.topicDiscuss = topicDiscuss;
    }
}
