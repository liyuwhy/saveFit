package com.fitmix.sdk.bean;

import java.util.List;

/**
 * 登录接口login.json返回的结果中附带的消息体
 */
public class PushMessageBody {

    /**
     * activityId : 33
     * num : 1
     * pushType : 1
     */

    private List<ActivitysBean> activitys;
    /**
     * clubId : 223
     * clubNoticeId : 29
     * num : 3
     * pushType : 12
     */

    private List<ClubsBean> clubs;

    public List<ActivitysBean> getActivitys() {
        return activitys;
    }

    public void setActivitys(List<ActivitysBean> activitys) {
        this.activitys = activitys;
    }

    public List<ClubsBean> getClubs() {
        return clubs;
    }

    public void setClubs(List<ClubsBean> clubs) {
        this.clubs = clubs;
    }

    public static class ActivitysBean {
        private int activityId;
        private int num;
        private int pushType;

        public int getActivityId() {
            return activityId;
        }

        public void setActivityId(int activityId) {
            this.activityId = activityId;
        }

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public int getPushType() {
            return pushType;
        }

        public void setPushType(int pushType) {
            this.pushType = pushType;
        }
    }

    public static class ClubsBean {
        private int clubId;
        private int clubNoticeId;
        private int num;
        private int pushType;

        public int getClubId() {
            return clubId;
        }

        public void setClubId(int clubId) {
            this.clubId = clubId;
        }

        public int getClubNoticeId() {
            return clubNoticeId;
        }

        public void setClubNoticeId(int clubNoticeId) {
            this.clubNoticeId = clubNoticeId;
        }

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public int getPushType() {
            return pushType;
        }

        public void setPushType(int pushType) {
            this.pushType = pushType;
        }
    }
}
