package com.fitmix.sdk.bean;

/**
 * 跳绳记录信息
 */
public class SkipLogInfo {

    private int uid;//用户ID
    private int bpm;//平均跳频(每分钟个数)
    private int bpmMatch;//平均跳频与音乐BPM匹配度 (平均跳频/音乐BPM)*100%
    private int uploaded;//是否已同步到服务器,1:已同步,0:未同步
    private long skipTime;//运动时长,单位毫秒
    private long startTime;//开始时间,单位毫秒
    private long endTime;//结束时间,单位毫秒
    private int skipNumber;//个数
    private double calorie;//卡路里
    private double heartRateAvg;//心率平均值
    private double maxHeartRate;//最大心率
    private double minHeartRate;//最小心率
    private double consumptionSpendTime;//燃脂时长
    private int type;//类型
    private int dataSources;//1在线数据 2 离线数据

    private String skipDataPath;//计数文件路径

    private String heartRateData;//心率数据相关，由UserHeartRate类转为的json字符串

    public SkipLogInfo() {
        clear();
    }

    public void clear() {
        uid = -1;
        bpm = 0;
        bpmMatch = 0;
        uploaded = 0;
        startTime = 0;
        endTime = 0;
        calorie = 0;
        heartRateAvg = 0;

        maxHeartRate = 0;
        minHeartRate = 0;
        consumptionSpendTime = 0;
        heartRateData = "";
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    /**
     * 获取运动消耗卡路里,单位大卡
     */
    public double getCalorie() {
        return calorie;
    }

    /**
     * 设置运动消耗卡路里
     *
     * @param calorie 运动消耗卡路里,单位大卡
     */
    public void setCalorie(double calorie) {
        this.calorie = calorie;
    }

    public int getBpm() {
        return bpm;
    }

    public void setBpm(int bpm) {
        this.bpm = bpm;
    }

    public int getBpmMatch() {
        return bpmMatch;
    }

    public void setBpmMatch(int bpmMatch) {
        this.bpmMatch = bpmMatch;
    }

    /**
     * 记录是否已同步到服务器,1:已同步,0:未同步
     */
    public int getUploaded() {
        return uploaded;
    }

    /**
     * 设置记录与服务器同步状态
     *
     * @param uploaded 1:已同步,0:未同步,2:记录未完成
     */
    public void setUploaded(int uploaded) {
        this.uploaded = uploaded;
    }

    /**
     * 获取运动开始时间
     *
     * @return 运动开始时间, 单位毫秒
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * 设置运动开始时间
     *
     * @param startTime 运动开始时间,单位毫秒
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取运动结束时间
     *
     * @return 运动结束时间, 单位毫秒
     */
    public long getEndTime() {
        return endTime;
    }

    /**
     * 设置运动结束时间
     *
     * @param endTime 运动结束时间,单位毫秒
     */
    public void setEndTime(long endTime) {
        this.endTime = endTime;

    }

    /**
     * 获取运动时长,单位毫秒
     */
    public long getSkipTime() {
        return skipTime;
    }

    /**
     * 设置运动时长
     *
     * @param skipTime 运动时长,单位毫秒
     */
    public void setSkipTime(long skipTime) {
        this.skipTime = skipTime;
    }

    public int getSkipNumber() {
        return skipNumber;
    }

    public void setSkipNumber(int skipNumber) {
        this.skipNumber = skipNumber;
    }

    public String getSkipDataPath() {
        return skipDataPath;
    }

    public void setSkipDataPath(String skipDataPath) {
        this.skipDataPath = skipDataPath;
    }

    /**
     * 获取运动类型 0或1表示跑步2表示跳绳
     */
    public int getType() {
        return type;
    }

    /**
     * 设置运动类型 0或1表示跑步2表示跳绳
     */
    public void setType(int type) {
        this.type = type;
    }

    public double getHeartRateAvg() {
        return heartRateAvg;
    }

    public void setHeartRateAvg(double heartRateAvg) {
        this.heartRateAvg = heartRateAvg;
    }

    public double getMaxHeartRate() {
        return maxHeartRate;
    }

    public void setMaxHeartRate(double maxHeartRate) {
        this.maxHeartRate = maxHeartRate;
    }

    public double getMinHeartRate() {
        return minHeartRate;
    }

    public void setMinHeartRate(double minHeartRate) {
        this.minHeartRate = minHeartRate;
    }

    public double getConsumptionSpendTime() {
        return consumptionSpendTime;
    }

    public void setConsumptionSpendTime(double consumptionSpendTime) {
        this.consumptionSpendTime = consumptionSpendTime;
    }

    public int getDataSources() {
        return dataSources;
    }

    public void setDataSources(int dataSources) {
        this.dataSources = dataSources;
    }

    public String getHeartRateDate() {
        return heartRateData;
    }

    public void setHeartRateDate(String heartRateData) {
        this.heartRateData = heartRateData;
    }
}
