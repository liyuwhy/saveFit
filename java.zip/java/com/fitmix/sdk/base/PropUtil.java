package com.fitmix.sdk.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 音乐下载进度文件（.prop）的工具类
 */
public class PropUtil {

    private List<String> tagList;//存放键（完整歌曲名234.m4a）
    private List<String> valueList;//存放值()

    private static PropUtil instance;
    private String sSaveFile;//保存FitmixUtil的getMusicPath() + "downloading.prop"


    public static PropUtil getInstance() {
        if (instance == null) {
            instance = new PropUtil();
        }
        return instance;
    }

    public String getFilename() {
        return sSaveFile;
    }

    public boolean setLocaleFilename(String sFilename) {
        sSaveFile = sFilename;
        File f = new File(sFilename);
        if (!f.exists())
            return false;

        try {
            FileInputStream fin = new FileInputStream(sFilename);
            setInputStream(fin);
            fin.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean setInputStream(InputStream is) {
        releaseResource();
        if (is == null)
            return false;
        String res;
        try {
            int length = is.available();
            byte[] buffer = new byte[length];
            is.read(buffer);
            res = new String(buffer, "UTF-8");//EncodingUtils.getString(buffer, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        setContent(res);
        return true;
    }

    public void setContent(String sContent) {

        String[] lines = sContent.split("\r\n");

        int iIndex;
        String sTag;
        String sValue;

        for (String sLine : lines) {
            if (sLine == null || sLine.isEmpty())
                continue;

            iIndex = sLine.indexOf('=');
            if (iIndex == -1)
                continue;
            sTag = sLine.substring(0, iIndex);
            sValue = sLine.substring(iIndex + 1);
            sTag = sTag.trim();
            sValue = sValue.trim();
            if (sTag == null || sTag.isEmpty())
                continue;

            getTags().add(sTag);
            getValues().add(sValue);
        }
        distinctTags();
    }

    private void distinctTags() {
        if (getTags().size() != getValues().size())
            return;

        for (int i = 0; i < getTags().size() - 1; ) {
            for (int j = i + 1; j < getTags().size() - 1; ) {
                if (getTags().get(j).equals(getTags().get(i))) {
                    getTags().remove(j);
                    getValues().remove(j);
                    continue;
                }
                j++;
            }
            i++;
        }
    }

    public void releaseResource() {
        if (tagList != null)
            getTags().clear();
        tagList = null;
        if (valueList != null)
            getValues().clear();
        valueList = null;
    }


    //音乐下载的进度文件相关
    public boolean parseDownloadInfo(String sInfo,
                                     HashMap<String, Integer> hashmap) {
        if (sInfo == null || sInfo.isEmpty())
            return false;
        if (hashmap == null)
            return false;

        final int HEAD_INDEX = 0;
        final int TAIL_INDEX = 1;
        final int BODY_INDEX = 2;

        int iIndex = sInfo.indexOf('_');
        if (iIndex == -1)
            return false;
        /**
         * 解决bug
         * java.lang.NumberFormatException: Invalid int: "
         * at java.lang.Integer.parseInt(Integer.java:334)
         * at com.fitmix.sdk.base.FitmixUtil.parseDownloadInfo(FitmixUtil.java:589)
         * */
        int id;
        try {
            id = Integer.parseInt(sInfo.substring(0, iIndex));
        } catch (NumberFormatException e) {
            return false;
        }
        sInfo = sInfo.substring(iIndex + 1);
        String sSeg[] = sInfo.split("_");
        if (sSeg == null || sSeg.length != 3)
            return false;

        iIndex = sSeg[HEAD_INDEX].indexOf('.');
        if (iIndex == -1)
            return false;
        String sHeadCurrent = sSeg[HEAD_INDEX].substring(0, iIndex);
        if (sHeadCurrent == null || sHeadCurrent.isEmpty())
            return false;
        String sHeadTotal = sSeg[HEAD_INDEX].substring(iIndex + 1);
        if (sHeadTotal == null || sHeadTotal.isEmpty())
            return false;

        iIndex = sSeg[BODY_INDEX].indexOf('.');
        if (iIndex == -1)
            return false;
        String sBodyCurrent = sSeg[BODY_INDEX].substring(0, iIndex);
        if (sBodyCurrent == null || sBodyCurrent.isEmpty())
            return false;
        String sBodyTotal = sSeg[BODY_INDEX].substring(iIndex + 1);
        if (sBodyTotal == null || sBodyTotal.isEmpty())
            return false;

        iIndex = sSeg[TAIL_INDEX].indexOf('.');
        if (iIndex == -1)
            return false;
        String sTailCurrent = sSeg[TAIL_INDEX].substring(0, iIndex);
        if (sTailCurrent == null || sTailCurrent.isEmpty())
            return false;
        String sTailTotal = sSeg[TAIL_INDEX].substring(iIndex + 1);
        if (sTailTotal == null || sTailTotal.isEmpty())
            return false;

        int headCurrent = Integer.parseInt(sHeadCurrent);
        int headTotal = Integer.parseInt(sHeadTotal);
        int bodyCurrent = Integer.parseInt(sBodyCurrent);
        int bodyTotal = Integer.parseInt(sBodyTotal);
        int tailCurrent = Integer.parseInt(sTailCurrent);
        int tailTotal = Integer.parseInt(sTailTotal);

        if ((headCurrent > headTotal) || (bodyCurrent > bodyTotal)
                || (tailCurrent > tailTotal))
            return false;
        hashmap.put("id", id);
        hashmap.put("headCurrent", headCurrent);
        hashmap.put("headTotal", headTotal);
        hashmap.put("bodyCurrent", bodyCurrent);
        hashmap.put("bodyTotal", bodyTotal);
        hashmap.put("tailCurrent", tailCurrent);
        hashmap.put("tailTotal", tailTotal);

        return true;
    }

    public List<String> getTags() {
        if (tagList == null)
            tagList = new ArrayList<>();
        return tagList;
    }

    private List<String> getValues() {
        if (valueList == null)
            valueList = new ArrayList<>();
        return valueList;
    }


    public boolean isExistTag(String sTag) {
        if (sTag == null || sTag.isEmpty())
            return false;

        for (int i = 0; i < getTags().size(); i++) {
            if (getTags().get(i).equals(sTag))
                return true;
        }
        return false;
    }

    public void setStringValue(String sTag, String sValue) {
        if (sTag == null || sTag.isEmpty())
            return;

        if (getTags().size() != getValues().size())
            return;
        for (int i = 0; i < getTags().size(); i++) {
            if (getTags().get(i).equals(sTag)) {
                getValues().set(i, sValue);
            }
        }
    }

    public void removeItem(String sTag) {
        if (sTag == null || sTag.isEmpty())
            return;

        if (getTags().size() != getValues().size())
            return;
        for (int i = 0; i < getTags().size(); ) {
            if (getTags().get(i).equals(sTag)) {
                getTags().remove(i);
                getValues().remove(i);
                break;
            }
            i++;
        }

    }

    public void addItem(String sTag, String sValue) {
        if (isExistTag(sTag)) {
            setStringValue(sTag, sValue);
            return;
        }

        getTags().add(sTag);
        if (sValue == null)
            sValue = "";
        getValues().add(sValue);
    }

    public void saveProp() {
        if (sSaveFile == null)
            return;
        String sContent = getResultString();
        if (sContent == null)
            return;
        File f = new File(sSaveFile);

        try {
            if (!f.exists())
                f.createNewFile();

            FileOutputStream fout = new FileOutputStream(sSaveFile);
            byte[] bytes = sContent.getBytes();
            fout.write(bytes);
            fout.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getResultString() {

        if (getTags().size() != getValues().size())
            return null;
        StringBuffer sb = new StringBuffer();
//        String sContent = "";
        for (int i = 0; i < getTags().size(); i++) {
//            sContent += getTags().get(i) + "=";
            sb.append(getTags().get(i));
            sb.append("=");
            if (getValues().get(i) != null) {
//                sContent += getValues().get(i);
                sb.append(getValues().get(i));
            }
//            sContent += "\r\n";
            sb.append("\r\n");
        }
        return sb.toString();//sContent;
    }

    //解析.prop文件进度方法
    public String getStringValue(String sTag) {
        return getStringValue(sTag, null);
    }

    public String getStringValue(String sTag, String valueDefault) {
        if (sTag == null || sTag.isEmpty())
            return valueDefault;

        if (getTags().size() != getValues().size())
            return valueDefault;
        for (int i = 0; i < getTags().size(); i++) {
            if (getTags().get(i).equals(sTag))
                return getValues().get(i);
        }

        return valueDefault;
    }

}
