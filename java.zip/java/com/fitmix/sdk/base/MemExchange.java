package com.fitmix.sdk.base;

import android.text.TextUtils;

import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.view.bean.Album;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MemExchange {
    private Album album;
    private Club club;
    private List<Music> listSelect;//准备选中的歌曲
    private List<Integer> listMusicId; //以选中的歌曲ID
    private boolean bNeedRefreshClubList;

    private Topic topic;//话题,用于DiscoveryFragment传递给TopicDetailActivity用
    private HashMap<String, String> topicContents;//用于保存话题补充描述、答案、评论内容,防止上传时Intent超过
    // 1M问题

    private static MemExchange instance;

    public MemExchange() {
        clear();
    }

    public void clear() {
        album = null;
        bNeedRefreshClubList = true;
        topic = null;
        topicContents = null;
    }

    public static MemExchange getInstance() {
        if (instance == null) {
            synchronized (MemExchange.class) {
                if (instance == null) {
                    instance = new MemExchange();
                }
            }
        }
        return instance;
    }

    public Club getCurrentClub() {
        return club;
    }

    public void setCurrentClub(Club club) {
        this.club = club;
    }

    public List<Music> getListMusicSelect() {
        if (listSelect == null) listSelect = new ArrayList<>();
        return listSelect;
    }

    public void setListMusicSelect(List<Music> list) {
        if ((listSelect != null) && (list != listSelect)) listSelect.clear();
        listSelect = list;
    }

    public Album getCurrentAlbum() {
        return album;
    }

    public void setCurrentAlbum(Album album) {
        this.album = album;
    }

    public boolean getNeedRefreshClubList() {
        return bNeedRefreshClubList;
    }

    public void setNeedRefreshClubList(boolean bNeedRefreshClubList) {
        this.bNeedRefreshClubList = bNeedRefreshClubList;
    }

    public List<Integer> getListMusicId() {
        if (listMusicId == null) listMusicId = new ArrayList<>();
        return listMusicId;
    }

    public Topic getTopic() {
        return topic;
    }

    public void setTopic(Topic topic) {
        this.topic = topic;
    }

    /**
     * 获取保存话题补充描述、答案、评论内容的hashMap
     */
    private HashMap<String, String> getTopicContents() {
        if (topicContents == null) {
            topicContents = new HashMap<>();
        }
        return topicContents;
    }

    /**
     * 根据key,获取话题补充描述、答案、评论内容
     */
    public String getTopicContent(String key) {
        if (TextUtils.isEmpty(key)) {
            return "";
        }
        return getTopicContents().get(key);
    }

    /**
     * 设置话题补充描述、答案、评论内容至hashMap
     */
    public void setTopicContent(String key, String content) {
        if (TextUtils.isEmpty(key)) {
            return;
        }
        getTopicContents().put(key, content);
        if (getTopicContents().entrySet() != null) {
            Iterator iterator = getTopicContents().entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> entry = (Map.Entry<String, String>) iterator.next();
                String k = entry.getKey();
                String v = entry.getValue();
                Logger.i(Logger.DEBUG_TAG, "MemExchange-->setTopicContent k:" + k + ",v:" + v);
            }
        }
    }

    /**
     * 移除指定Key的话题补充描述、答案、评论内容
     */
    public void removeTopicContent(String key) {
        if (TextUtils.isEmpty(key)) {
            return;
        }
        getTopicContents().remove(key);
    }

    /**
     * 清空所有的话题补充描述、答案、评论内容
     */
    public void clearTopicContent() {
        getTopicContents().clear();
    }

}
