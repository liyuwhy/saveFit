package com.fitmix.sdk.base;

import com.fitmix.sdk.common.sound.PlayerController;

public class MyConfig {
    private static MyConfig instance;

    public MyConfig() {
        super();
    }

    public static MyConfig getInstance() {
        if (instance == null) {
            synchronized (MyConfig.class) {
                if (instance == null) {
                    instance = new MyConfig();
                }
            }
        }
        return instance;
    }

    public PlayerController getPlayer() {
        return PlayerController.getInstance();
    }

    public MemExchange getMemExchange() {
        return MemExchange.getInstance();
    }

}
