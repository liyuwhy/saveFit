package com.fitmix.sdk.task;

import android.os.Handler;
import android.os.Message;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.common.FileCompressHelper;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.bean.UserSportsWatch;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.process.BaseProcessor;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.WatchSportLog;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 同步手表运动记录的任务,不需要与UI交互,在{@link ThreadManager#NETWORK_EXECUTOR 中执行}
 */
public class SyncWatchRecordTask implements Runnable {

    //    private WeakReference<Context> mContext;
    private WatchSportLog watchSportLog;
    private List<WatchSportLog> mWatchSportLogs;
    //    private String[] rawFiles;
    private Handler mHandler;


    /**
     * 创建同步手表运动记录的任务
     */
    public SyncWatchRecordTask(WatchSportLog watchSportRecord, Handler handler) {
        this.watchSportLog = watchSportRecord;
//        this.rawFiles = rawFiles;
        mHandler = handler;
    }

    /**
     * 创建同步运动记录的任务
     *
     * @param watchRecords 未同步的运动记录集合
     */
    public SyncWatchRecordTask(List<WatchSportLog> watchRecords, Handler handler) {
        mWatchSportLogs = watchRecords;
//        this.rawFiles = rawFiles;
        mHandler = handler;
    }


    @Override
    public void run() {
        if (watchSportLog != null) {
            saveWatchSportInNet(watchSportLog);
        }

        if (mWatchSportLogs != null) {
            for (WatchSportLog sportRecord : mWatchSportLogs) {
                saveWatchSportInNet(sportRecord);
            }
        }
    }

    /**
     * 保存运动记录到后台服务器
     *
     * @param sportRecord
     */
    private void saveWatchSportInNet(WatchSportLog sportRecord) {
        if (sportRecord == null) return;

        int uid = sportRecord.getUid();
//        int type = sportRecord.getType();
        long startTime = sportRecord.getStartTime();
        long duration = sportRecord.getSportDuration() * 1000;//转换单位为毫秒
        long endTime = startTime + duration;//转换单位为毫秒
        String detail = sportRecord.getDetail();
        int calorie = sportRecord.getTotalCalorie();
        double consumeFat = sportRecord.getFatBurst();

        //处理记录相应的文件
        String trailFileName = Config.PATH_DOWN_TRAIL + sportRecord.getUid() + "_" + sportRecord.getStartTime() + ".json";
        String stepFileName = Config.PATH_DOWN_STEP + sportRecord.getUid() + "_" + sportRecord.getStartTime() + ".step";
        String zipFileName = Config.PATH_DOWN_STEP + sportRecord.getUid() + "_" + sportRecord.getStartTime() + ".zip";//压缩文件
        List<String> files = FileUtils.getFilesByPrefix(Config.PATH_WATCH_LOG_DATA, sportRecord.getUid() + "_" + sportRecord.getStartTime());
        if (files == null) {
            files = new ArrayList<>();
        }
        files.add(trailFileName);
        files.add(stepFileName);
        String[] rawFiles = files.toArray(new String[0]);

        boolean zipped = false;
        File zipFile = new File(zipFileName);
        if (!zipFile.exists()) {
            //1.获取要上传的文件列表和标签
            zipped = FileCompressHelper.zipFiles(rawFiles, zipFileName);
            Logger.d(Logger.DEBUG_TAG, "zipped:" + zipped);
        } else {//文件如果存在则不再做压缩操作
            if (zipFile.length() > 0) {
                zipped = true;
            }
        }

        // 获取压缩源文件
        String directory =  Config.PATH_WATCH_LOG_DATA + startTime+ File.separator;
        String timeStr = WatchFormatManager.dateTime2String(startTime);
        String zipSourceFile =  Config.PATH_WATCH_LOG_DATA + timeStr+".zip";

        if( !new File(zipSourceFile).exists() && new File(directory).exists() ){
            Logger.d(Logger.LOG_TAG,"source Directory tozip");
            FileCompressHelper.toZip(directory,zipSourceFile,true);
            FileUtils.deleteFile(directory);
        }

        //2.网络请求
        String url = ApiConstants.addWatchSportRecord(uid, 3, startTime, endTime, duration, calorie, consumeFat, detail);

        BaseProcessor baseProcessor = new BaseProcessor();
        String result;
        if (zipped) {//优先调用上传压缩文件的接口
            List<String> sFilenames = new ArrayList<>();
            sFilenames.add(zipFileName);
            sFilenames.add(zipSourceFile);
            List<String> sTags = new ArrayList<>();
            sTags.add("fileZip");
            sTags.add("fileSourceZip");
            result = baseProcessor.uploadDataToServer(url, sFilenames, sTags);
        } else {//调用
            result = baseProcessor.getDataFromApi(url);
        }
        Logger.i(Logger.DEBUG_TAG, "SyncWatchRecordTask-->saveWatchSportInNet url:" + url + "\nresult:" + result);
        //3.处理网络请求结果
        UserSportsWatch addWatchRecord = JsonHelper.getObject(result, UserSportsWatch.class);
        handleUploadWatchRecord(addWatchRecord);
    }

    /**
     * 处理上传运动记录回调
     */
    private void handleUploadWatchRecord(UserSportsWatch userSportsWatch) {
        if (userSportsWatch == null) {
            Logger.e(Logger.DEBUG_TAG, "handleUploadRecord-->addRunRecord is null");
            if (mHandler != null) {
                Message message = new Message();
                message.what = Config.MSG_SYNC_TASK_DONE;
                message.arg1 = 404;//上传结果为空
                mHandler.sendMessage(message);
            }
            return;
        }
        if (userSportsWatch.getCode() == 0) {
            UserSportsWatch.UserRunBean userRunBean = userSportsWatch.getUserRun();
            if (userRunBean != null) {
                int uid = userRunBean.getUid();
                long startTime = userRunBean.getStartTime();
                String zipFile = userRunBean.getWatchZipFile();
                if (zipFile != null) {
                    if (!zipFile.startsWith("http")) {//调整下
                        zipFile = Config.RESOURCE_HOST + zipFile;
                    }
                }
                //上传成功后更新运动记录同步状态
                WatchSportDataHelper.updateWatchSportRecordSyncState(uid, startTime, zipFile, 1);
                if (mHandler != null) {
                    Message message = new Message();
                    message.what = Config.MSG_SYNC_TASK_DONE;
                    message.arg1 = 0;//上传结果为成功
                    message.obj = startTime;
                    mHandler.sendMessage(message);
                }
                //删除本地压缩文件
                String zipFileName = Config.PATH_DOWN_STEP + uid + "_" + startTime + ".zip";
                if (FileUtils.isFileExist(zipFileName)) {
                    FileUtils.deleteFile(zipFileName);
                }
            }
        } else {
            if (mHandler != null) {
                Message message = new Message();
                message.what = Config.MSG_SYNC_TASK_DONE;
                message.arg1 = 404;//上传结果为空
                mHandler.sendMessage(message);
            }
        }
    }


}
