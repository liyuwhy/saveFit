package com.fitmix.sdk.task;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.common.FileCompressHelper;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.bean.AddRunRecord;
import com.fitmix.sdk.model.api.bean.CoinReward;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.UserRunStatistics;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.process.BaseProcessor;
import com.fitmix.sdk.view.activity.BaseActivity;

import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;

/**
 * 同步跑步记录的任务,不需要与UI交互,在{@link com.fitmix.sdk.common.ThreadManager#NETWORK_EXECUTOR 中执行}
 */
public class SyncRunRecordTask implements Runnable {

    private RunLogInfo mRunLogInfo;
    private List<RunLogInfo> mRunLogInfoList;
    private Handler mHandler;

    /**
     * 创建同步跑步记录的任务
     *
     * @param runLogInfo 未同步的跑步记录
     */
    public SyncRunRecordTask(RunLogInfo runLogInfo, Handler handler) {
        mRunLogInfo = runLogInfo;
        mHandler = handler;
    }

    /**
     * 创建同步跑步记录的任务
     *
     * @param runLogInfoList 未同步的跑步记录集合
     */
    public SyncRunRecordTask(List<RunLogInfo> runLogInfoList, Handler handler) {
        mRunLogInfoList = runLogInfoList;
        mHandler = handler;
    }

    @Override
    public void run() {
        if (mRunLogInfo != null) {
            saveRunLogInNet(mRunLogInfo);
        }

        if (mRunLogInfoList != null) {
            for (RunLogInfo runLogInfo : mRunLogInfoList) {
                saveRunLogInNet(runLogInfo);
            }
        }
    }

    /**
     * 保存运动记录到后台服务器
     */
    private void saveRunLogInNet(RunLogInfo runLog) {
        if (runLog == null) return;
        String trailFileName = Config.PATH_DOWN_TRAIL + runLog.getUid() + "_" + runLog.getStartTime() + ".json";
        String stepFileName = Config.PATH_DOWN_STEP + runLog.getUid() + "_" + runLog.getStartTime() + ".step";
        String zipFileName = Config.PATH_DOWN_STEP + runLog.getUid() + "_" + runLog.getStartTime() + ".zip";//压缩文件

        //1.以下代码与SportDataProcessor一致
        int uid = runLog.getUid();
        int type = runLog.getType();
        int mode = runLog.getMode();
        int locationType = runLog.getLocationType();
        int bpm = runLog.getBpm();
        int bpmMatch = runLog.getBpmMatch();
        int step = runLog.getStep();
        long calorie = runLog.getCalorie();
        long runTime = runLog.getRunTime();
        long startTime = runLog.getStartTime();
        long endTime = runLog.getEndTime();
        long distance = runLog.getDistance();
        double startLng = runLog.getStartLng();
        double startLat = runLog.getStartLat();
        double endLng = runLog.getEndLng();
        double endLat = runLog.getEndLat();

        String heartRateData = runLog.getHeartRateDate();

        double consumeFat = runLog.getConsumeFat();
        double elevation = runLog.getElevation();

        //2.获取要上传的文件列表和标签
        boolean ignore4003Error = false;//是否忽略服务器返回的4003(计步文件没上传)错误
        List<String> fileNames = new ArrayList<>();
        List<String> fileTagList = new ArrayList<>();
        //尝试将轨迹文件和计步文件一起压缩上传,V2.3.1版本以后开始
        String[] files = new String[]{trailFileName, stepFileName};
        boolean zipped = FileCompressHelper.zipFiles(files, zipFileName);
        if (!zipped) {//压缩失败,用回之前的方式
            if (!TextUtils.isEmpty(trailFileName)) {
                if (FileUtils.isFileExist(trailFileName)) {
                    fileNames.add(trailFileName);
                    fileTagList.add("file");
                }
            }
            if (!TextUtils.isEmpty(stepFileName)) {
                if (FileUtils.isFileExist(stepFileName)) {
                    fileNames.add(stepFileName);
                    fileTagList.add("stepFile");
                } else {
                    ignore4003Error = true;
                }
            } else {
                ignore4003Error = true;
            }
        }

        //3.网络请求
        String url = ApiConstants.addSportRecordWithHeartRate(uid, type, mode, locationType, bpm, bpmMatch, step,
                calorie, runTime, startTime, endTime, distance,
                startLng, startLat, endLng, endLat, heartRateData, consumeFat, elevation);

        BaseProcessor baseProcessor = new BaseProcessor();
        String result;
        if (zipped) {//优先调用上传压缩文件的接口
            result = baseProcessor.uploadDataToServer(url, zipFileName, "userRunZip");
        } else if (fileNames.size() > 0) {//有文件时,调用带上传文件的接口
            result = baseProcessor.uploadDataToServer(url, fileNames, fileTagList);
        } else {//调用
            result = baseProcessor.getDataFromApi(url);
        }
        Logger.i(Logger.DEBUG_TAG, "SyncRunRecordTask-->saveRunLogInNet URL:" + url);
        Logger.i(Logger.DEBUG_TAG, "SyncRunRecordTask-->saveRunLogInNet uid:" + uid + ",runId:" + startTime +
                "\nresult:" + result);
        //4.处理网络请求结果
        AddRunRecord addRunRecord = JsonHelper.getObject(result, AddRunRecord.class);
        handleUploadRecord(addRunRecord, ignore4003Error);
        //5.处理金币任务
        handleCoinTask(addRunRecord);
    }


    /**
     * 处理上传跑步记录回调
     */
    private void handleUploadRecord(AddRunRecord addRunRecord, boolean ignore4003Error) {
        if (addRunRecord == null) {
            Logger.e(Logger.DEBUG_TAG, "handleUploadRecord-->addRunRecord is null");
            if (mHandler != null) {
                Message message = new Message();
                message.what = Config.MSG_SYNC_TASK_DONE;
                message.arg1 = 404;//上传结果为空
                mHandler.sendMessage(message);
            }
            return;
        }
        AddRunRecord.UserRunEntity userRunEntity = addRunRecord.getUserRun();

        if (addRunRecord.getCode() == 0) {//上传成功后
            if (userRunEntity != null) {
                int uid = userRunEntity.getUid();
                long startTime = userRunEntity.getStartTime();
                //上传成功后更新跑步记录同步状态
                SportRecordsHelper.updateSportRecordSyncState(uid, startTime, 1);
                if (mHandler != null) {
                    Message message = new Message();
                    message.what = Config.MSG_SYNC_TASK_DONE;
                    message.arg1 = addRunRecord.getCode();
                    message.obj = startTime;
                    mHandler.sendMessage(message);
                }
                //删除本地压缩文件
                String zipFileName = Config.PATH_DOWN_STEP + uid + "_" + startTime + ".zip";
                if (FileUtils.isFileExist(zipFileName)) {
                    FileUtils.deleteFile(zipFileName);
                }

            }
        } else if (addRunRecord.getCode() == 4003) {
            if (ignore4003Error) {
                if (userRunEntity != null) {
                    int uid = userRunEntity.getUid();
                    long startTime = userRunEntity.getStartTime();
                    //上传成功后更新跑步记录同步状态
                    SportRecordsHelper.updateSportRecordSyncState(uid, startTime, 1);
                    if (mHandler != null) {
                        Message message = new Message();
                        message.what = Config.MSG_SYNC_TASK_DONE;
                        message.arg1 = addRunRecord.getCode();
                        message.obj = startTime;
                        mHandler.sendMessage(message);
                    }
                }
            }
        } else {//同步失败
            if (mHandler != null) {
                Message message = new Message();
                message.what = Config.MSG_SYNC_TASK_DONE;
                message.arg1 = addRunRecord.getCode();
                mHandler.sendMessage(message);
            }
        }
    }

    /**
     * 记录上传后,进一步的金币任务处理
     */
    private void handleCoinTask(AddRunRecord addRunRecord) {
        if (addRunRecord == null) {
            Logger.e(Logger.DEBUG_TAG, "handleCoinTask-->addRunRecord is null");
            return;
        }

        UserRunStatistics userRunStatistics = addRunRecord.getUserRunStatistics();
        AddRunRecord.UserRunEntity userRunEntity = addRunRecord.getUserRun();
        //1.用户是否升级
        int levelUp = addRunRecord.getLevelUp();
        Logger.i(Logger.DEBUG_TAG, "syncRunRecordTask-->handleCoinTask levelUp:" + levelUp);
        if (levelUp == 1 && userRunStatistics != null) {

            //升级成功了,更改数据库个人信息
            int userInfoRequestId = BaseActivity.getUserInfoRequestIdByLoginType();
            DataReqStatusHelper.getInstance().setDataReqStatusCacheUseless(userInfoRequestId);

            //更新用户等级相关
            final int prevLevel = SettingsHelper.getInt(Config.SETTING_USER_LEVEL, 0);
            final int level = userRunStatistics.getUserLevel();
            if (level > prevLevel) {
                SettingsHelper.putInt(Config.SETTING_USER_LEVEL, level);//更新用户当前等级
            }

            //计算升级奖励金币
            List<CoinReward> coinRewards = addRunRecord.getAccountFlowList();
            if (coinRewards != null && coinRewards.size() > 0) {
                int coin = 0;
                String taskDescription = null;
                for (CoinReward coinReward : coinRewards) {//金币加总,等级以最高的为准
                    if (coinReward != null) {
                        coin += coinReward.getCoin();
                        taskDescription = coinReward.getDescription();
                    }
                }

                if (coin > 0 && taskDescription != null) {
                    final int coinSum = coin;
                    final String taskName = taskDescription;
                    ThreadManager.getMainHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            //发广播
                            LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
                            Intent intent = new Intent();
                            intent.putExtra("flag", 1);//广播类型,1:用户等级升级金币,2:每日三公里金币
                            intent.putExtra("coin", coinSum);
                            intent.putExtra("taskName", taskName);
                            intent.putExtra("prevLevel", prevLevel);
                            intent.putExtra("level", level);

                            intent.setAction(Config.COIN_TASK_RUN_RECORD_BROADCAST);
                            lbm.sendBroadcast(intent);
                        }
                    });
                }
            }
        }

        //2.每日三公里任务是否完成
        if (userRunEntity != null) {
            int distance = userRunEntity.getDistance();
            long lastThreeMileTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_THREE_MILE, 0);
            Logger.i(Logger.DEBUG_TAG, "syncRunRecordTask-->handleCoinTask three mile,distance:" + distance + ",lastThreeMileTime:" + lastThreeMileTime + ",runId:" + userRunEntity.getId());
            if (!FitmixUtil.isToday(lastThreeMileTime)) {//今日还未完成过三公里
                if (distance > 3000) {//3公里
                    //3.网络请求完成每日三公里金币任务
                    String url = Config.API_HOST + Config.API_PORT + "/task/task-finish.json?";
                    FormBody body = ApiConstants.finishTask(userRunEntity.getUid(),
                            Config.COIN_TASK_TYPE_EVERYDAY, Config.COIN_TASK_THREE_MILE_KEY, String.valueOf(userRunEntity.getId()));//测试数据 uid:27,id:1437197
                    BaseProcessor baseProcessor = new BaseProcessor();
                    String result = baseProcessor.postRequestBodyToApi(url, body);
                    Logger.i(Logger.DEBUG_TAG, "syncRunRecordTask-->three mile coin task result:" + result);
                    //4.处理网络请求结果
                    FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                    if (finishTask != null) {
                        if (finishTask.getCode() == 0) {//任务成功
                            FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                            if (accountFlowEntity != null) {
                                final int coin = accountFlowEntity.getCoin();
                                final String taskName = accountFlowEntity.getDescription();
                                if (coin > 0 && taskName != null) {
                                    ThreadManager.getMainHandler().post(new Runnable() {
                                        @Override
                                        public void run() {
                                            //发广播
                                            LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
                                            Intent intent = new Intent();
                                            intent.putExtra("flag", 2);//广播类型,1:用户等级升级金币,2:每日三公里金币
                                            intent.putExtra("coin", coin);
                                            intent.putExtra("taskName", taskName);
                                            intent.setAction(Config.COIN_TASK_RUN_RECORD_BROADCAST);
                                            lbm.sendBroadcast(intent);
                                        }
                                    });

                                    SettingsHelper.putLong(Config.SETTING_COIN_TASK_THREE_MILE, System.currentTimeMillis());//设置完成任务时间
                                }
                            }
                        }
                    }

                }
            }
        }

    }

}
