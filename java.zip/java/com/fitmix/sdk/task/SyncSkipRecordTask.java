package com.fitmix.sdk.task;

import android.content.Context;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.bean.AddSkipRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.process.BaseProcessor;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * 同步跳绳记录的任务,不需要与UI交互,在{@link com.fitmix.sdk.common.ThreadManager#NETWORK_EXECUTOR 中执行}
 */
public class SyncSkipRecordTask implements Runnable {

    private WeakReference<Context> mContext;
    private SkipLogInfo mSkipLogInfo;

    public SyncSkipRecordTask(Context context, SkipLogInfo skipLogInfo) {
        mContext = new WeakReference<>(context);
        mSkipLogInfo = skipLogInfo;
    }

    @Override
    public void run() {
        if (mSkipLogInfo != null) {
            saveSkipLogInNet(mSkipLogInfo);
        }
    }

    /**
     * 保存运动记录到后台服务器
     */
    private void saveSkipLogInNet(SkipLogInfo skipLogInfo) {
        if (skipLogInfo == null) return;
        String skipFileName = Config.PATH_DOWN_SKIP + skipLogInfo.getUid() + "_" + skipLogInfo.getStartTime() + ".skip";
        String heartFileName = Config.PATH_DOWN_SKIP + skipLogInfo.getUid() + "_" + skipLogInfo.getStartTime() + ".heart";
        //以下代码与SportDataProcessor一致
        int uid = skipLogInfo.getUid();
        int bpm = skipLogInfo.getBpm();
        int bpmMatch = skipLogInfo.getBpmMatch();
        int skipNumber = skipLogInfo.getSkipNumber();
        long calorie = (long) skipLogInfo.getCalorie();
        long skipTime = skipLogInfo.getSkipTime();
        long startTime = skipLogInfo.getStartTime();
        long endTime = skipLogInfo.getEndTime();
        String heartRateData = skipLogInfo.getHeartRateDate();
        int type = 2;

        //2.获取要上传的文件列表和标签
        boolean ignore4003Error = false;//是否忽略服务器返回的4003(计步文件没上传)错误
        List<String> fileNames = new ArrayList<>();
        List<String> fileTagList = new ArrayList<>();
        if (!TextUtils.isEmpty(skipFileName)) {
            if (FileUtils.isFileExist(skipFileName)) {
                fileNames.add(skipFileName);
                fileTagList.add("file");
            }
        }
        if (!TextUtils.isEmpty(heartFileName)) {
            if (FileUtils.isFileExist(heartFileName)) {
                fileNames.add(heartFileName);
                fileTagList.add("heartRateFile");
            } else {
                ignore4003Error = true;
            }
        } else {
            ignore4003Error = true;
        }
        // 3.网络请求
        String url = ApiConstants.addSkipSportRecordWithHeartRate(uid, bpm, skipTime, startTime, endTime, type, bpmMatch, skipNumber, calorie, heartRateData);
        BaseProcessor baseProcessor = new BaseProcessor();
        String result = baseProcessor.uploadDataToServer(url, fileNames, fileTagList);
        Logger.i(Logger.DEBUG_TAG, "SyncSkipRecordTask-->saveSkipLogInNet uid:" + uid + ",runId:" + startTime +
                "\nresult:" + result);
        // 4.处理网络请求结果
        AddSkipRecord addSkipRecord = JsonHelper.getObject(result, AddSkipRecord.class);
        handleUploadRecord(addSkipRecord, ignore4003Error);
    }

    /**
     * 处理上传跑步记录回调
     */
    private void handleUploadRecord(AddSkipRecord addSkipRecord, boolean ignore4003Error) {
        if (addSkipRecord == null) {
            return;
        }
        AddSkipRecord.UserSkipRopeBean skipRopeBean = addSkipRecord.getUserSkipRope();
        if (addSkipRecord.getCode() == 0) {//上传成功后
            if (skipRopeBean != null) {
                int uid = skipRopeBean.getUid();
                long startTime = skipRopeBean.getStartTime();
                String skipDataPath = skipRopeBean.getSkipDetail();
                //上传成功后更新跑步记录同步状态
                SportRecordsHelper.updateSkipSportRecordSyncState(uid, startTime, skipDataPath, 1);
            }
        } else if (addSkipRecord.getCode() == 4003) {
            if (ignore4003Error) {
                if (skipRopeBean != null) {
                    int uid = skipRopeBean.getUid();
                    long startTime = skipRopeBean.getStartTime();
                    String skipDataPath = skipRopeBean.getSkipDetail();
                    //上传成功后更新跑步记录同步状态
                    SportRecordsHelper.updateSkipSportRecordSyncState(uid, startTime, skipDataPath, 1);
                }
            }
        }
    }

}
