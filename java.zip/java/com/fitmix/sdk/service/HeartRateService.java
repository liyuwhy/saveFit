package com.fitmix.sdk.service;

import android.annotation.SuppressLint;
import android.app.Service;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.ParcelUuid;
import android.os.PowerManager;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ServiceAliveHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.ble.HRSManager;
import com.fitmix.sdk.common.bluetooth.ble.HRSManagerCallbacks;
import com.fitmix.sdk.common.bluetooth.scanner.BluetoothLeScannerCompat;
import com.fitmix.sdk.common.bluetooth.scanner.ScanCallback;
import com.fitmix.sdk.common.bluetooth.scanner.ScanFilter;
import com.fitmix.sdk.common.bluetooth.scanner.ScanResult;
import com.fitmix.sdk.common.bluetooth.scanner.ScanSettings;
import com.fitmix.sdk.common.sound.VoiceManager;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.activity.RunMainActivity;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

//import com.squareup.leakcanary.RefWatcher;

/**
 * 心率服务
 */
public class HeartRateService extends Service {

    /**
     * HeartRateService 名称
     */
    public static final String SERVICE_NAME = HeartRateService.class.getName();
    private HRSManager hrsManager;

    /**
     * 判断有没连接心率设备的依据 当断开设备时onDeviceDisconnected()或者onError()时设为null
     */
    private BluetoothDevice device;
    private boolean ifDisConnectByMan;//是否人为断开, 有意义的前提是人为点击断开,就一定会进入Service的onDeviceDisconnected()
    private int refreshSignalStrength = -1;//信号强度
    private long refreshTime = -1;

    /**
     * 跑步过程中保存的运动开始时间
     */
    private long mRunStartTime = -1;

    /**
     * 当前最新心率值
     */
    private int latestHeartRate;

    /**
     * 上一次运动是否正常结束,只有用户明确结束运动才算正常
     */
    private boolean lastRunFinished;

//    /**
//     * 当前心率所属于五大区间和两个特殊数值的哪个,6、5、4、3、2、1、0分别代表达到最大限、最大、无氧、有氧、燃脂、热身、燃脂与热身的交界处
//     */
//    private int nowLevel = -1;

    /**
     * 最大摄氧量,单位ml/kg/min
     */
    private float theMaxVo2;

    //发送给心率耳机的用户个人信息相关参数,
    private int age = -1;//单位为月
    private int gender = -1;//0：女,1：男,默认：1（男）
    private int weight = -1;//默认：816（81.6kg）,单位:0.1kg
    private int height = -1;//180（180cm）,单位:cm
    private int sportMode = -1;//0：autonomous mode,1：Running,2：Low HR,3：Cycling,4：Weights & Sports,5：Aerobics,6：Lifestyle,默认：1（Running）

    /**
     * 语音管理器,负责语音播报
     */
    private VoiceManager voiceManager;
    /**
     * 语音播报语调,int型,0:男声,1:女声
     */
    private int toneType = -1;

    private int lastFreeModeHrZone = 0;//自由模式中上个教练区间名称

    private boolean isNotFirstInHotMode = false;//不是第一次进入热身区间  默认 false
    private boolean isNotFirstInFatMode = false;//不是第一次进入燃脂区间  默认 false
    private boolean isNotFirstInHeartLungMode = false;//不是第一次进入强化心肺区间  默认 false
    private boolean isNotFirstInBodyMode = false;//不是第一次进入强化机能区间  默认 false
    private boolean isNotFirstInSuperMode = false;//不是第一次进入极限强度区间  默认 false

    private int lowZoneTime;//心率值低于区间下限时间,每次进来,从0计,单位为秒
    private int inZoneTime;//心率值位于区间范围时间,每次进来,从0计,单位为秒
    private int upZoneTime;//心率值高于于区间上限时间,每次进来,从0计,单位为秒
    private int superZoneTime;//心率值高于极限值时间,每次进来,从0计,单位为秒

    private int inCoachModeAllTime;//在教练模式区间内的持续总时间,单位为秒

    /**
     * 获取VoiceManager
     */
    public VoiceManager getVoiceManager() {
        if (voiceManager == null)
            voiceManager = new VoiceManager();
        return voiceManager;
    }

    /**
     * 获取语音播报语调,int型,0:男声,1:女声
     *
     * @return 语音播报语调, int型, 0:男声,1:女声
     */
    public int getToneType() {
        if (toneType == -1) {
            toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        }
        return toneType;
    }

    /**
     * 获取上一次运动是否正常完成
     *
     * @return true:完成,false:未完成
     */
    private boolean isLastRunFinished() {
        //如果上一次运动未正常结束,从SharedPreferences确认上一次运动完成状态
        if (!lastRunFinished) {
            long saveTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_LAST_RUN_SAVE_TIME, 0);
            if (saveTime == 0) {//APP第一次运动时,直接算上一次运动是完成的
                lastRunFinished = true;
            } else {
                lastRunFinished = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_LAST_RUN_FINISHED, true);
            }
        }
        return lastRunFinished;
    }

    /**
     * 获取刷新时间,使得数据库存储时间戳与界面上增加的点的时间戳相吻合
     **/
    public long getRefreshTime() {
        return refreshTime;
    }

    public void setRefreshTime(long refreshTime) {
        this.refreshTime = refreshTime;
    }

    /**
     * 获取最近一次的心率值
     */
    public int getLatestHeartRate() {
        return latestHeartRate;
    }

    /**
     * 获取最大摄氧量,单位ml/kg/min
     */
    public float getTheMaxVo2() {
        return theMaxVo2;
    }

    //region ================================== 服务的接口回调 ==================================

    /**
     * 心率事件回调
     */
    public interface HeartRateServiceFunction {
        /**
         * 蓝牙设置已连接
         */
        void onDeviceConnected();

        /**
         * 蓝牙设置已断开
         */
        void onDeviceDisconnected();

        void onError();

        /**
         * 接收到心率数值
         */
        void onHRValueReceived();

        /**
         * 接收到的心率设备固件版本值
         */
        void onFirmwareVersionReceive(String firmwareVersion);

        /**
         * 接收到心率设备信号值
         *
         * @param deviceOff   是否脱落
         * @param signalValue 信号强度
         */
        void onSignalValueReceived(boolean deviceOff, int signalValue);

        void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list);

        /**
         * 更新心率图表
         */
        void reDrawHeartRateData();

        /**
         * 播报心率语音
         *
         * @param latestHeartRate           当前心率值
         * @param restHeartRate             静息心率值
         * @param inCoachModeAllTime        在教练模式区间内的持续总时间,单位为秒
         * @param lowZoneTime               心率值低于区间下限时间,每次进来,从0计,单位为秒
         * @param inZoneTime                心率值位于区间范围时间,每次进来,从0计,单位为秒
         * @param upZoneTime                心率值高于于区间上限时间,每次进来,从0计,单位为秒
         * @param superZoneTime             心率值高于极限值时间,每次进来,从0计,单位为秒
         * @param isNotFirstInHotMode
         * @param isNotFirstInFatMode
         * @param isNotFirstInHeartLungMode
         * @param isNotFirstInBodyMode
         * @param isNotFirstInSuperMode
         */
        void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                       int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                       boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode);
    }

    /**
     * 心率事件回调集合
     */
    private HashMap<String, HeartRateServiceFunction> mServiceFunctionHashMap;

    /**
     * 解绑指定键值的心率事件回调
     *
     * @param key 键值
     */
    public void removeHeartRateItem(String key) {
        if (mServiceFunctionHashMap != null && key != null) {
            mServiceFunctionHashMap.remove(key);
        }
    }

    /**
     * 添加心率事件回调监听
     *
     * @param key                      心率事件回调监听键值
     * @param heartRateServiceFunction 心率事件回调监听
     */
    public void addHeartRateServiceFunction(String key, HeartRateServiceFunction heartRateServiceFunction) {
        if (mServiceFunctionHashMap == null) {
            mServiceFunctionHashMap = new HashMap<>();
        }

        if (key != null && heartRateServiceFunction != null) {
            mServiceFunctionHashMap.put(key, heartRateServiceFunction);
        }
    }

    //endregion ================================== 服务的接口回调 ==================================

    //region ================================== 每秒刷新 ==================================

    private boolean ifBindWithRunMain;//是否跟跑步界面绑定,1.只有跑步界面才需要每秒刷新功能,2.在跑步界面时一键启动失效

    /**
     * 设置心率服务是否与跑步界面绑定
     *
     * @param ifBindWithRunMain true:绑定,false:未绑定
     */
    public void setIfBindWithRunMain(boolean ifBindWithRunMain) {
        this.ifBindWithRunMain = ifBindWithRunMain;
    }

    /**
     * 自定义handler
     */
    protected static class MyHandler extends WeakHandler {
        public MyHandler(Service heartRateService) {
            super(heartRateService);
        }

        public void handleMessage(Message msg) {
            HeartRateService service = (HeartRateService) getReference();
            if (service == null)
                return;
            switch (msg.what) {
                case Config.MSG_REPEAT_EVERY_SECOND://每秒刷新一次运动数据
                    service.refresh();
                    sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                            1000);
                    break;
            }
        }
    }

    private MyHandler myHandler;

    /**
     * 获取Handler,保证不为null
     */
    private MyHandler getMyHandler() {
        if (myHandler == null) {
            myHandler = new MyHandler(this);
        }
        return myHandler;
    }

    /**
     * 数据刷新操作
     */
    public void refresh() {
        if (!ifBindWithRunMain) {
            return;
        }
        //0.根据心率所属区间,播报语音
        if (latestHeartRate != 0) {
            int restHeartRate = latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR;

            int custom_min = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MIM_VALUE, 130);
            int custom_max = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MAX_VALUE, 170);

            int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
            age = age > 0 ? age : Config.USER_DEFAULT_AGE;//新用户可能存在获取到的SettingsHelper.getInt(Config.SETTING_USER_AGE, 24)为0的情况
            int max = SettingsHelper.getInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age));
            double hr_01 = restHeartRate + 0.5 * (max - restHeartRate);//放松与热身之间的边界值
            double hr_21 = restHeartRate + 0.6 * (max - restHeartRate);//燃脂与热身之间的边界值
            double hr_32 = restHeartRate + 0.7 * (max - restHeartRate);//燃脂与强化心肺之间的边界值
            double hr_43 = restHeartRate + 0.8 * (max - restHeartRate);//强化心肺与强化机能之间的边界值
            double hr_54 = restHeartRate + 0.9 * (max - restHeartRate);//极限与强化机能之间的边界值


           /* int max = 130;
            double hr_01 = 20;//放松与热身之间的边界值
            int hr_21 = 40;
            int hr_32 = 60;
            int hr_43 = 80;
            int hr_54 = 100;*/

            //  Logger.e(Logger.DEBUG_TAG,"calHRLelAndCount heartRate:"+heartRate+" restHeartRate:"+restHeartRate);
//            int level = FitmixUtil.getHeartRateLevelAndSpecialNum(latestHeartRate, restHeartRate);
            int coachMode = SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7);
            Logger.d(Logger.DEBUG_TAG, "coachMode:" + coachMode);
            //  Logger.e(Logger.DEBUG_TAG,"calHRLelAndCount level:"+level+" nowLevel:"+nowLevel);

            switch (coachMode) {
                case 7://自由模式

                    if (latestHeartRate >= hr_54 && latestHeartRate < max) {//极限强度 5

                        if (lastFreeModeHrZone != 5) {
                            lastFreeModeHrZone = 5;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        if (inZoneTime >= 10) {
                            isNotFirstInSuperMode = true;
                        }
                        superZoneTime = 0;

                    } else if (latestHeartRate >= hr_43 && latestHeartRate < hr_54) {//强化机能 4

                        if (lastFreeModeHrZone != 4) {
                            lastFreeModeHrZone = 4;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        if (inZoneTime >= 10) {
                            isNotFirstInBodyMode = true;
                        }


                    } else if (latestHeartRate >= hr_32 && latestHeartRate < hr_43) {//强化心肺 3

                        if (lastFreeModeHrZone != 3) {
                            lastFreeModeHrZone = 3;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        if (inZoneTime >= 10) {
                            isNotFirstInHeartLungMode = true;
                        }

                    } else if (latestHeartRate >= hr_21 && latestHeartRate < hr_32) {//燃脂训练 2

                        if (lastFreeModeHrZone != 2) {
                            lastFreeModeHrZone = 2;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        if (inZoneTime >= 10) {
                            isNotFirstInFatMode = true;
                        }

                    } else if (latestHeartRate >= hr_01 && latestHeartRate < hr_21) {//热身训练 1

                        if (lastFreeModeHrZone != 1) {
                            lastFreeModeHrZone = 1;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        if (inZoneTime >= 10) {
                            isNotFirstInHotMode = true;
                        }

                    } else if (latestHeartRate < hr_01 && latestHeartRate > 0) { //低于hr_01  7
                        if (lastFreeModeHrZone != 7) {
                            lastFreeModeHrZone = 7;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }


                    } else if (latestHeartRate > max) {

                        if (lastFreeModeHrZone != 6) {
                            lastFreeModeHrZone = 6;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        superZoneTime++;

                    }
                    inCoachModeAllTime++;
//                    nowLevelTime++;
                    break;
                case 6://自定义模式
                    if (latestHeartRate >= custom_min && latestHeartRate <= custom_max) {
                        if (lastFreeModeHrZone != 6) {
                            lastFreeModeHrZone = 6;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        inCoachModeAllTime++;

                        lowZoneTime = 0;
                        upZoneTime = 0;
                        superZoneTime = 0;

                    } else if (latestHeartRate < custom_min - 5) {
                        lowZoneTime++;
                        upZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate > custom_max + 5 && latestHeartRate < max) {
                        upZoneTime++;
                        lowZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate >= max) {
                        superZoneTime++;
                        lowZoneTime = 0;
                        upZoneTime = 0;
                    }
//                    nowLevelTime++;
                    break;
                case 5://极限强度
                    if (latestHeartRate >= hr_54 && latestHeartRate < max) {
                        if (lastFreeModeHrZone != 5) {
                            lastFreeModeHrZone = 5;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        inCoachModeAllTime++;

                        lowZoneTime = 0;
                        upZoneTime = 0;
                        superZoneTime = 0;

                        if (inZoneTime >= 10) {
                            isNotFirstInSuperMode = true;
                        }
                    } else if (latestHeartRate > hr_01 && latestHeartRate < hr_54 - 5) {
                        lowZoneTime++;
                        upZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate > max) {
                        superZoneTime++;
                        lowZoneTime = 0;
                        upZoneTime = 0;
                        inZoneTime = 0;
                    }
//                    nowLevelTime++;
                    break;
                case 4://强化机能
                    if (latestHeartRate >= hr_43 && latestHeartRate < hr_54) {
                        if (lastFreeModeHrZone != 4) {
                            lastFreeModeHrZone = 4;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        inCoachModeAllTime++;

                        lowZoneTime = 0;
                        upZoneTime = 0;
                        superZoneTime = 0;

                        if (inZoneTime >= 10) {
                            isNotFirstInBodyMode = true;
                        }
                    } else if (latestHeartRate > hr_01 && latestHeartRate < hr_43 - 5) {
                        lowZoneTime++;
                        upZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate > hr_43 + 5 && latestHeartRate < max) {
                        upZoneTime++;
                        lowZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate >= max) {
                        superZoneTime++;
                        lowZoneTime = 0;
                        upZoneTime = 0;
                    }
//                    nowLevelTime++;
                    break;
                case 3://强化心肺
                    if (latestHeartRate >= hr_32 && latestHeartRate < hr_43) {
                        if (lastFreeModeHrZone != 3) {
                            lastFreeModeHrZone = 3;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        inCoachModeAllTime++;

                        lowZoneTime = 0;
                        upZoneTime = 0;
                        superZoneTime = 0;

                        if (inZoneTime >= 10) {
                            isNotFirstInHeartLungMode = true;
                        }

                    } else if (latestHeartRate > hr_01 && latestHeartRate < hr_32 - 5) {
                        lowZoneTime++;
                        upZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate > hr_43 + 5 && latestHeartRate < max) {
                        upZoneTime++;
                        lowZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate >= max) {
                        superZoneTime++;
                        lowZoneTime = 0;
                        upZoneTime = 0;
                    }
//                    nowLevelTime++;
                    break;
                case 2://燃脂训练
                    if (latestHeartRate >= hr_21 && latestHeartRate < hr_32) {
                        if (lastFreeModeHrZone != 2) {
                            lastFreeModeHrZone = 2;
                            inZoneTime = 0;
                            inZoneTime++;
                        } else {
                            inZoneTime++;
                        }
                        inCoachModeAllTime++;

                        lowZoneTime = 0;
                        upZoneTime = 0;
                        superZoneTime = 0;

                        if (inZoneTime >= 10) {
                            isNotFirstInFatMode = true;
                        }
                    } else if (latestHeartRate > hr_01 && latestHeartRate < hr_21 - 5) {
                        lowZoneTime++;
                        upZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate > hr_32 + 5 && latestHeartRate < max) {
                        upZoneTime++;
                        lowZoneTime = 0;
                        superZoneTime = 0;
                        inZoneTime = 0;
                    } else if (latestHeartRate >= max) {
                        superZoneTime++;
                        lowZoneTime = 0;
                        upZoneTime = 0;
                    }
//                    nowLevelTime++;
                    break;
            }

            calHRLelAndCount(latestHeartRate, restHeartRate, inCoachModeAllTime, lowZoneTime, inZoneTime, upZoneTime, superZoneTime,
                    isNotFirstInHotMode, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode);
        }
        //1.数据库存储
        if (refreshTime == -1) {//第一个点必须要写进数据库
            refreshTime = System.currentTimeMillis();
            writeHeartRateToDb(refreshTime);
        } else {//其余点根据心率值选择是否写进数据库
            refreshTime += 1000;//默认增加一秒
            if (getLatestHeartRate() != 0) {
                writeHeartRateToDb(refreshTime);
            }
        }
        //2.画图刷新
        if (mServiceFunctionHashMap != null) {
            for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                serviceFunction.reDrawHeartRateData();
            }
        }
        //3.数据统计
        addHeartRateAreaNum(latestHeartRate, latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR);
    }

    /**
     * 心率数值所属六大区间的判断,静息语音播报数据相关统计
     *
     * @param isNotFirstInHotMode       = false;//不是第一次进入热身区间  默认 false
     * @param isNotFirstInFatMode       = false;//不是第一次进入燃脂区间  默认 false
     * @param isNotFirstInHeartLungMode = false;//不是第一次进入强化心肺区间  默认 false
     * @param isNotFirstInBodyMode      = false;//不是第一次进入强化机能区间  默认 false
     * @param isNotFirstInSuperMode     = false;//不是第一次进入极限强度区间  默认 false
     * @param lowZoneTime               心率值低于区间下限时间,每次进来,从0计
     * @param inZoneTime                心率值位于区间范围时间,每次进来,从0计
     * @param upZoneTime                心率值高于于区间上限时间,每次进来,从0计
     * @param superZoneTime             心率值高于极限值时间,每次进来,从0计
     * @param inCoachModeAllTime        在教练模式区间内的持续总时间
     */
    private void calHRLelAndCount(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                                  int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                                  boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {
        if (mServiceFunctionHashMap != null) {
            for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                serviceFunction.playVoice(latestHeartRate, restHeartRate, inCoachModeAllTime, lowZoneTime, inZoneTime, upZoneTime, superZoneTime,
                        isNotFirstInHotMode, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode);
            }
        }
    }

    /**
     * 写入心率数据库表中
     *
     * @param writeTime 写入时间戳
     */
    private void writeHeartRateToDb(long writeTime) {
//        Logger.e(Logger.DEBUG_TAG, "HeartRateService-->writeHeartRateToDb writeTime:" + writeTime + ",getRunStartTime:" + getRunStartTime());
        com.fitmix.sdk.model.database.HeartRateInfo heartRateInfo = new com.fitmix.sdk.model.database.HeartRateInfo();
        heartRateInfo.setUid(UserDataManager.getUid());
        heartRateInfo.setRunId(getRunStartTime());
        heartRateInfo.setHeartRate(getLatestHeartRate());
        heartRateInfo.setTime(writeTime);
        SportRecordsHelper.writeHeartRateInfo(this, heartRateInfo);
    }

    /**
     * 获取跑步过程中保存的开始运动时间
     */
    public long getRunStartTime() {
        if (mRunStartTime < 0) {
            mRunStartTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_START_TIME);
        }
        return mRunStartTime;
    }

    //region ================================== 开启每秒刷新功能 ==================================

    /**
     * 开始运动(开始画心率图)
     */
    public void startExercise() {
        if (isLastRunFinished()) {//上一次运动正常结束或者启动新的运动记录
            //新的运动需要删除数据库中存储的之前心率数据
            SportRecordsHelper.deleteHeartRateInfo(this);
            getMyHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                    1000);
        } else {//恢复上次运动
            searchHeartRateListHistory();
            getMyHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                    1000);
        }

        //获取CPU锁、开始Service保护并注册屏幕熄屏事件
        startCPULock();
        startKeepAlive();

    }

    /**
     * 搜索同一运动开始时间的记录。回调将记录集传给activity
     */
    public void searchHeartRateListHistory() {
        SportRecordsHelper.asyncGetAllHeartRateInfo(this, UserDataManager.getUid(), getRunStartTime(), new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                try {
                    List<com.fitmix.sdk.model.database.HeartRateInfo> heartRateInfoList = (List<com.fitmix.sdk.model.database.HeartRateInfo>) operation.getResult();
                    List<HeartRateChartInfo> heartRateChartInfoList = new ArrayList<>();
                    for (int i = 0; i < heartRateInfoList.size(); i++) {
                        com.fitmix.sdk.model.database.HeartRateInfo info = heartRateInfoList.get(i);
                        if (info == null) {
                            continue;
                        }
                        heartRateChartInfoList.add(new HeartRateChartInfo(info.getHeartRate(), info.getTime()));
                        //数据统计
                        addHeartRateAreaNum(info.getHeartRate(), latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR);
                    }
                    if (ifBindWithRunMain) {
                        if (mServiceFunctionHashMap != null) {
                            for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                                serviceFunction.onHeartRateHistoryRecovery(heartRateChartInfoList);
                            }
                        }
                    }
                } catch (Exception e) {
                    Logger.i(Logger.DEBUG_TAG, e.getMessage());
                }
            }
        });
    }

    /**
     * 结束运动（不画心率图）
     */
    public void stopExercise() {
        //1.关闭每秒刷新运动数据
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        //2.释放CPU锁、停止Service保护并注销监听屏幕亮熄屏事件
        releaseCPULock();
        stopKeepAlive();

        mRunStartTime = -1;//清空运动开始时间
        refreshTime = -1;
    }

    /**
     * 暂停运动
     */
    public void pauseExercise() {
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
    }

    /**
     * 运动继续
     */
    public void continueExercise() {
        getMyHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                1000);
    }

    //endregion ================================== 开启每秒刷新功能 ==================================

    //endregion ================================== 每秒刷新 ==================================

    //region ================================== 数据统计相关 ==================================

    //五大阶段数量
    private int AerobicNum;//有氧区间
    private int AnaerobicNum;//无氧区间
    private int FatBurningNum;//燃脂区间
    private int MaxNum;//最大区间
    private int WarmNum;//热身区间

    private int maxHeartRate;//最大心率
    private int minHeartRate;//最小心率
    private int sumHeartRate;//有效的心率值的总和（过滤掉0的）
    private int heartRateSize;//有效的心率点数（过滤掉0的）
    /**
     * 最近一次的静息心率记录
     */
    private int latestRestHeartRate;

    /**
     * 获取有氧区间数量
     */
    public int getAerobicNum() {
        return AerobicNum;
    }

    /**
     * 获取无氧区间数量
     */
    public int getAnaerobicNum() {
        return AnaerobicNum;
    }

    /**
     * 获取燃脂区间数量
     */
    public int getFatBurningNum() {
        return FatBurningNum;
    }

    /**
     * 获取最大区间数量
     */
    public int getMaxNum() {
        return MaxNum;
    }

    /**
     * 获取热身区间数量
     */
    public int getWarmNum() {
        return WarmNum;
    }

    /**
     * 获取最大心率值
     */
    public int getMaxHeartRate() {
        return maxHeartRate;
    }

    /**
     * 获取最小心率值
     */
    public int getMinHeartRate() {
        return minHeartRate;
    }

    /**
     * 获取有效的心率值的总和(过滤掉0)
     */
    public int getSumHeartRate() {
        return sumHeartRate;
    }

    /**
     * 获取有效的心率点数(过滤掉0)
     */
    public int getHeartRateSize() {
        return heartRateSize;
    }

    /**
     * 设置最近一次静息心率值
     *
     * @param latestRestHeartRate 最近一次静息心率值
     */
    public void setLatestRestHeartRate(int latestRestHeartRate) {
        this.latestRestHeartRate = latestRestHeartRate;
    }

    /**
     * 获取最近一次静息心率值
     */
    public int getLatestRestHeartRate() {
        return latestRestHeartRate;
    }

    public int getCurrentZoneTime() {
        return inCoachModeAllTime;
    }

    public void setCurrentZoneTime(int inCoachModeAllTime) {
        this.inCoachModeAllTime = inCoachModeAllTime;
    }

    /**
     * 根据心率更改五个区域中的数量
     */
    private void addHeartRateAreaNum(int heartRate, int restHeartRate) {
        if (heartRate == 0) {//过滤掉心率为0的情况
            return;
        }
        //更改最大心率数值
        if (heartRate > maxHeartRate) {
            maxHeartRate = heartRate;
        }

        if (minHeartRate == 0 || heartRate < minHeartRate) {
            minHeartRate = heartRate;
        }

        if (heartRate != 0) {//过滤掉值为0的情况,计算心率平均值
            sumHeartRate += heartRate;
            heartRateSize++;
        }

        int level = FitmixUtil.getHeartRateLevel(heartRate, restHeartRate);
        switch (level) {
            case 5:
                MaxNum++;
                break;
            case 4:
                AnaerobicNum++;
                break;
            case 3:
                AerobicNum++;
                break;
            case 2:
                FatBurningNum++;
                break;
            case 1:
                WarmNum++;
                break;
        }

    }

    /**
     * 释放统计的相关数据
     */
    public void releaseCountData() {
        AerobicNum = 0;
        AnaerobicNum = 0;
        FatBurningNum = 0;
        MaxNum = 0;
        WarmNum = 0;

        maxHeartRate = 0;
        minHeartRate = 0;
        sumHeartRate = 0;
        heartRateSize = 0;

        latestRestHeartRate = 0;

        theMaxVo2 = 0f;

        lowZoneTime = 0;
        upZoneTime = 0;
        superZoneTime = 0;
        inZoneTime = 0;
        inCoachModeAllTime = 0;
        isNotFirstInHeartLungMode = false;
        isNotFirstInSuperMode = false;
        isNotFirstInBodyMode = false;
        isNotFirstInFatMode = false;
        isNotFirstInHotMode = false;

        age = -1;
        gender = -1;
        weight = -1;
        height = -1;
        sportMode = -1;
    }


//    /**
//     * 根据性别、年龄、体重及心率区间所占的时间,得出脂肪燃烧克数,单位：克
//     *
//     * @return
////     */
//    public int getTotalFatBurn(){
//        int gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
//        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, 24);
//        int weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);//单位暂时为千克
//        int sum = 0;
//        if(gender == 1){//男性
//            for(int i = 1;i<=5;i++) {
//                double aa = age *0.2017 + weight * 0.09036 +
//                        (FitmixUtil.getLevelMiddleNum(latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR,i)) * 0.6309
//                        - 55.0969;
//                if(aa > 0 ){
//                    sum += FitmixUtil.getFatBurnFromCal((aa * getHeartRateAreaSecond(i) / 60 / 4.184), i);
//                }
//            }
//        }else{//女性
//            for(int i = 1;i<=5;i++) {
//                double aa = age * 0.0740 + weight * 0.05741 +
//                        (FitmixUtil.getLevelMiddleNum(latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR,i)) * 0.4472
//                        - 20.4022;
//                if(aa > 0 ){
//                    sum += FitmixUtil.getFatBurnFromCal((aa * getHeartRateAreaSecond(i) / 60 / 4.184), i);
//                }
//            }
//        }
//        return sum;
//    }
//
//    /**
//     * 获取指定心率区间存在的时间,单位为秒数
//     * @param level
//     * @return
//     */
//    private int getHeartRateAreaSecond(int level){
//        int num = 0;
//        switch (level){
//            case 1:
//                num = WarmNum;
//                break;
//            case 2:
//                num = FatBurningNum;
//                break;
//            case 3:
//                num = AerobicNum;
//                break;
//            case 4:
//                num = AnaerobicNum;
//                break;
//            case 5:
//                num = MaxNum;
//                break;
//        }
//        return num;
//    }


    //endregion ================================== 数据统计相关 ==================================

    //region ================================== Service生命周期相关 ==================================

    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        public HeartRateService getService() {
            return HeartRateService.this;
        }
    }

    @Override
    public void onCreate() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateService --- > onCreate()");
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            init();
        }
    }

    public void init() {
        /*
         * We use the managers using a singleton pattern. It's not recommended for the Android, because the singleton instance remains after Activity has been
		 * destroyed but it's simple and is used only for this demo purpose. In final application Managers should be created as a non-static objects in
		 * Services. The Service should implement ManagerCallbacks interface. The application Activity may communicate with such Service using binding,
		 * broadcast listeners, local broadcast listeners (see support.v4 library), or messages. See the Proximity profile for Service approach.
		 */
        mServiceFunctionHashMap = new HashMap<>();
        hrsManager = initializeManager();
        getMyHandler();
    }

    protected HRSManager initializeManager() {
        Logger.i(Logger.DEBUG_TAG, "initializeManager()");
        HRSManager manager = new HRSManager(this);
        manager.setGattCallbacks(getDefaultCallBack());
        return manager;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getExtras() == null || device != null) {//如果当前设备已经连了设备,则直接跳过
            return super.onStartCommand(intent, flags, startId);
        }
        //存在一开启心率服务就必须连接蓝牙设备的情况
        Bundle bundle = intent.getExtras();
        BluetoothDevice device = (BluetoothDevice) bundle.get("bleAddress");
        if (device != null) {
            setDevice(device);
            if (getBleManager() != null) {
                getBleManager().disconnect();
                getBleManager().connect(device);
            }
        }
        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

//    @Override
//    public void onLowMemory() {
//        super.onLowMemory();
//        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
//        am.getMemoryInfo(mi);
//    }

    @Override
    public void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateService --- > onDestroy()");
        release();
//        RefWatcher refWatcher = MixApp.getRefWatcher(this);
//        refWatcher.watch(this);
        super.onDestroy();
    }

    /**
     * 释放资源
     */
    public void release() {
        //断开连接
        if (hrsManager != null) {
            hrsManager.disconnect();
            hrsManager.close();
            hrsManager.setGattCallbacks(null);
            hrsManager = null;
        }

        if (voiceManager != null)
            voiceManager.releaseResource();
        voiceManager = null;
        toneType = -1;

        device = null;
        defaultCallBack = null;

        ifBindWithRunMain = false;
        mServiceFunctionHashMap = null;
        refreshTime = -1;
        mRunStartTime = -1;
        latestHeartRate = -1;
//        batteryValue = 0;
        refreshSignalStrength = -1;

        releaseCountData();
        getMyHandler().removeCallbacksAndMessages(null);
        myHandler = null;
    }

    public HRSManager getBleManager() {
        return hrsManager;
    }

    public BluetoothDevice getDevice() {
        return device;
    }

    public void setDevice(BluetoothDevice device) {
        this.device = device;
        if (device == null) {
            ifDisConnectByMan = true;
        }
        if (device != null) {//存储
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS, device.getAddress());
        }
    }

//    public int getBatteryValue() {
//        return batteryValue;
//    }

    public int getRefreshSignalStrength() {
        return refreshSignalStrength;
    }


    //endregion ================================== Service生命周期相关 ==================================

    //endregion ================================== 重连操作 ==================================

    private boolean ifReconnectSearching = false;
    private final static long SCAN_DURATION = 3000;
    private String lastConnectedAddress;

    private void stopScan() {
        if (ifReconnectSearching) {
            final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
            scanner.stopScan(scanCallback);
            ifReconnectSearching = false;
        }
    }

    @SuppressLint("NewApi")
    private ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult result : results) {
                if (result.getDevice() == null || TextUtils.isEmpty(result.getDevice().getAddress())) {
                    continue;
                }
                if (lastConnectedAddress.equals(result.getDevice().getAddress())) {
                    //进行重连
                    ifReconnectSearching = false;
                    if (result.getDevice() != null) {
                        setDevice(result.getDevice());
                        if (getBleManager() != null) {
                            getBleManager().disconnect();
                            getBleManager().connect(result.getDevice());
                        }
                    }
                    break;
                }
            }
            super.onBatchScanResults(results);
        }
    };

    /**
     * 当执行onDeviceDisconnected()方法并非人为时,执行重连操作
     */
    private void autoReconnectDevice() {
        Logger.i(Logger.DEBUG_TAG, "autoReconnectDevice(),进行重连");
        String bluetoothAddress = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS, "");
        if (TextUtils.isEmpty(bluetoothAddress))
            return;
        lastConnectedAddress = bluetoothAddress;
        if (!FitmixUtil.isBLEEnabled(HeartRateService.this)) {
            return;
        }

        if (lastConnectedAddress != null) {
            lastConnectedAddress = lastConnectedAddress.toUpperCase();
        }

        final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        final ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(1000).setUseHardwareBatchingIfSupported(false).build();
        final List<ScanFilter> filters = new ArrayList<>();
        filters.add(new ScanFilter.Builder().setDeviceAddress(lastConnectedAddress).setServiceUuid(new ParcelUuid(HRSManager.HR_SERVICE_UUID)).build());
        try {
            scanner.startScan(filters, settings, scanCallback);
        } catch (Exception ex) {
            //不处理
        }
        ifReconnectSearching = true;
        getMyHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                stopScan();
            }
        }, SCAN_DURATION);
    }


    //endregion ================================== 重连操作 ==================================

    //region ##################### HRSManagerCallbacks的相关回调 #####################
    /**
     * 默认的回调,当不在心率的相关activity时,使得心率断开时销毁该HeartRateService
     */
    HRSManagerCallbacks defaultCallBack = new HRSManagerCallbacks() {
        @Override
        public void onHRSensorPositionFound(String position) {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService--> onHRSensorPositionFound");
        }

        @Override
        public void onHRValueReceived(int value) {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService--> onHRValueReceived:" + value);
            latestHeartRate = value;
            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onHRValueReceived();
                }
            }
        }

        @Override
        public void onDeviceConnected() {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService--> onDeviceConnected");
            sendSendUserDataCmd();//一连接就发送设置用户信息命令。
            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onDeviceConnected();
                }
            }
        }

        @Override
        public void onDeviceDisconnecting() {
            //不处理
        }

        @Override
        public void onDeviceDisconnected() {
//            Logger.i(Logger.DEBUG_TAG, "HeartRateService--> onDeviceDisconnected,#heartRateServiceFunction.size()--->"+heartRateServiceFunction.size());
            device = null;
            latestHeartRate = 0;

            refreshSignalStrength = -1;

            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onDeviceDisconnected();
                }

                if (ifDisConnectByMan) {//重连
                    autoReconnectDevice();
                    ifDisConnectByMan = false;
                } else {
                    if (mServiceFunctionHashMap.size() == 0) {
                        Logger.e(Logger.DEBUG_TAG, "HeartRateService--> onDeviceDisconnected stopSelf");
                        stopSelf();
                    }
                }
            } else {//注意,当没与任何activity绑定时,自己销毁
                Logger.e(Logger.DEBUG_TAG, "HeartRateService--> onDeviceDisconnected stopSelf");
                stopSelf();
            }
        }

        @Override
        public void onLinkLossOccur() {
            Logger.e(Logger.DEBUG_TAG, "HeartRateService--> onLinkLossOccur");
        }

        @Override
        public void onServicesDiscovered(boolean optionalServicesFound) {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onServicesDiscovered optionalServicesFound:" + optionalServicesFound);
        }

        @Override
        public void onDeviceReady() {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onDeviceReady");
        }

        @Override
        public void onBondingRequired() {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onBondingRequired");
        }

        @Override
        public void onBonded() {
            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onBonded");
        }

        @Override
        public void onError(String message, int errorCode) {
            Logger.e(Logger.DEBUG_TAG, "HeartRateService onError--> message:" + message + ",errorCode:" + errorCode);
            autoReconnectDevice();

            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onError();
                }
            }
        }

        @Override
        public void onDeviceNotSupported() {
//            Logger.i(Logger.DEBUG_TAG, "onDeviceNotSupported()!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            //不处理
        }

        @Override
        public void onSignalValueReceived(boolean ifDrop, int signalValue) {
//            Logger.i(Logger.DEBUG_TAG, "HeartRateService,onSignalValueReceived(),ifDrop=" + ifDrop + ",signalValue:" + signalValue);
            refreshSignalStrength = signalValue < 0 ? 0 : signalValue > 100 ? 100 : signalValue;
            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onSignalValueReceived(ifDrop, signalValue);
                }
            }
        }

        @Override
        public void onPushBtnReceived(int btnType, int msgType) {
            if (btnType == 1) {//一键运动
                if (msgType == 0 || msgType == 1){
                    LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
                    Intent intent = new Intent();
                    intent.setAction(Config.HEART_RATE_CLICK_TO_RUN);
                    lbm.sendBroadcast(intent);
                }

            } else if (btnType == 0 && msgType == 0) {// 播报当前心率区间
                if (getLatestHeartRate() <= 0) {
                    return;
                }
                getVoiceManager().playHrVoice(getLatestHeartRate());
            }
        }

        @Override
        public void onLAVAHRReceive(int avgHr, int minHr, int maxHr) {
//            String test = "avgHr=" + avgHr + ",minHr:" + minHr + ",maxHr:" + maxHr;
//            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onLAVAHRReceive(): " + test);
            //不处理
        }

        @Override
        public void onHRFirmware(String firmwareVersion) {
            Logger.d(Logger.DEBUG_TAG, "firmwareVersion:" + firmwareVersion);
            if (mServiceFunctionHashMap != null) {
                for (HeartRateServiceFunction serviceFunction : mServiceFunctionHashMap.values()) {
                    serviceFunction.onFirmwareVersionReceive(firmwareVersion);
                }
            }

        }

        @Override
        public void onSportDataReceive(int sportMode, int stepBPM, int distance, int totalStep, int speed, int vo2, int calBurnRate, int totalCal, int maxVo2) {
            theMaxVo2 = maxVo2 / 10f;//最大摄氧量为设备传输值除以10

//            String test = "sportMode=" + sportMode + ",stepBPM:" + stepBPM
//                    + ",distance:" + distance + ",totalStep:" + totalStep + ",speed:" + speed + ",vo2:" + vo2
//                    + ",calBurnRate:" + calBurnRate + ",totalCal:" + totalCal + ",maxVo2:" + maxVo2 + ",maxVo2Restore:" + theMaxVo2;
//
//            Logger.i(Logger.DEBUG_TAG, "HeartRateService-->onSportDataReceive(): " + test);
            //不处理
        }
    };

    private void sendSendUserDataCmd() {
        if (age == -1) {
//            age = PrefsHelper.with(HeartRateService.this,Config.PREFS_USER).readInt(Config.SETTING_USER_AGE,Config.USER_DEFAULT_AGE);
            age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
            age *= 12;
        }
        if (gender == -1) {
//            gender = PrefsHelper.with(HeartRateService.this,Config.PREFS_USER).readInt(Config.SETTING_USER_GENDER,Config.GENDER_MALE);
            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
            if (gender != Config.GENDER_MALE) {
                gender = 0;
            }
        }
        if (weight == -1) {
//            weight = PrefsHelper.with(HeartRateService.this,Config.PREFS_USER).readInt(Config.SETTING_USER_WEIGHT,Config.USER_DEFAULT_WEIGHT);
            weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);
            weight *= 10;
        }
        if (height == -1) {
//            height = PrefsHelper.with(HeartRateService.this,Config.PREFS_USER).readInt(Config.SETTING_USER_HEIGHT,Config.USER_DEFAULT_HEIGHT);
            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        }
        if (sportMode == -1) {
            sportMode = 2;//默认运动类型为跑步
        }
        sportMode = 0;//心率蓝牙耳机要求传0；
        setUserData(age, gender, weight, height, latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR, sportMode);
    }

    /**
     * 连接到耳机后,发送设置用户信息的命令
     */
    private void setUserData(int age, int sexuality, int weight, int height, int rest_hr, int sport_mode) {
        if (device != null) {
            String name = device.getName();
            if (name == null)return;
            if (TextUtils.isEmpty(name))return;
            if (name.contains("H10") || name.contains("ROC HR") ||
                    name.contains("ROC Model") ||
                    name.contains("IRON CLOUD")) {
                if (getBleManager() != null) {
                    getBleManager().setUserData(age, sexuality, weight, height, rest_hr, sport_mode);
                }
            }
        }
    }

    /**
     * 一键运动
     */
    public void clickToRun() {
        //除了正在主跑界面和音乐播放界面外,一键运动
        if (!ifBindWithRunMain) {
            Intent intent = new Intent(getApplicationContext(), RunMainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    public HRSManagerCallbacks getDefaultCallBack() {
        return defaultCallBack;
    }

    //endregion ##################### HRSManagerCallbacks的相关回调 #####################

    //region ================================== Service保活相关 ==================================

    private PowerManager.WakeLock mCPUWakeLock;//CPU锁,防止CPU休眠

    /**
     * 获取WakeLock
     */
    private PowerManager.WakeLock getCPUWakeLock() {
        if (mCPUWakeLock == null) {
            PowerManager manager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            mCPUWakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "HeartRateService_CPU_Lock");//在部分手机,熄屏后加速传感器会停止
        }
        return mCPUWakeLock;
    }

    /**
     * 开启CPU锁定
     */
    private void startCPULock() {
        getCPUWakeLock().acquire();
    }

    /**
     * 释放CPU锁定
     */
    private void releaseCPULock() {
        if (mCPUWakeLock != null) {
            getCPUWakeLock().release();
        }
        mCPUWakeLock = null;
    }

    /**
     * 开启Service存活保护
     */
    private void startKeepAlive() {
        ServiceAliveHelper.getInstance(this).startKeep();
    }

    /**
     * 停止Service存活保护
     */
    private void stopKeepAlive() {
        ServiceAliveHelper.getInstance(this).stopKeep();
    }

    //endregion ================================== Service保活相关 ==================================


    private BluetoothA2dp mBluetoothA2dp;
    private BluetoothAdapter mBluetoothAdapter;


    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        return mBluetoothAdapter;
    }

    /**
     * 蓝牙音频通道连接相关
     */
    public void getBluetoothA2DP(BluetoothAdapter mBluetoothAdapter) {
        if (mBluetoothAdapter == null) {
            return;
        }

        if (mBluetoothA2dp != null) {
            return;
        }

        mBluetoothAdapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override
            public void onServiceConnected(int profile, BluetoothProfile proxy) {
                if (profile == BluetoothProfile.A2DP) {
                    //Service连接成功,获得BluetoothA2DP
                    mBluetoothA2dp = (BluetoothA2dp) proxy;

                    //连接蓝牙音频通道
                    try {
                        Method connect = mBluetoothA2dp.getClass().getDeclaredMethod("connect", BluetoothDevice.class);
                        connect.setAccessible(true);
                        connect.invoke(mBluetoothA2dp, device);
                    } catch (Exception e) {
                        Logger.e(Logger.DEBUG_TAG, "connect exception:" + e);
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onServiceDisconnected(int profile) {

            }
        }, BluetoothProfile.A2DP);
    }

    //取消连接蓝牙音频通道
    private void disconnect() {
        Logger.i(Logger.DEBUG_TAG, "disconnect");
        if (mBluetoothA2dp == null) {
            return;
        }
        if (device == null) {
            return;
        }

        try {
            Method disconnect = mBluetoothA2dp.getClass().getDeclaredMethod("disconnect", BluetoothDevice.class);
            disconnect.setAccessible(true);
            disconnect.invoke(mBluetoothA2dp, device);
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "connect exception:" + e);
            e.printStackTrace();
        }
    }

    //注意,在程序退出之前（OnDestroy）,需要断开蓝牙相关的Service
    //否则,程序会报异常：service leaks
    private void disableAdapter() {
        Logger.i(Logger.DEBUG_TAG, "disableAdapter");
        if (mBluetoothAdapter == null) {
            return;
        }

        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }

        //关闭ProfileProxy,也就是断开service连接
        mBluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, mBluetoothA2dp);
        if (mBluetoothAdapter.isEnabled()) {
            boolean ret = mBluetoothAdapter.disable();
            Logger.i(Logger.DEBUG_TAG, "disable adapter:" + ret);
        }
    }


}
