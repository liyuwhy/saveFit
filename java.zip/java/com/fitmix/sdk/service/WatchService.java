package com.fitmix.sdk.service;

import android.app.ActivityManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.android.internal.telephony.ITelephony;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.bluetooth.ble.WatchManager;
import com.fitmix.sdk.common.bluetooth.ble.WatchManagerCallbacks;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.watch.FileOperator;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.DataProtocolItem;
import com.fitmix.sdk.watch.bean.Watch1024SendTempData;
import com.fitmix.sdk.watch.bean.WatchBigDataSend;
import com.fitmix.sdk.watch.bean.WatchBigFile;
import com.fitmix.sdk.watch.bean.WatchBindUnbind;
import com.fitmix.sdk.watch.bean.WatchDailyData;
import com.fitmix.sdk.watch.bean.WatchSetting;
import com.fitmix.sdk.watch.bean.WatchSportLog;
import com.fitmix.sdk.watch.bean.WatchSportLogSyncProgress;
import com.fitmix.sdk.watch.bean.WatchTransReceiveTempData;
import com.fitmix.sdk.watch.bean.WatchVersion;
import com.fitmix.sdk.watch.notification.NotificationMonitor;

import java.io.File;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;


/**
 * 手表服务（数据传输的应用层协议）
 */
public class WatchService extends Service {

    /**
     * BleService 名称
     */
    public static final String SERVICE_NAME = WatchService.class.getName();
    private int totalLog;//同步记录总条数
    private int indexLog;//当前记录的序号
    private int lastIndexLog;//上次记录的序号

    /**
     * 获取已连接的蓝牙设备
     */
    public BluetoothDevice getDevice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (getWatchManager() != null && getWatchManager().getBluetoothGatt() != null) {
                return getWatchManager().getBluetoothGatt().getDevice();
            }
        }
        return null;
    }

    /**
     * 由于1024的response包告知错误,重发1024包的次数
     */
    private int nowResendTimes = 0;
    /**
     * 由于1024的response包告知断点续传位置错误,重发1024包的次数
     */
    private int nowErrorResendTimes = 0;
    /**
     * 最大重发次数
     */
    private static final int MAX_RESEND_TIMES = 2;

//    /**
//     * 等待下一条运动记录命令时间,单位为秒
//     */
//    private int mWaitNextRecordTime;
    /**
     * 是否正在同步运动记录中
     */
    private boolean isSyncRecord;

    /**
     * 当前连接的手表设备
     */
    private BluetoothDevice mDevice;

    //region ================================== Services生命周期 ==================================
    /**
     * 乐享动用户ID
     */
    private int userId = -1;

    /**
     * 获取当前用户的id
     *
     * @return
     */
    public int getUserId() {
        userId = UserDataManager.getUid();
        return userId;
    }

    /**
     * 手表固件升级文件路径
     */
    public String firmFilePath;

    public String getFirmFilePath() {
        return firmFilePath;
    }

    public void setFirmFilePath(String firmFilePath) {
        this.firmFilePath = firmFilePath;
    }

    /**
     * 手表固件升级是否等待发送
     */
    public boolean waitSendFirm;

    public boolean isWaitSendFirm() {
        return waitSendFirm;
    }

    public void setWaitSendFirm(boolean waitSendFirm) {
        this.waitSendFirm = waitSendFirm;
    }

    public int getTotalLog() {
        return totalLog;
    }

    public void setTotalLog(int totalLog) {
        this.totalLog = totalLog;
    }

    public int getIndexLog() {
        return indexLog;
    }

    public void setIndexLog(int indexLog) {
        this.indexLog = indexLog;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initWatchManager();//初始化
        registerNotification();
        //注册蓝牙监听状态
        IntentFilter statusFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mStatusReceive, statusFilter);
    }

    @Override
    public void onDestroy() {
        Logger.e(Logger.DEBUG_TAG, "WatchService-->onDestroy");
        //需要清空可能引起内存泄露的资源
        receivingTag = null;
        release();
        unbindDownloadService();
        unregisterNotification();
        if (mStatusReceive != null) {
            unregisterReceiver(mStatusReceive);
        }
    }

    public class LocalBinder extends Binder {
        public WatchService getService() {
            return WatchService.this;
        }
    }

    private final IBinder mBinder = new LocalBinder();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    //endregion ================================== Services生命周期 ==================================

    //region ================================== activity的回调 ==================================

    private Hashtable<String, ServiceFunction> serviceFunctionTable;

    /**
     * 设置手表蓝牙事件回调
     *
     * @param activityName    Activity名称
     * @param serviceFunction 手表蓝牙事件回调
     */
    public void addServiceFunction(String activityName, ServiceFunction serviceFunction) {
        if (serviceFunctionTable == null) {
            serviceFunctionTable = new Hashtable<>();
        }

        if (activityName != null && serviceFunction != null) {
            serviceFunctionTable.put(activityName, serviceFunction);
        }
    }

    /**
     * 移除手表蓝牙事件回调
     *
     * @param activityName Activity名称
     */
    public void removeServiceFunction(String activityName) {
        if (serviceFunctionTable != null && activityName != null) {
            serviceFunctionTable.remove(activityName);
        }
    }

    public interface SportLogListener {
        void progress(int progress);
    }

    public SportLogListener listener;

    public void setListener(SportLogListener listener) {
        this.listener = listener;
    }

    /**
     * 蓝牙事件回调
     */
    public interface ServiceFunction {
        /**
         * 蓝牙设备已连接事件回调
         */
        void onDeviceConnected();

        /**
         * 蓝牙设备已准备好通讯
         */
        void onDeviceReady();

        /**
         * 蓝牙设备已断开事件回调
         */
        void onDeviceDisconnected();

        /**
         * 手表回复包结果信息<br/>
         * <b>注意:方法不是在主线程</b>
         *
         * @param groupTag 参考{@link WatchDataProtocol} TagGroup部分
         * @param cell     参考各GroupTag 的cell定义
         * @param iPos     应答的包的传输位置,不是大文件传输的话,值为0
         * @param result   应答结果,0:成功,1:失败,2:解码错误,3:超时 参考{@link WatchDataProtocol} enumPackageResult部分
         */
        void onResponse(int groupTag, int cell, int iPos, int result);

        /**
         * 收到手表主动发来的信息,并需要通知UI更新<br/>
         * <b>注意:方法不是在主线程</b>
         *
         * @param groupTag 参考{@link WatchDataProtocol} TagGroup部分
         * @param dataJson 信息结果实体对应的json字符串
         */
        void onReceiveDataRefreshUi(int groupTag, String dataJson);
    }

    /**
     * 获取手机是否和手表正在同步运动记录
     */
    public boolean isSyncRecord() {
        return isSyncRecord;
    }

    /**
     * 重置状态
     */
    private void clearState() {
        isSyncRecord = false;
        mDevice = null;
    }

    //endregion ================================== activity的回调 ==================================

    //region ================================== 手表BLE管理器相关 ==================================

    private WatchManager mWatchManager;

    public WatchManager getWatchManager() {
        if( mWatchManager == null){
            initWatchManager();
        }
        return mWatchManager;
    }

    /**
     * 初始化手表BLE层协议相关
     */
    private void initWatchManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            Logger.i(Logger.DEBUG_TAG, "WatchService-->initWatchManager()");
            mWatchManager = new WatchManager(this);
            mWatchManager.setWatchManagerCallbacks(mWatchManagerCallback);
            mWatchManager.setWatchManagerHandler(this);
        }
    }

    /**
     * 释放手表BLE层资源
     */
    public void release() {
        Logger.i(Logger.DEBUG_TAG, "WatchService-->release() mWatchManager is null:" + (mWatchManager == null));
        if (mWatchManager != null) {
            mWatchManager.disconnect();
            mWatchManager.close();
            mWatchManager.setGattCallbacks(null);
            mWatchManager.clear();
            mWatchManager = null;
        }
        clearState();
    }

    /**
     * 手表BLE事件回调
     */
    private WatchManagerCallbacks mWatchManagerCallback = new WatchManagerCallbacks() {
        @Override
        public void data1024SendStateChange(int state) {
            Logger.i(Logger.DEBUG_TAG, "data1024SendStateChange state:" + state);
        }

        @Override
        public void receive1024DataSuccess(byte[] receivedTotalData) {
            if (receivedTotalData != null) {
                parseWatchData(receivedTotalData);
            }
        }

        @Override
        public void onDeviceConnected() {
            if (serviceFunctionTable != null) {
                Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
                for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                    entry.getValue().onDeviceConnected();
                }
            }
        }

        @Override
        public void onDeviceDisconnecting() {
            //do nothing
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.i(Logger.LOG_TAG, "WatchService ble-->onDeviceDisconnected");
            if (serviceFunctionTable != null) {
                Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
                for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                    entry.getValue().onDeviceDisconnected();
                }
            }
            if (mWatchManager != null) {//清除WatchManager有关状态
                mWatchManager.clear();
            }
            clearState();
        }

        @Override
        public void onLinkLossOccur() {
            //不处理
        }

        @Override
        public void onServicesDiscovered(boolean optionalServicesFound) {
            //不处理
        }

        @Override
        public void onDeviceReady() {
            if (serviceFunctionTable != null) {
                getWatchManager().setIs20Sending(false);
                getWatchManager().setPack1024SendState(0);
                Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
                for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                    entry.getValue().onDeviceReady();
                }
            }
        }

        @Override
        public void onBondingRequired() {
            //不处理
        }

        @Override
        public void onBonded() {
            //不处理
        }

        @Override
        public void onError(String message, int errorCode) {
            Logger.e(Logger.DEBUG_TAG, "WatchService-->onError message:" + message + ",errorCode:" + errorCode);
            if (errorCode == 133 || errorCode == 34 || errorCode == 22 || errorCode == 8 || errorCode == 257) {//BLE 蓝牙连接133问题,重新连接
                disconnectDevice();
                if (mDevice != null) {
                    connectDevice(mDevice);
                }
            }
        }

        @Override
        public void onDeviceNotSupported() {
            //没找到服务
        }
    };

    //endregion ================================== 手表BLE管理器相关 ==================================

    //region ================================== BLE通道连接 ==================================

    /**
     * 蓝牙BLE连接
     *
     * @param device
     */
    public void connectDevice(BluetoothDevice device) {
        if (getWatchManager() != null) {
            getWatchManager().clear();
            getWatchManager().disconnect();
            getWatchManager().connect(device);
            mDevice = device;
        }
    }

    /**
     * 断开连接
     */
    public void disconnectDevice() {
        if (getWatchManager() != null) {
            getWatchManager().disconnect();
        }
    }

    /**
     * 断开蓝牙并通知界面刷新状态
     */
    public void disconnectDeviceAndRefreshView() {
        Logger.i(Logger.DEBUG_TAG, "WatchService 蓝牙 disconnectDeviceAndRefreshView");
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onDeviceDisconnected();
            }
        }

        if (mWatchManager != null) {//清除WatchManager有关状态
            mWatchManager.disconnect();
            mWatchManager.close();
            mWatchManager.clear();
        }
        clearState();
    }

    /**
     * 判断BLE通道是否处于成功状态
     *
     * @return
     */
    public boolean ifBLEFunctionOk() {
        return getWatchManager() != null && getWatchManager().isWatchDataChannelOk();
    }

    //endregion ================================== BLE通道连接 ==================================

    //region ================================== 应用层 总数据包中1024字节包的传输 ==================================

    //接收
    private Hashtable<Integer, WatchTransReceiveTempData> receivingTag;//正在接收过程中的Tag集合

    /**
     * 正在接收大数据包的
     */
    private Hashtable<Integer, WatchTransReceiveTempData> getReceivingTag() {
        if (receivingTag == null) {
            receivingTag = new Hashtable<>();
        }
        return receivingTag;
    }

    /**
     * 标识指定Tag类型正在接收大数据中
     */
    private void addReceivingTag(int tag, WatchTransReceiveTempData tempData) {
        Logger.i(Logger.DEBUG_TAG, "WatchService-->addReceivingTag tag:" + tag);
        getReceivingTag().put(tag, tempData);
    }

    /**
     * 清除指定Tag类型正在接收大数据中标识
     */
    private void removeReceivingTag(int tag) {
        Logger.i(Logger.DEBUG_TAG, "WatchService-->removeReceivingTag tag:" + tag);
        getReceivingTag().remove(tag);
    }

    /**
     * 获取指定tag类型大数据传输情况
     */
    private WatchTransReceiveTempData getWatchTransReceiveTempData(int tag) {
        return getReceivingTag().get(tag);
    }

    //region #################################### 处理接收到的1024字节数据 ####################################

    /**
     * 解析手表传过来的数据(每接收到一个1024包)
     *
     * @param receivedTotalData 收到的有意义的字节数组
     */
    private void parseWatchData(byte[] receivedTotalData) {
        //缓冲区每次存放1024字节包
        int chapterTag = WatchFormatManager.getChapterGroupTag(receivedTotalData);
        WatchFormatManager.logoutAllByte("WatchService--->parseWatchData chapterTag:" + chapterTag + ",thread id:" + Thread.currentThread().getId()
                + ",\ndata:", receivedTotalData);
        if (chapterTag == WatchDataProtocol.TAG_GROUP_RESPONSE) {//为回复包
            Logger.logTimeFile(4);
            handleResponse(receivedTotalData);
        } else {//其它数据包
            handleReceiveData(receivedTotalData);
        }
//        Logger.i(Logger.DEBUG_TAG, "WatchService--->parseWatchData 等待接收手表response包队列长度:" + getWatchManager().getWaitResponseSize());
    }

    /**
     * 处理手表发回的response包，默认都是一个1024足够存放完毕 FIXME 回复包超过1024字节情况未考虑
     *
     * @param receivedTotalData 回复包数据
     */
    private void handleResponse(byte[] receivedTotalData) {
        //1.查看回复包中对应发送包的group tag
        int tag = WatchFormatManager.getIntContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_RESPONSE, WatchDataProtocol.RESPONSE_TAG);
        int groupTag = WatchFormatManager.getGroupTagFromTag(tag);//取group tag = tag >> 16;
        int cell = WatchFormatManager.getCellFromTag(tag);//取cell = tag & 65535;

        //2.查看回复包中对应发送数据在总包的位置
        int iPos = WatchFormatManager.getIntContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_RESPONSE, WatchDataProtocol.RESPONSE_POS);
        //3.查看回复结果
        int result = WatchFormatManager.getIntContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_RESPONSE, WatchDataProtocol.RESPONSE_RESULT);

        Logger.i(Logger.DEBUG_TAG, "WatchService--->handleResponse 回复包内容 groupTag:" + groupTag + ",cell:" + cell + ",iPos:" + iPos + ",result:" + result
                + ",serviceFunctionTable.size():" + serviceFunctionTable.size());
        //4.通知UI回复情况
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onResponse(groupTag, cell, iPos, result);
            }
        }

        //5.判断这个response包是否是对正在发送的1024字节的回应
//        Watch1024SendTempData temp = getWatchManager().getWaitResponseData(tag);
        Watch1024SendTempData temp = getWatchManager().getSending1024Data(tag);
        if (temp == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse(),tag:" + tag + ",groupTag:" + groupTag + ",cell:" + cell + ",temp == NULL");
            return;//不操作,继续等待
        }

        //6.此response包是对正在发送的1024字节的回应,标志1024发送完成
        getWatchManager().clearWaitResponseState();

        //7.发送数据可应用的结果
        if (result == WatchDataProtocol.PACKAGE_RESULT_SUCCESS) {
            nowResendTimes = 0;
            switch (groupTag) {//对于大文件发送,准备下一个包
                case WatchDataProtocol.TAG_GROUP_UPGRADE://升级包
                    sendBigFileNext(tag, groupTag, iPos);
                    break;
                case WatchDataProtocol.TAG_GROUP_GPS://星历数据
                    if (cell == WatchDataProtocol.GPS_BLE_EPHEMERIS) {
                        sendBigFileNext(tag, groupTag, iPos);
                    }
                    break;
            }
        } else if (result == WatchDataProtocol.PACKAGE_RESULT_FAILURE) {//失败，重发上一个包
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse result异常 tag:" + tag + ",groupTag:"
                    + groupTag + ",cell:" + cell + ",iPos:" + iPos + ",result:" + result);
            if (nowResendTimes < MAX_RESEND_TIMES) {
                Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse,result为失败,需要重发上一个包");
                nowResendTimes++;
                // 因为response告知错误，需要重发,
                getWatchManager().addDataToSendQueue(temp);
            } else {
                nowResendTimes = 0;
                Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse result为失败,达到最大重发数,不再重发");
            }
        } else if (result == WatchDataProtocol.RECEIVE_RESULT_LARGE_PACKAGE_BREAK_POS_ERROR) {//断点续传位置错误，重发上一个包
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse result异常 tag:" + tag + ",groupTag:"
                    + groupTag + ",cell:" + cell + ",iPos:" + iPos + ",result:" + result);
            if (nowErrorResendTimes < MAX_RESEND_TIMES) {
                Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse,result为失败,需要重发上一个包");
                nowErrorResendTimes++;
                // 因为response告知错误，需要重发,
                getWatchManager().addDataToSendQueue(temp);
            } else {
                nowErrorResendTimes = 0;
                Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse result为失败,达到最大重发数,不再重发");
            }
        } else {//异常
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handleResponse result异常 tag:" + tag + ",groupTag:"
                    + groupTag + ",cell:" + cell + ",iPos:" + iPos + ",result:" + result);
            nowResendTimes = 0;
            //4.通知UI回复情况
            if (serviceFunctionTable != null) {
                Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
                for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                    entry.getValue().onResponse(groupTag, cell, iPos, result);
                }
            }
        }
    }

    /**
     * 处理特殊的回复包
     * <p>这些发送给手表的命令,手表没有以response包方式回应,而是以普通数据包回发的,
     * 移除相应等待手表回复的1024字节包,设置1024字节包发送状态为成功</p>
     */
    private void handSpecialResponse(int groupTag, int tag) {
        int newTag;//实际发送的tag
        switch (groupTag) {
            case WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS://app其它设置查询
                newTag = WatchFormatManager.generateTag(groupTag, WatchDataProtocol.OTHER_SETTINGS_BLE_QUERY);
                break;
            case WatchDataProtocol.TAG_GROUP_UPGRADE://升级,手表固件版本查询
                newTag = WatchFormatManager.generateTag(groupTag, WatchDataProtocol.UPGRADE_BLE_QUERY);
                break;
            case WatchDataProtocol.TAG_GROUP_BIND://绑定解绑
                newTag = WatchFormatManager.generateTag(groupTag, WatchDataProtocol.BIND_BLE_RESERVED);
                break;
            case WatchDataProtocol.TAG_GROUP_DAILY_DATA://电量等日常数据
                newTag = WatchFormatManager.generateTag(groupTag, WatchDataProtocol.DAILY_BLE_QUERY);
                break;

            default://返回
                return;
        }

        Watch1024SendTempData temp = getWatchManager().getSending1024Data(newTag);
        if (temp == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handSpecialResponse(),tag:" + tag + ",groupTag:" + groupTag + ",temp == NULL");
            return;//不操作,继续等待
        }
        Logger.i(Logger.DEBUG_TAG, "WatchService-->handSpecialResponse groupTag:" + groupTag + ",tag:" + tag);
        getWatchManager().clearWaitResponseState();

//        getWatchManager().removeWaitResponseData(tag);
    }

    /**
     * 处理手表发回的数据包
     *
     * @param receivedTotalData 数据包数据
     */
    private void handleReceiveData(byte[] receivedTotalData) {
        //缓冲区每次最多存放1024字节包,解析成功与否都要发回应包
        int groupTag = WatchFormatManager.getChapterGroupTag(receivedTotalData);
        int tag = WatchFormatManager.getChapterTag(receivedTotalData);
        int iPos = WatchFormatManager.getPackagePos(receivedTotalData);
        int thisPackageLength = WatchFormatManager.getChapterPackageLength(receivedTotalData);//当前包长度
        int packageTotalLength = WatchFormatManager.getTotalPackageLength(receivedTotalData);//包的总长度

        if (packageTotalLength == thisPackageLength) {//所有内容都在一个1024字节包内
            receiveNormalData(tag, receivedTotalData);//解析并处理有关app操作，如收到挂断电话就挂断手机电话
            sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_SUCCESS);//向手表发送response包
            handSpecialResponse(groupTag, tag);
        } else if (packageTotalLength < thisPackageLength) {//异常
            Logger.d(Logger.DEBUG_TAG, "WatchService--->handleReceiveData chapter长度大于总包长度,thisPackageLength:" + thisPackageLength + ">packageTotalLength:" + packageTotalLength);
            // 出错，告诉发送方出错,要求重发该1024包
            sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_FAILURE);
        } else {//要接收的数据由多个1024字节包组成,即大文件
            receiveBigData(tag, groupTag, iPos, thisPackageLength, packageTotalLength, receivedTotalData);
        }
    }

    /**
     * 接收单个完整的1024字节数据
     *
     * @param tag               传输对应的tag,包括groupTag和cell
     * @param receivedTotalData 本次1024字节包的数据
     */
    private void receiveNormalData(int tag, byte[] receivedTotalData) {
        int groupTag = WatchFormatManager.getGroupTagFromTag(tag);
        int cell = WatchFormatManager.getCellFromTag(tag);
        Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveNormalData 接收单个完整的1024字节数据 groupTag:" + groupTag + ",cell:" + cell);
        switch (groupTag) {
            case WatchDataProtocol.TAG_GROUP_REQUEST://断点续传请求
                handleBreakContinue(receivedTotalData, groupTag);
                break;

            case WatchDataProtocol.TAG_GROUP_UPGRADE://升级,手表固件版本查询
                handleWatchUpgrade(receivedTotalData, groupTag);
                break;

            case WatchDataProtocol.TAG_GROUP_WEATHER://天气
                if (cell == WatchDataProtocol.WEATHER_BLE_QUERY) {//手表请求天气数据
                    handleWatchWeather(groupTag);
                }
                break;

            case WatchDataProtocol.TAG_GROUP_DAILY_DATA://日常数据
                handleDailyData(receivedTotalData, groupTag);
                break;

            case WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS://APP 端其它手表设置
                handleAppOtherSetting(receivedTotalData, groupTag);
                break;

            case WatchDataProtocol.TAG_GROUP_ADD_LOG://添加运动记录
                handleAddLog(groupTag, receivedTotalData);
                break;

            case WatchDataProtocol.TAG_GROUP_SENSOR_DATA://sensor数据,不是大文件
                handleSensorData(receivedTotalData);
                break;

            case WatchDataProtocol.TAG_GROUP_SYN_LOG_CONTROL://记录同步控制
                handleSyncLogControl(groupTag, receivedTotalData);
                break;

            case WatchDataProtocol.TAG_GROUP_GPS://gps校准
                if (cell == WatchDataProtocol.GPS_BLE_EPHEMERIS_QUERY) {//手表请求星历数据
                    handleGpsEphemeris();
                }
                break;

            case WatchDataProtocol.TAG_GROUP_BIND://绑定解绑
                handleBindUnbind(groupTag, receivedTotalData);
                break;

            case WatchDataProtocol.TAG_GROUP_CALL://来电
                if (cell == WatchDataProtocol.CALL_BLE_ANSWER) {//接听

                } else if (cell == WatchDataProtocol.CALL_BLE_DECLINE) {//挂断
                    declinePhone();//需获取call phone权限
                }
                break;
            case WatchDataProtocol.TAG_GROUP_TIME://时间同步 509
                if (cell == WatchDataProtocol.TIME_BLE_QUERY) {//时间查询 1
                    handleQueryTimeRequest();
                }

                break;

        }

    }

    int logProgress = 0;
    int index = 0;

    /**
     * 接收大数据
     *
     * @param tag                大文件传输对应的tag,包括groupTag和cell
     * @param groupTag           大文件传输对应的groupTag
     * @param iPos               数据包为总包的位置,目前传输位置,若只有一个包,则为0
     * @param thisPackageLength  本次1024字节包,CONTENT信息中指示的本次有效单元数据长度
     * @param packageTotalLength 本次1024字节包中,CONTENT信息中指示的总有效数据长度
     * @param receivedTotalData  本次1024字节包的数据
     */
    private void receiveBigData(int tag, int groupTag, int iPos, int thisPackageLength, int packageTotalLength, byte[] receivedTotalData) {
        Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveBigData 接收大数据 groupTag:" + groupTag + ",cell:" + WatchFormatManager.getCellFromTag(tag)
                + ",iPos:" + iPos + ",thisPackageLength:" + thisPackageLength + ",packageTotalLength:" + packageTotalLength
                + ",thread id:" + Thread.currentThread().getId());
        int nowPackageLength;//当前累加接收的长度
        boolean isHead;//是否为头个1024包
        WatchTransReceiveTempData receiveTempData;
        byte[] data = null;//大文件真正的内容
        if (iPos == 0) {//头个1024包
            Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveBigData,第一个1024字节包");
            nowPackageLength = thisPackageLength;
            receiveTempData = new WatchTransReceiveTempData(thisPackageLength, packageTotalLength, iPos);
            if (groupTag == WatchDataProtocol.TAG_GROUP_SENSOR_DATA) {//传感器文件
                List<DataProtocolItem> items = WatchFormatManager.getItems(receivedTotalData);
                for (DataProtocolItem item : items) {
                    int itemTag = item.getTag();
                    if (itemTag == -1) {//获取大文件内容
                        data = item.getData();
                    }
                }
                receiveTempData.setFileName(WatchFormatManager.getSensorFileName(getUserId(), items));
            } else if (groupTag == WatchDataProtocol.TAG_GROUP_ERROR_REPORT) { // 手表的错误日志
                receiveTempData.setFileName(Config.PATH_WATCH_ERROR_LOG + Config.LOG_NAME);
                Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveBigData -- error_report name" + receiveTempData.getFileName());
                data = new byte[thisPackageLength];
                System.arraycopy(receivedTotalData, 34, data, 0, data.length);
            }
            addReceivingTag(tag, receiveTempData);
            isHead = true;

        } else {//中后段的1024包
            Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveBigData,not Head");
            isHead = false;

            receiveTempData = getWatchTransReceiveTempData(tag);
            if (receiveTempData == null) {//出错,之前接收的包在内存中丢失
                Logger.e(Logger.DEBUG_TAG, "WatchService--->handleReceiveData getWatchTransReceiveTempData(chapterTag) == null");
                sendWatchResponseCmd(tag, 0, WatchDataProtocol.PACKAGE_RESULT_FAILURE);//从头开始?
                removeReceivingTag(tag);
                return;
            }

            if (packageTotalLength != receiveTempData.getPackageTotalLength()) {//当前接收的1024字节片段与之前正在接收的不是同一个大包的内容
                Logger.e(Logger.DEBUG_TAG, "WatchService--->receiveBigData, 解析1024包数据发生错误 packageTotalLength != getPackageTotalLength packageTotalLength:"
                        + packageTotalLength + ",getPackageTotalLength:" + receiveTempData.getPackageTotalLength());
                sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_FAILURE);//出错,告诉发送方出错,要求重发该1024包
                return;
            }

            nowPackageLength = receiveTempData.getNowPackageLength();
            if (iPos != nowPackageLength) {//本次接收的1024字节不是上一次字节包后的一个
                Logger.e(Logger.DEBUG_TAG, "WatchService--->receiveBigData,当前接收的1024字节包iPos不对 != iPos:"
                        + iPos + ",nowPackageLength:" + nowPackageLength);
                sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_FAILURE);//出错,告诉发送方出错,要求重发该1024包
                //todo 2018.5.22新增
                return;
            }

            nowPackageLength += thisPackageLength;
            //接收成功
            receiveTempData.setNowPackageLength(nowPackageLength);//累加长度
            //余下的大文件包结构为,34字节头+大文件内容
            data = new byte[thisPackageLength];
            System.arraycopy(receivedTotalData, 34, data, 0, data.length);
        }

        if (nowPackageLength > packageTotalLength) {//出错
            Logger.e(Logger.DEBUG_TAG, "WatchService--->handleReceiveData ,nowPackageLength:" + nowPackageLength + " > packageTotalLength:" + packageTotalLength);
            sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_FAILURE);// 出错,告诉发送方出错,要求重发该1024包
            return;
        } else if (nowPackageLength == packageTotalLength) {//d当前1024为总包的全部
            removeReceivingTag(tag);
        }

        //向手表发送response包
        sendWatchResponseCmd(tag, iPos, WatchDataProtocol.PACKAGE_RESULT_SUCCESS);
        //写文件
        if (data != null && receiveTempData != null) {
            saveFile(data, isHead, receiveTempData.getFileName());
        }
        /*Logger.d(Logger.DEBUG_TAG, "WatchService--->receiveBigData 写入文件完成 groupTag:" + groupTag + " nowPackageLength:" + nowPackageLength +
                " packageTotalLength" + packageTotalLength);*/
        if (groupTag == WatchDataProtocol.TAG_GROUP_SENSOR_DATA) {
            if (packageTotalLength == 0) return;
            if (990 == nowPackageLength) {
                if (lastIndexLog != indexLog){//上次记录序号跟当前不一致时，重新计index
                    index =0;
                    lastIndexLog = indexLog;
                }
                index++;

            }
            double lengthProgress = ((double) nowPackageLength / ((double) packageTotalLength));
            if (1 == index) {
                logProgress = (int) (lengthProgress * (6 / 20d) * 100d);
            } else if (2 == index) {
                logProgress = (int) (lengthProgress * 100d * (3 / 20d) + (6 / 20d) * 100d);
            } else if (3 == index) {
                logProgress = (int) (lengthProgress * 100d * (4 / 20d) + (9 / 20d) * 100d);
            } else if (4 == index) {
                logProgress = (int) (lengthProgress * 100d * (2 / 20d) + (13 / 20d) * 100d);
            } else if (5 == index) {
                logProgress = (int) (lengthProgress * 100d * (1 / 20d) + (15 / 20d) * 100d);
            } else if (6 == index) {
                logProgress = (int) (lengthProgress * 100d * (1 / 20d) + (16 / 20d) * 100d);
            } else if (7 == index) {
                logProgress = (int) (lengthProgress * 100d * (1 / 20d) + (17 / 20d) * 100d);
            } else if (8 == index) {
                logProgress = (int) (lengthProgress * 100d * (1 / 20d) + (18 / 20d) * 100d);
            }  else {
                logProgress = (int) (100d * (19 / 20d) + lengthProgress * 100d * (1 / 20d));
            }
            if (listener != null) {
                listener.progress(logProgress);
            }
        }
        // 错误日志写入完成
        if (groupTag == WatchDataProtocol.TAG_GROUP_ERROR_REPORT && nowPackageLength == packageTotalLength) {
            handleErrorLogReceivedFinish(groupTag);
        }

    }

    /**
     * 保存内容到相应的文件
     *
     * @param data     需要保存的内容
     * @param isHead   是否是文件头
     * @param fileName 文件名,只要不是手表发过来的回复类型信息都写文件
     */
    private void saveFile(final byte[] data, final boolean isHead, final String fileName) {
        //1.写文件
        ThreadManager.executeOnSubThread1(new Runnable() {
            @Override
            public void run() {
                FileOperator.writeDataToFile(fileName, data, isHead);
            }
        });
    }

    //endregion #################################### 处理接收到的1024字节数据 ####################################

    //region #################################### 发送数据 ####################################

    /**
     * 当前正在发送的大文件信息
     */
    private WatchBigDataSend mWatchBigDataSend;

    public void setmWatchBigDataSend(WatchBigDataSend mWatchBigDataSend) {
        this.mWatchBigDataSend = mWatchBigDataSend;
    }

    /**
     * 获取当前正在发送的大文件信息
     */
    public WatchBigDataSend getWatchBigDataSend() {
        return mWatchBigDataSend;
    }


    /**
     * 每接收一个1024字节包后向手表发送数据回应包(收到手表的response包除外)
     *
     * @param tag    接收到的1024字节包tag,包括groupTag和cell
     * @param iPos   当前数据内容在总数据包中的目前传输位置,第一个包或总数据长度小于1024字节则为0x00
     * @param result WatchDataProtocol.PACKAGE_RESULT_SUCCESS、WatchDataProtocol.PACKAGE_RESULT_FAILURE 等
     */
    public void sendWatchResponseCmd(int tag, int iPos, int result) {
        Logger.i(Logger.DEBUG_TAG, "WatchService--->sendWatchResponseCmd() 向手表发送数据回应包,tag:" + tag + "," + ",result:" + result);
//        byte[] resultByte = WatchFormatManager.getAnswer(result);
        byte[] resultByte = WatchFormatManager.getAnswer(result, tag, iPos);
        if (resultByte.length != 0) {
            Watch1024SendTempData tempData = new Watch1024SendTempData(Watch1024SendTempData.TYPE_RESPONSE, tag, resultByte, iPos, false);
            getWatchManager().addDataToSendQueue(tempData);
        }
    }

    /**
     * 发送一个总数据内容长度在1024字节内的数据包
     * <p>如果长度大于1024字节,需要以大文件形式传输</p>
     *
     * @param tag         数据所属的Tag,包括groupTag和cell
     * @param totallyData 需要发送的应用层数据(所有的数据在1024字节内)
     */
    public void sendTotallyDataCmd(int tag, byte[] totallyData) {
        if (totallyData == null || totallyData.length == 0) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->sendTotallyDataCmd tag:" + tag + " sendTotallyDataCmd(),totallyData异常");
            return;
        }

        Watch1024SendTempData tempData = new Watch1024SendTempData(Watch1024SendTempData.TYPE_NORMAL, tag, totallyData, 0, true);
        getWatchManager().addDataToSendQueue(tempData);
    }

    /**
     * 向手表发送大文件,(规则:每次发送1024字节包，需要等到手表应用层回应ok的response包才进行下一步操作)
     *
     * @param groupTag  大文件传输对应的groupTag
     * @param cell      大文件传输对应的cell
     * @param fileName  大文件名
     * @param startPack 开始包的序号,如果是从头开始,则为0,断点续传时,根据手表返回的pos开始
     * @return 大文件长度
     */
    public int sendBigFile(final int groupTag, final int cell, final String fileName, final int startPack) {
        //1.信息有效性判断
        if (getDevice() == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->groupTag:" + groupTag + " sendBigFile(),device == null");
            return 0;
        }
        if (!FileUtils.isFileExist(fileName)) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->groupTag:" + groupTag + " sendBigFile() 文件不存在:" + fileName);
            return 0;
        }

        if (mWatchBigDataSend != null && mWatchBigDataSend.getFileName() != null
                && !mWatchBigDataSend.getFileName().equals(fileName)) {//保证同一时间段只发送一个大文件
            if (mWatchBigDataSend.getFileType() != groupTag && mWatchBigDataSend.getCell() != cell) {//不是同一个cell
                Logger.e(Logger.DEBUG_TAG, "WatchService--->groupTag:" + groupTag + " sendBigFile() 当前已有大文件在发送:"
                        + mWatchBigDataSend.getFileName());
                return 0;
            }
        }

        //2.保存大文件发送最新信息,并写回SharePreferences
        String oldBigFileStr = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_BIG_FILE);
        WatchBigFile watchBigFile = JsonHelper.getObject(oldBigFileStr, WatchBigFile.class);
        if (watchBigFile == null) {
            watchBigFile = new WatchBigFile();
        }
        switch (groupTag) {
            case WatchDataProtocol.TAG_GROUP_UPGRADE://升级包
                if (cell == WatchDataProtocol.UPGRADE_BLE_DATA) {//手表固件
                    watchBigFile.setUpgradeFileName(fileName);
                    waitSendFirm = false;
                } else if (cell == WatchDataProtocol.UPGRADE_BLE_APOLLO) {//阿波罗
                    watchBigFile.setApolloFileName(fileName);
                }
                break;
            case WatchDataProtocol.TAG_GROUP_GPS://星历数据
                watchBigFile.setGpsFileName(fileName);
                break;
        }
        String newBigFileStr = JsonHelper.createJsonString(watchBigFile);
        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_BIG_FILE, newBigFileStr);


        //3.开启大文件发送
        mWatchBigDataSend = new WatchBigDataSend(fileName, groupTag, cell);
        final File file = new File(fileName);
        final int fileLength = (int) file.length();
        Logger.i(Logger.DEBUG_TAG, "WatchService--->sendBigFile groupTag:" + groupTag + ",fileName:" + fileName + ",thread:" + Thread.currentThread().getId());
        //小于4M直接把文件内容读入内存
        if (fileLength < 4194304) {//4 * 1024 * 1024   4M
            byte[] data = null;
            try {
                data = new byte[fileLength];
            } catch (Exception e) {
                Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFile 创建data失败,内存不够? error:" + e.getMessage());
            }
            if (data == null)
                return fileLength;

            int read = readBytesFromFile(fileName, data, 0, fileLength);
            if (read == fileLength) {
                mWatchBigDataSend.setData(data);
                byte[] bytes = mWatchBigDataSend.getDataFragment(startPack);//从文件中获取内容,最多990字节(预留34字节用来加上应用层协议头)
                if (bytes == null) {
                    Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFile 从文件中获取内容为空!大文件发送完毕?");
                    mWatchBigDataSend = null;//大文件发送完毕
                    return fileLength;
                }

                byte[] toSendData = null;//文件内容加上应用层协议数据
                if (groupTag == WatchDataProtocol.TAG_GROUP_UPGRADE) {//发送升级包
                    if (cell == WatchDataProtocol.UPGRADE_BLE_DATA) {
                        toSendData = WatchFormatManager.getUpgradeFileSendData(startPack, bytes.length, fileLength, bytes);
                    } else if (cell == WatchDataProtocol.UPGRADE_BLE_APOLLO) {
                        toSendData = WatchFormatManager.getUpgradeAploFileSendData(startPack, bytes.length, fileLength, bytes);
                    }

                } else if (groupTag == WatchDataProtocol.TAG_GROUP_GPS) {//发送星历数据
                    toSendData = WatchFormatManager.getGpsFileSendData(startPack, bytes.length, fileLength, bytes);
                }

                if (toSendData == null) {
                    Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFile 文件内容加上应用层协议生成的数据为空!");
                    return fileLength;
                }
                int tag = WatchFormatManager.generateTag(groupTag, cell);
                Watch1024SendTempData tempData = new Watch1024SendTempData(Watch1024SendTempData.TYPE_FILE, tag, toSendData, startPack, true);
                getWatchManager().addDataToSendQueue(tempData);
            } else {
                Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFile readBytesFromFile 出错!");
            }
        } else {
            //TODO 尚未处理
        }

        return fileLength;
    }

    /**
     * 发送大文件下一个1024字节包
     *
     * @param tag      tag
     * @param groupTag groupTag
     * @param iPos     上一个发送成功的大文件字节包在总数据中的位置
     */
    public void sendBigFileNext(int tag, int groupTag, int iPos) {
        if (mWatchBigDataSend == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFileNext mWatchBigDataSend is null");
            return;
        }
        int cell = WatchFormatManager.getCellFromTag(tag);
        if (mWatchBigDataSend.getData() == null) return;
        int progress = (int) (iPos * 100.0f / mWatchBigDataSend.getData().length);
        Logger.d(Logger.DEBUG_TAG, "WatchService --> sendBigFileNext groupTag:" + groupTag + ",cell:" + cell + ",progress:" + progress);
        int nextPos = iPos + 990;//下一个包在大包中发送的位置
        byte[] bytes = mWatchBigDataSend.getDataFragment(nextPos);//从文件中获取内容,最多990字节(预留34字节用来加上应用层协议头)
        if (bytes == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFileNext 从文件中获取内容为空! ---!!!大文件发送完成");
            mWatchBigDataSend = null;//大文件发送完成
            if (groupTag == WatchDataProtocol.TAG_GROUP_UPGRADE && cell == WatchDataProtocol.UPGRADE_BLE_DATA) {
                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, 100);
                if (serviceFunctionTable != null) {
                    Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
                    for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                        entry.getValue().onResponse(groupTag, cell, iPos, 100);
                    }
                }
            } else {
                if (waitSendFirm) {
                    if (!TextUtils.isEmpty(getFirmFilePath())) {
                        sendBigFile(WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_DATA, getFirmFilePath(), 0);
                    }
                }
            }

            return;
        }
        byte[] toSendData = null;//文件内容加上应用层协议数据
        if (groupTag == WatchDataProtocol.TAG_GROUP_UPGRADE) {//发送升级包
            if (cell == WatchDataProtocol.UPGRADE_BLE_DATA) {
                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, progress);
                toSendData = WatchFormatManager.getUpgradeFileSendData(nextPos, bytes.length, mWatchBigDataSend.getData().length, bytes);
            } else if (cell == WatchDataProtocol.UPGRADE_BLE_APOLLO) {
                toSendData = WatchFormatManager.getUpgradeAploFileSendData(nextPos, bytes.length, mWatchBigDataSend.getData().length, bytes);
            }
        } else if (groupTag == WatchDataProtocol.TAG_GROUP_GPS) {//发送星历数据
            toSendData = WatchFormatManager.getGpsFileSendData(nextPos, bytes.length, mWatchBigDataSend.getData().length, bytes);
        }

        if (toSendData == null) {
            Logger.e(Logger.DEBUG_TAG, "WatchService--->sendBigFileNext 文件内容加上应用层协议生成的数据为空!");
            return;
        }

        Watch1024SendTempData tempData = new Watch1024SendTempData(Watch1024SendTempData.TYPE_FILE, tag, toSendData, nextPos, true);
        getWatchManager().addDataToSendQueue(tempData);
    }

    /**
     * 在指定文件中,从指定开始位置读取指定长度的数据到字节数组中
     *
     * @param fileName 文件名
     * @param data     保存读取数据的字节数组
     * @param startPos 从文件中开始读取的位置
     * @param readNum  需要读取的数据长度
     * @return 返回真正读取的长度
     */
    private int readBytesFromFile(String fileName, byte[] data, int startPos, int readNum) {
        int read = 0;
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(fileName, "r");
            read = randomAccessFile.read(data, startPos, readNum);
        } catch (Exception ex) {
            Logger.e(Logger.DEBUG_TAG, "WatchService-->readBytesFromFile error:" + ex.getMessage());
        }

        return read;
    }

    //endregion #################################### 发送数据 ####################################

    //endregion ================================== 应用层 总数据包中1024字节包的传输 ==================================

    //region ================================== 数据处理 ==================================

    /**
     * 处理手表发来的断点续传请求
     */
    private void handleBreakContinue(byte[] receivedTotalData, int groupTag) {
        String breakTagStr = WatchFormatManager.getStringContent(receivedTotalData, groupTag, WatchDataProtocol.REQUEST_TAG);//断点续传的tag
        String breakPosStr = WatchFormatManager.getStringContent(receivedTotalData, groupTag, WatchDataProtocol.REQUEST_POS);//断点续传的位置
        String breakTotalLenStr = WatchFormatManager.getStringContent(receivedTotalData, groupTag, WatchDataProtocol.REQUEST_TOTALLEN);//断点续传的总长度
        try {
            int breakTag = Integer.parseInt(breakTagStr);
            int breakPos = Integer.parseInt(breakPosStr);
            int breakTotalLen = Integer.parseInt(breakTotalLenStr);

            String bigFile = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_BIG_FILE);
            WatchBigFile watchBigFile = JsonHelper.getObject(bigFile, WatchBigFile.class);

            if (watchBigFile != null) {
                int breakGroupTag = WatchFormatManager.getGroupTagFromTag(breakTag);
                switch (breakGroupTag) {
                    case WatchDataProtocol.TAG_GROUP_UPGRADE://升级包数据
                        int cellFromTag = WatchFormatManager.getCellFromTag(breakTag);
                        Logger.i(Logger.DEBUG_TAG, "WatchService-->handleBreakContinue bigFile:" + bigFile + ",breakTag:" + breakTag + ",breakPos:" + breakPos
                                + ",breakTotalLen:" + breakTotalLen + ",breakGroupTag:" + breakGroupTag + ",cellFromTag:" + cellFromTag);
                        if (cellFromTag == WatchDataProtocol.UPGRADE_BLE_DATA) {
                            String upgradeFileName = watchBigFile.getUpgradeFileName();
                            sendBigFile(WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_DATA, upgradeFileName, breakPos);
                        } else if (cellFromTag == WatchDataProtocol.UPGRADE_BLE_APOLLO) {
                            String upgradeFileName = watchBigFile.getApolloFileName();
                            sendBigFile(WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_APOLLO, upgradeFileName, breakPos);
                        }
                        break;

                    case WatchDataProtocol.TAG_GROUP_GPS://星历数据
                        String gpsFileName = watchBigFile.getGpsFileName();
                        sendBigFile(WatchDataProtocol.TAG_GROUP_GPS, WatchDataProtocol.GPS_BLE_EPHEMERIS, gpsFileName, breakPos);
                        break;
                }
            }
        } catch (Exception ex) {
            Logger.e(Logger.DEBUG_TAG, "WatchService-->handleBreakContinue error:" + ex.getMessage());
        }
    }


    /**
     * 处理手表发来的升级,手表固件版本查询
     */
    private void handleWatchUpgrade(byte[] receivedTotalData, int groupTag) {
        WatchVersion watchVersion = new WatchVersion();
        String versionNum = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_VERSION_NO);
        String versionName = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_VERSIONS_NAME);
        String product = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_PRODUCT);
        String apolloVersionNum = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_APOLLO_VERSION_NO);

        watchVersion.setVersionNum(versionNum);
        watchVersion.setVersionName(versionName);
        watchVersion.setProduct(product);
        watchVersion.setApolloVersionNum(apolloVersionNum);
        String versionJsonString = JsonHelper.createJsonString(watchVersion);
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, versionJsonString);
            }
        }
    }

    /**
     * 处理手表发来的天气查询
     */
    private void handleWatchWeather(int groupTag) {
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, null);
            }
        }
    }

    /**
     * 处理手表发来的日常数据
     */
    private void handleDailyData(byte[] receivedTotalData, int groupTag) {
        WatchDailyData watchDailyData = new WatchDailyData();
        String battery = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_BATTERY_POWER);
        String step = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_STEPS);
        String walkStep = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_WALK_STEPS);
        String runStep = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_RUN_STEPS);
        String climbStairStep = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_CLIMB_STATIR_STEPS);
        watchDailyData.setBattery(battery);
        watchDailyData.setStep(step);
        watchDailyData.setWalkStep(walkStep);
        watchDailyData.setRunStep(runStep);
        watchDailyData.setClimbStairStep(climbStairStep);
        String jsonString = JsonHelper.createJsonString(watchDailyData);
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, jsonString);
            }
        }
        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_DAILY, jsonString);
    }

    /**
     * 处理手表发来的APP其它设置
     */
    private void handleAppOtherSetting(byte[] receivedTotalData, int groupTag) {
        WatchSetting watchSetting = new WatchSetting();
        String stormAlert = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_STORM_ALERT);
        String longRestAlert = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_LONG_REST_ALERT);
        String alarm1 = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM1);
        String alarm2 = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM2);
        String alarm3 = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM3);
        String alarm4 = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM4);
        String wristLifted = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_BL_ON_WHEN_WRIST_LIFTED);
        String dailyHr = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_DAILY_HR);
        String autoLock = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_AUTO_LOCK);
        String rightWrist = WatchFormatManager.getStringContent(receivedTotalData, WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_RIGHTWRIST);
        watchSetting.setStormAlert(stormAlert);
        watchSetting.setLongRestAlert(longRestAlert);
        watchSetting.setAlarm1(alarm1);
        watchSetting.setAlarm2(alarm2);
        watchSetting.setAlarm3(alarm3);
        watchSetting.setAlarm4(alarm4);
        watchSetting.setWristLifted(wristLifted);
        watchSetting.setDailyHr(dailyHr);
        watchSetting.setAutoLock(autoLock);
        watchSetting.setRightWrist(rightWrist);
        String watchSettingJsonString = JsonHelper.createJsonString(watchSetting);
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, watchSettingJsonString);
            }
        }
        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_SETTING, watchSettingJsonString);
    }

    /**
     * 处理手表发来的新增运动记录
     */
    private void handleAddLog(int groupTag, byte[] receivedTotalData) {
        //1.更新记录同步状态
        isSyncRecord = true;
        //2.通知界面
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, null);
            }
        }
        //3.方法一: 保存文件再用付工写的代码转换,目前只保存文件,不用付工写的so转换
        int dataLength = receivedTotalData.length - 34;
        if (dataLength <= 0) {
            Logger.e(Logger.DEBUG_TAG, "handleAddLog data not valid..");
            return;
        }
        List<DataProtocolItem> logItems = WatchFormatManager.getItems(receivedTotalData);
        String logFileName = WatchFormatManager.getLogFileName(getUserId(), logItems);
        byte[] logData = new byte[dataLength];//运动记录真正的内容,运动记录必须在一个1024字节包内传完
        System.arraycopy(receivedTotalData, 34, logData, 0, logData.length);//这里需要包括group
        if (logData != null && logFileName != null) {//写文件,收到运动同步完成后,用付工写的so转换
            saveFile(logData, true, logFileName);
        }

        //4.方法二: 自己解析,直接保存数据库,暂时不用
        WatchSportLog watchSportLog = WatchFormatManager.parseSportRecord(getUserId(), receivedTotalData);
        if (watchSportLog != null) {
            WatchSportDataHelper.insertOrReplaceWatchSportRecord(watchSportLog);
        }
    }

    /**
     * 处理手表发来的sensor数据(1024字节内)
     */
    private void handleSensorData(byte[] receivedTotalData) {
        List<DataProtocolItem> items = WatchFormatManager.getItems(receivedTotalData);
        String fileName = WatchFormatManager.getSensorFileName(getUserId(), items);
        byte[] data = null;//文件真正的内容
        for (DataProtocolItem item : items) {
            int itemTag = item.getTag();
            if (itemTag == -1) {//获取大文件内容
                data = item.getData();
            }
        }
        if (data != null && fileName != null) {//写文件,收到运动同步完成后,用付工写的so转换
            saveFile(data, true, fileName);
        }
    }

    /**
     * 处理手表发来的时间查询请求(1024字节内)
     */
    private void handleQueryTimeRequest() {
        long time = System.currentTimeMillis();
        SimpleDateFormat formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_DATA_FORMAT,
                Locale.getDefault());

        Date curDate = new Date(time);
        String date = formatterTime.format(curDate);
        formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_TIME_FORMAT, Locale.getDefault());
        String currentTime = formatterTime.format(curDate);
        int timeZone = TimeZone.getDefault().getOffset(time) / 3600000;
        byte[] data = WatchFormatManager.getSynchronizeTime(date, currentTime, String.valueOf(timeZone));
        if (data.length != 0) {
            int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_TIME, WatchDataProtocol.TIME_BLE_RESERVED);
            sendTotallyDataCmd(tag, data);
        }
    }


    private void handleErrorLogReceivedFinish(int tagErrorReport) {
        Logger.d(Logger.DEBUG_TAG, "handleErrorLogReceivedFinish -- to onReceiveDataRefreshUi");

        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(tagErrorReport, null);
            }
        }
    }

    /**
     * 处理手表发来的运动记录同步控制
     */
    private void handleSyncLogControl(int groupTag, byte[] receivedTotalData) {
        WatchSportLogSyncProgress progress = new WatchSportLogSyncProgress();
        WatchFormatManager.parseSportRecordDone(getUserId(), receivedTotalData, progress);
        //1.通知界面
        String dataJson = JsonHelper.createJsonString(progress);
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, dataJson);
            }
        }
        //2.更新记录同步状态
        isSyncRecord = false;

        totalLog = progress.getTotal();
        indexLog = progress.getIndex();
    }

    /**
     * 处理手表发来的gps星历数据查询请求
     */
    private void handleGpsEphemeris() {
        //1.从mtk网站下载星历数据
        final String epoFile = FitmixUtil.getWatchPath() + "epo.dat";
        if (FileUtils.isFileExist(epoFile)) {//删除历史数据
            FileUtils.deleteFile(epoFile);
        }
        mDownloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                Logger.e(Logger.DEBUG_TAG, "WatchService-->onDownloading");
            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                //1.发送最近7天用到的数据,每天9k,即文件前63k数据发送给手表
                if (FileUtils.isFileExist(epoFile)) {
                    try {
                        RandomAccessFile randomAccessFile = new RandomAccessFile(epoFile, "rw");
                        long length = randomAccessFile.length();
                        if (length >= 64512) {//63 * 1024
                            randomAccessFile.setLength(64512);
                            randomAccessFile.close();
                            sendBigFile(WatchDataProtocol.TAG_GROUP_GPS, WatchDataProtocol.GPS_BLE_EPHEMERIS, epoFile, 0);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                Logger.e(Logger.DEBUG_TAG, "WatchService-->onCompleted");
                //2.解绑下载服务
                unbindDownloadService();
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                Logger.e(Logger.DEBUG_TAG, "WatchService-->onFail");
                unbindDownloadService();
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                Logger.e(Logger.DEBUG_TAG, "WatchService-->onExist");
                //2.解绑下载服务
                unbindDownloadService();
            }
        };
        bindDownloadService();

        DownloadService.makeDownload(this, "http://epodownload.mediatek.com/EPO.DAT", epoFile, DownloadType.TYPE_FILE);
    }

    /**
     * 处理手表发来的绑定解绑事宜
     */
    private void handleBindUnbind(int groupTag, byte[] receivedTotalData) {
        //1.解析绑定或解绑结果
        List<DataProtocolItem> dataItems = WatchFormatManager.getItems(receivedTotalData);
        String dataJson = null;
        if (dataItems != null) {
            WatchBindUnbind watchBindUnbind = new WatchBindUnbind();
            for (int i = 0; i < dataItems.size(); i++) {//打印
                Logger.i(Logger.DEBUG_TAG, i + ":" + dataItems.get(i));
            }

            String content;
            for (DataProtocolItem item : dataItems) {
                switch (item.getCell()) {
                    case WatchDataProtocol.BIND_BLE_BIND:
                        watchBindUnbind.setType(1);
                        break;

                    case WatchDataProtocol.BIND_BLE_UNBIND:
                        watchBindUnbind.setType(2);
                        break;

                    case WatchDataProtocol.BIND_BLE_SN:
                        content = WatchFormatManager.parseBytesByDataType(item.getDataType(), item.getData());
                        watchBindUnbind.setSn(content);
                        break;

                    case WatchDataProtocol.BIND_BLE_CHIPID:
                        content = WatchFormatManager.parseBytesByDataType(item.getDataType(), item.getData());
                        watchBindUnbind.setChipId(content);
                        break;

                    case WatchDataProtocol.BIND_BLE_BIND_RESULT:
                        content = WatchFormatManager.parseBytesByDataType(item.getDataType(), item.getData());
                        int bindResult = Integer.parseInt(content);
                        watchBindUnbind.setResult(bindResult);
                        watchBindUnbind.setType(1);
                        break;

                    case WatchDataProtocol.BIND_BLE_UNBIND_RESULT:
                        content = WatchFormatManager.parseBytesByDataType(item.getDataType(), item.getData());
                        int unbindResult = Integer.parseInt(content);
                        watchBindUnbind.setResult(unbindResult);
                        watchBindUnbind.setType(2);
                        break;
                }

            }
            dataJson = JsonHelper.createJsonString(watchBindUnbind);
        }

        //2.通知界面
        if (serviceFunctionTable != null) {
            Set<Map.Entry<String, ServiceFunction>> entrySet = serviceFunctionTable.entrySet();
            for (Map.Entry<String, ServiceFunction> entry : entrySet) {
                entry.getValue().onReceiveDataRefreshUi(groupTag, dataJson);
            }
        }
    }

    //endregion ================================== 数据处理 ==================================

    //region ================================== 文件上传下载 ==================================

    private DownloadService mDownloadService;
    private DownloadInfoListener mDownloadListener;
    private ServiceConnection serviceConnection;

    /**
     * 绑定下载或上传服务
     */
    private void bindDownloadService() {
        Intent intent = new Intent(this, DownloadService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mDownloadService = ((DownloadService.GetServiceClass) service).getService();
                    if (mDownloadService == null)
                        return;

                    if (mDownloadListener != null) {//注册下载状态监听
                        mDownloadService.addDownloadListener(mDownloadListener);
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mDownloadService == null)
                        return;
                    if (mDownloadListener != null) {//注销下载状态监听
                        mDownloadService.removeDownloadListener(mDownloadListener);
                    }
                }
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        Logger.i(Logger.DEBUG_TAG, "WatchService-->bindDownloadService");
    }

    /**
     * 解绑下载或上传服务
     */
    private void unbindDownloadService() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        serviceConnection = null;
        mDownloadListener = null;
        Logger.i(Logger.DEBUG_TAG, "WatchService-->unbindDownloadService");
    }

    //endregion ================================== 文件上传下载 ==================================

    //region ================================== app的消息通知 ==================================

    /**
     * 注册手机消息通知
     */
    private void registerNotification() {
        if (isNotificationListenEnabled()) {
            ensureNotificationListener();
        }
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(onNotice, new IntentFilter(NotificationMonitor.NOTIFICATION_BROADCAST_TAG));
    }

    /**
     * 注销手机消息通知
     */
    private void unregisterNotification() {
        if (onNotice != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(onNotice);
        }
        onNotice = null;
    }


    private void ensureNotificationListener() {
        ComponentName collectorComponent = new ComponentName(this, NotificationMonitor.class);
        Logger.v(Logger.LOG_TAG, "ensureNotificationListener collectorComponent: " + collectorComponent);
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        boolean collectorRunning = false;
        List<ActivityManager.RunningServiceInfo> runningServices = manager.getRunningServices(Integer.MAX_VALUE);
        if (runningServices == null) {
            Logger.w(Logger.LOG_TAG, "ensureNotificationListener() runningServices is NULL");
            return;
        }
        for (ActivityManager.RunningServiceInfo service : runningServices) {
            if (service.service.equals(collectorComponent)) {
                collectorRunning = true;
            }
        }
        if (collectorRunning) {
            Logger.d(Logger.LOG_TAG, "ensureNotificationListener: collector is running");
            return;
        }
        Logger.d(Logger.LOG_TAG, "ensureNotificationListener: collector not running, reviving...");
        toggleNotificationListenerService();
    }

    /**
     * 判断当前应用是否有监听通知的权限
     *
     * @return true:是,false:否
     */
    public boolean isNotificationListenEnabled() {
        String pkgName = getPackageName();
        final String flat = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private void toggleNotificationListenerService() {
        Logger.d(Logger.LOG_TAG, "toggleNotificationListenerService() called");
        ComponentName thisComponent = new ComponentName(this, /*getClass()*/ NotificationMonitor.class);
        if (Build.VERSION.SDK_INT > 24) {
            NotificationListenerService.requestRebind(thisComponent);
            PackageManager pm = getPackageManager();
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        } else {
            PackageManager pm = getPackageManager();
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            pm.setComponentEnabledSetting(thisComponent, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        }
    }

    /**
     * 消息接收通知回调
     */
    private BroadcastReceiver onNotice = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) {
                Logger.e(Logger.DEBUG_TAG, "BroadcastReceiver onReceive intent is null:" + (intent == null));
                return;
            }
            String pack = intent.getStringExtra("package");
            String title = intent.getStringExtra("title");
            String text = intent.getStringExtra("text");

            try {
//                byte[] byteArray = intent.getByteArrayExtra("icon");
//                Bitmap bmp = null;
//                if (byteArray != null) {
//                    bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//                }

                Logger.d(Logger.DEBUG_TAG, String.format("pack:%s\ntitle:%s\ntext:%s\n", pack, title, text));

                long time = System.currentTimeMillis();
                SimpleDateFormat formatterTime = new SimpleDateFormat("yyyyMMdd",
                        Locale.getDefault());

                Date curDate = new Date(time);
                String date = formatterTime.format(curDate);
                formatterTime = new SimpleDateFormat("HHmmss", Locale.getDefault());
                String currentTime = formatterTime.format(curDate);

                Logger.d(Logger.DEBUG_TAG, date + "+" + currentTime);

                if ("android.server.telecom".equals(pack)) {//来电
                    if (text.equals(context.getString(R.string.activity_watch_notify_setting_incoming_call_receive))) {//接听
                        byte[] data = WatchFormatManager.getPhoneCallData(title, WatchDataProtocol.CALL_BLE_ANSWER);
                        int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_CALL, WatchDataProtocol.NOTIFICATION_BLE_INCOMINGCALL);
                        sendTotallyDataCmd(tag, data);
                    } else if (text.equals(context.getString(R.string.activity_watch_notify_setting_incoming_call_idle))) {//挂断
                        byte[] data = WatchFormatManager.getPhoneCallData(title, WatchDataProtocol.CALL_BLE_DECLINE);
                        int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_CALL, WatchDataProtocol.NOTIFICATION_BLE_INCOMINGCALL);
                        sendTotallyDataCmd(tag, data);
                    } else {
                        byte[] data = WatchFormatManager.getPhoneCallData(title, WatchDataProtocol.CALL_BLE_INCOMING);//来电
                        int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_CALL, WatchDataProtocol.NOTIFICATION_BLE_INCOMINGCALL);
                        sendTotallyDataCmd(tag, data);
                    }

                } else {
                    int msgType = WatchFormatManager.getMsgType(pack);
                    if (msgType == -1) {
                        Logger.e(Logger.DEBUG_TAG, "msgType == -1");
                        return;
                    }
                    byte[] data = WatchFormatManager.getNotification(msgType, title, date, currentTime, text);
                    //cell本来是要传msgType的,但手表对此请求回复结果的tag是00006400
                    int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_NOTIFICATION, WatchDataProtocol.NOTIFICATION_BLE_RESERVED);
                    sendTotallyDataCmd(tag, data);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };


    //endregion ================================== app的消息通知 ==================================

    //region ================================== 来电的app电话挂断操作 ==================================
    private void declinePhone() {
        try {
            //获取到ServiceManager
            Class<?> clazz = Class.forName("android.os.ServiceManager");
            //获取到ServiceManager里面的方法
            Method method = clazz.getDeclaredMethod("getService", String.class);
            //通过反射的方法调用方法
            IBinder iBinder = (IBinder) method.invoke(null, TELEPHONY_SERVICE);
            ITelephony iTelephony = ITelephony.Stub.asInterface(iBinder);
            iTelephony.endCall();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //endregion ================================== 来电的app电话挂断操作 ==================================

    //region ================================ 手表蓝牙状态监听 ================================
    private BroadcastReceiver mStatusReceive = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case BluetoothAdapter.ACTION_STATE_CHANGED:
                    int blueState = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
                    switch (blueState) {
                        case BluetoothAdapter.STATE_TURNING_ON:
                            break;
                        case BluetoothAdapter.STATE_ON:
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            break;
                        case BluetoothAdapter.STATE_OFF:
                            Logger.d(Logger.DEBUG_TAG, "WatchService 蓝牙关闭了");
                            if (mDevice != null) {
                                disconnectDeviceAndRefreshView();
                            }
                            break;
                    }
                    break;
            }
        }
    };

    //endregion ================================ 手表蓝牙状态监听 ================================
}
