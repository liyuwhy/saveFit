package com.fitmix.sdk.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.RemoteViews;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.cache.HttpProxyCacheServer;
import com.fitmix.sdk.common.sound.PlayerController;

/**
 * 音乐播放服务
 */
public class PlayerService extends Service {

    public static final String NOTIFICATION_CHANNEL_ID = "10002";
    /**
     * PlayerService 名称
     */
    public static final String SERVICE_NAME = PlayerService.class.getName();

    //region ============================= 自定义接口,类 ===================================

    /**
     * 音乐播放状态
     */
    private class MusicPlayerState {
        public static final int STATE_IDLE = 0;
        public static final int STATE_INIT = 1;
        public static final int STATE_PREPARED = 2;
        public static final int STATE_PREPARING = 3;
        public static final int STATE_STARTED = 4;
        public static final int STATE_PAUSED = 5;
        public static final int STATE_STOPPED = 6;
        public static final int STATE_ENDED = 7;
        public static final int STATE_ERROR = 8;
        public static final int STATE_PLAY_COMPLETED = 9;
        private int mState;

        public MusicPlayerState() {
            mState = STATE_IDLE;
        }


        /**
         * 设置播放状态码
         *
         * @param state [0,9]
         */
        public void setState(int state) {
//            long now = System.currentTimeMillis();
//            Log.d(FitmixConstant.TAG, "from " + getStateName(mState) + " to "
//                    + getStateName(state) + " time:" + (now - lLastStateTime));
            mState = state;
        }

        public int getState() {
            return mState;
        }

        public boolean isCanStop() {
            switch (mState) {
                case STATE_STOPPED:
                case STATE_PREPARED:
                case STATE_STARTED:
                case STATE_PAUSED:
                case STATE_PLAY_COMPLETED:
                    return true;
            }
            return false;
        }

        public boolean isCanPause() {
            switch (mState) {
                case STATE_STARTED:
                case STATE_PAUSED:
                    return true;
            }
            return false;
        }

        public boolean isCanResume() {
            switch (mState) {
                case STATE_STARTED:
                case STATE_PAUSED:
                case STATE_PREPARED:
                case STATE_PLAY_COMPLETED:
                    return true;
            }
            return false;
        }

        public boolean isCanSeek() {
            switch (mState) {
                case STATE_STARTED:
                case STATE_PAUSED:
                case STATE_PREPARED:
                case STATE_PLAY_COMPLETED:
                    return true;
            }
            return false;
        }

        public boolean isCanGetDuration() {
            switch (mState) {
                case STATE_STARTED:
                case STATE_PAUSED:
                case STATE_PREPARED:
                    return true;
            }
            return false;
        }
    }

    /**
     * 音乐播放完成回调接口
     */
    public interface OnMusicCompleteListener {
        /**
         * 音乐播放完成回调
         */
        void onMusicComplete();
    }

    //endregion ============================= 自定义接口,类 ===================================
    private MediaPlayer musicPlayer;

    private MediaPlayer getMediaPlayer() {
        if (musicPlayer == null) {
            musicPlayer = new MediaPlayer();
        }
        return musicPlayer;
    }

    private OnMusicCompleteListener onMusicCompleteListener;

    /**
     * 设置音乐播放完成事件回调
     *
     * @param listener 音乐播放完成事件回调
     */
    public void setOnMusicCompleteListener(OnMusicCompleteListener listener) {
        this.onMusicCompleteListener = listener;
    }

    //private Music musicInfo;//当前在播放器的音乐信息
    private boolean bPausedByAudioFocus;
    private boolean bPausedByPhone;//来电话时,暂停
    private String mUrl;
    private int mUrlType;

    public int getUrlType() {
        return mUrlType;
    }

    private boolean isAudioPrepared;//是否资源加载完成，在OnPreparedListener.onPrepared()执行时才设为true

    public boolean isAudioPrepared() {
        return isAudioPrepared;
    }

    private boolean bEnableAutoPlay;//是否可以自动播放

    public void changeBEnableAutoPlay() {
        this.bEnableAutoPlay = !bEnableAutoPlay;
        if (bEnableAutoPlay) {
            notifyChange(Config.MUSIC_PLAY_START);
            notifyChange(Config.MUSIC_PLAY_STATE_CHANGED);
        } else {
            notifyChange(Config.MUSIC_PLAY_STATE_CHANGED);
        }
    }

    private MusicPlayerState mMusicState;
    private long mStartPlayTimeStamp = 0;//音乐播放器开始播放的时间戳,用于友盟音乐播放时长统计
    private long mPlayDuration = 0;//播放时长,单位为秒,用于友盟音乐播放时长统计

    private int mBufferingPercent = 0;//音频缓冲进度

    public int getBufferingPercent() {
        return mBufferingPercent;
    }

    private MusicPlayerState getMusicPlayerState() {
        if (mMusicState == null)
            mMusicState = new MusicPlayerState();
        return mMusicState;
    }

    private MyConfig getMyConfig() {
        return MyConfig.getInstance();
    }


    //region ========================== MediaPlayer事件回调 =================================

    private final OnInfoListener infoListener = new OnInfoListener() {
        @Override
        public boolean onInfo(MediaPlayer mp, int what, int extra) {
//            Logger.d(Logger.DEBUG_TAG, "PlayerService onInfo:" + what + ","
//                    + extra);
            return getMediaPlayer() == mp;
        }

    };

    private final OnErrorListener errorListener = new OnErrorListener() {

        @Override
        public boolean onError(MediaPlayer mp, int what, int extra) {
            Logger.e(Logger.DEBUG_TAG, "PlayerService-->dispatchDownFail mp is null:" + (mp == null) + " what:" + what + " extra:" + extra);
            if (getMediaPlayer() != mp)
                return false;
            getMusicPlayerState().setState(MusicPlayerState.STATE_ERROR);
            if (mUrl == null || mUrl.isEmpty())
                return false;
            bEnableAutoPlay = true;
            loadMusic(mUrl, mUrlType);
            return false;
        }

    };

    private final OnBufferingUpdateListener bufferingUpdateListener = new OnBufferingUpdateListener() {
        @Override
        public void onBufferingUpdate(MediaPlayer mp, int percent) {//只限于网络加载资源的情况下，因此当加载本地文件时，直接发送预加载100%的广播
            if (getMediaPlayer() != mp)
                return;
            mBufferingPercent = percent;
            notifyChange(Config.MUSIC_BUFFERINGUPDATE);
        }
    };

    private final OnPreparedListener prepareListener = new OnPreparedListener() {
        @Override
        public void onPrepared(MediaPlayer mp) {
//            Logger.d(Logger.DEBUG_TAG, "PlayerService-->onPrepared mp is null:" + (mp == null));
            if (getMediaPlayer() != mp)
                return;
            isAudioPrepared = true;//资源加载成功

            getMusicPlayerState().setState(MusicPlayerState.STATE_PREPARED);
            getMediaPlayer().setOnCompletionListener(completeListener);
            bPausedByPhone = false;
            bPausedByAudioFocus = false;
            if (!bEnableAutoPlay) {
                //资源加载成功，但是不自动播放，进度条上总时长需要更改
                bEnableAutoPlay = true;
                notifyChange(Config.MUSIC_PREPARED);
                return;
            }
            resumeMusic();
            sendNotification();
        }

    };
    private final OnCompletionListener completeListener = new OnCompletionListener() {

        @Override
        public void onCompletion(MediaPlayer mp) {
//            Logger.d(Logger.DEBUG_TAG,"PlayerService-->onCompletion");
            if (getMediaPlayer() != mp)
                return;
            getMusicPlayerState()
                    .setState(MusicPlayerState.STATE_PLAY_COMPLETED);
            if (onMusicCompleteListener != null) {
                onMusicCompleteListener.onMusicComplete();
            }
        }
    };

    //endregion ========================== MediaPlayer事件回调 =================================

    //region ========================== 来电状态监听 =================================
    private final PhoneStateListener phoneStateListener = new PhoneStateListener() {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            super.onCallStateChanged(state, incomingNumber);
//            Log.d(FitmixConstant.TAG, "PlayerSrvice onCallStateChanged:"
//                    + state + ",bPausedByPhone:" + bPausedByPhone);
            switch (state) {
                case TelephonyManager.CALL_STATE_IDLE:
                    if (runService != null) {
                        runService.resumeVoiceByAudioOrPhone();
                    }
                    if (skipService != null) {
                        skipService.resumeVoiceByAudioOrPhone();
                    }
                    if (bPausedByPhone)
                        resumeMusic();
                    bPausedByPhone = false;
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                case TelephonyManager.CALL_STATE_RINGING:
                    if (runService != null) {
                        runService.pauseVoiceByAudioOrPhone();
                    }
                    if (skipService != null) {
                        skipService.pauseVoiceByAudioOrPhone();
                    }
                    if (!isPlaying())
                        break;
                    pauseMusic();
                    bPausedByPhone = true;
                    break;
            }
        }
    };

    /**
     * 注册电话状态监听
     */
    private void registerTelephonyListen() {
        TelephonyManager tm = (TelephonyManager) getSystemService(Service.TELEPHONY_SERVICE);
        if (tm == null)
            return;
        try {
            tm.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注销电话状态监听
     */
    private void unregisterTelephonyListen() {
        TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (tm == null)
            return;
        try {
            tm.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //endregion ========================== 来电状态监听 =================================

    //region ========================== 声音焦点状态监听 =================================

    private final AudioManager.OnAudioFocusChangeListener afChangeListener = new AudioManager.OnAudioFocusChangeListener() {

        @Override
        public void onAudioFocusChange(int focusChange) {
//            Log.d(FitmixConstant.TAG, "PlayerSrvice onAudioFocusChange:"
//                    + focusChange);
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    if (runService != null) {
                        runService.pauseVoiceByAudioOrPhone();
                    }
                    if (!isPlaying())
                        return;
                    bPausedByAudioFocus = true;
                    pauseMusic();
                    sendNotification();
                    break;
                case AudioManager.AUDIOFOCUS_GAIN:
                case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT:
                    if (runService != null) {
                        runService.resumeVoiceByAudioOrPhone();
                    }
                    if (!bPausedByAudioFocus)
                        return;
                    bPausedByAudioFocus = false;
                    setVolume(1.0f);
                    resumeMusic();
                    sendNotification();
                    break;
            }
        }
    };

    /**
     * 申请获取声音焦点
     */
    private void requestAudioFocus() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am == null)
            return;
        am.requestAudioFocus(afChangeListener, AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN);
    }

    /**
     * 放弃声音焦点
     */
    private void abandonAudioFocus() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am == null)
            return;
        am.abandonAudioFocus(afChangeListener);
    }

    //endregion ========================== 声音焦点状态监听 =================================

    //region ========================== 自定义音乐控制Receiver =================================

    private final BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
//			Log.d(FitmixConstant.TAG, "PlayerService mIntentReceiver:" + action
//					+ "," + cmd);
            String cmd = intent.getStringExtra(PlayerController.ACTION_WHAT);
            if (PlayerController.ACTION_NEXT.equals(cmd)) {
                nextMusic();
            } else if (PlayerController.ACTION_PREV.equals(cmd)) {
                prevMusic();
            } else if (PlayerController.ACTION_SWITCH.equals(cmd)) {
                switchMusic();
                sendNotification();
            }
        }
    };

    /**
     * 注册下一首,上一首,暂停或继续播放广播
     */
    private void registerMyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(PlayerController.ACTION_INTENT);
        registerReceiver(mIntentReceiver, intentFilter);
    }

    //endregion ========================== 自定义音乐控制Receiver =================================

    //region ========================== Service 生命周期相关 =================================
    public class MyBinder extends Binder {
        public PlayerService getService() {
            return PlayerService.this;
        }
    }


    @Override
    public void onCreate() {
        super.onCreate();
        //1.注册MediaPlayer事件回调
        getMediaPlayer().setOnInfoListener(infoListener);
        getMediaPlayer().setOnErrorListener(errorListener);
        getMediaPlayer().setOnPreparedListener(prepareListener);
        getMediaPlayer().setOnBufferingUpdateListener(bufferingUpdateListener);
        //2.注册自定义播放广播
        registerMyReceiver();
        //3.注册电话状态监听
        registerTelephonyListen();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        Log.d(FitmixConstant.TAG, "PlayerService onStartCommand");
        processIntent(intent);
        return super.onStartCommand(intent, flags, startId);
    }

    private void processIntent(Intent intent) {
        if (intent == null)
            return;
        String action = intent.getStringExtra(PlayerController.ACTION_WHAT);
        if (TextUtils.isEmpty(action))
            return;

        String url = intent.getStringExtra(PlayerController.KEY_URL);
        int urlType = intent.getIntExtra(PlayerController.URL_TYPE, PlayerController.URL_TYPE_ONLINE);

        switch (action) {
            case PlayerController.ACTION_PLAY_MUSIC://音乐播放
                bEnableAutoPlay = true;
                loadMusic(url, urlType);
                sendNotification();
                break;
            case PlayerController.ACTION_LOAD_MUSIC://加载音乐
                bEnableAutoPlay = false;
                loadMusic(url, urlType);
                sendNotification();
                break;
            case PlayerController.ACTION_SEEK_TIME://从指定时间播放
                int time = intent.getIntExtra(PlayerController.KEY_SEEK_TIME, 0);
                seekToTime(time);
                sendNotification();
                break;
            case PlayerController.ACTION_PAUSE://暂停播放
                pauseMusic();
                sendNotification();
                break;
            case PlayerController.ACTION_RESUME://继续播放
                resumeMusic();
                sendNotification();
                break;
            case PlayerController.ACTION_STOP://停止播放
                bEnableAutoPlay = false;
                stopMusic();
                break;
            case PlayerController.ACTION_SWITCH://切换音乐播放状态
                switchMusic();
                sendNotification();
                break;
            case PlayerController.ACTION_PREV://播放mix音乐中上一个音乐片段
                prevMusic();
                sendNotification();
                break;
            case PlayerController.ACTION_NEXT://播放mix音乐中下一个音乐片段
                nextMusic();
                sendNotification();
                break;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        Logger.i(Logger.DEBUG_TAG, "PlayerService onBind:");
        return new MyBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Logger.i(Logger.DEBUG_TAG, "PlayerService onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        //1.注销自定义广播
        unregisterReceiver(mIntentReceiver);
        //2.注销电话监听
        unregisterTelephonyListen();
        //3.结束音乐播放器
        clearNotification();
        releaseResource();
        super.onDestroy();
        Logger.i(Logger.DEBUG_TAG, "PlayService-->onDestroy");
    }

    /**
     * 释放音乐播放器资源
     */
    private void releaseResource() {
        if (getMusicPlayerState().isCanStop())
            getMediaPlayer().stop();
        getMusicPlayerState().setState(MusicPlayerState.STATE_STOPPED);
        getMediaPlayer().reset();
        getMusicPlayerState().setState(MusicPlayerState.STATE_IDLE);
        getMediaPlayer().release();
        getMusicPlayerState().setState(MusicPlayerState.STATE_ENDED);

    }

    //endregion ========================== Service 生命周期相关 =================================

    //region ========================== 音乐播放操作相关 =================================

    /**
     * 根据操作类型不同发送不同的广播
     *
     * @param what
     */
    private void notifyChange(String what) {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
        Intent intent = new Intent();
        intent.setAction(what);
        lbm.sendBroadcast(intent);
    }

    /**
     * 暂停播放音乐
     */
    private void pauseMusic() {
        if (!getMusicPlayerState().isCanPause())
            return;
        getMediaPlayer().pause();
        getMusicPlayerState().setState(MusicPlayerState.STATE_PAUSED);
        getMyConfig().getPlayer().setIsActionPlay(false);
        //abandonAudioFocus();
        //友盟统计音乐播放时长
        mPlayDuration += System.currentTimeMillis() - mStartPlayTimeStamp;
        notifyChange(Config.MUSIC_PLAY_STATE_CHANGED);
    }

    /**
     * 继续播放音乐
     */
    private void resumeMusic() {
        if (!getMusicPlayerState().isCanResume())
            return;
        getMediaPlayer().start();
        getMusicPlayerState().setState(MusicPlayerState.STATE_STARTED);
        getMyConfig().getPlayer().setIsActionPlay(true);
        requestAudioFocus();
        //友盟统计音乐播放时长
        mStartPlayTimeStamp = System.currentTimeMillis();
        notifyChange(Config.MUSIC_PLAY_START);
        notifyChange(Config.MUSIC_PLAY_STATE_CHANGED);
    }

    /**
     * 停止播放音乐
     */
    private void stopMusic() {
        if (!getMusicPlayerState().isCanStop())
            return;
        getMediaPlayer().stop();
        getMusicPlayerState().setState(MusicPlayerState.STATE_STOPPED);
        abandonAudioFocus();
        notifyChange(Config.MUSIC_PLAY_STOP);
        clearNotification();
        Logger.i(Logger.DEBUG_TAG, "PlayerService-->stopMusic");
        //友盟统计音乐播放时长
        if (mPlayDuration > 10000) {
            UmengAnalysisHelper.getInstance().musicPlayDurationReportPlus(getApplicationContext(), mPlayDuration / 1000);
        }
        mStartPlayTimeStamp = 0;
        mPlayDuration = 0;
    }

    /**
     * 跳转到指定时间播放
     *
     * @param time 指定时间,单位为毫秒
     */
    private void seekToTime(int time) {
        if (!getMusicPlayerState().isCanSeek())
            return;
//        Log.d(FitmixConstant.TAG, "seekToTime:" + time);
        getMediaPlayer().seekTo(time);
    }

    /**
     * 加载音乐
     *
     * @param url     音乐资源url,支持http/rtsp和file-path
     * @param urlType
     */
    private void loadMusic(final String url, final int urlType) {
        if (url == null || url.isEmpty())
            return;
        //MediaPlayer.reset()等方法有时耗时较长,造成卡顿
        ThreadManager.executeOnSubThread1(new Runnable() {
            @Override
            public void run() {
                try {
//                    long start = System.currentTimeMillis();
//                  Logger.i(Logger.DEBUG_TAG, "PlayerService-->loadMusic url:" + url);
                    getMediaPlayer().setOnCompletionListener(null);
                    stopMusic();

                    isAudioPrepared = false;//资源未加载成功

                    if (getMusicPlayerState().getState() != MusicPlayerState.STATE_IDLE) {
                        getMediaPlayer().reset();
                    }
//                    Logger.i(Logger.DEBUG_TAG, "PlayerService-->loadMusic duration1:" + (System.currentTimeMillis() - start));
                    getMusicPlayerState().setState(MusicPlayerState.STATE_IDLE);
                    getMediaPlayer().setAudioStreamType(AudioManager.STREAM_MUSIC);

                    if (urlType == PlayerController.URL_TYPE_ONLINE) {
                        HttpProxyCacheServer proxy = MixApp.getProxy(getApplicationContext());
                        if (proxy != null) {
                            getMediaPlayer().setDataSource(proxy.getProxyUrl(url));
                        }
                    } else if (urlType == PlayerController.URL_TYPE_LOCAL || urlType == PlayerController.URL_TYPE_LOCAL_TEMP) {
                        getMediaPlayer().setDataSource(url);
                    }
//                    Logger.i(Logger.DEBUG_TAG, "PlayerService-->loadMusic duration2:" + (System.currentTimeMillis() - start));
                    getMusicPlayerState().setState(MusicPlayerState.STATE_INIT);
                    getMediaPlayer().prepareAsync();
                    getMusicPlayerState().setState(MusicPlayerState.STATE_PREPARING);
                    mUrl = url;
                    PlayerService.this.mUrlType = urlType;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    /**
     * 切换音乐播放状态,(暂停-->播放 或者 播放-->暂停)
     */
    public void switchMusic() {
        if (isPlaying())
            pauseMusic();
        else
            resumeMusic();
    }

    /**
     * 播放Mix音乐上一个音乐片段或者普通音乐快退
     */
    public void prevMusic() {
        int iPos = getCurrentPosition() / 1000;
        int iNewPos = iPos - Config.MUSIC_NEXT_SEGMENT_TIME;
        if (iNewPos <= 0)
            iNewPos = 0;
        seekToTime(iNewPos * 1000);
    }

    /**
     * 播放Mix音乐下一个音乐片段或者普通音乐快进
     */
    public void nextMusic() {
        int iPos = getCurrentPosition() / 1000;
        int iNewPos = iPos + Config.MUSIC_NEXT_SEGMENT_TIME;
        if (iNewPos >= getDuration() / 1000)
            iNewPos = 0;
        seekToTime(iNewPos * 1000);
    }

    //endregion ========================== 音乐播放操作相关 =================================

    //region ========================== 音乐信息相关 =================================

    /**
     * 获取音乐是否播放中
     *
     * @return true:是, false:否
     */
    public boolean isPlaying() {
        return (getMusicPlayerState().getState() == MusicPlayerState.STATE_STARTED);
    }

    /**
     * 获取音乐时长
     *
     * @return 音乐时长, 单位为毫秒
     */
    public int getDuration() {
        if (!getMusicPlayerState().isCanGetDuration())
            return 0;
        try {
            return getMediaPlayer().getDuration();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 设置播放器音量
     *
     * @param volume 音量
     */
    public void setVolume(float volume) {
        if (!getMusicPlayerState().isCanResume())
            return;
        try {
            getMediaPlayer().setVolume(volume, volume);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取当前音乐播放时间位置
     *
     * @return 当前音乐播放位置, 单位毫秒
     */
    public int getCurrentPosition() {
        if (!getMusicPlayerState().isCanGetDuration())
            return 0;
        try {
            return getMediaPlayer().getCurrentPosition();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

//    /**
//     * 设置当前播放音乐信息
//     *
//     * @param musicInfo 当前播放音乐信息
//     */
//    public void setMusicInfo(Music musicInfo) {
//        Logger.i(Logger.DEBUG_TAG, "playerService  --- setMusicInfo > musicName : " + musicInfo.getName());
//        this.musicInfo = musicInfo;
//    }

    /**
     * 获取当前播放音乐信息
     *
     * @return 当前播放音乐信息
     */
    public Music getMusicInfo() {
        return PlayerController.getInstance().getCurrentMusic();
    }

    /**
     * 获取当前音乐播放器状态码
     *
     * @return 0:STATE_IDLE 1:STATE_INIT  2:STATE_PREPARED  3:STATE_PREPARING  4:STATE_STARTED,
     * 5:STATE_PAUSED  6:STATE_STOPPED  7:STATE_ENDED  8:STATE_ERROR  9:STATE_PLAY_COMPLETED
     */
    public int getState() {
        return getMusicPlayerState().getState();
    }

    //endregion ========================== 音乐信息相关 =================================

    //region ========================== 通知栏信息相关 =================================
    private final int NOTIFICATION_ID = 0x2345;

    /**
     * 发送音乐播放通知栏,并将音乐播放Service前台运行方式
     */
    private void sendNotification() {
        if (getMusicInfo() == null) {
            clearNotification();
            return;
        }

        RemoteViews views = new RemoteViews(getPackageName(),
                R.layout.notification_player_service);

        views.setTextViewText(R.id.album_name, getMusicInfo().getName());
        views.setTextViewText(R.id.album_bpm, String.format(" %s %s ", getResources().getString(R.string.fm_runmain_music_beat)
                , getMusicInfo().getBpm()));

        if (isPlaying()) {
            views.setImageViewResource(R.id.pause, R.drawable.run_main_pause);
        } else {
            views.setImageViewResource(R.id.pause, R.drawable.run_main_play);
        }

        views.setOnClickPendingIntent(R.id.prev, prePendingIntent());
        views.setOnClickPendingIntent(R.id.pause, pausePendingIntent());
        views.setOnClickPendingIntent(R.id.next, nextPendingIntent());

        NotificationCompat.Builder builder= new NotificationCompat.Builder(this)
                .setContent(views)
                .setSmallIcon(R.drawable.notification_icon)
                .setShowWhen(true)
                .setWhen(100000)//防止部分机型更新通知栏时闪烁
                .setAutoCancel(true);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context
                    .NOTIFICATION_SERVICE);
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "音乐播放", importance);
            notificationChannel.enableLights(false);
            notificationChannel.setLightColor(Color.RED);
            // notificationChannel.setSound(null,null);
            notificationChannel.enableVibration(false);
            // notificationChannel.setVibrationPattern(new long[]{0});
            mNotificationManager.createNotificationChannel(notificationChannel);
            builder.setChannelId(NOTIFICATION_CHANNEL_ID);
        }

        Notification notification = builder.build();

        notification.flags = Notification.FLAG_AUTO_CANCEL;

        startForeground(NOTIFICATION_ID, notification);
//        Logger.i(Logger.DEBUG_TAG, "PlayService-->sendNotification");
    }

    private PendingIntent prePendingIntent() {
        return getMyPendingIntent(PlayerController.ACTION_PREV);
    }

    private PendingIntent pausePendingIntent() {
        return getMyPendingIntent(PlayerController.ACTION_SWITCH);
    }

    private PendingIntent nextPendingIntent() {
        return getMyPendingIntent(PlayerController.ACTION_NEXT);
    }

    private PendingIntent getMyPendingIntent(String action) {
//        Log.d(FitmixConstant.TAG, "PlayerService getMyPendingIntent:" + action);
        if (TextUtils.isEmpty(action))
            return null;
        Intent intent = new Intent(PlayerController.ACTION_INTENT);
        intent.putExtra(PlayerController.ACTION_WHAT, action);

        int requestCode = -1;
        switch (action) {
            case PlayerController.ACTION_PREV:
                requestCode = 0;
                break;
            case PlayerController.ACTION_SWITCH:
                requestCode = 1;
                break;
            case PlayerController.ACTION_NEXT:
                requestCode = 2;
                break;
        }

        return PendingIntent.getBroadcast(this, requestCode,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /**
     * 清除音乐播放通知栏,并结束音乐播放Service前台运行方式
     */
    private void clearNotification() {
        stopForeground(true);
//        Logger.i(Logger.DEBUG_TAG, "PlayService-->clearNotification");
    }
    //endregion ========================== 通知栏信息相关 =================================

    /**
     * 服务绑定状态
     */
    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (name.getClassName().equals(RunService.SERVICE_NAME)) {//跑步服务
                runService = ((RunService.LocalBinder) service).getService();
            } else if (name.getClassName().equals(SkipService.SERVICE_NAME)) {//跳绳服务
                skipService = ((SkipService.LocalBinder) service).getService();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (name.getClassName().equals(RunService.SERVICE_NAME)) {//跑步服务
                runService = null;
            } else if (name.getClassName().equals(SkipService.SERVICE_NAME)) {//跳绳服务
                skipService = null;
            }


        }
    };


    //region ========================== 与RunService交互相关 =================================
    private RunService runService;

    /**
     * 绑定跑步服务
     */
    private void connectToRunService() {
        if (runService != null)
            return;
        Intent intent = new Intent(this, RunService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 绑定跑步服务
     */
    private void disconnectToRunService() {
        if (runService == null)
            return;
        if (connection != null) {
            unbindService(connection);
        }
        runService = null;
    }

    /**
     * 将playService绑定到跑步服务
     *
     * @param bind true:绑定,false:解绑
     */
    public void bindRunService(boolean bind) {
        if (bind) {
            connectToRunService();
        } else {
            disconnectToRunService();
        }
    }

    //endregion ========================== 与RunService交互相关 =================================

    //region ========================== 与SkipService交互相关 =================================
    private SkipService skipService;

    /**
     * 绑定跳绳服务
     */
    private void connectToSkipService() {
        if (skipService != null)
            return;
        Intent intent = new Intent(this, SkipService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑跳绳服务
     */
    private void disconnectToSkipService() {
        if (skipService == null)
            return;
        if (connection != null) {
            unbindService(connection);
        }
        skipService = null;
    }

    /**
     * 将playService绑定到跳绳服务
     *
     * @param bind true:绑定,false:解绑
     */
    public void bindSkipService(boolean bind) {
        if (bind) {
            connectToSkipService();
        } else {
            disconnectToSkipService();
        }
    }

    //endregion ========================== 与SkipService交互相关 =================================


}
