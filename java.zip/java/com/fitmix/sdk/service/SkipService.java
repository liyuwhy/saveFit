package com.fitmix.sdk.service;

import android.app.KeyguardManager;
import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.text.TextUtils;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.bean.SkipNumberInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ServiceAliveHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.skip.SkipBluetoothService;
import com.fitmix.sdk.common.bluetooth.skip.SkipCommandHelper;
import com.fitmix.sdk.common.sound.VoiceManager;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SkipInfo;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.activity.LockScreenActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;


/**
 * 跳绳主服务
 */
public class SkipService extends Service {

    /**
     * SkipService 名称
     */
    public static final String SERVICE_NAME = SkipService.class.getName();
    /**
     * 跳绳无响应消息编号
     */
    private static final int SKIP_DEVICE_NO_RESPONSE = 110;

    /**
     * 自定义handler
     */
    protected static class MyHandler extends WeakHandler {
        public MyHandler(Service skipService) {
            super(skipService);
        }

        public void handleMessage(Message msg) {
            SkipService service = (SkipService) getReference();
            if (service == null)
                return;
            switch (msg.what) {
                case Config.MSG_REPEAT_EVERY_SECOND://每秒刷新一次运动数据
                    service.refresh();
                    sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                            500);
                    break;

                case Config.MSG_START_LOCK_SCREEN:
                    service.startLockScreenActivity();
                    break;

                case Config.MSG_SKIP_QUEST_TIMER://请求跳绳数据
                    service.sendCommandBySteps();
                    break;

                case SKIP_DEVICE_NO_RESPONSE://跳绳无响应
                    service.processNoResponse();
                    break;
            }
        }
    }

    private MyHandler myHandler;

    /**
     * 获取Handler,保证不为null
     */
    private MyHandler getMyHandler() {
        if (myHandler == null)
            myHandler = new MyHandler(this);
        return myHandler;
    }

    //region ================================== Service生命周期相关 ==================================

    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        public SkipService getService() {
            return SkipService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        connectToSkipBluetoothService();
        Logger.i(Logger.DEBUG_TAG, "SkipService--->onCreate()");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

//    @Override
//    public void onLowMemory() {
//        super.onLowMemory();
//        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
//        am.getMemoryInfo(mi);
//    }

    @Override
    public void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "SkipService --- > onDestroy()");
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        clearSkipData();
        disconnectToSkipBluetoothService();
        super.onDestroy();

    }

    /**
     * 清除跳绳业务数据
     */
    public void clearSkipData() {
        Logger.i(Logger.DEBUG_TAG, "SkipService --- > clearSkipData()");
        myHandler = null;
        bSkipping = false;
        mIsScreenOff = false;

        //region ======================= 语音播报相关 =======================
        bPausedVoiceByAudioOrPhone = false;
        if (voiceManager != null)
            voiceManager.releaseResource();
        voiceManager = null;
        //endregion ======================= 语音播报相关 =======================

        //region ======================= 任务计划相关 =======================
        bTaskComplete = false;
        taskValue = 0;
        taskType = 0;
        //endregion ======================= 任务计划相关 =======================

        //region ======================= 跳绳参数相关 =======================
        toneType = -1;
        weight = 0;
        height = 0;
        gender = 0;
        age = 0;
        //endregion ======================= 跳绳参数相关 =======================
        mSkipLog = null;
        clearHeartRateData();
    }

    //endregion ================================== Service生命周期相关 ==================================

    //region ================================== Service保活相关 ==================================
    /**
     * CPU锁,防止CPU休眠
     */
    private PowerManager.WakeLock mCPUWakeLock;
    /**
     * 屏幕是否熄屏
     */
    private boolean mIsScreenOff = false;
    /**
     * 锁屏控制
     */
    private KeyguardManager.KeyguardLock mKeyguardLock;

    /**
     * 熄屏,亮屏广播,跳绳过程中强制显示锁屏界面,防止部分手机(如魅族)回收资源
     */
    private BroadcastReceiver mReceiver;

    /**
     * 启动锁屏界面
     */
    private void startLockScreenActivity() {
        Intent i = new Intent(SkipService.this, LockScreenActivity.class);
        i.putExtra("sportType", Config.SPORT_TYPE_SKIP);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//268435456
        try {
            startActivity(i);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * 获取WakeLock
     */
    private PowerManager.WakeLock getCPUWakeLock() {
        if (mCPUWakeLock == null) {
            PowerManager manager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            mCPUWakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "SkipService_CPU_Lock");
        }
        return mCPUWakeLock;
    }

    /**
     * 开启CPU锁定
     */
    private void startCPULock() {
        getCPUWakeLock().acquire();
    }

    /**
     * 释放CPU锁定
     */
    private void releaseCPULock() {
        if (mCPUWakeLock != null) {
            getCPUWakeLock().release();
        }
        mCPUWakeLock = null;
    }

    /**
     * 开启Service存活保护
     */
    private void startKeepAlive() {
        ServiceAliveHelper.getInstance(this).startKeep();
    }

    /**
     * 停止Service存活保护
     */
    private void stopKeepAlive() {
        ServiceAliveHelper.getInstance(this).stopKeep();
    }

    /**
     * 监听屏幕亮屏,熄屏事件,熄屏启动锁屏界面防止部分手机回收Service
     */
    private void registerScreenEventReceiver() {
        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (TextUtils.isEmpty(action)) {
                    return;
                }
                if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                    getMyHandler().sendEmptyMessageDelayed(Config.MSG_START_LOCK_SCREEN, 1000);
                    mIsScreenOff = true;
                } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                    mIsScreenOff = false;
                    startLockScreenActivity();//激活LockScreenActivity的刷新
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(mReceiver, intentFilter);
        disableKeyguard();
    }

    /**
     * 注销屏幕亮屏,熄屏事件
     */
    private void unRegisterScreenEventReceiver() {
        if (mReceiver != null) {
            try {
                unregisterReceiver(mReceiver);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        mReceiver = null;
    }

    /**
     * 禁止键盘锁
     */
    private void disableKeyguard() {
        KeyguardManager manager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        mKeyguardLock = manager.newKeyguardLock("goodLuck");
        mKeyguardLock.disableKeyguard();
    }

    /**
     * 恢复键盘锁
     */
    private void enableKeyguard() {
        if (mKeyguardLock != null) {
            mKeyguardLock.reenableKeyguard();
        }
        mKeyguardLock = null;
    }

    //endregion ================================== Service保活相关 ==================================

    //region ================================== 与Activity交互 ==================================
    private long invalidTime = 0;

    public long getInvalidTime() {
        return invalidTime;
    }

    public void setInvalidTime(long invalidTime) {
        this.invalidTime = invalidTime;
    }

    /**
     * 获取运动时长
     *
     * @return 运动时长, 单位毫秒
     */
    public long getSkipTime() {
        return getSkipLogInfo().getSkipTime();
    }

    /**
     * 获取跳绳个数
     */
    public int getSkipNumber() {
        return getSkipLogInfo().getSkipNumber();
    }

    /**
     * 获取跳绳消耗卡路里,单位大卡
     */
    public double getSkipCalorie() {
        return getSkipLogInfo().getCalorie();
    }

    /**
     * 获取跳频,单位为个/分
     */
    public double getSkipBpm() {
        return getCurrentBpm();//TODO
    }

    /**
     * 获取实时心率
     */
    public int getHeartRate() {
        return 0;//TODO
    }

    /**
     * 屏幕是否已熄屏
     */
    public boolean isScreenOff() {
        return mIsScreenOff;
    }

    //endregion ================================== 与Activity交互 ==================================

    //region ================================== 跳绳蓝牙相关 ==================================
    private SkipBluetoothService skipBluetoothService;

    /**
     * 连接跳绳蓝牙服务
     */
    private void connectToSkipBluetoothService() {
        if (skipBluetoothService != null)
            return;
        Intent intent = new Intent(this, SkipBluetoothService.class);
        bindService(intent, skipServiceConnection, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection skipServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (!name.getClassName().equals(SkipBluetoothService.SERVICE_NAME))
                return;
            skipBluetoothService = ((SkipBluetoothService.LocalBinder) service).getService();
            if (skipBluetoothService == null)
                return;
            skipBluetoothService.removeMessage();//接手替换SkipBluetoothService
            skipBluetoothService.addOnIBluzDeviceConnectionListener(getBluzDeviceConnectionListener());
            skipBluetoothService.addOnCustomCommandListener(getCustomCommandListener());
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            if (skipBluetoothService != null) {
                skipBluetoothService = null;
            }
        }
    };

    /**
     * 解绑跳绳蓝牙服务
     */
    private void disconnectToSkipBluetoothService() {
        if (skipBluetoothService != null) {
            skipBluetoothService.removeOnIBluzDeviceConnectionListener(mOnIBluzDeviceConnectionListener);
            mOnIBluzDeviceConnectionListener = null;
            skipBluetoothService.removeOnCustomCommandListener(mOnCustomCommandListener);
            mOnCustomCommandListener = null;
            skipBluetoothService.sendMessage();
        }
        if (skipServiceConnection != null) {
            unbindService(skipServiceConnection);
        }
        skipServiceConnection = null;
    }

    /**
     * 跳绳蓝牙数据回调监听
     */
    private SkipBluetoothService.OnCustomCommandListener mOnCustomCommandListener;
    /**
     * 蓝牙连接状态回调监听
     */
    private SkipBluetoothService.OnIBluzDeviceConnectionListener mOnIBluzDeviceConnectionListener;
    /**
     * 跳绳运动状态回调监听
     */
    private OnSkipActionListener mOnSkipActionListener;

    /**
     * 获取蓝牙连接状态回调监听
     */
    private SkipBluetoothService.OnIBluzDeviceConnectionListener getBluzDeviceConnectionListener() {
        if (mOnIBluzDeviceConnectionListener == null) {
            mOnIBluzDeviceConnectionListener = new SkipBluetoothService.OnIBluzDeviceConnectionListener() {
                @Override
                public void onConnected(BluetoothDevice device) {
                    Logger.i(Logger.DEBUG_TAG, "SkipService--->mOnIBluzDeviceConnectionListener--->onConnected");
                    if (onBluetoothConnectionListener != null) {
                        onBluetoothConnectionListener.onConnected(device);
                    }
                }

                @Override
                public void onDisconnected(BluetoothDevice device) {
                    //FIXME 重新发送指令
//                    disconnectTime = System.currentTimeMillis();
//                    Logger.e(Logger.DEBUG_TAG, "SkipService--->mOnIBluzDeviceConnectionListener--->onDisconnected disconnectTime:"+disconnectTime+",isInSkipDuration:"+isInSkipDuration());
//                    if(onBluetoothConnectionListener != null && noResponseTime > 40){
//                        onBluetoothConnectionListener.onDisconnected(device);
//                    }

                    if (onBluetoothConnectionListener != null) {
                        onBluetoothConnectionListener.onDisconnected(device);
                    }
                }
            };
        }
        return mOnIBluzDeviceConnectionListener;
    }

    /**
     * 获取跳绳蓝牙数据回调监听
     */
    private SkipBluetoothService.OnCustomCommandListener getCustomCommandListener() {
        if (mOnCustomCommandListener == null) {
            mOnCustomCommandListener = new SkipBluetoothService.OnCustomCommandListener() {
                @Override
                public void onReady(int btConnectStatus, int command, int jumpNumber, byte[] bytes) {
                    Logger.i(Logger.DEBUG_TAG, "SkipService--->onReady()");
                    processData(btConnectStatus, command, jumpNumber, bytes);
                }
            };
        }
        return mOnCustomCommandListener;
    }

    /**
     * 蓝牙连接状态监听
     */
    private OnBluetoothConnectionListener onBluetoothConnectionListener;

    /**
     * 跳绳主页面蓝牙连接监听接口
     */
    public interface OnBluetoothConnectionListener {
        /**
         * 蓝牙连接
         *
         * @param device 蓝牙设备信息
         */
        void onConnected(BluetoothDevice device);

        /**
         * 蓝牙断开连接
         *
         * @param device 蓝牙设备信息
         */
        void onDisconnected(BluetoothDevice device);
    }

    /**
     * 添加蓝牙连接状态监听
     *
     * @param listener
     */
    public void addOnBluetoothConnectionListener(OnBluetoothConnectionListener listener) {
        this.onBluetoothConnectionListener = listener;
    }

    /**
     * 移除蓝牙连接状态监听
     */
    public void removeOnIBluzDeviceConnectionListener() {
        onBluetoothConnectionListener = null;
    }

    /**
     * 添加跳绳运动监听
     *
     * @param listener
     */
    public void addOnSkipActionListener(OnSkipActionListener listener) {
        this.mOnSkipActionListener = listener;
    }

    /**
     * 移除跳绳运动监听
     */
    public void removeSkipActionListener() {
        mOnSkipActionListener = null;
    }

    /**
     * 跳绳运动状态接口
     */
    public interface OnSkipActionListener {
        /**
         * 运动开始
         */
        void onStart();

        /**
         * 运动结束
         */
        void onStop();
    }

    // region =================================在线跳绳数据处理=====================================
    private boolean resetTime;
//    /** 蓝牙断开时间*/
//    private long disconnectTime;
//    /** 跳绳无响应时间,单位为秒*/
//    private int noResponseTime;
//    /** 是否需要重新数据连接*/
//    private boolean mReconnect;

    /**
     * 处理获得的在线跳绳记录信息
     *
     * @param jumpNumber 跳绳个数  Jump_counter (16bit) +  Num_counter(16bit);
     * @param bytes      当前时间 和 偏移时间值
     */
    private void processOnLineData(int jumpNumber, byte[] bytes) {
        //1.移除跳绳无响应消息,判断是否需要发送
        getMyHandler().removeMessages(SKIP_DEVICE_NO_RESPONSE);
        //FIXME 重新发送指令
//        if(noResponseTime > 8 && noResponseTime <= 200){
//            Logger.i(Logger.DEBUG_TAG,"SkipService-->processOnLineData 1发送运动恢复 noResponseTime:" + noResponseTime);
//            sendCustomCommand(SkipCommandHelper.getJumpStatusKey(), 1);
//        }else if(noResponseTime > 200){
//            Logger.i(Logger.DEBUG_TAG,"SkipService-->processOnLineData 2发送运动重置 noResponseTime:" + noResponseTime);
//            sendCustomCommand(SkipCommandHelper.getJumpStatusKey(), 2);
//            noResponseTime = 0;
//        }
//        mReconnect = false;

        //2.运动暂停时,不处理
        if (!isSkipping()) return;
        //3.保存跳绳信息到数据库表SkipInfo
        int jumpCount = jumpNumber & 0x0000ffff;//一共跳了多少下
        int numCount = (jumpNumber >> 16) & 0x0000ffff;//距离上次获取数据跳了多少下
        if (numCount > 0) {
            if (bytes != null && bytes.length >= ((numCount + 3) * 2)) {
                try {
                    int year = bytes[0] & 0xff;
                    int month = bytes[1] & 0xff;
                    int day = bytes[2] & 0xff;
                    int hour = bytes[3] & 0xff;
                    int minute = bytes[4] & 0xff;
                    int second = bytes[5] & 0xff;
                    long skipTime;
                    String dateTime = (year + 2000) + "-" + getRightString(month) + "-" + getRightString(day) + " " + getRightString(hour) + ":" + getRightString(minute) + ":" + getRightString(second);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());//FIXME yyyy-MM-dd KK:mm:ss
                    Date date = simpleDateFormat.parse(dateTime);
                    long baseTime = date.getTime();
                    long preTime = getSkipLogInfo().getEndTime() > getSkipLogInfo().getStartTime() ? getSkipLogInfo().getEndTime() : getSkipLogInfo().getStartTime();
                    long lastTime = 0;
                    for (int h = 0; h < numCount; h++) {
                        int ms = (bytes[(h + 3) * 2] & 0xff) | ((bytes[((h + 3) * 2 + 1)] & 0xff) << 8);//偏移毫秒值
                        skipTime = baseTime + ms;
                        if (isFirstData && h == 0) {
                            if (skipTime < getSkipLogInfo().getStartTime()) {
                                getSkipLogInfo().setStartTime(skipTime);
                            }
                        }
                        int skipNumber = jumpCount - numCount + (h + 1);
                        //setSkipNumber(skipNumber);
                        //Logger.i(Logger.DEBUG_TAG, "SkipService ---> 第:" + skipNumber + "下时间值 : " + skipTime);
                        addDataToTempList(skipNumber, skipTime);
                        if (resetTime) {
                            if (numCount > 1) {
                                if (h == 0) {
                                    preTime = skipTime;
                                }
                                if (h == numCount - 1) {
                                    lastTime = skipTime;
                                }
                            } else {
                                lastTime = skipTime;
                            }
                        } else {
                            lastTime = skipTime;
                        }
                        resetTime = false;
                    }
                    writeDataToDb();
                    if (getCurrentBpm() != 0) {//只计算有效的跳绳数据的卡路里
                        getSkipLogInfo().setCalorie(getSkipCalorie() + calculateCalorie(Math.abs(lastTime - preTime), getCurrentBpm()));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            resetTime = true;
            setInvalidTime(getInvalidTime() + 1000);
            addDataToTempList(jumpCount, System.currentTimeMillis());
            writeDataToDb();
        }
        if (jumpCount > 0) {
            isFirstData = false;
        }
        //Logger.i(Logger.DEBUG_TAG, "SkipService ---> jumpCount:" + jumpCount + " numCount:" + numCount);
        //4.更新跳绳个数
        getSkipLogInfo().setSkipNumber(jumpCount);
    }

    /**
     * 处理蓝牙返回的数据
     *
     * @param btConnectStatus 蓝牙连接状态
     * @param command         命令  cmd (8bit) + Status (8bit) + Reserve (16bit);
     * @param jumpNumber      跳绳个数  Jump_counter (16bit) +  Num_counter(16bit);
     * @param bytes           当前时间 和 偏移时间值
     */
    private void processData(int btConnectStatus, int command, int jumpNumber, byte[] bytes) {
        Logger.i(Logger.DEBUG_TAG, "SkipService-->processData btConnectStatus:" + btConnectStatus + ",command:" + command + ",jumpNumber:" + jumpNumber);
        if (btConnectStatus == SkipCommandHelper.getJumpInfoResultKey(1)) {//蓝牙已连接
            int cmd = command & 0xff;
            if (cmd == 1) {//开始运动
                if (mOnSkipActionListener != null) {
                    mOnSkipActionListener.onStart();
                }
            } else if (cmd == 2) {//运动结束
                if (mOnSkipActionListener != null) {
                    mOnSkipActionListener.onStop();
                }
            } else {
                processOnLineData(jumpNumber, bytes);
            }

        } else if (btConnectStatus == SkipCommandHelper.getJumpInfoResultKey(0)) {//蓝牙已断开
            processOffLineData(command, jumpNumber, bytes);
        } else {//TODO 还有其他类型的数据处理

        }
    }

    /**
     * 临时数据的链表
     */
    private LinkedList<SkipInfo> skipInfoList = new LinkedList<>();

    public boolean isFirstData = false;

    /**
     * 把跳绳信息加入到一个临时链表中
     *
     * @param skipNumber 跳绳个数
     * @param time       与个数对应的时间,单位为毫秒
     */
    private void addDataToTempList(int skipNumber, long time) {
        if (skipInfoList != null) {
            if (skipInfoList.size() > 0) {
                if (time <= skipInfoList.getLast().getTime()) {
                    return;
                }
            }
            SkipInfo skipInfo = new SkipInfo();
            skipInfo.setUid(getSkipLogInfo().getUid());
            skipInfo.setSkipId(getSkipLogInfo().getStartTime());
            skipInfo.setTime(time);
            skipInfo.setSkipNumber(skipNumber);
            skipInfoList.add(skipInfo);
        }

//        SportRecordsHelper.getInstance().writeSkipInfo(this, skipInfo);
//        getSkipLogInfo().setEndTime(time);
//        getSkipLogInfo().setSkipTime(time - getSkipLogInfo().getStartTime());
    }

    /**
     * 把跳绳记录的时间戳及该时间下的bpm 写入数据库表SkipInfo
     */
    private void writeDataToDb() {
        if (skipInfoList != null) {
            //1. 更新运动时长
            long now = System.currentTimeMillis();

            //2. 判断
            if (skipInfoList.size() <= 0) {
                return;
            }
            //3.只保存最近5秒内的数据,用于计算跳频 FIXME 会有问题?
            while ((skipInfoList.getLast().getTime() - skipInfoList.getFirst().getTime()) >= 5000) {
                skipInfoList.removeFirst();
            }

            //4.再次判断
            if (skipInfoList.size() <= 0) {
                return;
            }

            long lastTime = skipInfoList.getLast().getTime();
            int lastNumber = skipInfoList.getLast().getSkipNumber();
            long firstTime = skipInfoList.getFirst().getTime();
            int firstNumber = skipInfoList.getFirst().getSkipNumber();

            getSkipLogInfo().setEndTime(lastTime);
            getSkipLogInfo().setSkipTime(getSkipTime() + (now - getSkipLogRefreshTime()));
            setSkipLogRefreshTime(now);

            if (skipInfoList != null && skipInfoList.size() > 1) {
                int bpm = 0;
                if (lastNumber > firstNumber) {
                    long duration = lastTime - firstTime;
                    if (duration > 60000) {
                        bpm = (int) ((lastNumber - firstNumber) * 1.0f / ((lastTime - firstTime) / 60000.0f));
                    } else if (duration > 0) {
                        bpm = (int) ((lastNumber - firstNumber) * 60000.0f / (lastTime - firstTime));
                    }
//                    Logger.i(Logger.DEBUG_TAG, "SkipService ---> writeDataToDb() --- > bpm : " + bpm + " lastTime : " + lastTime
//                            + " lastNumber : " + lastNumber + " firstTime : " + firstTime + " firstNumber : " + firstNumber);
                    if (bpm > 450) bpm = 450;
                }
                setCurrentBpm(bpm);
                SkipInfo skipInfo = new SkipInfo();
                skipInfo.setUid(getSkipLogInfo().getUid());
                skipInfo.setSkipId(getSkipLogInfo().getStartTime());
                skipInfo.setTime(lastTime - getSkipLogInfo().getStartTime() - getPauseTime());
                skipInfo.setSkipNumber(lastNumber);
                skipInfo.setSkipBpm(bpm);
                SportRecordsHelper.writeSkipInfo(this, skipInfo);
            }
        }
    }

    private String getRightString(int number) {
        if (number < 10) {
            return "0" + number;
        } else {
            return String.valueOf(number);
        }
    }

//    private String byte2bits(byte b) {
//        int z = b;
//        z |= 256;
//        String str = Integer.toBinaryString(z);
//        int len = str.length();
//        return str.substring(len - 8, len);
//    }
    //endregion =================================在线跳绳数据处理=====================================


    /**
     * 向跳绳发送指令
     *
     * @param key  指令的key
     * @param arg1 指令的参数
     */
    public void sendCustomCommand(int key, int arg1) {
        if (skipBluetoothService != null) {
            skipBluetoothService.sendCustomCommand(key, arg1);
        }
    }

    /**
     * 向跳绳发送指令
     *
     * @param key   指令的key
     * @param arg1  指令的参数1
     * @param arg2  指令的参数2
     * @param bytes 指令带的数据
     */
    public void sendCustomCommand(int key, int arg1, int arg2, byte[] bytes) {
        if (skipBluetoothService != null) {
            skipBluetoothService.sendCustomCommand(key, arg1, arg2, bytes);
        }
    }

    //endregion ================================== 跳绳蓝牙相关 ==================================

    //region ================================== 音乐播放相关 ==================================

    private PlayerService musicPlayerService;//音乐播放服务

    private final ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (!name.getClassName().equals(PlayerService.SERVICE_NAME))
                return;
            musicPlayerService = ((PlayerService.MyBinder) service).getService();
            if (musicPlayerService == null)
                return;
            musicPlayerService.bindSkipService(true);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicPlayerService = null;
        }
    };

    private int numberSiriRate;//0表示没有设置，-1表示关闭播报

    private int havePlayNumTime = -1;//已经播报跳绳数的次数，默认为-1，与被销毁后默认值为0做区分

    private int getHavePlayNumTime() {
        if (havePlayNumTime == 0) {//被销毁的情况
            havePlayNumTime = getSkipNumber() / getNumberSiriRate();
        }
        return havePlayNumTime;
    }

    private int getNumberSiriRate() {
        if (numberSiriRate == 0) {
            numberSiriRate = PrefsHelper.with(SkipService.this, Config.PREFS_SPORT).readInt(Config.SY_KEY_SIRI_RATE_SKIP, Config.SY_KEY_SIRI_RATE_SKIP_DEFAULT);
        }
        return numberSiriRate;
    }

    public void setNumberSiriRate(int rate) {
        numberSiriRate = rate;
    }

    /**
     * 播报数字
     */
    private void playNumber() {
        if (isSportWithVoice()) {
            if (getNumberSiriRate() != -1) {
                if (getSkipNumber() >= ((getHavePlayNumTime() == -1 ? 0 : getHavePlayNumTime()) + 1) * getNumberSiriRate()) {
                    getVoiceManager().playNumber(getSkipNumber());
                    if (getHavePlayNumTime() != -1) {
                        havePlayNumTime++;
                    } else {
                        havePlayNumTime = 1;
                    }
                }
            }
        }
    }

    /**
     * 连接音乐播放器
     */
    private void connectToPlayerService() {
        if (musicPlayerService != null)
            return;
        Intent intent = new Intent(this, PlayerService.class);
        intent.putExtra("fromSkipService", true);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑音乐播放器
     */
    private void disconnectToPlayerService() {
        if (musicPlayerService == null)
            return;
        musicPlayerService.bindSkipService(false);
        unbindService(connection);
        musicPlayerService = null;
    }

    //endregion ================================== 音乐播放相关 ==================================

    //region ================================== 跳绳参数相关 ==================================
    /**
     * 是否有语音播报
     */
    private boolean sportWithVoice;
    /**
     * 语音播报语调,int型,0:男声,1:女声
     */
    private int toneType = -1;
    /**
     * 用户体重,单位为千克
     */
    private int weight = 0;
    /**
     * 用户身高,单位为厘米
     */
    private int height = 0;
    /**
     * 用户性别,int型,1:男,2:女
     */
    private int gender = 0;
    /**
     * 用户年龄,int型
     */
    private int age = 0;

    /**
     * 是否有语音播报
     *
     * @return true:有语音播报,false:没有语音播报
     */
    private boolean isSportWithVoice() {
        if (toneType == -1) {
            sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        }
        return sportWithVoice;
    }

    /**
     * 获取语音播报语调,int型,0:男声,1:女声
     *
     * @return 语音播报语调, int型, 0:男声,1:女声
     */
    public int getToneType() {
        if (toneType == -1) {
            sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        }
        return toneType;
    }

    /**
     * 获取用户体重
     *
     * @return 用户体重, 单位为千克
     */
    public int getWeight() {
        if (weight == 0) {
            weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);
        }
        if (weight == 0) {//数据库表保存了Login接口返回为0的结果时
            weight = Config.USER_DEFAULT_WEIGHT;
        }
        return weight;
    }

    /**
     * 获取用户身高
     *
     * @return 用户身高, 单位为厘米
     */
    public int getHeight() {
        if (height == 0) {
            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        }
        if (height == 0) {//数据库表保存了Login接口返回为0的结果时
            height = Config.USER_DEFAULT_HEIGHT;
        }
        return height;
    }

    /**
     * 获取用户性别
     *
     * @return 用户性别, 1:男,2:女
     */
    public int getGender() {
        if (gender == 0) {
            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        }
        return gender;
    }

    /**
     * 获取用户年龄
     */
    public int getAge() {
        if (age == 0) {
            age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
        }
        return age;
    }

    /**
     * 获取卡路里计算结果
     */
    private double calculateCalorie(long duration, int bpm) {
        double result = FitmixUtil.calculateSkipCalorie(getGender() == Config.GENDER_FEMALE,
                getAge(),
                getWeight(),
                getHeight(),
                duration,
                bpm);
        Logger.i(Logger.DEBUG_TAG, "SkipService --- > calculateCalorie() ---- > duration : " + duration + " bpm : " + bpm + " 卡路里 : " + result);
        return result;
    }

    //endregion ================================== 跳绳参数相关 ==================================

    //region ================================== 跳绳业务相关 ==================================
    /**
     * 跳绳记录信息
     */
    private SkipLogInfo mSkipLog;

    /**
     * 跳绳过程中保存的运动开始时间
     */
    private long mSkipStartTime = -1;

    /**
     * 跳绳记录暂停的时长 单位是毫秒
     */
    private long mPauseTime = 0;

    /**
     * 运动暂停的时间戳
     */
    private long pauseTimestamp;

    /**
     * 获取运动暂停的时间戳
     */
    public long getPauseTimestamp() {
        return pauseTimestamp;
    }

    /**
     * 设置运动暂停的时间戳
     */
    public void setPauseTimeStamp(long pauseTimestamp) {
        this.pauseTimestamp = pauseTimestamp;
    }

    /**
     * 获取跳绳记录暂停的时长 单位是毫秒
     */
    public long getPauseTime() {
        return mPauseTime;
    }

    /**
     * 设置跳绳记录暂停的时长 单位是毫秒
     *
     * @param mPauseTime 跳绳记录暂停的时长 单位是毫秒
     */
    public void setPauseTime(long mPauseTime) {
        this.mPauseTime = mPauseTime;
    }

    /**
     * 是否正在运动,为true时表明用户处于正在运动状态,为false表明用户处于用户暂停状态(没有结束)
     */
    private boolean bSkipping;

    /**
     * 是否还在运动过程中,为true时表明用户没有结束运动
     */
    private boolean bInSkipDuration;

    /**
     * 本节真正运动的开始时间,即暂停运动后继续运动那一刻的时刻
     */
    private long lStartSkipTime;

    /**
     * 实时的跳频,每分钟个数
     */
    private int currentBpm;

    /**
     * 获取实时的跳频
     */
    public int getCurrentBpm() {
        return currentBpm;
    }

    /**
     * 设置实时的跳频(每分钟跳绳个数)
     *
     * @param currentBpm 跳频,单位为 个/分钟
     */
    public void setCurrentBpm(int currentBpm) {
        this.currentBpm = currentBpm;
    }

    /**
     * 获取当前跳绳记录
     */
    public SkipLogInfo getSkipLogInfo() {
        if (mSkipLog == null) {
            newSkipLog();
        }
        return mSkipLog;
    }


    /**
     * 获取跳绳过程中保存的开始运动时间
     */
    public long getSkipStartTime() {
        if (mSkipStartTime < 0) {
            mSkipStartTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_START_TIME_SKIP);
        }
        return mSkipStartTime;
    }

    /**
     * 获取是否正在运动中
     *
     * @return true:运动中,false:运动暂停
     */
    public boolean isSkipping() {
        return bSkipping;
    }

    /**
     * 获取是否处在运动过程中
     *
     * @return true:表示还在运动,false:表示运动结束
     */
    public boolean isInSkipDuration() {
        return bInSkipDuration;
    }

    /**
     * 设置是否处在运动过程中
     *
     * @param bInSkipDuration 设置是否在运动过程中
     */
    private void setInSkipDuration(boolean bInSkipDuration) {
        this.bInSkipDuration = bInSkipDuration;
    }

    /**
     * 设置是否正在运动中
     *
     * @param bSkipping true:运动中,false:运动暂停
     */
    private void setSkipping(boolean bSkipping) {
        this.bSkipping = bSkipping;
    }

    /**
     * 获取本节真正运动的开始时间
     */
    public long getStartSkipTime() {
        return lStartSkipTime;
    }

    /**
     * 设置本节真正运动的开始时间
     *
     * @param time 运动开始时间
     */
    private void setStartSkipTime(long time) {
        lStartSkipTime = time;
    }

//    /**
//     * 获取本次运动开始到现在的时间
//     */
//    private long getPeriodSkipTime() {
//        return System.currentTimeMillis() - getStartSkipTime();
//    }

    /**
     * 创建新的运动日志
     */
    private void newSkipLog() {
        mSkipLog = new SkipLogInfo();
        getSkipLogInfo().setUid(UserDataManager.getUid());//用户ID
        getSkipLogInfo().setUploaded(2);//是否与服务器同步

        long startTime = System.currentTimeMillis();
        PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_START_TIME_SKIP, startTime);//保存运动开始时间到sp,防止mSkipLog被清
        getSkipLogInfo().setStartTime(startTime);
    }

    /**
     * 开始跳绳
     *
     * @param sendStartCommand 是否发送开始运动的命令
     */
    public void startSkip(boolean sendStartCommand) {
        Logger.i(Logger.DEBUG_TAG, "SkipService ---> startSkip--->start");
        //1.发送开始运动命令到跳绳
        if (isSkipping()) return;
        if (sendStartCommand) {
            sendCustomCommand(SkipCommandHelper.getJumpActionKey(), 1);
        }
        //2.设置本节真正运动的开始时间
        setStartSkipTime(System.currentTimeMillis());
        //3.设置运动记录最近刷新时间
        setSkipLogRefreshTime(System.currentTimeMillis());
        //4.连接音乐播放器
        connectToPlayerService();
        //5.根据是否有语音播报来开启语音播报
        startVoiceMessageIfNeed();
        //6.更新运动状态
        setSkipping(true);
        setInSkipDuration(true);
        //7.获取CPU锁、开始Service保护并注册屏幕熄屏事件
        startCPULock();
        startKeepAlive();
        registerScreenEventReceiver();
        //8.开启每秒刷新运动数据
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        getMyHandler().sendEmptyMessage(Config.MSG_REPEAT_EVERY_SECOND);
        Logger.i(Logger.DEBUG_TAG, "SkipService ---> startSkip --- end");
    }

    /**
     * 继续运动
     */
    public void continueSkip() {
        //1.发送继续运动命令到跳绳
        if (isSkipping())
            return;
        setPauseTime(getPauseTime() + (System.currentTimeMillis() - getPauseTimestamp()));
        sendCustomCommand(SkipCommandHelper.getJumpActionKey(), 4);
//
//        setStartRunTime(System.currentTimeMillis());
        //2.设置运动记录最近刷新时间
        setSkipLogRefreshTime(System.currentTimeMillis());
        //3.播报语音提示:【继续运动】
        continueVoiceManager();
        //4.设置运动状态为运动中
        setSkipping(true);
        //5.恢复每秒刷新
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        getMyHandler().sendEmptyMessage(Config.MSG_REPEAT_EVERY_SECOND);
        Logger.d(Logger.DEBUG_TAG, "continueSkip");
    }

    /**
     * 暂停跳绳
     */
    public void pauseSkip() {
        if (!isSkipping())
            return;
        //1.设置运动暂停的时间戳
        setPauseTimeStamp(System.currentTimeMillis());
        //2.暂停每秒刷新,发送暂停运动命令到跳绳
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        sendCustomCommand(SkipCommandHelper.getJumpActionKey(), 3);
        //3.语音播报:【暂停运动】
        pauseVoiceManager();
        //4.设置运动状态为暂停运动
        setSkipping(false);
        Logger.d(Logger.DEBUG_TAG, "pauseSkip");
    }

    /**
     * 停止跳绳
     */
    public void stopSkip() {
        //1.关闭每秒刷新运动数据
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        //2.停止音乐播放
        disconnectToPlayerService();
        //3.发送结束运动命令到跳绳
        sendCustomCommand(SkipCommandHelper.getJumpActionKey(), 2);
        //4 心率UserHeartRate类数据
        if (getUserHeartRateFinish() != null) {
            getUserHeartRateFinish().doUserHeartRateFinish();
        }
        //5.保存运动记录,计数文件
        saveSkipRecordToDb(getSkipLogInfo(), 1);
        writeFiles();
        //6.更新运动状态
        setSkipping(false);
        setInSkipDuration(false);
        //7.释放CPU锁、停止Service保护并注销监听屏幕亮熄屏事件
        releaseCPULock();
        stopKeepAlive();
        unRegisterScreenEventReceiver();
        enableKeyguard();
    }

    /**
     * 清空跳绳数据
     */
    public void resetSkipData() {
        mSkipLog = null;
    }

    /**
     * 添加或更新跳绳记录到数据库
     *
     * @param skipLogInfo 跳绳运动信息
     * @param flag        运动完成标志,0:运动未完成,1:运动已完成
     */
    private void saveSkipRecordToDb(SkipLogInfo skipLogInfo, int flag) {
        if (skipLogInfo == null)
            return;
        SportRecord sportRecord = new SportRecord(null);
        sportRecord.setUid(skipLogInfo.getUid());//用户Uid
        sportRecord.setStartTime(skipLogInfo.getStartTime());//运动开始时间
        sportRecord.setFlag(flag);//运动完成标志
        sportRecord.setType(2);//类型
        sportRecord.setStep(skipLogInfo.getSkipNumber());//运动数量
        sportRecord.setRunTime(skipLogInfo.getSkipTime());//运动时长
        if (flag == 1) {//运动完成,计算总的平均BPM
            sportRecord.setUploaded(0);//记录未同步
        } else {
            sportRecord.setUploaded(2);//记录未完成
        }
        if (skipLogInfo.getSkipTime() > 60000) {
            sportRecord.setBpm((int) (1.0f * skipLogInfo.getSkipNumber() / (skipLogInfo.getSkipTime() / 60000.0f)));//总的平均跳频
        } else if (skipLogInfo.getSkipTime() > 0) {
            sportRecord.setBpm((int) (skipLogInfo.getSkipNumber() * 60000.0f / skipLogInfo.getSkipTime()));//总的平均跳频
        }
        sportRecord.setBpm(skipLogInfo.getBpm());
        if (!TextUtils.isEmpty(skipLogInfo.getHeartRateDate())) {
            sportRecord.setHeartRateDate(skipLogInfo.getHeartRateDate());//心率相关数据
        }

        sportRecord.setEndTime(skipLogInfo.getEndTime());//运动结束时间
        sportRecord.setCalorie((long) skipLogInfo.getCalorie());//运动卡路里
        //bpmMatch,score,trail,stepData由服务器返回,在此不考虑
        SportRecordsHelper.insertOrReplaceSportRecord(this, sportRecord);
    }

    /**
     * 写跳绳文件
     */
    private void writeFiles() {
        final int uid = UserDataManager.getUid();
        final long skipId = getSkipLogInfo().getStartTime();
        if (skipId < 0) {
            return;
        }
        final String skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipId + ".skip";
        SportRecordsHelper.asyncGetAllSkipInfo(this, uid, skipId, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SkipInfo> skipInfoList = (List<SkipInfo>) operation.getResult();
                if (skipInfoList != null && skipInfoList.size() > 0) {
                    List<SkipNumberInfo> skipNumberInfos = new ArrayList<>();
                    //数据库步数信息实体(StepInfo)转换为跳绳信息实体(SkipNumberInfo)
                    for (SkipInfo skipInfo : skipInfoList) {
                        SkipNumberInfo skipNumberInfo = new SkipNumberInfo();
                        skipNumberInfo.setTime(skipInfo.getTime() == null ? 0 : skipInfo.getTime());
                        skipNumberInfo.setBpm(skipInfo.getSkipBpm() == null ? 0 : skipInfo.getSkipBpm());
                        skipNumberInfo.setCount(skipInfo.getSkipNumber() == null ? 0 : skipInfo.getSkipNumber());
                        skipNumberInfo.setHeartRate(skipInfo.getHeartRate() == null ? 0 : skipInfo.getHeartRate());
                        skipNumberInfos.add(skipNumberInfo);
                    }
                    boolean success = JsonHelper.writeSkipNumberFile(skipFileName, skipNumberInfos);
                    Logger.i(Logger.DEBUG_TAG, "SkipService ---> skipFileName : ----2--- " + skipFileName);
                    if (success) {//写文件成功,删除数据库表记录
                        SportRecordsHelper.deleteSkipInfo(SkipService.this, uid, skipId);
                    }
                }
            }
        });
    }

    //endregion ================================== 跳绳业务相关 ==================================

    //region ================================== 跳绳数据刷新相关 ==================================
    /**
     * 当前跳绳记录最近刷新的时间
     */
    private long lSkipLogRefreshTime;

    /**
     * 获取记录上次刷新时间
     */
    private long getSkipLogRefreshTime() {
        return lSkipLogRefreshTime;
    }

    /**
     * 设置运动记录最近刷新时间
     *
     * @param time 设置记录上次刷新时间
     */
    private void setSkipLogRefreshTime(long time) {
        lSkipLogRefreshTime = time;
    }

    /**
     * 运动数据刷新
     */
    private void refresh() {
        //如果熄屏,启动锁屏界面
        if (mIsScreenOff) {
            startLockScreenActivity();
        }
        //1.获取跳绳信息/状态 0x82
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(1), 2);//
        //2.每秒钟发送跳绳无响应的消息,如果接收到有在线数据,则会在processOnLineData中移除
        getMyHandler().sendEmptyMessageDelayed(SKIP_DEVICE_NO_RESPONSE, 1000);
        //3. 检测运动目标完成情况
        checkTaskObject();
        //4.根据跳绳次数、播报频率，播报次数
        playNumber();

    }

    private void processNoResponse() {
        resetTime = true;
        Logger.i(Logger.DEBUG_TAG, "SkipService ---> processNoResponse() skipBluetoothService is null:" + (skipBluetoothService == null) + ",isInSkipDuration:" + isInSkipDuration());
        setInvalidTime(getInvalidTime() + 1000);
        addDataToTempList(getSkipNumber(), System.currentTimeMillis());
        writeDataToDb();

        //FIXME 重新发送指令
//        noResponseTime++;
//        if(noResponseTime > 0 && noResponseTime <= 20){
//            Logger.i(Logger.DEBUG_TAG,"SkipService-->processNoResponse 1发送运动恢复 noResponseTime:" + noResponseTime+",mReconnect:"+mReconnect);
//            sendCustomCommand(SkipCommandHelper.getJumpStatusKey(), 1);
//            if(skipBluetoothService != null && !mReconnect){
//                BluetoothDevice device = skipBluetoothService.getSkipSppConnectDevice();
//                if(device != null) {
//                    skipBluetoothService.disConnectBluetoothDevice();
//                    skipBluetoothService.connectBluetoothDevice(device);
//                    skipBluetoothService.addOnIBluzDeviceConnectionListener(getBluzDeviceConnectionListener());//FIXME 注意
//                    skipBluetoothService.addOnCustomCommandListener(getCustomCommandListener());//FIXME 注意
//                    Logger.i(Logger.DEBUG_TAG,"SkipService-->processNoResponse connectBluetoothDevice!!! device is null:"+(device == null));
//                    mReconnect = true;
//                }
//            }
//
//        }

    }

    //endregion ================================== 跳绳数据刷新相关 ==================================

    //region =================================== 语音播报相关 ===================================
    /**
     * 是否语音暂停
     */
    private boolean bPausedVoiceByAudioOrPhone;
    /**
     * 语音管理器,负责语音播报
     */
    private VoiceManager voiceManager;

    /**
     * 获取VoiceManager
     */
    public VoiceManager getVoiceManager() {
        if (voiceManager == null)
            voiceManager = new VoiceManager();
        return voiceManager;
    }

    /**
     * 根据是否有语音播报来开启语音播报,并设置语调
     */
    private void startVoiceMessageIfNeed() {
        if (isSportWithVoice()) {//设置语调(男声或女声)
            getVoiceManager().setToneType(getToneType());
        }
    }

    /**
     * 语音播报:暂停运动
     */
    private void pauseVoiceManager() {
        if (isSportWithVoice()) {
            getVoiceManager().playPauseSkip();
        }
    }

    /**
     * 语音播报:继续运动
     */
    private void continueVoiceManager() {
        if (isSportWithVoice()) {
            getVoiceManager().playContinueSkip();
        }
    }

    /**
     * 获取是否语音暂停
     */
    private boolean getPausedVoiceByAudioOrPhone() {
        return bPausedVoiceByAudioOrPhone;
    }

    /**
     * 设置是否语音暂停
     *
     * @param bValue true:语音播报暂停,false:语音播报继续
     */
    private void setPausedVoiceByAudioOrPhone(boolean bValue) {
        bPausedVoiceByAudioOrPhone = bValue;
    }

    /**
     * 暂停语音播报
     */
    public void pauseVoiceByAudioOrPhone() {
        if (!getVoiceManager().isMetronomeWorking())
            return;
        setPausedVoiceByAudioOrPhone(true);
        getVoiceManager().stopMetronome();
    }

    /**
     * 继续语音播报
     */
    public void resumeVoiceByAudioOrPhone() {
        if (!getPausedVoiceByAudioOrPhone())
            return;
        setPausedVoiceByAudioOrPhone(false);
        getVoiceManager().startMetronome();
    }

    //endregion =================================== 语音播报相关 ===================================

    //region ================================== 运动训练计划相关 ==================================
    /**
     * 运动训练设置,0:自由跳
     */
    public static final int TASK_TYPE_FREE = 0;
    /**
     * 运动训练设置,1:计时跳
     */
    public static final int TASK_TYPE_TIME = 1;
    /**
     * 运动训练设置,2:计数跳
     */
    public static final int TASK_TYPE_NUMBER = 2;
    /**
     * 运动训练设置,3:卡路里跳
     */
    public static final int TASK_TYPE_CALORIE = 3;
    /**
     * 运动训练设置,4:运动计划
     */
    public static final int TASK_TYPE_SPORT_PLAN = 4;
    /**
     * 运动目标值
     */
    private long taskValue;
    /**
     * 运动目标类型
     */
    private int taskType;
    /**
     * 目标是否完成
     */
    private boolean bTaskComplete;

    /**
     * 获取运动目标类型
     */
    public int getTaskType() {
        return taskType;
    }

    /**
     * 获取任务目标
     */
    public long getTaskValue() {
        return taskValue;
    }

    /**
     * 设置运动目标类型和值
     *
     * @param value 目标值
     * @param type  目标类型
     */
    public void setTaskTypeAndValue(long value, int type) {
        this.taskValue = value;
        this.taskType = type;
    }

    /**
     * 获取运动目标是否完成
     *
     * @return true:是,false:否
     */
    public boolean isTaskComplete() {
        return bTaskComplete;
    }

    /**
     * 设置运动目标是否完成
     *
     * @param bValue true:是,false:否
     */
    private void setTaskComplete(boolean bValue) {
        this.bTaskComplete = bValue;
    }

    /**
     * 检查目标任务完成情况
     */
    private void checkTaskObject() {
        boolean bFinish = false;
//        Logger.i(Logger.DEBUG_TAG, "运动时长 : " + getSkipTime() + " 运动目标 : " + getTaskValue());
        switch (getTaskType()) {
            case TASK_TYPE_NUMBER://运动距离
            case TASK_TYPE_SPORT_PLAN://运动计划
                if (getSkipNumber() >= getTaskValue()) bFinish = true;
                break;
            case TASK_TYPE_TIME://运动时长
                if (getSkipTime() >= getTaskValue()) bFinish = true;
                break;
            case TASK_TYPE_CALORIE://运动卡路里
                if (getSkipCalorie() >= getTaskValue()) bFinish = true;
                break;
        }
        if (bFinish && (!isTaskComplete())) {
            setTaskComplete(true);
            getVoiceManager().playTaskSkipComplete();
        }
    }

    //endregion ================================== 运动训练计划相关 ==================================

    //region ================================== 心率统计相关 ==================================

    private int lastestHeartRate; //上一次的心率值，如果还没收到则读上一次的

    private UserHeartRateFinish userHeartRateFinish;

    public UserHeartRateFinish getUserHeartRateFinish() {
        return userHeartRateFinish;
    }

    public void setUserHeartRateFinish(UserHeartRateFinish userHeartRateFinish) {
        this.userHeartRateFinish = userHeartRateFinish;
    }

    /**
     * UI界面上更新心率数值
     *
     * @return
     */
    public int getLastestHeartRate() {
        return lastestHeartRate;
    }

    /**
     * 设置最新的心率数据
     */
    public void setLastestHeartRate(int value) {
        lastestHeartRate = value;
    }


    public interface UserHeartRateFinish {
        /**
         * 运动完成后设置心率接口相关的参数，存储在UserLog中
         */
        void doUserHeartRateFinish();
    }

    public void clearHeartRateData() {
        userHeartRateFinish = null;
        lastestHeartRate = 0;
    }

    //endregion ================================== 心率统计相关 ==================================

    //region ================================= 离线跳绳数据处理 =====================================

    private int steps;
    private int connectTimeOutCount = 0;

    /**
     * 请求跳绳数据消息处理
     */
    private void sendCommandBySteps() {
        connectTimeOutCount++;
        if (connectTimeOutCount > 3) {
            getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
            sendGetOffLineDataResult(1);
            return;
        }
        if (steps > 0) {
            switch (steps) {
                case 1:
                    sendHasOffLineData();
                    break;
                case 2:
                    sendGetOffLineData();
                    break;
                case 3:
                    break;
            }
        }
    }

    /**
     * 2秒后调用sendCommandBySteps方法
     *
     * @param steps 后续操作
     */
    private void resetTimer(int steps) {
        this.steps = steps;
        getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
        getMyHandler().sendEmptyMessageDelayed(Config.MSG_SKIP_QUEST_TIMER, 2000);
    }

    /**
     * 查询有没有离线跳绳记录
     */
    private void sendHasOffLineData() {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 1);
        resetTimer(1);
    }

    /**
     * 获取离线的跳绳记录数据
     */
    private void sendGetOffLineData() {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 2);
        resetTimer(2);
    }

    /**
     * 获取记录结果
     *
     * @param type 0 校验成功 1 超时 2 校验失败 3 数据丢包
     */
    private void sendGetOffLineDataResult(int type) {
        sendCustomCommand(SkipCommandHelper.getJumpInfoKey(0), 3, type, null);
        resetTimer(3);
    }

    /**
     * 当前序列号
     */
    private int currentSerialNumber;
    /**
     * 离线的临时的跳绳记录信息
     */
    private SkipLogInfo currentSkipLogInfo;

    /**
     * 获取离线的临时的跳绳记录信息
     */
    private SkipLogInfo getCurrentSkipLogInfo() {
        if (currentSkipLogInfo == null) {
            currentSkipLogInfo = new SkipLogInfo();
        }
        return currentSkipLogInfo;
    }

    /**
     * 处理获得的离线跳绳记录信息
     *
     * @param command    命令  cmd (8) + Status (8) + Reserve (16);
     * @param jumpNumber 跳绳个数  Jump_counter (16) +  Num_counter(16);
     * @param bytes      当前时间 和 偏移时间值
     */
    private void processOffLineData(int command, int jumpNumber, byte[] bytes) {
        if (command == 1 && jumpNumber == 0) {//没有记录停止获取操作
            getMyHandler().removeMessages(Config.MSG_SKIP_QUEST_TIMER);
        } else if (command == 1 && jumpNumber > 0) {//如果有未同步跳绳记录
            connectTimeOutCount = 0;
            currentSkipLogInfo = null;
            sendGetOffLineData();
        } else if (command == 2) {//获取数据之后
            int serialNumber = jumpNumber & 0x0000ffff;//序列号
            int totalPackageNumber = (jumpNumber >> 16) & 0x0000ffff;//该条记录总包数
            if ((serialNumber - 1) > currentSerialNumber) {
                sendGetOffLineDataResult(3);
                return;
            }
            currentSerialNumber = serialNumber;
            long baseTime = -1;
            int numberCount = -1;
            int timeSpace = -1;
            long checkSum = -1;
            long currentCheck = -1;
            Logger.i(Logger.DEBUG_TAG, "SkipService ---> serialNumber : " + serialNumber + " totalPackageNumber : " + totalPackageNumber);
            if (bytes != null && bytes.length > 0) {
                if (serialNumber == 1) {//第一个包数据
                    connectTimeOutCount = 0;
                    int version = bytes[0] & 0xff;
                    timeSpace = bytes[1] & 0xff;
                    int year = bytes[2] & 0xff;
                    int month = bytes[3] & 0xff;
                    int day = bytes[4] & 0xff;
                    int hour = bytes[5] & 0xff;
                    int minute = bytes[6] & 0xff;
                    int second = bytes[7] & 0xff;
                    long jumpTime = (bytes[8] & 0xff) | ((bytes[9] & 0xff) << 8);
                    int jumpCount = (bytes[10] & 0xff) | ((bytes[11] & 0xff) << 8);
                    int dataCount = (bytes[12] & 0xff) | ((bytes[13] & 0xff) << 8);
                    if (jumpCount <= 20) return;
                    checkSum = bytes[14] & 0xff;//包所有数据的异或校验
                    //临时校验
                    currentCheck = version ^ timeSpace ^ year ^ month ^ day ^ hour ^ minute ^ second ^ jumpTime ^ jumpCount ^ dataCount;

                    String dateTime = (year + 2000) + "-" + getRightString(month) + "-" + getRightString(day) + " " + getRightString(hour) + ":" + getRightString(minute) + ":" + getRightString(second);
                    try {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());//FIXME yyyy-MM-dd KK:mm:ss
                        Date date = simpleDateFormat.parse(dateTime);
                        baseTime = date.getTime();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (baseTime < 0) return;

                    getCurrentSkipLogInfo().setStartTime(baseTime);
                    getCurrentSkipLogInfo().setSkipTime(jumpTime);
                    getCurrentSkipLogInfo().setSkipNumber(jumpCount);
                    getCurrentSkipLogInfo().setUid(UserDataManager.getUid());
                    getCurrentSkipLogInfo().setEndTime(baseTime + jumpTime);

                    if (dataCount > 0 && currentSkipLogInfo != null) {
                        for (int j = 0; j < (bytes.length - 15); j++) {
                            baseTime = baseTime + timeSpace;
                            int number = bytes[j + 15] & 0xff;
                            currentCheck = currentCheck ^ number;
                            numberCount = numberCount + number;
                            int bpm = number * 12;
                            getCurrentSkipLogInfo().setCalorie(getCurrentSkipLogInfo().getCalorie() + calculateCalorie(timeSpace, bpm));
                            saveOffLineDataToDb(numberCount, baseTime, bpm);
                        }
                    }
                } else {//第二个包开始
                    if (currentSkipLogInfo != null) {
                        for (byte aByte : bytes) {
                            baseTime = baseTime + timeSpace;
                            int number = aByte & 0xff;
                            currentCheck = currentCheck ^ number;
                            numberCount = numberCount + number;
                            int bpm = number * 12;
                            getCurrentSkipLogInfo().setCalorie(getCurrentSkipLogInfo().getCalorie() + calculateCalorie(timeSpace, bpm));
                            saveOffLineDataToDb(numberCount, baseTime, bpm);
                        }
                    }
                }
            }

            if ((currentCheck ^ checkSum) != 0) {
                Logger.i(Logger.DEBUG_TAG, "SkipService ---> 校验失败");
                sendGetOffLineDataResult(2);//校验失败
                return;
            }

            if (serialNumber == totalPackageNumber) {//获取到所有包成功
                currentSerialNumber = 0;
                if (currentSkipLogInfo != null) {
                    saveOffLineSkipRecordToDb(getCurrentSkipLogInfo());
                    writeOffLineDataFiles();
                }
            }
        } else if (command == 3) {//一条记录数据获取完成 之后 再次检查有没有未同步的数据
            sendHasOffLineData();
        } else if (command == 4) {
            if (jumpNumber == 0) {
                //TODO 强制退出获取历史记录
            } else if (jumpNumber == 1) {
                //TODO 获取命令异常 重新获取
            }
        }
    }

    /**
     * 保存离线跳绳信息到数据库表SkipInfo
     *
     * @param skipNumber 跳绳个数
     * @param time       跳绳记录时刻的时间戳,单位毫秒
     * @param bpm        跳频,每分钟个数
     */
    private void saveOffLineDataToDb(int skipNumber, long time, int bpm) {
        SkipInfo skipInfo = new SkipInfo();
        skipInfo.setSkipId(getCurrentSkipLogInfo().getStartTime());
        skipInfo.setSkipNumber(skipNumber);
        if (bpm > 450) bpm = 450;//350?
        skipInfo.setSkipBpm(bpm);
        skipInfo.setTime(time);
        skipInfo.setUid(getCurrentSkipLogInfo().getUid());
        SportRecordsHelper.writeSkipInfoSync(this, skipInfo);
    }

    /**
     * 添加或更新跳绳记录到数据库
     *
     * @param skipLogInfo 跳绳运动信息
     */
    private void saveOffLineSkipRecordToDb(SkipLogInfo skipLogInfo) {
        if (skipLogInfo == null)
            return;
        SportRecord sportRecord = new SportRecord(null);
        sportRecord.setUid(skipLogInfo.getUid());//用户Uid
        sportRecord.setStartTime(skipLogInfo.getStartTime());//运动开始时间
        sportRecord.setFlag(1);//运动完成标志
        sportRecord.setType(2);//类型
        sportRecord.setStep(skipLogInfo.getSkipNumber());//运动数量
        sportRecord.setRunTime(skipLogInfo.getSkipTime());//运动时长
        sportRecord.setUploaded(0);//记录未同步
        if (skipLogInfo.getSkipTime() > 60000) {
            sportRecord.setBpm((int) (1.0f * skipLogInfo.getSkipNumber() / (skipLogInfo.getSkipTime() / 60000.0f) + 0.5));//总的平均BPM
        } else if (skipLogInfo.getSkipTime() > 0) {
            sportRecord.setBpm((int) (skipLogInfo.getSkipNumber() * 60000.0f / skipLogInfo.getSkipTime() + 0.5));//总的平均BPM
        }
        sportRecord.setEndTime(skipLogInfo.getEndTime());//运动结束时间
        sportRecord.setCalorie((long) skipLogInfo.getCalorie());//运动卡路里
        SportRecordsHelper.insertOrReplaceSportRecord(this, sportRecord);
    }

    /**
     * 写离线跳绳文件文件
     */
    private void writeOffLineDataFiles() {
        final int uid = UserDataManager.getUid();
        if (currentSkipLogInfo == null) return;
        final long skipId = currentSkipLogInfo.getStartTime();
        if (skipId < 0) {
            return;
        }
        currentSkipLogInfo = null;
        final String skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipId + ".skip";
        Logger.i(Logger.DEBUG_TAG, "SkipService ---> skipFileName : ----1--- " + skipFileName);
        SportRecordsHelper.asyncGetAllSkipInfo(this, uid, skipId, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SkipInfo> skipInfoList = (List<SkipInfo>) operation.getResult();
                if (skipInfoList != null && skipInfoList.size() > 0) {
                    List<SkipNumberInfo> skipNumberInfos = new ArrayList<>();
                    //数据库跳绳计数信息实体(SkipInfo)转换为跳绳计数信息实体(SkipNumberInfo)
                    for (SkipInfo skipInfo : skipInfoList) {
                        SkipNumberInfo skipNumberInfo = new SkipNumberInfo();
                        skipNumberInfo.setTime(skipInfo.getTime() == null ? 0 : skipInfo.getTime());
                        skipNumberInfo.setBpm(skipInfo.getSkipBpm() == null ? 0 : skipInfo.getSkipBpm());
                        skipNumberInfo.setCount(skipInfo.getSkipNumber() == null ? 0 : skipInfo.getSkipNumber());
                        skipNumberInfo.setHeartRate(skipInfo.getHeartRate() == null ? 0 : skipInfo.getHeartRate());
                        skipNumberInfos.add(skipNumberInfo);
                    }
                    boolean success = JsonHelper.writeSkipNumberFile(skipFileName, skipNumberInfos);
                    Logger.i(Logger.DEBUG_TAG, "SkipService ---> skipFileName : ----2--- " + skipFileName);
                    if (success) {//写文件成功,删除数据库表记录
                        SportRecordsHelper.deleteSkipInfo(SkipService.this, uid, skipId);
                        sendGetOffLineDataResult(0);
                    }
                }
            }
        });
    }
    //endregion ================================= 离线跳绳数据处理 =====================================

}
