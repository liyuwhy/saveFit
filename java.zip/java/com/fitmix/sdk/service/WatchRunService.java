package com.fitmix.sdk.service;


import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.view.activity.MainActivity;
import com.xdandroid.hellodaemon.AbsWorkService;

import java.util.List;

import io.reactivex.disposables.Disposable;

/**
 * Created by zmt on 2018/6/21.
 * RunService的守护进程
 */
public class WatchRunService extends AbsWorkService {

    //是否 任务完成, 不再需要服务运行?
    public static boolean sShouldStopService;
    public static Disposable sDisposable;
    //用户是否在运动
    public static boolean isRunning;




    public static void stopService() {
        //我们现在不再需要服务运行了, 将标志位置为 true
        sShouldStopService = true;
        //取消对任务的订阅
        if (sDisposable != null) sDisposable.dispose();
        //取消 Job / Alarm / Subscription
        cancelJobAlarmSub();
        Logger.d(Logger.DEBUG_TAG,"WatchRunService --->stopWork");
    }

    /**
     * 是否 任务完成, 不再需要服务运行?
     * @return 应当停止服务, true; 应当启动服务, false; 无法判断, 什么也不做, null.
     */
    @Override
    public Boolean shouldStopService(Intent intent, int flags, int startId) {
        return sShouldStopService;
    }

    @Override
    public void startWork(Intent intent, int flags, int startId) {
        /*sDisposable = Observable
                .interval(5, TimeUnit.SECONDS)
                //取消任务时取消定时唤醒
                .doOnDispose(() -> {
                    cancelJobAlarmSub();
                })
                .subscribe(count -> {
                    Logger.e(Logger.DEBUG_TAG,"WatchRunService --->startWork");
                    if (getRunningStatus()){
                        Logger.e(Logger.DEBUG_TAG,"主进程："+this.getPackageName());
                        if (!isMainProcessRunning(this,this.getPackageName())){
                            Intent intent0 = new Intent(this, MainActivity.class);
                            intent0.putExtra("fromWatchRunService",true);
                            intent0.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                            startActivity(intent0);
                            Logger.e(Logger.DEBUG_TAG,"RunService被杀死了------- ");
                        }
                    }
                });*/
        Logger.d(Logger.DEBUG_TAG,"WatchRunService --->startWork");
    }

    @Override
    public void stopWork(Intent intent, int flags, int startId) {
        stopService();
    }

    /**
     * 任务是否正在运行?
     * @return 任务正在运行, true; 任务当前不在运行, false; 无法判断, 什么也不做, null.
     */
    @Override
    public Boolean isWorkRunning(Intent intent, int flags, int startId) {
        //若还没有取消订阅, 就说明任务仍在运行.
        return sDisposable != null && !sDisposable.isDisposed();
    }

    @Override
    public IBinder onBind(Intent intent, Void v) {
        return null;
    }

    @Override
    public void onServiceKilled(Intent rootIntent) {
        Logger.e(Logger.DEBUG_TAG,"WatchRunService --->onServiceKilled");
        if (getRunningStatus()){
            Intent intent0 = new Intent(this, MainActivity.class);
            intent0.putExtra("fromWatchRunService",true);
            intent0.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(intent0);
            SettingsHelper.putBoolean(Config.SP_KEY_RUNNING_IF_KILLED,true);
        }
    }


    /**
     *
     * @param context 上下文
     * @param processName 进程名称
     * @return true，在运行；false，停止运行
     */
    public boolean isMainProcessRunning(Context context, String processName) {

        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        if (runningApps == null) {
            return false;
        }
        for (ActivityManager.RunningAppProcessInfo procInfo : runningApps) {
            Logger.d(Logger.DEBUG_TAG,"process:"+procInfo.processName);
            if (procInfo.processName.equals(processName)) {
                return true;
            }
        }
        return false;

    }

    public static boolean getRunningStatus(){
        boolean isRunning = SettingsHelper.getBoolean(Config.SETTING_IS_RUNNING,false);
        return isRunning;
    }

    public static void setRunningStatus(boolean isRunning){
        SettingsHelper.putBoolean(Config.SETTING_IS_RUNNING,isRunning);
    }
}
