package com.fitmix.sdk.service;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Binder;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.RemoteViews;

import com.amap.api.location.AMapLocation;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateJsonInfo;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.RunStepInfo;
import com.fitmix.sdk.bean.TrailInfo;
import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ServiceAliveHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.maps.AMapLocationManager;
import com.fitmix.sdk.common.maps.TrailManager;
import com.fitmix.sdk.common.pedometer.BpmManager;
import com.fitmix.sdk.common.pedometer.GSensorStepManager;
import com.fitmix.sdk.common.pedometer.PedometerBase;
import com.fitmix.sdk.common.sound.VoiceManager;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.database.HeartRateInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.database.StepInfo;
import com.fitmix.sdk.model.database.TrailPoint;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.activity.LockScreenActivity;
import com.fitmix.sdk.view.activity.RunMainActivity;
import com.fitmix.sdk.view.activity.SettingStepActivity;
import com.fitmix.sdk.view.fragment.RunSettingBaseFragment;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

/**
 * 跑步主服务
 */
public class RunService extends Service {

    public static final String NOTIFICATION_CHANNEL_ID = "10001";

    /**
     * RunService 名称
     */
    public static final String SERVICE_NAME = RunService.class.getName();
    /**
     * 操作类型
     */
    public static final String ACTION_WHAT = "ACTION_WHAT";
    /**
     * 开启后台计步
     */
    public static final String ACTION_START_DAEMON_STEP_COUNT = "ACTION_START_DAEMON_STEP_COUNT";
    /**
     * 停止后台计步
     */
    public static final String ACTION_STOP_DAEMON_STEP_COUNT = "ACTION_STOP_DAEMON_STEP_COUNT";

    /**
     * 自定义handler
     */
    protected static class MyHandler extends WeakHandler {
        public MyHandler(Service runService) {
            super(runService);
        }

        public void handleMessage(Message msg) {
            RunService service = (RunService) getReference();
            if (service == null)
                return;
            switch (msg.what) {
                case Config.MSG_REPEAT_EVERY_SECOND://每秒刷新一次运动数据
//                    Logger.v(Logger.DEBUG_TAG,"RunService-->MSG_REPEAT_EVERY_SECOND event");
                    service.refresh();
                    sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND,
                            1000);
                    break;

                case Config.MSG_START_LOCK_SCREEN:
                    service.startLockScreenActivity();
                    break;

            }
        }
    }

    private MyHandler myHandler;

    /**
     * 获取Handler,保证不为null
     */
    private MyHandler getMyHandler() {
        if (myHandler == null)
            myHandler = new MyHandler(this);
        return myHandler;
    }

    //region ================================== Service生命周期相关 ==================================

    // Binder given to clients
    private final IBinder mBinder = new LocalBinder();

    /**
     * Class used for the client Binder.  Because we know this service always
     * runs in the same process as its clients, we don't need to deal with IPC.
     */
    public class LocalBinder extends Binder {
        public RunService getService() {
            // Return this instance of LocalService so clients can call public methods
            return RunService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        //初始化今日步数
        todaySteps = PrefsHelper.with(this, Config.PREFS_SPORT).readInt(Config.SP_KEY_TODAY_STEPS, 0);
        Logger.i(Logger.DEBUG_TAG, "RunService-->onCreate service pid:" + android.os.Process.myPid());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_STICKY;
//            return super.onStartCommand(intent, flags, startId);
        }
        String action = intent.getStringExtra(ACTION_WHAT);
        if (action == null) return super.onStartCommand(intent, flags, startId);
        if (action.equals(ACTION_START_DAEMON_STEP_COUNT)) {//开启后台计步
            if (!isInRunDuration()) {
                stopDaemonStepCount();
                startDaemonStepCount();
            }
        } else if (action.equals(ACTION_STOP_DAEMON_STEP_COUNT)) {//停止后台计步
            if (!isInRunDuration()) {
                stopDaemonStepCount();
                stopSelf();
            }
        }
//        return super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        Logger.e(Logger.DEBUG_TAG, "RunService-->onLowMemory!!!! availMem:" + mi.availMem + " threshold:" + mi.threshold);
    }

    @Override
    public void onDestroy() {
        Logger.e(Logger.DEBUG_TAG, "RunService-->onDestroy pid:" + android.os.Process.myPid());
        super.onDestroy();
        if (isDaemonStepMode()) {
            stopDaemonStepCount();
        }
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        clearNotification();
        clearRunData();
//        RefWatcher refWatcher = MixApp.getRefWatcher(this);
//        refWatcher.watch(this);
    }

    /**
     * 清除运动业务数据
     */
    public void clearRunData() {
        BpmManager.getInstance().releaseResource();
        TrailManager.getInstance().releaseResource();
        if (mRunLog != null) {
            mRunLog.clear();
        }
        mRunLog = null;
        myHandler = null;
        bRunning = false;
        bInRunDuration = false;
        lStartRunTime = 0;
        mIsScreenOff = false;
        //region ======================= 语音播报相关 =======================
        iVoiceTimeIndex = 0;
        iVoiceDistanceIndex = 0;
        bPausedVoiceByAudioOrPhone = false;
        if (voiceManager != null)
            voiceManager.releaseResource();
        voiceManager = null;
        //endregion ======================= 语音播报相关 =======================

        //region ======================= 跑步数据刷新相关 =======================
        lRunLogRefreshTime = 0;
        iWeixinStepIndex = -1;
        iTodayStepIndex = -1;
        iRunLogSaveIndex = 0;
        oldGSensorSteps = 0;
        //endregion ======================= 跑步数据刷新相关 =======================

        //region ======================= 任务计划相关 =======================
        bTaskComplete = false;
        taskValue = 0;
        taskType = 0;
        lastCheckTime = 0;
        lastCheckDistance = 0;
        //endregion ======================= 任务计划相关 =======================

        //region ======================= 跑步参数相关 =======================
        sportEnvironment = -1;
        sportWithVoice = false;
        toneType = -1;
        weight = 0;
        height = 0;
        gender = 0;
        age = 0;
        siriTime = -1;
        siriDistance = -1;
        lastWriteStepTime = 0;
        mDaemonStepNotify = false;
        //endregion ======================= 跑步参数相关 =======================

        //region ======================= 地图定位 =======================
        mLastValidLocation = null;
        if (mLocations != null) {
            mLocations.clear();
        }
        mLocations = null;
        locationManager = null;

        //endregion ======================= 地图定位 =======================

        //region ======================= 传感器计步 =======================
        gSensorDistanceLastLocatePos = 0;
        mSensorMissDuration = 0;
        mLastSensorTime = 0;
        //endregion ======================= 传感器计步 =======================

    }

    //endregion ================================== Service生命周期相关 ==================================

    //region ================================== Service保活相关 ==================================
    /**
     * CPU锁,防止CPU休眠
     */
    private PowerManager.WakeLock mCPUWakeLock;
    /**
     * 屏幕是否熄屏
     */
    private boolean mIsScreenOff = false;
    /**
     * 锁屏控制
     */
    private KeyguardManager.KeyguardLock mKeyguardLock;
    /**
     * 熄屏,亮屏广播,跑步过程中强制显示锁屏界面,防止部分手机(如魅族)回收资源
     */
    private BroadcastReceiver mReceiver;

    /**
     * 启动锁屏界面
     */
    private void startLockScreenActivity() {
        Intent intent = new Intent(RunService.this, LockScreenActivity.class);
        if (isGpsLoss()) {
            Logger.e(Logger.DEBUG_TAG, "gps丢失,请求LockScreenActivity点亮屏幕");
        }

        if (isSensorLoss()) {
            Logger.e(Logger.DEBUG_TAG, "sensor丢失,请求LockScreenActivity点亮屏幕");
        }

        if (isDaemonStepMode()) {
            intent.putExtra("only_step", true);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//268435456
        try {
            startActivity(intent);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * 获取WakeLock
     */
    private PowerManager.WakeLock getCPUWakeLock() {
        if (mCPUWakeLock == null) {
            PowerManager manager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            mCPUWakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "RunService_CPU_Lock");//在部分手机,熄屏后加速传感器会停止
        }
        return mCPUWakeLock;
    }

    /**
     * 开启CPU锁定
     */
    private void startCPULock() {
        getCPUWakeLock().acquire();
    }

    /**
     * 释放CPU锁定
     */
    private void releaseCPULock() {
        if (mCPUWakeLock != null) {
            getCPUWakeLock().release();
        }
        mCPUWakeLock = null;
    }

    /**
     * 开启Service存活保护
     */
    private void startKeepAlive() {
        ServiceAliveHelper.getInstance(this).startKeep();
    }

    /**
     * 停止Service存活保护
     */
    private void stopKeepAlive() {
        ServiceAliveHelper.getInstance(this).stopKeep();
    }

    /**
     * 监听屏幕亮屏,熄屏事件,熄屏启动锁屏界面防止部分手机回收Service
     */
    private void registerScreenEventReceiver() {
        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (TextUtils.isEmpty(action)) {
                    return;
                }
//                Logger.i(Logger.DEBUG_TAG, "RunService screen off or on BroadcastReceiver action:" + action);
                if (Intent.ACTION_SCREEN_OFF.equals(action)) {//如果是跑步,则强制显示锁屏界面
//                    if (!isDaemonStepMode()) {
                    //在部分手机,熄屏后加速传感器会停止,因此熄屏时重新注册传感器
                    //https://code.google.com/p/android/issues/detail?id=3708#c46
                    getGSensorStepManager().unregisterSensorListener();
                    getGSensorStepManager().registerSensorListener();
                    getMyHandler().sendEmptyMessageDelayed(Config.MSG_START_LOCK_SCREEN, 1000);
//                    }
                    mIsScreenOff = true;
                } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                    mIsScreenOff = false;
//                    startLockScreenActivity();//激活LockScreenActivity的刷新
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        // 屏幕灭屏广播
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        // 屏幕亮屏广播
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(mReceiver, intentFilter);

        // 跑步过程中,禁止键盘锁
        if (!isDaemonStepMode()) {
            disableKeyguard();
        }
//        Logger.i(Logger.DEBUG_TAG,"runService-->registerScreenEventReceiver mReceiver is null:"+(mReceiver == null)+ " mKeyguardLock is null:"+(mKeyguardLock == null));
    }

    /**
     * 注销屏幕亮屏,熄屏事件
     */
    private void unRegisterScreenEventReceiver() {
        if (mReceiver != null) {
            try {
                unregisterReceiver(mReceiver);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        mReceiver = null;
    }

    /**
     * 禁止键盘锁
     */
    private void disableKeyguard() {
        KeyguardManager manager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        mKeyguardLock = manager.newKeyguardLock("goodLuck");
        mKeyguardLock.disableKeyguard();
    }

    /**
     * 恢复键盘锁
     */
    private void enableKeyguard() {
        if (mKeyguardLock != null) {
            mKeyguardLock.reenableKeyguard();
        }
        mKeyguardLock = null;
    }

    /**
     * 开启Service前台运行方式,并发送通知
     */
    private void sendNotification() {
        //1.如果通知为空或者通知布局为空,创建
        RemoteViews views = new RemoteViews(getPackageName(),
                R.layout.notification_run_service);
        PendingIntent p_intent = PendingIntent.getActivity(MixApp
                .getContext(), 0, new Intent(MixApp.getContext(),
                isDaemonStepMode() ? SettingStepActivity.class : RunMainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
        views.setOnClickPendingIntent(R.id.state, p_intent);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.notification_icon)
                .setContent(views)
                .setContentIntent(p_intent)
                .setShowWhen(true)
                .setWhen(100000)//防止部分机型更新通知栏时闪烁
                .setAutoCancel(true);



        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context
                    .NOTIFICATION_SERVICE);
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "今日步数", importance);
            notificationChannel.enableLights(false);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(false);
           // notificationChannel.setVibrationPattern(new long[]{0});
            mNotificationManager.createNotificationChannel(notificationChannel);
            builder.setChannelId(NOTIFICATION_CHANNEL_ID);
        }

        Notification mStatusNotification = builder.build();

        //2. 设置消息内容
        int id = 0;
        if (!isDaemonStepMode()) {
            if (isRunning()) {
                id = R.string.sporting;//正在运动
            } else if (isInRunDuration()) {
                id = R.string.pause_sporting;//暂停运动
            } else {
                id = R.string.stop_sporting;//停止运动
            }
            //设置跑步过程的运动步数
            mStatusNotification.contentView.setTextViewText(R.id.now_step, String.format(" %s %s ", getRunSteps(), getResources().getString(R.string.run_service_step)));
            mStatusNotification.contentView.setTextViewText(R.id.state, getResources().getString(id));
        }
        mStatusNotification.contentView.setViewVisibility(R.id.rl_running, (id == 0) ? View.INVISIBLE : View.VISIBLE);
        //设置今日步数
        mStatusNotification.contentView.setTextViewText(R.id.tv_step, String.valueOf(todaySteps));

        //3. 发送通知
        try {
            startForeground(0x1234, mStatusNotification);
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "RunService-->sendNotification exception");
        }
//        Logger.i(Logger.DEBUG_TAG, "RunService-->sendNotification todaySteps:"+todaySteps);
    }

    /**
     * 停止Service前台运行方式,并去掉通知栏信息
     */
    private void clearNotification() {
        stopForeground(true);
//        Logger.i(Logger.DEBUG_TAG,"runService-->clearNotification");
    }

    //endregion ================================== Service保活相关 ==================================

    //region ================================== 与Activity交互 ==================================

    /**
     * 获取运动时长
     *
     * @return 运动时长, 单位毫秒
     */
    public long getRunTime() {
        return getRunLogInfo().getRunTime();
    }

    /**
     * 获取运动距离
     *
     * @return 运动距离, 单位米
     */
    public long getRunDistance() {
        return getRunLogInfo().getDistance();
    }

    /**
     * 获取运动步数
     *
     * @return 运动步数
     */
    public int getRunSteps() {
        return getRunLogInfo().getStep();
    }

    /**
     * 获取运动消耗卡路里,单位卡路里
     */
    public long getRunCalorie() {
        return getRunLogInfo().getCalorie();
    }

    private double totalAvgSpeed;
    private double instantSpeed;

    /**
     * 获取跑步速度,单位为米/秒
     */
    public double getRunSpeed() {
        if (getPeriodRunTime() >= 15000 && getRunTime() - 15000 > 0) {
            //15秒前的总平均速度
//            double totalAvgSpeed = distances[0] * 1.0f / (getRunTime() - 15000);
            totalAvgSpeed = distances[0] * 1000.0f / (getRunTime() - 15000);
//            double instantSpeed = (distances[14] - distances[0]) * 1.0f / 15;
            instantSpeed = (distances[14] - distances[0]) * 1.0f / 15;
//            Logger.e(Logger.LOG_TAG, "RunService instantSpeed:" + instantSpeed);
//            Logger.e(Logger.LOG_TAG, "RunService totalAvgSpeed:" + totalAvgSpeed);
            return totalAvgSpeed * 0.2 + instantSpeed * 0.8;
        } else {
            return BpmManager.getInstance().getSpeed(getGender() == Config.GENDER_FEMALE, getHeight());
        }
    }

    /**
     * 获取步频
     */
    public long getRunBpm() {
        //FIXME Test
//        if (getPeriodRunTime() >= 60000) {
//            return BpmManager.getInstance().getShowBpm();
//        }
        if (getPeriodRunTime() >= 15000) {
            return (steps[14] - steps[0]) * 4;
        }
        return BpmManager.getInstance().getBpm();
    }

    /**
     * 获取平均步频,由运动步数与运动时长得出
     */
    public int getAvgBpm() {
        return getRunLogInfo().getBpm();
    }

    /**
     * 获取GPS信号强度,返回值0至4
     */
    public int getGpsSignalLevel() {
        return getLocationManager().getGpsSignalLevel();
    }

    /**
     * 获取今日步数
     */
    public int getTodaySteps() {
        return todaySteps;
    }

    /**
     * 获取定位点信息,注意返回的点不一定是有效定位点
     */
    public TrailInfo getLocationPoint() {
        if (mLastValidLocation != null) {
            TrailInfo trailInfo = new TrailInfo();
            trailInfo.setLat(mLastValidLocation.getLatitude());
            trailInfo.setLng(mLastValidLocation.getLongitude());
            trailInfo.setUsed(true);
            return trailInfo;
        } else {
            if (locationManager != null) {
                AMapLocation location = locationManager.getLastLocationInfo();
                if (location != null) {
                    TrailInfo trailInfo = new TrailInfo();
                    trailInfo.setLat(location.getLatitude());
                    trailInfo.setLng(location.getLongitude());
                    trailInfo.setUsed(false);
                    return trailInfo;
                }
            }
        }
        return null;
    }

    /**
     * 屏幕是否已熄屏
     */
    public boolean isScreenOff() {
        return mIsScreenOff;
    }

//    /**
//     * 获取测试信息
//     */
//    public String getTestString() {
//        return String.format("15秒之前总平均:%.2f,最近15秒平均:%.2f,\n totalAvgSpeed * 0.2 + instantSpeed * 0.8 = %.2f", totalAvgSpeed, instantSpeed,
//                (totalAvgSpeed * 0.2 + instantSpeed * 0.8));
//    }

    //endregion ================================== 与Activity交互 ==================================

    //region ================================== 音乐播放相关 ==================================
    private PlayerService musicPlayerService;//音乐播放服务

    private final ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (!name.getClassName().equals(PlayerService.SERVICE_NAME))
                return;
            musicPlayerService = ((PlayerService.MyBinder) service).getService();
            if (musicPlayerService == null)
                return;
            musicPlayerService.bindRunService(true);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicPlayerService = null;
        }
    };

    /**
     * 连接音乐播放器
     */
    private void connectToPlayerService() {
        if (musicPlayerService != null)
            return;
        Intent intent = new Intent(this, PlayerService.class);
        intent.putExtra("fromRunService", true);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑音乐播放器
     */
    private void disconnectToPlayerService() {
        if (musicPlayerService == null)
            return;
        musicPlayerService.bindRunService(false);
        unbindService(connection);
        musicPlayerService = null;
    }

    //endregion ================================== 音乐播放相关 ==================================

    //region ================================== 跑步参数相关 ==================================
    /**
     * 运动环境,1:室外,2:室内
     */
    private int sportEnvironment = -1;
    /**
     * 是否有语音播报
     */
    private boolean sportWithVoice;
    /**
     * 语音播报语调,int型,0:男声,1:女声
     */
    private int toneType = -1;
    /**
     * 用户体重,单位为千克
     */
    private int weight = 0;
    /**
     * 用户身高,单位为厘米
     */
    private int height = 0;
    /**
     * 用户性别,int型,1:男,2:女
     */
    private int gender = 0;
    /**
     * 用户年龄,int型
     */
    private int age = 0;
    /**
     * 语音播报时间频率类型
     */
    private int siriTime = -1;
    /**
     * 语音播报距离频率类型
     */
    private int siriDistance = -1;

    /**
     * 获取运动环境,1:室外,2:室内
     *
     * @return 运动环境, 1:室外,2:室内
     */
    public int getEnvironment() {
        if (sportEnvironment == -1) {
            sportEnvironment = SettingsHelper.getInt(Config.SETTING_SPORT_ENVIRONMENT, 0);
        }
        return sportEnvironment;
    }

    /**
     * 是否有语音播报
     *
     * @return true:有语音播报,false:没有语音播报
     */
    private boolean isSportWithVoice() {
        if (toneType == -1) {
            sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        }
        return sportWithVoice;
    }

    /**
     * 获取语音播报语调,int型,0:男声,1:女声
     *
     * @return 语音播报语调, int型, 0:男声,1:女声
     */
    public int getToneType() {
        if (toneType == -1) {
            sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        }
        return toneType;
    }

    /**
     * 获取用户体重
     *
     * @return 用户体重, 单位为千克
     */
    public int getWeight() {
        if (weight <= 0) {
            weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);
        }
        if (weight <= 0) {//数据库表保存了Login接口返回为0的结果时
            weight = Config.USER_DEFAULT_WEIGHT;
        }
        return weight;
    }

    /**
     * 获取用户身高
     *
     * @return 用户身高, 单位为厘米
     */
    public int getHeight() {
        if (height <= 0) {
            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        }
        if (height <= 0) {//数据库表保存了Login接口返回为0的结果时
            height = Config.USER_DEFAULT_HEIGHT;
        }
        return height;
    }

    /**
     * 获取用户性别
     *
     * @return 用户性别, 1:男,2:女
     */
    public int getGender() {
        if (gender == 0) {
            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        }
        return gender;
    }

    /**
     * 获取用户年龄
     */
    public int getAge() {
        if (age <= 0) {//age == 0的bug
            age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
            if (age <= 0) {
                age = Config.USER_DEFAULT_AGE;
            }
        }
        return age;
    }

    /**
     * 获取时间播报频率
     */
    public int getSiriTime() {
        if (siriTime == -1) {
            siriTime = SettingsHelper.getInt(Config.SETTING_SIRI_TIME, 0);
        }
        return siriTime;
    }

    /**
     * 获取距离播报频率
     */
    public int getSiriDistance() {
        if (siriDistance == -1) {
            siriDistance = SettingsHelper.getInt(Config.SETTING_SIRI_DISTANCE, 3);//默认1公里,下标为3
        }
        return siriDistance;
    }

    //endregion ================================== 跑步参数相关 ==================================

    //region ================================== 跑步业务相关 ==================================
    private RunLogInfo mRunLog;//运动记录
    /**
     * 上一次运动是否正常结束,只有用户明确结束运动才算正常
     */
    private boolean lastRunFinished;
    /**
     * 跑步过程中保存的运动开始时间
     */
    private long mRunStartTime = -1;
    /**
     * 是否正在跑步,为true时表明用户处于正在运动状态,为false表明用户处于用户暂停状态(没有结束)
     */
    private boolean bRunning;
    /**
     * 是否还在运动过程中,为true时表明用户没有结束运动
     */
    private boolean bInRunDuration;
    /**
     * 本节真正运动的开始时间,即暂停运动后继续运动那一刻的时刻
     */
    private long lStartRunTime;
    /**
     * 最近一次运动异常结束而保存的运动距离
     */
    private long lastRunDistance = -1;
    /**
     * 上一次非正常结束运动时的运动步数
     */
    private int lastSteps = -1;

    /**
     * 获取运动异常结束而保存的运动距离
     */
    private long getLastRunDistance() {
        if (lastRunDistance < 0) {
            lastRunDistance = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_LAST_RUN_DISTANCE, 0);
        }
//        Logger.i(Logger.DEBUG_TAG,"getLastRunDistance lastRunDistance:"+lastRunDistance);
        return lastRunDistance;
    }

    /**
     * 设置运动异常结束而保存的运动距离
     *
     * @param oldDistance 距离,单位米
     */
    private void setLastRunDistance(long oldDistance) {
        if (oldDistance > 0) {
            long saved = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_LAST_RUN_DISTANCE);
            if (oldDistance > saved) {
                PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_LAST_RUN_DISTANCE, oldDistance);
                lastRunDistance = -1;
            }
        }
//        Logger.i(Logger.DEBUG_TAG,"setLastRunDistance distance:"+oldDistance);
    }

    /**
     * 获取上一次非正常结束运动时的运动步数
     */
    private int getLastSteps() {
        if (lastSteps < 0) {
            lastSteps = PrefsHelper.with(this, Config.PREFS_SPORT).readInt(Config.SP_KEY_LAST_RUN_STEPS, 0);
        }
        return lastSteps;
    }

    /**
     * 设置上一次非正常结束运动时的运动步数
     *
     * @param oldSteps 步数
     */
    private void setLastSteps(int oldSteps) {
        if (oldSteps > 0) {
            int saved = PrefsHelper.with(this, Config.PREFS_SPORT).readInt(Config.SP_KEY_LAST_RUN_STEPS, 0);
            if (oldSteps > saved) {
                PrefsHelper.with(this, Config.PREFS_SPORT).writeInt(Config.SP_KEY_LAST_RUN_STEPS, oldSteps);
            }
        }
//        Logger.i(Logger.DEBUG_TAG,"setLastSteps steps:"+oldSteps);
    }

    /**
     * 获取当前跑步记录
     */
    public RunLogInfo getRunLogInfo() {
        if (mRunLog == null) {
            //从数据库加载
            mRunLog = new RunLogInfo();
            int uid = UserDataManager.getUid();
            mRunLog.setUid(uid);//用户ID
            mRunLog.setStartTime(getRunStartTime());//开始时间,单位毫秒
            SportRecord sportRecord = SportRecordsHelper.getUncompletedRunRecords(this, uid, getRunStartTime());
            if (sportRecord != null) {
                mRunLog.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                mRunLog.setType(sportRecord.getType());//运动类型(跑步,骑行),跑步为1
                mRunLog.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                mRunLog.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                mRunLog.setLocationType(sportRecord.getLocationType());//定位类型,1:GPS定位,2:LBS定位
                mRunLog.setDistance(sportRecord.getDistance());//运动距离,单位米
                mRunLog.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                mRunLog.setStartLat(sportRecord.getStartLat());//开始点经度
                mRunLog.setStartLng(sportRecord.getStartLng());//开始点经度
                mRunLog.setEndLat(sportRecord.getEndLat());//结束点纬度
                mRunLog.setEndLng(sportRecord.getEndLng());//结束点经度
                mRunLog.setStep(sportRecord.getStep());//步数
                mRunLog.setCalorie(sportRecord.getCalorie() == null ? 0 : sportRecord.getCalorie());//卡路里
                mRunLog.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                mRunLog.setConsumeFat(sportRecord.getConsumeFat() == null ? 0 : sportRecord.getConsumeFat());//脂肪燃烧克数
                mRunLog.setElevation(sportRecord.getElevation() == null ? 0 : sportRecord.getElevation());//累积爬升

                Logger.i(Logger.DEBUG_TAG, "RunService-->getRunLogInfo mRunLog:" + mRunLog);
            }
        }
        return mRunLog;
    }

    /**
     * 获取上一次运动是否正常完成
     *
     * @return true:完成,false:未完成
     */
    public boolean isLastRunFinished() {
        //如果上一次运动未正常结束,从SharedPreferences确认上一次运动完成状态
        if (!lastRunFinished) {
            long saveTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_LAST_RUN_SAVE_TIME, 0);
            if (saveTime == 0) {//APP第一次运动时,直接算上一次运动是完成的
                lastRunFinished = true;
            } else {
                lastRunFinished = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_LAST_RUN_FINISHED, true);
            }
        }
        return lastRunFinished;
    }

    /**
     * 设置运动完成标志,用于下一次运动开始时判断是否要恢复数据。
     * <p/>
     * 开始运动时,设置为false,用户确定运动结束时,设置为true;
     *
     * @param isFinished true:本次运动结束,false:本次运动未结束
     */
    public void setRunFinishFlag(boolean isFinished) {
        PrefsHelper.with(this, Config.PREFS_SPORT).writeBoolean(Config.SP_KEY_LAST_RUN_FINISHED, isFinished);
        PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_LAST_RUN_SAVE_TIME, System.currentTimeMillis());

        if (isFinished) {
            mRunStartTime = -1;
            lastRunDistance = -1;
            lastSteps = -1;
            PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_START_TIME, -1);//运动完成时,运动开始时间清除状态
            PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_LAST_RUN_DISTANCE, 0);//运动完成时,运动距离清除状态
            PrefsHelper.with(this, Config.PREFS_SPORT).writeInt(Config.SP_KEY_LAST_RUN_STEPS, 0);//运动完成时,运动步数清除状态
        }
    }

    /**
     * 获取跑步过程中保存的开始运动时间
     */
    public long getRunStartTime() {
        if (mRunStartTime < 0) {
            mRunStartTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_START_TIME);
        }
        return mRunStartTime;
    }

    /**
     * 获取是否正在运动中
     *
     * @return true:运动中,false:运动暂停
     */
    public boolean isRunning() {
        return bRunning;
    }

    /**
     * 设置是否正在运动中
     *
     * @param bRunning true:运动中,false:运动暂停
     */
    private void setRunning(boolean bRunning) {
        this.bRunning = bRunning;
    }

    /**
     * 获取是否处在运动过程中
     *
     * @return true:表示还在运动,false:表示运动结束
     */
    public boolean isInRunDuration() {
        return bInRunDuration;
    }

    /**
     * 设置是否处在运动过程中
     *
     * @param bInRunDuration 设置是否在运动过程中
     */
    private void setInRunDuration(boolean bInRunDuration) {
        this.bInRunDuration = bInRunDuration;
    }

    /**
     * 获取本节真正运动的开始时间
     */
    private long getStartRunTime() {
        return lStartRunTime;
    }

    /**
     * 设置本节真正运动的开始时间
     *
     * @param time 运动开始时间
     */
    private void setStartRunTime(long time) {
        lStartRunTime = time;
    }

    /**
     * 获取本次运动开始到现在的时间
     */
    private long getPeriodRunTime() {
        return System.currentTimeMillis() - getStartRunTime();
    }

    /**
     * 从最近一次为了防止运动异常结束而保存的运动数据中恢复数据
     */
    private void recoveryLastRunData() {
        //1.还在运动过程中则返回
        if (isInRunDuration()) {
            return;
        }
        getRunLogInfo();
        setLastRunDistance(getRunLogInfo().getDistance());
        setLastSteps(getRunLogInfo().getStep());
    }

    /**
     * 创建新的运动日志
     */
    private void newRunLog() {
        mRunLog = new RunLogInfo();
        getRunLogInfo().setUid(UserDataManager.getUid());//用户ID
        getRunLogInfo().setLocationType(Config.LOCATION_TYPE_NONE);//定位类型
        getRunLogInfo().setType(1);//运动类型,1表示跑步
        getRunLogInfo().setMode(getEnvironment());//运动环境
        getRunLogInfo().setUploaded(2);//是否与服务器同步

        long startTime = getRunLogRefreshTime() / 1000 * 1000;//精确到秒
        PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_START_TIME, startTime);//保存运动开始时间到sp,防止runLogInfo被清
        getRunLogInfo().setStartTime(startTime);
        SportRecordsHelper.deleteStepInfo(this);
        SportRecordsHelper.deleteTrailPoints(this);
    }

    /**
     * 准备跑步
     */
    public void prepareRun() {
        //1.如果后台计步在运行,先停止计步
        boolean daemonStepCounter = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        Logger.i(Logger.DEBUG_TAG, "RunService-->prepareRun getStepCountAlways():" + daemonStepCounter
                + " isLastRunFinished():" + isLastRunFinished());
        if (daemonStepCounter) {
            stopDaemonStepCount();
        }
        //2.如果上一次运动没有正常结束,从上一次运动中恢复数据
        if (!isLastRunFinished()) {
            recoveryLastRunData();
        }
        //3.退出仅计步模式
        setDaemonStepMode(false);
        //4.如果上一次运动正常结束,清除跑步数据
        if (isLastRunFinished()) {
            clearRunData();
        }
    }

    /**
     * 开始跑步
     */
    public void startRun() {
        //1.设置本节真正运动的开始时间
        setStartRunTime(System.currentTimeMillis());
        //2.设置运动记录最近刷新时间
        setRunLogRefreshTime(System.currentTimeMillis());
        //3.连接音乐播放器
        connectToPlayerService();
        //4.如果上一次运动正常结束,开始新的记录
        if (isLastRunFinished()) {
            newRunLog();
        }
        //5.开启传感器计步
        startGSensorManager();
        //6.根据运动环境决定是否需要定位和写轨迹文件,仅室外模式下才定位和写轨迹文件
        startLocationIfNeed();//开启定位
        //7.根据是否有语音播报来开启语音播报
        startVoiceMessageIfNeed();
        //8.更新运动状态
        setRunning(true);
        setInRunDuration(true);
        setRunFinishFlag(false);//设置运动完成标志为未完成
        PrefsHelper.with(this, Config.PREFS_SPORT).writeBoolean(Config.SP_KEY_RUN_SPORT, true);//设置当前为跑步运动,用于跳绳状态判断
        //9.以前台方式运行,并向通知栏发送消息
        sendNotification();
        //10.获取CPU锁、开始Service保护并注册屏幕熄屏事件
        startCPULock();
        startKeepAlive();
        registerScreenEventReceiver();
        //11.开启每秒刷新运动数据
        getMyHandler().sendEmptyMessageDelayed(
                Config.MSG_REPEAT_EVERY_SECOND, 1000);
        Logger.d(Logger.DEBUG_TAG, "RunService-->startRun");
    }

    /**
     * 继续运动
     */
    public void continueRun() {
        if (isRunning())
            return;
        //1.设置当前时间为本节真正运动的开始时间
        setStartRunTime(System.currentTimeMillis());
        //2.设置运动记录最近刷新时间
        setRunLogRefreshTime(System.currentTimeMillis());
        //3.开始计步
        continueGSensorManager();
        //4.清除缓存的(用于分析平均步频)步数信息
        clearRecentCachedSteps();
        //5.播报语音提示:【继续运动】
        continueVoiceManager();
        //6.设置运动状态为运动中
        setRunning(true);
        //7.更新通知栏运动状态
        sendNotification();
        Logger.d(Logger.DEBUG_TAG, "RunService-->continueRun");
    }

    /**
     * 暂停跑步
     */
    public void pauseRun() {
        if (!isRunning())
            return;
        //1.停止计步
        stopGSensorManager();
        //2.清除缓存的(用于分析平均步频)步数信息
        clearRecentCachedSteps();
        //3.语音播报:【暂停运动】
        pauseVoiceManager();
        //4.设置运动状态为暂停运动
        setRunning(false);
        //5.更新通知栏运动状态
        sendNotification();
        Logger.d(Logger.DEBUG_TAG, "RunService-->pauseRun");
    }

    /**
     * 停止跑步
     */
    public void stopRun(int minute) {
        //1.关闭每秒刷新运动数据
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        //2.停止音乐播放
        disconnectToPlayerService();
        getVoiceManager().releaseMetronome();
        //3.停止定位和停止写轨迹文件
        unregisterWakeGpsAlarm();
        stopLocation();
        //4.停止计步和停止写计步文件
        stopGSensorManager();
        //5.语音播报【运动完成】
        playStopRunVoice(minute);

        //6.心率UserHeartRate类数据
        if (getUserHeartRateFinish() != null) {
            getUserHeartRateFinish().doUserHeartRateFinish();

        }

        //7.纠正由于传感器不工作导致的步数偏少
        float percent = getSensorMissDuration() * 1.0f / getRunTime();
        Logger.i(Logger.DEBUG_TAG, "stopRun-->miss data percent:" + percent);
        if (percent > 0.2) { //传感器不工作的时间大于总运动时间的20%时,需要加一个估算步数
            //9.1添加异常标志
            getRunLogInfo().setBpmMatch(-2);

            //7.2计算各个参数
            int step = getRunLogInfo().getStep();
            long distance = getRunLogInfo().getDistance();
            long runTotalTime = getRunLogInfo().getRunTime();
            long responseTime = runTotalTime - getSensorMissDuration();//传感器响应时长
            int bpm = 0;
            if (responseTime > 60000) {
                bpm = (int) (1.0f * step / (responseTime / 60000.0f));//真正的bpm
            } else if (responseTime > 0) {
                bpm = (int) (step * 60000.0f / responseTime);//真正的bpm
            }

            float velocity = 0;//速度,米/秒
            if (runTotalTime > 0) {
                velocity = distance * 1000.0f / runTotalTime;
            }

            Logger.i(Logger.DEBUG_TAG, "step:" + step + ",runTotalTime:" + runTotalTime + ",runTime:" + responseTime + ",bpm:" + bpm + ",velocity:" + velocity);
            //7.3估算步数条件判断
            if (runTotalTime >= 600000 && velocity > 0 && velocity < 4.15f) {//总时长>=10分钟情况下,并且平均速度小于4.15米/秒才估算。否则大于4.15米/秒认为是坐车,4.15米/秒大概是15公里/小时。
                float estimateBpm = 2.5f;//默认以bpm 150为准,即每秒钟2.5步
                //bpm大于180,且真正有传感器数据的跑步时间>=20分钟情况下,估算以bpm 180 为准,即每秒钟3步
                if (bpm > 180 && responseTime > 1200000) {
                    estimateBpm = 3.0f;
                } else if (bpm < 100) { //bpm 90为准
                    estimateBpm = 1.5f;
                } else if (bpm >= 100 && bpm < 130) {//bpm 120为准
                    estimateBpm = 2.0f;
                }

                int estimateSteps = (int) (estimateBpm * getSensorMissDuration() / 1000);
                //重新设置步数、卡路里和距离
                getRunLogInfo().setStep(step + estimateSteps);//重新估算步数
                Logger.i(Logger.DEBUG_TAG, "estimateBpm" + estimateBpm + ",step:" + step + ",estimateSteps:" + estimateSteps + ",totalStep:" + getRunLogInfo().getStep() + ",calorie:" + getRunLogInfo().getCalorie());
                refreshAverageBpmInfo();
                getRunLogInfo().setCalorie(calculateCalorie());
                Logger.i(Logger.DEBUG_TAG, "new calorie:" + getRunLogInfo().getCalorie());

                //室内模式的话,修正距离
                if (getRunLogInfo().getMode() == 2) {//室内运动
                    int estimateDistance = (int) (estimateSteps * BpmManager.getStepRatioByBpm((int) (estimateBpm * 60), getGender() == Config.GENDER_FEMALE) * getHeight()
                            / 100);
                    getRunLogInfo().setDistance(distance + estimateDistance);//重新估算距离
                } else if (getRunLogInfo().getMode() == 1) {//室外运动
                    if (getRunLogInfo().getStartLat() == 0 && getRunLogInfo().getStartLng() == 0) {//没有定位数据
                        int estimateDistance = (int) (estimateSteps * BpmManager.getStepRatioByBpm((int) (estimateBpm * 60), getGender() == Config.GENDER_FEMALE) * getHeight()
                                / 100);
                        getRunLogInfo().setDistance(distance + estimateDistance);//重新估算距离
                    }
                }

            }

            //7.4上传异常日志
            String error = String.format("'uid':%s,'运动开始时间':%s,'计步算法步数':%s,'距离':%s,'总时长':%s,'传感器响应时长':%s,'运动速度':%s",
                    getRunLogInfo().getUid(), getRunLogInfo().getStartTime(), step, distance, runTotalTime, responseTime, velocity);
            SportDataManager.getInstance().uploadSensorAbnormalError(error, "PedometerAbnormal");
        }

        //8.保存运动记录,今日步数,轨迹文件,计步文件
        saveRunRecordToDb(getRunLogInfo(), 1);
        writeTodaySteps(todaySteps);
        writeFiles();
        //9.更新运动状态
        setRunning(false);
        setInRunDuration(false);
        setRunFinishFlag(true);
        PrefsHelper.with(this, Config.PREFS_SPORT).writeBoolean(Config.SP_KEY_RUN_SPORT, false);//设置当前为跑步运动,用于跳绳状态判断
        clearNotification();
        //10.清空心率相关数据
        clearHeartRateData();
        //11.释放CPU锁、停止Service保护并注销监听屏幕亮熄屏事件
        releaseCPULock();
        stopKeepAlive();
        unRegisterScreenEventReceiver();
        enableKeyguard();
        //12.继续后台计步
        boolean daemonStepCount = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        if (daemonStepCount) {
            stopDaemonStepCount();
            startDaemonStepCount();
        }
        Logger.d(Logger.DEBUG_TAG, "RunService-->stopRun");
    }

    /**
     * 写轨迹文件,计步文件
     */
    private void writeFiles() {
        final int uid = UserDataManager.getUid();
        final long runId = getRunStartTime();
        if (runId < 0) {
            return;
        }
        final String stepFileName = Config.PATH_DOWN_STEP + uid + "_" + runId + ".step";
        final String trailFileName = Config.PATH_DOWN_TRAIL + uid + "_" + runId + ".json";

//        Logger.i(Logger.DEBUG_TAG, "runService writeFiles-->stepFileName:" + stepFileName + " trailFileName:" + trailFileName +
//                "heartRateFileName:" + heartRateFileName);

//        final long now = System.currentTimeMillis();

        SportRecordsHelper.asyncGetAllStepInfo(this, uid, runId, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                try {
                    //调试用
//                    String test = Config.PATH_DOWN_STEP + "test.step";
//                    FileUtils.copyFile(test, stepFileName);
//                    SportRecordsHelper.getInstance().deleteStepInfo(RunService.this, uid, runId);

                    List<StepInfo> stepInfoList = (List<StepInfo>) operation.getResult();
                    if (stepInfoList != null && stepInfoList.size() > 0) {
                        List<RunStepInfo> runStepInfoList = new ArrayList<>();
                        //数据库步数信息实体(StepInfo)转换为运动步数信息实体(RunStepInfo)
                        for (StepInfo stepInfo : stepInfoList) {
                            RunStepInfo runStepInfo = new RunStepInfo();
                            runStepInfo.setTime(stepInfo.getTime());
                            runStepInfo.setStep(stepInfo.getSteps());
                            runStepInfo.setDistance(stepInfo.getDistance());
                            runStepInfoList.add(runStepInfo);
                        }

                        /** 如果运动记录中有心率资料，则搜索心率数据库表，并删除数据库表。若无，则直接删除数据库表数据！*/
                        if (!TextUtils.isEmpty(getRunLogInfo().getHeartRateDate())) {
                            searchHeartRateData(uid, runId, runStepInfoList, stepFileName);
                        } else {//无心率数据，直接写计步文件
                            boolean success = JsonHelper.writeRunStepFile(stepFileName, runStepInfoList);
                            if (success) {//写文件成功,删除数据库表记录
                                SportRecordsHelper.deleteStepInfo(RunService.this, uid, runId);
                            }
                        }
//                        Logger.i(Logger.DEBUG_TAG, "write file runStepInfoList size:" + runStepInfoList.size()
//                                + " thread id:" + Thread.currentThread().getId() + " time:" + (System.currentTimeMillis() - now));

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        if (getEnvironment() == RunLogInfo.SPORT_MODE_OUTDOOR) {//室外模式再写轨迹文件
            SportRecordsHelper.asyncGetAllTrailPoint(this, uid, runId, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    //调试用
//                    String test = Config.PATH_DOWN_TRAIL + "347796_1469012459000.json";
//                    FileUtils.copyFile(test, trailFileName);
//                    SportRecordsHelper.getInstance().deleteTrailPoints(RunService.this, uid, runId);
//                    Logger.i(Logger.DEBUG_TAG, "write file trailInfoList thread id:" + Thread.currentThread().getId() + " time:" + (System.currentTimeMillis() - now));

                    List<TrailPoint> trailPointList = (List<TrailPoint>) operation.getResult();
                    if (trailPointList != null && trailPointList.size() > 0) {
                        List<TrailInfo> trailInfoList = new ArrayList<>();
                        //数据库轨迹点信息实体(TrailPoint)转换为运动轨迹信息实体(TrailInfo)
                        for (TrailPoint trailPoint : trailPointList) {
                            TrailInfo trailInfo = new TrailInfo();
                            trailInfo.setTime(trailPoint.getTime());
                            trailInfo.setType(trailPoint.getType());//定位类型
                            trailInfo.setLng(trailPoint.getLng());
                            trailInfo.setLat(trailPoint.getLat());
                            trailInfo.setSportState(trailPoint.getSportState());
                            trailInfo.setAccuracy(trailPoint.getAccuracy());
                            trailInfo.setSpeed(trailPoint.getSpeed());
                            trailInfo.setAltitude(trailPoint.getAltitude());
                            trailInfo.setBearing(trailPoint.getBearing());
                            trailInfo.setUsed(true);

                            trailInfoList.add(trailInfo);
                        }

//                        Logger.i(Logger.DEBUG_TAG, "write file trailInfoList size:" + trailInfoList.size()
//                                + " thread id:" + Thread.currentThread().getId() + " time:" + (System.currentTimeMillis() - now));
                        boolean success = JsonHelper.writeRunTrailFile(trailFileName, trailInfoList);
                        if (success) {//写文件成功,删除数据库表记录
                            SportRecordsHelper.deleteTrailPoints(RunService.this, uid, runId);
                        }
                    }
                }
            });
        }

    }

    /**
     * 搜索指定用户、运动开始时间戳的心率记录，写计步文件操作
     *
     * @param uid
     * @param startRunTime
     */
    private void searchHeartRateData(final int uid, final long startRunTime, final List<RunStepInfo> stepInfoList, final String stepFileName) {
        SportRecordsHelper.asyncGetAllHeartRateInfo(this, uid, startRunTime, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                try {
                    List<HeartRateInfo> heartRateInfoList = (List<HeartRateInfo>) operation.getResult();
                    List<HeartRateJsonInfo> heartRateChartInfoList = new ArrayList<>();
                    if (heartRateInfoList != null && heartRateInfoList.size() > 0) {
                        //数据库步数信息实体(StepInfo)转换为运动步数信息实体(RunStepInfo)
                        for (HeartRateInfo heartRateInfo : heartRateInfoList) {
                            HeartRateJsonInfo heartRateChartInfo = new HeartRateJsonInfo();
                            heartRateChartInfo.setTime(heartRateInfo.getTime());
                            heartRateChartInfo.setHeartrate(heartRateInfo.getHeartRate());
                            heartRateChartInfoList.add(heartRateChartInfo);
                        }
                    }
                    //无论数据库搜索结果如何，都要会进行写文件操作
                    boolean success = JsonHelper.writeRunStepFile(stepFileName, stepInfoList, heartRateChartInfoList);
                    if (success) {//写文件成功,删除数据库表记录（心率与计步）
                        SportRecordsHelper.deleteHeartRateInfo(RunService.this, uid, startRunTime);
                        SportRecordsHelper.deleteStepInfo(RunService.this, uid, startRunTime);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    //endregion ================================== 跑步业务相关 ==================================

    //region ================================== 跑步数据刷新相关 ==================================
    /**
     * 当前跑步记录最近刷新的时间
     */
    private long lRunLogRefreshTime;
    /**
     * 上次写今日步数时的gSensor计步步数
     */
    private int oldGSensorSteps;
    /**
     * 记录保存索引号
     */
    private long iRunLogSaveIndex;
    /**
     * 微信计步索引号
     */
    private int iWeixinStepIndex = -1;
    /**
     * 今日计步保存索引号
     */
    private int iTodayStepIndex = -1;
    /**
     * 今日步数
     */
    private int todaySteps;
    /**
     * 最近一次写入数据库表(StepInfo)的时间
     */
    private long lastWriteStepTime;
    /**
     * 最近15秒的距离变化
     */
    private long[] distances = new long[15];

    /**
     * 最近15秒的步数变化
     */
    private int[] steps = new int[15];

    /**
     * 获取记录上次刷新时间
     */
    public long getRunLogRefreshTime() {
        return lRunLogRefreshTime;
    }

    /**
     * 设置运动记录最近刷新时间
     *
     * @param time 设置记录上次刷新时间
     */
    private void setRunLogRefreshTime(long time) {
        lRunLogRefreshTime = time;
    }

    /**
     * 运动数据刷新
     */
    private void refresh() {
//        Logger.i("TT","RunService-->refresh isDaemonStepMode:"+isDaemonStepMode()+" mDaemonStepNotify:"+mDaemonStepNotify);
        if (isDaemonStepMode()) {//只计步时,只需要刷新步数
            refreshTodaySteps();
            // 2.步数刷新,刷新通知栏
            if (mDaemonStepNotify) {
                sendNotification();
            } else {
                clearNotification();
            }
        } else {
            //1.刷新步数
            refreshTodaySteps();
            //2.刷新通知栏
            sendNotification();
            //3.统计脂肪消耗,需要比刷新跑步记录先执行
            refreshFatBurn();
            //4.刷新跑步记录,语音播报
            refreshRunLog();
            refreshVoice();
            if (isNeedLocateAndSaveTrail() && (getLocationManager().getOnAMapLocationChangeListener() == null)) {
                getLocationManager().setOnAMapLocationChangeListener(mLocationChangeListener);
            }
            //5.如果熄屏,启动锁屏界面
//            if (mIsScreenOff) {//
//                startLockScreenActivity();
//            }
        }
    }

    /**
     * 获取存储的最大心率，因为FitmixUtil.getMaxHearRate(age)计算复杂，不适合每次都执行
     *
     * @return
     */
    private int getMaxHeartRate() {
        if (maxHeartRate == 0) {
            maxHeartRate = SettingsHelper.getInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age));
        }
        return maxHeartRate;
    }

    /**
     * 每秒刷新脂肪燃烧克数
     */
    private void refreshFatBurn() {
        int hr;
        if (latestHeartRate == 0) {
//            int maxHeartRate = SettingsHelper.getInt(Config.HEART_RATE_MAX,FitmixUtil.getMaxHeartRate(age));
            hr = getHeartRateByPace((float) getRunSpeed(), getMaxHeartRate(), latestRestHeartRate);
        } else {
            hr = latestHeartRate;
        }
        if (getRunTime() > 0) {
            float nowCalorie = calculateCalorie();
            if (nowCalorie - lastCalorie > 1) {
                int level = FitmixUtil.getHeartRateLevel(hr, latestRestHeartRate != 0 ? latestRestHeartRate : Config.HEART_RATE_DEFAULT_REST_HR);
//                int level = 1;
                float fatBurnAdd = FitmixUtil.getFatBurnFromCal(nowCalorie - lastCalorie, level);
                lastCalorie = nowCalorie;
                if (fatBurnAdd > 0) {
                    fatBurn += fatBurnAdd;
                }
//                Logger.i(Logger.DEBUG_TAG, "fatBurnAdd:" + fatBurnAdd + ",fatBurn:" + fatBurn);
            }
        }
    }

    /**
     * 根据配速获取心率目标区限度
     *
     * @param dSpeed               配速，单位为米/秒
     * @param maxHR                最大心率
     * @param lastRestingHeartRate 最近一次静息心率
     * @return
     */
    private int getHeartRateByPace(float dSpeed, int maxHR, int lastRestingHeartRate) {
//        Logger.i(Logger.DEBUG_TAG, "RunService-->getHeartRateByPace dSpeed:" + dSpeed + ",maxHR:" + maxHR + ",lastRestingHeartRate:" + lastRestingHeartRate);
        long runPace = 0;//配速，单位为：公里/分钟
        if (dSpeed > 0) {//得到每公里需要的秒数
            runPace = (int) (1000 / dSpeed);
        } else if (dSpeed < 0) {
            runPace = (int) (1000 / dSpeed) * -1;
        }

        if (runPace < 0) {
            runPace = -runPace;
        }
        runPace = runPace / 60;//配速，单位为：公里/分钟

        float intensity;
        if (runPace >= 10) {
            if (runPace < 30 && runPace >= 20) {
                intensity = 0.51f + 0.06f * (30 - runPace) / 10;
            } else if (runPace < 20 && runPace >= 10) {
                intensity = 0.57f + 0.03f * (20 - runPace) / 10;
            } else {
                intensity = 0.50f;
            }
        } else if (runPace < 10 && runPace >= 7) {
            //配速7:03的时候 正好是8.5公里每小时 差不多已经开始上运动量了
            if (runPace < 10 && runPace >= 8) {
                intensity = 0.60f + 0.07f * (10 - runPace) / 2;
            } else {
                intensity = 0.67f + 0.03f * (8 - runPace);
            }
        } else if (runPace < 7 && runPace >= 3) {
            if (runPace < 7 && runPace >= 5) {
                intensity = 0.70f + 0.07f * (7 - runPace) / 2;
            } else {
                intensity = 0.77f + 0.03f * (5 - runPace) / 2;
            }
        } else if (runPace < 3 && runPace > 0) {
            if (runPace < 3 && runPace >= 2) {
                intensity = 0.80f + 0.085f * (3 - runPace);
            } else {
                intensity = 0.885f + 0.015f * (2 - runPace) / 2;
            }
        } else {
            return 0;
        }
        return (int) (lastRestingHeartRate + intensity * (maxHR - lastRestingHeartRate));
    }

    /**
     * 刷新今日步数
     */
    private void refreshTodaySteps() {
        int steps = getGSensorStepManager().getSteps();
        int stepDiff = steps - oldGSensorSteps;
        // 1.更新今日步数
        addTodayStepsValue(stepDiff);
        oldGSensorSteps = steps;
        //2.每1000步同步一次微信步数
        if (((steps / 1000) != iWeixinStepIndex) && ApiUtils.isNetWorkAvailable()) {
            iWeixinStepIndex = steps / 1000;
            FitmixUtil.syncWeChatStep(this, true);
        }
    }

    /**
     * 刷新跑步记录
     */
    private void refreshRunLog() {
        if (!isRunning())
            return;
        //1.更新运动时长
        long now = System.currentTimeMillis();

        //2.更新运动记录
        long lDistance;
        /**
         * 在得到定位起点的一瞬间保存传感器步数计算出的距离,
         * 具体见方法{@link com.fitmix.sdk.controller.RunService.getValidStartPoint}方法
         * **/
        if (isNeedLocateAndSaveTrail()) { //室外模式
            if (TrailManager.getInstance().getPointUsed() == 1) {//得到起始点的那一瞬间
                lDistance = 0;
                lDistance += getRunDistanceByGSensor() - getSensorDistanceLastLocatePos();
            } else if (TrailManager.getInstance().getPointUsed() > 1) {//有了GPS距离
                // 室外模式且有gps定位轨迹情况,
                // 运动距离 = A + B ,其中A表示 最近一次GPS计算出的运动距离, B表示 最近一次有效定位时到此刻的GPS运动距离空白期,
                // 而 B 只能用传感器步数得出的距离来估算,因此
                // 运动距离 = 最近一次GPS计算出的运动距离 + (此刻传感器步数计算出的距离-最近一次有效定位点时的传感器步数计算出的距离)
                lDistance = getRunDistanceByGPS();
                lDistance += getRunDistanceByGSensor() - getSensorDistanceLastLocatePos();
                //防止GPS关闭后,由于getRunDistanceByGPS大于getRunDistanceByGSensor造成运动距离减少的现象
                if (lDistance < (getRunDistance() - getLastRunDistance())) {
                    lDistance = getRunDistance() - getLastRunDistance();
                }
            } else {//室外模式但没有gps定位轨迹情况,只用传感器步数计算出的距离
                lDistance = getRunDistanceByGSensor();
            }
        } else {//室内情况
            lDistance = getRunDistanceByGSensor();
        }
        long distance = getLastRunDistance() + lDistance;
        getRunLogInfo().setDistance(distance);//距离
        getRunLogInfo().setEndTime(now);//运动结束时间
        getRunLogInfo().setRunTime(getRunLogInfo().getRunTime() + (now - getRunLogRefreshTime()));//运动时长
        int step = getLastSteps() + getGSensorStepManager().getSteps();
        getRunLogInfo().setStep(step);//设置运动步数
        refreshDistanceAndStep(distance, step);//加入距离、步数变化列表,用于计算速度-->配速以及步频
        refreshAverageBpmInfo();//由运动时长和运动步数-->刷新平均步频
        getRunLogInfo().setCalorie(calculateCalorie());//卡路里
        getRunLogInfo().setConsumeFat(fatBurn);//增加脂肪燃烧字段
        /**
         * 每次刷新都存下心率统计数据
         * 好处:每秒的进行调用getUserHeartRateFinish()回调方法,防止被回收
         * 小问题:由于runService与HeartRateService刷新的时间不同步,在RunService每秒存下的HeartRateService的统计数据可能不是最新的
         * 因此在运动结束时必须更新到最新数据
         */
        if (getUserHeartRateFinish() != null && getUserHeartRateFinish().getUserHeartRate() != null) {
            UserHeartRate user_hr = getUserHeartRateFinish().getUserHeartRate();
            user_hr.setConsumptionSpendTime(getRunTime());
            String heartRateString = JsonHelper.createJsonString(user_hr);
            getRunLogInfo().setHeartRateDate(heartRateString);
        }

        //3.检查传感器工作状况
        long sensorSleepDuration = now - getGSensorStepManager().getLastSensorTime();
        if (sensorSleepDuration > 15000 && sensorSleepDuration < 604800000L) {//传感器长时间未响应,大于15秒并且小于1个星期
            if (mLastSensorTime != getGSensorStepManager().getLastSensorTime()) {
                mSensorMissDuration += sensorSleepDuration;
                mLastSensorTime = getGSensorStepManager().getLastSensorTime();
            } else {
                mSensorMissDuration += (now - getRunLogRefreshTime());
            }
            if (!mSensorLoss) {
                startLockScreenActivity();
            }
            mSensorLoss = true;
            Logger.e(Logger.DEBUG_TAG, "传感器长时间未响应,lastSensorTime:" + getGSensorStepManager().getLastSensorTime() + ",sensorSleepDuration:" + sensorSleepDuration + ",mSensorMissDuration:" + mSensorMissDuration);
        } else if (sensorSleepDuration > 10000) {//传感器未响应
            Logger.e(Logger.DEBUG_TAG, "传感器未响应,lastSensorTime:" + getGSensorStepManager().getLastSensorTime() + ",sensorSleepDuration:" + sensorSleepDuration);
            //尝试重新注册传感器
            getGSensorStepManager().unregisterSensorListener();
            getGSensorStepManager().registerSensorListener();
        }
//        else if(sensorSleepDuration > 5000){
//            Logger.e(Logger.DEBUG_TAG,"传感器异常观察期,lastSensorTime:"+getGSensorStepManager().getLastSensorTime() +",sensorSleepDuration:"+sensorSleepDuration);
//        }
        else {
            mSensorLoss = false;
        }

        //4.检测GPS工作状况
        if (isNeedLocateAndSaveTrail()) { //室外模式
            long gpsSleepDuration = now - getLocationManager().getLastGpsTime();
            if (gpsSleepDuration > 15000 && gpsSleepDuration < 604800000L) {//GPS长时间未响应,大于15秒并且小于1个星期
                //尝试重新激活定位,没有效果
//                getLocationManager().activateLocate();
                if (!mGpsLoss) {
                    startLockScreenActivity();
                }
                mGpsLoss = true;
            } else {
                mGpsLoss = false;
            }
        }

        //5.更新记录刷新时间
        setRunLogRefreshTime(now);
        //6.每30秒保存最近一次运动信息为了防止被杀死
        if ((getRunLogInfo().getRunTime() / 30000) != iRunLogSaveIndex) {
            iRunLogSaveIndex = getRunLogInfo().getRunTime() / 30000;
            //并且如果距离大于100米,则更新数据库中的运动记录
            if (getRunLogInfo().getDistance() >= 100) {
                saveRunRecordToDb(getRunLogInfo(), 0);
            }
        }
        //7.检测运动目标完成情况
        checkTaskObject(now);

    }

    /**
     * 刷新最近15秒距离、步数信息
     */
    private void refreshDistanceAndStep(long distance, int step) {
//        Logger.i(Logger.DEBUG_TAG, "refreshDistanceAndStep distance:" + distance + ",step:" + step);
        for (int i = 0; i < 14; i++) {
            distances[i] = distances[i + 1];
            steps[i] = steps[i + 1];
        }
        distances[14] = distance;
        steps[14] = step;
    }

    /**
     * 刷新平均步频
     */
    private void refreshAverageBpmInfo() {
        int bpm = 0;
        if (getRunTime() > 60000) {//int型溢出
            bpm = (int) (getRunSteps() * 1.0f / (getRunTime() / 60000.0f));
        } else if (getRunTime() > 0) {
            bpm = (int) (getRunSteps() * 60000.0f / getRunTime());
        }
        if (bpm > 240) {//限制跑步最高bpm
            bpm = 240;
        }
        getRunLogInfo().setBpm(bpm);
//        getRunLogInfo().setBpmMatch(-1);
    }

    /**
     * 刷新语音播报
     */
    private void refreshVoice() {
        if (!isRunning())
            return;

        //1.满足时间播报频率时,播报运动成绩
        int iTimeStep = getSiriTimeByIndex(getSiriTime());
        int iRunTime = (int) (getRunTime() / 1000);
        boolean bEnableTime = false;
        if (iTimeStep > 0) {
            int iTempTimeIndex = iRunTime / iTimeStep;
            if (iTempTimeIndex != getVoiceTimeIndex()) {
                setVoiceTimeIndex(iTempTimeIndex);
                bEnableTime = true;
            }
        }

        //2.满足距离播报频率时,播报运动成绩
        int iDistanceStep = getSiriDistanceByIndex(getSiriDistance());
        int iDistance = (int) getRunDistance();
        boolean bEnableDistance = false;
        if (iDistanceStep > 0) {
            int iTempDistanceIndex = iDistance / iDistanceStep;
            if (iTempDistanceIndex != getVoiceDistanceIndex()) {
                setVoiceDistanceIndex(iTempDistanceIndex);
                bEnableDistance = true;
            }
        }

        voiceOut(bEnableTime, bEnableDistance);
    }

    /**
     * 获取由定位轨迹计算出的距离
     *
     * @return 由定位轨迹计算出的距离
     */
    private long getRunDistanceByGPS() {
        if (!isNeedLocateAndSaveTrail())
            return 0;
        if (mLastValidLocation != null) {
            return TrailManager.getInstance().getDistance();
        }
        return 0;
    }

    /**
     * 增加今日运动步数
     *
     * @param addedSteps 增加的步数
     */
    private void addTodayStepsValue(int addedSteps) {
        if (addedSteps <= 0) return;
        todaySteps += addedSteps;
        //每30步写一次
        if ((todaySteps / 30) != iTodayStepIndex) {
            iTodayStepIndex = todaySteps / 30;
            writeTodaySteps(todaySteps);
        }
    }

    /**
     * 保存今日步数
     *
     * @param steps 今天内到当前为止运动总步数
     */
    private void writeTodaySteps(int steps) {
        long lastWriteTime = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_TODAY_STEPS_TIME);
        if (!FitmixUtil.isToday(lastWriteTime)) {//新的一天,今日步数归零
            todaySteps = 0;
            getGSensorStepManager().resetAndroidStep();//新的一天,重置自带的计步器
            Logger.i(Logger.DEBUG_TAG, "writeTodaySteps-->is new day:" + System.currentTimeMillis());
            PrefsHelper.with(this, Config.PREFS_SPORT).writeInt(Config.SP_KEY_TODAY_STEPS, 0);
            PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_TODAY_STEPS_TIME, System.currentTimeMillis());
        } else {
            int lastStep = PrefsHelper.with(this, Config.PREFS_SPORT).readInt(Config.SP_KEY_TODAY_STEPS, 0);
            Logger.i(Logger.DEBUG_TAG, "writeTodaySteps-->is same day:" + System.currentTimeMillis() + " steps < lastStep:" + (steps < lastStep) + ",today step:" + steps);
            if (steps < lastStep) {//今日步数只能多不能少
                PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_TODAY_STEPS_TIME, System.currentTimeMillis());
            } else {
                PrefsHelper.with(this, Config.PREFS_SPORT).writeInt(Config.SP_KEY_TODAY_STEPS, steps);
                PrefsHelper.with(this, Config.PREFS_SPORT).writeLong(Config.SP_KEY_TODAY_STEPS_TIME, System.currentTimeMillis());
            }
        }
//        Logger.i(Logger.DEBUG_TAG, "writeTodaySteps end");
    }

    /**
     * 获取卡路里计算结果
     */
    private long calculateCalorie() {
        double result = FitmixUtil.calculateCalorie(getGender() == Config.GENDER_FEMALE,
                getAge(),
                getWeight(),
                getHeight(),
                getRunTime(),
                getAvgBpm(),
                getRunSteps());
        return (long) result;
    }

    /**
     * 添加或更新跑步记录到数据库
     *
     * @param runLogInfo 跑步运动信息
     * @param flag       运动完成标志,0:运动未完成,1:运动已完成
     */
    private void saveRunRecordToDb(RunLogInfo runLogInfo, int flag) {
        if (runLogInfo == null)
            return;

        SportRecord sportRecord = new SportRecord(null);
        sportRecord.setUid(runLogInfo.getUid());//用户Uid
        sportRecord.setStartTime(runLogInfo.getStartTime());//运动开始时间
        sportRecord.setFlag(flag);//运动完成标志
        sportRecord.setType(1);//跑步类型
        sportRecord.setMode(runLogInfo.getMode());//运动环境
        sportRecord.setLocationType(runLogInfo.getLocationType());//定位类型
        sportRecord.setDistance(runLogInfo.getDistance());//运动距离
        sportRecord.setRunTime(runLogInfo.getRunTime());//运动时长
        sportRecord.setStep(runLogInfo.getStep());//步数
        if (flag == 1) {//运动完成,计算总的平均BPM
            sportRecord.setUploaded(0);//记录未同步
        } else {
            sportRecord.setUploaded(2);//记录未完成
        }

        sportRecord.setBpm(runLogInfo.getBpm());//总的平均BPM
        sportRecord.setStartLng(runLogInfo.getStartLng());//开始点经度
        sportRecord.setStartLat(runLogInfo.getStartLat());//开始点纬度
        sportRecord.setEndLat(runLogInfo.getEndLat());//结束点纬度
        sportRecord.setEndLng(runLogInfo.getEndLng());//结束点经度
        sportRecord.setEndTime(runLogInfo.getEndTime());//运动结束时间
        sportRecord.setCalorie(runLogInfo.getCalorie());//运动卡路里
        sportRecord.setConsumeFat(runLogInfo.getConsumeFat());//运动脂肪消耗
        sportRecord.setBpmMatch(runLogInfo.getBpmMatch());//步数是否异常,-2表示异常
        sportRecord.setElevation(runLogInfo.getElevation());//累积爬升

        if (!TextUtils.isEmpty(runLogInfo.getHeartRateDate())) {
            sportRecord.setHeartRateDate(runLogInfo.getHeartRateDate());//心率相关数据
        }

        Logger.i(Logger.DEBUG_TAG, "RunService-->saveRunRecordToDb runLogInfo:" + runLogInfo);
        //bpmMatch,score,trail,stepData由服务器返回,在此不考虑
        SportRecordsHelper.insertOrReplaceSportRecord(this, sportRecord);

    }

    //endregion ================================== 跑步数据刷新相关 ==================================

    //region ================================== 地图定位轨迹相关 ==================================

    private AMapLocationManager locationManager;//定位管理
//    private AMapNavManager navManager;//导航管理,小米等手机在熄屏后会关闭gps,而开启导航则不会
    /**
     * 最近一次有效定位点
     */
    private AMapLocation mLastValidLocation;
    /**
     * 缓存的定位点,用于分析开始点
     */
    private List<AMapLocation> mLocations;
    /**
     * Gps点是否丢失
     */
    private boolean mGpsLoss = false;

    /**
     * gps点是否丢失
     */
    public boolean isGpsLoss() {
        return mGpsLoss;
    }

    /**
     * 唤醒GPS定位广播
     */
    private BroadcastReceiver mWakeGpsReceiver;

    /**
     * 唤醒GPS定位PendingIntent
     */
    private PendingIntent mPendingIntent;

    /**
     * 注册唤醒GPS定位的定时器
     */
    private void registerWakeGpsAlarm() {
        IntentFilter intentFilter = new IntentFilter("ALARM_WAKE_GPS_SERVICE");
        mWakeGpsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Logger.i(Logger.DEBUG_TAG, "RunService-->mWakeGpsReceiver onReceive!!!!");
                getLocationManager().activateLocate();
            }
        };
        registerReceiver(mWakeGpsReceiver, intentFilter);
        Intent intent = new Intent("ALARM_WAKE_GPS_SERVICE");
        mPendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), 60000L, mPendingIntent);
    }

    /**
     * 注销唤醒GPS定位的定时器
     */
    private void unregisterWakeGpsAlarm() {
        if (mWakeGpsReceiver != null) {
            unregisterReceiver(mWakeGpsReceiver);
        }
        mWakeGpsReceiver = null;

        if( mPendingIntent != null){
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.cancel(mPendingIntent);
        }
//        releaseCPULock();
    }

    /**
     * 定位回调监听事件
     */
    private final AMapLocationManager.OnAMapLocationChangeListener mLocationChangeListener = new AMapLocationManager.OnAMapLocationChangeListener() {

        @Override
        public void onLocationChange(AMapLocation aLocation) {
            if ((aLocation == null))
                return;
            Logger.i(Logger.DEBUG_TAG, "AMapLocationManager.OnAMapLocationChangeListener-->onLocationChange type:" + aLocation.getProvider());
            //1.得到起始点或开始过滤定位点
            if (!isLocationPointValid(aLocation)) {
                return;
            }

            //2.根据得到的定位点,组织成轨迹点信息
            int sportState = isRunning() ? TrailInfo.SPORT_STATE_SPORT
                    : TrailInfo.SPORT_STATE_PAUSE;
            int iLocateType = getLocationManager().getGPSLocateType();

            long now = System.currentTimeMillis();
            TrailInfo trailInfo = new TrailInfo(now, aLocation.getLatitude(), aLocation.getLongitude(), sportState);
            trailInfo.setUsed(true);
            trailInfo.setAltitude(aLocation.getAltitude());
            trailInfo.setBearing(aLocation.getBearing());
            trailInfo.setType(iLocateType);
            trailInfo.setSpeed(aLocation.getSpeed());

            //数据库
            TrailPoint trailPoint = new TrailPoint();
            trailPoint.setUid(UserDataManager.getUid());//用户uid
            trailPoint.setRunId(getRunStartTime());//运动记录编号
            trailPoint.setTime(now);//轨迹点写入时间
            trailPoint.setType(iLocateType);//定位类型
            trailPoint.setAccuracy(aLocation.getAccuracy());
            trailPoint.setSportState(sportState);//运动状态
            trailPoint.setLat(aLocation.getLatitude());//纬度
            trailPoint.setLng(aLocation.getLongitude());//经度
            trailPoint.setAltitude(aLocation.getAltitude());//海拔
            trailPoint.setSpeed(aLocation.getSpeed());//速度
            trailPoint.setBearing(aLocation.getBearing());//角度

            //3.保存轨迹点
            TrailManager.getInstance().addTrailInfoToArray(trailInfo);
            SportRecordsHelper.writeTrailPoint(RunService.this, trailPoint);

            //4.保存此刻的由传感器计算的运动距离,用于在下一次有效轨迹点到来时的这一段GPS距离空白期运动距离判断
            // 具体用法见{@link com.fitmix.sdk.controller.RunService.refreshRunLog}方法
            setSensorDistanceLastLocatePos(getRunDistanceByGSensor());

            //5.将运动记录的最终定位点的经纬度更新为当前有效定位点的经纬度
            setRunLogEndGeoPoint(aLocation.getLatitude(), aLocation.getLongitude());
        }
    };

    /**
     * 是否需要记录轨迹,同时只有需要记录轨迹时才开启定位
     *
     * @return true:需要记录轨迹,false:不需要记录轨迹
     */
    private boolean isNeedLocateAndSaveTrail() {
        //只在室外模式时,需要记录轨迹
        return getEnvironment() == RunLogInfo.SPORT_MODE_OUTDOOR;
    }

    /**
     * 获取缓存的定位点,用于分析开始点
     *
     * @return 缓存的定位点
     */
    private List<AMapLocation> getCachedLocations() {
        if (mLocations == null) {
            mLocations = new ArrayList<>(100);
        }
        return mLocations;
    }

    /**
     * 获取定位管理器
     */
    public AMapLocationManager getLocationManager() {
        if (locationManager == null) {
            locationManager = new AMapLocationManager();
//            final String trailDebugFileName = Config.PATH_DOWN_TRAIL + getRunStartTime() + "_debug" + ".json";
//            locationManager = new AMapLocationManager(trailDebugFileName);//debug
        }
        return locationManager;
    }

    /**
     * 根据是否需要定位,开启定位
     */
    private void startLocationIfNeed() {
        if (!isNeedLocateAndSaveTrail())
            return;
        //开启定位
        getLocationManager().setOnAMapLocationChangeListener(mLocationChangeListener);
        getLocationManager().startLocate();

        //开启导航模式
        registerWakeGpsAlarm();
    }

    /**
     * 停止定位
     */
    private void stopLocation() {
        if (!isNeedLocateAndSaveTrail())
            return;
        //停止定位
        getLocationManager().setOnAMapLocationChangeListener(null);
        getLocationManager().stopLocate();

    }

    /**
     * 设置运动记录定位起点信息
     *
     * @param locationType 定位类型
     * @param startLat     起点纬度
     * @param startLng     起点经度
     */
    private void setRunLogStartGeoPoint(int locationType, double startLat,
                                        double startLng) {
        getRunLogInfo().setStartLat(startLat);
        getRunLogInfo().setStartLng(startLng);
        getRunLogInfo().setLocationType(locationType);
    }

    /**
     * 设置运动记录定位终点信息
     *
     * @param endLat 终点纬度
     * @param endLng 终点经度
     */
    private void setRunLogEndGeoPoint(double endLat, double endLng) {
        getRunLogInfo().setEndLat(endLat);
        getRunLogInfo().setEndLng(endLng);
    }

    /**
     * 判断定位点是否有效 (用于处理定位漂移和获取起始点)
     *
     * @param location 要判断的定位点
     * @return true:有效,false:无效
     */
    private boolean isLocationPointValid(AMapLocation location) {
        //1.有定位点为0,0直接为无效点
        if (location.getLatitude() == 0 && location.getLongitude() == 0) {
            return false;
        }
        //2.之前没有确定过定位点,新来的点加入分析列表,用于分析得出起始点
        if (mLastValidLocation == null) {
            if (getCachedLocations().size() >= 100) {//注意内存
                getCachedLocations().clear();
            }
            getCachedLocations().add(location);
            mLastValidLocation = getValidStartPoint(getCachedLocations());
            if (mLastValidLocation != null) {//得到有效起始点
                //2.1 写入运动记录起始点信息
                int iLocateType = getLocationManager().getGPSLocateType(mLastValidLocation);
                setRunLogStartGeoPoint(iLocateType, mLastValidLocation.getLatitude(), mLastValidLocation.getLongitude());
                //2.2 清除用于分析得出起始点的缓存列表
                getCachedLocations().clear();
                Logger.i(Logger.DEBUG_TAG, String.format("得到定位起点,lat:%s,lng:%s", mLastValidLocation.getLatitude(),
                        mLastValidLocation.getLongitude()));
//                Toast.makeText(this, String.format("得到定位起点,lat:%s,lng:%s", mLastValidLocation.getLatitude(),
//                        mLastValidLocation.getLongitude()), Toast.LENGTH_LONG).show();
                return true;
            } else {
                return false;
            }
        } else {
            //3.如果当前点的时间戳比最近一次有效点的时间戳要小,说明当前的点经过多次折射才到手机,放弃(一般在定位状态不好时会出现)
            if (location.getTime() < mLastValidLocation.getTime()) {
                return false;
            }

            float currentAccuracy = location.getAccuracy();
//            if(currentAccuracy > Config.GPS_AVAILABLE_ACCURACY){
//                return false;
//            }
            float previousAccuracy = mLastValidLocation.getAccuracy();

            float accuracyDifference = Math.abs(previousAccuracy - currentAccuracy);
            //4.如果当前点精度比之前的点低,但是来源于相同则判断新来点的精度是否在可接受范围
            boolean lowerAccuracyAcceptable = currentAccuracy > previousAccuracy && mLastValidLocation.getProvider().equals(location.getProvider())
                    && (accuracyDifference <= previousAccuracy / 10);//ACCURACY_PERCENT 可接受定位精度偏差

            float velocity = getAverageVelocity(mLastValidLocation, location);
            //速度小于阀值并且
            //(当前点精度要高于上一点 或者 当前点是从上一点接收以后超过了10秒再进来的点
            // 或者是当前点虽然精度要低于上一点但在可接受范围)
            if (velocity <= 11//VELOCITY_THRESHOLD 临近两点速度限制11 m/s 即39.6km/h
                    && (currentAccuracy < previousAccuracy
                    || ((location.getTime() - mLastValidLocation.getTime()) > 5000)//TIME_THRESHOLD 5秒
                    || lowerAccuracyAcceptable)) {
                //计算累积爬升 不考虑
//                double climbHeight = location.getAltitude() - mLastValidLocation.getAltitude();
//                if (climbHeight > 0.1) {
//                    Logger.i(Logger.DEBUG_TAG, "climb height:" + climbHeight);
//                    getRunLogInfo().setElevation(getRunLogInfo().getElevation() + climbHeight);
//                }
                mLastValidLocation = location;
                return true;
            }
        }
        return false;
    }

    /**
     * 获取第一个有效定位点
     *
     * @param locations 用于判断的定位点集合
     * @return 认定的有效开始定位点
     */
    private AMapLocation getValidStartPoint(List<AMapLocation> locations) {
        //1.判断定位点集合是否有效
        if (locations == null) {
            return null;
        }
        //2.从集合点中获取有效起始点,规则如下:
        // 一、有效起始点前3个点的精度均可接受,比如精度小于或等于80米;
        // 二、有效起始点前3个点,每点间的速度可接受,比如平均速度小于30米/秒
        if (locations.size() < 4) {
            return null;
        }
        int size = locations.size();
        for (int i = (size - 1); (i - 3) >= 0; i--) {//判断最后4个点
            if (locations.get(i).getAccuracy() <= Config.GPS_AVAILABLE_ACCURACY) {//最后一点,精度达到要求
                if (locations.get(i - 1).getAccuracy() <= Config.GPS_AVAILABLE_ACCURACY) {//倒数第二个点,精度也达到要求
                    if (locations.get(i - 2).getAccuracy() <= Config.GPS_AVAILABLE_ACCURACY) {//倒数第三个点,精度也达到要求
                        if (locations.get(i - 3).getAccuracy() <= Config.GPS_AVAILABLE_ACCURACY) {//倒数第四个点,精度也达到要求
                            //判断速度
                            float velocity1 = getAverageVelocity(locations.get(i - 1), locations.get(i));//最后一点与倒数第二点速度
                            float velocity2 = getAverageVelocity(locations.get(i - 2), locations.get(i - 1));//倒数第二点与倒数第三点速度
                            float velocity3 = getAverageVelocity(locations.get(i - 3), locations.get(i - 2));//倒数第三点与倒数第四点速度
                            if (velocity1 <= 30 && velocity2 <= 30 && velocity3 <= 30) {
                                // 判断了第一个定位有效点时,把第一个有效定位点之前的传感器计步距离保存
                                setLastRunDistance(getLastRunDistance() + getRunDistanceByGSensor());
//                                Logger.i(Logger.DEBUG_TAG,"得到开始点,此刻G-sensor距离:"+getRunDistanceByGSensor());
                                return locations.get(i);
                            } else {
                                return null;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * 获取两个定位点间的平均速度
     *
     * @param startPoint 始点
     * @param endPoint   终点
     * @return 两定位点间的平均速度, 单位米/秒,默认返回0
     */
    private float getAverageVelocity(AMapLocation startPoint, AMapLocation endPoint) {
//        float[] distance = new float[1];
//        AMapLocation.distanceBetween(startPoint.getLatitude(),
//                startPoint.getLongitude(),
//                endPoint.getLatitude(),
//                endPoint.getLongitude(),
//                distance);
        double distance = TrailManager.getShortDistance(startPoint.getLongitude(), startPoint.getLatitude(),
                endPoint.getLongitude(),
                endPoint.getLatitude());
        long duration = Math.abs(endPoint.getTime() - startPoint.getTime()) / 1000;
        return (float) (distance / duration);//1.0f * distance[0] / duration;
    }

    //endregion ================================== 地图定位轨迹相关 ==================================

    //region ================================== 传感器计步相关 ==================================
    /**
     * 上次有效定位点时的gSensor计算出的运动距离
     */
    private long gSensorDistanceLastLocatePos;
    /**
     * 跑步过程中,运动传感器丢失数据的总时长,单位为毫秒.
     */
    private long mSensorMissDuration;
    /**
     * 最近一次传感器响应时间
     */
    private long mLastSensorTime;

    /**
     * sensor是否丢失响应
     */
    private boolean mSensorLoss = false;

    /**
     * 获取sensor是否丢失响应
     */
    public boolean isSensorLoss() {
        return mSensorLoss;
    }

    /**
     * @return 获取有效定位点时gSensor距离
     */
    private long getSensorDistanceLastLocatePos() {
        return gSensorDistanceLastLocatePos;
    }

    /**
     * @param value 设置有效定位点时gSensor距离
     */
    private void setSensorDistanceLastLocatePos(long value) {
        gSensorDistanceLastLocatePos = value;
    }

    /**
     * 获取由步数累计算出的运动距离
     *
     * @return 由步数累计算出的运动距离, 单位为米
     */
    private long getRunDistanceByGSensor() {
        return BpmManager.getInstance().getDistance();
    }

    /**
     * 获取跑步过程中,运动传感器丢失数据的总时长,单位为毫秒
     */
    public long getSensorMissDuration() {
        return mSensorMissDuration;
    }

    /**
     * 清除缓存的(用于分析平均步频)步数信息
     */
    private void clearRecentCachedSteps() {
        BpmManager.getInstance().clearSteps();
    }

    /**
     * 获取GSensor管理
     */
    public GSensorStepManager getGSensorStepManager() {
        return GSensorStepManager.getInstance();
    }

    private final GSensorStepManager.OnStepChangeListener mStepChangeListener = new GSensorStepManager.OnStepChangeListener() {
        @Override
        public void onStepChange() {
            //仅后台计步或运动暂停时不计步
            if (isDaemonStepMode())
                return;
            if ((!isRunning()))
                return;
            writeStepToDb();
        }
    };

    /**
     * 刷新跑步步数,并写入数据库表STEP_INFO
     */
    private void writeStepToDb() {
//        Logger.i(Logger.DEBUG_TAG,"writeStepToDb...");
        long now = System.currentTimeMillis();
        if (now - lastWriteStepTime >= 1000) {
            //新创建插入数据点
            StepInfo stepInfo = new StepInfo();
            stepInfo.setUid(UserDataManager.getUid());
            stepInfo.setRunId(getRunStartTime());
            stepInfo.setTime(now);//设置时间戳
            stepInfo.setSteps(getLastSteps() + getGSensorStepManager().getSteps());//设置步数
            stepInfo.setDistance(getRunDistance());//设置距离

            lastWriteStepTime = now;
            SportRecordsHelper.writeStepInfo(this, stepInfo);

            BpmManager.getInstance().addStepsToArray(getGender() == Config.GENDER_FEMALE,
                    getHeight(), stepInfo.getSteps(), now, getRunDistance());
        }
    }

    //region ########################## 后台计步相关 ##########################

    /**
     * 是否仅后台今日计步
     */
    private boolean mDaemonStepMode;
    /**
     * 后台计步步数是否显示在通知栏上
     */
    private boolean mDaemonStepNotify;

    /**
     * 获取是否仅后台今日计步
     *
     * @return true:仅后台今日计步,false:运动计步
     */
    public boolean isDaemonStepMode() {
        return mDaemonStepMode;
    }

    /**
     * 设置是否仅后台今日计步
     *
     * @param bOnlyStep true:仅后台今日计步,false:运动计步
     */
    private void setDaemonStepMode(boolean bOnlyStep) {
        mDaemonStepMode = bOnlyStep;
    }

    /**
     * 开始后台计步
     */
    public void startDaemonStepCount() {
        setDaemonStepMode(true);
        startGSensorManager();
//        startCPULock();
        ServiceAliveHelper.getInstance(this).startKeep();
        mDaemonStepNotify = SettingsHelper.getBoolean(Config.SETTING_SHOW_STEP_IN_NOTIFICATION, true);
        boolean showStepInLock = SettingsHelper.getBoolean(Config.SETTING_SHOW_STEP_IN_LOCK_SCREEN, false);
        if (mDaemonStepNotify) {
            sendNotification();
        }
        if (showStepInLock) {
            registerScreenEventReceiver();
        }
        getMyHandler().sendEmptyMessageDelayed(
                Config.MSG_REPEAT_EVERY_SECOND, 1000);
    }

    /**
     * 停止后台计步
     */
    public void stopDaemonStepCount() {
        writeTodaySteps(todaySteps);
        getMyHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        stopGSensorManager();
//        releaseCPULock();
        ServiceAliveHelper.getInstance(this).stopKeep();
        unRegisterScreenEventReceiver();
    }

    //endregion ######################## 后台计步相关 ##########################

    //region ######################## 跑步计步相关 ##########################

    /**
     * 开启gSensor计步功能
     */
    private void startGSensorManager() {
        getGSensorStepManager().resetStep();
        continueGSensorManager();
    }

    /**
     * gSensor计步
     */
    private void continueGSensorManager() {
        getGSensorStepManager().stopStep();
        getGSensorStepManager().setOnStepChangeListener(mStepChangeListener);
        int mode = PedometerBase.MODE_RUN_OUTDOOR;
        if (isDaemonStepMode()) {
            mode = PedometerBase.MODE_WALK;
        } else if (getEnvironment() == RunLogInfo.SPORT_MODE_INDOOR) {
            mode = PedometerBase.MODE_RUN_INDOOR;
        }
        getGSensorStepManager().setMode(mode);
        getGSensorStepManager().startStep();
//        Log.i("TT","continueGSensorManager");
    }

    /**
     * 停止gSensor计步功能
     */
    private void stopGSensorManager() {
        getGSensorStepManager().stopStep();
        getGSensorStepManager().setOnStepChangeListener(null);

    }

    //endregion ######################## 跑步计步相关 ##########################

    //endregion ======================== 传感器计步相关 ========================

    //region =================================== 语音播报相关 ===================================
    /**
     * 语音播报时间索引号
     */
    private int iVoiceTimeIndex;
    /**
     * 语音播报距离索引号
     */
    private int iVoiceDistanceIndex;
    /**
     * 是否语音暂停
     */
    private boolean bPausedVoiceByAudioOrPhone;
    /**
     * 语音管理器,负责语音播报
     */
    private VoiceManager voiceManager;

    /**
     * 获取VoiceManager
     */
    public VoiceManager getVoiceManager() {
        if (voiceManager == null)
            voiceManager = new VoiceManager();
        return voiceManager;
    }

    /**
     * 根据是否有语音播报来开启语音播报,并设置语调
     */
    private void startVoiceMessageIfNeed() {
        if (isSportWithVoice()) {//设置语调(男声或女声)
            getVoiceManager().setToneType(getToneType());
        }
    }

    /**
     * 语音播报:运动完成
     */
    private void playStopRunVoice(int sportT) {
        if (isSportWithVoice()) {
            //如果运动距离小于100米并且步数小于200,仅播报结束,否则播报成绩
            if ((getRunDistance() < 100) && (getRunSteps() < 200)) {
                getVoiceManager().playStopRun();
            } else {
                int runTime = (int) (getRunTime() / 1000);
                int uid = UserDataManager.getUid();
                SportRecord sportRecord = SportRecordsHelper.getLastRunRecord(this, uid);
                int type = 0;
                if (sportRecord != null) {
                    long lastDistance = sportRecord.getDistance();
                    type = getRunDistance() > lastDistance ? 1 : 0;
                }
                getVoiceManager().playRunScore(getToneType(), getRunDistance(), sportT, runTime,
                        (int) getRunCalorie(), type);
            }

        }
    }

    /**
     * 语音播报:暂停运动
     */
    private void pauseVoiceManager() {
        if (isSportWithVoice()) {
            getVoiceManager().playPauseRun();
        }
    }

    /**
     * 语音播报:继续运动
     */
    private void continueVoiceManager() {
        if (isSportWithVoice()) {
            getVoiceManager().playContinueRun();
        }
    }

    /**
     * 获取语音播报时间索引
     */
    private int getVoiceTimeIndex() {
        return iVoiceTimeIndex;
    }

    /**
     * 设置语音播报时间索引
     */
    public void setVoiceTimeIndex(int index) {
        this.iVoiceTimeIndex = index;
    }

    /**
     * 获取语音播报距离索引
     */
    private int getVoiceDistanceIndex() {
        return iVoiceDistanceIndex;
    }

    /**
     * 设置语音播报距离索引
     */
    public void setVoiceDistanceIndex(int index) {
        this.iVoiceDistanceIndex = index;
    }

    /**
     * 语音播报
     *
     * @param bTime     按时间播报
     * @param bDistance 按距离播报
     */
    private void voiceOut(boolean bTime, boolean bDistance) {
        if (!isRunning())
            return;
        if (getPausedVoiceByAudioOrPhone())
            return;
        if (!isSportWithVoice())
            return;

        int runTime = (int) (getRunTime() / 1000);
        if (bDistance && bTime) {
            getVoiceManager().playRunScore(getToneType(), getRunDistance(), runTime);

        } else if (bDistance) {
            long distance = getRunDistance();
            if ((distance % 1000) < 100) {
                getVoiceManager().playRunDataOfMarathon(distance, getRunTime());
            } else {
                getVoiceManager().playRunDistance(getToneType(), distance);
            }
        } else if (bTime) {
            getVoiceManager().playRunDuration(getToneType(), runTime);
        }
    }

    /**
     * 获取是否语音暂停
     */
    private boolean getPausedVoiceByAudioOrPhone() {
        return bPausedVoiceByAudioOrPhone;
    }

    /**
     * 设置是否语音暂停
     *
     * @param bValue true:语音播报暂停,false:语音播报继续
     */
    private void setPausedVoiceByAudioOrPhone(boolean bValue) {
        bPausedVoiceByAudioOrPhone = bValue;
    }

    /**
     * 暂停语音播报
     */
    public void pauseVoiceByAudioOrPhone() {
        if (!getVoiceManager().isMetronomeWorking())
            return;
        setPausedVoiceByAudioOrPhone(true);
        getVoiceManager().stopMetronome();
    }

    /**
     * 继续语音播报
     */
    public void resumeVoiceByAudioOrPhone() {
        if (!getPausedVoiceByAudioOrPhone())
            return;
        setPausedVoiceByAudioOrPhone(false);
        getVoiceManager().startMetronome();
    }

    /**
     * 根据用户选择的时间播报频率下标,获取相应的秒数
     *
     * @param iIndex 时间播报频率下标,见{@link com.fitmix.sdk.view.activity.SiriSettingActivity spinner_siri_time}
     * @return 时间播报的频率秒数
     */
    private int getSiriTimeByIndex(int iIndex) {
        int iTime = 0;
        switch (iIndex) {
            case 0://关闭
                iTime = 0;
                break;
            case 1://每1分钟播报
                iTime = 60;
                break;
            case 2://每5分钟播报
                iTime = 5 * 60;
                break;
            case 3://每10分钟播报
                iTime = 10 * 60;
                break;
            case 4://每15分钟播报
                iTime = 15 * 60;
                break;
        }
        return iTime;
    }

    /**
     * 根据用户选择的距离播报频率下标,获取相应的距离
     *
     * @param iIndex 距离播报频率下标,见{@link com.fitmix.sdk.view.activity.SiriSettingActivity spinner_siri_distance}
     * @return 距离播报的频率距离数, 单位为米
     */
    private int getSiriDistanceByIndex(int iIndex) {
        int iDistance = 0;
        switch (iIndex) {
            case 0://关闭
                iDistance = 0;
                break;
            case 1://每250米播报
                iDistance = 250;
                break;
            case 2://每500米播报
                iDistance = 500;
                break;
            case 3://每1000米播报
                iDistance = 1000;
                break;
            case 4://每5000米播报
                iDistance = 5000;
                break;
        }
        return iDistance;
    }

    //endregion =================================== 语音播报相关 ===================================

    //region ================================== 运动训练计划相关 ==================================
    /**
     * 运动目标值
     */
    private long taskValue;
    /**
     * 运动目标类型
     */
    private int taskType;
    /**
     * 目标是否完成
     */
    private boolean bTaskComplete;

    /**
     * 最近一次检测目标的时间
     */
    private long lastCheckTime;

    /**
     * 最近一次检测目标时的运动距离
     */
    public long lastCheckDistance;

    /**
     * 获取运动目标类型
     */
    private int getTaskType() {
        return taskType;
    }

    /**
     * 获取任务目标
     */
    private long getTaskValue() {
        return taskValue;
    }

    /**
     * 设置运动目标类型和值
     *
     * @param value 目标值
     * @param type  目标类型
     */
    public void setTaskTypeAndValue(long value, int type) {
        this.taskValue = value;
        this.taskType = type;
    }

    /**
     * 获取运动目标是否完成
     *
     * @return true:是,false:否
     */
    public boolean isTaskComplete() {
        return bTaskComplete;
    }

    /**
     * 设置运动目标是否完成
     *
     * @param bValue true:是,false:否
     */
    private void setTaskComplete(boolean bValue) {
        this.bTaskComplete = bValue;
    }

    /**
     * 检查目标任务完成情况
     */
    private void checkTaskObject(long now) {
        boolean bFinish = false;
        switch (getTaskType()) {
            case RunSettingBaseFragment.TASK_TYPE_DISTANCE://运动距离
                if (getRunDistance() >= getTaskValue()) bFinish = true;
                break;
            case RunSettingBaseFragment.TASK_TYPE_TIME://运动时长
                if (getRunTime() >= getTaskValue()) bFinish = true;
                break;
            case RunSettingBaseFragment.TASK_TYPE_CALORIE://运动卡路里
                if (getRunCalorie() >= getTaskValue()) bFinish = true;
                break;
            case RunSettingBaseFragment.TASK_TYPE_PACE://配速跑
                if (getPausedVoiceByAudioOrPhone()) {//语音暂停时,不播报
                    break;
                }
                long distance = getRunDistance();
                if (lastCheckTime == 0) {
                    lastCheckTime = getStartRunTime();
                }
                //配速跑语音播报配速间隔
                int paceRunVoiceIntervalType = SettingsHelper.getInt(Config.SETTING_PACE_RUN_VOICE_INTERVAL, 1);
                if (0 == paceRunVoiceIntervalType) {
                    break;
                } else {
                    long internal_time = 30000;
                    switch (paceRunVoiceIntervalType) {
                        case 1:
                            internal_time = 30000;
                            break;
                        case 2:
                            internal_time = 60000;
                            break;
                        case 3:
                            internal_time = 120000;
                            break;
                        case 4:
                            internal_time = 300000;
                            break;
                        case 5:
                            internal_time = 600000;
                            break;
                    }

                    if (getPeriodRunTime() > 45000 && now - lastCheckTime > internal_time) {//每节运动开始45秒后每30秒检测一次
                        double speed = (distance - lastCheckDistance) * 1000.0f / (now - lastCheckTime);
                        if (speed > 0.83) {//20'00"
                            int time = (int) (1000 / speed);//当前的速度完成一公里所需要的秒数
                            long deviation = (long) (getTaskValue() * 0.2);
                            long fit = deviation >> 1;
                            if (getTaskValue() - time >= deviation) {
                                getVoiceManager().playSpeedTooFast(time);
                            } else if (time - getTaskValue() >= deviation) {
                                getVoiceManager().playSpeedTooSlow(time);
                            } else if (Math.abs(time - getTaskValue()) <= fit) {
                                getVoiceManager().playSpeedFit();
                            }
                            Logger.d(Logger.DEBUG_TAG, "checkTaskObject-->speed:" + speed + " taskValue:" + getTaskValue());
                        }

                        lastCheckDistance = distance;
                        lastCheckTime = now;
                    }
                }

                break;

        }
        if (bFinish && (!isTaskComplete())) {
            setTaskComplete(true);
            getVoiceManager().playTaskComplete();
        }
    }

    //endregion ================================== 运动训练计划相关 ==================================

    //region ================================== 心率统计相关 ==================================
    /**
     * 五个区间，是否已经在每个区间经历了一分钟
     */
    private boolean[] heartRateLevelEntered;

    /**
     * 脂肪燃烧克数
     */
    private float fatBurn;

    /**
     * 用户的最大心率上限，存储在SharePreference
     */
    private int maxHeartRate;

    private float lastCalorie;

    /**
     * 最近一次的静息心率 用于计算当前所属心率区间，从卡路里计算脂肪（不同区间所占百分比不同）
     */
    private int latestRestHeartRate;

    /**
     * 上一次的心率值，如果还没收到则读上一次的
     */
    private int latestHeartRate;

    private UserHeartRateFinish userHeartRateFinish;

    public UserHeartRateFinish getUserHeartRateFinish() {
        return userHeartRateFinish;
    }

    /**
     * 设置运动结束保存心率数据回调
     */
    public void setUserHeartRateFinish(UserHeartRateFinish userHeartRateFinish) {
        this.userHeartRateFinish = userHeartRateFinish;
    }

    /**
     * 设置最近一次的静息心率
     */
    public void setLatestRestHeartRate(int latestRestHeartRate) {
        this.latestRestHeartRate = latestRestHeartRate;
    }

    /**
     * 获取指示在某个区间持续运动时长是否大于等于一分钟的数组(index 0:运动热身区间,index 1:燃脂区间,index 2:有氧区间,index 3:无氧区间,index 4:最大心率区间)
     */
    private boolean[] getHeartRateLevelEntered() {//TODO 很多次情况都变成null了
        if (heartRateLevelEntered == null) {
            heartRateLevelEntered = new boolean[7];
        }
        return heartRateLevelEntered;
    }

    /**
     * 设置五个区间中,在某个区间持续运动时长是否大于等于一分钟
     *
     * @param position 0:运动热身区间,1:燃脂区间,2:有氧区间,3:无氧区间,4:最大心率区间
     * @param ifEnter  true:是,false:否
     */
    private void setHeartRateLevelEntered(int position, boolean ifEnter) {
        boolean[] haveEnteredArray = getHeartRateLevelEntered();
        haveEnteredArray[position] = ifEnter;
    }

    /**
     * 获取脂肪燃烧克数
     */
    public float getFatBurn() {
        return fatBurn;
    }

    /**
     * UI界面上更新心率数值
     *
     * @return
     */
    public int getLatestHeartRate() {
        return latestHeartRate;
    }

    /**
     * 设置最新的心率数据
     */
    public void setLatestHeartRate(int value) {
//        Logger.e(Logger.DEBUG_TAG, "RunService-->setLatestHeartRate:" + value);
        latestHeartRate = value;
    }

    public interface UserHeartRateFinish {
        /**
         * 运动完成后设置心率接口相关的参数，存储在UserLog中
         */
        void doUserHeartRateFinish();

        /**
         * 获取用于的心率统计数据
         *
         * @return
         */
        UserHeartRate getUserHeartRate();
    }

    /**
     * 清空心率相关数据
     */
    private void clearHeartRateData() {
        userHeartRateFinish = null;
        latestHeartRate = 0;
        fatBurn = 0f;
        latestRestHeartRate = 0;
        lastCalorie = 0;

        heartRateLevelEntered = null;
        maxHeartRate = 0;
    }

    /**
     * 根据所属心率区间及在区间的持续时长，播放语音
     *
     * @param isNotFirstInHotMode                 = false;//不是第一次进入热身区间  默认 false
     * @param isNotFirstInFatMode                 = false;//不是第一次进入燃脂区间  默认 false
     * @param isNotFirstInHeartLungMode           = false;//不是第一次进入强化心肺区间  默认 false
     * @param isNotFirstInBodyMode                = false;//不是第一次进入强化机能区间  默认 false
     * @param isNotFirstInSuperMode               = false;//不是第一次进入极限强度区间  默认 false
     * @param lowZoneTime;//心率值低于区间下限时间，每次进来，从0计
     * @param inZoneTime;//心率值位于区间范围时间，每次进来，从0计
     * @param upZoneTime;//心率值高于于区间上限时间，每次进来，从0计
     * @param superZoneTime;//心率值高于极限值时间，每次进来，从0计
     * @param inCoachModeAllTime;//在教练模式区间内的持续总时间
     */
    public void playHRMessageVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                                   int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                                   boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {

        getVoiceManager().playHeartRateLevelMessage(latestHeartRate, restHeartRate, inCoachModeAllTime, lowZoneTime, inZoneTime, upZoneTime, superZoneTime,
                isNotFirstInHotMode, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode);

    }

    /**
     * 播放脂肪燃烧克数的语音
     *
     * @param gram 脂肪燃烧克数
     */
    public void playFatBurnMessageVoice(float gram) {
        if (gram <= 0)
            return;
        getVoiceManager().playFatBurn(gram);
    }

    /**
     * 播放最大摄氧量语音
     *
     * @param maxVo2 最大摄氧量,单位ml/kg/min
     */
    public void playMaxVo2MessageVoice(float maxVo2) {
        float avgVoMax = FitmixUtil.getAvgVoMax(getGender(), getAge());
        getVoiceManager().playMaxVo2(maxVo2, avgVoMax);

    }

    /**
     * 播放连接后的声音
     */
    public void playLAVAConnectedVoice() {
        getVoiceManager().playLAVAVoice();
    }

    //endregion ================================== 心率统计相关 ==================================
}
