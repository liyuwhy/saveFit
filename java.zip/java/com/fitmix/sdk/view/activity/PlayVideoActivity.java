package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.cache.HttpProxyCacheServer;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.bean.Video;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.FullScreenVideoView;
import com.fitmix.sdk.view.widget.VerticalSeekBar;

/**
 * 运动视频界面
 */
public class PlayVideoActivity extends BaseActivity {
    private FullScreenVideoView videoView;
    private LinearLayout bottomLayout;
    private LinearLayout headerLayout;
    private LinearLayout rightLayout;
    private SeekBar seekBar;
    private VerticalSeekBar volume_seekbar;
    private ImageView video_play_state;
    private TextView videoTitle;
    private TextView currentPosition;
    private TextView totalSize;
    private RelativeLayout error_layout;
    private RelativeLayout progress_layout;
    private static int progressValue = 0;
    private static int videoLength;
    private String uriAddress;
    private Video video;
    private int index;
    private boolean bCanShow = true;
    private boolean bControlHide = true;
//    private ArrayList<Video> videoList;

    private AudioManager mAudioManager;
    /**
     * 最大声音
     */
    private int mMaxVolume;
    /**
     * 当前声音
     */
    private int mVolume = -1;
    private GestureDetector mGestureDetector;
    private MyGestureListener myGestureListener;
    private SeekBar.OnSeekBarChangeListener videoProgressListener;
    private SeekBar.OnSeekBarChangeListener volumeProgressListener;
    private MediaPlayer.OnErrorListener videoErrorListener;
    private MediaPlayer.OnCompletionListener videoCompleteListener;
    private MediaPlayer.OnPreparedListener videoPreParedListener;
    private MediaPlayer.OnInfoListener videoInfoListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        full(false);
        setContentView(R.layout.activity_play_video);
        setPageName("PlayVideoActivity");
//        videoList = getIntent().getParcelableArrayListExtra("videoList");
//        index = getIntent().getIntExtra("currentIndex", -1);
//        if (videoList != null)
//            video = videoList.get(index);
        String videoString = getIntent().getStringExtra("videoString");
        if (!TextUtils.isEmpty(videoString))
            video = JsonHelper.getObject(videoString, Video.class);
        initViews();
        initPlayer();
        initData();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onStart ()");
    }

    protected void initViews() {
        //视频播放
        videoView = (FullScreenVideoView) findViewById(R.id.competition_video_view);
        //底部控制
        bottomLayout = (LinearLayout) findViewById(R.id.bottom_view);
        //顶部控制
        headerLayout = (LinearLayout) findViewById(R.id.header_view);
        //右步控制
        rightLayout = (LinearLayout) findViewById(R.id.right_view);
        //错误提示
        error_layout = (RelativeLayout) findViewById(R.id.error_layout);
        progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);

        videoTitle = (TextView) findViewById(R.id.tv_video_title);
        currentPosition = (TextView) findViewById(R.id.tv_current_position);
        totalSize = (TextView) findViewById(R.id.tv_total_time);
        //进度条
        seekBar = (SeekBar) findViewById(R.id.videoview_seekbar);
        volume_seekbar = (VerticalSeekBar) findViewById(R.id.volume_seekbar);

        video_play_state = (ImageView) findViewById(R.id.video_play_state);

        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mMaxVolume = mAudioManager
                .getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        volume_seekbar.setMax(mMaxVolume);
        //视频进度
        videoProgressListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                videoView.removeCallbacks(hideLayoutTask);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                progressValue = seekBar.getProgress();
                videoView.seekTo(progressValue);
                videoView.start();
                updateVideoProgress();
                hideVideoControler();
            }
        };
        seekBar.setOnSeekBarChangeListener(videoProgressListener);
        //声音大小
        volumeProgressListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
//                showRightLayout();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
        volume_seekbar.setOnSeekBarChangeListener(volumeProgressListener);
    }

    private void initData() {
        setUriAddress(video.getVideoUrl());
        setTitle(video.getTitle());
        playVideo();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();

        switch (requestId) {
            case Config.MODULE_USER + 60://完成每日分享运动视频金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, System.currentTimeMillis());//设置完成任务时间

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        //不处理
    }

    private void setTitle(String title) {
        videoTitle.setText(title);
    }

    /**
     * 动态设置状态栏是否显示
     *
     * @param enable 1、true 显示  2、false 不显示
     */
    private void full(boolean enable) {
        if (!enable) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            getWindow().setAttributes(lp);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        } else {
            WindowManager.LayoutParams attr = getWindow().getAttributes();
            attr.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().setAttributes(attr);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
    }

    /**
     * 隐藏控制video任务
     */
    private void hideVideoControler() {
        videoView.removeCallbacks(hideLayoutTask);
        videoView.postDelayed(hideLayoutTask, 3000);
    }

    /**
     * 隐藏开启声音任务
     */
    private void hideVolumeControler() {
        videoView.removeCallbacks(hideRightLayoutTask);
        videoView.postDelayed(hideRightLayoutTask, 3000);
    }

    /**
     * 进度条更新开启任务
     */
    private void updateVideoProgress() {
        seekBar.removeCallbacks(mUpdateProgress);
        seekBar.post(mUpdateProgress);
    }

    /**
     * 隐藏布局
     */
    public Runnable hideRightLayoutTask = new Runnable() {
        @Override
        public void run() {
            hideRightLayout();
        }
    };

    /**
     * 隐藏布局
     */
    public Runnable hideLayoutTask = new Runnable() {
        @Override
        public void run() {
            hideLayout();
        }
    };

    /**
     * 进度条更新
     */
    public Runnable mUpdateProgress = new Runnable() {
        @Override
        public void run() {
            if (videoView.isPlaying()) {
                seekBar.postDelayed(mUpdateProgress, 1000);
            }
            int progressValue = videoView.getCurrentPosition();
            seekBar.setProgress(progressValue);
            if (seekBar != null) {
                seekBar.setSecondaryProgress((int) (videoLength * (videoView.getBufferPercentage() / 100.0f)));
            }
            currentPosition.setText(FormatUtil.formatMusicTime(progressValue / 1000));
            totalSize.setText(FormatUtil.formatMusicTime(videoLength / 1000));
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (getmGestureDetector().onTouchEvent(event))
            return true;
        // 处理手势结束
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP:
                endGesture();
                break;
        }
        return super.onTouchEvent(event);
    }

    private GestureDetector getmGestureDetector() {
        if (mGestureDetector == null) {
            myGestureListener = new MyGestureListener();
            mGestureDetector = new GestureDetector(this, myGestureListener);
        }
        return mGestureDetector;
    }

    /**
     * 手势结束
     */
    private void endGesture() {
        mVolume = -1;
    }

    private class MyGestureListener extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            if (bCanShow && bControlHide) {
                showVideoControlerLayout();
            } else if (!bControlHide) {
                hideLayout();
            }
            return super.onSingleTapUp(e);
        }

//        @Override
//        public boolean onDoubleTap(MotionEvent e) {
//            if (bCanShow)
//                showVideoControlerLayout();
//            return true;
//        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                float distanceX, float distanceY) {
            float mOldX = e1.getX(), mOldY = e1.getY();
            int y = (int) e2.getRawY();
            Display disp = getWindowManager().getDefaultDisplay();
            Point size = new Point();
            disp.getSize(size);
            int width = size.x;
            int height = size.y;

            if (mOldX > width * 4.0 / 5)// 右边滑动
                onVolumeSlide((mOldY - y) / height);

            return super.onScroll(e1, e2, distanceX, distanceY);
        }
    }

    /**
     * 滑动改变声音大小
     *
     * @param percent
     */
    private void onVolumeSlide(float percent) {
        if (mVolume == -1) {
            mVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if (mVolume < 0)
                mVolume = 0;
        }
        volume_seekbar.setProgress(mVolume);
        showRightLayout();
        int index = (int) (percent * mMaxVolume) + mVolume;
        if (index > mMaxVolume)
            index = mMaxVolume;
        else if (index < 0)
            index = 0;
        // 变更进度条 进而变更声音
        volume_seekbar.setProgress(index);

    }


    /**
     * 初始化mediaplayer
     */
    private void initPlayer() {
        videoErrorListener = new MediaPlayer.OnErrorListener() {
            /**
             * 视频播放发生错误
             */
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                cancleProgressBar();
                showVideoControlerLayout();
                Logger.e(Logger.DEBUG_TAG, "onError mp current position:" + mp.getCurrentPosition() + ",duration:" + mp.getDuration());
                showAppMessage("视频播放错误~", AppMsg.STYLE_ALERT);
                return true;
            }
        };
        videoCompleteListener = new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Logger.i(Logger.DEBUG_TAG, "onCompletion mp current position:" + mp.getCurrentPosition() + ",duration:" + mp.getDuration());
                stop();
            }
        };
        videoPreParedListener = new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                full(true);
                cancleProgressBar();
                videoView.start();
                videoLength = videoView.getDuration();
                seekBar.setMax(videoLength);
                seekBar.setProgress(progressValue);
                updateVideoProgress();
//                mp.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
//                    @Override
//                    public void onBufferingUpdate(MediaPlayer mp, int percent) {
//                        if (seekBar != null) {
//                            seekBar.setSecondaryProgress((int) (videoLength * (percent / 100.0f)));
//                        }
//                        Logger.i(Logger.DEBUG_TAG,"videoLength:"+ videoLength +",onBufferingUpdate percent:"+ percent);
//                    }
//                });
            }
        };

        videoView.setOnErrorListener(videoErrorListener);
        videoView.setOnPreparedListener(videoPreParedListener);
        videoView.setOnCompletionListener(videoCompleteListener);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            videoInfoListener = new MediaPlayer.OnInfoListener() {
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    Logger.i(Logger.DEBUG_TAG, "onInfo what:" + what + ",extra:" + extra);
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                        showProgressBar();
                    } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {  //此接口每次回调完START就回调END,若不加上判断就会出现缓冲图标一闪一闪的卡顿现象
                        if (mp.isPlaying()) {
                            cancleProgressBar();
                        }
                    }
                    return true;
                }
            };
            videoView.setOnInfoListener(videoInfoListener);
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.video_play_state:
                showVideoControlerLayout();
                if (videoView.isPlaying()) {
                    pause();
                    video_play_state.setImageResource(R.drawable.play);
                } else {
                    if (progressValue > 0) {
                        Logger.i(Logger.DEBUG_TAG, "playVideoActivity --- > doClick : progressValue :" + progressValue);
                        videoView.start();
                        updateVideoProgress();
                    } else {
                        playVideo();
                    }
                    video_play_state.setImageResource(R.drawable.stop);
                }
                break;
            case R.id.iv_play_next:
//                video = videoList.get((index + 1) % videoList.size());
//                index++;
//                initData();
                break;
            case R.id.iv_back:
                finish();
                break;
            case R.id.iv_share_video:
                shareVideo();
                break;
        }
    }

    public void shareVideo() {
        if (video != null)
            ShareUtils.getInstance().shareVideo(this, video);
    }

    /**
     * 显示声音控制布局
     */
    private void showRightLayout() {
        rightLayout.setVisibility(View.VISIBLE);
        hideVolumeControler();
    }

    /**
     * 隐藏布局
     */
    private void hideRightLayout() {
        rightLayout.setVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        resume();
        super.onResume();
    }

    @Override
    protected void onPause() {
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onPause ()");
        pause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onStop ()");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            videoView.setOnInfoListener(null);
        }
        myGestureListener = null;
        mGestureDetector = null;

        if (volume_seekbar != null) {
            volume_seekbar.setOnSeekBarChangeListener(null);
        }

        if (seekBar != null) {
            seekBar.setOnSeekBarChangeListener(null);
            seekBar.removeCallbacks(mUpdateProgress);
        }
        if (videoView != null) {
            progressValue = 0;
            videoView.setOnCompletionListener(null);
            videoView.setOnPreparedListener(null);
            videoView.setOnErrorListener(null);
            videoView.removeCallbacks(hideLayoutTask);
            videoView.removeCallbacks(hideRightLayoutTask);
            videoView.stopPlayback();
            ((ViewGroup) videoView.getParent()).removeView(videoView);
            videoView = null;
        }
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onDestroy ()");
        super.onDestroy();
    }

    /**
     * 显示布局
     */
    private void showVideoControlerLayout() {
        bControlHide = false;
        full(true);
        error_layout.setVisibility(View.VISIBLE);
        bottomLayout.setVisibility(View.VISIBLE);
        headerLayout.setVisibility(View.VISIBLE);
//        if (!videoView.isPlaying()) {
//            return;
//        }
        if (videoView.isPlaying()) {
            showPause();
        } else {
            showPLay();
        }
//        hideVideoControler();
    }

    /**
     * 隐藏布局
     */
    private void hideLayout() {
        full(false);
        error_layout.setVisibility(View.GONE);
        bottomLayout.setVisibility(View.GONE);
        headerLayout.setVisibility(View.GONE);
        bControlHide = true;
    }

    /**
     * 显示播放按钮的布局
     */
    private void showPLay() {
        video_play_state.setImageResource(R.drawable.play);

    }

    /**
     * 显示暂停按钮的布局
     */
    private void showPause() {
        video_play_state.setImageResource(R.drawable.stop);
    }

    /**
     * 暂停播放
     */
    private void pause() {
        progressValue = videoView.getCurrentPosition();
        videoView.pause();
        Logger.i(Logger.DEBUG_TAG, "playVideoActivity --- > pause : progressValue :" + progressValue);
    }

    /**
     * 暂停播放
     */
    private void resume() {
        if (progressValue > 0) {
            videoView.seekTo(progressValue);
            videoView.setOnPreparedListener(videoPreParedListener);
            videoView.start();
        }

    }

    /**
     * 停止播放
     */
    private void stop() {
        progressValue = 0;
        videoView.pause();
        showVideoControlerLayout();
    }

    /**
     * 播放视频
     */
    public void playVideo() {
        if (TextUtils.isEmpty(uriAddress)) {
            return;
        }
//        uriAddress = "http://10.10.8.219/1c6f9fa047e64e1690c6ca8b152494dc.mp4";
//        uriAddress = "http://10.10.8.219/3c4bf10f8b344c268fb6a4136dead293.mp4";
//        Map<String,String> headers = new HashMap<>(2);
//        headers.put("User-Agent","stagefright/1.2 (Linux;Android 5.1.1)");
//        headers.put("Content-Type","video/mp4");
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            videoView.setVideoURI(Uri.parse(uriAddress), headers);
//            Logger.i(Logger.DEBUG_TAG, "playVideo uriAddress0:" + uriAddress+",Uri.parse(uriAddress).getPath():"+Uri.parse(uriAddress).getPath());
//        }else{
        HttpProxyCacheServer proxy = MixApp.getProxy(getApplicationContext());
        if (proxy != null) {
            String proxyUrl = proxy.getProxyUrl(uriAddress);
            if (!TextUtils.isEmpty(proxyUrl)) {
                videoView.setVideoURI(Uri.parse(proxyUrl));
            }
            Logger.i(Logger.DEBUG_TAG, "playVideo uriAddress1:" + uriAddress + ",Uri.parse(uriAddress).getPath():" + Uri.parse(uriAddress).getPath());
//        }
        }

        showProgressBar();
        videoView.start();
        videoView.requestFocus();

    }


//    /**
//     * @return 返回视频地址
//     */
//    public String getUriAddress() {
//        return uriAddress;
//    }

    /**
     * 设置视频地址
     *
     * @param uriAddress 视频地址
     */
    public void setUriAddress(String uriAddress) {
        this.uriAddress = uriAddress;
    }

    /**
     * 取消加载图层
     */
    private void cancleProgressBar() {
        bCanShow = true;
        progress_layout.setVisibility(View.GONE);
        videoView.setEnabled(true);
    }

    /**
     * 显示加载图层
     */
    private void showProgressBar() {
        bCanShow = false;
        hideLayout();
        progress_layout.setVisibility(View.VISIBLE);
        videoView.setEnabled(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            default:
                if (resultCode == Activity.RESULT_OK) {//三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareVideoCoinTask();
                            }
                            break;
                    }
                }
                break;
        }
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动视频金币任务
     */
    private void finishShareVideoCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareVideoCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================
}
