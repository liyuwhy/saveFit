package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.DeviceLocalUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.zxing.CodeUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.fragment.CaptureFragment;
import com.fitmix.sdk.view.fragment.WatchBindFailFragment;
import com.fitmix.sdk.watch.bean.WatchInfo;

/**
 * 手表查找界面
 */

public class WatchSearchActivity extends BaseWatchActivity implements CodeUtils.AnalyzeCallback {

    private CaptureFragment captureFragment;
    private WatchBindFailFragment watchBindFailFragment;

    private String watchMacAddress;//手表MAC地址

    private View layout_bind;
    private TextView tv_bind_status;

    private boolean mIsFound = false;//是否已经找到了手表
    private BluetoothDevice mWatch;//蓝牙搜索找到的手表

    private MenuItem menuContinue;//没有找到手表时,显示继续菜单,适配部分机子BLE搜索不到手表问题
    private boolean sendBindCmd;//是否需要向手表发送绑定指令,具体在WatchActivity执行
    private WatchInfo watchInfo;//扫描手表二维码得到的手表信息
    private Button reSearchBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_search);
        setPageName("WatchSearchActivity");
        initToolbar();
        initViews();
        if (getIntent() != null) {
            sendBindCmd = getIntent().getBooleanExtra("sendBindCmd", false);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {

            String info = SettingsHelper.getString(Config.SETTING_WATCH_INFO, "");
            watchInfo = JsonHelper.getObject(info, WatchInfo.class);
            if (watchInfo != null) {
                watchMacAddress = watchInfo.getMac();
            }
            //1.打开蓝牙
            openBluetooth(new OpenBluetoothResult() {
                @Override
                public void openSuccess() {
                    //不处理
                }

                @Override
                public void openFail() {//打开失败
                    delayFinishActivity();
                }
            });

            //绑定手表服务
            bindWatchService();
        } else {//不支持BLE,退出
            Toast.makeText(this, R.string.heart_rate_warn_sdk_version, Toast.LENGTH_SHORT).show();
            finish();
        }
        initWatchQRCodeScanFragment();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mBluetoothReady) {
            //判断有没有绑定手表
            hasBindWatch();
        }
        if (reSearchBtn != null){
            reSearchBtn.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onPause() {
        // 调换了顺序 -- 否则 会先退出回调到显示继续字的方法
        mIsFound = true;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindWatchService();
        stopScan();
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        layout_bind = findViewById(R.id.layout_bind);
        tv_bind_status = (TextView) findViewById(R.id.tv_bind_status);
        reSearchBtn = (Button) findViewById(R.id.btn_search_retry);
        reSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchWatch();//搜索手表
            }
        });
    }


    /**
     * 判断有没有绑定手表
     */
    private void hasBindWatch() {
        if (TextUtils.isEmpty(watchMacAddress)) {//没有绑定
            showWatchQRCodeScanFragment();//二维码扫描绑定流程
        } else {
            searchWatch();//搜索手表
            if (layout_bind != null) {
                layout_bind.setVisibility(View.VISIBLE);
                if (reSearchBtn != null){
                    reSearchBtn.setVisibility(View.GONE);
                }
            }
        }
    }

    /**
     * 搜索手表
     */
    private void searchWatch() {
        if (watchMacAddress != null) {//开启搜索
            stopScan();
            mIsFound = false;
            if (tv_bind_status != null) {
                tv_bind_status.setText(R.string.activity_watch_search_searching);
            }

            BluetoothDevice device = DeviceLocalUtil.checkLocalDevice(watchMacAddress);
            if(device != null){
                Logger.d(Logger.DEBUG_TAG, "WatchSearchActivity Device in local ------");
                onSearchWatchSuccess(device);
                return;
            }

            Logger.d(Logger.DEBUG_TAG,"WatchSearchActivity isSearching------");
            searchWatch(watchMacAddress, 24000);
        } else {
            bindWatchFail(0);
        }
    }


    /**
     * 初始化手表二维码扫描界面
     */
    private void initWatchQRCodeScanFragment() {
        captureFragment = new CaptureFragment();
        captureFragment.setAnalyzeCallback(this);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.mainContainer, captureFragment)
                .hide(captureFragment)
                .commit();
    }

    /**
     * 显示手表二维码扫描界面
     */
    private void showWatchQRCodeScanFragment() {
        //1. Android 6.0 检测有没有相机权限
        getPermission(Manifest.permission.CAMERA);
        if (captureFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .show(captureFragment)
                    .commitAllowingStateLoss();
        }
        sendBindCmd = true;
    }

    /**
     * 手表绑定成功
     */
    private void bindWatchSuccess() {
        if (tv_bind_status != null) {
            tv_bind_status.setText(R.string.activity_watch_search_bind_success);
        }
        if (layout_bind != null) {
            layout_bind.setVisibility(View.VISIBLE);
            if (reSearchBtn != null){
                reSearchBtn.setVisibility(View.GONE);
            }
        }
        if (mIsFound){
            reSearchBtn.setVisibility(View.GONE);
            mIsFound = false;
            ThreadManager.getMainHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Logger.d(Logger.DEBUG_TAG,"WatchSearchActivity ----> bindWatchSuccess");
                    gotoWatchActivity();
                }
            }, 500);//0.5秒进入手表主页
        }
    }


    /**
     * 手表绑定失败
     *
     * @param failReason 手表绑定失败原因, 0:二维码识别问题,1:找不到手表或手机网络故障 ,2:手表已经与其它账号绑定了
     */
    private void bindWatchFail(int failReason) {
        Logger.i(Logger.DEBUG_TAG, "bindWatchFail  failReason:" + failReason);
        if (layout_bind != null) {
            layout_bind.setVisibility(View.GONE);
        }

        watchBindFailFragment = new WatchBindFailFragment();
        watchBindFailFragment.setFailReason(failReason);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.mainContainer, watchBindFailFragment, WatchBindFailFragment.TAG)
                .addToBackStack(null)
                .commit();
    }

    /**
     * 导航至手表主界面
     */
    private void gotoWatchActivity() {
        Intent intent = new Intent(WatchSearchActivity.this, WatchActivity.class);
        if (watchMacAddress != null) {//蓝牙搜索需要大写字母
            watchMacAddress = watchMacAddress.toUpperCase();
        }
        intent.putExtra("macAddress", watchMacAddress);
        intent.putExtra("watch", mWatch);
        intent.putExtra("sendBindCmd", sendBindCmd);
        startActivity(intent);
        finish();
    }


    /**
     * 1秒后销毁Activity
     */
    private void delayFinishActivity() {
        ThreadManager.getMainHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 1000);//1秒
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null)
            return;

        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);

        switch (requestId) {
            case Config.MODULE_USER + 48://上传设备信息给后台
                BaseBean baseBean = JsonHelper.getObject(result, BaseBean.class);
                if (baseBean != null) {
                    if (baseBean.getCode() == 0) {//绑定成功
                        sendBindCmd = true;
                        if (watchInfo != null) {
                            String info = JsonHelper.createJsonString(watchInfo);
                            SettingsHelper.putString(Config.SETTING_WATCH_INFO, info);//保存手表信息

                            watchMacAddress = watchInfo.getMac();//
                        }
                        searchWatch();//搜索手表
                    } else {//处理后台发回的绑定结果
                        bindWatchFail(2);
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 48://上传设备信息给后台
                    if (bean.getCode() == 3020) {//设备已存在
                        bindWatchFail(2);
                    } else {
                        bindWatchFail(1);
                    }
                    break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menuContinue = menu.add(0, Menu.FIRST + 6, 6, R.string.activity_watch_search_continue);
        menuContinue.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menuContinue.setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;

            case Menu.FIRST + 6://导航到手表主界面
                gotoWatchActivity();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //回退fragment栈
        int stackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        if (stackEntryCount > 0) {
            if (ftCanCommit) {
                getSupportFragmentManager().popBackStack();
                //重建二维码扫描界面
                initWatchQRCodeScanFragment();
                showWatchQRCodeScanFragment();
            }
        } else {
            finish();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Logger.d(Logger.LOG_TAG,"WatchSearchActivity onRequestPermissionsResult");
        if( captureFragment != null){
            captureFragment.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
    }

    //region ========================== Override 父类方法 ==========================
    @Override
    protected void initWatchServiceFunction() {
        //不处理,此界面不需要知道蓝牙回调事件
    }

    @Override
    protected void onWatchServiceConnected() {
        if (mWatchService.getDevice() != null && mWatchService.getDevice().getAddress() != null
                && mWatchService.getDevice().getAddress().equalsIgnoreCase(watchMacAddress)) {//说明现在已经连接了,直接到WatchActivity
            Logger.d(Logger.DEBUG_TAG,"WatchSearchActivity -----> onWatchServiceConnected()");
            mIsFound = true;
            bindWatchSuccess();
        }
    }

    @Override
    protected void onSearchWatchSuccess(BluetoothDevice device) {//已找到手表
        Logger.d(Logger.DEBUG_TAG,"WatchSearchActivity -----> onSearchWatchSuccess()");
        mWatch = device;
        mIsFound = true;
        bindWatchSuccess();
        DeviceLocalUtil.putDevice2Local(mWatch);
    }

    @Override
    protected void onSearchWatchFail() {
        bindWatchFail(1);
    }

    @Override
    protected void onSearchWatchStop() {
        if (!mIsFound) {
            if (menuContinue != null) {
                menuContinue.setVisible(true);
            }
            if (tv_bind_status != null) {
                tv_bind_status.setText(R.string.activity_watch_search_search_fail);
            }

            if (reSearchBtn != null){
                reSearchBtn.setVisibility(View.VISIBLE);
            }
        }
    }

    //endregion ========================== Override 父类方法 ==========================

    //region ========================== 二维码解析 ==========================
    @Override
    public void onAnalyzeSuccess(Bitmap mBitmap, String result) {
        //1.销毁二维码扫描界面
        if (captureFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .remove(captureFragment)
                    .commit();
        }

        //2.解析扫描结果
        //http://a.app.qq.com/o/simple.jsp?pkgname=com.fitmix.sdk&BtID='c7:57:c5:ff:f0:94'&ChipID='74B5E7EEB1E5AA55'&SN='A1AX0100HPHH000057'
        if (result != null) {
            watchInfo = new WatchInfo();
            String chipId = null;
            int index = result.lastIndexOf("BtID=");
            if (index != -1 && result.length() > index + 22) {
                String scanMac = result.substring(index + 6, index + 23).toUpperCase();//蓝牙搜索需要大写字母
                watchInfo.setMac(scanMac);
            }

            index = result.lastIndexOf("ChipID=");
            if (index != -1) {
                chipId = result.substring(index + 8, result.indexOf("'&SN="));
                watchInfo.setChipId(chipId);
            }

            index = result.lastIndexOf("SN=");
            if (index != -1) {
                watchInfo.setSerialNum(result.substring(index + 4, result.length() - 1));
            }
            //向服务器发送绑定请求
            if (!TextUtils.isEmpty(chipId)) {
                Logger.i(Logger.DEBUG_TAG, "WatchSearchActivity-->onAnalyzeSuccess watchInfo:" + watchInfo.getWatchInfo());
                sendBindWatch(chipId, watchInfo.getWatchInfo());//
                if (layout_bind != null) {
                    layout_bind.setVisibility(View.VISIBLE);
                    if (reSearchBtn != null){
                        reSearchBtn.setVisibility(View.GONE);
                    }
                }
                return;
            }
        }

        bindWatchFail(0);
    }

    @Override
    public void onAnalyzeFailed() {
        bindWatchFail(0);
    }

    //endregion ========================== 二维码解析 ==========================

    //region ========================== 乐享动账号和手表蓝牙绑定 ==========================

    /**
     * 向后台发起手表绑定请求
     *
     * @param chipId    chipId
     * @param watchInfo 手表其它补充信息,json字符串
     */
    private void sendBindWatch(String chipId, String watchInfo) {
        int uid = UserDataManager.getUid();
        String key = uid + "_IRONCLOUDT1_" + chipId;
        int requestId = UserDataManager.getInstance().uploadDeviceInfo(uid, 1, watchInfo, key, true);
        registerDataReqStatusListener(requestId);
    }

    //endregion ========================== 乐享动账号和手表蓝牙绑定 ==========================
}
