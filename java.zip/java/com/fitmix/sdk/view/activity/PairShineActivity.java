package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.sound.SoundPlayer;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.fragment.SelectColorFragment;
import com.fitmix.sdk.view.fragment.SelectModeFragment;

/**
 * 智能灯界面
 */
public class PairShineActivity extends BaseActivity {

    public static final int SOUND_COLOR_CHANGE = 1;
    public static final int SOUND_STYLE_ENTERTAINMENT = 2;


    private FragmentManager fragmentManager;
    FragmentTransaction transaction;
    private SelectColorFragment colorFragment;
    private SelectModeFragment modeFragment;

    private RadioGroup rg_pair_shine_select;
    private final int FRAGMENT_SELECT_COLOR = 0;
    private final int FRAGMENT_SELECT_MODE = 1;
    private TextView pair_shine__bg_select;
    private RadioButton rb_select_color;
    private RadioButton rb_select_mode;

    private Button activity_shine_brightness_up;
    private Button activity_shine_brightness_down;
    private Button activity_shine_off;
    private Button activity_shine_on;
    private SoundPlayer soundPlayer;
    private RadioGroup.OnCheckedChangeListener onCheckedChangeListener;
    private View.OnClickListener myOnClickListener;

    //    /** 指示音效播放是否正在忙*/
//    private boolean isBusy = false;
    // //////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_shine);
        setPageName("PairShineActivity");

        initToolbar();
        toolbarSet();
        initView();
        initFunction();
    }

    /**
     * 灯泡控制器初始化
     */
    private void initFunction() {
        if (soundPlayer == null) {
            soundPlayer = new SoundPlayer();
        }
    }

    private void toolbarSet() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
    }

    private void initView() {
        fragmentManager = getSupportFragmentManager();
        rb_select_color = (RadioButton) findViewById(R.id.radio_pair_shine_select_color);
        rb_select_mode = (RadioButton) findViewById(R.id.radio_pair_shine_select_mode);
        rg_pair_shine_select = (RadioGroup) findViewById(R.id.rg_pair_shine_select);
        pair_shine__bg_select = (TextView) findViewById(R.id.pair_shine__bg_select);
        initAllFragment();
        setTabSelection(FRAGMENT_SELECT_COLOR);
        onCheckedChangeListener = new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                getSupportFragmentManager().popBackStackImmediate();
                switch (checkedId) {
                    case R.id.radio_pair_shine_select_color://颜色选择
                        setTabSelection(FRAGMENT_SELECT_COLOR);
                        break;
                    case R.id.radio_pair_shine_select_mode:
                        setTabSelection(FRAGMENT_SELECT_MODE);
                        break;
                }
            }
        };
        rg_pair_shine_select.setOnCheckedChangeListener(onCheckedChangeListener);

        activity_shine_brightness_up = (Button) findViewById(R.id.activity_shine_brightness_up);
        activity_shine_brightness_down = (Button) findViewById(R.id.activity_shine_brightness_down);
        activity_shine_off = (Button) findViewById(R.id.activity_shine_off);
        activity_shine_on = (Button) findViewById(R.id.activity_shine_on);

        //监听器
        myOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**
                 * 解决bug
                 * java.lang.NullPointerException
                 * at com.fitmix.sdk.PairShineActivity$3.onClick(PairShineActivity.java:223)
                 * */
                if (soundPlayer == null) {
                    soundPlayer = new SoundPlayer();
                }
                if (soundPlayer == null) return;
                switch (v.getId()) {
                    case R.id.activity_shine_on:
                        soundPlayer.playSingleSound(R.raw.snet_control_button_open);
                        break;

                    case R.id.activity_shine_off:
                        soundPlayer.playSingleSound(R.raw.snet_control_button_close);
                        break;

                    case R.id.activity_shine_brightness_up:
                        soundPlayer.playSingleSound(R.raw.snet_light_add);
                        break;

                    case R.id.activity_shine_brightness_down:
                        soundPlayer.playSingleSound(R.raw.snet_light_decrept);
                        break;

                    default:
                        break;
                }
            }
        };

        activity_shine_brightness_up.setOnClickListener(myOnClickListener);
        activity_shine_brightness_down.setOnClickListener(myOnClickListener);
        activity_shine_off.setOnClickListener(myOnClickListener);
        activity_shine_on.setOnClickListener(myOnClickListener);
    }

    /**
     * 初始化所有的Fragment
     */
    private void initAllFragment() {
        transaction = fragmentManager.beginTransaction();
        if (colorFragment == null) {
            /** SelectColorFragment,则创建一个并添加到界面上 **/
            colorFragment = new SelectColorFragment();
            transaction.add(R.id.fl_activity_pair_shine_select, colorFragment);
        }
        if (modeFragment == null) {
            /** SelectModeFragment,则创建一个并添加到界面上 **/
            modeFragment = new SelectModeFragment();
            transaction.add(R.id.fl_activity_pair_shine_select, modeFragment);
        }
        transaction.commit();
    }

    /**
     * 先隐藏掉所有的Fragment,以防止有多个Fragment显示在界面上的情况
     *
     * @param transaction
     */
    private void hideFragments(FragmentTransaction transaction) {
        if (colorFragment != null) {
            transaction.hide(colorFragment);
        }
        if (modeFragment != null) {
            transaction.hide(modeFragment);
        }
    }

    /**
     * 根据序号设置fragment
     *
     * @param index
     */
    private void setTabSelection(int index) {
        transaction = fragmentManager.beginTransaction();
        /** 先隐藏掉所有的Fragment,以防止有多个Fragment显示在界面上的情况 **/
        hideFragments(transaction);
        textNormal();
        switch (index) {
            case FRAGMENT_SELECT_COLOR:
                if (colorFragment == null) {
                    /** 如果conversationFragment为空,则创建一个并添加到界面上 **/
                    colorFragment = new SelectColorFragment();
                    transaction.add(R.id.fl_activity_pair_shine_select, colorFragment);
                } else {
                    transaction.show(colorFragment);
                }
                rb_select_color.setChecked(true);
                rb_select_color.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                        getResources().getDimension(R.dimen.radio_button_checked));
                pair_shine__bg_select.setBackgroundResource(R.drawable.activity_pair_shine_select_color);
                break;
            case FRAGMENT_SELECT_MODE:
                if (modeFragment == null) {
                    /** 如果conversationFragment为空,则创建一个并添加到界面上 **/
                    modeFragment = new SelectModeFragment();
                    transaction.add(R.id.fl_activity_pair_shine_select, modeFragment);
                } else {
                    transaction.show(modeFragment);
                }
                rb_select_mode.setChecked(true);
                rb_select_mode.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                        getResources().getDimension(R.dimen.radio_button_checked));
                pair_shine__bg_select.setBackgroundResource(R.drawable.activity_pair_shine_select_mode);
                break;
        }
        transaction.commit();
    }

    private void textNormal() {
//		float xx = Utils.sp2px(getResources(),getResources().getDimension(R.dimen.radio_button_normal));
//		rb_select_color.setTextSize(xx);
//		rb_select_mode.setTextSize(xx);
        rb_select_color.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                getResources().getDimension(R.dimen.radio_button_normal));
        rb_select_mode.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                getResources().getDimension(R.dimen.radio_button_normal));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (soundPlayer != null) {
            soundPlayer.releaseResource();
            soundPlayer = null;
        }
    }


    @Override
    protected void initViews() {

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {

    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {

    }

    /**
     * 播放音频命令
     *
     * @param type  命令类型,可选值
     * @param index 声音资源标号
     */
    public void playCommand(int type, int index) {
        if (soundPlayer == null) {
            soundPlayer = new SoundPlayer();
        }
        if (soundPlayer == null) return;

        switch (type) {
            case SOUND_COLOR_CHANGE://改变颜色命令
                if (index == 0) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_0);
                } else if (index == 1) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_1);
                } else if (index == 2) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_2);
                } else if (index == 3) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_3);
                } else if (index == 4) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_4);
                } else if (index == 5) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_5);
                } else if (index == 6) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_6);
                } else if (index == 7) {
                    soundPlayer.playSingleSound(R.raw.snet_control_color_7);
                }
                break;
            case SOUND_STYLE_ENTERTAINMENT://改变场景
                if (index == 0) {
                    soundPlayer.playSingleSound(R.raw.snet_style_entertainment_0);
                } else if (index == 1) {
                    soundPlayer.playSingleSound(R.raw.snet_style_entertainment_1);
                } else if (index == 2) {
                    soundPlayer.playSingleSound(R.raw.snet_style_entertainment_2);
                } else if (index == 3) {
                    soundPlayer.playSingleSound(R.raw.snet_style_entertainment_3);
                } else if (index == 4) {
                    soundPlayer.playSingleSound(R.raw.snet_style_entertainment_4);
                }
                break;
        }
    }
}
