package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.widget.AppMsg;

public class EmailBindActivity extends BaseActivity {

    public static final int BIND_TYPE_BY_EMAIL = 1;
    public static final int BIND_TYPE_BY_EMAIL_WITH_PWD = 2;
    private EditText txt_account;
    private String mEmailAddress;
    private EditText txt_password;
    private EditText txt_confirm_password;

    private String mPassword;
    private String mConfirmPwd;

    private boolean isEmailBind;//邮箱绑定
    private boolean isEmailBindWithPWd;//没有设置过密码的邮箱绑定

    /**
     * 金币任务,邮箱绑定是否完成
     */
    private boolean coinTaskEmailBind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_email);
        setPageName("EmailBindActivity");

        isEmailBind = getIntent().getBooleanExtra("EmailBind", false);
        isEmailBindWithPWd = getIntent().getBooleanExtra("EmailBindWithPWD", false);
        initToolbar();
        initViews();

        coinTaskEmailBind = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_BIND_EMAIL, true);
    }

    /**
     * 初始化控件
     */
    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        txt_account = (EditText) findViewById(R.id.txt_account);
        txt_password = (EditText) findViewById(R.id.txt_password);
        txt_confirm_password = (EditText) findViewById(R.id.txt_confirm_password);

        if (isEmailBind) {
            txt_password.setVisibility(View.INVISIBLE);
            txt_confirm_password.setVisibility(View.INVISIBLE);
        } else if (isEmailBindWithPWd) {
            txt_password.setVisibility(View.VISIBLE);
            txt_confirm_password.setVisibility(View.VISIBLE);
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 35://绑定邮箱
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表存手机号
                SettingsHelper.putString(Config.SETTING_USER_EMAIL, mEmailAddress);

//                getMyConfig().getPersonInfo().setBindEmail(mEmailAddress);
                if (!coinTaskEmailBind) {
                    finishBindEmailCoinTask();
                } else {
                    setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                    finish();
                }
                break;
            case Config.MODULE_USER + 37://绑定邮箱带有密码的绑定
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表存手机号
                SettingsHelper.putString(Config.SETTING_USER_EMAIL, mEmailAddress);
                //本地存的个人密码更改
                PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_PWD, mPassword);
//                getMyConfig().getPersonInfo().setBindEmail(mEmailAddress);
//                getMyConfig().getSystemConfig().setLastPassword(mPassword);
                if (!coinTaskEmailBind) {
                    finishBindEmailCoinTask();
                } else {
                    setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                    finish();
                }
                break;

            case Config.MODULE_USER + 63://完成绑定邮箱金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        //弹窗
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_EMAIL, true);//绑定邮箱金币任务完成

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription(),
                                    new QuestRewardsDialog.OnQuestRewardsDialogDismiss() {
                                        @Override
                                        public void onRewardsDialogDismiss() {//奖励金币确定后,继续返回状态给AccountSetActivity
                                            setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                                            finish();
                                        }
                                    });

                            return;
                        }
                    }
                }
                setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                finish();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 35://绑定邮箱
            case Config.MODULE_USER + 37://绑定邮箱带有密码的绑定
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        if (!TextUtils.isEmpty(bean.getMsg())) {
                            showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                        }
                    }
                }
                break;
            case Config.MODULE_USER + 63://绑定邮箱金币任务
                setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                finish();
                break;
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_bind:
                processBindEmail();
                break;
        }
    }


    /**
     * 绑定邮箱
     */
    private void processBindEmail() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        if (isEmailBind) {
            sendBindRequest();
        } else if (isEmailBindWithPWd) {
            sendBindRequestWithPWD();
        }

    }

    /**
     * 发送绑定的请求
     */
    private void sendBindRequest() {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().userBind(mEmailAddress, mEmailAddress, BIND_TYPE_BY_EMAIL, true);
        registerDataReqStatusListener(requestId);
//
//        String bindString = getRequestSynthesizer().getBindString(mEmailAddress, mEmailAddress, BIND_TYPE_BY_EMAIL);
//        sendNetRequest(bindString, BIND_TYPE_BY_EMAIL);
    }

    /**
     * 发送绑定的请求 绑定手机 并且带着密码的绑定
     */
    private void sendBindRequestWithPWD() {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().userBindWithPWD(mEmailAddress, mEmailAddress, BIND_TYPE_BY_EMAIL_WITH_PWD, mPassword, true);
        registerDataReqStatusListener(requestId);

//        String bindString = .getBindWithPWDString(mEmailAddress, mEmailAddress, BIND_TYPE_BY_EMAIL, mPassword);
//        sendNetRequest(bindString, BIND_TYPE_BY_EMAIL_WITH_PWD);

    }

    /**
     * 检查错误
     *
     * @return Config.ERROR_NO_ERROR   成功
     * 其它                             错误代码
     */
    private int checkInputError() {

        mEmailAddress = txt_account.getText().toString();
        if (!FitmixUtil.isEmail(mEmailAddress)) {
            return Config.ERROR_FORMAT_ERROR;
        }
        if (isEmailBindWithPWd) {
            mPassword = txt_password.getText().toString();
            mConfirmPwd = txt_confirm_password.getText().toString();
            if (mPassword.length() < Config.PASSWORD_LENGTH_MIN)
                return Config.ERROR_PASSWORD_TOO_SHORT;
            if (!mPassword.equals(mConfirmPwd))
                return Config.ERROR_PASSWORD_NOT_MATCH;
        }
        return Config.ERROR_NO_ERROR;
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成绑定邮箱金币任务
     */
    private void finishBindEmailCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishEmailBindCoinTask(uid, true);
        registerDataReqStatusListener(reqId);
    }
    //endregion ============================= 金币任务 =============================

}
