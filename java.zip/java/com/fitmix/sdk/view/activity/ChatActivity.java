package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.ChatActivityMessageBeanList;
import com.fitmix.sdk.model.api.bean.ChatMessageBean;
import com.fitmix.sdk.model.database.ChatMessageInfoList;
import com.fitmix.sdk.model.database.ChatMessageInfoListHelper;
import com.fitmix.sdk.model.database.ChatMessageResultBean;
import com.fitmix.sdk.model.database.ChatMessageResultBeanHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MessageInfo;
import com.fitmix.sdk.model.database.MessageInfoHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.ChatMessageAdapter;
import com.fitmix.sdk.view.animation.LayoutAnimationUtils;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.EmptyRecyclerView;
import com.fitmix.sdk.view.widget.recyclerview_decoration.SpacesItemDecoration;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends BaseActivity {
    private ImageView chat_send_iv;
    private EmptyRecyclerView chat_message_rv;
    private SwipeLoadLayout swipeLayout;
    private ChatMessageAdapter chatMessageAdapter;
    private EditText chat_et;
    private int targetId;
    private int groupId;
    private int reject;
    private List<ChatMessageResultBean> resultBeanListDataBase = new ArrayList<>();//数据库
    private JSONArray jsonArrayDatabase;
    String groupIdFromWeb;
    private ChatMessageInfoList chatMessageInfoListBase = new ChatMessageInfoList();
    private String targetName;
    private String targetAvatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        initToolbar();
        initData();
        getChatMessageInfoListBase();
        getPrivateMsg();
        initViews();
    }


    //获取当前聊天组的聊天内容
    private List<ChatMessageResultBean> getChatMessageInfoListBase() {
        if (groupId != 0) {

            ChatMessageInfoList chatMessageInfoListByID = ChatMessageInfoListHelper.getInstance().getChatMessageInfoListByID(String.valueOf(groupId));
            if (chatMessageInfoListByID == null) {
                chatMessageInfoListBase = new ChatMessageInfoList();
                jsonArrayDatabase = new JSONArray();
            } else {
                if (resultBeanListDataBase.size() > 0) {
                    resultBeanListDataBase.clear();
                }
                chatMessageInfoListBase = chatMessageInfoListByID;
                String result = chatMessageInfoListByID.getResult();
                Logger.d(Logger.DEBUG_TAG, "database result:" + result);
                try {
                    jsonArrayDatabase = new JSONArray(result);
                    for (int i = 0; i < jsonArrayDatabase.length(); i++) {
                        ChatMessageResultBean object = JsonHelper.getObject(jsonArrayDatabase.getString(i), ChatMessageResultBean.class);
                        resultBeanListDataBase.add(object);
                    }

                    Logger.d(Logger.DEBUG_TAG, "view messageBeanListData:" + resultBeanListDataBase.size());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return resultBeanListDataBase;
        } else {
            jsonArrayDatabase = new JSONArray();
        }
        return resultBeanListDataBase;
    }

    private void initData() {
        if (getIntent() != null) {
            groupId = getIntent().getIntExtra("groupId", 0);
            targetId = getIntent().getIntExtra("targetId", 0);
            reject = getIntent().getIntExtra("reject", 0);
            targetName = getIntent().getStringExtra("targetName");
            targetAvatar = getIntent().getStringExtra("targetAvatar");
        }

    }

    private void getPrivateMsg() {
        if (groupId != 0) {
            int requestId = UserDataManager.getInstance().getUserPrivateMsgInfo(groupId, true);
            registerDataReqStatusListener(requestId);
        }
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            if (getIntent() != null) {
                setUiTitle(getIntent().getStringExtra("targetName"));
            }
        }
        chat_et = (EditText) findViewById(R.id.chat_et);
        swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
        swipeLayout.setOnRefreshListener(new SwipeLoadLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getPrivateMsg();
            }
        });
        chat_send_iv = (ImageView) findViewById(R.id.chat_send_iv);
        chat_message_rv = (EmptyRecyclerView) findViewById(R.id.swipe_target);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        chat_message_rv.setEmptyView(emptyView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        chat_message_rv.setLayoutManager(linearLayoutManager);//设置布局管理器
        chat_message_rv.addItemDecoration(new SpacesItemDecoration(10));
        chat_message_rv.setHasFixedSize(true);
        chat_message_rv.setLayoutAnimation(LayoutAnimationUtils.getModalInAnimationController());//item 展示动画
        chat_message_rv.setAdapter(getChatMessageRecyclerAdapter());
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.chat_send_iv:
                String content = chat_et.getText().toString();
                if (!TextUtils.isEmpty(content)) {
                    if (0 == reject) {//没有被屏蔽
                        chat_send_iv.setEnabled(false);
                        //不考虑缓存
                        int requestId = UserDataManager.getInstance().sendUserPrivateMsg(targetId, content, true);
                        registerDataReqStatusListener(requestId);
                    } else if (1 == reject) {//已经被屏蔽

                        //保存屏蔽用户相关信息，在消息列表展示被屏蔽用户，用于取消屏蔽
                        MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(groupId);
                        if (messageInfoByID == null) {//消息列表中没有，说明已删除该组聊天,就保存到 ChatMessageResultBeanHelper 里
                            ChatMessageResultBean shieldUserResult = ChatMessageResultBeanHelper.getInstance().getChatMessageInfoListByID(String.valueOf(groupId));
                            if (shieldUserResult == null) {
                                shieldUserResult = new ChatMessageResultBean();
                                shieldUserResult.setMessageId(0L);
                                shieldUserResult.setUid((long) UserDataManager.getUid());
                                shieldUserResult.setReject(1);
                                shieldUserResult.setName(targetName);
                                shieldUserResult.setAddTime(System.currentTimeMillis());
                                shieldUserResult.setAvatar(targetAvatar);
                                shieldUserResult.setContent(content);
                                shieldUserResult.setGroupId(String.valueOf(groupId));
                                ChatMessageResultBeanHelper.getInstance().asyncWriteChatMessageInfo(shieldUserResult);
                            } else {
                                shieldUserResult.setMessageId(0L);
                                shieldUserResult.setUid((long) UserDataManager.getUid());
                                shieldUserResult.setReject(1);
                                shieldUserResult.setName(targetName);
                                shieldUserResult.setAddTime(System.currentTimeMillis());
                                shieldUserResult.setAvatar(targetAvatar);
                                shieldUserResult.setContent(content);
                                shieldUserResult.setGroupId(String.valueOf(groupId));
                                ChatMessageResultBeanHelper.getInstance().asyncWriteChatMessageInfo(shieldUserResult);
                            }
                        }

                        ChatMessageResultBean chatMessageResultBean = new ChatMessageResultBean();
                        chatMessageResultBean.setMessageId(0L);
                        chatMessageResultBean.setUid((long) UserDataManager.getUid());
                        chatMessageResultBean.setReject(1);
                        chatMessageResultBean.setName(SettingsHelper.getString(Config.SETTING_USER_NAME, ""));
                        chatMessageResultBean.setAddTime(System.currentTimeMillis());
                        chatMessageResultBean.setAvatar(SettingsHelper.getString(Config.SETTING_USER_AVATAR, ""));
                        chatMessageResultBean.setContent(content);
                        chatMessageResultBean.setGroupId(String.valueOf(groupId));


                        //保存到数据库
                        jsonArrayDatabase.put(JsonHelper.createJsonString(chatMessageResultBean));
                        resultBeanListDataBase.add(chatMessageResultBean);

                        chatMessageInfoListBase.setSelectChannel("0");
                        chatMessageInfoListBase.setResult(jsonArrayDatabase.toString());
                        Logger.d(Logger.DEBUG_TAG, "屏蔽 database result:" + jsonArrayDatabase.toString());
                        chatMessageInfoListBase.setGroupId(String.valueOf(groupId));
                        Logger.d(Logger.DEBUG_TAG, "屏蔽 写入：" + chatMessageInfoListBase.getResult());
                        ChatMessageInfoListHelper.getInstance().asyncWriteChatMessageInfo(chatMessageInfoListBase);


                        //添加到adapter的data
                        getChatMessageRecyclerAdapter().setChatMessageList(resultBeanListDataBase);
                        chat_message_rv.scrollToPosition(resultBeanListDataBase.size() - 1);
                        Toast.makeText(this, getResources().getString(R.string.chat_cannot_send_msg_to_shield_user), Toast.LENGTH_LONG).show();
                        chat_et.setText("");
                        hideInputMethod();
                        Logger.d(Logger.DEBUG_TAG, "屏蔽消息时数据库消息内容数量：" + resultBeanListDataBase.size());

                    }

                } else {
                    showAppMessage(getResources().getString(R.string.activity_leave_message_empty_prompt), AppMsg.STYLE_ALERT);
                }


                break;
        }
    }


    /**
     * 获取成员适配器
     */
    private ChatMessageAdapter getChatMessageRecyclerAdapter() {
        if (chatMessageAdapter == null) chatMessageAdapter = new ChatMessageAdapter();
        return chatMessageAdapter;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
            String content = chat_et.getText().toString();
            if (!TextUtils.isEmpty(content)) {
                if (0 == reject) {//没有被屏蔽
                    chat_send_iv.setEnabled(false);
                    //不考虑缓存
                    int requestId = UserDataManager.getInstance().sendUserPrivateMsg(targetId, content, true);
                    registerDataReqStatusListener(requestId);
                } else if (1 == reject) {//已经被屏蔽

                    //保存屏蔽用户相关信息，在消息列表展示被屏蔽用户，用于取消屏蔽
                    MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(groupId);
                    if (messageInfoByID == null) {//消息列表中没有，说明已删除该组聊天,就保存到 ChatMessageResultBeanHelper 里
                        ChatMessageResultBean shieldUserResult = ChatMessageResultBeanHelper.getInstance().getChatMessageInfoListByID(String.valueOf(groupId));
                        if (shieldUserResult == null) {
                            shieldUserResult = new ChatMessageResultBean();
                            shieldUserResult.setMessageId(0L);
                            shieldUserResult.setUid((long) UserDataManager.getUid());
                            shieldUserResult.setReject(1);
                            shieldUserResult.setName(targetName);
                            shieldUserResult.setAddTime(System.currentTimeMillis());
                            shieldUserResult.setAvatar(targetAvatar);
                            shieldUserResult.setContent(content);
                            shieldUserResult.setGroupId(String.valueOf(groupId));
                            ChatMessageResultBeanHelper.getInstance().asyncWriteChatMessageInfo(shieldUserResult);
                        } else {
                            shieldUserResult.setMessageId(0L);
                            shieldUserResult.setUid((long) UserDataManager.getUid());
                            shieldUserResult.setReject(1);
                            shieldUserResult.setName(targetName);
                            shieldUserResult.setAddTime(System.currentTimeMillis());
                            shieldUserResult.setAvatar(targetAvatar);
                            shieldUserResult.setContent(content);
                            shieldUserResult.setGroupId(String.valueOf(groupId));
                            ChatMessageResultBeanHelper.getInstance().asyncWriteChatMessageInfo(shieldUserResult);
                        }


                    }


                    //保存到数据库
                    ChatMessageResultBean chatMessageResultBean = new ChatMessageResultBean();

                    chatMessageResultBean.setMessageId(0L);
                    chatMessageResultBean.setUid((long) UserDataManager.getUid());
                    chatMessageResultBean.setReject(1);
                    chatMessageResultBean.setName(SettingsHelper.getString(Config.SETTING_USER_NAME, ""));
                    chatMessageResultBean.setAddTime(System.currentTimeMillis());
                    chatMessageResultBean.setAvatar(SettingsHelper.getString(Config.SETTING_USER_AVATAR, ""));
                    chatMessageResultBean.setContent(content);
                    chatMessageResultBean.setGroupId(String.valueOf(groupId));


                    jsonArrayDatabase.put(JsonHelper.createJsonString(chatMessageResultBean));
                    resultBeanListDataBase.add(chatMessageResultBean);

                    chatMessageInfoListBase.setSelectChannel("0");
                    chatMessageInfoListBase.setResult(jsonArrayDatabase.toString());
                    Logger.d(Logger.DEBUG_TAG, "屏蔽 database result:" + jsonArrayDatabase.toString());
                    chatMessageInfoListBase.setGroupId(String.valueOf(groupId));
                    Logger.d(Logger.DEBUG_TAG, "屏蔽 写入：" + chatMessageInfoListBase.getResult());
                    ChatMessageInfoListHelper.getInstance().asyncWriteChatMessageInfo(chatMessageInfoListBase);


                    //添加到adapter的data
                    getChatMessageRecyclerAdapter().setChatMessageList(resultBeanListDataBase);
                    chat_message_rv.scrollToPosition(resultBeanListDataBase.size() - 1);
                    Toast.makeText(this, getResources().getString(R.string.chat_cannot_send_msg_to_shield_user), Toast.LENGTH_LONG).show();
                    chat_et.setText("");
                    hideInputMethod();
                    Logger.d(Logger.DEBUG_TAG, "屏蔽消息时数据库消息内容数量：" + resultBeanListDataBase.size());

                }

            } else {
                showAppMessage(getResources().getString(R.string.activity_leave_message_empty_prompt), AppMsg.STYLE_ALERT);
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        chat_send_iv.setEnabled(true);
        if (dataReqResult == null) return;
        Logger.d(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 68://发送私信
                ChatMessageBean messageBean = JsonHelper.getObject(result, ChatMessageBean.class);
                if (messageBean != null) {
                    ChatMessageBean.MessageBean message = messageBean.getMessage();
                    if (message != null) {
                        ChatMessageBean.MessageBean.MsgBodyBean msgBody = message.getMsgBody();


                        ChatMessageResultBean chatMessageResultBean = new ChatMessageResultBean();
                        chatMessageResultBean.setMessageId((long) message.getId());
                        chatMessageResultBean.setAddTime(message.getAddTime());
                        if (msgBody != null) {
                            groupIdFromWeb = msgBody.getGroupId();
                            chatMessageResultBean.setGroupId(groupIdFromWeb);
                            chatMessageResultBean.setContent(msgBody.getContent());
                            chatMessageResultBean.setUid(Long.parseLong(msgBody.getFromUid()));

                        } else {
                            groupIdFromWeb = String.valueOf(groupId);
                        }
                        chatMessageResultBean.setAvatar(SettingsHelper.getString(Config.SETTING_USER_AVATAR, ""));
                        chatMessageResultBean.setName(SettingsHelper.getString(Config.SETTING_USER_NAME, ""));
                        chatMessageResultBean.setReject(0);


                        //保存到数据库
                        jsonArrayDatabase.put(JsonHelper.createJsonString(chatMessageResultBean));
                        resultBeanListDataBase.add(chatMessageResultBean);
                    }

                    chatMessageInfoListBase.setSelectChannel("0");
                    chatMessageInfoListBase.setResult(jsonArrayDatabase.toString());
                    chatMessageInfoListBase.setGroupId(groupIdFromWeb);
                    Logger.d(Logger.DEBUG_TAG, "发送私信callback 写入：" + chatMessageInfoListBase.getResult());
                    ChatMessageInfoListHelper.getInstance().asyncWriteChatMessageInfo(chatMessageInfoListBase);

                    getChatMessageInfoListBase();
                    //添加到adapter的data
                    getChatMessageRecyclerAdapter().setChatMessageList(resultBeanListDataBase);
                    chat_et.setText("");
                    hideInputMethod();
                    chat_message_rv.scrollToPosition(resultBeanListDataBase.size() - 1);

                }


                break;

            case Config.MODULE_USER + 72://获取用户消息详情
                ChatActivityMessageBeanList messageBeanList = JsonHelper.getObject(result, ChatActivityMessageBeanList.class);
                List<ChatActivityMessageBeanList.PageBean.ResultBean> resultBeanList = messageBeanList.getPage().getResult();
                swipeLayout.setRefreshing(false);

                if (resultBeanList.size() > 0) {
                    for (int i = 0; i < resultBeanList.size(); i++) {
                        ChatActivityMessageBeanList.PageBean.ResultBean resultBean1 = resultBeanList.get(i);


                        ChatMessageResultBean chatMessageResultBean_base_user = new ChatMessageResultBean();
                        chatMessageResultBean_base_user.setGroupId(String.valueOf(groupId));
                        chatMessageResultBean_base_user.setMessageId((long) resultBean1.getId());
                        chatMessageResultBean_base_user.setAddTime(resultBean1.getAddTime());
                        chatMessageResultBean_base_user.setAvatar(resultBean1.getFromUser().getAvatar());
                        chatMessageResultBean_base_user.setContent(resultBean1.getMsgBody().getContent());
                        chatMessageResultBean_base_user.setName(resultBean1.getFromUser().getName());
                        chatMessageResultBean_base_user.setReject(0);
                        chatMessageResultBean_base_user.setUid((long) (resultBean1.getFromUser().getId()));

                        //保存到数据库
                        jsonArrayDatabase.put(JsonHelper.createJsonString(chatMessageResultBean_base_user));
                        resultBeanListDataBase.add(chatMessageResultBean_base_user);

                    }

                    //保存到数据库
                    chatMessageInfoListBase.setSelectChannel(resultBeanList.get(0).getSelectChannel());
                    chatMessageInfoListBase.setResult(jsonArrayDatabase.toString());
                    chatMessageInfoListBase.setGroupId(String.valueOf(groupId));
                    Logger.d(Logger.DEBUG_TAG, "获取用户消息详情callback 写入：" + chatMessageInfoListBase.getResult());
                    ChatMessageInfoListHelper.getInstance().asyncWriteChatMessageInfo(chatMessageInfoListBase);


                    getChatMessageRecyclerAdapter().setChatMessageList(resultBeanListDataBase);
                    chat_message_rv.scrollToPosition(resultBeanListDataBase.size() - 1);

                } else {
                    Logger.d(Logger.DEBUG_TAG, "无消息时消息内容数量：" + resultBeanListDataBase.size());
                    getChatMessageRecyclerAdapter().setChatMessageList(resultBeanListDataBase);
                    chat_message_rv.scrollToPosition(resultBeanListDataBase.size() - 1);
                }


                break;
        }


    }

    @Override
    protected void processReqError(int requestId, String error) {
        chat_send_iv.setEnabled(true);
        Logger.e(Logger.DEBUG_TAG, "ChatActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        switch (requestId) {
            case Config.MODULE_USER + 68:
                showAppMessage(getResources().getString(R.string.errcode_send_failure), AppMsg.STYLE_ALERT);
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
