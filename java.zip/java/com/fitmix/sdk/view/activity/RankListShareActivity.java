package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.widget.CircleImageView;
import com.fitmix.sdk.view.widget.ViewUtils;

import java.io.File;
import java.util.Calendar;

public class RankListShareActivity extends BaseActivity implements View.OnClickListener {

    private View picView;
    private ImageView rank_list_share_pic_iv;
    private Bitmap sharePhotoBitmap;
    public final String TAG = "AuthShareHelper";
    ShareManager share = new ShareManager(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_list_share);
        setPageName("RankListShareActivity");
        initToolbar();
        initViews();
    }


    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        rank_list_share_pic_iv = (ImageView) findViewById(R.id.rank_list_share_pic_iv);

        TextView tv_share_to_wechat = (TextView) findViewById(R.id.tv_share_to_wechat);
        TextView tv_share_to_circle = (TextView) findViewById(R.id.tv_share_to_circle);
        TextView tv_share_to_qzone = (TextView) findViewById(R.id.tv_share_to_qzone);
        TextView tv_share_to_weibo = (TextView) findViewById(R.id.tv_share_to_weibo);
        TextView tv_share_to_qq = (TextView) findViewById(R.id.tv_share_to_qq);

        tv_share_to_wechat.setOnClickListener(this);
        tv_share_to_circle.setOnClickListener(this);
        tv_share_to_qzone.setOnClickListener(this);
        tv_share_to_weibo.setOnClickListener(this);
        tv_share_to_qq.setOnClickListener(this);

        picView = getLayoutInflater().inflate(R.layout.rank_list_share_view, null);
        CircleImageView rank_list_share_avatar = (CircleImageView) picView.findViewById(R.id.rank_list_share_avatar);
        TextView rank_list_share_user_name_tv = (TextView) picView.findViewById(R.id.rank_list_share_user_name_tv);
        TextView rank_list_month_tv = (TextView) picView.findViewById(R.id.rank_list_month_tv);
        TextView rank_list_distance_tv = (TextView) picView.findViewById(R.id.rank_list_distance_tv);
        ImageView rank_list_share_level_iv = (ImageView) picView.findViewById(R.id.rank_list_share_level_iv);
        TextView rank_list_level_name_tv = (TextView) picView.findViewById(R.id.rank_list_level_name_tv);
        TextView rank_list_level_score_tv = (TextView) picView.findViewById(R.id.rank_list_level_score_tv);
        TextView rank_list_level_pace_name = (TextView) picView.findViewById(R.id.rank_list_level_pace_name);
        TextView rank_list_level_pace_value_name = (TextView) picView.findViewById(R.id.rank_list_level_pace_value_name);
     //   ImageView rank_list_share_code_icon_iv = (ImageView) picView.findViewById(R.id.rank_list_share_code_icon_iv);

        rank_list_share_user_name_tv.setText(SettingsHelper.getString(Config.SETTING_USER_NAME, ""));

        String stringAvatar = SettingsHelper.getString(Config.SETTING_USER_AVATAR, "");
        if (!TextUtils.isEmpty(stringAvatar)){
            String localFile = FitmixUtil.getPhotoPath() + SettingsHelper.getString(Config.SETTING_USER_ID,"") + "_avatar.jpg";
            if (FileUtils.isFileExist(localFile)) {//本地有图片,则从本地加载
                if (rank_list_share_avatar != null) {//头像
                    rank_list_share_avatar.setImageURI(Uri.fromFile(new File(localFile)));
                }
            } else {
                if (rank_list_share_avatar != null) {//头像
                    rank_list_share_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
                }
            }
        }


//        String appDownload = PrefsHelper.with(this, Config.PREFS_SPORT).read(Config.SP_KEY_APP_DOWNLOAD_QR);
//        if (!TextUtils.isEmpty(appDownload)) {//app下载二维码,暂不下载，使用默认的
//            if (rank_list_share_code_icon_iv != null) {
//                try {
//                    URL picUrl = new URL(appDownload);
//                    Bitmap pngBM = BitmapFactory.decodeStream(picUrl.openStream());
//                    rank_list_share_code_icon_iv.setImageBitmap(pngBM);
//                }catch (Exception e){
//                    e.printStackTrace();
//                }
//            }
//        }

        int distance = getIntent().getIntExtra("distance", 0);
        rank_list_distance_tv.setText(FormatUtil.formatDistance(distance));
        Logger.d(Logger.LOG_TAG, "distance:" + distance);
        Calendar instance = Calendar.getInstance();
        int month_defalt = instance.get(Calendar.MONTH) + 1;
        int month = getIntent().getIntExtra("month", month_defalt);
        Logger.d(Logger.DATA_FLOW_TAG, "month:" + month + " moth_defalt:" + month_defalt);
        if (0 == month) {
            month = month_defalt;
        }
        rank_list_month_tv.setText(String.valueOf(month));

        Logger.d(Logger.LOG_TAG, "month:" + month);

        int rank = getIntent().getIntExtra("rank", 0);
        if (0 == rank) {
            String language = ApiUtils.getLanguage();
            if ("zh".equals(language)) {
                rank_list_level_score_tv.setText("10万+");
            } else {
                rank_list_level_score_tv.setText("No." + "one hundred thousand+");
            }

        } else {
            String language = ApiUtils.getLanguage();
            if ("zh".equals(language)) {
                rank_list_level_score_tv.setText("第" + rank + "名");
            } else {
                rank_list_level_score_tv.setText("No." + rank);
            }
        }

        int level = getIntent().getIntExtra("level", 1);
        switch (level) {
            case 1:
                rank_list_level_pace_value_name.setText("10'00\"+");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_bronze_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_bronze_section));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.bronze_1E4B45));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_bronze_section_pace));
                }
                break;
            case 2:
                rank_list_level_pace_value_name.setText("8'00\"--10'00\"");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_silver_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_silver_section));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.silver_7C888D));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_silver_section_pace));
                }
                break;
            case 3:
                rank_list_level_pace_value_name.setText("6'30\"--8'00\"");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_gold_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_gold_section));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.gold_8A7139));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_gold_section_pace));
                }
                break;
            case 4:
                rank_list_level_pace_value_name.setText("5'30\"--6'30\"");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_platinum_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_platinum));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.platinum_47687A));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_platinum_pace));
                }
                break;
            case 5:
                rank_list_level_pace_value_name.setText("5'30\"--");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_diamond_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_diamond));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.diamond_6A6990));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_diamond_pace));
                }
                break;
            default:
                rank_list_level_pace_value_name.setText("10'00\"+");
                if (rank_list_share_level_iv != null) {
                    rank_list_share_level_iv.setBackgroundResource(R.drawable.rank_list_share_bronze_icon);
                }
                if (rank_list_level_name_tv != null) {
                    rank_list_level_name_tv.setText(getResources().getString(R.string.rank_list_bronze_section));
                    rank_list_level_name_tv.setTextColor(getResources().getColor(R.color.bronze_1E4B45));
                }
                if (rank_list_level_pace_name != null) {
                    rank_list_level_pace_name.setText(getResources().getString(R.string.rank_list_bronze_section_pace));
                }
                break;

        }

        sharePhotoBitmap = getScreenShot(picView,
                ViewUtils.dp2px(this, 400), ViewUtils.dp2px(this, 400));
        Bitmap sharePhotoBitmap1 = ImageHelper.adjustPhotoToFitSize(sharePhotoBitmap, ViewUtils.dp2px(this, 310), ViewUtils.dp2px(this, 310));
        rank_list_share_pic_iv.setImageBitmap(sharePhotoBitmap1);

        String sharePhotoPic = FitmixUtil.getTempPath() + UserDataManager.getUid() + "_" + System.currentTimeMillis() + "_rank_list_share_photo.jpg";
        if (sharePhotoBitmap1 != null && !TextUtils.isEmpty(sharePhotoPic)) {//保存相应的分享图片
            ImageHelper.saveBitmap2File(sharePhotoBitmap1, sharePhotoPic);
        }
        if (TextUtils.isEmpty(sharePhotoPic) || !FileUtils.isFileExist(sharePhotoPic)) {
            return;
        }
        share.setContentType(ShareManager.SHARE_TYPE_PIC);
        share.setFilename(sharePhotoPic);//截图
    }


    /**
     * 获取截屏
     *
     * @param view   要截屏的view
     * @param width  View的宽度,单位为像素,如果View有完整展示在界面上可以传0
     * @param height View的高度,单位为像素,如果View有完整展示在界面上可以传0
     * @return 位图
     */
    private Bitmap getScreenShot(View view, int width, int height) {
        if (view == null)
            return null;
        view.clearFocus();
        view.setPressed(false);
        boolean willNotCache = view.willNotCacheDrawing();
        view.setWillNotCacheDrawing(false);
        //清除背景色
        int color = view.getDrawingCacheBackgroundColor();
        view.setDrawingCacheBackgroundColor(0);
        if (color != 0) {
            view.destroyDrawingCache();
        }
        if (width > 0 && height > 0) {
            //测量并布局
            view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        }

        view.buildDrawingCache();
        Bitmap cacheBitmap = view.getDrawingCache();
        if (cacheBitmap == null) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap(cacheBitmap);
        view.destroyDrawingCache();
        view.setWillNotCacheDrawing(willNotCache);
        view.setDrawingCacheBackgroundColor(color);
        return bitmap;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_share_to_wechat:
                shareToWeChat();

                break;
            case R.id.tv_share_to_circle:
                shareToWeChatCircle();
                break;
            case R.id.tv_share_to_qzone:
                shareToQQZone();
                break;
            case R.id.tv_share_to_weibo:
                shareToWeibo();

                break;
            case R.id.tv_share_to_qq:
                shareToQQ();
                break;
        }
    }

    private void shareToWeChatCircle() {
        Intent intent = new Intent(this, AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_CIRCLE_SHARE);
        bundle = AuthShareHelper.buildWechatShareParams(share.getTitle(), share.getContent(),
                share.getUrl(), share.getFilename());
        intent.putExtra(AuthShareHelper.KEY_WECHAT_SHARE_BUNDLE, bundle);
        intent.putExtra(ShareManager.SHARE_TYPE, share.getContentType());//传内容类型,分辨内容
        intent.putExtra(ShareManager.MUSIC_URL, share.getMusicUrl());//音乐url
        intent.putExtra(ShareManager.IF_HAVE_LOGO, share.isPicAddLogo());//是否加上fitmix图片修饰
        startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_CIRCLE_SHARE);

    }

    private void shareToWeChat() {
        Intent intent = new Intent(this, AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_WECHAT_SHARE);
        bundle = AuthShareHelper.buildWechatShareParams(share.getTitle(), share.getContent(),
                share.getUrl(), share.getFilename());
        intent.putExtra(AuthShareHelper.KEY_WECHAT_SHARE_BUNDLE, bundle);
        intent.putExtra(ShareManager.SHARE_TYPE, share.getContentType());//传内容类型,分辨内容
        intent.putExtra(ShareManager.MUSIC_URL, share.getMusicUrl());//音乐url
        intent.putExtra(ShareManager.IF_HAVE_LOGO, share.isPicAddLogo());//是否加上fitmix图片修饰
        startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_WECHAT_SHARE);
    }

    private void shareToQQ() {
        Intent intent = new Intent(this, AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_QQ_SHARE);
        bundle = AuthShareHelper.buildQQSharePicParams(true, share.getFilename(), "乐享动");
        intent.putExtra(AuthShareHelper.KEY_QQ_SHARE_BUNDLE, bundle);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_SHARE);
    }

    private void shareToWeibo() {
        Intent intent = new Intent(this, AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_SINA_SHARE);
        intent.putExtra(ShareManager.SHARE_TYPE, share.getContentType());//传内容类型,分辨内容
        bundle = AuthShareHelper.buildWeiboShareParams(share.getTitle(), share.getContent(), share.getUrl(),
                share.getFilename());
        intent.putExtra(AuthShareHelper.KEY_SINA_SHARE_BUNDLE, bundle);
        startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_SINA_SHARE);
    }

    private void shareToQQZone() {

        Intent intent = new Intent(this, AuthShareHelper.class);
        Bundle bundle;
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE,
                AuthShareHelper.REQUESTCODE_QZONE_SHARE);
        bundle = AuthShareHelper.buildQQSharePicParams(false, share.getFilename(), "乐享动");
        intent.putExtra(AuthShareHelper.KEY_QQ_SHARE_BUNDLE, bundle);
        startActivityForResult(intent,
                AuthShareHelper.REQUESTCODE_QZONE_SHARE);
    }


    @Override
    protected void dataUpdateNotify(int requestId) {

    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {

    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
