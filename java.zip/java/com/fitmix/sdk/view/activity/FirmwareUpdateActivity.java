package com.fitmix.sdk.view.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.model.api.bean.HRFirmwareUpdateVersionBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.DfuService;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.HeadsetFirmUpdateProgressBar;

import java.util.List;

import no.nordicsemi.android.dfu.DfuProgressListener;
import no.nordicsemi.android.dfu.DfuProgressListenerAdapter;
import no.nordicsemi.android.dfu.DfuServiceInitiator;
import no.nordicsemi.android.dfu.DfuServiceListenerHelper;

/**
 * 心率耳机固件升级界面
 */
public class FirmwareUpdateActivity extends BaseActivity {

    private ServiceConnection serviceConnection;//心率服务连接
    private ServiceConnection downloadServiceConnection;//download服务连接
    private HeartRateService heartRateService;//心率服务
    private DownloadInfoListener downloadListener;
    private DownloadService mService;

    private HeadsetFirmUpdateProgressBar updateArc;
    private String lastHrFirmwareVersion;
    private View no_update_view, have_update_view, is_update_view;
    private TextView headset_update_content_item1,
            update_progress_number_tv, update_result_note_tv;
    private String newVersionUrl;

    private int progress = 0;//下载完成时为总进度的50%,dfu传输完成时为100%
    private String name;
    private String deviceName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPageName("FirmwareUpdateActivity");
        setContentView(R.layout.activity_firmware_update);
        initToolbar();
        initViews();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            connectToHeartRateService();
            DfuServiceListenerHelper.registerProgressListener(this, mDfuProgressListener);
        }
        bindDownloadService();
    }


    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);

        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService != null) {
                    heartRateService.setIfBindWithRunMain(false);
                    heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);
                    if (heartRateService.getDevice() != null) {
                        deviceName = heartRateService.getDevice().getName();
                        showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (heartRateService != null) {//释放服务运用到的相关资源
                heartRateService.removeHeartRateItem(mPageName);
            }
        }
        if (serviceConnection != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(serviceConnection);
            }
        }
        serviceConnection = null;
    }


    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        updateArc = (HeadsetFirmUpdateProgressBar) findViewById(R.id.update_arc_circle);
        no_update_view = findViewById(R.id.no_update_view);
        have_update_view = findViewById(R.id.update_version_content_view);
        is_update_view = findViewById(R.id.update_progress_view);
        headset_update_content_item1 = (TextView) findViewById(R.id.headset_update_content_item1);
        update_progress_number_tv = (TextView) findViewById(R.id.update_progress_number_tv);
        update_result_note_tv = (TextView) findViewById(R.id.update_result_note_tv);

        lastHrFirmwareVersion = SettingsHelper.getString(Config.SETTING_HR_FIRMWARE_VERSION_CODE, "");

        downloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                Logger.d(Logger.DEBUG_TAG, "已经下载  " + downloadInfo.getLocalPath() + " " + downloadInfo.getCurrentSize());
                progress = (int) ((downloadInfo.getCurrentSize() * 1.0f / downloadInfo.getTotalSize()) * 50);
                update_progress_number_tv.setText(progress + "%");
                updateArc.setProgress(progress);

            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {

            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                //       update_result_note_tv.setText("下载完成，请等待发送固件到设备");
                update_result_note_tv.setText(getResources().getString(R.string.item_updating));
                update_progress_number_tv.setText("50%");
                Logger.d(Logger.DEBUG_TAG, "zipFilePath:" + Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name);
                final DfuServiceInitiator starter = new DfuServiceInitiator(
                        PrefsHelper.with(FirmwareUpdateActivity.this, Config.PREFS_USER).read(Config.SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS, ""));
                starter.setDeviceName(deviceName)
                        .setZip(Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name)
                        .setDisableNotification(true)
                        .start(FirmwareUpdateActivity.this, DfuService.class);
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                Logger.e(Logger.DEBUG_TAG, "errormsg:" + errorMsg);
                if (!TextUtils.isEmpty(newVersionUrl)) {
                    if (mService != null) {
                        mService.cancelDownload(newVersionUrl);
                    }
                    try {
                        int index = newVersionUrl.lastIndexOf("/");
                        if (index != -1) {
                            String name = newVersionUrl.substring(index, newVersionUrl.length());
                            if (!TextUtils.isEmpty(name)) {
                                String tmpPath = Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name + ".tmp";
                                FileUtils.deleteFile(tmpPath);//删除下载的临时文件
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                Logger.e(Logger.DEBUG_TAG, "onExist:" + downloadInfo.getLocalPath());

                //  update_result_note_tv.setText("下载完成，请等待发送固件到设备");
                update_result_note_tv.setText(getResources().getString(R.string.item_updating));
                update_progress_number_tv.setText("0%");
                updateArc.setProgress(0);

                Logger.d(Logger.DEBUG_TAG, "zipFilePath:" + Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name);
                final DfuServiceInitiator starter = new DfuServiceInitiator(
                        PrefsHelper.with(FirmwareUpdateActivity.this, Config.PREFS_USER).read(Config.SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS, ""));
                starter.setDeviceName(deviceName)
                        .setZip(Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name)
                        .setDisableNotification(true)
                        .start(FirmwareUpdateActivity.this, DfuService.class);

            }
        };

        checkHRFirmwareNewVersion();
    }

    /**
     * 检查心率耳机固件版本
     */
    private void checkHRFirmwareNewVersion() {
        Logger.d(Logger.DEBUG_TAG, "version:" + lastHrFirmwareVersion);
        //不考虑缓存
        int requestId = UserDataManager.getInstance().checkHRFirmwareVersion(lastHrFirmwareVersion, true);
        // int requestId = UserDataManager.getInstance().checkHRFirmwareVersion(String.valueOf(107), true);
        registerDataReqStatusListener(requestId);
        showAppMessage(R.string.activity_about_us_check_version, AppMsg.STYLE_INFO);
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.headset_update_new_version_btn:
                if (TextUtils.isEmpty(newVersionUrl))
                    return;
                no_update_view.setVisibility(View.GONE);
                have_update_view.setVisibility(View.GONE);
                is_update_view.setVisibility(View.VISIBLE);

                int index = newVersionUrl.lastIndexOf("/");
                if (index != -1) {
                    name = newVersionUrl.substring(index + 1, newVersionUrl.length());
                    Logger.d(Logger.DEBUG_TAG, "zipName:" + name);
                    DownloadService.makeDownload(this, newVersionUrl, Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name, DownloadType.TYPE_FILE);
                }
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.d(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 28://检查固件新版本
                HRFirmwareUpdateVersionBean hrFirmwareBean = JsonHelper.getObject(result, HRFirmwareUpdateVersionBean.class);
                if (hrFirmwareBean != null) {
                    newVersionUrl = hrFirmwareBean.getUrl();
                    if (TextUtils.isEmpty(newVersionUrl)) {
                        no_update_view.setVisibility(View.VISIBLE);
                        have_update_view.setVisibility(View.GONE);
                        is_update_view.setVisibility(View.GONE);
                    } else {
                        no_update_view.setVisibility(View.VISIBLE);
                        have_update_view.setVisibility(View.VISIBLE);
                        is_update_view.setVisibility(View.GONE);
                        headset_update_content_item1.setText(getString(R.string.activity_firmware_update_desc) + hrFirmwareBean.getDes());
                    }

                }

                break;
        }
    }

    @Override
    protected void getDataReqStatusAsync(int requestId) {
        super.getDataReqStatusAsync(requestId);
    }


    /**
     * 心率服务回调
     */
    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {

        }

        @Override
        public void onDeviceConnected() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {//数据通道连接成功
                    Logger.i("TT", "FirmwareUpdateActivity HeartRateServiceFunction 数据通道连接成功");
                }
            });

            startHeartRateService();
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.i(Logger.DEBUG_TAG, "FirmwareUpdateActivity,onDeviceDisconnected()");
            //连接断开：
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showAppMessage(R.string.activity_pair_heart_rate_disconnected, AppMsg.STYLE_ALERT);

                }
            });
            stopHeartRateService();
        }

        @Override
        public void onError() {
        }

        @Override
        public void onHRValueReceived() {
            //不处理
        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, final int signalValue) {
            //不处理
        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {
            //不处理
        }

        @Override
        public void reDrawHeartRateData() {
            //不处理
        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                              int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                              boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {
            //不处理
        }

    };

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity --->  startHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        startService(i);
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity --->  stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }


    /**
     * The progress listener receives events from the DFU Service.
     * If is registered in onCreate() and unregistered in onDestroy() so methods here may also be called
     * when the screen is locked or the app went to the background. This is because the UI needs to have the
     * correct information after user comes back to the activity and this information can't be read from the service
     * as it might have been killed already (DFU completed or finished with error).
     */
    private final DfuProgressListener mDfuProgressListener = new DfuProgressListenerAdapter() {
        @Override
        public void onDeviceConnecting(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onDeviceConnecting" + "Connecting…");


        }

        @Override
        public void onDfuProcessStarting(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onDfuProcessStarting" + "Starting DFU…");
            // update_result_note_tv.setText(getString(R.string.is_deliver_firmware_to_device));
            update_result_note_tv.setText(getResources().getString(R.string.item_updating));
            showAppMessage(R.string.is_deliver_firmware_to_device, AppMsg.STYLE_INFO);

        }

        @Override
        public void onEnablingDfuMode(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onEnablingDfuMode" + "Starting bootloader…");

        }

        @Override
        public void onFirmwareValidating(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onFirmwareValidating" + "Validating…");

        }

        @Override
        public void onDeviceDisconnecting(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onDeviceDisconnecting" + "Disconnecting…");

        }

        @Override
        public void onDfuCompleted(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onDfuCompleted" + "Done");
            showAppMessage(R.string.hr_firmware_update_success_note, AppMsg.STYLE_INFO);
            update_result_note_tv.setText(getString(R.string.hr_firmware_update_success_note));
        }

        @Override
        public void onDfuAborted(final String deviceAddress) {
            Logger.d(Logger.DEBUG_TAG, "onDfuAborted" + "Aborted");
        }

        @Override
        public void onProgressChanged(final String deviceAddress, final int percent, final float speed, final float avgSpeed, final int currentPart, final int partsTotal) {
            Logger.d(Logger.DEBUG_TAG, "onProgressChanged" + "percent:" + percent);
            // update_result_note_tv.setText(getString(R.string.is_deliver_firmware_to_device));
            update_result_note_tv.setText(getResources().getString(R.string.item_updating));
            update_progress_number_tv.setText((percent / 2 + 50) + "%");
            updateArc.setProgress(50 + percent / 2);
        }

        @Override
        public void onError(final String deviceAddress, final int error, final int errorType, final String message) {
            showAppMessage(R.string.hr_firmware_update_fail_note, AppMsg.STYLE_ALERT);
            update_result_note_tv.setText(getString(R.string.hr_firmware_update_fail_note));
            try {
                int index = newVersionUrl.lastIndexOf("/");
                if (index != -1) {
                    String name = newVersionUrl.substring(index, newVersionUrl.length());
                    if (!TextUtils.isEmpty(name)) {
                        String tmpPath = Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + name + ".tmp";
                        FileUtils.deleteFile(tmpPath);//删除下载的临时文件
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };


    /**
     * 绑定下载服务
     */
    private void bindDownloadService() {
        //创建 语音包文件
        FileUtils.makeDirs(Config.PATH_LOCAL_FIRMWARE_VERSION_FILE);
        Intent intent = new Intent(this, DownloadService.class);
        downloadServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onServiceConnected");
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mService = ((DownloadService.GetServiceClass) service).getService();
                    if (mService == null)
                        return;

                    if (downloadListener != null) {//注册下载状态监听
                        Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onServiceConnected addDownloadListener");
                        mService.addDownloadListener(downloadListener);
                    }

                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mService == null)
                        return;
                    if (downloadListener != null) {//注销下载状态监听
                        mService.removeDownloadListener(downloadListener);
                    }
                }
            }
        };
        bindService(intent, downloadServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectToHeartRateService();
        unbindDownloadService();
    }

    /**
     * 解绑下载服务
     */
    private void unbindDownloadService() {
        if (downloadServiceConnection != null) {
            unbindService(downloadServiceConnection);
        }
        downloadServiceConnection = null;
        downloadListener = null;
    }


}
