package com.fitmix.sdk.view.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.TopicList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.TopicAdapter;
import com.fitmix.sdk.view.widget.ClearEditText;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.util.List;

/**
 * 搜索话题界面
 */
public class SearchTopicActivity extends BaseActivity {

    private ClearEditText searchView;
    private ListView list_search;//搜索出的话题列表
    private SwipeLoadLayout swipeLayout;
    private TextView mTvCancel;

    private int pageNo;
    private String sSearch;
    private String lastSearchText;
    private TopicAdapter topicAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_topic);
        setPageName("SearchTopicActivity");
        initToolbar();
        initViews();
    }

    @Override
    protected void initViews() {
        searchView = (ClearEditText) findViewById(R.id.searchView);
        searchView.setClearButtonClickListener(new ClearEditText.OnClearButtonClickListener() {
            @Override
            public void onClearButtonClick() {
                restoreInterface();
            }
        });
        mTvCancel = (TextView) findViewById(R.id.cancel);

        searchView.setOnEditorActionListener(new TextView.OnEditorActionListener() {//软键盘的搜索键
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                doSearch();
                return false;
            }
        });
        searchView.addTextChangedListener(new TextWatcher() {//输入框内容监听
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //不处理
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //不处理
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s)) {
                    mTvCancel.setText(getString(R.string.cancel));//无内容为取消
                    searchView.setClearIconVisible(false);
                } else {
                    mTvCancel.setText(getString(R.string.activity_main_search));//有内容为搜索
                    searchView.setClearIconVisible(true);
                }
            }
        });
        mTvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(searchView.getText())) {//输入框无内容时取消返回上一个界面
                    finish();
                } else {
                    doSearch();//有内容发送搜索请求
                }

            }
        });

        list_search = (ListView) findViewById(R.id.swipe_target);
        topicAdapter = new TopicAdapter(this);
        list_search.setAdapter(topicAdapter);

        swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
//        swipeLayout.setVisibility(View.GONE);
        swipeLayout.setListViewEmptyText(getString(R.string.activity_search_topic_empty_hint), ContextCompat.getColor(this, R.color.fitmix_black));
        list_search.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        list_search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                goToTopicDetailActivity(position);
            }
        });
        swipeLayout.setOnLoadMoreListener(new SwipeLoadLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                sendListRequest();
            }
        });

    }

    /**
     * 跳转至话题详情界面
     */
    private void goToTopicDetailActivity(int position) {
        if (topicAdapter != null && topicAdapter.getTopicList() != null) {
            if (position >= 0 && position < topicAdapter.getTopicList().size()) {
                Topic topic = topicAdapter.getTopicList().get(position);
                if (topic != null) {
                    Intent intent = new Intent(this, TopicDetailActivity.class);
                    intent.putExtra("topicId", topic.getId());
                    MyConfig.getInstance().getMemExchange().setTopic(topic);
                    startActivity(intent);
                }
            }
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {

            case Config.MODULE_COMPETITION + 8://搜索话题返回的结果
                swipeLayout.setLoadingMore(false);//加载更多布局消失
//                //存储搜索历史记录
                TopicList topicList = JsonHelper.getObject(result, TopicList.class);
                if (topicList != null && topicList.getPage() != null) {
                    if (topicList.getPage().getFilter() != null) {
                        String searchText = topicList.getPage().getFilter().getSearchText();
                        if (searchText != null && !searchText.equals(lastSearchText)) {//新的搜索关键字
                            if (topicAdapter != null) {
                                topicAdapter.getTopicList().clear();
                                topicAdapter.notifyDataSetChanged();
                            }
                            lastSearchText = searchText;
                        }
                    }
                    List<Topic> list = topicList.getPage().getResult();
                    showTopicList(list, pageNo);
                    pageNo++;
                }
                break;
        }
    }

    public void showTopicList(List<Topic> list, int index) {
        if (list == null || list.size() < 1) {
            if (swipeLayout != null) {
                if (swipeLayout.isLoadingMore()) {
                    swipeLayout.setLoadingNothing();
                }

            }
            return;
        } else {
            if (swipeLayout != null) {
                swipeLayout.setLoadMoreEnabled(true);//当有数据的时候才可以上拉加载
                if (swipeLayout.isLoadingMore())
                    swipeLayout.setLoadingMore(false);
            }
        }
        if (index < 2) {
            if (topicAdapter != null)
                topicAdapter.setTopicList(list);
        } else {
            if (topicAdapter != null) {
                topicAdapter.getTopicList().addAll(list);
                topicAdapter.notifyDataSetChanged();
            }
        }

    }

    /**
     * 清空当前搜索框后执行回到第一个展示界面
     */
    public void restoreInterface() {
        //TODO
//        deleteUseLessSearchHistory();
//        getHistory_searched_adapter().setKeyWordList(SearchHistoryHelper.getInstance().getHistoryList());
//        emptyView.setVisibility(View.GONE);
//        swipeLayout.setVisibility(View.GONE);//搜索结果布局消失
//        ll_keyword_and_searched.setVisibility(View.VISIBLE);//热词和历史记录布局显示出现
//        if (SearchHistoryHelper.getInstance().getHistoryList().size() > 0) {
//            view_clear_all_history.setVisibility(View.VISIBLE);
//        } else {
//            view_clear_all_history.setVisibility(View.GONE);
//        }
    }

    private void doSearch() {
        //隐藏键盘
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchView.getWindowToken(), 0);
        pageNo = 0;
        sSearch = searchView.getText().toString();
        searchView.setSelection(searchView.getText().length());
        sendListRequest();
    }

    /**
     * 发送网络请求更新列表
     */
    private void sendListRequest() {
        if (UserDataManager.getUid() != -1) {
            int requestId = DiscoverDataManager.getInstance().searchTopic(sSearch, pageNo, true);
            registerDataReqStatusListener(requestId);
        }
    }

}
