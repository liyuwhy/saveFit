package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FastBlur;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.fresco.FrescoHelper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.MusicList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MusicInfo;
import com.fitmix.sdk.model.database.MusicInfoHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.MaterialViewPager;

import java.util.ArrayList;
import java.util.List;

public class PlayMusicActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener {
    private final int USER_LOGIN = 456;
    private SimpleDraweeView img_song_bg;
    private TextView tv_current_position;
    private TextView tv_duration;
    private SeekBar seekBar;
    private TextView tv_song_name;
    private TextView tv_song_author;
    private TextView tv_song_bpm;
    private TextView tv_song_description;
    //private TextView music_title;

    private CheckBox ckb_favorite;
    private CheckBox ckb_download;
    private CheckBox ckb_share;
    private Button btn_play_style;
    private LinearLayout ckb_container;
    private int currentId;//正在播放歌曲的id
    private MaterialViewPager viewPager;
    private boolean toggleByMan = true;//防止程序设置checkBox时回调

    private int index; //播放歌曲在列表中的位置
    //private String downloadingFile;
    private Music tempMusic;//用来处理收藏等操作的中间变量
    private CheckBox btn_play_state;//播放或暂停
    private boolean needToPlay = false;//需不需要手动播放
    private SeekBar.OnSeekBarChangeListener seekBarChangeListener;
//    private ViewPager.OnPageChangeListener pageChangeListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //透明导航栏
            //getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
        setContentView(R.layout.activity_play_music);
        setPageName("PlayMusicActivity");
        //android 6.0权限
        getPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);//下载音乐用到

        initToolbar();
        initViews();
        initData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (viewPager != null)
            viewPager.pauseAnimation();
    }

    @Override
    protected void onDestroy() {
        if (viewPager != null)
            viewPager.endAnimation();
        super.onDestroy();
    }

    @Override
    protected void clickToRun() {
        super.clickToRun();
        finish();//进入跑步界面后立即销毁该activity
    }

    //region =============================initView and initdata======================

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        showGoToPlayMusicMenu = false;
        img_song_bg = (SimpleDraweeView) findViewById(R.id.img_song_bg);
        Button btn_sport = (Button) findViewById(R.id.btn_sport);
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        switch (sportType) {
            case Config.SPORT_TYPE_RUN:
                if (btn_sport != null) {
                    btn_sport.setText(getString(R.string.activity_main_run));
                }
                break;
            case Config.SPORT_TYPE_SKIP:
                if (btn_sport != null) {
                    btn_sport.setText(getString(R.string.activity_main_skip));
                }
                break;
        }
        //music_title = (TextView) findViewById(R.id.music_title);
        viewPager = (MaterialViewPager) findViewById(R.id.music_cover_viewpager);
        //circleimg_song_cover = (SimpleDraweeView) viewPager.findViewById(R.id.img_song_cover);
        //gifView = (GifView) findViewById(R.id.gif);
        tv_current_position = (TextView) findViewById(R.id.tv_current_position);
        tv_duration = (TextView) findViewById(R.id.tv_duration);
        seekBar = (SeekBar) findViewById(R.id.seek);
        seekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //不处理
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //不处理
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                getMyConfig().getPlayer().seekToTime(getMyConfig().getPlayer().getDuration() * seekBar.getProgress() / 100);

                if (seekBar.getProgress() == 100) {
                    if (getMyConfig().getPlayer().getPlayMode() != PlayerController.MODE_REPEAT_ONE) {
                        getMyConfig().getPlayer().nextMusic();
                    } else {
                        getMyConfig().getPlayer().playMusic(getMusic(), true);
                    }
                }
                if (getMusic() == null) return;
                MusicDataManager.getInstance().uploadMusicAudition(getMusic().getId(), true);
                Music music = OperateMusicUtils.getMusicById(getMusic().getId());
                if (music != null) {
                    music.setAuditionCount(music.getAuditionCount() + 1);
                    OperateMusicUtils.insertMusic(music, Config.LIST_TYPE_SCENE);//把本地试听数量加一
                }
            }
        };
        seekBar.setOnSeekBarChangeListener(seekBarChangeListener);
        tv_song_name = (TextView) findViewById(R.id.tv_song_name);
        tv_song_author = (TextView) findViewById(R.id.tv_song_author);
        tv_song_bpm = (TextView) findViewById(R.id.tv_song_bpm);
        tv_song_description = (TextView) findViewById(R.id.tv_song_description);

        ckb_container = (LinearLayout) findViewById(R.id.ckb_container);
        ckb_favorite = (CheckBox) findViewById(R.id.ckb_favorite);
        ckb_download = (CheckBox) findViewById(R.id.ckb_download);
        ckb_share = (CheckBox) findViewById(R.id.ckb_share);

        ckb_favorite.setOnCheckedChangeListener(this);
        ckb_download.setOnCheckedChangeListener(this);
        ckb_share.setOnCheckedChangeListener(this);

        btn_play_state = (CheckBox) findViewById(R.id.btn_play_state);
        btn_play_style = (Button) findViewById(R.id.btn_play_style);
        btn_play_state.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPlayState();
            }
        });
    }


    /**
     * 初始化界面数据
     */
    private void initData() {
        if (getIntent() != null) {
            if (getIntent().getBooleanExtra("isFromXinGe", false)) {//从信鸽推送消息点击进来
                ArrayList<Integer> list = new ArrayList<>();
                list.add(getIntent().getIntExtra("musicId", 0));
                int requestId = MusicDataManager.getInstance().getMusicListInfo(list, true);
                registerDataReqStatusListener(requestId);
            } else {
                setPlayMusicList();
                viewPager.init(getMusicList());
            }
        } else {
            setPlayMusicList();
            viewPager.init(getMusicList());
        }

        viewPager.addOnViewPagerStateListener(new MaterialViewPager.OnViewPagerStateListener() {

            @Override
            public void onPageSelected(int dataSize, int position) {
                Logger.i(Logger.DEBUG_TAG, "PlayingMusicActivity--->onPageSelected() position:" + position);

                if (!FitmixUtil.checkNetworkStateForMusic(getMusic()) && getMusic().getLocalFlag() == 0) {
                    showAppMessage(R.string.check_network, AppMsg.STYLE_ALERT);
                }

                position = position - 1;
                if (getMusicList() == null) return;
                if (position % getMusicList().size() == getMusicList().indexOf(getMusic())) {
                    return;
                }
                seekBar.setProgress(0);
                seekBar.setSecondaryProgress(0);
                getMyConfig().getPlayer().playListByIndex(position, true);
                needToPlay = false;
                refresh();
            }
        });

    }

    private void setPlayMusicList() {
        index = getIntent().getIntExtra("index", -1);
        if (index < 0) {//歌曲为空时应该 设置有一个默认值
            if (getMusic() == null) {//当前播放歌曲为空
                List<Music> musicList = new ArrayList<>();
                musicList.addAll(OperateMusicUtils.getMusicPlayingList());
                index = OperateMusicUtils.getIndexInPlayingList();
                if (musicList != null && musicList.size() > 0 && index > -1) {
                    getMyConfig().getPlayer().setPlayList(musicList);
                    if (index < musicList.size()) {
                        Music music = musicList.get(index);
                        if (music != null) {
                            OperateMusicUtils.setPlayingMusic(music);
                            PlayerController.getInstance().setCurrentMusic(music);
                            // showPlayMessage();
                            needToPlay = true;
                        }
                    }
                } else {
                    //播放美好的一天
                    Music music = OperateMusicUtils.getMusicById(46);
                    if (music != null) {
                        List<Music> list = new ArrayList<>();
                        list.add(music);
                        index = 0;
                        getMyConfig().getPlayer().setPlayList(list);
                        OperateMusicUtils.setPlayingMusic(music);
                        PlayerController.getInstance().setCurrentMusic(music);
                        showPlayMessage();
                    }
                }
            }
        } else {
            /** 解决
             * java.lang.IndexOutOfBoundsException: Invalid index 7, size is 0
             * at java.util.ArrayList.throwIndexOutOfBoundsException(ArrayList.java:255)
             * */
            if (getMusicList() != null) {
                if (index < getMusicList().size()) {
                    if (getMusic() == null || getMusic().getId() != getMusicList().get(index).getId()) {
                        PlayerController.getInstance().setCurrentMusic(getMusicList().get(index));
                        showPlayMessage();
                    }
                    if (getMusic() != null && getMusic().getId() == getMusicList().get(index).getId()) {//重新点击了当前播放的歌曲
                        PlayerController.getInstance().setCurrentMusic(getMusicList().get(index));
                    }
                }
            }
        }
    }

//    private long lastSong;

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();

        switch (requestId) {
            case Config.MODULE_MUSIC + 3://获取音乐列表
                break;

            case Config.MODULE_MUSIC + 4://收藏音乐
                favoriteSwitchInLocale(tempMusic);
                break;
            case Config.MODULE_MUSIC + 12://获取歌曲列表
                MusicList musicList = JsonHelper.getObject(result, MusicList.class);
                if (musicList != null) {
                    List<Music> musics = musicList.getMixList();
                    getMyConfig().getPlayer().setPlayList(musics);
                    setPlayMusicList();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            viewPager.init(getMusicList());
                        }
                    });

                }
                break;

            case Config.MODULE_USER + 59://完成每日分享音乐金币任务
            case Config.MODULE_USER + 62://完成每日播放音乐金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            if (requestId == Config.MODULE_USER + 59) {//分享音乐
                                SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_MIX, System.currentTimeMillis());//设置完成任务时间
                            } else if (requestId == Config.MODULE_USER + 62) {//播放音乐
                                SettingsHelper.putLong(Config.SETTING_COIN_TASK_PLAY_MIX, System.currentTimeMillis());//设置完成任务时间
                            }

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        switch (requestId) {
            case Config.MODULE_MUSIC + 4:
                super.processReqError(requestId, error);
                ckb_favorite.setEnabled(true);
                refreshMusicNumber();
                break;

            case Config.MODULE_USER + 62://播放音乐{"code":9002,"msg":"该任务已完成"}
                if (bean != null) {
                    if (bean.getCode() == 9002) {//该任务已完成
                        SettingsHelper.putLong(Config.SETTING_COIN_TASK_PLAY_MIX, System.currentTimeMillis());//设置完成任务时间
                    }
                }
                break;
        }

    }

    /**
     * 显示播放音乐的信息提示
     */
    private void showPlayMessage() {
        if (getMusic() == null) return;
        if (getMusic().getLocalFlag() == 1) { //本地音乐
            startPlayMusic();
            return;
        }
        if (OperateMusicUtils.checkMusicExist(getMusic(), Config.LIST_TYPE_DOWNLOADED)) {//判断是否有下载完成状态的音频文件存在
            startPlayMusic();
            return;
        }
        if (MixApp.getProxy(this) != null && MixApp.getProxy(this).isCached(getMusic().getUrl())) {//是否有完整的缓存文件存在
            startPlayMusic();
            return;
        }
//        String sLocalFile = getFitmixUtil().getLocalFilePath(getMusic().getUrl(),
//                getMusic().getId(), Config.DOWNLOAD_FORMAT_MUSIC);
        String tempFile = FitmixUtil.getTempMusicPath(getMusic());

        if (FitmixUtil.checkMusicDownloadParamValid(tempFile, true)
                && !FitmixUtil.checkNetworkStateForMusic(getMusic()) && getMusic().getLocalFlag() == 0) {//因为只有在没有网络并且临时文件可播放的情况下才播临时文件
            showAppMessage(R.string.activity_play_music_play_downloading_music, AppMsg.STYLE_CONFIRM);
        } else {
            if (!FitmixUtil.checkNetworkStateForMusic(getMusic()) && getMusic().getLocalFlag() == 0) {
                startPlayMusic();
                showAppMessage(R.string.check_network, AppMsg.STYLE_ALERT);
                return;
            } else if (ApiUtils.getNetworkType() != Config.NETWORK_TYPE_WIFI) {
                new MaterialDialog.Builder(this)
                        .title(R.string.warning)
                        .content(R.string.downstream_control)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE://开始在线播放
                                        startPlayMusic();
                                        break;

                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
                return;
            }
        }
        startPlayMusic();
    }
    //endregion =============================initView and initdata======================

    //region =============================refresh======================

    @Override
    protected void onStop() {
        super.onStop();
        stopAnimation();
    }

    /**
     * 切换歌曲时刷新页面
     */
    @Override
    public void onMusicChanged() {
        super.onMusicChanged();
        refresh();
    }

    @Override
    public void onMusicPrepared() {
        super.onMusicPrepared();
        if (tv_duration != null) {
            tv_duration.setText(FormatUtil.formatMusicTime(getMyConfig().getPlayer().getDuration() / 1000));
        }
    }

    @Override
    public void onMusicBufferingUpdate() {
        seekBar.setSecondaryProgress(getMyConfig().getPlayer().getPlayerService() != null ? getMyConfig().getPlayer().getPlayerService().getBufferingPercent() : 0);
    }

    /**
     * 歌曲播放状态切换时
     */
    @Override
    public void onMusicPlayStateChanged() {
        super.onMusicPlayStateChanged();
        startUpdateProgress();
        //startRotateAnimation();
        //updateRotateAnimation();
        if (viewPager != null)
            viewPager.setRotationAnimationState();
        setPlayState();
        setMusicPlayStatus(getMyConfig().getPlayer().getIsActionPlay());

        finishPlayMixCoinTask();//完成每日播放歌曲金币任务
    }

    /**
     * 把动画任务关掉
     */
    private void stopAnimation() {
        if (seekBar != null)
            seekBar.removeCallbacks(mUpdateProgress);
    }

    /**
     * 开启进度条更新任务
     */
    private void startUpdateProgress() {
        if (seekBar != null) {
            seekBar.removeCallbacks(mUpdateProgress);
            seekBar.post(mUpdateProgress);
        }
        if (getMyConfig().getPlayer().getPlayerService() != null &&
                getMyConfig().getPlayer().getPlayerService().getUrlType() == PlayerController.URL_TYPE_LOCAL) {//如果加载的是本地文件时，设置预加载进度为100
            seekBar.setSecondaryProgress(100);
        }
    }

    private void refresh() {
        startUpdateProgress();
        setPlayState();
        switchPlayModeState(false);
        if (viewPager != null)
            viewPager.setRotationAnimationState();
        if (getMusic() == null) {
            btn_play_state.setEnabled(false);
            return;
        } else {
            btn_play_state.setEnabled(true);
        }
        if (getMusic().getId() != currentId) {//用于判定是否是当前播放的歌曲 如果是就略过
            currentId = getMusic().getId();//不是 重新给标志赋值
            int index = getMusicList().indexOf(getMusic());
            if (index >= 0 && index < getMusicList().size()) {
                //此时的index是歌曲在真实列表的中的位置 index+1 是为了与adapter中保持一致 因为在列表首尾各加了一条数据
                if (viewPager != null)
                    viewPager.setCurrentItem(index + 1, false);//在歌曲列表中选择到当前播放的歌曲
            }
            refreshJustOne();
            setPlayBackground(false);//模糊处理背景图
//            if (!TextUtils.isEmpty(getMusic().getAlbumUrl_2()) && getMusic().getAlbumUrl_2().endsWith(".gif") && !gifImageIsDownLoad(getMusic())) {
//                downloadAlbumLogo(getMusic().getId(), getMusic().getAlbumUrl_2());
//            }
        }
    }

    /**
     * 设置播放页面的背景
     *
     * @param loopCall 是否为循环调用setPlayBackground
     */
    private void setPlayBackground(boolean loopCall) {
        if (getMusic() == null) {
            return;
        }
        //1.判断是否存在模糊化的图片,有则设置
        final String localBlurFile = FitmixUtil.getPicturePath() + getMusic().getId() + "_blur.jpg";
        if (FileUtils.isFileExist(localBlurFile)) {
            Uri uri = Uri.parse(localBlurFile);
            Bitmap bmp = BitmapFactory.decodeFile(uri.toString());
            setPlayBackgroundBlur(bmp);
            return;
        }

        //2.模糊化图片不存在,但存在原图片,异步线程生成模糊图片,并保存到文件用于下次使用
        final String localFile = FitmixUtil.getPicturePath() + getMusic().getId() + ".jpg";
        if (FileUtils.isFileExist(localFile)) {
            if (img_song_bg != null) {
                ThreadManager.executeOnSubThread2(new Runnable() {//异步线程处理
                    @Override
                    public void run() {
                        final BitmapFactory.Options options = new BitmapFactory.Options();
                        Bitmap blur;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                            Uri uri = Uri.parse(localFile);
                            Bitmap bmp = BitmapFactory.decodeFile(uri.toString());
                            blur = FastBlur.blur(PlayMusicActivity.this, bmp);
                        } else {
                            options.inSampleSize = 16;//提前缩小
                            options.inPreferredConfig = Bitmap.Config.RGB_565;
                            Uri uri = Uri.parse(localFile);
                            Bitmap bmp = BitmapFactory.decodeFile(uri.toString(), options);
                            blur = newBlur(bmp, img_song_bg);
                        }

                        setPlayBackgroundBlur(blur);
                        ImageHelper.saveBitmap2File(blur, localBlurFile);
                    }
                });
            }
            return;
        }

        //3.本地原图片和模糊化的图片都不存在,则设置默认的模糊背景,从Fresco缓存中获取图片,保存在本地
        if (loopCall)
            return;
//        FrescoHelper.saveImage2Local(MixApp.getContext(), getMusic().getAlbumUrl(), localFile);
        FrescoHelper.saveImage2Local(MixApp.getContext(), getMusic().getAlbumUrl(), localFile, new FrescoHelper.BitmapSaveCallback() {
            @Override
            public void afterBitmapSave(String url) {//图片下载完成
                if (url != null && getMusic() != null && url.equals(getMusic().getAlbumUrl())) {
                    setPlayBackground(true);//更新播放页面的背景
                }
            }
        });
    }

    /**
     * 设置模糊化的背景
     */
    private void setPlayBackgroundBlur(final Bitmap bitmap) {
        //在非ui线程,view.post有潜在的内存泄漏
        ThreadManager.getMainHandler().post(new Runnable() {
            @Override
            public void run() {
                if (img_song_bg != null) {
                    img_song_bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    if (bitmap != null) {
                        img_song_bg.setImageBitmap(bitmap);
                    } else {
                        img_song_bg.setImageDrawable(getResources().getDrawable(R.drawable.activity_play_music_gif_bg));
                    }
                }
            }
        });
    }


    /**
     * bitmap 模糊化处理
     */
    @SuppressLint("NewApi")
    private Bitmap newBlur(Bitmap bkg, SimpleDraweeView view) {
        float scaleFactor = 20;//图片缩放比例；
        int radius = 15;//模糊程度
        Bitmap bitmap = null;
        try {
            bkg = zoomBitmap(bkg);
            if (bkg == null) return null;
            Bitmap overlay = Bitmap.createBitmap(
                    (int) (getX() / scaleFactor),
                    (int) (getY() / scaleFactor),
                    Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(overlay);
            canvas.translate(-view.getLeft() / scaleFactor, -view.getTop() / scaleFactor);
            canvas.scale(1 / scaleFactor, 1 / scaleFactor);
            Paint paint = new Paint();
            paint.setFlags(Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(bkg, 0, 0, paint);
            bitmap = FastBlur.doBlur(overlay, radius, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    /**
     * @param target 需要处理的bitmap
     * @return 正确比例的bitmap
     */
    public Bitmap zoomBitmap(Bitmap target) {
        if (target == null) return null;
        int width = target.getWidth();
        int height = target.getHeight();
        Matrix matrix = new Matrix();
        float scaleWidth = getX() * 1.0f / width;
        float scaleHeight = getY() * 1.0f / height;
        if (scaleWidth <= 0 || scaleHeight <= 0) {
            return null;
        }
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap bitmap = Bitmap.createBitmap(target, 0, 0, width, height, matrix, true);
        target.recycle();
        return bitmap;

    }

    /**
     * @return 屏幕的宽度
     */
    private int getX() {
        Display screen = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        screen.getSize(size);
        return size.x;

    }

    /**
     * @return 屏幕的高度
     */
    private int getY() {
        Display screen = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        screen.getSize(size);
        return size.y;
    }

    /**
     * 进度条更新
     */
    public Runnable mUpdateProgress = new Runnable() {
        @Override
        public void run() {
            tv_current_position.setText(FormatUtil.formatMusicTime(getMyConfig().getPlayer().getCurrentPosition() / 1000));//当前时间进度
            int duration = getMyConfig().getPlayer().getDuration();
            if (duration <= 0) {
                tv_duration.setText(getResources().getString(R.string.music_progress_loading));
            } else {
                tv_duration.setText(FormatUtil.formatMusicTime(duration / 1000));//当前时间进度
            }

            if (duration > 0) {
                seekBar.setProgress(100 * getMyConfig().getPlayer().getCurrentPosition() / duration);
            }
            if (getMyConfig().getPlayer().getIsActionPlay()) {
                seekBar.postDelayed(mUpdateProgress, 1000);
            }
        }
    };


    private void refreshJustOne() {//这些数据只刷新一次就可以了
        if (getMusic() == null) return;
        tv_song_name.setText(getMusic().getName());//歌曲名称
        tv_song_author.setText(getMusic().getAuthor());//歌手
        tv_song_bpm.setText(getMusic().getBpm());//歌曲BPM
        tv_song_description.setText(getMusic().getIntroduce());//歌曲描述
        //music_title.setText(getMusic().getName());
        refreshMusicNumber();
        setPlayState();
    }

    private void setPlayState() {//回显播放状态按钮
        if (!getMyConfig().getPlayer().getIsActionPlay()) {
            btn_play_state.setChecked(false);
            return;
        }
        btn_play_state.setChecked(true);
    }

    private void refreshMusicNumber() {//刷新歌曲的收藏,下载,分享-计数
        if (getMusic() == null) return;
        ckb_favorite.setText(String.format(getString(R.string.string_format), String.valueOf(getMusic().getCollectNumber())));//收藏
        ckb_download.setText(String.format(getString(R.string.string_format), String.valueOf(getMusic().getDownloadCount())));//下载
        ckb_share.setText(String.format(getString(R.string.string_format), String.valueOf(getMusic().getShareCount())));//分享
        toggleByMan = false;
        if (getMusic().getLocalFlag() != 1) {
            ckb_container.setVisibility(View.VISIBLE);
        } else {
            ckb_container.setVisibility(View.GONE);
        }
        ckb_favorite.setChecked(OperateMusicUtils.checkMusicExist(getMusic(), Config.LIST_TYPE_FAVORITE));
        ckb_download.setChecked(OperateMusicUtils.checkMusicExist(getMusic(), Config.LIST_TYPE_DOWNLOADED));
        toggleByMan = true;

        if (ckb_download.isChecked()) {
            ckb_download.setEnabled(false);
        }
    }

//    public void downloadAlbumLogo(int id, String uriJpg) {
//        if (uriJpg == null || uriJpg.isEmpty())
//            return;
//        if (!(uriJpg.endsWith(".gif") || uriJpg.endsWith(".GIF"))) return;
//        boolean bExist = FitmixUtil.isExistCacheFile(uriJpg, id,
//                Config.DOWNLOAD_FORMAT_PICTURE2);
//        if (bExist)
//            return;
//        String sLocalPath = getFitmixUtil().getLocalFilePath(uriJpg, id,
//                Config.DOWNLOAD_FORMAT_PICTURE2);
//        if (sLocalPath.equals(downloadingFile)) return;
//        downloadingFile = sLocalPath;
    //RequestManager.getInstance().downloadSmallFile(uriJpg, getWeakHandler(), sLocalPath);
//    }

    /**
     * gif图是否已下载
     *
     * @param music
     * @return
     */
    private boolean gifImageIsDownLoad(Music music) {
        return FitmixUtil.isExistCacheFile(
                music.getAlbumUrl_2(), music.getId(),
                Config.DOWNLOAD_FORMAT_PICTURE2);
    }

    //endregion =============================refresh======================

    //region =============================点击操作======================
    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_play_next:
                if (getMusic() == null) return;
                getMyConfig().getPlayer().nextMusic();
                if (seekBar != null) {
                    seekBar.setProgress(0);
                    seekBar.setSecondaryProgress(0);
                }
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "播放音乐界面音乐快进");
                break;
            case R.id.btn_play_back:
                if (getMusic() == null) return;
                getMyConfig().getPlayer().prevMusic();
                if (seekBar != null) {
                    seekBar.setProgress(0);
                    seekBar.setSecondaryProgress(0);
                }
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "播放音乐界面音乐快退");
                break;
            case R.id.btn_play_style:
                int currentPlayModel = SettingsHelper.getInt(Config.SETTING_PLAY_MODE, 1);
                SettingsHelper.putInt(Config.SETTING_PLAY_MODE, (currentPlayModel + 1) % 3);
                getMyConfig().getPlayer().setPlayMode(SettingsHelper.getInt(Config.SETTING_PLAY_MODE, 1));
                switchPlayModeState(true);
                break;
            case R.id.btn_sport:
//            case R.id.btn_run_another:
                gotoRunSetting();
                break;
        }
    }

    /**
     * 开始播放音乐
     */
    private void startPlayMusic() {
        if (getMusic() == null) return;
        playMusic();
    }

    /**
     * 播放歌曲
     */
    private void playMusic() {
        int playMode = SettingsHelper.getInt(Config.SETTING_PLAY_MODE, 1);
        getMyConfig().getPlayer().setPlayMode(playMode);
        getMyConfig().getPlayer().playListByIndex(index, true);
        needToPlay = false;
    }

    /**
     * 切换播放状态
     */
    private void switchPlayState() {
        if (getMusic() == null) return;
        if (needToPlay) {
            showPlayMessage();
        } else {
            Music info = getMyConfig().getPlayer().getCurrentMusic();
            if ((info == null) || info.getId() != getMusic().getId()) {
                showPlayMessage();
            } else {
                if (getMyConfig().getPlayer().getPlayerService().isAudioPrepared()) {
                    if (getMyConfig().getPlayer().getIsActionPlay()) {
                        getMyConfig().getPlayer().pauseMusic();
                        if (info != null) {
                            UmengAnalysisHelper.getInstance().musicReportPlus(PlayMusicActivity.this, "播放音乐界面音乐暂停", info.getId());
                        }
                    } else {
                        getMyConfig().getPlayer().resumeMusic();
                        if (info != null) {
                            UmengAnalysisHelper.getInstance().musicReportPlus(PlayMusicActivity.this, "播放音乐界面音乐继续", info.getId());
                        }
                    }
                } else {
                    if (getMyConfig().getPlayer().getIsActionPlay()) {
                        getMyConfig().getPlayer().setIsActionPlay(false);

                    } else {
                        getMyConfig().getPlayer().setIsActionPlay(true);
                    }
                    //在音频资源未加载成功前，点击播放或者暂停，则改变是否是否自动播放
                    getMyConfig().getPlayer().getPlayerService().changeBEnableAutoPlay();
                }
            }
        }
    }

    /**
     * 切换播放状态
     *
     * @param showMsg 是否提示,true:是,false:否
     */
    private void switchPlayModeState(boolean showMsg) {
        switch (SettingsHelper.getInt(Config.SETTING_PLAY_MODE, 1)) {
            case PlayerController.MODE_REPEAT_ONE:
                btn_play_style.setBackgroundResource(R.drawable.activity_play_song_only_selector);
                if (showMsg) {
                    showAppMessage(R.string.activity_play_music_mode_repeat_one, AppMsg.STYLE_INFO);
                }
                break;
            case PlayerController.MODE_REPEAT_ALL:
                btn_play_style.setBackgroundResource(R.drawable.activity_play_song_list_selector);
                if (showMsg) {
                    showAppMessage(R.string.activity_play_music_mode_repeat_all, AppMsg.STYLE_INFO);
                }
                break;
            case PlayerController.MODE_RANDOM:
                btn_play_style.setBackgroundResource(R.drawable.activity_play_song_random_selector);
                if (showMsg) {
                    showAppMessage(R.string.activity_play_music_mode_random, AppMsg.STYLE_INFO);
                }
                break;
        }
    }

    /**
     * 切换到下载列表
     */
    private void gotoDownloadList() {

    }

    /**
     * 切换到登录
     */
    private void startLoginActivity() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.setClass(PlayMusicActivity.this, LoginActivity.class);
        startActivityForResult(intent, USER_LOGIN);
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (toggleByMan) {
            switch (buttonView.getId()) {
                case R.id.ckb_favorite://收藏
                    favoriteSwitchMusic(getMusic());
                    break;

                case R.id.ckb_download://下载
                    downloadMusic();
                    break;

                case R.id.ckb_share://分享
                    ShareUtils.getInstance().shareMusic(this, getMusic());
                    break;
            }
        }
    }

    /**
     * 跳转到主跑界面
     */
    private void gotoRunSetting() {
        if (getMusic() == null) return;
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        Intent intent = new Intent();
        switch (sportType) {
            case Config.SPORT_TYPE_RUN:
                intent.setClass(PlayMusicActivity.this, RunSettingActivity.class);
                break;
            case Config.SPORT_TYPE_SKIP:
                intent.setClass(PlayMusicActivity.this, SkipSettingActivity.class);
                break;
        }
        Bundle bundle = new Bundle();
        if (getMusic() != null) {
            String musicString = JsonHelper.createJsonString(getMusic());
            bundle.putString("musicInfo", musicString);
        }
        intent.putExtras(bundle);
        startActivity(intent);
        finish();
    }
    //endregion =============================点击操作======================

    //region =============================keyDown and keyUp======================
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT:
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                bResult = true;
                break;
        }
        if (!bResult) return super.onKeyDown(keyCode, event);
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
//        if (getMyConfig().isLogOut())
//            Log.d(getMyConfig().getTag(), "onKeyUp:" + keyCode);
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                getMyConfig().getPlayer().playNextSong();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                getMyConfig().getPlayer().playPrevSong();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                getMyConfig().getPlayer().pauseMusic();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                getMyConfig().getPlayer().resumeMusic();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK:
                if (getMyConfig().getPlayer().getIsActionPlay())
                    getMyConfig().getPlayer().pauseMusic();
                else getMyConfig().getPlayer().resumeMusic();

                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                bResult = true;
                break;
        }
        if (!bResult) return super.onKeyUp(keyCode, event);
        return true;
    }

    //endregion =============================keyDown and keyUp======================

    //region =============================获取歌曲封面适配器 和 其他数据======================

    /**
     * 获取当前播放音乐,注意null值处理
     */
    private Music getMusic() {
        return getMyConfig().getPlayer().getCurrentMusic();
    }

//    private MusicCoverAdapter getMusicCoverAdapter() {
//        return new MusicCoverAdapter(getBaseContext(), getMyConfig().getPlayer().getPlayList());
//    }

    private List<Music> getMusicList() {
        return getMyConfig().getPlayer().getPlayList();
    }
    //endregion =============================获取歌曲封面适配器 和 其他数据======================

    //region =============================歌曲分享 下载 收藏======================

    /**
     * 收藏歌曲或者取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchMusic(Music music) {
        if (music == null) return;
        ckb_favorite.setEnabled(false);
        favoriteSwitchInNet(music);
    }

    /**
     * 在服务器收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInNet(Music music) {
        tempMusic = music;
        boolean bFavorited = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);

        int requestId = MusicDataManager.getInstance().favoriteMusicChange(UserDataManager.getUid(), music.getId(), false);
        registerDataReqStatusListener(requestId);

        showAppMessage(
                bFavorited ? R.string.activity_main_unfavoriting : R.string.activity_main_favoriting, AppMsg.STYLE_INFO);
        if (!bFavorited) {
            UmengAnalysisHelper.getInstance().musicReportPlus(this, "音乐收藏", music.getId());
        }
    }

    /**
     * 在本地收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInLocale(Music music) {
        OperateMusicUtils.favoriteSwitchInLocale(music);
        boolean bFavorited = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);

        int iCollect = music.getCollectNumber();
        if (bFavorited) {
            iCollect++;
        } else {
            iCollect--;
            if (iCollect < 0)
                iCollect = 0;
        }
        music.setCollectNumber(iCollect);
        showAppMessage(
                bFavorited ? R.string.activity_main_album_add_favorite_tip : R.string.activity_main_album_remove_favorite_tip, AppMsg.STYLE_INFO);
        refreshMusicNumber();
        ckb_favorite.setEnabled(true);
    }

    /**
     * 下载音乐
     */
    private void downloadMusic() {
        if (getMusic() == null) return;
        if (OperateMusicUtils.checkMusicExist(getMusic(), Config.LIST_TYPE_DOWNLOADED)) {
            return;
        }
        //判断网络，如果无网络则提示，返回
        if (!FitmixUtil.checkNetworkStateForMusic(getMusic()) && getMusic().getLocalFlag() == 0) {
            showAppMessage(R.string.check_network, AppMsg.STYLE_ALERT);
            refreshMusicNumber();
            return;
        }
        showAppMessage(R.string.added_downloading, AppMsg.STYLE_INFO);
        updateDownCount();
        OperateMusicUtils.downloadMusic(getMusic());
        UmengAnalysisHelper.getInstance().musicReportPlus(PlayMusicActivity.this, "音乐下载", getMusic().getId());
    }

    /**
     * 分享的次数增加
     */
    private void updateShareCount() {
        if (getMusic() == null) return;
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(getMusic().getId());
        if (musicInfo != null) {
            musicInfo.setShareCount(musicInfo.getShareCount() + 1);
            MusicInfoHelper.getInstance().asyncWriteMusicInfo(musicInfo);
        }
        getMusic().setShareCount(getMusic().getShareCount() + 1);
        refreshMusicNumber();
    }

    /**
     * 下载的次数增加
     */
    private void updateDownCount() {
        if (getMusic() == null) return;
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(getMusic().getId());
        if (musicInfo != null) {
            musicInfo.setDownloadCount(musicInfo.getDownloadCount() + 1);//数据库中歌曲（下载数）信息更新
            MusicInfoHelper.getInstance().asyncWriteMusicInfo(musicInfo);//MusicInfo表中删除歌曲????????
        }
        getMusic().setDownloadCount(getMusic().getDownloadCount() + 1);//播放器的controller中歌曲（下载数）信息更新
        refreshMusicNumber();
    }
    //endregion =============================歌曲分享 下载 收藏======================

    //region =============================网络请求 下载完成 activityResult======================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case USER_LOGIN:
                break;
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                                if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                    updateShareCount();
                                    finishShareMixCoinTask();
                                }
                            }
                            break;
                    }
                }
                break;
        }
    }
    //endregion =============================网络请求 下载完成 activityResult======================

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享歌曲金币任务
     */
    private void finishShareMixCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_MIX, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareMixCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * 完成每日播放歌曲金币任务
     */
    private void finishPlayMixCoinTask() {
        long lastPlayTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_PLAY_MIX, 0);
        if (!FitmixUtil.isToday(lastPlayTime)) {//今日已播放过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishPlayMixCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================
}
