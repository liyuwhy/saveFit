package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.SetMusicCacheDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;

public class CacheManagerActivity extends BaseActivity {

    private TextView tv_album_cover_cache_size;
    private TextView tv_local_music_size;//本地音乐大小
    private TextView tv_trail_cache_size;
    private TextView tv_step_cache_size;
    private TextView tv_photo_cache_size;
    private TextView tv_voice_cache_size;
    private TextView tv_temp_cache_size;
    private TextView tv_setted_music_cache_size;//设置的音乐缓存上限
    private TextView tv_online_music_cache_size;//音乐缓存大小

    private String sizeCover;
    private String sizeMusic;//本地音乐
    private String sizeTrail;
    private String sizeStep;
    private String sizePhoto;
    private String sizeVoice;
    private String sizeTemp;
    private String sizeMusicCache;//音乐缓存
//    private String sizeAll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cache_manager);
        setPageName("CacheManagerActivity");
        initToolbar();
        initViews();
        getCacheSize();
        refresh();
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        setUiTitle(getString(R.string.fm_mine_more_clear_cache));
        tv_album_cover_cache_size = (TextView) findViewById(R.id.tv_album_cover_cache_size);
        tv_local_music_size = (TextView) findViewById(R.id.tv_local_music_size);
        tv_trail_cache_size = (TextView) findViewById(R.id.tv_trail_cache_size);
        tv_step_cache_size = (TextView) findViewById(R.id.tv_step_cache_size);
        tv_photo_cache_size = (TextView) findViewById(R.id.tv_photo_cache_size);
        tv_voice_cache_size = (TextView) findViewById(R.id.tv_voice_cache_size);
        tv_temp_cache_size = (TextView) findViewById(R.id.tv_temp_cache_size);
        tv_setted_music_cache_size = (TextView) findViewById(R.id.tv_setted_music_cache_size);
        tv_online_music_cache_size = (TextView) findViewById(R.id.tv_online_music_cache_size);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }


    /**
     * 清除指定目录
     *
     * @param sDeleteTree 需要清除的目录
     */
    private void deleteTreeByDialog(final String sDeleteTree) {
        if (TextUtils.isEmpty(sDeleteTree))
            return;
        String message = getString(R.string.activity_cache_manager_delete);

        if (sDeleteTree.equals(Config.PATH_DOWN_PICTURE)) {//清除音乐封面图片
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_album_cover) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_cover_again);

        } else if (sDeleteTree.equals(Config.PATH_DOWN_MUSIC)) {//清除本地音乐
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_music) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_music_again);

        } else if (sDeleteTree.equals(Config.PATH_DOWN_TRAIL)) {//清除运动轨迹
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_trail) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_trail_again);

        } else if (sDeleteTree.equals(Config.PATH_DOWN_STEP)) {//清除计步文件
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_step) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_step_again);

        } else if (sDeleteTree.equals(Config.PATH_RUN_VOICE)) {//清除语音
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_voice) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_voice_again);
        } else if (sDeleteTree.equals(Config.PATH_MUSIC_CACHE)) {
            message = getString(R.string.activity_cache_manager_delete_format) + "\t\t" +
                    getString(R.string.activity_cache_manager_delete_music_cache) + "?\n\t\t" +
                    getString(R.string.activity_cache_manager_music_cache_again);
        }

        if (!TextUtils.isEmpty(message)) {
            new MaterialDialog.Builder(this)
                    .title(R.string.warning)
                    .content(message)
                    .positiveText(R.string.delete)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    FileUtils.deleteFile(sDeleteTree);
                                    getCacheSize();
                                    refresh();
                                    break;
                            }
                        }
                    }).show();
        }
    }

    public void doClick(View v) {
        String sPath = null;
        if (v.getId() == R.id.btn_set_music_cache_size) {
            SetMusicCacheDialog cacheDialog = new SetMusicCacheDialog();
            cacheDialog.setOnCacheListener(new SetMusicCacheDialog.MusicCacheListener() {
                @Override
                public void doSure(int size) {
                    if (size > 0) {
                        PrefsHelper.with(CacheManagerActivity.this, Config.PREFS_USER).writeInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, size);
                    }
                    refresh();
                }
            });
            int cacheSize = PrefsHelper.with(this, com.fitmix.sdk.Config.PREFS_USER).readInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, Config.SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE);
            cacheDialog.setSize(String.valueOf(cacheSize));
            cacheDialog.show(getFragmentManager(), "cacheDialog");
            return;
        }
        switch (v.getId()) {

            case R.id.btn_clear_music_cache://清除音乐缓存
                sPath = Config.PATH_MUSIC_CACHE;
                break;

            case R.id.btn_delete_album_cover://清除音乐封面图片
                sPath = Config.PATH_DOWN_PICTURE;
                break;

            case R.id.btn_delete_music://清除本地音乐
                sPath = Config.PATH_DOWN_MUSIC;
                break;

            case R.id.btn_delete_trail://清除运动轨迹
                sPath = Config.PATH_DOWN_TRAIL;
                break;

            case R.id.btn_delete_step:  //清除计步文件
                sPath = Config.PATH_DOWN_STEP;
                break;

            case R.id.btn_delete_photo://清除拍照
                sPath = Config.PATH_RUN_PHOTO;
                break;

            case R.id.btn_delete_voice://清除语音
                sPath = Config.PATH_RUN_VOICE;
                break;

            case R.id.btn_delete_temp://清除临时文件
                sPath = Config.PATH_LOCAL_TEMP;
                break;

            case R.id.btn_delete_bind_device://清除已绑定的蓝牙设备
                new MaterialDialog.Builder(this)
                        .title(R.string.warning)
                        .content(R.string.activity_cache_manager_delete_bind_device_tip)
                        .positiveText(R.string.delete)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        clearBondDevices();
                                        break;
                                }
                            }
                        }).show();
                break;

            case R.id.btn_clear_prefrence:  //清除设置项
                new MaterialDialog.Builder(this)
                        .title(R.string.warning)
                        .content(R.string.fm_mine_more_clear_config_confirm)
                        .positiveText(R.string.delete)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        clearPreferencesData();
                                        break;
                                }
                            }
                        }).show();
                break;

            case R.id.btn_clear_database:   //清除数据库
                new MaterialDialog.Builder(this)
                        .title(R.string.warning)
                        .content(R.string.fm_mine_more_clear_db_confirm)
                        .positiveText(R.string.delete)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        clearDatabase();
                                        break;
                                }
                            }
                        }).show();
                break;

        }
        if (sPath == null) return;
        deleteTreeByDialog(sPath);
    }


    /**
     * 刷新界面
     */
    private void refresh() {
        tv_album_cover_cache_size.setText(sizeCover);
        tv_local_music_size.setText(sizeMusic);
        tv_trail_cache_size.setText(sizeTrail);
        tv_step_cache_size.setText(sizeStep);
        tv_photo_cache_size.setText(sizePhoto);
        tv_voice_cache_size.setText(sizeVoice);
        tv_temp_cache_size.setText(sizeTemp);
        //设置的音乐缓存大小
        int max_music_cache_size = PrefsHelper.with(this, com.fitmix.sdk.Config.PREFS_USER).readInt(com.fitmix.sdk.Config.SP_KEY_MUSIC_CACHE_SIZE, Config.SP_VALUE_DEFAULT_MUSIC_CACHE_SIZE);
        tv_setted_music_cache_size.setText(max_music_cache_size + getString(R.string.mega_byte));//音乐缓存上限
        tv_online_music_cache_size.setText(sizeMusicCache);//音乐缓存大小

    }

    /**
     * 获取缓冲大小
     */
    private void getCacheSize() {
        long size;
        try {
            size = FileUtils.getFileFoldSize(Config.PATH_DOWN_PICTURE);
            sizeCover = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_DOWN_MUSIC);
            sizeMusic = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_DOWN_TRAIL);
            sizeTrail = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_DOWN_STEP);
            sizeStep = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_RUN_PHOTO);
            sizePhoto = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_RUN_VOICE);
            sizeVoice = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_LOCAL_TEMP);
            sizeTemp = FormatUtil.formatFileSize(size);

            size = FileUtils.getFileFoldSize(Config.PATH_MUSIC_CACHE);
            sizeMusicCache = FormatUtil.formatFileSize(size);

//            size = FileUtils.getFileSize(getMyConfig().getDataPath());
//            sizeAll = FormatUtil.formatFileSize(size);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 清除已配对的蓝牙设备
     */
    private void clearBondDevices() {
        //清除已配对的手表
        SettingsHelper.putString(Config.SETTING_WATCH_INFO, "");
//        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_MAC_ADDRESS, "");
    }

    /**
     * 清空系统设置,恢复为系统默认值
     */
    private void clearPreferencesData() {
        int uid = UserDataManager.getUid();
        //从后台服务器最近一次获取用户历史跑步记录的时间戳清零,表示下一次拉取所有跑步记录
        SettingsHelper.putLong(uid, Config.SETTING_RUN_RECORD_SYNC_TIME, 0);
    }

    /**
     * 清空数据库
     */
    private void clearDatabase() {
        //getMyConfig().getDatabase().clearCache();
        //不处理
    }
}
