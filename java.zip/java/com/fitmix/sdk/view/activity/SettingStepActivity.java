package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.SwitchCompat;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;

public class SettingStepActivity extends BaseActivity implements SwitchCompat.OnCheckedChangeListener {

    /**
     * 是否开启后台计步
     */
    private SwitchCompat switch_step_count;
    /**
     * 是否在通知栏显示步数
     */
    private SwitchCompat switch_notification;
    /**
     * 是否在锁屏界面显示步数
     */
    private SwitchCompat switch_lockscreen;
    //	private Button btnLaunch;
    private View groupSettingMore;
    /**
     * 是否人为设置开关
     */
    private boolean toggleByMan = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_step);
        setPageName("SettingStepActivity");
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        setTitle(R.string.title_activity_setting_step);

        boolean daemonStepCount = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        boolean showStepInNotification = SettingsHelper.getBoolean(Config.SETTING_SHOW_STEP_IN_NOTIFICATION, true);
        boolean showStepInLockScreen = SettingsHelper.getBoolean(Config.SETTING_SHOW_STEP_IN_LOCK_SCREEN, false);
        switch_step_count = (SwitchCompat) findViewById(R.id.switch_step_count);
        switch_notification = (SwitchCompat) findViewById(R.id.switch_notification);
        switch_lockscreen = (SwitchCompat) findViewById(R.id.switch_lockscreen);

        toggleByMan = false;
        switch_step_count.setChecked(daemonStepCount);
        switch_notification.setChecked(showStepInNotification);
        switch_lockscreen.setChecked(showStepInLockScreen);
        toggleByMan = true;

//		btnLaunch = (Button) findViewById(R.id.launch);
        groupSettingMore = findViewById(R.id.setting_more_group);

        if (daemonStepCount) {
            groupSettingMore.setVisibility(View.VISIBLE);
        } else {
            groupSettingMore.setVisibility(View.GONE);
        }
        switch_step_count.setOnCheckedChangeListener(this);
        switch_notification.setOnCheckedChangeListener(this);
        switch_lockscreen.setOnCheckedChangeListener(this);
    }


    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onStart() {
        super.onStart();
        if (LockScreenActivity.sIsFromLock) {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
    }

    /**
     * 开始后台今日计步
     */
    private void startStepCount() {
        Intent i = new Intent(this, RunService.class);
        i.putExtra(RunService.ACTION_WHAT, RunService.ACTION_START_DAEMON_STEP_COUNT);
        startService(i);
    }

    /**
     * 停止后台今日计步
     */
    private void stopStepCount() {
        Intent i = new Intent(this, RunService.class);
        stopService(i);
    }


//	/**
//	 * 启动开机流程
//	 */
//	private void startLaunchFitmix() {
//		Intent intent = new Intent();
//		intent.setClass(this, SplashActivity.class);
//		startActivity(intent);
//		finish();
//	}

//	@Override
//	protected void requestingCountChang(int requestingCount) {
//		//不处理
//	}

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    @Override
    protected void processReqError(int requestId, String error) {
        //不处理
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        //人为设置
        if (toggleByMan) {
            switch (buttonView.getId()) {
                case R.id.switch_step_count://是否开启后台计步
                    if (isChecked) {
                        new MaterialDialog.Builder(this)
                                .title(R.string.information)
                                .content(R.string.step_count_always_hint)
                                .positiveText(R.string.ok)
                                .negativeText(R.string.cancel)
                                .onAny(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.dismiss();
                                        switch (which) {
                                            case POSITIVE:
                                                SettingsHelper.putBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
                                                startStepCount();
                                                groupSettingMore.setVisibility(View.VISIBLE);
                                                break;
                                            case NEGATIVE:
                                                toggleByMan = false;
                                                switch_step_count.setChecked(false);
                                                toggleByMan = true;
                                                break;
                                        }
                                    }
                                }).show();
                    } else {
                        stopStepCount();
                        groupSettingMore.setVisibility(View.GONE);
                        SettingsHelper.putBoolean(Config.SETTING_DAEMON_STEP_COUNTER, false);
                    }
                    break;

                case R.id.switch_notification://是否在通知栏显示步数
                    SettingsHelper.putBoolean(Config.SETTING_SHOW_STEP_IN_NOTIFICATION, isChecked);
                    startStepCount();
                    break;

                case R.id.switch_lockscreen://是否在锁屏界面显示步数
                    SettingsHelper.putBoolean(Config.SETTING_SHOW_STEP_IN_LOCK_SCREEN, isChecked);
                    startStepCount();
                    break;
            }
        }
    }

//    public void doClick(View v) {
//        switch (v.getId()) {
//            case R.id.launch:
//                startLaunchFitmix();
//                break;
//        }
//    }


}
