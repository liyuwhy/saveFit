package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.common.sound.VoiceManager;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.AddSkipRecord;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.RunRecordShare;
import com.fitmix.sdk.model.api.bean.SumSkipRope;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.RestHeartRate;
import com.fitmix.sdk.model.database.RestHeartRateHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.service.SkipService;
import com.fitmix.sdk.view.dialog.ContinueFinishDialog;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.SkipMainFinishFragment;
import com.fitmix.sdk.view.fragment.SkipMainMusicFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.SlideButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class SkipMainActivity extends BaseActivity {
    /**
     * 选择音乐请求
     */
    private static final int REQUEST_SELECT_MUSIC = 457;

    //region ==================== 开场倒计时 ====================
    private View viewCountDownGroup;
    private Animation anim_count_down;
    private TextView textCountDown;
    private int mCountDownTime = 3;//3秒

    //endregion ==================== 开场倒计时 ====================

    //    private FrameLayout run_main_container;
    private SlideButton slideButton;//滑动暂停按钮
    private SlideButton.OnSlideListener slideListener;
    private SkipMainMusicFragment mainMusicFragment;
    private SkipMainFinishFragment finishFragment;

    private Music mMusicInfo;
    private boolean bMusicPlayed = false;

    private boolean bUseMetronome;
    private boolean bServiceCountDown = false;

    private Button btn_save_share;
    private boolean skipping;

    /**
     * 跳绳计数文件本地绝对路径
     */
    private String skipFileName;
    /**
     * 分享的临时文件绝对路径
     */
    private String shareFileName;
    /**
     * 保存并分享
     */
    private boolean saveAndShare = false;

    //region ==================== 任务计划 ====================
    private boolean bTaskComplete;
    private long taskObject;
    private int taskType;
    //endregion ==================== 任务计划 ====================


    /**
     * 自定义handler
     */
    private static class MyHandler extends WeakHandler {
        public MyHandler(SkipMainActivity runMainActivity) {
            super(runMainActivity);
        }

        public void handleMessage(Message msg) {
            SkipMainActivity activity = (SkipMainActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case Config.MSG_ANIMATION_TIMER://运动开始倒计时
                    activity.processAnimation();
                    break;

                case Config.MSG_REPEAT_EVERY_SECOND:
                    activity.refreshSkipInfo();
                    activity.getHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND, 1000);
                    break;
            }
        }
    }

    /**
     * SkipMainActivity页面中定义的handler
     */
    private MyHandler mHandler;

    /**
     * 获取SkipMainActivity页面中定义的handler
     */
    private MyHandler getHandler() {
        if (mHandler == null) {
            mHandler = new MyHandler(this);
        }
        return mHandler;
    }

    /**
     * @return 获取音乐信息
     */
    public Music getMusicInfo() {
        return mMusicInfo;
    }

    //region ====================================== 与SkipService交互相关 ======================================

    private SkipService skipService;

    /**
     * 获取跳绳服务
     */
    public SkipService getSkipService() {
        return skipService;
    }

    private SkipService.OnBluetoothConnectionListener mOnIBluetoothConnectionListener;
    private SkipService.OnSkipActionListener mOnSkipActionListener;
    private ServiceConnection serviceConnection;

    /**
     * 绑定跳绳服务
     */
    private void connectToSkipService() {
        Intent intent = new Intent(this, SkipService.class);
        intent.putExtra("fromSkipMainActivity", true);
        serviceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(SkipService.SERVICE_NAME))
                    return;
                skipService = ((SkipService.LocalBinder) service).getService();
                if (skipService == null)
                    return;

                skipService.setNumberSiriRate(PrefsHelper.with(SkipMainActivity.this, Config.PREFS_SPORT).readInt(Config.SY_KEY_SIRI_RATE_SKIP, Config.SY_KEY_SIRI_RATE_SKIP_DEFAULT));

                skipService.resetSkipData();
                skipService.addOnBluetoothConnectionListener(getBluetoothConnectionListener());
                skipService.addOnSkipActionListener(getSkipActionListener());
                skipService.setUserHeartRateFinish(userHeartRateFinish);
                long value = taskObject;
                if (taskType == SkipService.TASK_TYPE_TIME) value *= 1000;
                skipService.setTaskTypeAndValue(value, taskType);
                if (skipping) {
                    skipStart(false);
                } else {
                    if (bServiceCountDown) {
                        bServiceCountDown = false;
                        startCountDown();
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                skipService = null;
            }
        };

        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 获取跳绳运动监听回调
     */
    private SkipService.OnSkipActionListener getSkipActionListener() {
        if (mOnSkipActionListener == null) {
            mOnSkipActionListener = new SkipService.OnSkipActionListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onStop() {//运动结束
                    skipFinish();
                }
            };
        }
        return mOnSkipActionListener;
    }

    /**
     * 获取跳绳蓝牙连接监听
     */
    private SkipService.OnBluetoothConnectionListener getBluetoothConnectionListener() {
        if (mOnIBluetoothConnectionListener == null) {
            mOnIBluetoothConnectionListener = new SkipService.OnBluetoothConnectionListener() {
                @Override
                public void onConnected(BluetoothDevice device) {
                    Logger.i(Logger.DEBUG_TAG, "SkipMainActivity --- > mOnConnectionListener --- > onConnected");
                }

                @Override
                public void onDisconnected(BluetoothDevice device) {
                    Logger.i(Logger.DEBUG_TAG, "SkipMainActivity --- > mOnConnectionListener --- > onDisconnected");
                    skipFinish();
                }
            };
        }
        return mOnIBluetoothConnectionListener;
    }

    /**
     * 解绑跳绳服务
     */
    private void disconnectToSkipService() {
        if (getSkipService() != null) {
            mOnSkipActionListener = null;
            getSkipService().removeSkipActionListener();
            getSkipService().removeOnIBluzDeviceConnectionListener();
            getSkipService().setUserHeartRateFinish(null);
        }
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        serviceConnection = null;
    }

    /**
     * 从SkipService获取当前跑步信息
     */
    private SkipLogInfo getSkipLogInfo() {
        if (getSkipService() == null) return null;
        return getSkipService().getSkipLogInfo();
    }

    //endregion ====================================== 与SkipService交互相关 ======================================

    //region ====================================== 与HeartRateService交互相关 ======================================

    //当运动结束时的回调
    private SkipService.UserHeartRateFinish userHeartRateFinish = new SkipService.UserHeartRateFinish() {
        @Override
        public void doUserHeartRateFinish() {
            if (heartRateService == null) {
                return;
            }
            if (heartRateService.getHeartRateSize() > 0) { // 只要有心率值，便是心率
//                heartRateService.setUserHeartRate(new UserHeartRate());
//                UserHeartRate userHeartRate = heartRateService.getUserHeartRate();

//                heartRateService.setUserHeartRate(new UserHeartRate());
                UserHeartRate userHeartRate = new UserHeartRate();

                userHeartRate.setAerobicNum(heartRateService.getAerobicNum());
                userHeartRate.setAnaerobicNum(heartRateService.getAnaerobicNum());
                userHeartRate.setFatBurningNum(heartRateService.getFatBurningNum());
                userHeartRate.setMaxNum(heartRateService.getMaxNum());
                userHeartRate.setWarmNum(heartRateService.getWarmNum());
                userHeartRate.setMaxHeartRate(heartRateService.getMaxHeartRate());
                userHeartRate.setMinHeartRate(heartRateService.getMinHeartRate());
                if (heartRateService.getHeartRateSize() == 0 || heartRateService.getSumHeartRate() == 0) {
                    userHeartRate.setHeartRateAvg(0);
                } else {
                    userHeartRate.setHeartRateAvg(heartRateService.getSumHeartRate() / heartRateService.getHeartRateSize());
                }

                userHeartRate.setLastUpdated(System.currentTimeMillis());
                //增加的年龄与静息心率
                int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
                userHeartRate.setCurrentAge(age > 0 ? age : Config.USER_DEFAULT_AGE);

                userHeartRate.setCurrentRestHeartRate(heartRateService.getLatestRestHeartRate());

                if (getSkipService() != null) {
                    if (getSkipService().getSkipLogInfo() != null) {
                        userHeartRate.setConsumptionSpendTime(getSkipService().getSkipLogInfo().getSkipTime());//运动时长//TODO bug:存在为空的情况
                    }
                    String heartRateString = JsonHelper.createJsonString(userHeartRate);
                    getSkipService().getSkipLogInfo().setHeartRateDate(heartRateString);
                }
            }
        }

    };

    //HeartRateService的回调
    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {
            //不处理
        }

        @Override
        public void onDeviceConnected() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(SkipMainActivity.this, getResources().getString(R.string.gatt_connected), Toast.LENGTH_SHORT).show();
                }
            });
            startHeartRateService();
            Logger.i(Logger.DEBUG_TAG, "onDeviceConnected()");
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.i(Logger.DEBUG_TAG, "onDeviceDisconnected");
            //断开了也要设服务的最新心率为0
            if (getSkipService() != null) {
                getSkipService().setLastestHeartRate(getLastestHeartRate());
            }
            stopHeartRateService();
        }


        @Override
        public void onError() {
            Logger.i(Logger.DEBUG_TAG, "RunMainActivity,onError()");
        }

        @Override
        public void onHRValueReceived() {
            if (getSkipService() != null) {
                getSkipService().setLastestHeartRate(getLastestHeartRate());
            }
        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, int signalValue) {
            //不处理
        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {
            //不处理
        }

        /**
         * 心率图表刷新
         */
        @Override
        public void reDrawHeartRateData() {
            //不处理
        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                              int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                              boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {
            //不处理
        }
    };

    private HeartRateService heartRateService;

    /**
     * 获取跑步主服务
     */
    public HeartRateService getHeartRateService() {
        return heartRateService;
    }

    private ServiceConnection heartRateServiceConnection;

    /**
     * 运动开始前发送运动相关设置指令
     */
    private void sendSportDataCmd(int age, int sexuality, int weight, int height, int rest_hr, int sport_mode) {
        if (heartRateService == null) {
            return;
        }
        if (heartRateService.getDevice() != null) {
            if (heartRateService.getDevice().getName().contains("H10") || heartRateService.getDevice().getName().contains("ROC HR")
                    || heartRateService.getDevice().getName().contains("ROC Model")) {
                if (heartRateService.getBleManager() != null) {
                    heartRateService.getBleManager().sendHRCmd(4);
                    heartRateService.getBleManager().setUserData(age, sexuality, weight, height, rest_hr, sport_mode);
                }
            }
        }
    }

    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);
        heartRateServiceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService == null)
                    return;
                if (heartRateService != null) {
                    //静息心率，数据库搜索最近一次的静息心率记录
                    RestHeartRate info = RestHeartRateHelper.getInstance().getLatestHeartRateInfo(UserDataManager.getUid());
                    heartRateService.setLatestRestHeartRate((info != null && info.getHeart_rate_record() != null) ? info.getHeart_rate_record() : Config.HEART_RATE_DEFAULT_REST_HR);

                    heartRateService.setIfBindWithRunMain(true);
                    heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };

        bindService(intent, heartRateServiceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (heartRateService != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                heartRateService.setIfBindWithRunMain(false);
                heartRateService.releaseCountData();
                heartRateService.removeHeartRateItem(mPageName);
            }
        }
        if (heartRateServiceConnection != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(heartRateServiceConnection);
            }
        }
        heartRateServiceConnection = null;
    }

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Intent i = new Intent(this, HeartRateService.class);
        Logger.i(Logger.DEBUG_TAG, "SkipMainActivity --->  startHeartRateService()");
        startService(i);
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "SkipMainActivity --->  stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    /**
     * UI界面上更新心率数值
     *
     * @return
     */
    public int getLastestHeartRate() {
        if (heartRateService != null && heartRateService.getDevice() != null) {
            return heartRateService.getLatestHeartRate();
        } else { // 设备断开情况
            return 0;
        }
    }

    /**
     * 根据userHeartRate是否为空作为是否连接过心率带的依据
     *
     * @return
     */
    public boolean ifDeviceHaveConnected() {
        if (heartRateService != null) {
            if (heartRateService.getHeartRateSize() > 0) {
                return true;
            }
        }
        return false;
    }


    //endregion ====================================== 与HeartRateService交互相关 ======================================

    //region ====================================== Activity 生命周期相关 ======================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        setContentView(R.layout.activity_skip_main);
        setPageName("SkipMainActivity");
        //Android 6.0申请权限
        getPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE});
        PlayerController.getInstance().stopMusic();
        skipping = getIntent().getBooleanExtra("skipping", false);//跳绳启动的页面true 人为的打开页面false;
        if (savedInstanceState == null) {
            mainMusicFragment = new SkipMainMusicFragment();
            //音乐播放按钮状态监听
            mainMusicFragment.setMusicPlayControlChangeListener(new SkipMainMusicFragment.OnMusicPlayControlChangeListener() {
                @Override
                public void onCheckedChanged(boolean isPlaying) {
                    if (isPlaying) {
                        pauseMusic();
                    } else {
                        playMusic();
                    }
                }
            });
            //节拍器选择回调事件
            mainMusicFragment.setMetronomeSelectedListener(new SkipMainMusicFragment.OnMetronomeSelectedListener() {
                @Override
                public void onMetronomeSelected(int index, String value) {
                    int dpm = 0;
                    if ((value != null) && (!TextUtils.isEmpty(value))) {
                        try {
                            dpm = Integer.parseInt(value);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    setMetronome(dpm);
                }
            });
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.skip_main_container, mainMusicFragment, "mainMusic").commit();
        }

        initViews();
        init();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        /** V2.0.3 java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState*/
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
        if (loadingDialog != null) {
            loadingDialog.dismiss();
        }
        loadingDialog = null;
        disconnectToSkipService();
        disconnectToHeartRateService();
        releaseResource();
    }

    /**
     * 初始化
     */
    private void init() {
        //1.检查当前运动用户UID是否有效
        int uid = UserDataManager.getUid();
        if (uid < 0) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.login_the_sport)
                    .positiveText(android.R.string.ok)
                    .cancelable(false)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            finish();
                        }
                    }).show();
            return;
        }
        //2.获取音乐信息和运动计划
        Intent intent = getIntent();
        if (intent == null)
            return;

        String musicString = intent.getStringExtra("musicInfo");
        if (!TextUtils.isEmpty(musicString)) {
            mMusicInfo = JsonHelper.getObject(musicString, Music.class);
        }
        if (mMusicInfo == null) {
            if (PlayerController.getInstance().getIsActionPlay()) {
                PlayerController.getInstance().pauseMusic();
            }
        }
        taskObject = intent.getLongExtra("taskObject", 0);
        taskType = intent.getIntExtra("taskType", 0);
        //3.绑定跳绳服务
        mHandler = new MyHandler(this);
        connectToSkipService();

        //4.绑定心率服务
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            connectToHeartRateService();
        }

        if (!skipping) {
            startCountDown();
        }
    }

    protected void initViews() {
        slideButton = (SlideButton) findViewById(R.id.slideButton);
        slideListener = new SlideButton.OnSlideListener() {
            @Override
            public void onSlide() {//滑动暂停事件
                pauseSkip(false);
            }
        };
        slideButton.setOnSlideListener(slideListener);

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        if (requestId == (Config.MODULE_USER + 24)) {//向后台服务器发送用户统计数据
            return;//不需要从数据库查询请求结果
        }
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_SPORT + 10://添加跳绳记录到后台服务器
                AddSkipRecord addSkipRecord = JsonHelper.getObject(result, AddSkipRecord.class);
                handleUploadRecord(addSkipRecord);
                break;

            case Config.MODULE_SPORT + 13://分享跳绳记录
                hideLoadingDialog();
                String sLocale = getShareFileName();
                Logger.i(Logger.DEBUG_TAG, "分享跳绳记录 dataReqResult:" + dataReqResult);
                RunRecordShare runRecordShare = JsonHelper.getObject(result, RunRecordShare.class);
                if (runRecordShare != null) {
                    String sRemote = runRecordShare.getShare();
                    if (TextUtils.isEmpty(sLocale) || TextUtils.isEmpty(sRemote))
                        return;
                    shareSkipScore(sLocale, sRemote);
                } else {
                    showErrorDialog(R.string.error);
                }
                enableShareButton();
                break;

            case Config.MODULE_USER + 61://完成每日分享运动记录金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_RECORD, System.currentTimeMillis());//设置完成任务时间

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription(), new QuestRewardsDialog.OnQuestRewardsDialogDismiss() {
                                @Override
                                public void onRewardsDialogDismiss() {//对话框消失后,继续销毁activity
                                    delayFinishSkipMainActivity();
                                }
                            });
                        }
                    }
                }
                break;

        }
    }

    /**
     * 处理上传跑步记录回调
     */
    private void handleUploadRecord(AddSkipRecord addSkipRecord) {
        Logger.i(Logger.DEBUG_TAG, "handleUploadRecord addRunRecord is null:" + (addSkipRecord == null));
        enableShareButton();
        if (addSkipRecord == null) {
            showAppMessage(R.string.activity_runmain_add_record_fail, AppMsg.STYLE_ALERT);
            if (!saveAndShare) {
                delayFinishSkipMainActivity();
            }
            return;
        }
        if (addSkipRecord.getCode() == 0) {//上传成功后
            AddSkipRecord.UserSkipRopeBean userSkipRopeBean = addSkipRecord.getUserSkipRope();
            if (userSkipRopeBean != null) {
                int uid = userSkipRopeBean.getUid();
                long startTime = userSkipRopeBean.getStartTime();
                //上传成功后更新跳绳记录同步状态
                SportRecordsHelper.updateSkipSportRecordSyncState(uid, startTime, userSkipRopeBean.getSkipDetail(), 1);
                if (saveAndShare) {
                    int requestId = SportDataManager.getInstance().shareSkipRecord(startTime, getShareFileName(), "file");
                    registerDataReqStatusListener(requestId);
                } else {
                    hideLoadingDialog();
                    showAppMessage(R.string.activity_runmain_add_record_success, AppMsg.STYLE_INFO);
                    delayFinishSkipMainActivity();
                }
                return;
            }
        }
        //上传失败
        if (saveAndShare) {
            hideLoadingDialog();
            showErrorDialog(R.string.error);
        } else {
            hideLoadingDialog();
            delayFinishSkipMainActivity();
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        hideLoadingDialog();
        enableShareButton();
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            switch (requestId) {
                case Config.MODULE_USER + 24://用户统计不提示
                    break;
                case Config.MODULE_SPORT + 13://分享跳绳记录
                    showErrorDialog(R.string.error);
                    break;
                case Config.MODULE_SPORT + 10://添加跳绳记录到后台服务器
                    if (errorCode < 1000) {
                        if (saveAndShare) {
                            showErrorDialog(R.string.error);
                        } else {
                            showErrorDialog(R.string.activity_runmain_add_record_error);
                        }
                    } else if (errorCode == 4003) {//文件未上传
                        String msg = bean.getMsg();
                        if (!TextUtils.isEmpty(msg)) {
                            showAppMessage(msg, AppMsg.STYLE_ALERT);
                        }
                        delayFinishSkipMainActivity();
                    }
                    break;

                case Config.MODULE_USER + 61://每日分享运动记录金币任务
                    if (bean != null) {
                        if (bean.getCode() == 9002) {//任务已完成,更新任务完成时间
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_RECORD, System.currentTimeMillis());
                        }
                    }
                    delayFinishSkipMainActivity();
                    break;
            }
        }
    }

    /**
     * 弹出失败提示框
     *
     * @param strId 提示的信息字符串资源ID
     */
    private void showErrorDialog(int strId) {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(strId)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                delayFinishSkipMainActivity();
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 1.5秒后销毁activity
     */
    private void delayFinishSkipMainActivity() {
        Logger.i(Logger.DEBUG_TAG, "SkipMainActivity-->delayFinishSkipMainActivity mHandler is null:" + (mHandler == null));
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                SkipMainActivity.this.finish();
            }
        }, 1500);//1.5秒后销毁activity
    }

    //endregion ====================================== Activity 生命周期相关 ======================================

    //region ====================================== 跳绳相关 ======================================

    /**
     * 初始化倒计时控件
     */
    private void initCountDown() {
        anim_count_down = AnimationUtils.loadAnimation(this, R.anim.count_down);
        viewCountDownGroup = findViewById(R.id.count_down_group);
        textCountDown = (TextView) findViewById(R.id.count_down_text);
        viewCountDownGroup.setVisibility(View.VISIBLE);
    }

    private VoiceManager voiceManager;//语音管理器,负责语音播报

    /**
     * 获取VoiceManager
     */
    public VoiceManager getVoiceManager() {
        if (voiceManager == null)
            voiceManager = new VoiceManager();
        return voiceManager;
    }

    /**
     * 开始运动前判断
     */
    private void startCountDown() {
        //1.上一次运动正常结束,则开启新的运动
        initCountDown();
        startCountDownTimer();
        //playMusic();
        userBehaviorStat();
    }

    /**
     * 开始运动倒计时
     */
    private void startCountDownTimer() {
        if (mCountDownTime < 0)
            return;
        if (mCountDownTime > 0) {
            textCountDown.setText(String.valueOf(mCountDownTime));
        } else {
            textCountDown.setText("GO");
        }
        //语音播报321 GO并设置音调
        if (mCountDownTime == 3) {
            boolean sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            if (sportWithVoice) {
                getVoiceManager().playCounterDownSkip();
            }
        }
        if (anim_count_down != null)
            anim_count_down.cancel();
        if (viewCountDownGroup != null)
            viewCountDownGroup.startAnimation(anim_count_down);
        getHandler().sendEmptyMessageDelayed(Config.MSG_ANIMATION_TIMER, 1000);
    }

    /**
     * 处理运动开始倒计时动画
     */
    private void processAnimation() {
        mCountDownTime--;
        if (mCountDownTime < 0) {
            skipStart(true);
        } else {
            startCountDownTimer();
        }
    }

    /**
     * 开始运动
     *
     * @param sendStartCommand 是否发送开始运动的命令
     */
    private void skipStart(boolean sendStartCommand) {
        if (viewCountDownGroup != null)
            viewCountDownGroup.setVisibility(View.GONE);
        if (getSkipService() == null) {
            return;
        }
        playMusic();
        if (!getSkipService().isInSkipDuration()) {
            getSkipService().startSkip(sendStartCommand);
        }
        getHandler().sendEmptyMessage(Config.MSG_REPEAT_EVERY_SECOND);
    }

    /**
     * 运动继续
     */
    private void skipContinue() {
        getHandler().sendEmptyMessage(Config.MSG_REPEAT_EVERY_SECOND);
        if (getSkipService() == null)
            return;
        getSkipService().continueSkip();
        continueVoice();
        if (slideButton != null && slideButton.getVisibility() == View.GONE) {
            slideButton.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 运动暂停
     *
     * @param bHideDialog 是否隐藏继续运动和暂停运动的对话框
     */
    public void pauseSkip(boolean bHideDialog) {
        if (getSkipService() == null)
            return;
        getHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        getSkipService().pauseSkip();
        pauseVoice();
        if (!bHideDialog) {
            slideButton.setVisibility(View.GONE);//隐藏滑动暂停
            final ContinueFinishDialog dialog = new ContinueFinishDialog(SkipMainActivity.this,
                    new ContinueFinishDialog.OnButtonClickListener() {
                        @Override
                        public void sportContinue() {
                            SkipMainActivity.this.skipContinue();
                            slideButton.setVisibility(View.VISIBLE);//显示滑动暂停
                        }

                        @Override
                        public void sportFinish() {
                            SkipMainActivity.this.skipFinish();
                        }
                    });
            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    skipContinue();
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
    }

    /**
     * 运动结束
     */
    private void skipFinish() {
        getHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
        if (getSkipService() == null)
            return;
        //1.停止音乐和节拍器
        stopVoice();
        //2.停止运动
        final int uid = UserDataManager.getUid();

        final long skipId = getSkipService().getSkipLogInfo().getStartTime();
        skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipId + ".skip";
        //heartFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipId + ".heart";
        shareFileName = Config.PATH_LOCAL_TEMP + uid + "_" + skipId + ".jpg";
        getSkipService().stopSkip();
        //TODO 运动记录是否符合条件过滤
        //3.跳绳个数小于20个 给用户提示并不保存记录
        boolean quitSave = false;
        if (getSkipService().getSkipNumber() < 20) {
            quitSave = true;
        }
        if (quitSave) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.activity_skipmain_skipnumber_too_littal)
                    .positiveText(R.string.i_know)
                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            SportRecordsHelper.asyncDeleteSkipRecord(SkipMainActivity.this, uid, skipId, null);
                            FileUtils.deleteFile(skipFileName);
                            dialog.dismiss();
                            finish();//结束Activity
                        }
                    }).cancelable(false).show();
            return;
        }
        refreshSkipStatisticsInfo(true);
        skipFinishShare(uid, skipId);
    }

    private void releaseResource() {
        if (anim_count_down != null) {
            anim_count_down.cancel();
            anim_count_down = null;
        }
        if (viewCountDownGroup != null)
            viewCountDownGroup.clearAnimation();
        viewCountDownGroup = null;
        mCountDownTime = 0;
        mainMusicFragment = null;
        finishFragment = null;
        PlayerController.getInstance().stopMusic();
    }

    /**
     * 保存运动记录到后台服务器
     */
    private void saveSkipLogInNet() {
        if (!FileUtils.isStepFileCompleted(skipFileName)) {
            showAppMessage(R.string.activity_runmain_save_record_busy, AppMsg.STYLE_INFO);
            return;
        }
        String files = skipFileName;
        String fileTags = "file";

        if (getSkipLogInfo() != null) {
            if (getSkipLogInfo().getSkipTime() > 60000) {
                getSkipLogInfo().setBpm((int) (1.0f * getSkipLogInfo().getSkipNumber() / (getSkipLogInfo().getSkipTime() / 60000.0f)));//总的平均BPM
            } else if (getSkipLogInfo().getSkipTime() > 0) {
                getSkipLogInfo().setBpm((int) (getSkipLogInfo().getSkipNumber() * 60000.0f / getSkipLogInfo().getSkipTime()));//总的平均BPM
            }
            int requestId = SportDataManager.getInstance().addSkipSportRecord(getSkipLogInfo(), files, fileTags, true);//不考虑之前的请求结果
            registerDataReqStatusListener(requestId);

            if (saveAndShare) {
                showLoadingDialog(R.string.activity_runmain_share_record_busy, 1000);
            } else {
                showLoadingDialog(R.string.activity_runmain_add_record_busy, 1000);
            }
        }
    }

    @Override
    protected void showLoadingDialog(final int resId, long delayShowTime) {
        loadingDialog = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .content(resId)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                //仅保存记录时,用户点击确定销毁activity
                                if (resId == R.string.activity_runmain_add_record_busy) {
                                    delayFinishSkipMainActivity();
                                } else {
                                    enableShareButton();
                                }
                                break;
                        }
                    }
                }).build();
        canShowDialog = true;
        if (delayShowTime == 0) {
            if (loadingDialog != null) {
                loadingDialog.show();
            }
        } else if (delayShowTime >= 1000) {
            ThreadManager.getMainHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (loadingDialog != null && canShowDialog) {
                        loadingDialog.show();
                    }
                }
            }, delayShowTime);
        }
    }

    /**
     * 使保存并分享按钮可点击
     */
    private void enableShareButton() {
        if (btn_save_share != null) {
            btn_save_share.setEnabled(true);
        }
    }

    /**
     * 用户行为统计
     */
    private void userBehaviorStat() {
        int mid = -1;
        if (getMusicInfo() != null)
            mid = getMusicInfo().getId();
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().reportUserBehavior(uid, mid, 2, 0, 0);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 刷新界面上的跳绳信息
     */
    private void refreshSkipInfo() {
        if (getSkipService() == null || getSkipLogInfo() == null)
            return;
        //1.刷新界面信息
        String sSkipTime;
        if (getSkipService().getStartSkipTime() != 0) {
            sSkipTime = FormatUtil.formatRunTime(getSkipService().getSkipTime() / 1000);
        } else {
            sSkipTime = FormatUtil.formatRunTime(0);
        }
        int sSkipNumber = getSkipLogInfo().getSkipNumber();
        long calorie = (int) (getSkipLogInfo().getCalorie());
        int type = getSkipService().getTaskType();
        long value = getSkipService().getTaskValue();
        completeTaskGroup(type, value, sSkipNumber);
//        Logger.i(Logger.DEBUG_TAG, "SkipMainActivity--->refreshSkipInfo() calorie:" + calorie);
//        double currentBpm = getSkipService().getCurrentBpm();//实时的bpm
        if (mainMusicFragment != null && mainMusicFragment.isVisible()) {
            mainMusicFragment.setSkipDuration(sSkipTime);
            mainMusicFragment.setSkipNumber(sSkipNumber);
            mainMusicFragment.setSkipCalorie(calorie + "");
            mainMusicFragment.setPlayingTime();
            mainMusicFragment.setTaskProgress(type, value, sSkipNumber);
        }

        //2.检测任务计划
        if ((!bTaskComplete) && getSkipService().isTaskComplete()) {
            bTaskComplete = true;
            String sItemFormat = getResources().getString(R.string.task_complete);
            String sContent = String.format(sItemFormat, getTaskString());

            new MaterialDialog.Builder(this)
                    .title(R.string.information)
                    .content(sContent)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                        }
                    }).show();
        }
    }

    private int preGroup = 1;//当前跳绳的组数

    /**
     * 是否完成一组跳绳
     *
     * @param type       运动目标类型
     * @param value      运动目标值
     * @param skipNumber 当前跳绳个数
     */
    private void completeTaskGroup(int type, long value, int skipNumber) {
        if (type != SkipService.TASK_TYPE_SPORT_PLAN) return;
        double stage = value / calculate(1, -1, -value / 10);
        if (stage < 0) stage = 0;
        int progress = (int) (skipNumber / stage) + 1;
        if (progress < 0) progress = 0;
        int currentGroup = progress >= value / stage ? (int) (value / stage) : progress;
        if (currentGroup > preGroup) {
            preGroup = currentGroup;
            pauseSkip(false);
        }
    }

    /**
     * 获取当前训练计划的组数 (x + 2)(x +3)*100=n 求 x
     *
     * @param a 方程的二次项系数
     * @param b 方程的一次项系数
     * @param c 方程的常数项
     */
    public double calculate(double a, double b, double c) {
        double x1, x2; //两个根
        double d = b * b - 4 * a * c;
        if (Math.abs(d) < 1E-5) {//表示一个根，
            x1 = -b / (2 * a);
            x2 = x1;
            return x2;
        } else if (d > 0) {//表示两个实根
            x1 = (-b + Math.sqrt(d)) / (2 * a);
            x2 = (-b - Math.sqrt(d)) / (2 * a);
            return x2 > x1 ? x2 : x1;
        } else {//表示两个复数的根
//            double r = -b / (2 * a);
//            double v = Math.sqrt(-d) / (2 * a);
            return -1;
        }
    }
    //endregion ====================================== 跳绳相关 ======================================

    //region ====================================== SkipMainMusic相关 ======================================

    public void switchToMusic() {
        getVoiceManager().stopMetronome();
        playMusic();
    }

    public void switchToMetronome(int bpm) {
        pauseMusic();
//        getVoiceManager().setMetronomeDpm(bpm);
//        getVoiceManager().startMetronome();
        getVoiceManager().runMetronome(bpm);
    }

    private void checkStartPlay() {
        if (bMusicPlayed)
            return;
        if (getMusicInfo() == null)
            return;

        if (getMusicInfo().getLocalFlag() == 1) {
            startPlayMusic();
            return;
        }
        if (!FitmixUtil.isExistCacheFile(getMusicInfo().getUrl(), getMusicInfo().getId(),
                Config.DOWNLOAD_FORMAT_MUSIC)) {

            String sLocalFile = FitmixUtil.getTempMusicPath(getMusicInfo());

            if (FitmixUtil.checkMusicDownloadParamValid(sLocalFile, true)) {
                showAppMessage(getResources()
                        .getText(R.string.activity_play_music_play_downloading_music).toString(), AppMsg.STYLE_CONFIRM);

            } else {
                if (!FitmixUtil.checkNetworkStateForMusic(getMusicInfo())) {
                    showAppMessage(getResources()
                            .getText(R.string.check_network).toString(), AppMsg.STYLE_CONFIRM);
                    return;
                }
                if (ApiUtils.getNetworkType() != Config.NETWORK_TYPE_WIFI) {
                    /** bug v2.0.3 com.fitmix.sdk.dialog.material.MaterialDialog$DialogException:
                     //Bad window token, you cannot show a dialog before an Activity is
                     created or after it's hidden.*/
                    new MaterialDialog.Builder(this)//页面消失后弹框失败
                            .title(R.string.warning)
                            .content(R.string.downstream_control)
                            .positiveText(android.R.string.ok)
                            .negativeText(R.string.cancel)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            startPlayMusic();//非WIFI环境下,播放音乐
                                            break;
                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                    return;
                }
            }
        }
        startPlayMusic();
    }

    private void playMusic() {
        if (!checkMusicReady())
            return;
        if (!FitmixUtil.isExistCacheFile(getMusicInfo().getUrl(), getMusicInfo().getId(),
                Config.DOWNLOAD_FORMAT_MUSIC)) {
            String sLocalFile = FitmixUtil.getTempMusicPath(getMusicInfo());

            if (FitmixUtil.checkMusicDownloadParamValid(sLocalFile, true)) {
                showAppMessage(R.string.activity_play_music_play_downloading_music, AppMsg.STYLE_INFO);

            } else {
                if (!FitmixUtil.checkNetworkStateForMusic(getMusicInfo())) {
                    showAppMessage(R.string.check_network, AppMsg.STYLE_CONFIRM);
                }
            }
        }
        if (!bMusicPlayed) {
            checkStartPlay();
        } else {
            if (getMyConfig().getPlayer().getIsActionPlay())
                return;
            getMyConfig().getPlayer().resumeMusic();
        }
    }

    private void pauseMusic() {
        if (!checkMusicReady())
            return;
        if (!getMyConfig().getPlayer().getIsActionPlay())
            return;
        getMyConfig().getPlayer().pauseMusic();
    }

    private void startPlayMusic() {
        if (!checkMusicReady())
            return;
        if (getMyConfig().getPlayer().getIsActionPlay()) {
            getMyConfig().getPlayer().stopMusic();
        }
        if (getMusicInfo() == null) return;
        getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ONE);// XXX
        // 更改为顺序播放
        // PlayerController.MODE_REPEAT
//        RunLogInfo runLogInfo = null;
//        if (getRunService() != null)
//            runLogInfo = getRunService().getRunLogInfo();
//        if ((runLogInfo == null) || (runLogInfo.getRunTime() <= 1000)) {
//            //getMyConfig().getPlayer().playMusic(getMusicInfo(), true);//TODO 之前只是加载
//            getMyConfig().getPlayer().playMusic(getMusicInfo(), false);
//        } else {
        getMyConfig().getPlayer().playMusic(getMusicInfo(), true);
//        }
        bMusicPlayed = true;
    }

    private boolean checkMusicReady() {
        return getMusicInfo() != null;
    }

    private void playPauseMusic() {
        if (!checkMusicReady())
            return;
        if (!bMusicPlayed) {
            checkStartPlay();
        } else {
            if (getMyConfig().getPlayer().getIsActionPlay()) {
                pauseMusic();
            } else {
                playMusic();
            }
        }
    }

    private void playNextSegment() {
        getMyConfig().getPlayer().playNextSegment();

    }

    /**
     * 暂停播放音乐或节拍器
     */
    private void pauseVoice() {
        //pauseMusic();
        if (bUseMetronome) {
            if (getSkipService() != null)
                getSkipService().getVoiceManager().stopMetronome();
        } else {
            pauseMusic();
        }
    }

    private void stopVoice() {
        PlayerController.getInstance().stopMusic();
    }

    /**
     * 继续播放音乐或节拍器
     */
    private void continueVoice() {
        playMusic();
    }

    /**
     * 设置节拍器节奏
     *
     * @param dpm 节拍
     */
    private void setMetronome(int dpm) {
        try {
            //TODO 保存节拍器节拍
//            getVoiceManager().stopMetronome();
//            getVoiceManager().setMetronomeDpm(dpm);
//            getVoiceManager().startMetronome();

            getVoiceManager().runMetronome(dpm);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    /**
     * 设置是否节拍器模式
     *
     * @param useMetronome 是否节拍器模式
     */
    public void setUseMetronome(boolean useMetronome) {
        bUseMetronome = useMetronome;
    }

    //endregion ====================================== RunMainMusic相关 ======================================

    //region ====================================== 训练计划相关 ======================================


    private String getTaskString() {
        String sResult = "";
        switch (taskType) {
            case SkipService.TASK_TYPE_TIME:
                sResult = getResources().getString(R.string.skip_time) + FormatUtil.formatTimeChinaStyle(taskObject);
                break;
            case SkipService.TASK_TYPE_NUMBER:
                sResult = getResources().getString(R.string.skip) + String.valueOf(taskObject) + getResources().getString(R.string.fm_mine_skip_record_progress_unit_text);
                break;
            case SkipService.TASK_TYPE_CALORIE:
                sResult = getResources().getString(R.string.consume) + taskObject + getResources().getString(R.string.calorie_unit);
                break;
            case SkipService.TASK_TYPE_SPORT_PLAN:
                sResult = getResources().getString(R.string.skip) + String.valueOf(taskObject) + getResources().getString(R.string.fm_mine_skip_record_progress_unit_text);
                break;
        }
        return sResult;
    }


    //endregion ====================================== 训练计划相关 ======================================

    //region ====================================== SkipMainFinish相关 ======================================

    /**
     * 运动完成并分享,替换SkipMainFinishFragment
     *
     * @param uid    用户uid
     * @param skipId 跳绳编号
     */
    private void skipFinishShare(int uid, long skipId) {
        if (finishFragment == null) {
            finishFragment = new SkipMainFinishFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("uid", uid);
            bundle.putLong("skipStartTime", skipId);
            finishFragment.setArguments(bundle);
        }
        if (!isFinishing() && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out)
                    .replace(R.id.skip_main_container, finishFragment, "skipMainFinish")
                    .commitAllowingStateLoss();
            mainMusicFragment = null;
            //隐藏滑动暂停按钮,并更改toolbar标题
            if (toolbar != null) {
                toolbar.removeAllViews();
                SimpleDateFormat formatter = new SimpleDateFormat(
                        "yyyy-MM-dd", Locale.getDefault());
                Date curDate = new Date(getSkipService().getSkipLogInfo().getStartTime());
                String sTime = formatter.format(curDate);
                setUiTitle(sTime);
            }
            if (slideButton != null) {
                slideButton.setVisibility(View.GONE);
                slideButton.setOnSlideListener(null);
                slideListener = null;
            }
            slideButton = null;
        }
    }

    /**
     * 放弃跳绳记录
     */
    private void quitSkipRecord() {
        //deleteRunLogInLocale();
        refreshSkipStatisticsInfo(false);
        finish();
    }

    /**
     * 保存并分享跳绳记录
     */
    private void saveSkipRecordAndShare() {
        saveAndShare = true;
        //1.截图
        if (finishFragment != null) {
            finishFragment.captureScreen();
        }
        //2.保存运动记录到服务器
        saveSkipLogInNet();

    }

    /**
     * 保存跳绳记录
     */
    private void saveSkipRecord() {
        saveAndShare = false;
        //1.保存运动记录到服务器
        saveSkipLogInNet();
    }

    //endregion ====================================== SkipMainFinish相关 ======================================

    //region ====================================== 分享相关 ======================================

    /**
     * 获取共享文件名
     */
    public String getShareFileName() {
        //TODO return shareFileName;
        return shareFileName;
    }

    /**
     * 跳绳运动成绩分享
     *
     * @param locale  分享图片的本地路径
     * @param sRemote 分享网页的地址
     */
    private void shareSkipScore(String locale, String sRemote) {
        if (getSkipLogInfo() == null) return;
        String skipNumber = String.format(getString(R.string.share_skip_number), getSkipLogInfo().getSkipNumber());
        String time = FormatUtil.formatTimeChinaStyle(getSkipLogInfo().getSkipTime() / 1000);
        String bpm = String.format(getString(R.string.share_skip_bpm), getSkipLogInfo().getBpm());
        String sTitle = String.format(getResources().getString(R.string.my_score), (int) getSkipLogInfo().getCalorie());// 分享标题
        String sContent = String.format(getResources().getString(R.string.share_skip_content), skipNumber, time, bpm);

        ShareManager share = new ShareManager(this);
        share.setContent(sContent);
        share.setFilename(locale);
        share.setTitle(sTitle);
        share.setUrl(sRemote);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_RUN_SCORE);//分享类别为运动成绩,用于友盟分享统计
        share.share();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case REQUEST_SELECT_MUSIC:
                if (resultCode == RESULT_OK) {
                    if (data == null) return;
                    String musicString = data.getStringExtra("musicString");
                    if (!TextUtils.isEmpty(musicString)) {
                        mMusicInfo = JsonHelper.getObject(musicString, Music.class);
                        if (mMusicInfo != null)
                            loadMusicBySelectId();
                    }
                }
                break;
            case AuthShareHelper.REQUESTCODE_QQ_SHARE:// QQ分享
            case AuthShareHelper.REQUESTCODE_QZONE_SHARE:// QQ空间分享
            case AuthShareHelper.REQUESTCODE_WECHAT_SHARE:// 微信分享
            case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE:// 微信朋友圈分享
            case AuthShareHelper.REQUESTCODE_SINA_SHARE:// 新浪微博分享
                if (data != null) {
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, 0);
                    String resultStr = data
                            .getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    if (!TextUtils.isEmpty(resultStr)) {
                        if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {//分享成功
                            showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            if (!finishShareRecordCoinTask()) {
                                delayFinishSkipMainActivity();//完成每日分享运动记录金币任务
                            }
                            return;
                        } else {
                            showAppMessage(resultStr, AppMsg.STYLE_INFO);
                        }
                    }
                }

                break;
            default:
                break;
        }

    }

    //endregion ====================================== 分享相关 ======================================

    private void gotoMusicList() {
        Intent intent = new Intent(this, CreatePlaylistActivity.class);
        intent.putExtra("single", true);
        startActivityForResult(intent, REQUEST_SELECT_MUSIC);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            ///////////////////////////// music fragment toolbar//////////////////////////////////////
            case R.id.btn_music_playlist://播放列表
                gotoMusicList();
                break;

            case R.id.btn_music_forward://音乐快进
                playNextSegment();
                break;

            ///////////////////////////// finish fragment toolbar///////////////////////////////////
            case R.id.btn_force_quit://放弃
                quitSkipRecord();
                break;

            case R.id.btn_save_share://保存并分享
                btn_save_share = (Button) findViewById(R.id.btn_save_share);
                btn_save_share.setEnabled(false);
                saveSkipRecordAndShare();
                break;

            case R.id.btn_save_only://仅保存
                saveSkipRecord();
                break;
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT://87
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS://88
            case KeyEvent.KEYCODE_MEDIA_PAUSE://127
            case KeyEvent.KEYCODE_MEDIA_PLAY://126
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE://85
            case KeyEvent.KEYCODE_HEADSETHOOK://79
                bResult = true;
                break;
        }
        if (!bResult)
            return super.onKeyDown(keyCode, event);
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSegment();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS://上一首,如果还在运动过程中,触发滑动暂停或继续
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                pauseVoice();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                continueVoice();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK:
                bResult = true;
                break;
        }
        if (!bResult)
            return super.onKeyUp(keyCode, event);
        return true;
    }

    private void loadMusicBySelectId() {
        //mMusicInfo = getMyConfig().getMemExchange().getCurrentMusic();
        bMusicPlayed = false;
        playMusic();
    }

    /**
     * 刷新运动总数据(运动时长,卡路里,跳绳个数,距离)
     *
     * @param bAdd 是否增加数量
     */
    private void refreshSkipStatisticsInfo(boolean bAdd) {
        SkipLogInfo skipLogInfo = null;
        if (getSkipService() != null)
            skipLogInfo = getSkipService().getSkipLogInfo();
        if (skipLogInfo == null)
            return;

        if (bAdd) {
            //1.更新在登录接口结果中的个人信息(运动总时长、总消耗、跳绳总个数、总距离)
            int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
            int requestId = -1;
            if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
                requestId = UserDataManager.getInstance().generateRequestId(2);
            } else if (loginType == 2) {//表示QQ授权登录
                requestId = UserDataManager.getInstance().generateRequestId(3);
            } else if (loginType == 3) {//表示微信授权登录
                requestId = UserDataManager.getInstance().generateRequestId(5);
            } else if (loginType == 4) {//表示新浪微博授权登录
                requestId = UserDataManager.getInstance().generateRequestId(4);
            }
            if (requestId > 0) {
                DataReqStatus dataReqStatus = DataReqStatusHelper.getInstance().getDataReqStatusById(requestId);
                if (dataReqStatus != null) {
                    String result = dataReqStatus.getResult();
                    Login login = JsonHelper.getObject(result, Login.class);
                    if (login != null && login.getUser() != null) {
                        SumSkipRope sumSkipRope = login.getUser().getSumSkipRope();
                        if (sumSkipRope == null) sumSkipRope = new SumSkipRope();
                        long totalSkipTime = sumSkipRope.getRunTime() + skipLogInfo.getSkipTime();//单位为毫秒 TODO 现在后台给的数值为毫秒值  以后不知道改不改
                        sumSkipRope.setRunTime(totalSkipTime);
                        long totalCalorie = sumSkipRope.getCalorie() + (int) skipLogInfo.getCalorie();
                        sumSkipRope.setCalorie(totalCalorie);
                        long totalSkipNumber = sumSkipRope.getSkipNum() + skipLogInfo.getSkipNumber();
                        sumSkipRope.setSkipNum(totalSkipNumber);
                        login.getUser().setSumSkipRope(sumSkipRope);
                        String newResult = JsonHelper.createJsonString(login);
                        if (!TextUtils.isEmpty(newResult)) {
                            dataReqStatus.setResult(newResult);
                            DataReqStatusHelper.getInstance().updateDataReqStatus(dataReqStatus);
                        }
                    }
                }
            }
        }
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        super.handlePermissionAllowed(permissionName);
        switch (permissionName) {
            case Manifest.permission.ACCESS_FINE_LOCATION:

                break;

            case Manifest.permission.WRITE_EXTERNAL_STORAGE:

                break;
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        super.handlePermissionForbidden(permissionName);
        switch (permissionName) {
            case Manifest.permission.ACCESS_FINE_LOCATION:

                break;

            case Manifest.permission.WRITE_EXTERNAL_STORAGE:

                break;
        }
    }


    //region ====================================== 金币任务相关 ======================================

    /**
     * 完成每日分享运动记录金币任务
     *
     * @return true:每日分享运动记录金币任务未完成,需要发送请求并接听回调结果,false:每日分享运动记录金币任务已完成
     */
    private boolean finishShareRecordCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_RECORD, 0);
        if (FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            return false;
        } else {
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareRecordCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
            return true;
        }
    }

    //endregion ====================================== 金币任务相关 ======================================

}
