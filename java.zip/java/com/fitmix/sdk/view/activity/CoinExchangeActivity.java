package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.bean.AccountInfo;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.CoinExchange;
import com.fitmix.sdk.model.api.bean.CoinTask;
import com.fitmix.sdk.model.api.bean.CoinTaskInfo;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.LiuMi;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.FlowOptionAdapter;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.ArrayList;
import java.util.List;

import static com.fitmix.sdk.R.string.activity_coin_exchange_success;

/**
 * 金币兑换界面
 */
public class CoinExchangeActivity extends BaseActivity {

    private EditText txt_phone;
    private TextView tv_phone_type;
    private int coinNumbers;//金币总量
    private Button btn_exchange;
    private int select_index = -1;//套餐选择下标序号

    private GridView gv_option;//动态选项
    private FlowOptionAdapter adapter;
    private List<LiuMi.ProductEntity.FlowEntity> dataSet;
    private View layout_consume;

    private TextView tv_total_coin_number;
    private TextView tv_consume_coin;
    /**
     * 电信
     */
    private List<LiuMi.ProductEntity.FlowEntity> telecom;
    /**
     * 联通
     */
    private List<LiuMi.ProductEntity.FlowEntity> unicom;
    /**
     * 移动
     */
    private List<LiuMi.ProductEntity.FlowEntity> cmcc;

    /**
     * 有效手机号码正则判断
     */
    String validPhone = "^(((13[0-9])|(15[^4,\\D])|(18[0-9])|(17[6-8])|(145))\\d{8})|(170[0,5,9])\\d{7}$";
    /**
     * 中国移动正则判断
     * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     */
    String cm = "^1(34[0-8]|70[356]|(3[5-9]|5[0127-9]|78|8[23478]|47)\\d)\\d{7}$";
    //"^1(34[0-8]|705|(3[5-9]|5[017-9]|78|8[278])\\d)\\d{7}$";
    /**
     * 中国联通正则判断
     * 130,131,132,152,155,156,185,186
     */
    String cu = "^1(70[489]|(3[0-2]|5[56]|8[56]|7[156])\\d)\\d{7}$";//"^1(709|(3[0-2]|5[256]|8[56]|76)\\d)\\d{7}$";
    /**
     * 中国电信正则判断
     * 133,1349,153,180,189
     */
    String ct = "^1(77\\d|(33|53|8[019])[0-9]|49\\d|70[012])\\d{7}$";//"^1(77\\d|(33|53|8[09])[0-9]|349|700)\\d{7}$";

    /**
     * 分享流量兑换结果奖励的金币数量,用于Dialog显示
     */
    private int mShareFlowResultCoin;

    /**
     * 兑换流量成功后的订单编号
     */
    private String mOrderNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_exchange);
        setPageName("CoinExchangeActivity");
        initToolbar();
        initViews();

        getCoinInfo();
        getLiuMiProduct();
        getShareFlowExchangeTask();
    }

    /**
     * 获取金币总量
     */
    private void getCoinInfo() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().getUserAccountInfo(uid, true);//忽略缓存
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取流米流量套餐兑换信息
     */
    private void getLiuMiProduct() {
        int requestId = UserDataManager.getInstance().getLiuMiProduct(false);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取分享兑换流量结果再次奖励金币信息
     */
    private void getShareFlowExchangeTask() {
        int requestId = UserDataManager.getInstance().getShareFlowExchangeTask(false);
        registerDataReqStatusListener(requestId);
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        txt_phone = (EditText) findViewById(R.id.txt_phone);
        txt_phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //不处理
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //不处理
            }

            @Override
            public void afterTextChanged(Editable s) {
                //判断手机类型
                String phone = s.toString();
                if (phone != null && phone.length() == 11) {
                    if (phone.matches(validPhone)) {
                        if (phone.matches(cm)) {//移动
                            addRadioOptions(cmcc);
                            if (tv_phone_type != null) {
                                tv_phone_type.setText(getString(R.string.activity_coin_exchange_phone_type_format1) +
                                        getString(R.string.activity_coin_exchange_phone_cmcc));
                            }
                        } else if (phone.matches(cu)) {//联通
                            addRadioOptions(unicom);
                            if (tv_phone_type != null) {
                                tv_phone_type.setText(getString(R.string.activity_coin_exchange_phone_type_format1) +
                                        getString(R.string.activity_coin_exchange_phone_cu));
                            }
                        } else if (phone.matches(ct)) {
                            addRadioOptions(telecom);
                            if (tv_phone_type != null) {
                                tv_phone_type.setText(getString(R.string.activity_coin_exchange_phone_type_format1) +
                                        getString(R.string.activity_coin_exchange_phone_ct));
                            }
                        }
                    }
                }
            }
        });
        tv_phone_type = (TextView) findViewById(R.id.tv_phone_type);
        dataSet = new ArrayList<>();
        adapter = new FlowOptionAdapter(this, dataSet);
        gv_option = (GridView) findViewById(R.id.gv_option);
        gv_option.setChoiceMode(GridView.CHOICE_MODE_SINGLE);
        gv_option.setAdapter(adapter);
        gv_option.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> gv, View v, int position,
                                    long id) {
                select_index = position;
                adapter.setSelectedPosition(position);
                adapter.notifyDataSetInvalidated();

                int quantity = adapter.getSelectedPositionQuantity();
                if (quantity <= 0) {//不选择
                    select_index = -1;
                    adapter.setSelectedPosition(-1);
                    showAppMessage(R.string.activity_coin_exchange_understock, AppMsg.STYLE_ALERT);//显示库存不足
                }

                if (layout_consume != null) {
                    layout_consume.setVisibility(View.VISIBLE);
                }

                if (tv_consume_coin != null) {
                    if (dataSet != null && position < dataSet.size()) {
                        tv_consume_coin.setText(String.valueOf(dataSet.get(position).getCoin()));
                    }
                }

            }
        });

        layout_consume = findViewById(R.id.layout_consume);
        btn_exchange = (Button) findViewById(R.id.btn_exchange);
        tv_total_coin_number = (TextView) findViewById(R.id.tv_total_coin_number);
        tv_consume_coin = (TextView) findViewById(R.id.tv_consume_coin);

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "CoinExchangeActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 50://获取用户信息,金币总量,今日签到状态等
                AccountInfo accountInfo = JsonHelper.getObject(result, AccountInfo.class);
                if (accountInfo != null) {
                    if (accountInfo.getAccount() != null) {//总金币
                        coinNumbers = accountInfo.getAccount().getCoin();
                        if (adapter != null) {
                            adapter.setCoinNumbers(coinNumbers);
                            adapter.notifyDataSetChanged();
                        }
                        if (tv_total_coin_number != null) {
                            tv_total_coin_number.setText(String.valueOf(coinNumbers));
                        }
                    }
                }
                break;

            case Config.MODULE_USER + 53://获取流米流量套餐兑换信息
                LiuMi liuMi = JsonHelper.getObject(result, LiuMi.class);
                if (liuMi != null && liuMi.getProduct() != null) {
                    telecom = liuMi.getProduct().getDX();//电信
                    unicom = liuMi.getProduct().getLT();//联通
                    cmcc = liuMi.getProduct().getYD();//移动

                    addRadioOptions(cmcc);//默认先显示移动的套餐
                }
                break;

            case Config.MODULE_USER + 54://兑换流米流量套餐
                if (btn_exchange != null) {
                    btn_exchange.setEnabled(true);
                }
                hideLoadingDialog();

                getCoinInfo();//重新获取金币总数

                //弹出是否分享
                CoinExchange coinExchange = JsonHelper.getObject(result, CoinExchange.class);
                if (coinExchange != null) {
                    CoinExchange.LiumiOrderEntity liumiOrderEntity = coinExchange.getLiumiOrder();
                    if (liumiOrderEntity != null) {
                        mOrderNo = liumiOrderEntity.getOrderNo();
                        int uid = liumiOrderEntity.getUid();
                        String packageType = liumiOrderEntity.getPostpackage();//流量套餐类型
                        if (mOrderNo != null && uid > 0 && packageType != null) {
                            shareExchangeSuccessDialog(uid, packageType);
                        }
                    }
                } else {
                    showAppMessage(activity_coin_exchange_success, AppMsg.STYLE_INFO);
                }
                break;

            case Config.MODULE_USER + 65://完成分享流量兑换金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;

            case Config.MODULE_USER + 70://获取分享兑换流量结果金币任务信息
                CoinTask coinTask = JsonHelper.getObject(result, CoinTask.class);
                if (coinTask != null) {
                    CoinTaskInfo coinTaskInfo = coinTask.getTaskInfo();
                    if (coinTaskInfo != null) {
                        mShareFlowResultCoin = coinTaskInfo.getCoin();
                    }
                }
                break;

        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            switch (requestId) {
                case Config.MODULE_USER + 54://兑换流米流量套餐
                    hideLoadingDialog();
                    if (btn_exchange != null) {
                        btn_exchange.setEnabled(true);
                    }
                    if (errorCode == 8001) {//金币不足
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    } else if (errorCode == 8002) {//库存不足
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    } else if (errorCode == 8004) {//下单失败
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                    showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    break;
            }
        }
    }

    /**
     * 动态添加套餐选项
     */
    private void addRadioOptions(List<LiuMi.ProductEntity.FlowEntity> flowEntity) {
        select_index = -1;
        dataSet.clear();
        if (flowEntity != null) {
            for (LiuMi.ProductEntity.FlowEntity entity : flowEntity) {
                LiuMi.ProductEntity.FlowEntity newEntity = new LiuMi.ProductEntity.FlowEntity();
                newEntity.setAddTime(entity.getAddTime());
                newEntity.setCoin(entity.getCoin());
                newEntity.setId(entity.getId());
                newEntity.setModifyTime(entity.getModifyTime());
                newEntity.setName(entity.getName());
                newEntity.setQuantity(entity.getQuantity());
                newEntity.setType(entity.getType());
                newEntity.setStatus(entity.getStatus());
                newEntity.setVirtualKey(entity.getVirtualKey());
                dataSet.add(newEntity);
            }
        }

        if (layout_consume != null) {
            layout_consume.setVisibility(View.GONE);
        }

        if (tv_consume_coin != null) {
            tv_consume_coin.setText("");
        }

        if (adapter != null) {
            adapter.setSelectedPosition(select_index);
            adapter.notifyDataSetChanged();
        }

    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_exchange:
                if (select_index == -1) {
                    showAppMessage(R.string.activity_coin_exchange_invalid_select, AppMsg.STYLE_ALERT);
                    return;
                }
                String phone = txt_phone.getText().toString();
                if (phone != null && phone.matches(validPhone)) {
                    if (dataSet != null && select_index != -1 && select_index < dataSet.size()) {
                        int id = dataSet.get(select_index).getId();
                        Logger.i(Logger.DEBUG_TAG, "exchange phone:" + phone + ",id:" + id);
                        exchange(phone, id);
                    }
                } else {
                    showAppMessage(R.string.activity_coin_exchange_invalid_phone, AppMsg.STYLE_ALERT);
                    txt_phone.requestFocus();
                }
                break;
        }
    }

    /**
     * 流量兑换
     */
    private void exchange(String phone, int productId) {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().exchange(uid, phone, productId, true);
        registerDataReqStatusListener(requestId);
        if (btn_exchange != null) {
            btn_exchange.setEnabled(false);
        }

        showLoadingDialog(R.string.busying, 1000);
    }


    /**
     * 展示流量兑换成功,继续分享对话框
     *
     * @param uid         用户uid,用于生成分享信息
     * @param packageType 兑换成功的套餐类型
     */
    private void shareExchangeSuccessDialog(final int uid, String packageType) {
        View convertView = getLayoutInflater().inflate(R.layout.dialog_share_coin_exchange_success, null);
        TextView content = (TextView) convertView.findViewById(R.id.tv_content);
        TextView shareCoinReward = (TextView) convertView.findViewById(R.id.tv_share_coin_reward);
        String format1 = getString(R.string.activity_coin_exchange_congrats);
        String format2 = getString(R.string.activity_coin_exchange_flow);
        if (!TextUtils.isEmpty(packageType) && (packageType.startsWith("DX")
                || packageType.startsWith("LT")
                || packageType.startsWith("YD"))) {
            content.setText(Html.fromHtml(format1 + "<font color=\"#FF5722\">" + packageType.substring(2) + "M" + "</font>" + format2));
        }

        String format3 = getString(R.string.activity_coin_exchange_share_reward);
        String format4 = getString(R.string.activity_coin_exchange_coin);
        shareCoinReward.setText(Html.fromHtml(format3 + "<font color=\"#FF5722\">" + mShareFlowResultCoin + "</font>" + format4));

        new MaterialDialog.Builder(this)
                .title(R.string.activity_coin_exchange_success)
                .customView(convertView, false)
                .positiveText(R.string.activity_coin_exchange_share)
                .negativeText(R.string.activity_coin_exchange_cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case NEGATIVE:
                                delayFinishCoinExchangeActivity();//关闭Activity
                                break;

                            case POSITIVE:
                                String shareUrl = ApiConstants.getCoinExchangeShare(uid, mOrderNo);
                                share(shareUrl);
                                break;
                        }

                    }
                }).show();
    }


    /**
     * 运动成绩分享
     *
     * @param shareUrl 分享网页的地址
     */
    private void share(String shareUrl) {
        ShareManager share = new ShareManager(this);
        share.setTitle(getString(R.string.activity_coin_exchange_share_title));
        share.setContent(getString(R.string.activity_coin_exchange_share_content));
        share.setUrl(shareUrl);
        share.setFilename(ShareManager.DEFAULT_FILE_NAME);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_OTHER);//分享类别为其它
        share.share();
    }

    /**
     * 1.5秒后销毁activity
     */
    private void delayFinishCoinExchangeActivity() {
        ThreadManager.getMainHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (CoinExchangeActivity.this.isFinishing()) {
                    return;
                }
                finish();
            }
        }, 1000);//1秒后销毁activity
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareExchangeCoinTask();
                            }
                            break;
                    }
                }
                break;
        }
    }

    /**
     * 完成分享流量兑换金币任务
     */
    private void finishShareExchangeCoinTask() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().finishShareExchangeCoinTask(uid, mOrderNo, true);
        registerDataReqStatusListener(requestId);
    }


}
