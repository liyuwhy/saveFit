package com.fitmix.sdk.view.activity;


import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.model.api.bean.VoicePackageFileInfo;
import com.fitmix.sdk.model.api.bean.VoicePackageInfo;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.DownloadInfoHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.view.adapter.VoicePackageAdapter;
import com.fitmix.sdk.view.dialog.VoiceActionDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.VoiceStateButton;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VoiceManagerActivity extends BaseActivity {

    private VoicePackageAdapter voicePackageAdapter;
    private ServiceConnection serviceConnection;
    private DownloadService mService;
    private DownloadInfoListener downloadListener;
    private long tempTime;
    private ListView listView;
    private VoiceStateButton voice_package_state;
    private SwipeLoadLayout voice_swipeLayout;
    private SwipeLoadLayout.OnRefreshListener mVoiceRefreshListener;
    private int sportType;//运动类型，1：跑步，2：跳绳，0未无效
    private Handler mHandler;
    //    private int standardFemaleVoicePosition = 0;
//    private boolean isStandardFemaleVoice = false;
    private List<VoicePackageInfo.VoicesBean> voicePacketsBeanLocalList;
    public long totalSize;
    private int newestVersion = 0;

    public int getNewestVersion() {
        return newestVersion;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    private Handler getHandler() {
        if (mHandler == null) {
            mHandler = new Handler(Looper.getMainLooper()) {
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case 1:
                            getVoicePackageAdapter().notifyDataSetChanged();
                            break;
                        default:
                            break;
                    }
                }
            };
        }
        return mHandler;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_siri_type);
        setPageName("VoiceManagerActivity");
        initToolbar();
        initViews();
        bindDownloadService();
        getVoicePackageInfo(false);

    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        voice_package_state = (VoiceStateButton) findViewById(R.id.voice_package_state);
        voice_package_state.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VoiceStateButton voiceButton = (VoiceStateButton) v;
                if (voiceButton.getState() == VoiceStateButton.VOICE_PACKAGE_STATE_USE) {
                    SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
                    SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_VOICE_TYPE, "");
                    voiceButton.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USING);
                    getVoicePackageAdapter().notifyDataSetChanged();
                }
            }
        });

        voice_swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
        mVoiceRefreshListener = new SwipeLoadLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getVoicePackageInfo(false);
            }
        };
        voice_swipeLayout.setOnRefreshListener(mVoiceRefreshListener);

        refreshVoicePackageUseState();

        listView = (ListView) findViewById(R.id.swipe_target);
        listView.setAdapter(getVoicePackageAdapter());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        downloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                //不处理
                long time = System.currentTimeMillis();
                if ((time - tempTime) > 1000) {
                    String url = downloadInfo.getRemoteUrl();
                    int index = getVoicePackageAdapter().getCurrentDataIndex(url);
                    totalSize = downloadInfo.getTotalSize();
                    setTotalSize(totalSize);
                    updateViewOnDownloading(index, totalSize);
                    //Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onDownloading()");
                    //getVoicePackageAdapter().notifyDataSetChanged();
                    tempTime = time;
                    Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onDownloading()");
                }
            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {
                //不处理
                if (downloadInfo != null) {
                    String url = downloadInfo.getRemoteUrl();
                    int index = getVoicePackageAdapter().getCurrentDataIndex(url);
                    updateViewOnPause(index);
                }
            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onCompleted()");
                if (downloadInfo != null) {
                    String url = downloadInfo.getRemoteUrl();
                    int index = getVoicePackageAdapter().getCurrentDataIndex(url);
                    updateViewOnDownloaded(index);
                    SettingsHelper.putInt(Config.SETTING_VOICE_PACKAGE_INFO_VERSION, newestVersion);
                }
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                //不处理
                if (downloadInfo != null) {
                    String url = downloadInfo.getRemoteUrl();
                    VoicePackageInfo.VoicesBean voicePacketsBean = getVoicePackageAdapter().getCurrentData(url);
                    if (voicePacketsBean != null && !TextUtils.isEmpty(voicePacketsBean.getTitle())) {
                        showAppMessage(voicePacketsBean.getTitle() + "下载失败", AppMsg.STYLE_CONFIRM);
                    }
                }
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                //不处理
            }
        };

    }

    /**
     * 获取当前运动方式
     */
    private int getSportType() {
        if (sportType == 0) {
            sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_ALL);
        }
        return sportType;
    }

    private String getSportTypePath() {
        String sportTypePath;
        switch (getSportType()) {
            case Config.SPORT_TYPE_RUN:
                sportTypePath = Config.PATH_LOCAL_VOICE_RUN;
                break;
            case Config.SPORT_TYPE_SKIP:
                sportTypePath = Config.PATH_LOCAL_VOICE_SKIP;
                break;
            case Config.SPORT_TYPE_ALL:
                sportTypePath = Config.PATH_LOCAL_VOICE;
                break;
            default:
                sportTypePath = Config.PATH_LOCAL_VOICE;
        }
        return sportTypePath;
    }

    /**
     * @param showDialog 是否显示加载框
     */
    private void getVoicePackageInfo(boolean showDialog) {
        if (showDialog) {
            showLoadingDialog(R.string.activity_voice_manager_loading, 1000);
        }
        int requestId = SportDataManager.getInstance().getVoicePackageInfo(getSportType());
        registerDataReqStatusListener(requestId);
    }

    private void refreshVoicePackageUseState() {
        if (voice_package_state != null) {
            String voiceType = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
            Logger.d(Logger.DEBUG_TAG, "voiceType:" + voiceType);
            if (voiceType.equals("female")) {
                voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USING);
            } else {
                voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USE);
            }
        }
    }


    private void updateViewOnPause(int itemIndex) {
        //得到第一个可显示控件的位置，
        int visiblePosition = listView.getFirstVisiblePosition();
        //只有当要更新的view在可见的位置时才更新，不可见时，跳过不更新
        if ((itemIndex - visiblePosition) >= 0 && (itemIndex - visiblePosition) < listView.getChildCount()) {
            //得到要更新的item的view
            View view = listView.getChildAt(itemIndex - visiblePosition);
            //从view中取得holder
            VoicePackageAdapter.ViewHolder holder = (VoicePackageAdapter.ViewHolder) view.getTag();
            holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_CONTINUE);
        }
    }

    private void updateViewOnDownloaded(int itemIndex) {
        //得到第一个可显示控件的位置，
        int visiblePosition = listView.getFirstVisiblePosition();
        //只有当要更新的view在可见的位置时才更新，不可见时，跳过不更新
        if ((itemIndex - visiblePosition) >= 0 && (itemIndex - visiblePosition) < listView.getChildCount()) {
            //得到要更新的item的view
            View view = listView.getChildAt(itemIndex - visiblePosition);
            //从view中取得holder
            VoicePackageAdapter.ViewHolder holder = (VoicePackageAdapter.ViewHolder) view.getTag();
            holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USE);
            holder.voice_package_download_progress.setProgress(0);
        }
    }

    private void updateViewOnDownloading(int itemIndex, long totalSize) {
        //得到第一个可显示控件的位置，
        int visiblePosition = listView.getFirstVisiblePosition();
        //只有当要更新的view在可见的位置时才更新，不可见时，跳过不更新
        if ((itemIndex - visiblePosition) >= 0 && (itemIndex - visiblePosition) < listView.getChildCount()) {
            //得到要更新的item的view
            View view = listView.getChildAt(itemIndex - visiblePosition);
            //从view中取得holder
            VoicePackageAdapter.ViewHolder holder = (VoicePackageAdapter.ViewHolder) view.getTag();
            VoicePackageInfo.VoicesBean voicePacketsBean = getVoicePackageAdapter().getVoicePackageList().get(itemIndex);
            if (voicePacketsBean != null && !TextUtils.isEmpty(voicePacketsBean.getFileLink())) {
                try {
                    String name = voicePacketsBean.getFileLink().substring(voicePacketsBean.getFileLink().lastIndexOf("/"), (voicePacketsBean.getFileLink().length()));
                    File localPath = new File(Config.PATH_LOCAL_VOICE + name);//下载完成的文件
                    File tmpPath = new File(Config.PATH_LOCAL_VOICE + name + ".tmp");//下载中的文件
                    if (localPath.exists()) {//如果存在该压缩文件
                        holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USE);
                        holder.voice_package_download_progress.setProgress(0);

                    } else {
                        if (tmpPath.exists()) {
                            long length = tmpPath.length();
                            Logger.d(Logger.DEBUG_TAG, "tmpSize:" + length);
                            Logger.d(Logger.DEBUG_TAG, "fileSize:" + totalSize);
                            if (length < totalSize) {
                                holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_PAUSE);
                                holder.voice_package_download_progress.setProgress((float) (length * 100) / totalSize);
                            } else {
                                holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_USE);
                                holder.voice_package_download_progress.setProgress(0);
                            }
                        } else {
                            holder.voice_package_state.setState(VoiceStateButton.VOICE_PACKAGE_STATE_DOWNLOAD);
                            holder.voice_package_download_progress.setProgress(0);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getCurrentState(int itemIndex) {
        //得到第一个可显示控件的位置，
        int visiblePosition = listView.getFirstVisiblePosition();
        //只有当要更新的view在可见的位置时才更新，不可见时，跳过不更新
        if (itemIndex - visiblePosition >= 0) {
            //得到要更新的item的view
            View view = listView.getChildAt(itemIndex - visiblePosition);
            //从view中取得holder
            VoicePackageAdapter.ViewHolder holder = (VoicePackageAdapter.ViewHolder) view.getTag();
            return holder.voice_package_state.getState();
        } else {
            return -1;
        }
    }

    /**
     * 绑定下载服务
     */
    private void bindDownloadService() {
        //创建 语音包文件
        FileUtils.makeDirs(Config.PATH_LOCAL_VOICE);
        Intent intent = new Intent(this, DownloadService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onServiceConnected");
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mService = ((DownloadService.GetServiceClass) service).getService();
                    if (mService == null)
                        return;

                    if (downloadListener != null) {//注册下载状态监听
                        Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->onServiceConnected addDownloadListener");
                        mService.addDownloadListener(downloadListener);
                    }

                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mService == null)
                        return;
                    if (downloadListener != null) {//注销下载状态监听
                        mService.removeDownloadListener(downloadListener);
                    }
                }
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        unbindDownloadService();
        super.onDestroy();
    }

    /**
     * 解绑下载服务
     */
    private void unbindDownloadService() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        serviceConnection = null;
        downloadListener = null;
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private VoicePackageAdapter getVoicePackageAdapter() {
        if (voicePackageAdapter == null) {
            voicePackageAdapter = new VoicePackageAdapter(this);
            voicePackageAdapter.setOnVoiceButtonClickListener(new VoicePackageAdapter.VoiceButtonClickListener() {
                @Override
                public void onClick(VoiceStateButton voiceButton, VoicePackageInfo.VoicesBean voicePacketsBean) {
                    if (voicePacketsBean != null)
                        processEvent(voiceButton, voicePacketsBean);
                }

                @Override
                public void onActionClick(int position, VoicePackageInfo.VoicesBean voicePacketsBean) {
                    if (voicePacketsBean != null)
                        showActionDialog(position, voicePacketsBean);
                }
            });
        }
        return voicePackageAdapter;
    }

    /**
     * 处理按钮的点击事件
     *
     * @param voiceButton      按钮
     * @param voicePacketsBean 语音包信息
     */
    private void processEvent(VoiceStateButton voiceButton, VoicePackageInfo.VoicesBean voicePacketsBean) {
        int state = voiceButton.getState();
        switch (state) {
            case VoiceStateButton.VOICE_PACKAGE_STATE_USE:
                unzipFile(voicePacketsBean);//解压下载的语音压缩文件
                break;
            case VoiceStateButton.VOICE_PACKAGE_STATE_USING:
                break;
            case VoiceStateButton.VOICE_PACKAGE_STATE_DOWNLOAD:
                downloadVoicePackage(voicePacketsBean);
                break;
            case VoiceStateButton.VOICE_PACKAGE_STATE_PAUSE:
                if (mService != null) {
                    mService.pauseDownload(voicePacketsBean.getFileLink());
                }
                break;
            case VoiceStateButton.VOICE_PACKAGE_STATE_CONTINUE:
                if (mService != null) {
                    mService.resumeDownload(voicePacketsBean.getFileLink());
                }
                break;
            case VoiceStateButton.VOICE_PACKAGE_STATE_UPDATE:
                deleteVoicePackage(voicePacketsBean);
                downloadVoicePackage(voicePacketsBean);
                break;
        }
    }

    /**
     * 显示操作dialog
     *
     * @param position         语音包的位置 用于获得当前语音包的状态
     * @param voicePacketsBean 语音包
     */
    private void showActionDialog(final int position, final VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean == null) {
            return;
        }

        VoiceActionDialog voiceActionDialog = new VoiceActionDialog();
        voiceActionDialog.setVoicePacgkegeState(getCurrentState(position));
        voiceActionDialog.setVoicePackageName(voicePacketsBean.getTitle());
        voiceActionDialog.setOnActionClickListener(new VoiceActionDialog.ActionTypeClickListener() {
            @Override
            public void onActionClick(int state, int type) {//根据选择的按钮不同 选择不同的回调方法
                doMoreAction(state, type, voicePacketsBean);
            }
        });
        voiceActionDialog.show(this.getSupportFragmentManager(), "voiceActionDialog");
    }

    private void doMoreAction(int state, int type, VoicePackageInfo.VoicesBean voicePacketsBean) {
        switch (type) {
            case VoiceActionDialog.ACTION_TYPE_POSITIVE:

                switch (state) {
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_USE://使用
                        unzipFile(voicePacketsBean);//解压下载的语音压缩文件
                        break;
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_DOWNLOAD://下载语音包
                        downloadVoicePackage(voicePacketsBean);
                        break;
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_PAUSE://暂停下载
                        if (mService != null) {
                            mService.pauseDownload(voicePacketsBean.getFileLink());
                        }
                        break;
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_CONTINUE://继续下载
                        if (mService != null) {
                            mService.resumeDownload(voicePacketsBean.getFileLink());
                        }
                        break;
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_UPDATE://更新语音包
                        deleteVoicePackage(voicePacketsBean);
                        downloadVoicePackage(voicePacketsBean);
                        break;
                }
                break;
            case VoiceActionDialog.ACTION_TYPE_NEGATIVE:
                switch (state) {
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_USE:
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_USING://删除语音包
                        deleteVoicePackage(voicePacketsBean);
                        break;
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_PAUSE://取消下载
                    case VoiceActionDialog.VOICE_PACKAGE_STATE_CONTINUE://取消下载
                        deleteTmpVoicePackage(voicePacketsBean);
                        break;
                }
                break;
        }
    }

    /**
     * 下载语音包
     *
     * @param voicePacketsBean
     */
    private void downloadVoicePackage(VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean != null && !TextUtils.isEmpty(voicePacketsBean.getFileLink())) {
            DownloadInfo ll = DownloadInfoHelper.getDownloadInfoByUrl(voicePacketsBean.getFileLink());
            if (ll != null) {
                MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().delete(ll);
            }
            try {
                int index = voicePacketsBean.getFileLink().lastIndexOf("/");
                if (index != -1) {
                    String name = voicePacketsBean.getFileLink().substring(index, (voicePacketsBean.getFileLink().length()));
                    DownloadService.makeDownload(this, voicePacketsBean.getFileLink(), Config.PATH_LOCAL_VOICE + name, DownloadType.TYPE_ALL);
                    setVoicePackageInfo(voicePacketsBean);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 删除语言包(包括压缩文件 和 解析出来的文件)
     *
     * @param voicePacketsBean
     */
    private void deleteVoicePackage(VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean != null && !TextUtils.isEmpty(voicePacketsBean.getFileLink())) {
            DownloadInfo ll = DownloadInfoHelper.getDownloadInfoByUrl(voicePacketsBean.getFileLink());
            if (ll != null) {
                MixApp.getDaoSession(MixApp.getContext()).getDownloadInfoDao().delete(ll);
            }
            try {
                int index = voicePacketsBean.getFileLink().lastIndexOf("/");
                if (index != -1) {
                    String name = voicePacketsBean.getFileLink().substring(index, (voicePacketsBean.getFileLink().length()));
                    String zipPath = Config.PATH_LOCAL_VOICE + name;
                    String filePath = getSportTypePath() + voicePacketsBean.getDirName();
                    FileUtils.deleteFile(zipPath);//删除压缩文件
                    FileUtils.deleteFile(filePath);//删除解压文件
                }
                deletePackageInfo(voicePacketsBean);//从数据库中删除
                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_VOICE_TYPE, "");
                getVoicePackageAdapter().notifyDataSetChanged();
                refreshVoicePackageUseState();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 删除下载中的临时文件
     *
     * @param voicePacketsBean
     */
    private void deleteTmpVoicePackage(VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean != null && !TextUtils.isEmpty(voicePacketsBean.getFileLink())) {
            if (mService != null) {
                mService.cancelDownload(voicePacketsBean.getFileLink());
            }
            try {
                int index = voicePacketsBean.getFileLink().lastIndexOf("/");
                if (index != -1) {
                    String name = voicePacketsBean.getFileLink().substring(index, (voicePacketsBean.getFileLink().length()));
                    if (!TextUtils.isEmpty(name)) {
                        String tmpPath = Config.PATH_LOCAL_VOICE + name + ".tmp";
                        FileUtils.deleteFile(tmpPath);//删除下载的临时文件
                        deletePackageInfo(voicePacketsBean);//从数据库中删除
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusRESULT_OK-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_SPORT + 8://获得语音包下载的列表信息
                processRequestData(dataReqResult.getResult());
                break;

            case Config.MODULE_SPORT + 9://获得语音包下载用的地址url信息
                VoicePackageFileInfo voicePackageFileInfo = JsonHelper.getObject(dataReqResult.getResult(), VoicePackageFileInfo.class);
                if (voicePackageFileInfo != null) {
                    VoicePackageFileInfo.FileBean file = voicePackageFileInfo.getFile();
                    if (file != null) {
                        VoicePackageFileInfo.FileBean.OtherBean otherInfo = file.getOther();
                        if (otherInfo != null) {
                            int voiceId = otherInfo.getVoiceId();
                            for (VoicePackageInfo.VoicesBean voicesBean : voicePacketsBeanLocalList) {
                                if (voiceId == voicesBean.getId()) {
                                    voicesBean.setFileLink(file.getFileLink());
                                    voicesBean.setSize(file.getOther().getSize());
                                    voicesBean.setDirName(file.getOther().getDirName());
                                    newestVersion = otherInfo.getVersion();
                                    voicesBean.setVersion(newestVersion);
                                }
                            }
                        }
                        getHandler().sendEmptyMessage(1);
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_SPORT + 8://获得语音包下载的列表信息
                String result = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_SPORT + 8);
                if (!TextUtils.isEmpty(result))
                    processRequestData(result);
                break;
        }
        super.processReqError(requestId, error);
    }

    private void processRequestData(String sResult) {
        if (voice_swipeLayout != null) {
            voice_swipeLayout.setRefreshing(false);
        }
        hideLoadingDialog();
        voicePacketsBeanLocalList = getVoicePackageInfoList();

        List<Integer> voicePacketsBeanIdList = new ArrayList<>();
        List<VoicePackageInfo.VoicesBean> voicePacketsBeanList = new ArrayList<>();
        List<VoicePackageInfo.VoicesBean> voicePacketsBeanTmpList = new ArrayList<>();

        if (voicePacketsBeanLocalList.size() > 0) {
            for (int i = 0; i < voicePacketsBeanLocalList.size(); i++) {
                voicePacketsBeanIdList.add(voicePacketsBeanLocalList.get(i).getId());
            }
        }

        if (!TextUtils.isEmpty(sResult)) {
            VoicePackageInfo voicePackageInfo = JsonHelper.getObject(sResult, VoicePackageInfo.class);
            if (voicePackageInfo != null) {
                voicePacketsBeanList = voicePackageInfo.getVoices();
                if (voicePacketsBeanList != null && voicePacketsBeanList.size() > 0) {
                    for (int i = 0; i < voicePacketsBeanList.size(); i++) {
                        int id = voicePacketsBeanList.get(i).getId();
                        if (voicePackageInfo.getVoices().get(i).getTitle().contains("标准女声")) {//下载标准女声fileZip信息
//                            isStandardFemaleVoice = true;
//                            standardFemaleVoicePosition = i;
                            int requestId = SportDataManager.getInstance().getVoicePackageUrlInfo(id);
                            registerDataReqStatusListener(requestId);
                        } else {
//                            isStandardFemaleVoice = false;
//                            standardFemaleVoicePosition = i;
                            int requestId = SportDataManager.getInstance().getVoicePackageUrlInfo(id);
                            registerDataReqStatusListener(requestId);
                        }

                        if (voicePacketsBeanIdList.contains(id))
                            voicePacketsBeanTmpList.add(voicePacketsBeanList.get(i));
                    }
                    voicePacketsBeanList.removeAll(voicePacketsBeanTmpList);//删除重复的
                } else {
                    voicePacketsBeanList = new ArrayList<>();
                }
            }
        }

        voicePacketsBeanLocalList.addAll(voicePacketsBeanList);//本地加入网络请求的
        getVoicePackageAdapter().setVoiceInfoList(voicePacketsBeanLocalList);
    }

    /**
     * 获取数据库中的已下载全部语音包列表
     *
     * @return
     */
    private List<VoicePackageInfo.VoicesBean> getVoicePackageInfoListInLocal() {
        String dbString = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_INFO, "");
        if (!TextUtils.isEmpty(dbString)) {
            Logger.i(Logger.DEBUG_TAG, "VoiceManagerActivity-->getVoicePackageInfoListInLocal()" + dbString);
            VoicePackageInfo voicePackageInfo = JsonHelper.getObject(dbString, VoicePackageInfo.class);
            if (voicePackageInfo != null) {
                List<VoicePackageInfo.VoicesBean> voicePacketsBeanList = voicePackageInfo.getVoices();
                if (voicePacketsBeanList == null) voicePacketsBeanList = new ArrayList<>();
                return voicePacketsBeanList;
            }
        }
        VoicePackageInfo voicePackageInfo = JsonHelper.getObject(dbString, VoicePackageInfo.class);
        if (voicePackageInfo != null) {
            List<VoicePackageInfo.VoicesBean> voicePacketsBeanList = voicePackageInfo.getVoices();
            if (voicePacketsBeanList == null) voicePacketsBeanList = new ArrayList<>();
            return voicePacketsBeanList;
        }
        return new ArrayList<>();
    }

    /**
     * 获取数据库中的已下载全部语音包列表
     *
     * @return
     */
    private List<VoicePackageInfo.VoicesBean> getVoicePackageInfoList() {
        List<VoicePackageInfo.VoicesBean> list = getVoicePackageInfoListInLocal();
        List<VoicePackageInfo.VoicesBean> tempList = new ArrayList<>();
        if (list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                VoicePackageInfo.VoicesBean item = list.get(i);
                if (item != null) {
                    tempList.add(item);
                }
            }
            return tempList;
        }
        return list;
    }

    /**
     * 删除数据库中语音包信息
     *
     * @param voicePacketsBean
     */
    private void deletePackageInfo(VoicePackageInfo.VoicesBean voicePacketsBean) {
        List<VoicePackageInfo.VoicesBean> voicePacketsBeanList = getVoicePackageInfoListInLocal();

        VoicePackageInfo.VoicesBean voicePacketsBeanTmp = null;
        if (voicePacketsBeanList.size() > 0) {
            for (int i = 0; i < voicePacketsBeanList.size(); i++) {
                int id = voicePacketsBeanList.get(i).getId();
                if (id == voicePacketsBean.getId()) {
                    voicePacketsBeanTmp = voicePacketsBeanList.get(i);
                    break;
                }
            }
        }
        voicePacketsBeanList.remove(voicePacketsBeanTmp);//删除
        if (voicePacketsBeanList.size() > 0) {
            StringBuilder stringBuilder = new StringBuilder("{voices:[");//voicePackets
            for (int i = 0; i < voicePacketsBeanList.size(); i++) {
                String voiceInfoString = JsonHelper.createJsonString(voicePacketsBeanList.get(i));
                if (!TextUtils.isEmpty(voiceInfoString)) {
                    if (i > 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append(voiceInfoString);
                }
            }
            stringBuilder.append("]}");
            SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_INFO, stringBuilder.toString());
        } else {
            SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_INFO, "");
        }
    }

    /**
     * 把下载过的语音包信息加入到本地数据库
     *
     * @param voicePacketsBean
     */
    private void setVoicePackageInfo(VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean == null) return;
        List<VoicePackageInfo.VoicesBean> voicePacketsBeanList = getVoicePackageInfoListInLocal();
        if (voicePacketsBeanList.size() > 0) {
            for (int i = 0; i < voicePacketsBeanList.size(); i++) {
                int id = voicePacketsBeanList.get(i).getId();
                if (id == voicePacketsBean.getId()) {
                    return;
                }
            }
        }
        StringBuilder stringBuilder = new StringBuilder("{voices:[");//voicePackets
        voicePacketsBeanList.add(voicePacketsBean);
        for (int i = 0; i < voicePacketsBeanList.size(); i++) {
            String voiceInfoString = JsonHelper.createJsonString(voicePacketsBeanList.get(i));
            if (!TextUtils.isEmpty(voiceInfoString)) {
                if (i > 0) {
                    stringBuilder.append(",");
                }
                stringBuilder.append(voiceInfoString);
            }
        }
        stringBuilder.append("]}");
        String info = stringBuilder.toString();
        SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_INFO, info);
    }

    /**
     * 解压文件
     *
     * @param voicePacketsBean
     */
    private void unzipFile(VoicePackageInfo.VoicesBean voicePacketsBean) {
        if (voicePacketsBean != null
                && !TextUtils.isEmpty(voicePacketsBean.getDirName()) && !TextUtils.isEmpty(voicePacketsBean.getFileLink())) {

            String voiceInfoPath = getSportTypePath() + voicePacketsBean.getDirName() + File.separator;
            File file = new File(voiceInfoPath);
            if (file.exists()) {
                Logger.d(Logger.DEBUG_TAG, "语音包路径:" + voiceInfoPath);
                //语音包femaleVoiceEn路径
                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_DIR, voiceInfoPath);

                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_TYPE, voicePacketsBean.getDirName());
                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_VOICE_TYPE, voicePacketsBean.getDirName());
                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_NAME, voicePacketsBean.getTitle());
                getVoicePackageAdapter().notifyDataSetChanged();
                refreshVoicePackageUseState();
            } else {
                try {
                    int index = voicePacketsBean.getFileLink().lastIndexOf("/");
                    if (index != -1) {
                        String name = voicePacketsBean.getFileLink().substring(index, (voicePacketsBean.getFileLink().length()));
                        if (!TextUtils.isEmpty(Config.PATH_LOCAL_VOICE + name)) {
                            File localPath = new File(Config.PATH_LOCAL_VOICE + name);//下载完成的文件
                            boolean isUnzipSuccess = FileUtils.unZipFiles(localPath, getSportTypePath());
                            if (isUnzipSuccess) {//解压成功
                                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_DIR, voiceInfoPath);
                                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_TYPE, voicePacketsBean.getDirName());
                                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_VOICE_TYPE, voicePacketsBean.getDirName());
                                SettingsHelper.putString(Config.SETTING_VOICE_PACKAGE_NAME, voicePacketsBean.getTitle());
                                getVoicePackageAdapter().notifyDataSetChanged();
                                refreshVoicePackageUseState();
                            } else {//解压失败
                                showAppMessage("文件解析出错，请重新下载", AppMsg.STYLE_ALERT);
                                deleteVoicePackage(voicePacketsBean);
                            }
                        }
                    }
                } catch (Exception e) {
                    showAppMessage("文件解析出错，请重新下载", AppMsg.STYLE_ALERT);
                    deleteVoicePackage(voicePacketsBean);
                }
            }
        } else {
            showAppMessage("语音包名称解析为空", AppMsg.STYLE_ALERT);
            deleteVoicePackage(voicePacketsBean);
        }
    }
}
