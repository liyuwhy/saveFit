package com.fitmix.sdk.view.activity;

import android.os.Bundle;

import com.fitmix.sdk.R;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.adapter.FaqAdapter;
import com.fitmix.sdk.view.bean.FaqEntity;
import com.fitmix.sdk.view.widget.BounceListView;

import java.util.ArrayList;

/**
 * 金币说明界面
 */
public class CoinExplainActivity extends BaseActivity {


    private BounceListView list_coin_explain;
    private FaqAdapter adapter;
    private ArrayList<FaqEntity> faqs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_explain);
        setPageName("CoinExplainActivity");
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        list_coin_explain = (BounceListView) findViewById(R.id.list_coin_explain);
        faqs = new ArrayList<>();
        adapter = new FaqAdapter(this, faqs);
        list_coin_explain.setAdapter(adapter);

        String language = ApiUtils.getLanguage();
        if (language == null || language.endsWith("zh")) {//中文
            faqs.add(new FaqEntity("金币是什么?", "    金币是通过完成乐享动任务获得的奖励积分,它可以用来兑换奖品以及作为参与活动的筹码。"));
            faqs.add(new FaqEntity("金币有什么用?", "    1.兑换手机流量等数字奖励;<br/>" +
                    "    2.兑换运动装备等实物奖励;<br/>" +
                    "    3.兑换乐享动商城优惠券;<br/>" +
                    "    4.作为参加活动的筹码;<br/>" +
                    "    注:以上功能将逐步开放"));
            faqs.add(new FaqEntity("如何获得金币?", "    1.用乐享动运动;<br/>" +
                    "    2.收听乐享动音频内容;<br/>" +
                    "    3.报名参与乐享动活动;<br/>" +
                    "    4.分享乐享动运动记录.音乐.视频.活动等;<br/>" +
                    "    注:更详细获取方式,请查看“金币任务”;<br/>" +
                    "特别说明:对于特殊手段（包括但不限于作弊.扰乱系统等）获得金币的用户,乐享动有权回收异常金币。金币相关规则,最终解释权归乐享动所有。"));
            adapter.notifyDataSetChanged();
        } else {
            faqs.add(new FaqEntity("What is F-coin?", "    Fitmix has the F-coins reward system, where you can earn F-coins by completing Fitmix tasks, then the coins can be redeemed for certain gifts."));
            faqs.add(new FaqEntity("How to use?", "    1.Redeem F-coins for cellphone data and other artificial currency rewards;<br/>" +
                    "    2.Redeem F-coins for sport equipment and other real free gifts;<br/>" +
                    "    3.Redeem F-coins for coupons offered by Fitmix;<br/>" +
                    "    4.Redeem F-coins for rewards points to join certain activities;<br/>" +
                    "    Note:These features will coming soon."));
            faqs.add(new FaqEntity("How do you get F-coins?", "    1.Download and use Fitmix app when doing workout;<br/>" +
                    "    2.Listen to the Fitmix radio programme;<br/>" +
                    "    3.Join us on Fitmix activities;<br/>" +
                    "    4.By sharing sports records, music video and activities in Fitmix community.Find more details in F-coins tasks;<br/>" +
                    "    Note:For the F-coins (or other cheating methods to earn F-coins in non-standard ways) earned by players cheating in games, Fitmix has right to refuse to redeem the abnormal F-coins , and they have to be handed back. Any interpretation or deviation of the F-coins rules is left to Fitmix. Its decision is final.\n"
            ));
            adapter.notifyDataSetChanged();
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }


}
