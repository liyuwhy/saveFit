package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.widget.TextView;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.model.database.DataReqStatus;

public class RankListRuleActivity extends BaseActivity {

    private TextView level_requirement_content, level_rule_content, level_range_content;
    private String requirement_cn = "青铜：10'00\"≤本月平均配速\n" +
            "白银：8'00\"≤本月平均配速＜10'00\"\n" +
            "黄金：6'30\"≤本月平均配速＜8'00\"\n" +
            "铂金：5'30\"≤本月平均配速＜6'30\"\n" +
            "钻石： 本月平均配速＜5'30\"";
    private String requirement_en = "bronze：10'00\"≤Avg pace\n" +
            "silver：8'00\"≤Avg pace＜10'00\"\n" +
            "gold：6'30\"≤Avg pace＜8'00\"\n" +
            "Platinum：5'30\"≤Avg pace＜6'30\"\n" +
            "diamond： Avg pace＜5'30\"";

    private String range_cn = "1、合格里程:步频大于120，单次运动里程大于1km;\n" +
            "2、统计时间范围：当月第一天0点到最后一日24点；";
    private String range_en = "1、Qualified mileage: step frequency greater than 120, single-trip mileage greater than 1km;\n" +
            "2、Statistical time range: 0:00 on the first day of the month to 24:00 on the last day;";

    private String rule_cn = "1、赛段等级内，本月累计里程高者靠前；\n" +
            "2、若本月累计里程相同，则本月平均配速高者靠前；\n" +
            "3、若本月平均配速也相同，则老用户靠前；";
    private String rule_en = "1、In the stage, the highest mileage this month, the highest ranking;\n" +
            "2、If the mileage this month is the same, then the higher average pace one will rank higher;\n" +
            "3、If the average pace is the same too,then the old user will rank higher；";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_list_rule);
        setPageName("RankListRuleActivity");
        initToolbar();
        initViews();
    }


    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        level_range_content = (TextView) findViewById(R.id.level_range_content);
        level_requirement_content = (TextView) findViewById(R.id.level_requirement_content);
        level_rule_content = (TextView) findViewById(R.id.level_rule_content);

        if (FitmixUtil.phoneLanguageIsChinese()) {//中文
            level_requirement_content.setText(requirement_cn);
            level_rule_content.setText(rule_cn);
            level_range_content.setText(range_cn);
        } else {
            level_requirement_content.setText(requirement_en);
            level_rule_content.setText(rule_en);
            level_range_content.setText(range_en);
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {

    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {

    }
}
