package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.BuildConfig;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.bean.LocationInfo;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.common.AppUpgradeManager;
import com.fitmix.sdk.common.DeviceLocalUtil;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.bluetooth.skip.SkipBluetoothService;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.AlbumList;
import com.fitmix.sdk.model.api.bean.Announcements;
import com.fitmix.sdk.model.api.bean.BannerList;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.CheckAppVersion;
import com.fitmix.sdk.model.api.bean.ClubList;
import com.fitmix.sdk.model.api.bean.CoinTaskInfo;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.HandPickTopicList;
import com.fitmix.sdk.model.api.bean.Init;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.MessageRedPointBean;
import com.fitmix.sdk.model.api.bean.MusicList;
import com.fitmix.sdk.model.api.bean.RunRecordList;
import com.fitmix.sdk.model.api.bean.SkipRecordList;
import com.fitmix.sdk.model.api.bean.TaskList;
import com.fitmix.sdk.model.api.bean.TodayTrain;
import com.fitmix.sdk.model.api.bean.TopicList;
import com.fitmix.sdk.model.api.bean.User;
import com.fitmix.sdk.model.api.bean.UserRunStatistics;
import com.fitmix.sdk.model.api.bean.VideoList;
import com.fitmix.sdk.model.api.bean.WatchUpgrade;
import com.fitmix.sdk.model.api.bean.Weather;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.MessageHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.service.WatchService;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.bean.RankListData;
import com.fitmix.sdk.view.bean.Video;
import com.fitmix.sdk.view.dialog.ChangeSportTypeDialog;
import com.fitmix.sdk.view.dialog.MoreActionDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.ClubFragment;
import com.fitmix.sdk.view.fragment.DiscoveryFragment;
import com.fitmix.sdk.view.fragment.MineFragment;
import com.fitmix.sdk.view.fragment.MusicDownloadFragment;
import com.fitmix.sdk.view.fragment.MusicFavoriteFragment;
import com.fitmix.sdk.view.fragment.MusicFragment;
import com.fitmix.sdk.view.fragment.MusicImportFragment;
import com.fitmix.sdk.view.fragment.MusicOtherSourceFragment;
import com.fitmix.sdk.view.fragment.MusicRecentFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.BadgeRadioButton;
import com.fitmix.sdk.view.widget.BadgeRadioGroup;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.WatchInfo;
import com.fitmix.sdk.watch.bean.WatchVersion;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;


public class MainActivity extends BaseWatchActivity implements MusicFragment.MusicFragmentCallback, DiscoveryFragment.DiscoveryFragmentCallback {

    /**
     * 选取歌单
     */
    private static final int SELECT_SONG_ADD_TO_LIST = 125;
    /**
     * 编辑个人信息
     */
    public static final int REQUEST_EDIT_USER_INFO = 126;

    private Uri mCropImageUri;

    private final int FRAGMENT_PAGE_MINE = 0;
    private final int FRAGMENT_PAGE_MUSIC = 1;
    private final int FRAGMENT_PAGE_COMPETITION = 2;
    private final int FRAGMENT_PAGE_CLUB = 3;

    private BadgeRadioGroup rg_nav;
    private BadgeRadioButton radio_mine;
    private BadgeRadioButton radio_discovery;
    private BadgeRadioButton radio_club;
    private Button btn_run;
    private int avatarId;
    /**
     * 当前选择的RadioGroup中radio button下标
     */
    private int currentNavIndex = -1;
    private Music tempMusic;//用来处理收藏等操作的中间变量
    public LinearLayout bottom_container;
    private onMainListener mMainListener;
    //    private OnMessagePushListener mMessagePushListener;

    private User user;
    private boolean userInfoChanged;//个人信息是否有更改,防止每次都写数据库

    //    private int competitionListIndex;
    private int videoListIndex;
    private int topicListIndex;

    /**
     * 金币任务创建或加入俱乐部是否完成
     */
    private boolean coinTaskCreateJoinClub;
    private Dialog adDialog;

    private boolean isNotFirstShow = false;//防止app收到推送消息后刷新首页界面
    private boolean showMessageMenu = false;//是否显示消息菜单
    private boolean showMessageNote = false;//是否显示消息红点
    private int thisLevel;
    private WatchVersion watchVersion;//手表返回的固件信息
    private WatchUpgrade watchUpgrade;//服务器返回的手表固件升级信息

    private boolean isShowUpdateDailog = false;//是否在显示固件升级提示
    private boolean sendBindCmd;//是否需要向手表发送绑定指令

    //region ======================================== Activity生命周期 ========================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setPageName("MainActivity");
        initToolbar();
        initViews();

        //1. Android 6.0申请权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            getPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.BODY_SENSORS,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.CALL_PHONE});
        }
        dataRequestInOtherThread();
        startStepCount();//开启后台今日计步
//        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onCreate id:" + this);

        registerLocalBroadCast();
        autoConnectWatch();//自动连接手表
        getBestLocation(this);//通过google获取经纬度并请求天气接口获取当前国家

        if (getIntent() != null) {
            boolean fromWatchRunService = getIntent().getBooleanExtra("fromWatchRunService", false);
            if (fromWatchRunService) {
                ThreadManager.getSubThread1Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent0 = new Intent(MainActivity.this, RunMainActivity.class);
                        intent0.putExtra("fromWatchRunService", true);
                        intent0.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                        startActivity(intent0);
                    }
                }, 2500);
            } else {
                boolean ifRunningKilled = SettingsHelper.getBoolean(Config.SP_KEY_RUNNING_IF_KILLED, false);
                if (ifRunningKilled) {
                    ThreadManager.getSubThread1Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent0 = new Intent(MainActivity.this, RunMainActivity.class);
                            intent0.putExtra("fromWatchRunService", true);
                            intent0.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                            startActivity(intent0);
                        }
                    }, 2500);
                }
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onNewIntent");
        setIntent(intent);// 如果被打开的activity启动模式为SingleTop，SingleTask或SingleInstance，在该activity重载onNewIntent方法
    }

    @Override
    protected void onResume() {
        super.onResume();
//        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onResume currentNavIndex:" + currentNavIndex);
        checkMessageExist();
        appInit();
        uploadUserDeviceInfo();//上传设备信息  激活信鸽状态  请求私信数量

    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterLocalBroadCast();
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
//        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onResumeFragments");
        if (currentNavIndex == FRAGMENT_PAGE_MINE || currentNavIndex == -1) {
            MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
            if (fragment != null) {
                if (currentNavIndex == -1) {
                    if (radio_mine != null) {
                        radio_mine.setChecked(true);
                        currentNavIndex = FRAGMENT_PAGE_MINE;
                    }
                }
                loadDataForMineFragment();//可以的话再判断上一个结束的activity为EditProfileActivity ,数据跟网络相关的界面更新
            } else {
                switchToFragment(FRAGMENT_PAGE_MINE);
            }
            if (!TextUtils.isEmpty(XGPushConfig.getToken(this))) {
                uploadDeviceStatus(1, XGPushConfig.getToken(this));//刷新app的活跃状态
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (showMessageMenu) {
            final MenuItem menuGoToMessageView = menu.add(0, Menu.FIRST + 3, 3, R.string.title_activity_topic_message).setIcon(R.drawable.mine_message_icon);
            menuGoToMessageView.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
            menuGoToMessageView.setActionView(R.layout.menu_message);
            ImageView messageIv = (ImageView) menuGoToMessageView.getActionView().findViewById(R.id.message_iv);
            ImageView messageNoteIv = (ImageView) menuGoToMessageView.getActionView().findViewById(R.id.message_note_iv);
            if (showMessageNote) {
                messageNoteIv.setVisibility(View.VISIBLE);
            } else {
                messageNoteIv.setVisibility(View.GONE);
            }
            messageIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onOptionsItemSelected(menuGoToMessageView);
                }
            });
        }

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;

            case Menu.FIRST + 3://导航到消息界面
                startMessageNoticeActivity();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        if (!TextUtils.isEmpty(XGPushConfig.getToken(this))) {
            uploadDeviceStatus(0, XGPushConfig.getToken(this));//取消app的活跃状态
        }

        UmengAnalysisHelper.getInstance().onKillProcess(this);//在程序退出前完成统计使用时长
        PlayerController.getInstance().stopPlayer();//音乐停止播放

        //停止后台计步
        boolean daemonStepCounter = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        if (!daemonStepCounter) {
            stopStepCount();
        }
        stopSkipBluetoothService();//关闭跳绳蓝牙
        stopHeartRateService();//停止心率蓝牙服务
      //  unbindWatchService();//解绑手表蓝牙服务  基类已经解绑
        stopWatchService();//停止手表蓝牙服务

        if (mStatusReceive != null) {
            unregisterReceiver(mStatusReceive);
        }
        stopScan();
        // WatchRunService.stopService();//为了保活不停止保活服务

        //退出程序取消App的活跃状态，用于推送消息状态使用
        if (!TextUtils.isEmpty(XGPushConfig.getToken(MainActivity.this))) {
            uploadDeviceStatus(0, XGPushConfig.getToken(MainActivity.this));//取消app的活跃状态
        }
        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onDestroy");
        super.onDestroy();
    }

    /**
     * 根据设置,开始后台今日计步
     */
    private void startStepCount() {
        boolean daemonStepCounter = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        if (daemonStepCounter) {
            Intent i = new Intent(this, RunService.class);
            i.putExtra(RunService.ACTION_WHAT, RunService.ACTION_START_DAEMON_STEP_COUNT);
            try {//http://bbs.coloros.com/thread-174655-3-1.html
                startService(i);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 停止后台今日计步
     */
    private void stopStepCount() {
        Intent i = new Intent(this, RunService.class);
        stopService(i);
    }

    /**
     * 停止跳绳蓝牙服务
     */
    private void stopSkipBluetoothService() {
        Intent i = new Intent(this, SkipBluetoothService.class);
        stopService(i);
    }

    /**
     * 停止心率蓝牙服务
     */
    private void stopHeartRateService() {
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    /**
     * APP 初始化
     */
    private void appInit() {
        int appVersion = ApiUtils.getApkVersionCode();
        String lan = ApiUtils.getLanguage();
        if ("zh".equals(lan)) {
            int requestId = UserDataManager.getInstance().appInit(appVersion, "ch", false);
            registerDataReqStatusListener(requestId);
        } else {
            int requestId = UserDataManager.getInstance().appInit(appVersion, "en", false);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * 切换Fragment
     *
     * @param pageIndex 0:MineFragment,1:MusicFragment,2:DiscoveryFragment,3:ClubFragment
     */
    private void switchToFragment(int pageIndex) {
        Fragment fragment;
        String fragmentTag;
        if (currentNavIndex == pageIndex) {//防止同一个标签多次切换
            return;
        }
        switch (pageIndex) {
            case FRAGMENT_PAGE_MUSIC:
                showMessageMenu = false;
                fragmentTag = MusicFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                if (fragment == null) {
                    fragment = new MusicFragment().setFragmentCallback(this);
                } else {
                    return;
                }
                break;
            case FRAGMENT_PAGE_CLUB:
                showMessageMenu = false;
                fragmentTag = ClubFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(ClubFragment.TAG);
                if (fragment == null) {
                    fragment = new ClubFragment();
                } else {
                    return;
                }
                break;
            case FRAGMENT_PAGE_MINE:
                showMessageMenu = true;
                fragmentTag = MineFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
                if (fragment == null) {
                    fragment = new MineFragment();
                } else {
                    return;
                }

                break;
            case FRAGMENT_PAGE_COMPETITION:
                showMessageMenu = false;
                fragmentTag = DiscoveryFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
                if (fragment == null) {
                    fragment = new DiscoveryFragment().setFragmentCallback(this);
                } else {
                    return;
                }
                break;
            default:
                return;
        }


        int animationIdIn = 0;
        int animationIdOut = 0;
        int backStackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        if (backStackEntryCount == 0) {//当前显示的是二级fragment时,不用再设置切换动画
            if (this.currentNavIndex < 0) {

            } else if (this.currentNavIndex > pageIndex) {
                animationIdIn = R.anim.push_right_in;
                animationIdOut = R.anim.push_right_out;

            } else if (this.currentNavIndex < pageIndex) {
                animationIdIn = R.anim.push_left_in;
                animationIdOut = R.anim.push_left_out;
            } else {
                return;
            }
        }
        /**
         *  java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
         *  at android.support.v4.app.FragmentManagerImpl.checkStateLoss(FragmentManager.java:1489)
         *  at android.support.v4.app.FragmentManagerImpl.popBackStackImmediate(FragmentManager.java:584)
         *  at android.support.v4.app.FragmentActivity.onBackPressed(FragmentActivity.java:169)
         */
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(animationIdIn, animationIdOut, 0, 0)
                    .replace(R.id.mainContainer, fragment, fragmentTag)
                    .commitAllowingStateLoss();
        }
        invalidateOptionsMenu();//刷新菜单栏
        BadgeRadioButton badgeRadioButton = (BadgeRadioButton) rg_nav.getChildAt(pageIndex);
        badgeRadioButton.setChecked(true);
        this.currentNavIndex = pageIndex;
        processClubInvite();
    }

    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        bottom_container = (LinearLayout) findViewById(R.id.bottom_container);
        btn_run = (Button) findViewById(R.id.btn_run);
        rg_nav = (BadgeRadioGroup) findViewById(R.id.rg_nav);
        radio_mine = (BadgeRadioButton) findViewById(R.id.radio_mine);//我的底部按钮
        radio_discovery = (BadgeRadioButton) findViewById(R.id.radio_discovery);//发现底部按钮
        radio_club = (BadgeRadioButton) findViewById(R.id.radio_club);//俱乐部底部按钮
        rg_nav.setOnCheckedChangeListener(new BadgeRadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(BadgeRadioGroup group, @IdRes int checkedId) {
                if (ftCanCommit) {
                    getSupportFragmentManager().popBackStackImmediate();
                }
                switch (checkedId) {
                    case R.id.radio_music://动听
                        switchToFragment(FRAGMENT_PAGE_MUSIC);
                        loadDataForMusicFragment(false);
                        UmengAnalysisHelper.getInstance().reportEventPlus(MainActivity.this, "点击动听按钮");//友盟u-d plus统计
                        break;
                    case R.id.radio_club://俱乐部
                        switchToFragment(FRAGMENT_PAGE_CLUB);
                        loadDataForClubFragment();
                        UmengAnalysisHelper.getInstance().reportEventPlus(MainActivity.this, "点击俱乐部按钮");//友盟u-d plus统计
                        break;
                    case R.id.radio_mine://我的
                        switchToFragment(FRAGMENT_PAGE_MINE);
                        loadDataForMineFragment();
                        break;
                    case R.id.radio_discovery://发现
                        switchToFragment(FRAGMENT_PAGE_COMPETITION);
                        if (MessageHelper.getInstance().hasCompetitionMessage()) {//若有赛事新消息提醒 点击之后就把红点去掉
                            MessageHelper.getInstance().deleteCompetitionMessage();
                            radio_discovery.showBadge(false);
                            UserDataManager.getInstance().switchMessageState(1, -1);
                        }
                        loadDataForDiscoveryFragment();
                        UmengAnalysisHelper.getInstance().reportEventPlus(MainActivity.this, "点击发现按钮");//友盟u-d plus统计
                        break;
                }
            }
        });
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
//        Logger.e(Logger.DEBUG_TAG, "MainActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 1://App初始化    获取首页弹出的公告
                if (!isNotFirstShow) {
                    isNotFirstShow = true;
                    Init init = JsonHelper.getObject(result, Init.class);
                    setPopWindowAd(init);
                }
                break;

            case Config.MODULE_USER + 6://检测服务器上App最新版本信息
                setUpdateVersionInfo(result);
                break;
            //region =================================== MineFragment ===================================
            case Config.MODULE_USER + 2://邮箱或者手机账号登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录
                setUserInfo(result);
                break;
            case Config.MODULE_USER + 200://获取彩蛋
                setMineFragmentSurprise(result);
                break;
            case Config.MODULE_USER + 202://请求天气
                Weather weather = JsonHelper.getObject(result, Weather.class);
                if (weather != null) {
                    String cnty = weather.getSurprise().getBasic().getCnty();
                    if ("China".equals(cnty) || "中国".equals(cnty)) {
                        SettingsHelper.putBoolean(Config.SETTING_IS_ABROAD, false);
                        getLocate();//获取彩蛋定位城市
                    } else {
                        SettingsHelper.putBoolean(Config.SETTING_IS_ABROAD, true);
                    }
                }
                break;
            case Config.MODULE_SPORT + 2://从后台服务器获取用户历史跑步记录
                setRunRecordList(result);
                break;
            case Config.MODULE_SPORT + 12://从后台服务器获取用户历史跳绳记录
                setSkipRecordList(result);
                break;
            case Config.MODULE_SPORT + 35://获取今日运动计划
                setTrainPlanPrompt(result, false);
                break;
            case Config.MODULE_USER + 67://更新用户app的活跃状态
                MessageRedPointBean redPointBean = JsonHelper.getObject(result, MessageRedPointBean.class);
                if (redPointBean != null) {
                    int noticeNum = redPointBean.getNoticeNum();
                    if (noticeNum > 0) {
                        showMessageNote = true;
                        if (radio_mine != null) radio_mine.showBadge(true);
                        invalidateOptionsMenu();
                    } else if (noticeNum == 0) {
                        if (SettingsHelper.getBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, false)) {
                            showMessageNote = true;
                            if (radio_mine != null) radio_mine.showBadge(true);
                            invalidateOptionsMenu();
                        } else {
                            SettingsHelper.putBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, false);
                            if (radio_mine != null) radio_mine.showBadge(false);
                            showMessageNote = false;
                            invalidateOptionsMenu();
                        }
                    }
                }
//                boolean aBoolean = SettingsHelper.getBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, false);
//                Logger.e(Logger.LOG_TAG, "红点展示:" + aBoolean);
                break;

            case Config.MODULE_SPORT + 36://获取用户月运动排行榜数据
                RankListData rankListData = JsonHelper.getObject(result, RankListData.class);
                int thisRank = 0;
                thisLevel = 0;
                if (rankListData != null) {
                    RankListData.MonthRank month = rankListData.getMonth();
                    if (month != null) {
                        thisRank = month.getRank();
                        thisLevel = month.getLevel();
                    }
                }

                MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
                if (fragment != null) {
                    fragment.setRankListInfo(thisRank, thisLevel);
                }

                break;
            //endregion =================================== MineFragment ===================================

            //region =================================== MusicFragment ===================================
            case Config.MODULE_MUSIC + 1://获取专辑列表
                MusicFragment fragment_music = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                if (fragment_music != null) {
                    stopRefreshMusicFragmentAlbumList(dataReqResult.getResult());
                }
                break;
            case Config.MODULE_MUSIC + 2://获取Banner列表
                MusicFragment fragment2 = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                if (fragment2 != null) {
                    stopRefreshMusicFragmentBannerList(dataReqResult.getResult());
                }
                break;
            case Config.MODULE_MUSIC + 4://音乐收藏
                favoriteSwitchInLocale(tempMusic);
                break;
            case Config.MODULE_MUSIC + 6://获取电台列表
                stopRefreshMusicFragmentRadioList(dataReqResult.getResult());
                break;

            case Config.MODULE_MUSIC + 12://获取歌曲列表
                MusicList musicList = JsonHelper.getObject(result, MusicList.class);
                if (musicList != null) {
                    List<Music> musics = musicList.getMixList();
                    if (musics != null && musics.size() > 0) {
                        for (Music music : musics) {
                            OperateMusicUtils.insertMusic(music, Config.LIST_TYPE_SCENE);
                        }
                    }
                }
                break;
            //endregion =================================== MusicFragment ===================================

            //region =================================== ClubFragment ===================================
            case Config.MODULE_CLUB + 1://获取俱乐部列表
                stopRefreshClubFragmentList(result);
                break;
            case Config.MODULE_CLUB + 14://创建俱乐部
                afterCreateClub(true);
                if (!coinTaskCreateJoinClub) {
                    finishCreateJoinClubCoinTask();
                }
                break;
            case Config.MODULE_CLUB + 21://加入俱乐部
                getMyConfig().getMemExchange().setNeedRefreshClubList(true);
                if (!coinTaskCreateJoinClub) {
                    finishCreateJoinClubCoinTask();
                }
                break;
            //endregion =================================== ClubFragment ===================================

            //region =================================== DiscoveryFragment ===================================
//            case Config.MODULE_COMPETITION + 1://获取运动赛事列表
//                stopRefreshCompetitionList(result);
//                break;
            case Config.MODULE_COMPETITION + 2://获取运动视频列表
                stopRefreshVideoList(result);
                break;
//            case Config.MODULE_COMPETITION + 3://获取运动赛事列表
//                stopRefreshCompetitionList(result);
//                break;
            case Config.MODULE_COMPETITION + 4://获取运动视频列表
                stopRefreshVideoList(result);
                break;
            case Config.MODULE_COMPETITION + 5://获取话题列表
                stopRefreshTopicList(result);
                break;
            case Config.MODULE_COMPETITION + 6://根据话题编号,获取该话题的回答列表
                break;
            case Config.MODULE_COMPETITION + 20://获取精选话题
                setHandpickTopic(result);
                break;

            //endregion =================================== DiscoveryFragment ===================================

            //region =================================== 金币任务 ===================================
            case Config.MODULE_USER + 57://获取一次性任务列表
                setOnceTaskList(result);
                break;

            case Config.MODULE_USER + 52://完成创建或加入俱乐部任务金币任务
            case Config.MODULE_USER + 59://完成每日分享音乐金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            if (requestId == Config.MODULE_USER + 52) {//创建或加入俱乐部任务
                                coinTaskCreateJoinClub = true;
                                SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_CREATE_JOIN_CLUB, true);//设置完成创建或加入俱乐部任务
                            } else if (requestId == Config.MODULE_USER + 59) {//每日分享音乐
                                SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_MIX, System.currentTimeMillis());//设置完成任务时间
                            }
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;

            case Config.MODULE_USER + 63://完成绑定邮箱金币任务
            case Config.MODULE_USER + 64://完成绑定手机金币任务
                FinishTask task = JsonHelper.getObject(result, FinishTask.class);
                if (task != null) {
                    if (task.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = task.getAccountFlow();
                        if (accountFlowEntity != null) {
                            if (requestId == Config.MODULE_USER + 63) {//绑定邮箱金币任务
                                SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_EMAIL, true);//设置绑定邮箱已完成
                                PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_IS_NEW_EMAIL_REGISTER, false);//更改状态
                            } else if (requestId == Config.MODULE_USER + 64) {//绑定手机金币任务
                                SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_PHONE, true);//设置绑定手机已完成
                                PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_IS_NEW_PHONE_REGISTER, false);//更改状态
                            }
                        }
                    }
                }
                break;

            //endregion =================================== 金币任务 ===================================


            //region =================================== 手表固件 ===================================
            case Config.MODULE_USER + 29://检测服务器上手表固件最新版本信息//TODO
                watchUpgrade = JsonHelper.getObject(result, WatchUpgrade.class);
                judgeFirmUpdate(result);
                break;

            //endregion =================================== 手表固件 ===================================
        }
    }

    private void judgeFirmUpdate(String result) {
        if (watchUpgrade == null || TextUtils.isEmpty(watchUpgrade.getNewVersion())) {//没有新版本 或 手表更新类里没有新版本号
            Logger.i(Logger.DEBUG_TAG, "没有新版本 或 手表更新类里没有新版本号");
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, 0);
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, 0);
            SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, "");
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_NEWEST, 0);
            SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, false);
            SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
            return;
        }
        Logger.i(Logger.DEBUG_TAG, "watchUpgradeVersion:" + watchUpgrade.getNewVersion());
        int newVersion = Integer.parseInt(watchUpgrade.getNewVersion());
        SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_NEWEST, newVersion);
        String isForce = watchUpgrade.getIsForce();
        if (watchVersion != null && watchVersion.getVersionNum() != null) {
            Logger.d(Logger.DEBUG_TAG, "后台 versionNum:" + newVersion + " ,手表 watchVersion：" + watchVersion.getVersionNum());
            try {

                int version = Integer.parseInt(watchVersion.getVersionNum());
                if (version < newVersion) {//TODO 手表固件升级提示
                    SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, result);
                    if (!isShowUpdateDailog) {//防止弹窗两次
                        isShowUpdateDailog = true;
                        MineFragment fragment_mine = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
                        int isUpdatingFirmVersion = SettingsHelper.getInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, 0);//上次固件传输的版本号
                        int firmSendProgress = SettingsHelper.getInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, 0);//上次固件传输的进度
                        Logger.d(Logger.DEBUG_TAG, "isUpdatingFirmVersion:" + isUpdatingFirmVersion + ",firmSendProgress:" + firmSendProgress);
                        if (isUpdatingFirmVersion == newVersion) {
                            if (firmSendProgress == 100) return;
                        }
                        if (isUpdatingFirmVersion < newVersion) {//在更新的版本小于最新版本
                            if (firmSendProgress > 50 && firmSendProgress < 100) {//正在传输的进度在50到100之间，不提示升级

                            } else {
                                fragment_mine.setMyEquipmentMessage(true);
                                if (isForce.equals("0")) {
                                    showNoticeDialog();
                                } else if (isForce.equals("1")) {
                                    showNoticeDialogForce();
                                }
                            }
                        } else {//在更新的版本跟最新版本一致

                            boolean forceUpdate = SettingsHelper.getBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, false);
                            boolean selectUpdate = SettingsHelper.getBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
                            if (forceUpdate || selectUpdate) return;

                            fragment_mine.setMyEquipmentMessage(true);

                            if (isForce.equals("0")) {
                                showNoticeDialog();
                            } else if (isForce.equals("1")) {
                                showNoticeDialogForce();
                            }
                        }

                    }

                } else {
                    SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, "");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "MainActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                //region =================================== MineFragment ===================================
                case Config.MODULE_USER + 2://邮箱或者手机账号登录
                    int code = bean.getCode();
                    if (code == 2004) {//需要重新登录
                        showLogoutDialog();
                    } else if (code == 2001) {//用户密码错误
                        showLogoutDialog();
                    }
                    break;
                //endregion =================================== MineFragment ===================================

                //region =================================== MusicFragment ===================================
                case Config.MODULE_MUSIC + 1:
                    String albumResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_MUSIC + 1);
                    MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                    if (fragment != null) {
                        if (!TextUtils.isEmpty(albumResult))
                            stopRefreshMusicFragmentAlbumList(albumResult);
                    }
                    break;
                case Config.MODULE_MUSIC + 2:
                    String bannerResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_MUSIC + 2);
                    MusicFragment fragment2 = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                    if (fragment2 != null) {
                        if (!TextUtils.isEmpty(bannerResult))
                            stopRefreshMusicFragmentBannerList(bannerResult);
                    }
                    break;
                case Config.MODULE_MUSIC + 4://音乐收藏
                    super.processReqError(requestId, error);
                    break;
                case Config.MODULE_MUSIC + 6://获取电台列表
                    String radioResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_MUSIC + 6);
                    MusicFragment fragment3 = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                    if (fragment3 != null) {
                        if (!TextUtils.isEmpty(radioResult))
                            stopRefreshMusicFragmentRadioList(radioResult);
                    }
                    break;
                //endregion =================================== MusicFragment ===================================

                //region =================================== ClubFragment ===================================
                case Config.MODULE_CLUB + 1://获取俱乐部列表
                    getDataReqStatusAsync(requestId);
                    break;
                case Config.MODULE_CLUB + 14://创建俱乐部
                    super.processReqError(requestId, error);
                    break;
                case Config.MODULE_CLUB + 21://加入俱乐部
                    super.processReqError(requestId, error);
                    break;
                //endregion =================================== ClubFragment ===================================

                //region =================================== DiscoverFragment ===================================
//                case Config.MODULE_COMPETITION + 1://获取运动赛事列表
//                    String competitionResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_COMPETITION + 1);
//                    if (!TextUtils.isEmpty(competitionResult))
//                        stopRefreshCompetitionList(competitionResult);
//                    break;
                case Config.MODULE_COMPETITION + 2://获取运动视频列表
                    String videoResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_COMPETITION + 2);
                    if (!TextUtils.isEmpty(videoResult))
                        stopRefreshVideoList(videoResult);
                    break;
//                case Config.MODULE_COMPETITION + 3://获取运动赛事列表
//                    stopRefreshCompetitionListWithError();
//                    break;
                case Config.MODULE_COMPETITION + 4://获取运动视频列表
                    stopRefreshVideoListWithError();
                    break;
                case Config.MODULE_COMPETITION + 5://获取话题列表
                    stopRefreshTopicList(null);
                    break;
                //endregion =================================== DiscoverFragment ===================================
            }
        }
        super.processReqError(requestId, error);
    }

    /**
     * 在其它线程准备请求,减少主界面卡顿
     */
    private void dataRequestInOtherThread() {
        ThreadManager.executeOnSubThread1(new Runnable() {
            @Override
            public void run() {
                //1.加载运动数据
                loadSportData();
                //2.获取收藏歌曲列表的信息
                getMusicInfoByIdList();
                //3.检测新版本
                checkNewVersion();
                //4.获取一次性任务
                getHonorTaskList();
            }
        });
    }

    //endregion ======================================== Activity生命周期 ========================================

    //region ============================= 版本升级 =============================
    private void checkNewVersion() {
        // wifi情况下,检测新版本
        String netWorkType = ApiUtils.getNetWorkType();//卡顿点
        if (netWorkType != null && "wifi".equals(netWorkType)) {
            //APP版本升级检测
            int requestId = UserDataManager.getInstance().checkAppVersion();
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * 新版本提示
     *
     * @param downloadUrl 新版本apk下载地址
     * @param content     新版本特性说明
     * @param force       true:强制升级,false:非强制升级
     */
    private void detectNewAppAvailable(String downloadUrl, String content, final boolean force) {
        AppUpgradeManager manager = new AppUpgradeManager(this, downloadUrl, content);
        manager.setOnCancelUpgradeListener(new AppUpgradeManager.OnCancelUpgradeListener() {
            @Override
            public void OnCancelUpgrade() {//取消升级
                if (force) {//强制退出APP
                    finish();
                }
            }
        });
        manager.newVersionPrompt(force);
    }

    /**
     * 检测版本之后
     *
     * @param sResult
     */
    private void setUpdateVersionInfo(String sResult) {
        if (sResult == null) return;
        CheckAppVersion checkAppVersion = JsonHelper.getObject(sResult, CheckAppVersion.class);
        if (checkAppVersion != null) {
            int androidVersion = checkAppVersion.getAndroidVersion();
            int appVersion = ApiUtils.getApkVersionCode();
            int upgrade = checkAppVersion.getUpgrade();

            SettingsHelper.putInt(Config.SETTING_NEW_VERSION, androidVersion);
            int ignoreVersion = SettingsHelper.getInt(Config.SETTING_IGNORE_VERSION, -1);
            if (ignoreVersion < androidVersion) {//如果最新的版本比忽略的版本高 则把已经点击过的升级操作置为false
                SettingsHelper.putBoolean(Config.SETTING_VERSION_UPDATE, false);
                MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
                if (fragment != null && user != null) {
                    //设置app升级提示红点
                    checkMessageExist();
                    //fragment.setUpdateMessageShow(getShowAppUpdate());
                }
            }

            if (appVersion < androidVersion) {//提示升级
                String downloadUrl = checkAppVersion.getAndroidUpgradeUrl();
                if (upgrade == 1) {//强制升级
                    String content = checkAppVersion.getContent();
                    if (!TextUtils.isEmpty(downloadUrl) && !TextUtils.isEmpty(content)) {
                        detectNewAppAvailable(downloadUrl, content, true);
                    }
                } else {
                    String androidVersionIntroduction = checkAppVersion.getAndroidVersionIntroduction();
                    if (!TextUtils.isEmpty(downloadUrl) && !TextUtils.isEmpty(androidVersionIntroduction)) {
                        detectNewAppAvailable(downloadUrl, androidVersionIntroduction, false);
                    }
                }
            }
        }
    }

    //endregion ============================= 版本升级 =============================

    //region ============================= 嵌套Fragment页面共有的一些操作 =============================
    public interface onMainListener {
        void onDownLoadedFinish();

        void onMusicChanged();

        void onDownLoadMusicDeleted();

        void onFavoriteStateChange();

        void onMusicPlayStateChanged();
    }

    public void setOnMainListener(onMainListener listener) {
        this.mMainListener = listener;
    }

    protected void onDownLoadedFinish() {
        if (mMainListener != null)
            mMainListener.onDownLoadedFinish();
    }

    protected void onMusicChanged() {
        if (mMainListener != null)
            mMainListener.onMusicChanged();
        super.onMusicChanged();
    }

    protected void onMusicPlayStateChanged() {
        if (mMainListener != null)
            mMainListener.onMusicPlayStateChanged();
        super.onMusicPlayStateChanged();
    }

    public void onDownLoadMusicDeleted() {
        if (mMainListener != null)
            mMainListener.onDownLoadMusicDeleted();
    }

    public void onFavoriteStateChange() {
        if (mMainListener != null)
            mMainListener.onFavoriteStateChange();
    }

    /**
     * 播放全部
     */
    public void playAll(final List<Music> playList) {
        if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_MOBILE) {
            new MaterialDialog.Builder(this)
                    .title(R.string.warning)
                    .content(R.string.downstream_control)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE://开始播放
                                    SettingsHelper.putInt(Config.SETTING_PLAY_MODE, 1);
                                    getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);
                                    getMyConfig().getPlayer().setPlayList(playList);
                                    getMyConfig().getPlayer().playHeadOfList(true);
                                    invalidateOptionsMenu();
                                    break;
                                case NEGATIVE:
                                    break;
                            }
                        }
                    }).show();
        } else if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_WIFI) {
            SettingsHelper.putInt(Config.SETTING_PLAY_MODE, 1);
            getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);
            getMyConfig().getPlayer().setPlayList(playList);
            getMyConfig().getPlayer().playHeadOfList(true);
            invalidateOptionsMenu();
        } else {
            String info = getResources().getString(R.string.check_network);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
        }
    }

    /**
     * 播放全部
     */
    public void playAllWithNoCheck(List<Music> playList) {
        getMyConfig().getPlayer().setPlayList(playList);
        SettingsHelper.putInt(Config.SETTING_PLAY_MODE, 1);
        getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);
        getMyConfig().getPlayer().playHeadOfList(true);
    }

    /**
     * 选歌
     */
    public void selectSongs(int listType) {
        Intent intent = new Intent(this, SelectSongActivity.class);
        intent.putExtra("FromAlbum", true);
        intent.putExtra("ListType", listType);
        startActivityForResult(intent, SELECT_SONG_ADD_TO_LIST);
    }

    /**
     * 导航到音乐播放界面
     *
     * @param list  要播放的音乐列表
     * @param index 播放的下标
     */
    public void gotoPlayMusicActivity(List<Music> list, int index, int musicId) {
        getMyConfig().getPlayer().setPlayList(list);
        OperateMusicUtils.setPlayingMusic(musicId);
        Intent intent = new Intent(this, PlayMusicActivity.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }

    /**
     * 显示更多操作栏
     *
     * @param music    要进行操作的音乐
     * @param listType 列表类型 用来控制 操作的不同方式
     */
    public void showMoreActionDialog(final Music music, final int listType) {
        if (music == null) {
            return;
        }
        MoreActionDialog moreActionDialog = new MoreActionDialog();
        moreActionDialog.setListType(listType);
        moreActionDialog.setMusic(music);
        moreActionDialog.setOnActionClickListener(new MoreActionDialog.ActionTypeClickListener() {
            @Override
            public void onActionClick(int type) {//根据选择的按钮不同 选择不同的回调方法
                doMoreAction(music, type, listType);
            }
        });
        moreActionDialog.show(this.getSupportFragmentManager(), "moreActionDialog");
    }

    /**
     * 做更多操作
     *
     * @param music    要进行操作的音乐
     * @param type     操作的类型
     * @param listType 列表的类型
     */
    private void doMoreAction(final Music music, int type, int listType) {
        switch (type) {
            case MoreActionDialog.ACTION_TYPE_MUSIC_FAVORITE://收藏
                favoriteSwitchMusic(music);
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_DOWNLOAD://下载
                if (OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_DOWNLOADED)) {
                    deleteDownloadedMusic(music);
                } else {
                    OperateMusicUtils.downloadMusic(music);
                    if (music != null) {
                        UmengAnalysisHelper.getInstance().musicReportPlus(MainActivity.this, "音乐下载", music.getId());
                    }
                }
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_SHARE://分享
                ShareUtils.getInstance().shareMusic(this, music);
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_DELETE://删除
                if (listType != Config.LIST_TYPE_DOWNLOADED) {
                    OperateMusicUtils.deleteMusic(music, listType);
                } else {
                    deleteDownloadedMusic(music);
                }
                break;
        }
    }

    private void deleteDownloadedMusic(final Music music) {
        if (music == null) return;
        new MaterialDialog.Builder(this)
                .title(R.string.delete)
                .content(R.string.delete_tip)
                .positiveText(R.string.delete)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://删除已下载的音乐
                                OperateMusicUtils.deleteMusicDownloadedFile(music);
                                onDownLoadMusicDeleted();//刷新列表
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 收藏歌曲或者取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchMusic(Music music) {
        if (music == null) return;
        favoriteSwitchInNet(music);
    }

    /**
     * 在服务器收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInNet(Music music) {
        tempMusic = music;
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);
        int requestId = MusicDataManager.getInstance().favoriteMusicChange(UserDataManager.getUid(), music.getId(), false);
        registerDataReqStatusListener(requestId);
        showAppMessage(
                bFavorite ? R.string.activity_main_unfavoriting : R.string.activity_main_favoriting, AppMsg.STYLE_INFO);
        if (!bFavorite) {
            UmengAnalysisHelper.getInstance().musicReportPlus(this, "音乐收藏", music.getId());
        }
    }

    /**
     * 在本地收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInLocale(Music music) {
        OperateMusicUtils.favoriteSwitchInLocale(music);
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);
        onFavoriteStateChange();
        showAppMessage(bFavorite ? R.string.activity_main_album_add_favorite_tip : R.string.activity_main_album_remove_favorite_tip, AppMsg.STYLE_INFO);
    }

    //endregion ============================= 嵌套Fragment页面共有的一些操作 =============================

    //region ================================ MineFragment交互相关 ================================

    /**
     * 加载运动数据
     */
    private void loadSportData() {
        int uid = UserDataManager.getUid();

        //2.加载运动记录
        long lastRunUpdateTime = SettingsHelper.getLong(uid, Config.SETTING_RUN_RECORD_SYNC_TIME, 0);
        int requestId = SportDataManager.getInstance().getHistoryRunRecords(uid, lastRunUpdateTime);
        registerDataReqStatusListener(requestId);

        //3.加载跳绳运动记录
        boolean isConnected = SettingsHelper.getBoolean(Config.CONNECTED_SKIP_DEVICE, false);//是否连接过跳绳设备
        if (isConnected) {
            long lastSkipUpdateTime = SettingsHelper.getLong(uid, Config.SETTING_SKIP_RECORD_SYNC_TIME, 0);
            int requestId2 = SportDataManager.getInstance().getHistorySkipRecords(uid, lastSkipUpdateTime);
            registerDataReqStatusListener(requestId2);
        }

        //4.今日是否有训练计划 如果点击过忽略就不再请求
        long lastTime = SettingsHelper.getLong(Config.IGNORE_INFORMATION_DATE, 0);
        if (!FitmixUtil.isToday(lastTime)) {
            int requestId3 = SportDataManager.getInstance().getTodayStages();
            registerDataReqStatusListener(requestId3);
        }
    }

    /**
     * 加载MineFragment需要的数据
     */
    private void loadDataForMineFragment() {
//        Logger.e(Logger.DEBUG_TAG, "loadDataForMineFragment");
        //1.加载个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (!TextUtils.isEmpty(email) || !TextUtils.isEmpty(password)) {
                int requestId = UserDataManager.getInstance().emailLogin(email, password);
                registerDataReqStatusListener(requestId);
            } else {
                showLogoutDialog();
            }
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            } else {
                showLogoutDialog();
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            } else {
                showLogoutDialog();
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            } else {
                showLogoutDialog();
            }
        } else {
            showLogoutDialog();
        }


        //2.获取排行榜信息
        int requestId = SportDataManager.getInstance().getRankListData(UserDataManager.getUid(), System.currentTimeMillis(), true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取今日计划
     *
     * @param result
     * @param ignore 是否是用户自己点击忽略的 是 当天就不再显示提示,有新的提示才显示
     */
    private void setTrainPlanPrompt(String result, boolean ignore) {
        MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
        if (fragment != null) {
            TodayTrain todayTrain = JsonHelper.getObject(result, TodayTrain.class);
            if (todayTrain != null && todayTrain.getStages() != null) {
                fragment.showTodayPrompt(todayTrain.getStages());
            } else {
                if (ignore) {
                    SettingsHelper.putLong(Config.IGNORE_INFORMATION_DATE, System.currentTimeMillis());
                }
                fragment.hideTodayPrompt();
            }
        }
    }

    /**
     * 设置我的跑步记录列表
     *
     * @param result 网络请求返回的结果
     */
    public void setRunRecordList(String result) {
        RunRecordList runRecordList = JsonHelper.getObject(result, RunRecordList.class);
        if (runRecordList != null) {
            //1.更新最近一次获取用户历史跑步记录的时间戳
            long lastUpdateTime = runRecordList.getLastAddTime();
            SettingsHelper.putLong(Config.SETTING_RUN_RECORD_SYNC_TIME, lastUpdateTime);
            List<RunRecordList.RunRecord> runRecords = runRecordList.getRunRecords();
            if (runRecords != null && runRecords.size() > 0) {
                //2.区分运动记录是手表产生的还是乐享动app产生的
                List<RunRecordList.RunRecord> appRunRecords = null;
                List<RunRecordList.RunRecord> watchRecords = null;
                for (RunRecordList.RunRecord record : runRecords) {
                    if (record.getType() == 3) {//手表
                        if (watchRecords == null) {
                            watchRecords = new ArrayList<>();
                        }
                        watchRecords.add(record);
                    } else {
                        if (appRunRecords == null) {
                            appRunRecords = new ArrayList<>();
                        }
                        appRunRecords.add(record);
                    }
                }
                boolean success = false;
                if (appRunRecords != null) {
                    //3.将乐享动app产生的记录与本地数据库记录同步
                    success = SportRecordsHelper.bulkAddOrUpdateRunRecords(appRunRecords);
                }
                if (watchRecords != null) {
                    //4.将手表产生的记录与本地数据库记录同步
                    success = WatchSportDataHelper.bulkAddOrUpdateRecords(watchRecords);
                }

                //5.从数据请求状态表中,清除还在缓存有效期内的请求结果
                if (success) {
                    UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(2));
                }
            }
        }
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        if (sportType == Config.SPORT_TYPE_RUN) {
            MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
            if (fragment != null) {
                fragment.refreshRunLogList();
            }
        }
    }

    /**
     * 设置我的跳绳记录列表
     *
     * @param result 网络请求返回的结果
     */
    public void setSkipRecordList(String result) {
        SkipRecordList skipRecordList = JsonHelper.getObject(result, SkipRecordList.class);
        if (skipRecordList != null) {
            //1.更新最近一次获取用户历史跳绳记录的时间戳
            long lastUpdateTime = skipRecordList.getLastAddTime();
            SettingsHelper.putLong(Config.SETTING_SKIP_RECORD_SYNC_TIME, lastUpdateTime);
            List<SkipRecordList.SkipRecord> skipRecords = skipRecordList.getNewX();
            if (skipRecords != null && skipRecords.size() > 0) {
                //2.将跳绳记录与本地数据库记录同步
                boolean success = SportRecordsHelper.bulkAddOrUpdateSkipRecords(skipRecords);
                //3.从数据请求状态表中,清除还在缓存有效期内的请求结果
                if (success) {
                    UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(12));
                }
            }
        }
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        if (sportType == Config.SPORT_TYPE_SKIP) {
            MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
            if (fragment != null) {
                fragment.refreshSkipLogList();
            }
        }
    }

    /**
     * 退出登录
     */
    private void logout() {
        stopStepCount();
        //1.重新设置Uid,登录类型
        UserDataManager.setUid(Config.ANONYMOUS_UID);
        PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        //2.清除三方登录openid,access token
        AccessTokenKeeper.clear(this);
        //3.清除数据请求表
        MixApp.getDaoSession(this).getDataReqStatusDao().deleteAll();
        //4.启动登录界面
        startLoginActivity();
    }

    /**
     * 刷新 彩蛋
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshMineFragmentSurprise(boolean ignorePreCache) {
        LocationInfo locationInfo = getLastLocationInfo();
        String newCity = null;
        if (locationInfo != null) {
            newCity = locationInfo.getCity();
        }
        if (TextUtils.isEmpty(newCity)) {
            setMineFragmentSurprise(null);
            return;
        }
        int requestId2 = UserDataManager.getInstance().getSurpriseInfo(newCity, ignorePreCache);
        registerDataReqStatusListener(requestId2);
    }

    /**
     * 设置彩蛋内容
     */
    public void setMineFragmentSurprise(String sResult) {
        MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            fragment.setSurpriseInfo(sResult);
        }
    }

    /**
     * 设置用户信息,总的跑步记录
     */
    private void setUserInfo(String result) {
        Login login = JsonHelper.getObject(result, Login.class);
        int gender = 0;
        int age = 0;
        int height = 0;
        int weight = 0;

        if (login != null) {
            //设置我的界面,个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
            user = login.getUser();
            if (user != null) {
                //重要个人信息(身高、体重、年龄、性别)存在数据库表中
                gender = user.getGender();
                age = user.getAge();
                if (user.getType() == 2) {//英制转公制
                    height = (int) (user.getHeight() * 2.54f);
                    weight = (int) (user.getWeight() * 0.4535924f);
                } else {
                    height = user.getHeight();
                    weight = user.getWeight();
                }
            }

            MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);

            if (fragment != null && user != null) {
                int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
                loadDataBySportType(sportType);
                fragment.setUserAvatar(user.getId(), user.getAvatar());//头像
                fragment.setUserGender(gender);//性别
                fragment.setUserName(user.getName());//昵称
                fragment.setSignature(user.getSignature());//设置个性签名

                UserRunStatistics userRunStatistics = login.getUserRunStatistics();
                if (userRunStatistics != null) {
                    int saveLevel = SettingsHelper.getInt(Config.SETTING_USER_LEVEL, 0);
                    int level = userRunStatistics.getUserLevel();
                    if (level > saveLevel) {
                        SettingsHelper.putInt(Config.SETTING_USER_LEVEL, level);//更新用户当前等级
                        fragment.setUserLevel(level);
                    } else {
                        fragment.setUserLevel(saveLevel);
                    }
                }

                fragment.setMySettingMessage(getShowAppUpdate() || getShowAccountMessage());
                fragment.setCoinTaskMessageShow(getShowCoinTaskMessage());
//                fragment.setPersonInfoMessageShow(getShowPersonInfoMessage());
            }
        }

        //2.判断用户信息是否合格,如果不合格则跳转到用户信息补充界面
        boolean userInfoNotValid = false;
        if (age < 6 || age > 100) {
            userInfoNotValid = true;
        }
        if (height < 100 || height > 220) {
            userInfoNotValid = true;
        }
        if (weight < 20 || weight > 125) {
            userInfoNotValid = true;
        }
        if (gender != Config.GENDER_FEMALE && gender != Config.GENDER_MALE) {
            userInfoNotValid = true;
        }
        if (userInfoNotValid) {
            startUserInfoActivity();
            return;
        }

        //3.保存用户信息到数据库
        if (userInfoChanged) {
            SettingsHelper.putInt(Config.SETTING_USER_HEIGHT, height);
            SettingsHelper.putInt(Config.SETTING_USER_WEIGHT, weight);
            SettingsHelper.putInt(Config.SETTING_USER_AGE, age);
            SettingsHelper.putInt(Config.SETTING_USER_GENDER, gender);
            SettingsHelper.putInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age));//存储最大心率
            SettingsHelper.putString(Config.SETTING_USER_AVATAR, user.getAvatar());
            SettingsHelper.putString(Config.SETTING_USER_NAME, user.getName());
            userInfoChanged = false;
        }
    }

    /**
     * 显示选择运动方式dialog
     */
    public void showChooseSportTypeDialog() {
        ChangeSportTypeDialog changeSportTypeDialog = new ChangeSportTypeDialog();
        changeSportTypeDialog.setOnActionClickListener(new ChangeSportTypeDialog.ActionTypeClickListener() {
            @Override
            public void onActionClick(int type) {//根据选择的按钮不同 选择不同的回调方法
                loadDataBySportType(type);
            }
        });
        changeSportTypeDialog.show(this.getSupportFragmentManager(), "changeSportTypeDialog");
    }

    /**
     * 刷新界面
     *
     * @param type 选择的运动类型
     */
    private void loadDataBySportType(int type) {
        MineFragment fragment = (MineFragment) getSupportFragmentManager().findFragmentByTag(MineFragment.TAG);
        if (fragment != null) {
            fragment.setViewStyleBySportType(type);
            setToolbar(true, false, R.string.title_fragment_mine);
            if (user != null) {
                switch (type) {
                    case Config.SPORT_TYPE_RUN:
                        fragment.setTotalRunTime(user.getRunTime());//运动总时长
                        fragment.setTotalRunCalorie(user.getCalorie());//总消耗
                        fragment.setTotalRunSteps(user.getStep());//总步数
                        fragment.setTotalRunDistance(user.getDistance());//总距离
                        fragment.setHearRateData(user.getLastRunHeartRate(), user.getConsumeFatSum());
                        if (btn_run != null) {
                            btn_run.setText(getString(R.string.activity_main_run));
                        }
                        fragment.refreshRunLogList();
                        break;
                    case Config.SPORT_TYPE_SKIP:
                        if (user.getSumSkipRope() != null) {
                            fragment.setTotalSkipCalorie(user.getSumSkipRope().getCalorie());
                            fragment.setTotalSkipTime(user.getSumSkipRope().getRunTime());
                            fragment.setTotalSkipNumber(user.getSumSkipRope().getSkipNum());//总个数
                            fragment.setHearRateData(user.getLastRunHeartRate(), user.getConsumeFatSum());
                        } else {
                            fragment.setTotalSkipCalorie(0);
                            fragment.setTotalSkipTime(0);
                            fragment.setTotalSkipNumber(0);//总个数
                        }
                        if (btn_run != null) {
                            btn_run.setText(getString(R.string.activity_main_skip));
                        }
                        fragment.refreshSkipLogList();
                        break;
                }
            } else {
                loadDataForMineFragment();
            }
        }
    }

    //endregion ================================ MineFragment交互相关 ================================

    //region ================================ MusicFragment交互相关 ================================

    @Override
    public void onSportPageRefresh() {
        startRefreshMusicFragment(true);
    }

    @Override
    public void onRadioPageRefresh() {
        startRefreshMusicFragmentRadio(true);
    }

    /**
     * 加载MusicFragment需要的数据
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    private void loadDataForMusicFragment(boolean ignorePreCache) {
        startRefreshMusicFragment(ignorePreCache);
        startRefreshMusicFragmentRadio(ignorePreCache);
    }

    /**
     * 刷新 musicFragment
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshMusicFragment(boolean ignorePreCache) {
        int requestId = MusicDataManager.getInstance().getAlbumList(Config.REQUEST_MUSIC_ALBUM, ignorePreCache);
        registerDataReqStatusListener(requestId);

        int requestId2 = MusicDataManager.getInstance().getBannerList(ignorePreCache);
        registerDataReqStatusListener(requestId2);
    }

    /**
     * 刷新 musicFragment电台
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshMusicFragmentRadio(boolean ignorePreCache) {
        int requestId3 = MusicDataManager.getInstance().getAlbumRadioList(Config.REQUEST_RADIO_ALBUM, ignorePreCache);
        registerDataReqStatusListener(requestId3);
    }

    /**
     * 刷新专辑列表
     */
    public void stopRefreshMusicFragmentAlbumList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
            if (albumList == null || albumList.getList() == null || albumList.getList().size() <= 0)
                return;
            List<Album> list = new ArrayList<>();
            list.addAll(albumList.getList());
            if (OperateMusicUtils.getAlbumNumber() > 0) {
                list.addAll(OperateMusicUtils.getAlbumList());
            }
            fragment.showAlbumList(list);
        }
    }

    /**
     * 刷新电台
     */
    public void stopRefreshMusicFragmentRadioList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
            if (albumList == null || albumList.getList() == null || albumList.getList().size() <= 0)
                return;
            List<Album> list = new ArrayList<>();
            list.addAll(albumList.getList());
            fragment.showRadioList(list);
        }
    }

    /**
     * 刷新banner
     */
    public void stopRefreshMusicFragmentBannerList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            BannerList bannerList = JsonHelper.getObject(sResult, BannerList.class);
            if (bannerList == null || bannerList.getData() == null || bannerList.getData().size() <= 0)
                return;
            fragment.showBanner(bannerList.getData());
        }
    }

    /**
     * 主要用来获取收藏歌曲的信息
     * 数据库中可能不存在该歌曲
     */
    private void getMusicInfoByIdList() {
        int loginType = PrefsHelper.with(MainActivity.this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        final List<Integer> list = new ArrayList<>();
        String sResult = "";
        switch (loginType) {
            case 1:
                sResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_USER + 2);
                break;
            case 2:
                sResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_USER + 3);
                break;
            case 3:
                sResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_USER + 4);
                break;
            case 4:
                sResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_USER + 5);
                break;
            case 5:
                sResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_USER + 2);
                break;
        }
        if (TextUtils.isEmpty(sResult)) return;
        Login login = JsonHelper.getObject(sResult, Login.class);//可能的卡顿点
        if (login != null) {
            List<Integer> idList = login.getCollectIds();//收藏列表
            if (idList != null && idList.size() > 0) {
                for (Integer integer : idList) {
                    if (OperateMusicUtils.getMusicById(integer) == null) {
                        list.add(integer);
                    }
                }
            }
        }
        if (OperateMusicUtils.getMusicById(46) == null) {//美好的一天开始于5公里晨跑
            list.add(46);
        }
        if (list.size() <= 0) return;

        int requestId3 = MusicDataManager.getInstance().getMusicListInfo(list, true);
        registerDataReqStatusListener(requestId3);
    }

    //endregion ================================ MusicFragment交互相关 ================================

    //region ================================ ClubFragment交互相关 ================================

    /**
     * 加载俱乐部Fragment所需的数据
     */
    private void loadDataForClubFragment() {
        startRefreshClubFragmentList(false);
    }

    /**
     * 加载ClubFragment需要的数据
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshClubFragmentList(boolean ignorePreCache) {
        int uid = UserDataManager.getUid();
        int requestId = ClubDataManager.getInstance().getClubList(uid, ignorePreCache);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void createClub(String clubName, String clubDesc, String fileName) {
        int requestId = ClubDataManager.getInstance().createClub(clubName, clubDesc, fileName, "image", false);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void afterCreateClub(boolean isSuccess) {
        if (isSuccess) {
            onBackPressed();
            startRefreshClubFragmentList(true);
        }
    }

    /**
     * 处理俱乐部邀请
     */
    private void processClubInvite() {
        //处理俱乐部邀请
        String inviteClubIds = PrefsHelper.with(this, Config.PREFS_CLUB).read(Config.SP_KEY_INVITE_CLUB_IDS, "");
        String inviteClubNames = PrefsHelper.with(this, Config.PREFS_CLUB).read(Config.SP_KEY_INVITE_CLUB_NAMES, "");
        if (TextUtils.isEmpty(inviteClubIds)) return;
        if (TextUtils.isEmpty(inviteClubNames)) return;
        if (UserDataManager.getUid() < 0) return;
        if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_NONE) return;
        String message = String.format(getString(R.string.fm_club_invite_format), inviteClubNames);
        new MaterialDialog.Builder(this)
                .title(R.string.fm_club_invite_tip)
                .content(message)
                .positiveText(R.string.fm_club_invite_join)
                .negativeText(R.string.fm_club_invite_ignore)
                .cancelable(false)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                joinClub();
                                break;
                            case NEGATIVE:
                                break;
                        }
                        PrefsHelper.with(MainActivity.this, Config.PREFS_CLUB).write(Config.SP_KEY_INVITE_CLUB_IDS, "");
                        PrefsHelper.with(MainActivity.this, Config.PREFS_CLUB).write(Config.SP_KEY_INVITE_CLUB_NAMES, "");
                    }
                }).show();
    }

    /**
     * 加入俱乐部
     */
    private void joinClub() {
        if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_NONE) {
            showAppMessage(R.string.check_network, AppMsg.STYLE_INFO);
            return;
        }
        String inviteClubIds = PrefsHelper.with(this, Config.PREFS_CLUB).read(Config.SP_KEY_INVITE_CLUB_IDS, "");
        int requestId = ClubDataManager.getInstance().joinClub(inviteClubIds, UserDataManager.getUid(), false);
        registerDataReqStatusListener(requestId);
    }

    public void stopRefreshClubFragmentList(String sResult) {
        ClubFragment fragment = (ClubFragment) getSupportFragmentManager().findFragmentByTag(ClubFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            ClubList clubListInfo = JsonHelper.getObject(sResult, ClubList.class);
            if (clubListInfo != null) {
                List<Club> clubList = clubListInfo.getList();
                if (clubList != null) {
                    for (int i = 0; i < clubList.size(); i++) {
                        if (clubList.get(i).getType() == 2) {//2是开放俱乐部的标志 俱乐部假退出功能
                            boolean showOpenCLub = SettingsHelper.getBoolean(Config.SETTING_SHOW_OPEN_CLUB, true);
                            if (!showOpenCLub) {
                                clubList.remove(clubList.get(i));
                            }
                            break;
                        }
                    }
                    Club club = new Club();
                    club.setName(getResources().getString(R.string.fm_club_create_club));
                    club.setBackImageUrl(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.add_club)).build().toString());
                    clubList.add(club);
                    fragment.stopRefresh(clubList);
                }
            }
        }
    }

    //endregion ================================ ClubFragment交互相关 ================================

    //region ================================ DiscoveryFragment交互相关 ================================

    @Override
    public void onTopicRefresh(int topicListOrderType) {
        startRefreshTopicList(topicListOrderType, true);
    }

    @Override
    public void onTopicLoadMore(int topicListOrderType) {
        startLoadMoreTopicList(topicListOrderType);
    }

//    @Override
//    public void onCompetitionRefresh() {
//        //startRefreshCompetitionList(true);
//    }
//
//    @Override
//    public void onCompetitionLoadMore() {
//        startLoadMoreCompetitionList();
//    }

    @Override
    public void onVideoRefresh() {
        startRefreshVideoList(true);
    }

    @Override
    public void onVideoLoadMore() {
        startLoadMoreVideoList();
    }

    /**
     * 加载DiscoveryFragment需要的数据
     */
    private void loadDataForDiscoveryFragment() {
        startRefreshDiscoveryFragmentList(false);
    }

    /**
     * 请求赛事列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshDiscoveryFragmentList(boolean ignorePreCache) {
//        startRefreshCompetitionList(ignorePreCache);
        startRefreshVideoList(ignorePreCache);
        startRefreshTopicList(1, ignorePreCache);//默认按时间排序
    }

    /**
     * 请求话题列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshTopicList(int topicListOrderType, boolean ignorePreCache) {
        topicListIndex = 1;
        int requestId = DiscoverDataManager.getInstance().getTopicList(topicListIndex, topicListOrderType, ignorePreCache);
        registerDataReqStatusListener(requestId);

        int requestId1 = DiscoverDataManager.getInstance().getHandPickTopicList(ignorePreCache);
        registerDataReqStatusListener(requestId1);
    }

    /**
     * 加载更多话题列表
     */
    public void startLoadMoreTopicList(int topicListOrderType) {
        int requestId = DiscoverDataManager.getInstance().getTopicList(topicListIndex, topicListOrderType, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 请求运动视频列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshVideoList(boolean ignorePreCache) {
        videoListIndex = 1;
        int requestId = DiscoverDataManager.getInstance().getVideoList(videoListIndex, ignorePreCache);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 加载更多视频信息
     */
    public void startLoadMoreVideoList() {
        int requestId = DiscoverDataManager.getInstance().getVideoListForLoadMore(videoListIndex, true);
        registerDataReqStatusListener(requestId);
    }

//    /**
//     * 请求运动赛事列表
//     *
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     */
//    public void startRefreshCompetitionList(boolean ignorePreCache) {
//        competitionListIndex = 1;
//        int requestId = DiscoverDataManager.getInstance().getCompetitionList(competitionListIndex, ignorePreCache);
//        registerDataReqStatusListener(requestId);
//    }

//    /**
//     * 加载更多赛事列表
//     */
//    public void startLoadMoreCompetitionList() {
//        int requestId = DiscoverDataManager.getInstance().getCompetitionListForLoadMore(competitionListIndex, true);
//        registerDataReqStatusListener(requestId);
//    }

    /**
     * 完成话题列表获取,设置界面数据
     */
    public void stopRefreshTopicList(String sResult) {
        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            TopicList topicList = JsonHelper.getObject(sResult, TopicList.class);
            List<Topic> list = new ArrayList<>();
            if (topicList != null && topicList.getPage() != null) {
                list.addAll(topicList.getPage().getResult());
            }
            fragment.showTopicList(list, topicListIndex);
            topicListIndex++;
        }
    }

    /**
     * 完成精选话题列表获取,设置界面数据
     */
    public void setHandpickTopic(String sResult) {
        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            HandPickTopicList handPickTopicList = JsonHelper.getObject(sResult, HandPickTopicList.class);
            if (handPickTopicList != null) {
                List<Topic> list = handPickTopicList.getBanners();
                fragment.setHandpickTopic(list);
            } else {
                fragment.setHandpickTopic(null);
            }
        }
    }

    /**
     * 完成视频列表获取,设置界面数据
     */
    public void stopRefreshVideoList(String sResult) {
        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            VideoList videoList = JsonHelper.getObject(sResult, VideoList.class);
            List<Video> list = new ArrayList<>();
            if (videoList != null && videoList.getPage() != null) {
                list.addAll(videoList.getPage().getResult());
            }
            fragment.showVideoList(list, videoListIndex);
            if (list.size() > 0) videoListIndex++;
        }
    }

    /**
     * 加载视频更多失败
     */
    public void stopRefreshVideoListWithError() {
        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            fragment.showVideoListError();
        }
    }

//    /**
//     * 完成赛事列表获取,设置界面数据
//     */
//    public void stopRefreshCompetitionList(String sResult) {
//        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
//        if (fragment != null && fragment.isVisible()) {
//            CompetitionList competitionList = JsonHelper.getObject(sResult, CompetitionList.class);
//            if (competitionList != null) {
//                List<Competition> list = new ArrayList<>();
//                if (competitionList.getPage() != null) {
//                    list.addAll(competitionList.getPage().getResult());
//                }
//                long serverTime = competitionList.getSYSTIME();
//                fragment.showCompetitionList(list, serverTime, competitionListIndex);
//                if (list.size() > 0) competitionListIndex++;
//            }
//        }
//    }
//
//    /**
//     * 加载赛事更多失败
//     */
//    public void stopRefreshCompetitionListWithError() {
//        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
//        if (fragment != null && fragment.isVisible()) {
//            fragment.showCompetitionListError();
//        }
//    }

    //endregion ================================ DiscoveryFragment交互相关 ================================

    //region ================================ 启动其它Activity ================================

    /**
     * 启动个人信息编辑界面
     */
    public void startEditProfileActivity() {
        Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityForResult(intent, REQUEST_EDIT_USER_INFO);
    }

    /**
     * 启动运动级别说明界面
     */
    public void startLevelExplainActivity() {
        Intent intent = new Intent(MainActivity.this, LevelExplainActivity.class);
        startActivity(intent);
    }

    /**
     * 启动跑步设置界面
     */
    private void startRunSettingActivity(View view) {
        Intent intent = new Intent();
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        switch (sportType) {
            case Config.SPORT_TYPE_RUN:
                intent.setClass(MainActivity.this, RunSettingActivity.class);
                break;
            case Config.SPORT_TYPE_SKIP:
                intent.setClass(MainActivity.this, SkipSettingActivity.class);
                break;
        }
        //这个是用户手动设置的歌曲 优先级比较高
        String musicString = SettingsHelper.getString(Config.SETTING_EXPERT_MUSIC, "");
        if (!TextUtils.isEmpty(musicString)) {
            intent.putExtra("musicInfo", musicString);
        } else {
            //这个是用后台推荐的歌曲 优先级比较低
            //当用户没有设置过歌曲就使用推荐的歌曲作为默认设置的歌曲
            String recommendMusic = SettingsHelper.getString(Config.RECOMMEND_MUSIC, "");
            if (!TextUtils.isEmpty(recommendMusic)) {
                intent.putExtra("musicInfo", recommendMusic);
            } else {
                //当推荐的歌曲为空时 就使用默认的歌曲 跑步使用 美好一天开始于5公里晨跑 跳绳使用 行动起来
                Music music;
                switch (sportType) {
                    case Config.SPORT_TYPE_RUN:
                        if (PlayerController.getInstance().isMusicPlaying()) {
                            intent.putExtra("musicInfo", JsonHelper.createJsonString(PlayerController.getInstance().getCurrentMusic()));
                        } else {
                            music = OperateMusicUtils.getMusicById(46);
                            if (music != null) {
                                intent.putExtra("musicInfo", JsonHelper.createJsonString(music));
                            } else {
                                Music mMusicInfo = new Music();
                                mMusicInfo.setId(46);
                                mMusicInfo.setName("美好一天开始于5公里晨跑");
                                mMusicInfo.setBpm("144");
                                mMusicInfo.setAuthor("DJ Shine");
                                mMusicInfo.setAlbumUrl("http://yyssb.ifitmix.com//1001/8a163b37b26e4bee9f976cad312f7446.JPG");
                                mMusicInfo.setUrl("http://yyssb.ifitmix.com//1000/3e6d8e36e14e47d799f9df08aa60dfd0.m4a");
                                intent.putExtra("musicInfo", JsonHelper.createJsonString(mMusicInfo));
                            }
                        }

                        break;
                    case Config.SPORT_TYPE_SKIP:
                        music = OperateMusicUtils.getMusicById(473);
                        if (music != null) {
                            intent.putExtra("musicInfo", JsonHelper.createJsonString(music));
                        } else {
                            Music mMusicInfo = new Music();
                            mMusicInfo.setId(473);
                            mMusicInfo.setName(getResources().getString(R.string.go_now));
                            mMusicInfo.setBpm("110");
                            mMusicInfo.setAuthor(getResources().getString(R.string.hip_hop));
                            mMusicInfo.setAlbumUrl("http://yyssb.ifitmix.com/1001/7867552709824aa89e45352c7ded62d5.jpg");
                            mMusicInfo.setUrl("http://yyssb.ifitmix.com/1000/c876335d896442bd875ed7be6c933f5d.m4a");
                            intent.putExtra("musicInfo", JsonHelper.createJsonString(mMusicInfo));
                        }
                        break;
                }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            ActivityOptionsCompat options = ActivityOptionsCompat.makeScaleUpAnimation(view, view.getWidth() / 2,
                    view.getHeight() / 2, 0, 0);//从右下角展开
            ActivityCompat.startActivity(MainActivity.this, intent, options.toBundle());
        } else {
            startActivity(intent);
            overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
        }
    }

    /**
     * 启动登录界面
     */
    public void startLoginActivity() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("startMain", true);
        startActivity(intent);
        finish();
    }

    /**
     * 启动运动记录界面
     */
    public void startSportRecordActivity() {
        Intent intent = new Intent(MainActivity.this, SportRecordActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("startMain", true);
        startActivity(intent);
    }

    /**
     * 启动我的装备界面
     */
    public void startEquipmentActivity() {
        Intent intent = new Intent(MainActivity.this, EquipmentActivity.class);
        intent.putExtra("sendBindCmd", sendBindCmd);
        startActivity(intent);
    }

    /**
     * 启动我的设置界面
     */
    public void startSettingActivity() {
        Intent intent = new Intent(MainActivity.this, SettingActivity.class);
        startActivity(intent);
    }

    /**
     * 启动训练计划界面
     */
    public void startTrainingPlanActivity() {
        Intent intent = new Intent(MainActivity.this, TrainingPlanActivity.class);
        startActivity(intent);
    }

    /**
     * 启动静息心率界面
     */
    public void startHeartRateActivity() {
        Intent intent = new Intent(MainActivity.this, HeartRateActivity.class);
        startActivity(intent);
    }

    /**
     * 启动我的金币导航界面
     */
    public void startCoinMainActivity() {
        PrefsHelper.with(this, Config.PREFS_USER).writeLong(Config.SP_KEY_LAST_VIEW_COIN_TASK_TIME, System.currentTimeMillis());//写时间
        Intent intent = new Intent(MainActivity.this, CoinMainActivity.class);
        startActivity(intent);
    }

    /**
     * 启动排行榜界面
     */
    public void startRankListActivity() {
        Intent intent = new Intent(MainActivity.this, RankListActivity.class);
        intent.putExtra("isFromHome", true);
        intent.putExtra("thisLevel", thisLevel);
        startActivity(intent);
    }

    /**
     * 启动虾米音乐
     */
    private void startXiaMiMusic() {
        try {//尝试启动虾米音乐APP
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("xiami://open?url=http://h.xiami.com/sport.html?ch=10007781"));
            startActivity(intent);
        } catch (Exception e) {
            try {//启动失败或手机未安装虾米音乐APP
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://h.xiami.com/sportapp.html?id=228037095&ch=10007781"));
                startActivity(intent);
            } catch (Exception ex) {
                showAppMessage(R.string.fm_music_launch_xiami_fail, AppMsg.STYLE_ALERT);
            }
        }
    }

    /**
     * 启动个人消息通知界面
     */
    private void startMessageNoticeActivity() {
        Intent intent = new Intent();
        intent.setClass(this, MessageNoticeActivity.class);
        //  intent.setClass(this, com.fitmix.sdk.view.widget.recyclerviewenhanced.MainActivity.class);
        startActivity(intent);
    }

    /**
     * 启动用户信息补充界面
     */
    private void startUserInfoActivity() {
        Intent intent = new Intent();
        intent.setClass(this, UserInfoActivity.class);
        if (user != null) {
            intent.putExtra("gender", user.getGender());
            intent.putExtra("age", user.getAge() > 0 ? user.getAge() : Config.USER_DEFAULT_AGE);
            intent.putExtra("nickName", user.getName());
            intent.putExtra("avatar", user.getAvatar());
            intent.putExtra("signature", user.getSignature());

            if (user.getType() == 2) {
                //英制转公制
                int height = (int) (user.getHeight() * 2.54f);
                int weight = (int) (user.getWeight() * 0.4535924f);
                intent.putExtra("height", height);
                intent.putExtra("weight", weight);
            } else {
                intent.putExtra("height", user.getHeight());
                intent.putExtra("weight", user.getWeight());
            }
        }
        startActivityForResult(intent, REQUEST_EDIT_USER_INFO);
    }

    //endregion ================================ 启动其它Activity ================================

    //region ================================ 图片选择裁剪 ================================

    /**
     * 从相册或相机获取图片
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
        avatarId = view.getId();//保存ID,之后图片设置用
    }

    /**
     * 剪裁图片
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(43, 58)//172 232
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    //endregion ================================ 图片选择裁剪 ================================

    /**
     * 添加Fragment到back stack
     *
     * @param fragment 要添加的fragment
     * @param tag      fragment tag
     */
    public void pushFragment(Fragment fragment, String tag) {
//        Log.i("TT", "pushFragment-->Tag:" + tag);
        if (fragment == null) return;
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                    //.setCustomAnimations(R.animator.push_left_in, R.animator.push_left_out, R.animator.push_right_in, R.animator.push_right_out)
                    .addToBackStack(null)
                    .replace(R.id.mainContainer, fragment, tag)
                    .commit();
        }
    }

    /**
     * 设置 toolbar
     *
     * @param showIcon   是否显示左侧图标
     * @param showBack   是否显示返回按钮
     * @param titleResId toolbar标题字符串资源ID
     */
    public void setToolbar(boolean showIcon, boolean showBack, int titleResId) {
        if (toolbar == null) return;
        toolbar.setNavigationIcon(null);
        toolbar.setNavigationOnClickListener(null);
        if (showBack) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        } else {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            }
            if (titleResId == R.string.title_fragment_music) {//动听Fragment左边显示搜索
                toolbar.setNavigationIcon(R.drawable.menu_search);
                toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {//音乐搜索
                        Intent intent = new Intent();
                        intent.setClass(MainActivity.this, SearchMusicActivity.class);
                        startActivity(intent);
                    }
                });
            }
            //跳绳模块
            boolean isConnected = SettingsHelper.getBoolean(Config.CONNECTED_SKIP_DEVICE, false);//是否连接过跳绳设备
            if (showIcon && isConnected) {
                if (titleResId == R.string.title_fragment_mine) {//我的Fragment左边显示切换运动方式
                    int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
                    switch (sportType) {
                        case 1:
                            toolbar.setNavigationIcon(R.drawable.icon_run);
                            break;
                        case 2:
                            toolbar.setNavigationIcon(R.drawable.icon_tiaoshen);
                            break;
                    }
                    toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {//切换运动方式窗口展开
                            showChooseSportTypeDialog();
                        }
                    });
                }
            }
        }

        String title = getString(titleResId);
        if (!TextUtils.isEmpty(title)) {
            setUiTitle(title);
        }
    }

    /**
     * 设置 toolbar
     *
     * @param showBack   是否显示返回按钮
     * @param titleResId toolbar标题字符串资源ID
     */
    public void setToolbar(boolean showBack, int titleResId) {
        this.setToolbar(true, showBack, titleResId);
    }

    /**
     * 设置标题是否有viewPager
     *
     * @param viewPager viewPager,注意要作为Fragment的field,否则造成内存泄漏.
     */
    public void setIndicator(ViewPager viewPager, String[] titles) {
        setUiIndicator(viewPager, titles);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_run://开始运动
                startRunSettingActivity(v);
                break;

            //region ============================= Fragment Music 我的音乐 =============================
            case R.id.nav_download_music://下载音乐
                pushFragment(new MusicDownloadFragment(), "musicDownload");
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "\"下载音乐\"");
                break;

            case R.id.nav_recent_played_music://最近播放
                pushFragment(new MusicRecentFragment(), "musicRecent");
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "\"最近播放\"");
                break;

            case R.id.nav_favorite_music://我的收藏
                pushFragment(new MusicFavoriteFragment(), "musicFavorite");
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "\"我的收藏\"");
                break;

            case R.id.nav_other_source_music://外部音乐
                if (OperateMusicUtils.getLocalMusicNumber() > 0) {
                    pushFragment(new MusicOtherSourceFragment(), "musicOtherSource");
                } else {
                    pushFragment(new MusicImportFragment(), "musicImport");
                }
                break;

            case R.id.nav_xiami_music://虾米音乐
                startXiaMiMusic();
                break;

            //endregion ============================= Fragment Music 我的音乐 =============================

            //region ============================= Fragment Mine 我的 =============================

            case R.id.btn_login_status://个人信息面板
                startEditProfileActivity();
                break;

            case R.id.img_user_level://运动等级图标
                startLevelExplainActivity();
                break;

            case R.id.my_record://运动记录
                startSportRecordActivity();
                break;
            case R.id.my_equipment://我的装备
                startEquipmentActivity();
                break;
            case R.id.my_setting://我的设置
                startSettingActivity();

                break;
            case R.id.my_training_plan://训练计划
                startTrainingPlanActivity();
                break;
            case R.id.my_heart_rate://静息心率
                startHeartRateActivity();
                break;
            case R.id.my_coin_quest://金币系统
                startCoinMainActivity();
                break;
            case R.id.fragment_mine_rank_view://排行榜
                startRankListActivity();
                break;
            //endregion ============================= Fragment Mine 我的 =============================

            case R.id.delete_prompt:
                setTrainPlanPrompt(null, true);
                break;
        }
    }

    /*//在首页按返回键回到桌面
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {//防止华为机型未加入白名单时按返回键回到桌面再锁屏后几秒钟进程被杀
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            home.addCategory(Intent.CATEGORY_HOME);
            startActivity(home);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }*/

    @Override
    public void onBackPressed() {
        //回退fragment栈
        int stackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        Logger.i(Logger.DEBUG_TAG, "MainActivity-->onBackPressed stackEntryCount:" + stackEntryCount);
        if (stackEntryCount > 0) {
            if (stackEntryCount == 1 && currentNavIndex == FRAGMENT_PAGE_MUSIC) {
                //由于我的音乐标签下的[下载音乐],[最近播放],[我的收藏]等Fragment是replace方式添加的,因此从这些Fragment返回时,
                // MusicFragment会失效,重新加载数据
                loadDataForMusicFragment(false);
                Logger.i(Logger.DEBUG_TAG, "MainActivity-->onBackPressed load data for musicFragment");
            }
            if (ftCanCommit) {
                getSupportFragmentManager().popBackStack();
            }

        } else {
            if (getEmuiLeval() > 0) {
                Intent home = new Intent(Intent.ACTION_MAIN);
                home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                home.addCategory(Intent.CATEGORY_HOME);
                startActivity(home);
            } else {
                showExitTip();
            }
        }

    }


    /**
     * 显示退出登录对话框
     */
    private void showLogoutDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.logout)
                .content(R.string.fm_mine_more_force_logout_tip)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://注销登录
                                logout();
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 退出APP提示
     */
    private void showExitTip() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_main_exit_tip)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://MainActivity一直会在task底,退出MainActivity即退出程序
                                if (!TextUtils.isEmpty(XGPushConfig.getToken(MainActivity.this))) {
                                    uploadDeviceStatus(0, XGPushConfig.getToken(MainActivity.this));//取消app的活跃状态
                                }
                                finish();
                                break;

                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;
            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    View v = findViewById(avatarId);
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (v != null && bitmap != null) {
                        ImageHelper.adjustPhotoToFitSize(bitmap, Config.USER_CLUB_WIDTH, Config.USER_CLUB_HEIGHT, FitmixUtil.getTempPhotoFile());
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

            case SELECT_SONG_ADD_TO_LIST://点击选择歌曲操作（我的收藏fragment、下载歌曲fragment、最近播放fragment）
                if (data == null) break;
                String msg = data.getStringExtra(SelectSongActivity.NET_TOAST_TO_SHOW);
                boolean success = data.getBooleanExtra(SelectSongActivity.IS_SUCCESS, false);
                if (msg != null) {
                    if (success) {
                        showAppMessage(msg, AppMsg.STYLE_INFO);//提示操作后的信息（成功）
                    } else {
                        showAppMessage(msg, AppMsg.STYLE_ALERT);//提示操作后的信息（错误）
                    }
                }
                break;

            case REQUEST_EDIT_USER_INFO://个人信息修改
                if (resultCode == RESULT_OK) {
                    userInfoChanged = true;
                }
                break;

            case MusicFragment.CREATE_PLAY_LIST://自建歌单
            case MusicFragment.CHANGE_PLAY_LIST://修改自建歌单
                if (resultCode == RESULT_OK) {//成功
                    startRefreshMusicFragment(false);//刷新数据
                }
                break;

            case DiscoveryFragment.REQUEST_ADD_TOPIC://添加话题
            case DiscoveryFragment.REQUEST_VIEW_TOPIC://查看话题
                if (resultCode == RESULT_OK) {//需要重新刷新话题列表
                    Logger.i(Logger.DEBUG_TAG, "MainActivity-->onActivityResult startRefreshTopicList");
                    DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
                    if (fragment != null && fragment.isVisible()) {
                        fragment.requestTopicListData();//按当前界面上选定的顺序再请求数据
                    }
                }
                break;

            default:
                if (resultCode == RESULT_OK) {//三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareMixCoinTask();
                            }

                            break;
                    }
                }
                break;
        }
    }

    //region ================================ 权限处理相关 ================================
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        //不处理
    }

    //endregion ================================ 权限处理相关 ================================

    //region ================================ 消息推送相关 ================================

    public class LocalReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) {
                return;
            }

            boolean showRedPoint = intent.getBooleanExtra("showRedPoint", false);
            if (showRedPoint) {
                SettingsHelper.putBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, true);
                showMessageNote = true;
                if (radio_mine != null) radio_mine.showBadge(true);
                invalidateOptionsMenu();
            }
        }
    }

    //本地广播监听消息提醒
    private LocalReceiver localReceiver;

    /**
     * 如果有未读的消息提醒 显示红点
     */
    private void checkMessageExist() {
        if (radio_discovery != null) {
            if (MessageHelper.getInstance().hasCompetitionMessage()) {
                radio_discovery.showBadge(true);
            } else {
                radio_discovery.showBadge(false);
            }
        }
        if (radio_club != null) {
            if (MessageHelper.getInstance().hasClubMessage()) {
                radio_club.showBadge(true);
            } else {
                radio_club.showBadge(false);
            }
        }
        if (radio_mine != null) {
            if (getShowAppUpdate() || getShowPersonInfoMessage() || getShowAccountMessage()) {//
                radio_mine.showBadge(true);
            } else {
                radio_mine.showBadge(false);
            }
        }
    }

    /**
     * @return 显示app升级提示红点
     */
    private boolean getShowAppUpdate() {
        boolean showAppUpdate = false;
        int newVersion = SettingsHelper.getInt(Config.SETTING_NEW_VERSION, -1);
        int appVersion = ApiUtils.getApkVersionCode();//造成卡顿
        if (appVersion < newVersion) {
            boolean isClickAboutAs = SettingsHelper.getBoolean(Config.SETTING_VERSION_UPDATE, false);
            int ignoreVersion = SettingsHelper.getInt(Config.SETTING_IGNORE_VERSION, -1);
            if (ignoreVersion < newVersion && !isClickAboutAs) {
                showAppUpdate = true;
            }
        }
        return showAppUpdate;
    }

    /**
     * @return 是否显示个人信息红点
     */
    private boolean getShowPersonInfoMessage() {
        return SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, 0) == 0
                || SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, 0) == 0;
    }

    /**
     * @return 是否显示账号设置红点
     */
    private boolean getShowAccountMessage() {
        return !SettingsHelper.getBoolean(Config.SETTING_BIND_MOBILE, false)
                && TextUtils.isEmpty(SettingsHelper.getString(Config.SETTING_USER_MOBILE, ""));
    }

    /**
     * 注册消息推送本地广播及蓝牙状态监控广播
     */
    private void registerLocalBroadCast() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.fitmix.broadcasttest.LOCAL_BROADCAST");
        localReceiver = new LocalReceiver();
        LocalBroadcastManager.getInstance(this).registerReceiver(localReceiver, intentFilter); // 注册本地广播监听器

        IntentFilter statusFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mStatusReceive, statusFilter);
    }

    /**
     * 注销消息推送本地广播
     */
    private void unregisterLocalBroadCast() {
        if (localReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(localReceiver);
        }
    }

    //region ####################### 信鸽推送 #######################

    /**
     * 根据用户是否打开消息推送,上传设备信息,开启消息推送
     */
    private void uploadUserDeviceInfo() {
        boolean messagePush = SettingsHelper.getBoolean(Config.SETTING_MESSAGE_PUSH, true);
        if (messagePush) {
            // 开启logcat输出,方便debug,发布时请关闭
            XGPushConfig.enableDebug(this, BuildConfig.DEBUG);
            // 如果需要知道注册是否成功,请使用registerPush(getApplicationContext(), XGIOperateCallback)带callback版本
            // 如果需要绑定账号,请使用registerPush(getApplicationContext(),account)版本
            // 具体可参考详细的开发指南
            // 传递的参数为ApplicationContext
//            XGPushManager.registerPush(context);
            Context context = getApplicationContext();

            final String reservedToken = XGPushConfig.getToken(context);//当设备一旦注册成功后,便会将token存储在本地,之后可通过XGPushConfig.getToken(context)接口获取
            if (!TextUtils.isEmpty(reservedToken)) {//获取设备的token,只有注册成功才能获取到正常的结果
                int requestId = UserDataManager.getInstance().uploadUserDeviceInfo(reservedToken, true);
                registerDataReqStatusListener(requestId);
                Logger.i(Logger.XG_TAG, "uploadUserDeviceInfo-->XGPushConfig.getToken:" + reservedToken);

                uploadDeviceStatus(1, reservedToken);//激活 用户app的活跃状态  首页消息图标红点显示相关
            }

            // 注册
            XGPushManager.registerPush(context, new XGIOperateCallback() {
                @Override
                public void onSuccess(Object token, int flag) {
                    Logger.i(Logger.XG_TAG, "XGPushManager-->registerPush onSuccess token:" + token + ",flag:" + flag);
                    String deviceToken = (String) token;
                    if (!TextUtils.isEmpty(deviceToken) && !deviceToken.equals(reservedToken)) {//新token与之前的不一样再次更新上传设备信息
                        int requestId = UserDataManager.getInstance().uploadUserDeviceInfo(deviceToken, true);
                        registerDataReqStatusListener(requestId);

                        uploadDeviceStatus(1, deviceToken);//激活 用户app的活跃状态  首页消息图标红点显示相关
                    }
                }

                @Override
                public void onFail(Object token, int flag, String s) {
                    Logger.e(Logger.XG_TAG, "XGPushManager-->registerPush onFail token:" + token + ",flag:" + flag + ",error msg:" + s);
                }
            });

            // 在XGPushManager.registerPush(context)或其它版本的注册接口之后调用以下代码
            // 使用ApplicationContext,已知MIUI V6上会禁用所有静态广播,若出现有类似的情况,请添加以下代码兼容该系统
//            Intent service = new Intent(context, XGPushService.class);
//            context.startService(service);
            Logger.i(Logger.XG_TAG, "uploadUserDeviceInfo-->registerPush");
        } else {
            XGPushManager.unregisterPush(getApplicationContext());//注销
            Logger.i(Logger.XG_TAG, "uploadUserDeviceInfo-->unregisterPush");
        }
    }

    //endregion ####################### 信鸽推送 #######################

    //endregion ================================ 消息推送相关 ================================

    //region  ================================ 金币任务 ================================

    /**
     * 获取一次性任务列表
     */
    private void getHonorTaskList() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().getHonorTaskList(uid, true);
        registerDataReqStatusListener(requestId);
        coinTaskCreateJoinClub = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_CREATE_JOIN_CLUB, true);
    }

    /**
     * 完成创建或加入俱乐部金币任务
     */
    private void finishCreateJoinClubCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_CREATE_JOIN_CLUB, true);
        registerDataReqStatusListener(reqId);
    }

    /**
     * 完成每日分享歌曲金币任务
     */
    private void finishShareMixCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_MIX, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareMixCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * @return 是否显示金币任务红点
     */
    private boolean getShowCoinTaskMessage() {
        long lastViewCoinTask = PrefsHelper.with(this, Config.PREFS_USER).readLong(Config.SP_KEY_LAST_VIEW_COIN_TASK_TIME, 0);
        return !FitmixUtil.isToday(lastViewCoinTask);
    }

    /**
     * 获取一次性金币任务
     */
    private void setOnceTaskList(String result) {
        TaskList allTasks = JsonHelper.getObject(result, TaskList.class);
        if (allTasks != null && allTasks.getTaskList() != null) {
            CoinTaskInfo taskEntity;
            String taskKey;
            int finishStatus;
            for (int i = 0; i < allTasks.getTaskList().size(); i++) {
                taskEntity = allTasks.getTaskList().get(i);
                if (taskEntity != null) {
                    if (taskEntity.getTaskType() == Config.COIN_TASK_TYPE_ONCE) {//一次性任务
                        finishStatus = taskEntity.getFinishStatus();
                        taskKey = taskEntity.getTaskKey();
                        if (taskKey == null) {
                            break;
                        }
                        switch (taskKey) {
                            case Config.COIN_TASK_EMAIL_BIND_KEY://绑定邮箱
                                if (finishStatus == 0) {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_EMAIL, true);
                                } else {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_EMAIL, false);
                                    //如果当前是新注册的邮箱登录,默认完成邮箱绑定
                                    int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
                                    boolean isNewEmail = PrefsHelper.with(this, Config.PREFS_USER).readBoolean(Config.SP_KEY_IS_NEW_EMAIL_REGISTER, false);
                                    if (loginType == 1 && isNewEmail) {
                                        finishBindEmailCoinTask();
                                    }
                                }
                                break;

                            case Config.COIN_TASK_PHONE_BIND_KEY://绑定手机
                                if (finishStatus == 0) {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_PHONE, true);
                                } else {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_PHONE, false);
                                    //如果当前是新注册的手机登录,默认完成手机绑定
                                    int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
                                    boolean isNewPhone = PrefsHelper.with(this, Config.PREFS_USER).readBoolean(Config.SP_KEY_IS_NEW_PHONE_REGISTER, false);
                                    if (loginType == 5 && isNewPhone) {
                                        finishBindPhoneCoinTask();
                                    }
                                }
                                break;

                            case Config.COIN_TASK_COMPLETE_PERSONAL_INFO://完善个人资料
                                if (finishStatus == 0) {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_PERSONAL_INFO, true);
                                } else {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_PERSONAL_INFO, false);
                                }
                                break;

                            case Config.COIN_TASK_COMPLETE_COMPETITION_INFO://完善个人参赛资料
                                if (finishStatus == 0) {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_COMPETITION_INFO, true);
                                } else {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_COMPETITION_INFO, false);
                                }
                                break;

                            case Config.COIN_TASK_CREATE_JOIN_CLUB://创建或者加入俱乐部
                                if (finishStatus == 0) {
                                    coinTaskCreateJoinClub = true;
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_CREATE_JOIN_CLUB, true);
                                } else {
                                    coinTaskCreateJoinClub = false;
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_CREATE_JOIN_CLUB, false);
                                }
                                break;

                            case Config.COIN_TASK_PAIRING_BT://使用我的设备配对一次
                                if (finishStatus == 0) {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);
                                } else {
                                    SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, false);
                                }
                                break;
                        }
                    }
                }
            }

        }
    }

    /**
     * 完成绑定邮箱金币任务
     */
    private void finishBindEmailCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishEmailBindCoinTask(uid, true);
        registerDataReqStatusListener(reqId);
    }

    /**
     * 完成绑定手机金币任务
     */
    private void finishBindPhoneCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishPhoneBindCoinTask(uid, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion  ================================ 金币任务 ================================

    //region ================================ 弹窗广告 ================================

    @Override
    protected void bindWatchService() {
        super.bindWatchService();
    }

    /**
     * 设置弹窗广告
     */
    private void setPopWindowAd(Init init) {
        if (init == null)
            return;
        List<Announcements> announcementsList = init.getAnnouncements();
        if (announcementsList == null)
            return;

        String adString = SettingsHelper.getString(Config.SETTING_APP_HOME_AD_SHOW_INFO, "");
        JSONArray jsonArray = null;

        if (!TextUtils.isEmpty(adString)) {
            try {
                jsonArray = new JSONArray(adString);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);//在当前月份的第几天

        JSONArray newJsonArray = new JSONArray();
        if (TextUtils.isEmpty(adString) || jsonArray == null || jsonArray.length() == 0) {//判断缓存是否为空
            for (int i = 0; i < announcementsList.size(); i++) {
                Announcements announcements = announcementsList.get(i);
                int id = announcements.getId();
                String imgLink = announcements.getImgLink();
                int displayNum = announcements.getDisplayNum();
                String body = announcements.getBody();
                int type = announcements.getType();
                JSONObject jsonObject = new JSONObject();
                try {
                    if (i == 0) {
                        showAdView(type, imgLink, body);//首次展示广告
                        jsonObject.put("index", i);
                        jsonObject.put("id", id);
                        jsonObject.put("displayNum", 1);
                        jsonObject.put("imgLink", imgLink);
                        jsonObject.put("type", type);
                        jsonObject.put("body", body);
                        jsonObject.put("allDisplayNum", displayNum);
                        jsonObject.put("showDate", day);//特定日期
                    } else {
                        jsonObject.put("index", i);
                        jsonObject.put("id", id);
                        jsonObject.put("displayNum", 0);
                        jsonObject.put("imgLink", imgLink);
                        jsonObject.put("type", type);
                        jsonObject.put("body", body);
                        jsonObject.put("allDisplayNum", displayNum);
                        jsonObject.put("showDate", day);
                    }

                    newJsonArray.put(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            if (newJsonArray.length() > 0) {
                SettingsHelper.putString(Config.SETTING_APP_HOME_AD_SHOW_INFO, newJsonArray.toString());
            }
        } else {
            try {
                if (jsonArray.getJSONObject(0).getInt("showDate") < day) {
                    for (int i = 0; i < announcementsList.size(); i++) {
                        Announcements announcements = announcementsList.get(i);
                        int id = announcements.getId();
                        String imgLink = announcements.getImgLink();
                        int type = announcements.getType();
                        String body = announcements.getBody();
                        int displayNum = announcements.getDisplayNum();
                        JSONObject jsonObject = new JSONObject();
                        try {
                            if (i == 0) {
                                showAdView(type, imgLink, body);//首次展示广告
                                jsonObject.put("index", i);
                                jsonObject.put("id", id);
                                jsonObject.put("displayNum", 1);
                                jsonObject.put("imgLink", imgLink);
                                jsonObject.put("type", type);
                                jsonObject.put("body", body);
                                jsonObject.put("allDisplayNum", displayNum);
                                jsonObject.put("showDate", day);
                            } else {
                                jsonObject.put("index", i);
                                jsonObject.put("id", id);
                                jsonObject.put("displayNum", 0);
                                jsonObject.put("imgLink", imgLink);
                                jsonObject.put("type", type);
                                jsonObject.put("body", body);
                                jsonObject.put("allDisplayNum", displayNum);
                                jsonObject.put("showDate", day);
                            }
                            newJsonArray.put(jsonObject);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } else if (jsonArray.getJSONObject(0).getInt("showDate") == day) {
                    for (int i = 0; i < announcementsList.size(); i++) {
                        Announcements announcements = announcementsList.get(i);
                        int id = announcements.getId();
                        String imgLink = announcements.getImgLink();
                        int type = announcements.getType();
                        String body = announcements.getBody();
                        int displayNum = announcements.getDisplayNum();
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("index", i);
                        jsonObject.put("id", id);
                        jsonObject.put("displayNum", 0);
                        jsonObject.put("imgLink", imgLink);
                        jsonObject.put("type", type);
                        jsonObject.put("body", body);
                        jsonObject.put("allDisplayNum", displayNum);
                        jsonObject.put("showDate", day);

                        JSONObject jsonObject1;
                        for (int j = 0; j < jsonArray.length(); j++) {
                            jsonObject1 = jsonArray.getJSONObject(j);
                            if (id == jsonObject1.getInt("id")) {
                                jsonObject.put("displayNum", jsonObject1.getInt("displayNum"));
                            }
                        }
                        newJsonArray.put(jsonObject);
                    }
                    //即将展示的广告在集合中的位置，从0开始算
                    if (newJsonArray.length() > 0) {
                        int lastShowAdIndex = SettingsHelper.getInt(Config.SETTING_APP_HOME_AD_SHOW_NUM, 0) % newJsonArray.length();
                        int showAdIndex;
                        if (lastShowAdIndex == 0) {
                            showAdIndex = 0;
                        } else {
                            showAdIndex = lastShowAdIndex;
                        }
                        int displayNum = newJsonArray.getJSONObject(showAdIndex).getInt("displayNum");
                        int allDisplayNum = newJsonArray.getJSONObject(showAdIndex).getInt("allDisplayNum");
                        int type = newJsonArray.getJSONObject(showAdIndex).getInt("type");
//                        int id = newJsonArray.getJSONObject(showAdIndex).getInt("id");
                        String imgLink = newJsonArray.getJSONObject(showAdIndex).getString("imgLink");
                        String body = newJsonArray.getJSONObject(showAdIndex).getString("body");
                        if (displayNum < allDisplayNum) {//展示当前showAdIndex广告图片
                            showAdView(type, imgLink, body);
                            newJsonArray.getJSONObject(showAdIndex).put("displayNum", displayNum + 1);
                        } else {
                            ArrayList<Boolean> haveDisplayPics = new ArrayList<>();
                            for (int i = showAdIndex + 1; i < newJsonArray.length(); i++) {//从showAdIndex+1开始遍历查找
                                int displayNum_i = newJsonArray.getJSONObject(i).getInt("displayNum");
                                int allDisplayNum_i = newJsonArray.getJSONObject(i).getInt("allDisplayNum");
                                int type_i = newJsonArray.getJSONObject(i).getInt("type");
                                String body_i = newJsonArray.getJSONObject(i).getString("body");
//                                int id_i = newJsonArray.getJSONObject(i).getInt("id");
                                String imgLink_i = newJsonArray.getJSONObject(i).getString("imgLink");
                                if (displayNum_i < allDisplayNum_i) {
                                    showAdView(type_i, imgLink_i, body_i);//展示第i个广告图片
                                    newJsonArray.getJSONObject(i).put("displayNum", displayNum + 1);
                                    return;
                                }
                                if (displayNum_i == allDisplayNum_i && i == newJsonArray.length()) {
                                    haveDisplayPics.add(true);
                                }
                            }
                            if (haveDisplayPics.size() > 0 && haveDisplayPics.get(0) && showAdIndex > 0) {
                                for (int i = 0; i < showAdIndex; i++) {
                                    int displayNum_i = newJsonArray.getJSONObject(i).getInt("displayNum");
                                    int allDisplayNum_i = newJsonArray.getJSONObject(i).getInt("allDisplayNum");
                                    int type_i = newJsonArray.getJSONObject(i).getInt("type");
                                    String imgLink_i = newJsonArray.getJSONObject(i).getString("imgLink");
//                                    int id_i = newJsonArray.getJSONObject(i).getInt("id");
                                    String body_i = newJsonArray.getJSONObject(i).getString("body");
                                    if (displayNum_i < allDisplayNum_i) {
                                        showAdView(type_i, imgLink_i, body_i);//展示第i个广告图片
                                        newJsonArray.getJSONObject(i).put("displayNum", displayNum + 1);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }

                if (jsonArray.length() > 0) {
                    SettingsHelper.putString(Config.SETTING_APP_HOME_AD_SHOW_INFO, newJsonArray.toString());
                    Logger.d(Logger.DEBUG_TAG, "jsonArray:" + SettingsHelper.getString(Config.SETTING_APP_HOME_AD_SHOW_INFO, ""));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 显示弹窗广告
     *
     * @param type    点击广告跳转类型(2:网页,3:话题,4:MIX音乐,5:赛事)
     * @param imgLink 广告图片链接地址
     * @param body    点击广告跳转需要的内容(跳转类型为2时是网址,为3时是话题编号,为4时是MIX编号,为5时是赛事编号)
     */
    private void showAdView(final int type, String imgLink, final String body) {
//        Logger.e(Logger.DEBUG_TAG, "showAdView================");
        if (adDialog == null) {
            adDialog = new Dialog(this, R.style.dialog);
        }
        View adView = LayoutInflater.from(this).inflate(R.layout.home_ad_dialog_view, null);
        ImageView closeIv = (ImageView) adView.findViewById(R.id.ad_close_iv);
        SimpleDraweeView pic_sv = (SimpleDraweeView) adView.findViewById(R.id.ad_dialog_pic_view);
        pic_sv.setImageURI(Uri.parse(imgLink));
        closeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adDialog.dismiss();
            }
        });

        pic_sv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                switch (type) {
                    case 2://外链
                        if (FitmixUtil.isValidHttpUrl(body)) {
                            intent.setClass(MainActivity.this, WebViewActivity.class);
                            intent.putExtra("url", body);
                            intent.putExtra("title", "详情");
                            intent.putExtra("fromSplashActivity", false);
                            startActivity(intent);
                        }
                        break;
                    case 3://话题
                        intent.setClass(MainActivity.this, TopicDetailActivity.class);
                        intent.putExtra("topicId", Integer.parseInt(body));
                        intent.putExtra("isFromXgNotify", true);
                        startActivity(intent);
                        break;
                    case 4://MIX音乐
                        intent.setClass(MainActivity.this, PlayMusicActivity.class);
                        intent.putExtra("isFromXinGe", true);
                        intent.putExtra("musicId", Integer.parseInt(body));
                        intent.putExtra("index", 0);
                        startActivity(intent);
                        break;
                    case 5://赛事
                        intent.setClass(MainActivity.this, WebViewActivity.class);
                        intent.putExtra("competitionString", body);
                        intent.putExtra("title", getResources().getString(R.string.activity_main_competitions_detail));
                        intent.putExtra("isCanShare", true);
                        startActivity(intent);
                        break;
                }
                adDialog.dismiss();
            }
        });
        adDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                adDialog.dismiss();
            }
        });
        adDialog.setCanceledOnTouchOutside(true);
        adDialog.setContentView(adView);
        adDialog.show();
        SettingsHelper.putInt(Config.SETTING_APP_HOME_AD_SHOW_NUM,
                SettingsHelper.getInt(Config.SETTING_APP_HOME_AD_SHOW_NUM, 0) + 1);
    }
    //endregion ================================ 弹窗广告 ================================

    //region ================================ Override 父类方法 ================================
    @Override
    protected void initWatchServiceFunction() {
        mWatchServiceFun = new WatchService.ServiceFunction() {

            @Override
            public void onDeviceConnected() {
                Logger.i(Logger.DEBUG_TAG, "MainActivity-->onDeviceConnected()");
                mConnectRetry = false;
                startWatchService();
            }

            @Override
            public void onDeviceReady() {
                Logger.i(Logger.DEBUG_TAG, "MainActivity-->onDeviceReady()");
                queryWatchVersion();
                phoneTypeSetting();
                syncWatchDateAndTime();
                languageSetting();
                setUserInfo();
            }

            @Override
            public void onDeviceDisconnected() {
                Logger.i(Logger.DEBUG_TAG, "MainActivity-->onDeviceDisconnected()");
                mConnectRetry = true;
                autoConnectWatch();//蓝牙断开后,尝试自动连接
            }

            @Override
            public void onResponse(int groupTag, int cell, int iPos, final int result) {
                //不处理
            }

            @Override
            public void onReceiveDataRefreshUi(int groupTag, final String dataJson) {
                switch (groupTag) {
                    case WatchDataProtocol.TAG_GROUP_UPGRADE://查询手表固件版本
                        watchVersion = JsonHelper.getObject(dataJson, WatchVersion.class);
                        if (watchVersion != null) {
                            final String versionNum = watchVersion.getVersionNum();
                            final String versionName = watchVersion.getVersionName();
                            final String apolloVersionNum = watchVersion.getApolloVersionNum();
                            Logger.i(Logger.DEBUG_TAG, "查询手表固件版本 versionNum:" + versionNum + ",versionName:" + versionName
                                    + ",apolloVersionNum:" + apolloVersionNum);
                            if (versionNum != null) {
                                getWatchUpgrade(versionNum);
                            }
                            SettingsHelper.putInt(Config.SETTING_WATCH_VERSIONNUM, Integer.parseInt(versionNum));

                        }
                        break;
                }
            }
        };
    }

    @Override
    protected void onSearchWatchSuccess(BluetoothDevice device) {
        mWatch = device;
        // 缓存下 device
        DeviceLocalUtil.putDevice2Local(device);
        bindWatchService();
    }

    @Override
    protected void onWatchServiceConnected() {
        // 忽略省电优化
        ignoreBatteryOptimization(this);
        if (mWatchService.getDevice() == null && mWatch != null) {//连接设备
            mWatchService.connectDevice(mWatch);
        }
    }

    @Override
    protected void onSearchWatchStop() {
        if (mConnectRetry) {
            mConnectRetry = false;
            autoConnectWatch();
        }
    }

    //endregion ================================ Override 父类方法 ================================

    //region ================================ 手表蓝牙自动连接 ================================

    private BluetoothDevice mWatch;
    /**
     * 蓝牙非正常断开后,自动重连次数,大于2不再尝试
     */
    private boolean mConnectRetry;

    /**
     * 自动连接手表
     */
    private void autoConnectWatch() {
        //1.检查用户是否有手表设备
        String info = SettingsHelper.getString(Config.SETTING_WATCH_INFO, "");
        WatchInfo watchInfo = JsonHelper.getObject(info, WatchInfo.class);
        String watchMacAddress;
        if (watchInfo == null) {
            sendBindCmd = true;
            return;
        }
        watchMacAddress = watchInfo.getMac();
        if (watchMacAddress == null) {
            sendBindCmd = true;
            return;
        }
        //2.检查当前手机蓝牙是否开启,当开启时查找手表并连接
        if (isBluetoothReady()) {
            BluetoothDevice device = DeviceLocalUtil.checkLocalDevice(watchMacAddress);
            if (device != null) {
                Logger.d(Logger.DEBUG_TAG, "MainActivity Device in local ------");
                onSearchWatchSuccess(device);
                return;
            }

            Logger.d(Logger.DEBUG_TAG, "MainActivity isSearching------");
            searchWatch(watchMacAddress, 24000);
        }

    }


    private BroadcastReceiver mStatusReceive = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case BluetoothAdapter.ACTION_STATE_CHANGED:
                    int blueState = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);
                    switch (blueState) {
                        case BluetoothAdapter.STATE_TURNING_ON:
                            break;
                        case BluetoothAdapter.STATE_ON:
                            Logger.d(Logger.DEBUG_TAG, "MainActivity 蓝牙打开了");
                            autoConnectWatch();
                            break;
                        case BluetoothAdapter.STATE_TURNING_OFF:
                            break;
                        case BluetoothAdapter.STATE_OFF:

                            break;
                    }
                    break;
            }
        }
    };


    //endregion ================================ 手表蓝牙自动连接 ================================


    //region ================================ 手表固件升级提示 ================================

    /**
     * 查询手表固件版本
     */
    private void queryWatchVersion() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            int uid = UserDataManager.getUid(); //后续带乐享动uid
            byte[] data = WatchFormatManager.getWatchVersion(uid);
//            byte[] data = WatchFormatManager.getWatchVersion();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_QUERY);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置手表语言
     */
    private void languageSetting() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            String lan = "1";//默认为中文
            String appLan = ApiUtils.getLanguage();
            if (appLan != null && !appLan.endsWith("zh")) {
                lan = "0";
            }
            byte[] data = WatchFormatManager.getLanguageSettingData(lan);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_LANGUAGE);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置手表日期时间为手机当前日期和时间
     */
    private void syncWatchDateAndTime() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            long time = System.currentTimeMillis();
            SimpleDateFormat formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_DATA_FORMAT,
                    Locale.getDefault());

            Date curDate = new Date(time);
            String date = formatterTime.format(curDate);
            formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_TIME_FORMAT, Locale.getDefault());
            String currentTime = formatterTime.format(curDate);
            int timeZone = TimeZone.getDefault().getOffset(time) / 3600000;
            byte[] data = WatchFormatManager.getSynchronizeTime(date, currentTime, String.valueOf(timeZone));
            if (data.length != 0) {
                int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_TIME, WatchDataProtocol.TIME_BLE_RESERVED);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 告诉手表当前手机系统类型为android
     */
    private void phoneTypeSetting() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getAndroidPhoneInfo();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_PHONE_SYSTEM);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            //    showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 向手表发送用户信息
     */
    private void setUserInfo() {
        int gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
        int height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        int weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);

        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getUserInfo(gender, age, height, weight * 10);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_USERINFO, WatchDataProtocol.USERINFO_BLE_RESERVED);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //  showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 从服务器获取手表固件升级包
     *
     * @param versionNum 当前手表固件版本号
     */
    public void getWatchUpgrade(String versionNum) {
        int requestId = UserDataManager.getInstance().watchFirmwareVersion(versionNum, true);//
        registerDataReqStatusListener(requestId);
    }


    //手表新版本强制提示框
    private void showNoticeDialogForce() {
        new MaterialDialog.Builder(this)
                .title(R.string.new_watch_version_tip)
                .content(R.string.watch_version_force_tip)
                .cancelable(false)
                .positiveText(R.string.update_ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                startVersionInfoActivity(true);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, true);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
                                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, Integer.parseInt(watchUpgrade.getNewVersion()));
                                break;

                            case NEGATIVE://取消下载
                                finish();
                                break;
                        }
                    }
                }).show();

    }

    //手表新版本提示框
    private void showNoticeDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.new_watch_version_tip)
                .content(R.string.watch_version_select_tip)
                .positiveText(R.string.update_now)
                .negativeText(R.string.update_later)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                startVersionInfoActivity(false);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, false);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, true);
                                break;

                            case NEGATIVE://取消下载

                                break;
                        }
                    }
                }).show();
    }

    /**
     * 启动手表固件版本查看、升级界面
     */
    private void startVersionInfoActivity(boolean force) {
        Intent intent = new Intent(this, WatchVersionInfoActivity.class);
        intent.putExtra("macAddress", mWatch.getAddress());//当前连接的设备地址
        if (watchVersion != null) {
            intent.putExtra("curVersionName", watchVersion.getVersionName());
        }
        if (force) {
            intent.putExtra("forceUpdateClick", true);
        } else {
            intent.putExtra("selectUpdateClick", true);
        }
        startActivity(intent);
    }

    //endregion ================================ 手表固件升级提示 ================================

}
