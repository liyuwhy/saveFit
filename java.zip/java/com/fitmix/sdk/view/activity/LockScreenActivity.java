package com.fitmix.sdk.view.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.text.Html;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.service.SkipService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;

import static com.fitmix.sdk.Config.MSG_REPEAT_EVERY_SECOND;

public class LockScreenActivity extends BaseActivity {

    private TextView textDistance;
    private TextView textSkipNumber;
    private TextView textCalorie;
    private TextView textSpeed;
    private TextView textBPM;
    private TextView textHeartRate;
    private TextView textTime;
    private boolean bOnlyStep;
    private int sportType;

    private boolean isDialogShow;//信息弹框是否已经存在了,保证只显示一次
    private MaterialDialog mDialog;

    /**
     * 自定义handler
     */
    private static class MyHandler extends WeakHandler {
        public MyHandler(LockScreenActivity lockScreenActivity) {
            super(lockScreenActivity);
        }

        public void handleMessage(Message msg) {
            LockScreenActivity activity = (LockScreenActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case MSG_REPEAT_EVERY_SECOND:
                    activity.refresh();
                    if (activity.mHandler != null) {
                        activity.mHandler.sendEmptyMessageDelayed(MSG_REPEAT_EVERY_SECOND, 1000);
                    }
                    break;
            }
        }


    }

    /**
     * LockScreenActivity页面中定义的handler
     */
    private MyHandler mHandler;

    //region ======================== Activity 生命周期相关 ==============================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Window win = getWindow();
        Logger.i(Logger.DEBUG_TAG, "LockScreenActivity-->onCreate");

//        if (keepScreenOn) {
//            win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
//                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
//                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
//                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
//            );//524288
//        } else {
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
//                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );//524288
//        }

        super.onCreate(savedInstanceState);
        int sportType = getIntent().getIntExtra("sportType", Config.SPORT_TYPE_RUN);
        setPageName("LockScreenActivity");
        gestureDetector = new GestureDetector(this, new OnDoubleClick());
        setSportType(sportType);
        switch (sportType) {
            case Config.SPORT_TYPE_RUN:
                setOnlyStep(getIntent().getBooleanExtra("only_step", false));
                setContentView(R.layout.activity_lockscreen);
                connectToRunService();
                break;
            case Config.SPORT_TYPE_SKIP:
                setContentView(R.layout.activity_lockscreen_skip);
                connectToSkipService();
                break;
        }
        initViews();
    }

    protected void initViews() {
        switch (getSportType()) {
            case Config.SPORT_TYPE_RUN:
                initRunViews();
                break;
            case Config.SPORT_TYPE_SKIP:
                initSkipViews();
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        //重写点击分发
//		Log.i("TT","onTouchEvent");
        return gestureDetector.onTouchEvent(event); //super.onTouchEvent(event);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mHandler == null) {
            mHandler = new MyHandler(this);
        }

        switch (getSportType()) {
            case Config.SPORT_TYPE_RUN:
                if (runService != null && runService.isScreenOff()
                        && (runService.isGpsLoss() || runService.isSensorLoss())) {
                    wakeUpAndUnlock();
//                    finish();//屏幕熄灭,且gps点丢失时或sensor不响应,销毁activity,在下一次重建LockScreenActivity时将点亮
                } else {
                    Logger.i(Logger.DEBUG_TAG, "LockScreenActivity-->refresh");
                    mHandler.sendEmptyMessageDelayed(MSG_REPEAT_EVERY_SECOND, 1000);
                }
                break;
            case Config.SPORT_TYPE_SKIP:
                if (skipService != null && skipService.isScreenOff()) {
                    finish();//屏幕熄灭,销毁activity,在下一次重建LockScreenActivity时将点亮
                } else {
                    if (mHandler == null) {
                        mHandler = new MyHandler(this);
                    }
                    mHandler.sendEmptyMessageDelayed(MSG_REPEAT_EVERY_SECOND, 1000);
                }
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
    }

    @Override
    protected void onDestroy() {
        disconnectToRunService();
        disconnectToSkipService();
        super.onDestroy();
        if (mDialog != null) {
            mDialog.dismiss();
        }
    }


    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    //endregion ======================== Activity 生命周期相关 ==============================

    // region ======================== 跑步运动 ==============================

    private void refreshRunInfo() {
        if (runService == null)
            return;
        if (isOnlyStep()) {
            if (textDistance != null)
                textDistance.setText(String.valueOf(runService.getTodaySteps()));
        } else {
            if (textDistance != null)
                textDistance.setText(FormatUtil.formatDistance(runService.getRunDistance()));
        }
        if (textSpeed != null)
            textSpeed.setText(FormatUtil.formatSpeed(runService.getRunSpeed()));

        if (textCalorie != null)
            textCalorie.setText(String.valueOf(runService.getRunCalorie()));
        if (textTime != null)
            textTime.setText(FormatUtil.formatRunTime(runService.getRunTime() / 1000));
        if (textHeartRate != null) {
            textHeartRate.setText(runService.getLatestHeartRate() <= 0 ? getResources().getString(R.string.heart_rate_unknown) : String.valueOf(runService.getLatestHeartRate()));
        }

        String sBpm = "" + runService.getRunBpm();
        if (textBPM != null)
            textBPM.setText(Html.fromHtml(sBpm));

    }

    private boolean isOnlyStep() {
        return bOnlyStep;
    }

    private void setOnlyStep(boolean bValue) {
        bOnlyStep = bValue;
    }

    private RunService runService;

    private void connectToRunService() {
        if (runService != null) return;
        Intent intent = new Intent(this, RunService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);

    }

    private void disconnectToRunService() {
        if (runService == null) return;
        unbindService(connection);
        runService = null;
    }

    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            runService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (!name.getClassName().equals(RunService.SERVICE_NAME))
                return;
            runService = ((RunService.LocalBinder) service).getService();
            refresh(Config.SPORT_TYPE_RUN);
        }
    };


    // endregion ======================== 跑步运动 ==============================

    // region ======================== 跳绳运动 ==============================

    private void refreshSkipInfo() {
        if (skipService == null)
            return;
        if (textSkipNumber != null)
            textSkipNumber.setText(String.valueOf(skipService.getSkipNumber()));
        if (textCalorie != null)
            textCalorie.setText(String.valueOf((int) skipService.getSkipCalorie()));
        if (textTime != null)
            textTime.setText(FormatUtil.formatRunTime(skipService.getSkipTime() / 1000));
        if (textHeartRate != null)
            textHeartRate.setText(skipService.getHeartRate() == 0 ? getResources().getString(R.string.heart_rate_unknown) : String.valueOf(skipService.getHeartRate()));
    }

    private SkipService skipService;

    private void connectToSkipService() {
        if (skipService != null) return;
        Intent intent = new Intent(this, SkipService.class);
        bindService(intent, skipConnection, Context.BIND_AUTO_CREATE);
    }

    private void disconnectToSkipService() {
        if (skipService == null) return;
        unbindService(skipConnection);
        skipService = null;
    }

    private ServiceConnection skipConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            skipService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (!name.getClassName().equals(SkipService.SERVICE_NAME))
                return;
            skipService = ((SkipService.LocalBinder) service).getService();
            refresh(Config.SPORT_TYPE_SKIP);
        }
    };
    // endregion ======================== 跳绳运动 ==============================

    public static boolean sIsFromLock = false;
    private GestureDetector gestureDetector;
//    private boolean keepScreenOn = false;//是否屏幕常亮
//    private int turnOnScreenReason;//点亮屏幕的原因,1:GPS丢失 2:传感器不响应

    /// 双击事件监听
    private class OnDoubleClick extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onDoubleTap(MotionEvent e) {
//			Log.i("TT","onDoubleTap!!!! windows is active:"+getWindow().isActive());
            //XXX 跳转到主跑界面
            handleClickEvent();
            return false;//super.onDoubleTap(e);
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            Toast.makeText(LockScreenActivity.this, R.string.activity_lockscreen_click_tip, Toast.LENGTH_SHORT).show();
            return super.onSingleTapConfirmed(e);
        }
    }


    public int getSportType() {
        return sportType;
    }

    public void setSportType(int sportType) {
        this.sportType = sportType;
    }


    private void initRunViews() {
        textDistance = (TextView) findViewById(R.id.distance);
        textCalorie = (TextView) findViewById(R.id.calorie);
        textSpeed = (TextView) findViewById(R.id.speed);
        textBPM = (TextView) findViewById(R.id.bpm);
        textTime = (TextView) findViewById(R.id.time);
        textHeartRate = (TextView) findViewById(R.id.heart_rate);
        if (isOnlyStep()) {
            findViewById(R.id.run_data_group).setVisibility(View.GONE);
            findViewById(R.id.run_info_title_group).setVisibility(View.GONE);
            TextView textUnit = (TextView) findViewById(R.id.unit);
            textUnit.setText(R.string.steps_unit);
        }
    }

    private void initSkipViews() {
        textSkipNumber = (TextView) findViewById(R.id.skip_number);
        textCalorie = (TextView) findViewById(R.id.calorie);
        textHeartRate = (TextView) findViewById(R.id.skip_heart_rate);
        textTime = (TextView) findViewById(R.id.time);
    }


    private void refresh() {
        refresh(getSportType());
    }

    private void refresh(int type) {
        switch (type) {
            case Config.SPORT_TYPE_RUN:
                refreshRunInfo();
                break;
            case Config.SPORT_TYPE_SKIP:
                refreshSkipInfo();
                break;
        }
    }

    private void handleClickEvent() {
        Intent intent;
        switch (getSportType()) {
            case Config.SPORT_TYPE_RUN:
                sIsFromLock = true;
                if (isOnlyStep()) {
                    intent = new Intent(LockScreenActivity.this, SettingStepActivity.class);
                } else {
                    intent = new Intent(LockScreenActivity.this, RunMainActivity.class);
                }
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                finish();
                break;
            case Config.SPORT_TYPE_SKIP:
                sIsFromLock = true;
                intent = new Intent(LockScreenActivity.this, SkipMainActivity.class);
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                finish();
                break;
        }
    }

    public void myClickHandler(View v) {
        switch (v.getId()) {
            case R.id.close:
                sIsFromLock = false;
                finish();
                break;
        }
    }

    /**
     * 显示为何亮屏对话框
     */
    public void showTurnOnScreenDialog() {
        MaterialDialog.Builder builder = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                    }
                }).dismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        isDialogShow = false;
                    }
                });

        if (runService != null) {
            if (runService.isGpsLoss()) {
                builder.content(R.string.activity_lockscrenn_gps_loss);
            } else if (runService.isSensorLoss()) {
                builder.content(R.string.activity_lockscrenn_sensor_loss);
            }
            mDialog = builder.build();
            Logger.i(Logger.DEBUG_TAG, "LockScreenActivity-->showTurnOnScreenDialog ftCanCommit:" + ftCanCommit);
            if (ftCanCommit && !isDialogShow) {
                mDialog.show();
                isDialogShow = true;
            }
        }
    }

    /**
     * 唤醒手机屏幕并解锁
     */
    public void wakeUpAndUnlock() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean screenOn = pm.isScreenOn();
        if (!screenOn) {
            PowerManager.WakeLock wl = pm.newWakeLock(
                    PowerManager.ACQUIRE_CAUSES_WAKEUP |
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "bright");
            wl.acquire(10000); // 点亮屏幕
            wl.release(); // 释放
        }
        // 屏幕解锁
//        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
//        KeyguardManager.KeyguardLock keyguardLock = keyguardManager.newKeyguardLock("unLock");
//        keyguardLock.disableKeyguard(); // 解锁
        Logger.i(Logger.DEBUG_TAG, "LockScreenActivity-->wakeUpAndUnlock");
        showTurnOnScreenDialog();
    }

}
