package com.fitmix.sdk.view.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.BuildConfig;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.AppUpgradeManager;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.CheckAppVersion;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class AboutUsActivity extends BaseActivity {
    private TextView tv_app_version;
    //    private EditText editView;
//    private int iCount = 0;
    private boolean clicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        setPageName("AboutUsActivity");

        initToolbar();
        initViews();
    }

    /**
     * APP版本升级检测
     */
    private void sendUpgradeRequest() {
        int requestId = UserDataManager.getInstance().checkAppVersion();
        registerDataReqStatusListener(requestId);
        showAppMessage(R.string.activity_about_us_check_version, AppMsg.STYLE_INFO);
    }

    /**
     * 刷新版本号
     */
    private void refreshVersion() {
        String versionName = ApiUtils.getApkVersionName();// + "_内网_2017110801";
        String sText = String.format("%s V%s", getResources()
                .getString(R.string.activity_about_us_app_version), versionName);
        tv_app_version.setText(sText);
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        tv_app_version = (TextView) findViewById(R.id.tv_app_version);
        refreshVersion();
        setUpdateClick();
    }

    /**
     * 设置已经展示了升级 如果有红点就不显示
     */
    private void setUpdateClick() {
        int newVersion = SettingsHelper.getInt(Config.SETTING_NEW_VERSION, -1);
        int appVersion = ApiUtils.getApkVersionCode();
        if (appVersion < newVersion) {
            SettingsHelper.putBoolean(Config.SETTING_VERSION_UPDATE, true);
            SettingsHelper.putInt(Config.SETTING_IGNORE_VERSION, newVersion);
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
        if (dataReqResult == null)
            return;

        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 6://检测服务器上App最新版本信息
                CheckAppVersion checkAppVersion = JsonHelper.getObject(result, CheckAppVersion.class);
                if (checkAppVersion != null) {
                    int androidVersion = checkAppVersion.getAndroidVersion();
                    int appVersion = ApiUtils.getApkVersionCode();

                    SettingsHelper.putInt(Config.SETTING_NEW_VERSION, androidVersion);
                    int ignoreVersion = SettingsHelper.getInt(Config.SETTING_IGNORE_VERSION, -1);
                    if (ignoreVersion < androidVersion) {//如果最新的版本比忽略的版本高 则把已经点击过的升级操作置为false
                        SettingsHelper.putBoolean(Config.SETTING_VERSION_UPDATE, false);
                    }

                    if (appVersion < androidVersion) {//提示升级
                        String downloadUrl = checkAppVersion.getAndroidUpgradeUrl();
                        String content = checkAppVersion.getAndroidVersionIntroduction();
                        if (!TextUtils.isEmpty(downloadUrl) && !TextUtils.isEmpty(content)) {
                            detectNewAppAvailable(downloadUrl, content);
                        }
                    } else {//提示已经是最新版本
                        new MaterialDialog.Builder(this)
                                .title(R.string.activity_about_us_information)
                                .content(R.string.activity_about_us_last_version)
                                .positiveText(R.string.ok)
                                .onAny(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.dismiss();
                                    }
                                }).show();
                    }
                }
                break;
        }
    }

    /**
     * 新版本提示
     */
    private void detectNewAppAvailable(String downloadUrl, String content) {
        AppUpgradeManager manager = new AppUpgradeManager(this, downloadUrl, content);
        manager.newVersionPrompt(false);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.tv_app_version:
                int uid = UserDataManager.getUid();
                if (uid == 1340266 || uid == 27) {
                    if (!clicked) {
                        backupDatabase();
                        clicked = true;
                    }
                }
//                startTestActivity();
                break;

            //case R.id.btn_join_qq_group://加入QQ群
            //startAuthShare(AuthShareHelper.REQUESTCODE_QQ_JOIN_GROUP);
            //   break;

            case R.id.btn_join_qq_group://加入QQ
                startAuthShare(AuthShareHelper.REQUESTCODE_QQ_JOIN_GROUP);
                break;

            case R.id.btn_follow_sina_weibo:// 关注乐享动微博
//                startAuthShare(AuthShareHelper.REQUESTCODE_FOLLOW_WEIBO);
                break;

            case R.id.btn_follow_wechat_office:// 关注乐享动微信公众号
                startAuthShare(AuthShareHelper.REQUESTCODE_FOLLOW_WECHAT);
                break;

            case R.id.tv_privacy://隐私协议
                startPrivacy();
                break;
            case R.id.upgrade:  //升级
                sendUpgradeRequest();
                break;

        }
    }

    /**
     * 进入交流平台
     *
     * @param requestCode 请求码
     */
    private void startAuthShare(int requestCode) {
        Intent intent = new Intent();
        intent.setClass(AboutUsActivity.this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, requestCode);
        startActivityForResult(intent, requestCode);
    }

    /**
     * 启动隐私
     */
    private void startPrivacy() {
        Intent intent = new Intent();
        intent.setClass(AboutUsActivity.this, WebViewActivity.class);
        intent.putExtra("url", ApiConstants.appPrivacyPolicy());
        intent.putExtra("title", getResources().getString(R.string.activity_about_us_privacy));
        startActivity(intent);

//        Intent intent = new Intent(this, TestActivity.class);
//        startActivity(intent);

//        jumpStartInterface(this);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//DOZE
//            Intent intent = new Intent();
//            String packageName = getPackageName();
//            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
//
//            if (pm.isIgnoringBatteryOptimizations(packageName))
//                intent.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
//            else {
//                intent.setAction(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
//                intent.setData(Uri.parse("package:" + packageName));
//            }
//            startActivity(intent);
//        }

    }

    /**
     * 导出数据库到临时文件夹
     */
    public void backupDatabase() {
        try {
            //Open your local db as the input stream
            String inFileName = "/data/data/com.fitmix.sdk/databases/realm.db";
            File dbFile = new File(inFileName);
            FileInputStream fis = new FileInputStream(dbFile);

            String outFileName = Config.PATH_LOCAL_TEMP + "realm.db";
            //Open the empty db as the output stream
            OutputStream output = new FileOutputStream(outFileName);
            //transfer bytes from the inputfile to the outputfile
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
            //Close the streams
            output.flush();
            output.close();
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        showAppMessage("备份数据库成功", AppMsg.STYLE_INFO);
    }


    private String getMobileType() {
        return Build.MANUFACTURER;
    }

    /**
     * 跳转到自启动管理界面
     *
     * @param context
     */
    public void jumpStartInterface(Context context) {
        Intent intent = new Intent();
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ComponentName componentName = null;
            switch (getMobileType()) {
                case "Xiaomi":  // 红米Note4测试通过
                    componentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity");
                    break;
                case "Letv":  // 乐视2测试通过
                    intent.setAction("com.letv.android.permissionautoboot");
                    break;
                case "samsung":  // 三星Note5测试通过
                    componentName = new ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.ui.ram.AutoRunActivity");
                    break;
                case "HUAWEI":  // 华为测试通过
                    componentName = new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity");
                    break;
                case "vivo":  // VIVO测试通过
                    componentName = ComponentName.unflattenFromString("com.iqoo.secure/.safeguard.PurviewTabActivity");
                    break;
                case "Meizu":  //万恶的魅族
                    // 通过测试，发现魅族是真恶心，也是够了，之前版本还能查看到关于设置自启动这一界面，系统更新之后，完全找不到了，心里默默Fuck！
                    // 针对魅族，我们只能通过魅族内置手机管家去设置自启动，所以我在这里直接跳转到魅族内置手机管家界面，具体结果请看图
                    componentName = ComponentName.unflattenFromString("com.meizu.safe/.permission.PermissionMainActivity");
                    break;
                case "OPPO":  // OPPO R8205测试通过
                    componentName = ComponentName.unflattenFromString("com.oppo.safe/.permission.startup.StartupAppListActivity");
                    break;
                case "ulong":  // 360手机 未测试
                    componentName = new ComponentName("com.yulong.android.coolsafe", ".ui.activity.autorun.AutoRunListActivity");
                    break;
                default:
                    // 以上只是市面上主流机型，由于公司你懂的，所以很不容易才凑齐以上设备
                    // 针对于其他设备，我们只能调整当前系统app查看详情界面
                    // 在此根据用户手机当前版本跳转系统设置界面
//                if (Build.VERSION.SDK_INT >= 9) {
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", context.getPackageName(), null));
//                } else if (Build.VERSION.SDK_INT <= 8) {
//                    intent.setAction(Intent.ACTION_VIEW);
//                    intent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
//                    intent.putExtra("com.android.settings.ApplicationPkgName", context.getPackageName());
//                }
                    break;
            }
            intent.setComponent(componentName);
            context.startActivity(intent);
        } catch (Exception e) {//抛出异常就直接打开设置页面
            intent = new Intent(Settings.ACTION_SETTINGS);
            context.startActivity(intent);
        }
    }


    /**
     * 跳转到miui的权限管理页面
     */
    private void gotoMiuiPermission() {
        Intent i = new Intent("miui.intent.action.APP_PERM_EDITOR");
        ComponentName componentName = new ComponentName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity");
        i.setComponent(componentName);
        i.putExtra("extra_pkgname", getPackageName());
        try {
            startActivity(i);
        } catch (Exception e) {
            e.printStackTrace();
            gotoMeizuPermission();
        }
    }

    /**
     * 跳转到魅族的权限管理系统
     */
    private void gotoMeizuPermission() {
        Intent intent = new Intent("com.meizu.safe.security.SHOW_APPSEC");
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.putExtra("packageName", BuildConfig.APPLICATION_ID);
        try {
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            gotoHuaweiPermission();
        }
    }

    /**
     * 华为的权限管理页面
     */
    private void gotoHuaweiPermission() {
        try {
            Intent intent = new Intent();
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ComponentName comp = new ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity");//华为权限管理
            intent.setComponent(comp);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            startActivity(getAppDetailSettingIntent());
        }

    }

    /**
     * 获取应用详情页面intent
     *
     * @return
     */
    private Intent getAppDetailSettingIntent() {
        Intent localIntent = new Intent();
        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        if (Build.VERSION.SDK_INT >= 9) {
        localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        localIntent.setData(Uri.fromParts("package", getPackageName(), null));
//        } else if (Build.VERSION.SDK_INT <= 8) {
//            localIntent.setAction(Intent.ACTION_VIEW);
//            localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
//            localIntent.putExtra("com.android.settings.ApplicationPkgName", getPackageName());
//        }
        return localIntent;
    }


//    /**
//     * 打开测试界面
//     */
//    private void startTestActivity() {
//        Intent intent = new Intent(this, TestActivity.class);
//        startActivity(intent);
//    }

}
