package com.fitmix.sdk.view.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.widget.TextView;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;


public class CheckSensorActivity extends BaseActivity {
    private int iSensorDataCount;
    private boolean bScreenOff;
    private boolean bEnableShow;
    private long lScreenOffTime;

    private TextView tv_contain_step_sensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_sensor);
        setPageName("CheckSensorActivity");

        initToolbar();
        initViews();
        iSensorDataCount = 0;
        bScreenOff = false;
        bEnableShow = false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerSensorListener();
        registerMyReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bEnableShow) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content((iSensorDataCount >= 40) ? R.string.fm_mine_more_checksensor_ok : R.string.fm_mine_more_checksensor_cancel)
                    .positiveText(R.string.ok)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            finish();
                        }
                    }).show();
        }
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        tv_contain_step_sensor = (TextView) findViewById(R.id.tv_contain_step_sensor);
        tv_contain_step_sensor.setText(String.format(getString(R.string.fm_mine_more_checksensor_step_format), getString(R.string.no)));
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    @Override
    protected void onDestroy() {
        unregisterSensorListener();
        unregisterReceiver(mReceiver);
        super.onDestroy();
    }

    private void registerMyReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(mReceiver, intentFilter);
    }

    private void registerSensorListener() {
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null)
            return;
        Sensor sensor = sensorManager
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (sensor == null)
            return;
        sensorManager.registerListener(mSensorListener, sensor,
                SensorManager.SENSOR_DELAY_GAME);

        // 1.如果手机支持android自带的计步传感器,优先用计步感应传感器
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                boolean hasDetectSensor = getPackageManager().hasSystemFeature("android.hardware.sensor.stepdetector");
                boolean hasStepSensor = getPackageManager().hasSystemFeature("android.hardware.sensor.stepcounter");
                Sensor stepDetectSensor = sensorManager
                        .getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
                Sensor androidStepSensor = sensorManager
                        .getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
                if ((hasDetectSensor && stepDetectSensor != null)
                        || (hasStepSensor && androidStepSensor != null)) {
                    if (tv_contain_step_sensor != null) {//手机自带计步传感器
                        tv_contain_step_sensor.setText(String.format(getString(R.string.fm_mine_more_checksensor_step_format), getString(R.string.yes)));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    private void unregisterSensorListener() {
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null)
            return;
        sensorManager.unregisterListener(mSensorListener);
    }

    /**
     * 传感器监听事件
     */
    private final SensorEventListener mSensorListener = new SensorEventListener() {

        @Override
        public void onAccuracyChanged(Sensor arg0, int arg1) {

        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            if (bScreenOff) iSensorDataCount++;
            Logger.i(Logger.DEBUG_TAG, "iSensorDataCount : " + iSensorDataCount);
        }
    };

    /**
     * 熄屏,亮屏广播
     */
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                bScreenOff = true;
                lScreenOffTime = System.currentTimeMillis();
                bEnableShow = false;
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                bScreenOff = false;
                if (iSensorDataCount >= 40) bEnableShow = true;
                else bEnableShow = (System.currentTimeMillis() - lScreenOffTime) > 2000;
            }
        }
    };
}
