package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.model.api.bean.KeyWord;
import com.fitmix.sdk.model.api.bean.SearchMusicList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MusicInfo;
import com.fitmix.sdk.model.database.MusicInfoHelper;
import com.fitmix.sdk.model.database.SearchHistory;
import com.fitmix.sdk.model.database.SearchHistoryHelper;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.SearchedHistoryListAdapter;
import com.fitmix.sdk.view.adapter.SongsAdapter;
import com.fitmix.sdk.view.dialog.MoreActionDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.ClearEditText;
import com.fitmix.sdk.view.widget.MultipleTextViewGroup;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SearchMusicActivity extends BaseActivity {

    //private final int REQUEST_TYPE_MUSIC_FAVORITE_SWITCH = 0;
    //private final int REQUEST_SEARCH_MUSIC_LIST = 1;
    //private final int REQUEST_KEY_WORD_LIST = 11;
    public static final int LIST_TYPE_SEARCH = 4;
    private ClearEditText searchView;
    private ListView list_search;//搜索出的歌曲列表
    private SwipeLoadLayout swipeLayout;//包裹歌曲列表的pullToRefresh
    private TextView mTvCancel;
    private SongsAdapter adapter;
    private int index;
    private String sSearch;
    private Music tempMusic;//用来处理收藏等操作的中间变量
    private Music tempMusic_share;//用于分享操作的中间变量

    private MultipleTextViewGroup multiple_search_view_group;
    private List<String> key_word_multiple_List;//热词列表
    private ListView search_searched_lv;
    private SearchedHistoryListAdapter history_searched_adapter;
    private LinearLayout ll_keyword_and_searched;
    private TextView emptyView;
    //private static final int SEARCH_TYPE_KEYWORD = 1;
    //private static final int SEARCH_TYPE_TEXT = 2;

    private KeyWord keyWordList;

    Drawable drawable_search_delete;
    private TextView tv_hot_search;
    private View view_clear_all_history;//搜索记录底部view
    /**
     * @return 获取专辑信息
     */
//    public Album getAlbum() {
//        return getMyConfig().getMemExchange().getCurrentAlbum();
//    }

    /**
     * @return 获取歌曲列表
     */
//    private List<Music> getMusicList() {
//        return getMyConfig().getMemExchange().getListMusicSelect();
//    }

    /**
     * @return 获取适配器
     */

    private SongsAdapter getSongsAdapter() {
        if (adapter == null) adapter = new SongsAdapter(this);
        return adapter;
    }

    /**
     * 发送网络请求更新列表
     */
    private void sendListRequest() {
        if (UserDataManager.getUid() != -1) {
            int requestId = MusicDataManager.getInstance().searchMusic(index, sSearch, true);
            registerDataReqStatusListener(requestId);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_music);
        setPageName("SearchMusicActivity");
        initToolbar();
        initViews();
    }

    private void addSearchHistory() {
        int uid = UserDataManager.getUid();
        Date date = new Date();
        SearchHistoryHelper.getInstance().insertRecentMusic(uid, sSearch, date.getTime());
    }

    /**
     * 将历史记录中多余的记录清空,只保留最后的十条记录
     */
    private void deleteUseLessSearchHistory() {
        List<SearchHistory> history_list = SearchHistoryHelper.getInstance().getHistoryListAsc();
        int length = history_list.size();
        if (length > 10) {
            for (int i = 0; i < length - 10; i++) {
                SearchHistoryHelper.getInstance().deleteHistory(history_list.get(0));
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
//        getWeakHandler().sendEmptyMessageDelayed(
//                FitmixConstant.MSG_PROGRESS_UPDATE, 1000);
    }

    @Override
    public void onPause() {
        super.onPause();
//        getWeakHandler().removeMessages(FitmixConstant.MSG_PROGRESS_UPDATE);
    }

    /**
     * 移除搜索历史记录的item
     */
    public void removeHistory(SearchHistory history) {
        SearchHistoryHelper.getInstance().deleteHistory(history);
        getHistory_searched_adapter().setKeyWordList(SearchHistoryHelper.getInstance().getHistoryList());
        if (SearchHistoryHelper.getInstance().getHistoryListAsc().size() <= 0) {
            view_clear_all_history.setVisibility(View.GONE);
        }
    }

    /**
     * 热词列表,并从中筛选属于热门搜索的字符串
     */
    private void getKey_word_multiple_List(KeyWord list) {
        if (list == null || list.getResult() == null) return;
        int size = list.getResult().size();
        for (int i = 0; i < size; i++) {
            if (list.getResult().get(i).getType() != 2) continue;
            key_word_multiple_List.add(list.getResult().get(i).getName());
        }
    }

    /**
     * 搜索EditTexT默认字显示
     */
    private String getKey_word_search_edit(KeyWord list) {
        List<KeyWord.TheKeyWord> kk_list = list.getResult();
        StringBuilder keyWordSearchEditText = new StringBuilder();//搜索editText显示的内容
        for (int i = 0; i < kk_list.size(); i++) {
            if (kk_list.get(i).getType() != 1) continue;
            keyWordSearchEditText.append(kk_list.get(i).getName()).append("、");
        }
        if (keyWordSearchEditText.length() > 0) {
            keyWordSearchEditText = new StringBuilder(keyWordSearchEditText.substring(0, keyWordSearchEditText.length() - 1));
        }
        return keyWordSearchEditText.toString();
    }

    @Override
    protected void initViews() {
        tv_hot_search = (TextView) findViewById(R.id.tv_hot_search);
        drawable_search_delete = getResources().getDrawable(R.drawable.searched_history_delete);


        ll_keyword_and_searched = (LinearLayout) findViewById(R.id.ll_keyword_and_searched);
        key_word_multiple_List = new ArrayList<>();
        showGoToPlayMusicMenu = false;
        searchView = (ClearEditText) findViewById(R.id.searchView);
        searchView.setClearButtonClickListener(new ClearEditText.OnClearButtonClickListener() {
            @Override
            public void onClearButtonClick() {
                restoreInterface();
            }
        });
        mTvCancel = (TextView) findViewById(R.id.cancel);

        searchView.setOnEditorActionListener(new TextView.OnEditorActionListener() {//软键盘的搜索键
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                doSearch();
                return false;
            }
        });
        searchView.addTextChangedListener(new TextWatcher() {//输入框内容监听
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s)) {
                    mTvCancel.setText(getString(R.string.cancel));//无内容为取消
//                    searchView.setCompoundDrawables(searchView.getCompoundDrawables()[0], null, null, null);
                    searchView.setClearIconVisible(false);
                } else {
                    mTvCancel.setText(getString(R.string.activity_main_search));//有内容为搜索
//                    searchView.setCompoundDrawables(searchView.getCompoundDrawables()[0], null, drawable_search_delete, null);
                    searchView.setClearIconVisible(true);
                }
            }
        });
        mTvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(searchView.getText())) {//输入框无内容时取消返回上一个界面
                    finish();
                } else {
                    doSearch();//有内容发送搜索请求
                }

            }
        });
        list_search = (ListView) findViewById(R.id.swipe_target);

        swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
        swipeLayout.setVisibility(View.GONE);

        list_search.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        swipeLayout.setOnLoadMoreListener(new SwipeLoadLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                sendListRequest();
            }
        });


        index = 0;
        list_search.setAdapter(getSongsAdapter());
        getSongsAdapter().setOnSonsActionClickListener(new SongsAdapter.SongsActionClickListener() {
            @Override
            public void onSongPlayActionClick(int position, int musicID) {
                gotoPlayingScreen(position);
            }

            @Override
            public void onSongMoreActionClick(int musicID) {
                showMoreActionDialog(getMusic(musicID));
            }
        });
        list_search.setOnItemClickListener(null);

        //展示热词的viewGroup
        getKey_word_multiple_List(keyWordList);
        multiple_search_view_group = (MultipleTextViewGroup) findViewById(R.id.multiple_search_key_word);
        multiple_search_view_group.setOnMultipleTVItemClickListener(new MultipleTextViewGroup.OnMultipleTVItemClickListener() {
            @Override
            public void onMultipleTVItemClick(View view, int position) {
                if (keyWordList == null || keyWordList.getResult() == null) return;
                clickKeyWord(key_word_multiple_List.get(position));
            }
        });
        multiple_search_view_group.setTextViews(key_word_multiple_List);
        KeyWordRequest();

        //搜索过的列表
        deleteUseLessSearchHistory();
        search_searched_lv = (ListView) findViewById(R.id.search_searched_lv);
        //清除全部搜索记录
        view_clear_all_history = View.inflate(getApplicationContext(), R.layout.activity_clear_search_history, null);

        view_clear_all_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MaterialDialog.Builder(SearchMusicActivity.this)
                        .title(R.string.prompt)
                        .content(R.string.clear_all_search_history)
                        .positiveText(android.R.string.ok)
                        .cancelable(true)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                SearchHistoryHelper.getInstance().deleteAllHistory();
                                getHistory_searched_adapter().setKeyWordList(SearchHistoryHelper.getInstance().getHistoryList());
                                view_clear_all_history.setVisibility(View.GONE);
                            }
                        }).show();
            }
        });
        if (SearchHistoryHelper.getInstance().getHistoryList().size() > 0) {
            view_clear_all_history.setVisibility(View.VISIBLE);
        } else {
            view_clear_all_history.setVisibility(View.GONE);
        }
        search_searched_lv.addFooterView(view_clear_all_history);

        history_searched_adapter = new SearchedHistoryListAdapter(SearchMusicActivity.this, SearchHistoryHelper.getInstance().getHistoryList());
        search_searched_lv.setAdapter(getHistory_searched_adapter());


        emptyView = (TextView) findViewById(R.id.tv_empty_view);
        emptyView.setText(getString(R.string.activity_search_music_list_empty_hint));//未搜索到数据时显示

    }

    /**
     * 清空当前搜索框后执行回到第一个展示界面
     */
    public void restoreInterface() {
        deleteUseLessSearchHistory();
        getHistory_searched_adapter().setKeyWordList(SearchHistoryHelper.getInstance().getHistoryList());
        emptyView.setVisibility(View.GONE);
        swipeLayout.setVisibility(View.GONE);//搜索结果布局消失
        ll_keyword_and_searched.setVisibility(View.VISIBLE);//热词和历史记录布局显示出现
        if (SearchHistoryHelper.getInstance().getHistoryList().size() > 0) {
            view_clear_all_history.setVisibility(View.VISIBLE);
        } else {
            view_clear_all_history.setVisibility(View.GONE);
        }
    }

    /**
     * @return 总列表 包括推荐音乐列表 和 正常音乐列表
     */
    private List<Music> getPlayList() {
        List<Music> list = new ArrayList<>();
        list.addAll(getMusicList());
        return list;
    }

    private Music getMusic(int musicID) {
        return MusicInfoHelper.getInstance().getMusicByID(musicID);
    }

    private void gotoPlayingScreen(int index) {
        getMyConfig().getPlayer().setPlayList(getPlayList());
        Intent intent = new Intent(this, PlayMusicActivity.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }

    /**
     * 显示更多操作栏
     *
     * @param music 要进行操作的音乐
     *              listType 列表类型 用来控制 操作的不同方式 ,默认为搜索类型
     */
    public void showMoreActionDialog(final Music music) {
        if (music == null) {
            return;
        }
        MoreActionDialog moreActionDialog = new MoreActionDialog();
        moreActionDialog.setListType(Config.LIST_TYPE_SEARCH);
        moreActionDialog.setMusic(music);
        moreActionDialog.setOnActionClickListener(new MoreActionDialog.ActionTypeClickListener() {
            @Override
            public void onActionClick(int type) {//根据选择的按钮不同 选择不同的回调方法
                doMoreAction(music, type, LIST_TYPE_SEARCH);
            }
        });
        moreActionDialog.show(this.getSupportFragmentManager(), "moreActionDialog");
    }

    private void deleteDownloadedMusic(final Music music) {
        if (music == null) return;
        new MaterialDialog.Builder(this)
                .title(R.string.delete)
                .content(R.string.delete_tip)
                .positiveText(R.string.delete)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://删除已下载的音乐
//                                OperateMusicUtils.deleteDownLoadMusic(music, new AsyncOperationListener() {
//                                    @Override
//                                    public void onAsyncOperationCompleted(AsyncOperation operation) {
                                if (OperateMusicUtils.deleteMusicDownloadedFile(music)) {
                                    //TODO 删除完成之后怎么做
                                    getSongsAdapter().notifyDataSetChanged();
                                }
//                                    }
//                                });
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 做更多操作
     *
     * @param music    要进行操作的音乐
     * @param type     操作的类型
     * @param listType 列表的类型
     */
    private void doMoreAction(final Music music, int type, int listType) {
        switch (type) {
            case MoreActionDialog.ACTION_TYPE_MUSIC_FAVORITE://收藏
                favoriteSwitchMusic(music);
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_DOWNLOAD://下载
                if (OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_DOWNLOADED)) {
                    deleteDownloadedMusic(music);
                } else {
                    OperateMusicUtils.downloadMusic(music);
                    showAppMessage(R.string.added_downloading, AppMsg.STYLE_INFO);
                    if (music != null) {
                        UmengAnalysisHelper.getInstance().musicReportPlus(SearchMusicActivity.this, "音乐下载", music.getId());
                    }
                }
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_SHARE://分享
                tempMusic_share = music;
                ShareUtils.getInstance().shareMusic(this, music);
        }
    }

    /**
     * @return 获取歌曲列表
     */
    private List<Music> getMusicList() {
        return getMyConfig().getMemExchange().getListMusicSelect();
    }


//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_MUSIC + 8://获取热词
                keyWordList = JsonHelper.getObject(result, KeyWord.class);
                if (keyWordList == null || keyWordList.getResult().size() <= 0) {
                    tv_hot_search.setVisibility(View.GONE);
                    return;
                }
                if (getKey_word_search_edit(keyWordList).length() > 0) {
                    searchView.setHint(getResources().getString(R.string.activity_search_edit_pre) + getKey_word_search_edit(keyWordList));
                }
                getKey_word_multiple_List(keyWordList);
                if (key_word_multiple_List.size() == 0) {
                    tv_hot_search.setVisibility(View.GONE);
                } else {
                    tv_hot_search.setVisibility(View.VISIBLE);
                }
                multiple_search_view_group.setTextViews(key_word_multiple_List);
                break;
            case Config.MODULE_MUSIC + 9://搜索歌曲返回的结果
                swipeLayout.setLoadingMore(false);//加载更多布局消失
                //存储搜索历史记录
                addSearchHistory();
                SearchMusicList searchMusicList = JsonHelper.getObject(result, SearchMusicList.class);
                if (searchMusicList != null) {
                    List<Music> list = searchMusicList.getMix();//搜索的结果有无
                    if (index == 0) {//第一页
//                    getSongsAdapter().setMusicList(list);
                        getMyConfig().getMemExchange().setListMusicSelect(list);

                    } else {//加载更多时
                        getMusicList().addAll(list);
//                    getSongsAdapter().getMusicList().addAll(list);
//                    getSongsAdapter().notifyDataSetChanged();
                    }

                    getSongsAdapter().setMusicList(getMusicList());
                    swipeLayout.setVisibility(View.VISIBLE);//搜索结果布局显示出现
                    ll_keyword_and_searched.setVisibility(View.GONE);//热词和历史记录布局显示消失
                    list_search.setEmptyView(emptyView);//不设在initView上的原因因为初始化就显示出来了emptyView

                    if (searchMusicList.getMix() == null || searchMusicList.getMix().size() <= 0)
                        return;
                    MusicInfoHelper.getInstance().asyncWriteMusicInfoList(list);//数据库增加歌曲
//                getSongsAdapter().setMusicList(getMusicList());
                    index++;
                }
                break;
            case Config.MODULE_MUSIC + 4:
                favoriteSwitchInLocale(tempMusic);
                break;
        }
    }

    public SearchedHistoryListAdapter getHistory_searched_adapter() {
        return history_searched_adapter;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            default:
                if (resultCode == Activity.RESULT_OK) {//三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                                if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                    updateShareCount();
                                }
                            }
                            break;
                    }
                }
                break;
        }
    }

    /**
     * 分享的次数增加
     */
    private void updateShareCount() {
        if (tempMusic_share == null) return;
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(tempMusic_share.getId());
        if (musicInfo != null) {
            musicInfo.setShareCount(musicInfo.getShareCount() + 1);
            MusicInfoHelper.getInstance().asyncWriteMusicInfo(musicInfo);
        }
        tempMusic_share.setShareCount(tempMusic_share.getShareCount() + 1);
        if (getMusicList() == null || getMusicList().size() == 0) return;
        for (int i = 0; i < getMusicList().size(); i++) {
            if (getMusicList().get(i).getId() == tempMusic_share.getId()) {
                getMusicList().get(i).setShareCount(tempMusic_share.getShareCount());
            }
        }
        getSongsAdapter().notifyDataSetChanged();
        tempMusic_share = null;
    }

    private void doSearch() {
        //隐藏键盘
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchView.getWindowToken(), 0);
        index = 0;
        sSearch = searchView.getText().toString();
        searchView.setSelection(searchView.getText().length());
        sendListRequest();
        //友盟u-d plus统计
        UmengAnalysisHelper.getInstance().searchReport(this, sSearch);
    }

    /**
     * 点击热词或者历史记录进行网络访问
     *
     * @param keyword
     */
    public void clickKeyWord(String keyword) {
        //隐藏键盘
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchView.getWindowToken(), 0);
        index = 0;
        sSearch = keyword;
        searchView.setText(sSearch != null ? sSearch : "");
        searchView.setSelection(searchView.getText().length());
        sendListRequest();
    }

    /**
     * 调用接口获取热词等等数据
     */
    private void KeyWordRequest() {
        if (UserDataManager.getUid() != -1) {
            int requestId = MusicDataManager.getInstance().getKeyWordList(UserDataManager.getUid(), true);
            registerDataReqStatusListener(requestId);
        }
    }


//    private boolean checkMusicExist(Music music) {
//        if (music == null) return false;
//        return FitmixUtil.isExistCacheFile(music.getUrl(), music.getId(),
//                Config.DOWNLOAD_FORMAT_MUSIC);
//    }


    private void favoriteSwitchMusic(Music music) {
        if (music == null) return;
        favoriteSwitchInNet(music);
    }

    private void favoriteSwitchInNet(Music music) {
        if (music == null) return;
        tempMusic = music;
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);

        int requestId = MusicDataManager.getInstance().favoriteMusicChange(UserDataManager.getUid(), music.getId(), false);
        registerDataReqStatusListener(requestId);

        showAppMessage(
                bFavorite ? R.string.activity_main_unfavoriting : R.string.activity_main_favoriting, AppMsg.STYLE_INFO);
        if (!bFavorite) {
            UmengAnalysisHelper.getInstance().musicReportPlus(this, "音乐收藏", music.getId());
        }
    }

    private void favoriteSwitchInLocale(Music music) {
        if (music == null) return;
        OperateMusicUtils.favoriteSwitchInLocale(music);
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);
        for (int i = 0; i < getMusicList().size(); i++) {
            if (getMusicList().get(i).getId() == music.getId()) {
                getMusicList().get(i).setCollectNumber(bFavorite ? music.getCollectNumber() + 1 : music.getCollectNumber() - 1);
            }
        }
        getSongsAdapter().notifyDataSetChanged();
        showAppMessage(
                bFavorite ? R.string.activity_main_album_add_favorite_tip : R.string.activity_main_album_remove_favorite_tip, AppMsg.STYLE_INFO);
    }
}
