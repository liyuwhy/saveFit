package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

public class AccountSetActivity extends BaseActivity {
    /**
     * 请求绑定返回码
     */
    public static final int REQUEST_BIND_RESULT_CODE = 200;

    private static final int CHANGE_PASSWORD = 459;

    private TextView mTvAccountID;
    private TextView mTvPhoneBind;
    private TextView mTvEmailBind;
    private TextView mTvWeixinBind;
    private TextView mTvQQBind;
    private TextView mTvSinaBind;

    private LinearLayout mPhoneBindContainer;
    private LinearLayout mEmailBindContainer;
    private LinearLayout mWeixinBindContainer;
    private LinearLayout mQQBindContainer;
    private LinearLayout mWeiboBindContainer;


    private TextView mBtnPhoneBind;
    private TextView mBtnEmailBind;
    private TextView mBtnWeixinBind;
    private TextView mBtnQQBind;
    private TextView mBtnWeiboBind;

    private Button btn_change_password;
    private View view_divider_1;
    private View view_divider_2;

    private String name;//应用的用户name
    private String bindEmail;
    private String mobile;
    private String QQName;
    private String WBName;
    private String WXName;
//    private String accountName;

    private String WBOpenid;
    private String WXOpenid;
    private String QQOpenid;

    private int bindType;
    private String bindName;
    private String bindOpenid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_setting);
        setPageName("AccountSetActivity");
        initToolbar();
        initViews();
        getBindData();
        refresh();
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        mTvAccountID = (TextView) findViewById(R.id.tv_account_id);

        mTvPhoneBind = (TextView) findViewById(R.id.tv_bind_phone);
        mTvEmailBind = (TextView) findViewById(R.id.tv_bind_email);
        mTvWeixinBind = (TextView) findViewById(R.id.tv_bind_weixin);
        mTvQQBind = (TextView) findViewById(R.id.tv_bind_qq);
        mTvSinaBind = (TextView) findViewById(R.id.tv_bind_sina);

        mBtnPhoneBind = (TextView) findViewById(R.id.btn_bind_phone);
        mBtnEmailBind = (TextView) findViewById(R.id.btn_bind_email);
        mBtnWeixinBind = (TextView) findViewById(R.id.btn_bind_weixin);
        mBtnQQBind = (TextView) findViewById(R.id.btn_bind_qq);
        mBtnWeiboBind = (TextView) findViewById(R.id.btn_bind_sina);

        mPhoneBindContainer = (LinearLayout) findViewById(R.id.bind_phone_container);
        mEmailBindContainer = (LinearLayout) findViewById(R.id.bind_email_container);
        mWeixinBindContainer = (LinearLayout) findViewById(R.id.bind_wx_container);
        mQQBindContainer = (LinearLayout) findViewById(R.id.bind_qq_container);
        mWeiboBindContainer = (LinearLayout) findViewById(R.id.bind_wb_container);

        btn_change_password = (Button) findViewById(R.id.btn_change_password);
        view_divider_1 = findViewById(R.id.view_divider_1);
        view_divider_2 = findViewById(R.id.view_divider_2);
    }

    @Override
    protected void onResume() {
        checkToShowBindPhoneMessage();
        super.onResume();
    }

    /**
     * 手机绑定按钮显不显示红点
     */
    private void checkToShowBindPhoneMessage() {
        ImageView btn_phone_bind_message = (ImageView) findViewById(R.id.btn_phone_bind_message);
        boolean bindMobile = SettingsHelper.getBoolean(Config.SETTING_BIND_MOBILE, false);//账户设置有没有红点
        String mobile = SettingsHelper.getString(Config.SETTING_USER_MOBILE, "");
        if (!bindMobile && TextUtils.isEmpty(mobile)) {
            btn_phone_bind_message.setVisibility(View.VISIBLE);
        } else {
            btn_phone_bind_message.setVisibility(View.GONE);
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusRESULT_OK-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        switch (requestId) {
            case Config.MODULE_USER + 30://邮箱解绑操作成功
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表清空邮箱
                SettingsHelper.putString(Config.SETTING_USER_EMAIL, null);
                bindEmail = "";//SettingsHelper.getString(Config.SETTING_USER_EMAIL, "");
                switchLoginInfo();
                refresh();
                PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);//设置登录无效
                break;

            case Config.MODULE_USER + 31://QQ解绑操作成功
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表清空邮箱
                SettingsHelper.putString(Config.SETTING_USER_QQ_OPENID, null);
                QQOpenid = "";//SettingsHelper.getString(Config.SETTING_USER_QQ_OPENID, "");
                refresh();
                PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);//设置登录无效
                break;

            case Config.MODULE_USER + 34://微信解绑操作成功
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表清空邮箱
                SettingsHelper.putString(Config.SETTING_USER_WX_OPENID, null);
                WXOpenid = "";//SettingsHelper.getString(Config.SETTING_USER_WX_OPENID, "");
                refresh();
                PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);//设置登录无效
                break;

            case Config.MODULE_USER + 33://新浪微博解绑操作成功
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表清空邮箱
                SettingsHelper.putString(Config.SETTING_USER_WB_OPENID, null);
                WBOpenid = "";//SettingsHelper.getString(Config.SETTING_USER_WB_OPENID, "");
                refresh();
                PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);//设置登录无效
                break;

            case Config.MODULE_USER + 32://手机解绑操作成功
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表清空邮箱
                SettingsHelper.putString(Config.SETTING_USER_MOBILE, null);
                mobile = "";//SettingsHelper.getString(Config.SETTING_USER_MOBILE, "");
                switchLoginInfo();
                refresh();
                PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);//设置登录无效
                break;

            case Config.MODULE_USER + 39://QQ绑定操作成功
                QQName = bindName;
                QQOpenid = bindOpenid;
                refresh();
                break;
            case Config.MODULE_USER + 41://微信绑定操作成功
                WXName = bindName;
                WXOpenid = bindOpenid;
                refresh();
                break;
            case Config.MODULE_USER + 40://微博绑定操作成功
                WBName = bindName;
                WBOpenid = bindOpenid;
                refresh();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 30://邮箱解绑操作成功
            case Config.MODULE_USER + 31://QQ解绑操作成功
            case Config.MODULE_USER + 34://微信解绑操作成功
            case Config.MODULE_USER + 33://新浪微博解绑操作成功
            case Config.MODULE_USER + 32://手机解绑操作成功
            case Config.MODULE_USER + 39://QQ绑定操作成功
            case Config.MODULE_USER + 41://微信绑定操作成功
            case Config.MODULE_USER + 40://微博绑定操作成功
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }

    private void getBindData() {
//        accountName = getMyConfig().getSystemConfig().getLastUsername();
        mTvAccountID.setText(String.format(getString(R.string.string_format), String.valueOf(UserDataManager.getUid())));
        name = SettingsHelper.getString(Config.SETTING_USER_NAME, "");
        bindEmail = SettingsHelper.getString(Config.SETTING_USER_EMAIL, "");
        mobile = SettingsHelper.getString(Config.SETTING_USER_MOBILE, "");
        QQName = SettingsHelper.getString(Config.SETTING_USER_QQ_NAME, "");
        WBName = SettingsHelper.getString(Config.SETTING_USER_WB_NAME, "");
        WXName = SettingsHelper.getString(Config.SETTING_USER_WX_NAME, "");
        QQOpenid = SettingsHelper.getString(Config.SETTING_USER_QQ_OPENID, "");
        WXOpenid = SettingsHelper.getString(Config.SETTING_USER_WX_OPENID, "");
        WBOpenid = SettingsHelper.getString(Config.SETTING_USER_WB_OPENID, "");
    }


    private void refresh() {
        if (TextUtils.isEmpty(mobile) && !TextUtils.isEmpty(bindEmail)) {//手机号为空 邮箱不空
            mTvPhoneBind.setText("");
            mBtnPhoneBind.setVisibility(View.VISIBLE);
            mBtnPhoneBind.setText(getString(R.string.activity_account_set_bind));
            mPhoneBindContainer.setEnabled(true);

            mTvEmailBind.setText(bindEmail);
            mBtnEmailBind.setVisibility(View.INVISIBLE);
            mEmailBindContainer.setEnabled(false);
        } else if (!TextUtils.isEmpty(mobile) && TextUtils.isEmpty(bindEmail)) {
            mTvPhoneBind.setText(mobile);
            mBtnPhoneBind.setVisibility(View.INVISIBLE);
            mPhoneBindContainer.setEnabled(false);

            mTvEmailBind.setText("");
            mTvEmailBind.setVisibility(View.VISIBLE);
            mBtnEmailBind.setText(getString(R.string.activity_account_set_bind));
            mEmailBindContainer.setEnabled(true);
        } else if (!TextUtils.isEmpty(mobile) && !TextUtils.isEmpty(bindEmail)) {
            mTvPhoneBind.setText(mobile);
            mBtnPhoneBind.setVisibility(View.VISIBLE);
            mBtnPhoneBind.setText(getString(R.string.activity_account_set_unbind));
            mPhoneBindContainer.setEnabled(true);

            mTvEmailBind.setText(bindEmail);
            mBtnEmailBind.setVisibility(View.VISIBLE);
            mBtnEmailBind.setText(getString(R.string.activity_account_set_unbind));
            mEmailBindContainer.setEnabled(true);
        } else {
            mTvPhoneBind.setText("");
            mBtnPhoneBind.setVisibility(View.VISIBLE);
            mBtnPhoneBind.setText(getString(R.string.activity_account_set_bind));
            mPhoneBindContainer.setEnabled(true);

            mTvEmailBind.setText("");
            mTvEmailBind.setVisibility(View.VISIBLE);
            mBtnEmailBind.setText(getString(R.string.activity_account_set_bind));
            mEmailBindContainer.setEnabled(true);
        }

        if (TextUtils.isEmpty(mobile) && TextUtils.isEmpty(bindEmail)) {
            btn_change_password.setVisibility(View.GONE);
            view_divider_1.setVisibility(View.GONE);
            view_divider_2.setVisibility(View.GONE);
        } else {
            btn_change_password.setVisibility(View.VISIBLE);
            view_divider_1.setVisibility(View.VISIBLE);
            view_divider_2.setVisibility(View.VISIBLE);
        }

        if (PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1) == 2) {
            if (TextUtils.isEmpty(QQOpenid)) {//qq 没有经过绑定操作
                mTvQQBind.setText(name);//QQ的昵称 就是用用户姓名
            } else {
                mTvQQBind.setText(QQName);
            }
            mBtnQQBind.setVisibility(View.INVISIBLE);// 把绑定按钮隐藏
            mQQBindContainer.setEnabled(false);
        } else {//不是QQ登录的
            if (TextUtils.isEmpty(QQOpenid)) {//没绑定了qq
                mTvQQBind.setText("");
                mBtnQQBind.setText(getString(R.string.activity_account_set_bind));
            } else {//绑定了QQ
                mTvQQBind.setText(QQName);
                mBtnQQBind.setText(getString(R.string.activity_account_set_unbind));
            }
            mQQBindContainer.setEnabled(true);
        }

        if (PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1) == 3) {
            if (TextUtils.isEmpty(WXOpenid)) {//微信 没有经过绑定操作
                mTvWeixinBind.setText(name);//昵称 就是用用户姓名
            } else {
                mTvWeixinBind.setText(WXName);
                mBtnWeixinBind.setText(getString(R.string.activity_account_set_unbind));
            }
            mBtnWeixinBind.setVisibility(View.INVISIBLE);// 把绑定按钮隐藏
            mWeixinBindContainer.setEnabled(false);
        } else {
            if (TextUtils.isEmpty(WXOpenid)) {//微信
                mTvWeixinBind.setText("");
                mBtnWeixinBind.setText(getString(R.string.activity_account_set_bind));
            } else {
                mTvWeixinBind.setText(WXName);
                mBtnWeixinBind.setText(getString(R.string.activity_account_set_unbind));
            }
            mWeixinBindContainer.setEnabled(true);
        }

        if (PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1) == 4) {
            if (TextUtils.isEmpty(WBOpenid)) {//新浪微博
                mTvSinaBind.setText(name);
            } else {
                mTvSinaBind.setText(WBName);
            }
            mBtnWeiboBind.setVisibility(View.INVISIBLE);
            mWeiboBindContainer.setEnabled(false);
        } else {
            if (TextUtils.isEmpty(WBOpenid)) {//新浪微博
                mTvSinaBind.setText("");
                mBtnWeiboBind.setText(getString(R.string.activity_account_set_bind));
            } else {
                mTvSinaBind.setText(WBName);
                mBtnWeiboBind.setText(getString(R.string.activity_account_set_unbind));
            }
            mWeiboBindContainer.setEnabled(true);
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_change_password://修改密码
                startChangePasswordActivity();
                break;
            case R.id.bind_phone_container:
                if (TextUtils.isEmpty(mobile)) {//进行绑定手机号操作
                    startPhoneBindActivity();
                    SettingsHelper.putBoolean(Config.SETTING_BIND_MOBILE, true);
                } else {//解除绑定
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_account_set_unbind_confirm)
                            .negativeText(android.R.string.cancel)
                            .positiveText(android.R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            doUnBindByType(Config.UNBIND_TYPE_BY_PHONE);
                                            break;

                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                }
                break;
            case R.id.bind_email_container://邮箱绑定
                if (TextUtils.isEmpty(bindEmail)) {//进行绑定邮箱操作
                    startEmailBindActivity();
                } else {//解除绑定
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_account_set_unbind_confirm)
                            .negativeText(android.R.string.cancel)
                            .positiveText(android.R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            doUnBindByType(Config.UNBIND_TYPE_BY_EMAIL);
                                            break;

                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                }
                break;
            case R.id.bind_wx_container://微信绑定
                if (TextUtils.isEmpty(WXOpenid)) {//进行绑定微信操作
                    bindWechat();
                } else {//解除绑定
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_account_set_unbind_confirm)
                            .negativeText(android.R.string.cancel)
                            .positiveText(android.R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            doUnBindByType(Config.UNBIND_TYPE_BY_WECHAT);
                                            break;

                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                }
                break;
            case R.id.bind_qq_container://QQ绑定
                if (TextUtils.isEmpty(QQOpenid)) {//进行绑定QQ操作
                    bindQQ();
                } else {//解除绑定
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_account_set_unbind_confirm)
                            .negativeText(android.R.string.cancel)
                            .positiveText(android.R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            doUnBindByType(Config.UNBIND_TYPE_BY_QQ);
                                            break;

                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                }
                break;
            case R.id.bind_wb_container://新浪微博绑定
                if (TextUtils.isEmpty(WBOpenid)) {//进行绑定新浪微博操作
                    bindWeibo();
                } else {//解除绑定
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_account_set_unbind_confirm)
                            .negativeText(android.R.string.cancel)
                            .positiveText(android.R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            doUnBindByType(Config.UNBIND_TYPE_BY_SINA);
                                            break;

                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                }
                break;
        }
    }

    /**
     * 设置绑定类型
     *
     * @param sType 绑定类型
     */
    private void setBindType(int sType) {
        this.bindType = sType;
    }


    /**
     * 解绑操作
     *
     * @param sType 绑定类型
     */
    private void doUnBindByType(int sType) {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().unBindString(sType - 5, true);
        registerDataReqStatusListener(requestId);
//
//        String bindString = getRequestSynthesizer().getUnBindString(sType - 5);
//        sendNetRequest(bindString, sType);
    }

    /**
     * 获取绑定类型
     *
     * @return 绑定类型
     */
    private int getBindType() {
        return bindType;
    }

    private void startChangePasswordActivity() {
        Intent intent = new Intent();
        intent.setClass(this, ChangePasswordActivity.class);
        startActivityForResult(intent, CHANGE_PASSWORD);
    }

    /**
     * 邮箱绑定
     */
    private void startEmailBindActivity() {
        setBindType(Config.BIND_TYPE_BY_EMAIL);
        Intent intent = new Intent();
        if (TextUtils.isEmpty(mobile) && TextUtils.isEmpty(bindEmail)) {//手机邮箱均没有的第三方登录的用户 绑定时 需要填写密码
            intent.putExtra("EmailBindWithPWD", true);
        } else if (!TextUtils.isEmpty(mobile) && TextUtils.isEmpty(bindEmail)) {//乐享动手机注册用户,但没有绑定邮箱 绑定时 不需要填写密码
            intent.putExtra("EmailBind", true);
        }
        intent.setClass(this, EmailBindActivity.class);
        startActivityForResult(intent, Config.BIND_TYPE_BY_EMAIL);
    }

    /**
     * QQ绑定
     */
    private void bindQQ() {
        setBindType(Config.BIND_TYPE_BY_QQ);
        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_QQ_BIND);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_BIND);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);
    }

    /**
     * 微信绑定
     */
    private void bindWechat() {
        setBindType(Config.BIND_TYPE_BY_WECHAT);
        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_WECHAT_BIND);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_WECHAT_BIND);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);

    }

    /**
     * 微博绑定
     */
    private void bindWeibo() {
        setBindType(Config.BIND_TYPE_BY_SINA);
        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_SINA_BIND);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_SINA_BIND);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);
    }

    /**
     * 手机绑定
     */
    private void startPhoneBindActivity() {
        setBindType(Config.BIND_TYPE_BY_PHONE);
        Intent intent = new Intent();
        if (TextUtils.isEmpty(mobile) && TextUtils.isEmpty(bindEmail)) {//手机邮箱均没有的第三方登录的用户  绑定时 需要填写密码
            intent.putExtra("PhoneBindWithPWD", true);
        } else if (TextUtils.isEmpty(mobile) && !TextUtils.isEmpty(bindEmail)) {//乐享动邮箱注册用户,但没有经过手机验证  绑定时 不需要填写密码
            intent.putExtra("PhoneBind", true);
        }
        intent.setClass(this, PhoneBindActivity.class);
        startActivityForResult(intent, Config.BIND_TYPE_BY_PHONE);
    }


    /**
     * 通过的绑定的类型 来选择绑定方式 第三方通过这种方式
     */
    private void bindByType(String bindingName, String openid) {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().getBind(openid, bindingName != null ? bindingName : "", getBindType(), true);
        registerDataReqStatusListener(requestId);


//        String bindString = getRequestSynthesizer().getBindString();
//        sendNetRequest(bindString, bindType);
        bindName = bindingName;
        bindOpenid = openid;
    }


    private void switchLoginInfo() {
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1) {
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_USER, TextUtils.isEmpty(mobile) ? bindEmail : mobile);
//            String sResult = getRequestSynthesizer().getLoginString(getMyConfig().getSystemConfig().getLastUsername(), getMyConfig().getSystemConfig().getLastPassword());
//            getMyConfig().getSystemConfig().setLastLoginString(sResult);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CHANGE_PASSWORD:
                if (resultCode == Activity.RESULT_OK) {
                    logout();
                }
                break;
            case Config.BIND_TYPE_BY_EMAIL:
                if (resultCode == Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE) {//邮箱绑定返回 成功
                    getBindData();
                    refresh();
                }
                break;
            case Config.BIND_TYPE_BY_PHONE:
                if (resultCode == Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE) {//手机绑定返回 成功
                    getBindData();
                    refresh();
                }
                break;
        }
        if (resultCode == REQUEST_BIND_RESULT_CODE) {//三方绑定 获取信息成功
            if (data != null) {
                String name = data.getStringExtra("name");
                String openid = data.getStringExtra("openid");
                bindByType(name, openid);//信息 在 服务器注册
            }
        }
    }

    private void logout() {
        stopStepCount();
        //重新设置Uid,登录类型
        UserDataManager.setUid(Config.ANONYMOUS_UID);
        PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        //清除三方登录openid,access token
        AccessTokenKeeper.clear(this);
        //清除数据请求表
        MixApp.getDaoSession(this).getDataReqStatusDao().deleteAll();
        //启动登录界面
        startLoginActivity();
    }

    private void stopStepCount() {
        Intent i = new Intent(this, RunService.class);
        stopService(i);
    }

    private void startLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("startMain", true);
        startActivity(intent);
        finish();
    }
}
