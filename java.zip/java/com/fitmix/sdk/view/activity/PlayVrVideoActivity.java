package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.common.vrlibs.MDVRLibrary;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.bean.Video;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.VerticalSeekBar;

/**
 * 全景视频界面
 */
public class PlayVrVideoActivity extends BaseActivity {

    //    private static final String TAG = "PlayVrVideoActivity";
    private LinearLayout bottomLayout;
    private LinearLayout headerLayout;
    private LinearLayout rightLayout;
    private SeekBar seekBar;
    private VerticalSeekBar volume_seekbar;
    private ImageView video_play_state;
    private TextView videoTitle;
    private TextView currentPosition;
    private TextView totalSize;
    private RelativeLayout error_layout;
    private RelativeLayout progress_layout;
    private static int progressValue = 0;
    private static int videoLength;
    private String uriAddress;
    private Video video;
    private boolean bCanShow = true;
    private boolean bControlHide = true;

    private AudioManager mAudioManager;
    /**
     * 最大声音
     */
    private int mMaxVolume;
    /**
     * 当前声音
     */
    private int mVolume = -1;
    private GestureDetector mGestureDetector;
    private MyGestureListener myGestureListener;
    private SeekBar.OnSeekBarChangeListener videoProgressListener;
    private SeekBar.OnSeekBarChangeListener volumeProgressListener;
    private MediaPlayer.OnErrorListener videoErrorListener;
    private MediaPlayer.OnCompletionListener videoCompleteListener;
    private MediaPlayer.OnPreparedListener videoPreParedListener;
    private MediaPlayer.OnInfoListener videoInfoListener;
    private MediaPlayer.OnVideoSizeChangedListener videoSizeChangedListener;

    private MediaPlayer mMediaPlayer;
    private MDVRLibrary mVRLibrary;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        full(false);
        setContentView(R.layout.activity_md_multi);
        setPageName("PlayVrVideoActivity");
        String videoString = getIntent().getStringExtra("videoString");
        if (!TextUtils.isEmpty(videoString))
            video = JsonHelper.getObject(videoString, Video.class);
        initViews();
        initPlayer();
        initData();
    }

    protected void initViews() {
        //底部控制
        bottomLayout = (LinearLayout) findViewById(R.id.bottom_view);
        //顶部控制
        headerLayout = (LinearLayout) findViewById(R.id.header_view);
        //右步控制
        rightLayout = (LinearLayout) findViewById(R.id.right_view);
        //错误提示
        error_layout = (RelativeLayout) findViewById(R.id.error_layout);
        progress_layout = (RelativeLayout) findViewById(R.id.progress_layout);

        videoTitle = (TextView) findViewById(R.id.tv_video_title);
        currentPosition = (TextView) findViewById(R.id.tv_current_position);
        totalSize = (TextView) findViewById(R.id.tv_total_time);
        //进度条
        seekBar = (SeekBar) findViewById(R.id.videoview_seekbar);
        volume_seekbar = (VerticalSeekBar) findViewById(R.id.volume_seekbar);

        video_play_state = (ImageView) findViewById(R.id.video_play_state);

        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mMaxVolume = mAudioManager
                .getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        volume_seekbar.setMax(mMaxVolume);
        //视频进度
        videoProgressListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                volume_seekbar.removeCallbacks(hideLayoutTask);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                progressValue = seekBar.getProgress();
                getMediaPlayer().seekTo(progressValue);
                getMediaPlayer().start();
                updateVideoProgress();
                hideVideoControler();
            }
        };
        seekBar.setOnSeekBarChangeListener(videoProgressListener);
        //声音大小
        volumeProgressListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
//                showRightLayout();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
        volume_seekbar.setOnSeekBarChangeListener(volumeProgressListener);
    }

    private void initData() {
        if (video == null) return;
        setUriAddress(video.getVideoUrl());
        setTitle(video.getTitle());
        playVideo();
    }

    /**
     * 播放视频
     */
    public void playVideo() {
        if (TextUtils.isEmpty(uriAddress)) {
            return;
        }
        try {
            getVRLibrary();
            getMediaPlayer().reset();
//            HttpProxyCacheServer proxy = MixApp.getProxy(getApplicationContext());
//            getMediaPlayer().setDataSource(proxy.getProxyUrl(uriAddress));
            getMediaPlayer().setDataSource(uriAddress);
            showProgressBar();
            getMediaPlayer().prepareAsync();
        } catch (Exception e) {

        }

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();

        switch (requestId) {
            case Config.MODULE_USER + 60://完成每日分享运动视频金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, System.currentTimeMillis());//设置完成任务时间

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        //不处理
    }

    private void setTitle(String title) {
        videoTitle.setText(title);
    }

    /**
     * 动态设置状态栏是否显示
     *
     * @param enable 1、true 显示  2、false 不显示
     */
    private void full(boolean enable) {
        if (!enable) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            getWindow().setAttributes(lp);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        } else {
            WindowManager.LayoutParams attr = getWindow().getAttributes();
            attr.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().setAttributes(attr);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
    }

    /**
     * 隐藏控制video任务
     */
    private void hideVideoControler() {
        bottomLayout.removeCallbacks(hideLayoutTask);
        bottomLayout.postDelayed(hideLayoutTask, 3000);
    }

    /**
     * 隐藏开启声音任务
     */
    private void hideVolumeControler() {
        rightLayout.removeCallbacks(hideRightLayoutTask);
        rightLayout.postDelayed(hideRightLayoutTask, 3000);
    }

    /**
     * 进度条更新开启任务
     */
    private void updateVideoProgress() {
        seekBar.removeCallbacks(mUpdateProgress);
        seekBar.post(mUpdateProgress);
    }

    /**
     * 隐藏布局
     */
    public Runnable hideRightLayoutTask = new Runnable() {
        @Override
        public void run() {
            hideRightLayout();
        }
    };

    /**
     * 隐藏布局
     */
    public Runnable hideLayoutTask = new Runnable() {
        @Override
        public void run() {
            hideLayout();
        }
    };

    /**
     * 进度条更新
     */
    public Runnable mUpdateProgress = new Runnable() {
        @Override
        public void run() {
            int progressValue = getMediaPlayer().getCurrentPosition();
            seekBar.setProgress(progressValue);
            currentPosition.setText(FormatUtil.formatMusicTime(progressValue / 1000));
            totalSize.setText(FormatUtil.formatMusicTime(videoLength / 1000));

            if (getMediaPlayer().isPlaying()) {
                seekBar.postDelayed(mUpdateProgress, 1000);
            }
        }
    };


    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (getmGestureDetector().onTouchEvent(event))
            return true;
        // 处理手势结束
//        switch (event.getAction() & MotionEvent.ACTION_MASK) {
//            case MotionEvent.ACTION_UP:
//                endGesture();
//                break;
//        }
        //return super.onTouchEvent(event);
        return mVRLibrary.handleTouchEvent(event) || super.onTouchEvent(event);
    }

    private GestureDetector getmGestureDetector() {
        if (mGestureDetector == null) {
            myGestureListener = new MyGestureListener();
            mGestureDetector = new GestureDetector(this, myGestureListener);
        }
        return mGestureDetector;
    }

    /**
     * 手势结束
     */
    private void endGesture() {
        mVolume = -1;
    }

    private class MyGestureListener extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            if (bCanShow && bControlHide) {
                showVideoControlerLayout();
            } else if (!bControlHide) {
                hideLayout();
            }
            return super.onSingleTapUp(e);
        }
        //        @Override
//        public boolean onDoubleTap(MotionEvent e) {
//            if (bCanShow)
//                showVideoControlerLayout();
//            return true;
//        }

//        @Override
//        public boolean onScroll(MotionEvent e1, MotionEvent e2,
//                                float distanceX, float distanceY) {
//            float mOldX = e1.getX(), mOldY = e1.getY();
//            int y = (int) e2.getRawY();
//            Display disp = getWindowManager().getDefaultDisplay();
//            Point size = new Point();
//            disp.getSize(size);
//            int width = size.x;
//            int height = size.y;
//
//            if (mOldX > width * 4.0 / 5)// 右边滑动
//                onVolumeSlide((mOldY - y) / height);
//
//            return super.onScroll(e1, e2, distanceX, distanceY);
//        }
    }

    /**
     * 滑动改变声音大小
     *
     * @param percent
     */
    private void onVolumeSlide(float percent) {
        if (mVolume == -1) {
            mVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if (mVolume < 0)
                mVolume = 0;
        }
        volume_seekbar.setProgress(mVolume);
        showRightLayout();
        int index = (int) (percent * mMaxVolume) + mVolume;
        if (index > mMaxVolume)
            index = mMaxVolume;
        else if (index < 0)
            index = 0;
        // 变更进度条 进而变更声音
        volume_seekbar.setProgress(index);

    }

    public MDVRLibrary getVRLibrary() {
        if (mVRLibrary == null) {
            mVRLibrary = createVRLibrary();
        }
        return mVRLibrary;
    }


    protected MediaPlayer getMediaPlayer() {
        if (mMediaPlayer == null) {
            mMediaPlayer = new MediaPlayer();
        }
        return mMediaPlayer;
    }

    private MDVRLibrary createVRLibrary() {
        return MDVRLibrary.with(this)
                .displayMode(MDVRLibrary.DISPLAY_MODE_NORMAL)
                .interactiveMode(MDVRLibrary.INTERACTIVE_MODE_MOTION_WITH_TOUCH)
                .asVideo(new MDVRLibrary.IOnSurfaceReadyCallback() {
                    @Override
                    public void onSurfaceReady(Surface surface) {
                        getMediaPlayer().setSurface(surface);
                        Logger.i(Logger.DEBUG_TAG, "VideoPlayerActivity --- > createVRLibrary --- > onSurfaceReady -- > ");
                    }
                })
                .ifNotSupport(new MDVRLibrary.INotSupportCallback() {
                    @Override
                    public void onNotSupport(int mode) {
                        String tip = mode == MDVRLibrary.INTERACTIVE_MODE_MOTION
                                ? "onNotSupport:MOTION" : "onNotSupport:" + String.valueOf(mode);
                        Toast.makeText(PlayVrVideoActivity.this, tip, Toast.LENGTH_SHORT).show();
                    }
                })
                .pinchEnabled(true)
                .build(R.id.surface_view);
    }

    /**
     * 初始化mediaplayer
     */
    private void initPlayer() {
        videoErrorListener = new MediaPlayer.OnErrorListener() {
            /**
             * 视频播放发生错误
             */
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                cancleProgressBar();
                showVideoControlerLayout();
                showAppMessage("视频播放错误~", AppMsg.STYLE_ALERT);
                return true;
            }
        };
        videoCompleteListener = new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                stop();
            }
        };
        videoPreParedListener = new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                full(true);
                cancleProgressBar();
                getMediaPlayer().start();
                videoLength = getMediaPlayer().getDuration();
                seekBar.setMax(videoLength);
                seekBar.setProgress(progressValue);
                updateVideoProgress();
            }
        };
        videoSizeChangedListener = new MediaPlayer.OnVideoSizeChangedListener() {
            @Override
            public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                getVRLibrary().onTextureResize(width, height);
            }
        };

        getMediaPlayer().setOnVideoSizeChangedListener(videoSizeChangedListener);
        getMediaPlayer().setOnErrorListener(videoErrorListener);
        getMediaPlayer().setOnPreparedListener(videoPreParedListener);
        getMediaPlayer().setOnCompletionListener(videoCompleteListener);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            videoInfoListener = new MediaPlayer.OnInfoListener() {
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                        showProgressBar();
                    } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {  //此接口每次回调完START就回调END,若不加上判断就会出现缓冲图标一闪一闪的卡顿现象
                        if (mp.isPlaying()) {
                            cancleProgressBar();
                        }
                    }
                    return true;
                }
            };
            getMediaPlayer().setOnInfoListener(videoInfoListener);
        }
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.video_play_state:
                showVideoControlerLayout();
                if (getMediaPlayer().isPlaying()) {
                    getMediaPlayer().pause();
                    video_play_state.setImageResource(R.drawable.play);
                } else {
                    getMediaPlayer().start();
                    updateVideoProgress();
                    video_play_state.setImageResource(R.drawable.stop);
                }
                break;
            case R.id.iv_play_next:
//                video = videoList.get((index + 1) % videoList.size());
//                index++;
//                initData();
                break;
            case R.id.iv_back:
                finish();
                break;
            case R.id.iv_share_video:
                shareVideo();
                break;
        }
    }

    public void shareVideo() {
        if (video != null)
            ShareUtils.getInstance().shareVideo(this, video);
    }

    /**
     * 显示声音控制布局
     */
    private void showRightLayout() {
        rightLayout.setVisibility(View.VISIBLE);
        hideVolumeControler();
    }

    /**
     * 隐藏布局
     */
    private void hideRightLayout() {
        rightLayout.setVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        resume();
        super.onResume();
    }

    @Override
    protected void onPause() {
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onPause ()");
        pause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onStop ()");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
            getMediaPlayer().setOnInfoListener(null);
        }
        if (mVRLibrary != null)
            mVRLibrary.onDestroy();
        myGestureListener = null;
        mGestureDetector = null;
        if (volume_seekbar != null) {
            volume_seekbar.setOnSeekBarChangeListener(null);
        }

        if (seekBar != null) {
            seekBar.setOnSeekBarChangeListener(null);
            seekBar.removeCallbacks(mUpdateProgress);
        }

        if (mVRLibrary != null) {
            mVRLibrary.onDestroy();
        }
        if (getMediaPlayer() != null) {
            progressValue = 0;
            getMediaPlayer().setOnCompletionListener(null);
            getMediaPlayer().setOnPreparedListener(null);
            getMediaPlayer().setOnErrorListener(null);
            bottomLayout.removeCallbacks(hideLayoutTask);
            rightLayout.removeCallbacks(hideRightLayoutTask);
        }
        Logger.d(Logger.DEBUG_TAG, "playVideoActivity --- > onDestroy ()");
        super.onDestroy();
    }

    /**
     * 显示布局
     */
    private void showVideoControlerLayout() {
        bControlHide = false;
        full(true);
        error_layout.setVisibility(View.VISIBLE);
        bottomLayout.setVisibility(View.VISIBLE);
        headerLayout.setVisibility(View.VISIBLE);
//        if (!videoView.isPlaying()) {
//            return;
//        }
        if (getMediaPlayer().isPlaying()) {
            showPause();
        } else {
            showPLay();
        }
        hideVideoControler();
    }

    /**
     * 隐藏布局
     */
    private void hideLayout() {
        full(false);
        error_layout.setVisibility(View.GONE);
        bottomLayout.setVisibility(View.GONE);
        headerLayout.setVisibility(View.GONE);
        bControlHide = true;
    }

    /**
     * 显示播放按钮的布局
     */
    private void showPLay() {
        video_play_state.setImageResource(R.drawable.play);

    }

    /**
     * 显示暂停按钮的布局
     */
    private void showPause() {
        video_play_state.setImageResource(R.drawable.stop);
    }

    /**
     * 暂停播放
     */
    private void pause() {
        if (mVRLibrary != null)
            mVRLibrary.onPause(this);
        progressValue = getMediaPlayer().getCurrentPosition();
        getMediaPlayer().pause();
        Logger.i(Logger.DEBUG_TAG, "playVideoActivity --- > pause : progressValue :" + progressValue);
    }

    /**
     * 暂停播放
     */
    private void resume() {
        if (mVRLibrary != null)
            mVRLibrary.onResume(this);

        if (progressValue > 0) {
            getMediaPlayer().start();
            updateVideoProgress();
        }
    }

    /**
     * 停止播放
     */
    private void stop() {
        progressValue = 0;
        getMediaPlayer().stop();
        cancleProgressBar();
        showVideoControlerLayout();
    }

    /**
     * @return 返回视频地址
     */
    public String getUriAddress() {
        return uriAddress;
    }

    /**
     * 设置视频地址
     *
     * @param uriAddress 视频地址
     */
    public void setUriAddress(String uriAddress) {
        this.uriAddress = uriAddress;
    }

    /**
     * 取消加载图层
     */
    private void cancleProgressBar() {
        bCanShow = true;
        progress_layout.setVisibility(View.GONE);
    }

    /**
     * 显示加载图层
     */
    private void showProgressBar() {
        bCanShow = false;
        hideLayout();
        progress_layout.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareVideoCoinTask();
                            }
                            break;
                    }
                }
                break;
        }
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动视频金币任务
     */
    private void finishShareVideoCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareVideoCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================

}