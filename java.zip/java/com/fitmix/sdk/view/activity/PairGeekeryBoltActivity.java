package com.fitmix.sdk.view.activity;


import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.csr.gaia.android.library.Gaia;
import com.csr.gaia.android.library.GaiaLink;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.A2dpServiceListener;
import com.fitmix.sdk.common.bluetooth.Bolt_gaia_t;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.EmojiAdapter;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.Set;

public class PairGeekeryBoltActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener {

    /**
     * 打开系统蓝牙设置界面
     */
    private final static int REQUEST_ENABLE_BLUETOOTH = 21;
    private static final int MSG_REFRESH_STATUS = 111;

    private RadioGroup radiogroup_push_type;
    private boolean bLedBrightForever;
    private FrameLayout fl_activity_pair_pair_geekery_bolt;
    private RelativeLayout rl_txt;
    private EditText txt_push_text;
    private RelativeLayout rl_emoji;
    private GridView gv_push_emoji;
    private int select_emoji_index = 0;
    private CheckBox ckb_a2dp_connect;
    private CheckBox ckb_gaia_connect;
    private CheckBox ckb_led;

    private int a2dpState = BluetoothProfile.STATE_DISCONNECTED;
    private BluetoothAdapter mBluetoothAdapter;
    private EmojiAdapter emojiAdapter;

    private boolean checkByMan = true;
    private MyHandlerX mHandlerX;
    private String gaiaAddress;//GAIA连接地址

    /**
     * 金币任务,使用我的设备配对一次任务是否完成
     */
    private boolean coinTaskPairBtFinished = true;


    /**
     * GAIA连接帮助
     */
    private GaiaLink gaiaLink;
    /**
     * GAIA连接状态,参考{@link android.bluetooth.BluetoothProfile}
     */
    private int gaiaState = BluetoothProfile.STATE_DISCONNECTED;


    /**
     * 自定义
     */
    public static class MyHandlerX extends WeakHandler {

        public MyHandlerX(Activity activity) {
            super(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            PairGeekeryBoltActivity activity = (PairGeekeryBoltActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case A2dpServiceListener.MSG_A2DP_CONNECT_SUCCESS:
                    activity.showAppMessage(R.string.bt_connect_success, AppMsg.STYLE_INFO);
                    break;

                case A2dpServiceListener.MSG_A2DP_CONNECT_FAIL:
                    activity.showAppMessage(R.string.bt_connect_fail, AppMsg.STYLE_ALERT);
                    break;

                case MSG_REFRESH_STATUS:
                    activity.refresh();
                    break;
                default://GAIA相关
                    activity.handleGaiaMessage(activity, msg);
                    break;
            }
        }
    }

    /**
     * GAIA消息
     */
    public void handleGaiaMessage(PairGeekeryBoltActivity activity, Message msg) {
        if (activity == null) return;
        switch (GaiaLink.Message.valueOf(msg.what)) {
            case CONNECTED://1 GAIA连接成功
                activity.gaiaState = BluetoothProfile.STATE_CONNECTED;
                PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_GAIA_ADDRESS, gaiaAddress);//保存GAIA地址
                showAppMessage(R.string.activity_pair_bolt_gaia_connected, AppMsg.STYLE_INFO);
                activity.gaiaCheckByProgram(true);
                break;
            case DISCONNECTED://4 GAIA断开连接
                activity.gaiaState = BluetoothProfile.STATE_DISCONNECTED;
                PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_GAIA_ADDRESS, "");//清空GAIA地址
                showAppMessage(R.string.activity_pair_bolt_gaia_disconnected, AppMsg.STYLE_ALERT);
                activity.gaiaCheckByProgram(false);
                break;
            case ERROR://2
                showAppMessage(R.string.activity_pair_bolt_gaia_error, AppMsg.STYLE_ALERT);
                Logger.i(Logger.DEBUG_TAG, "gaia error");
                break;
            case STREAM://5
                Logger.i(Logger.DEBUG_TAG, "gaia stream");
                break;
            case DEBUG://3
                Logger.i(Logger.DEBUG_TAG, "gaia debug");
                break;
            case UNHANDLED://0
                Logger.i(Logger.DEBUG_TAG, "gaia unhandled");
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_geekery_bolt);
        setPageName("PairGeekeryBoltActivity");

        initToolbar();
        initViews();
        if (mHandlerX == null) {
            mHandlerX = new MyHandlerX(this);
        }
        gaiaAddress = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_GAIA_ADDRESS, "");
        if (!TextUtils.isEmpty(gaiaAddress)) {
            disconnectGaia();
            connectGaiaByAddress(gaiaAddress);
        }

        if (getIntent() != null) {
            coinTaskPairBtFinished = getIntent().getBooleanExtra(EquipmentActivity.INTENT_EXTRA_PAIR_BT_TASK, true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandlerX.removeMessages(MSG_REFRESH_STATUS);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandlerX.setDiscardMsgFlag(true);
    }

    /**
     * 刷新状态
     */
    private void refresh() {
        mHandlerX.sendEmptyMessageDelayed(MSG_REFRESH_STATUS, 1000);
        refreshA2dpState();
//        refreshGaiaState();
    }


    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        ckb_a2dp_connect = (CheckBox) findViewById(R.id.ckb_a2dp_connect);
        ckb_gaia_connect = (CheckBox) findViewById(R.id.ckb_gaia_connect);
        ckb_led = (CheckBox) findViewById(R.id.ckb_led);
        ckb_a2dp_connect.setOnCheckedChangeListener(this);
        ckb_gaia_connect.setOnCheckedChangeListener(this);
        ckb_led.setOnCheckedChangeListener(this);

        fl_activity_pair_pair_geekery_bolt = (FrameLayout) findViewById(R.id.fl_activity_pair_pair_geekery_bolt);
        rl_txt = (RelativeLayout) findViewById(R.id.rl_txt);
        txt_push_text = (EditText) findViewById(R.id.txt_text);
        txt_push_text.setOnKeyListener(new EditText.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {//点击回车,发送消息
                    int displayCount = bLedBrightForever ? 200 : 5;
                    String text = txt_push_text.getText().toString();
                    if (!TextUtils.isEmpty(text)) {
                        showText(text, displayCount);
                    }
                    return true;
                }
                return false;
            }
        });
        rl_emoji = (RelativeLayout) findViewById(R.id.rl_emoji);
        gv_push_emoji = (GridView) findViewById(R.id.gv_emoji);
        emojiAdapter = new EmojiAdapter(this);
        gv_push_emoji.setChoiceMode(GridView.CHOICE_MODE_SINGLE);
        gv_push_emoji.setAdapter(emojiAdapter);
        gv_push_emoji.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> gv, View v, int position,
                                    long id) {
                select_emoji_index = position + 1;
                emojiAdapter.setSelectedPosition(position);
                emojiAdapter.notifyDataSetInvalidated();
            }
        });

        emojiAdapter.setSelectedPosition(0);
        radiogroup_push_type = (RadioGroup) findViewById(R.id.radiogroup_gaia_type);
        radiogroup_push_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radio_text:
                        select_emoji_index = 0;
                        fl_activity_pair_pair_geekery_bolt.setBackgroundResource(R.drawable.icon_text_fl_bg);
                        rl_txt.setVisibility(View.VISIBLE);
                        rl_emoji.setVisibility(View.GONE);
                        break;


                    case R.id.radio_emoji:
                        select_emoji_index = 1;
                        fl_activity_pair_pair_geekery_bolt.setBackgroundResource(R.drawable.icon_expression_fl_bg);
                        rl_txt.setVisibility(View.GONE);
                        rl_emoji.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });
    }

//	@Override
//	protected void requestingCountChang(int requestingCount) {
//		//不处理
//	}

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 52://完成使用我的设备配对一次金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            coinTaskPairBtFinished = true;
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成任务

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 52://设备配对一次金币任务
                    if (bean.getCode() == 9002) {//该任务已完成
                        coinTaskPairBtFinished = true;
                        SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成
                    }
                    break;
            }
        }
    }

    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if (mBluetoothAdapter == null) {
            showAppMessage(R.string.bt_not_supported, AppMsg.STYLE_ALERT);
        }
        return mBluetoothAdapter;
    }

    /**
     * 根据蓝牙连接状态刷新界面
     */
    private void refreshA2dpState() {
        if (getBluetoothAdapter() == null) return;
        int state = getBluetoothAdapter()
                .getProfileConnectionState(BluetoothProfile.A2DP);
        switch (state) {
            case BluetoothProfile.STATE_CONNECTED:
                if (a2dpState != state) {
                    showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                }
                a2dpCheckByProgram(true);

                break;
            case BluetoothProfile.STATE_DISCONNECTED:
            case BluetoothProfile.STATE_DISCONNECTING:
                if (a2dpState != state) {
                    showAppMessage(R.string.a2dp_disconnected, AppMsg.STYLE_INFO);
                    a2dpCheckByProgram(false);
                }
                break;

            case BluetoothProfile.STATE_CONNECTING:
                if (a2dpState != state) {
                    showAppMessage(R.string.bt_connecting, AppMsg.STYLE_INFO);
                }
                break;
        }

        a2dpState = state;
    }

//    /** 根据GAIA连接状态刷新界面*/
//    private void refreshGaiaState() {
//        if(getBluetoothAdapter() == null)return;
//        int state = getBluetoothAdapter()
//                .getProfileConnectionState(BluetoothProfile.A2DP);
//        switch (state) {
//            case BluetoothProfile.STATE_CONNECTED:
//                if (!TextUtils.isEmpty(gaiaAddress)){//蓝牙已连接并且之前保存的GAIA地址为空
//                    gaiaCheckByProgram(true);
//                }
//                break;
//            case BluetoothProfile.STATE_DISCONNECTED:
//            case BluetoothProfile.STATE_DISCONNECTING:
//                gaiaCheckByProgram(false);
//                PrefsHelper.with(this,Config.PREFS_USER).write(Config.SP_KEY_GAIA_ADDRESS,"");//清空GAIA连接
//                break;
//        }
//    }

    /**
     * a2dp CheckBox由程序设定值
     *
     * @param isCheck true:选中,false:不选中
     */
    private void a2dpCheckByProgram(boolean isCheck) {
        if (ckb_a2dp_connect != null) {
            checkByMan = false;
            ckb_a2dp_connect.setChecked(isCheck);
            checkByMan = true;

            if (isCheck) {
                if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                    finishPairBtCoinTask();
                }
            }
        }
    }

    /**
     * gaia CheckBox由程序设定值
     *
     * @param isCheck true:选中,false:不选中
     */
    private void gaiaCheckByProgram(boolean isCheck) {
        if (ckb_a2dp_connect != null) {
            checkByMan = false;
            ckb_gaia_connect.setChecked(isCheck);
            checkByMan = true;
            if (isCheck) {
                if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                    finishPairBtCoinTask();
                }
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (checkByMan) {
            switch (buttonView.getId()) {
                case R.id.ckb_a2dp_connect:
                    if (isChecked) {
                        gotoBluetoothSettings();
                    }
                    a2dpCheckByProgram(!isChecked);
                    break;

                case R.id.ckb_gaia_connect:
                    int state = getBluetoothAdapter()
                            .getProfileConnectionState(BluetoothProfile.A2DP);
                    if (isChecked) {
                        if (state != BluetoothProfile.STATE_CONNECTED) {//蓝牙没有连接上时,打开系统蓝牙设置界面
                            gotoBluetoothSettings();
                        } else {
                            Set<BluetoothDevice> bondedDevices = getBluetoothAdapter().getBondedDevices();
                            if (bondedDevices != null) {
                                for (BluetoothDevice device : bondedDevices) {
                                    if (device != null && device.getBondState() == BluetoothDevice.BOND_BONDED) {
                                        String deviceName = device.getName();
                                        if (!TextUtils.isEmpty(deviceName) && deviceName.startsWith("Geekery Bolt")) {
                                            if (TextUtils.isEmpty(gaiaAddress)) {
                                                gaiaAddress = device.getAddress();
                                            }
                                            if (!TextUtils.isEmpty(gaiaAddress)) {
                                                connectGaiaByAddress(gaiaAddress);
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    } else {
                        disconnectGaia();//断开gaia连接
                    }
                    gaiaCheckByProgram(!isChecked);
                    break;

                case R.id.ckb_led:
                    bLedBrightForever = isChecked;
                    break;
            }
        }
    }

    /**
     * 通过蓝牙设备地址,开启A2DP连接
     *
     * @param deviceAddress 蓝牙设备Mac地址,如24:da:9b:c5:54:81
     */
    private void connectGaiaByAddress(String deviceAddress) {
        Logger.i(Logger.DEBUG_TAG, "connectGaiaByAddress deviceAddress:" + deviceAddress);
        // 1.如果当前还在连接状态中,忽略
        if (gaiaState == BluetoothProfile.STATE_CONNECTING) {
            return;
        }

        // 2.初始化GAIA
        if (gaiaLink == null) {
            gaiaLink = new GaiaLink(GaiaLink.Transport.BT_GAIA);
            gaiaLink.setReceiveHandler(mHandlerX);
        }
        // 3.判断蓝牙地址有效性
        if (TextUtils.isEmpty(deviceAddress)) {
            return;
        }

        try {
            gaiaState = BluetoothProfile.STATE_CONNECTING;
            gaiaLink.disconnect();
            gaiaLink.connect(deviceAddress);
            Logger.i(Logger.DEBUG_TAG, "connectGaiaByAddress");
        } catch (Exception e) {
            e.printStackTrace();
            Logger.e(Logger.DEBUG_TAG, "connectGaiaByAddress error:" + e.getMessage());
            gaiaState = BluetoothProfile.STATE_DISCONNECTED;
        }
    }

    /**
     * 停止GAIA连接
     */
    private void disconnectGaia() {
        if (gaiaState == BluetoothProfile.STATE_DISCONNECTED ||
                gaiaState == BluetoothProfile.STATE_DISCONNECTING)
            return;
        try {
            gaiaState = BluetoothProfile.STATE_DISCONNECTING;
            gaiaLink.disconnect();
            gaiaState = BluetoothProfile.STATE_DISCONNECTED;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 导航到系统蓝牙设置
     */
    private void gotoBluetoothSettings() {
        Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        if (intent != null && intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_ENABLE_BLUETOOTH);
        }
    }

    public void doClick(View v) {
        if (getBluetoothAdapter() == null) return;
        switch (v.getId()) {
            case R.id.btn_send:
                int displayCount = bLedBrightForever ? 200 : 5;
                if (gaiaState != BluetoothProfile.STATE_CONNECTED) {
                    showAppMessage(R.string.gaia_disconnected, AppMsg.STYLE_CONFIRM);
                    break;
                }
                int state = getBluetoothAdapter()
                        .getProfileConnectionState(BluetoothProfile.A2DP);
                if (state != BluetoothProfile.STATE_CONNECTED) {
                    showAppMessage(R.string.bt_not_connected, AppMsg.STYLE_ALERT);
                    break;
                }

                if (rl_txt.getVisibility() == View.VISIBLE) {// 显示文字
                    String text = txt_push_text.getText().toString();
                    if (!TextUtils.isEmpty(text)) {
                        showText(text, displayCount);
                    } else {
                        showText("Geekery Bolt", displayCount);// 默认显示Geekery Bolt
                    }
                } else {// 显示表情
                    if ((select_emoji_index >= 1) && (select_emoji_index <= 15)) {
                        showEmoji(select_emoji_index, 1, displayCount);// 动画display_animation_index
                    }
                }

                break;
        }

    }

    /**
     * B1耳机显示文字
     *
     * @param text  要显示的文字
     * @param count 显示的次数,大于100表示永久
     */
    public void showText(String text, int count) {
        if (text == null)
            return;

        Bolt_gaia_t data = new Bolt_gaia_t();
        data.cmd = Bolt_gaia_t.BOLT_GAIA_CMD_ANIM_TEXT;
        data.data = text.getBytes();
        data.anim_count = (byte) count;
        sendCsrCommand(Gaia.COMMAND_BOLT_TRANSFER, data.toBytes());
    }

    /**
     * B1耳机显示表情
     *
     * @param index     表情标号
     * @param animation 动画类型
     * @param count     显示的次数,大于100表示永久
     */
    public void showEmoji(int index, int animation, int count) {
        Bolt_gaia_t data = new Bolt_gaia_t();
        data.cmd = Bolt_gaia_t.BOLT_GAIA_CMD_EMOJI;// 表情命令
        data.color_format = Bolt_gaia_t.GRAPHIC_FMT_8BIT;// 颜色格式
        data.data[0] = (byte) index;// 数据
        data.flag = (byte) animation;// 要静态图常亮 即animation =0
        // 必须用bolt_gaia.cmd=BOLT_GAIA_CMD_SET_LED_DISP_MODLE 命令
        data.anim_count = (byte) count;// XXX 次数 anim_count大于1000表示永久滚动
        sendCsrCommand(Gaia.COMMAND_BOLT_TRANSFER, data.toBytes());
    }

    /**
     * 发送指令
     */
    private void sendCsrCommand(int command, byte[] payload) {
        if (payload == null)
            return;
        if (gaiaState != BluetoothProfile.STATE_CONNECTED) {
            return;
        }
        try {
            gaiaLink.sendCommand(Gaia.VENDOR_CSR, command, payload);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_ENABLE_BLUETOOTH == requestCode) {
            refreshA2dpState();

        }
    }

    //region  ============================= 金币任务 =============================

    /**
     * 完成使用我的设备配对一次任务
     */
    private void finishPairBtCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_PAIRING_BT, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion ============================= 金币任务 =============================

}
