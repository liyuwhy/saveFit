package com.fitmix.sdk.view.activity;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.actions.ibluz.b.h;
import com.actions.ibluz.factory.IBluzDevice;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.bluetooth.skip.SkipBluetoothService;
import com.fitmix.sdk.common.bluetooth.skip.SkipCommandHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.BluetoothDevicesAdapter;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.progressbar.MaterialProgressBar;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;


public class PairSkipActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    /**
     * 打开系统蓝牙设置界面
     */
    private final static int REQUEST_ENABLE_BLUETOOTH = 21;

    private CheckBox ckb_a2dp_connect;
    private CheckBox ckb_spp_connect;
    private boolean checkByMan = true;
    private BluetoothAdapter mBluetoothAdapter;
    private int a2dpState = BluetoothProfile.STATE_DISCONNECTED;

    private Spinner spinner_skip_rate;
    //    private TextView tvSkipMode;
    private TextView tv_siri_set;
    /**
     * 金币任务,使用我的设备配对一次任务是否完成
     */
    private boolean coinTaskPairBtFinished = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_skip);
        setPageName("PairSkipActivity");
        initToolbar();
        initViews();
        connectToSkipService();

        if (getIntent() != null) {
            coinTaskPairBtFinished = getIntent().getBooleanExtra(EquipmentActivity.INTENT_EXTRA_PAIR_BT_TASK, true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mHandlerX.removeMessages(MSG_REFRESH_STATUS);
    }

    @Override
    protected void onDestroy() {
        disconnectToSkipBluetoothService();
//        RefWatcher refWatcher = MixApp.getRefWatcher(this);
//        refWatcher.watch(this);
        super.onDestroy();
        //mHandlerX.setDiscardMsgFlag(true);
    }

    //region ====================================== 与SkipService交互相关 ======================================

    private SkipBluetoothService skipBluetoothService;
    private SkipBluetoothService.OnCustomCommandListener mOnCustomCommandListener;
    private SkipBluetoothService.OnIBluzDeviceConnectionListener mOnIBluzDeviceConnectionListener;
    private h a2dpListener;

    /**
     * 获取跳绳服务
     */
    public SkipBluetoothService getSkipBluetoothService() {
        return skipBluetoothService;
    }

    private ServiceConnection serviceConnection;

    /**
     * 绑定跳绳服务
     */
    private void connectToSkipService() {
        Intent intent = new Intent(this, SkipBluetoothService.class);
        serviceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(SkipBluetoothService.SERVICE_NAME))
                    return;
                skipBluetoothService = ((SkipBluetoothService.LocalBinder) service).getService();
                if (skipBluetoothService != null) {
                    skipBluetoothService.addOnIBluzDeviceConnectionListener(getBluzDeviceConnectionListener());
                    skipBluetoothService.addOnIBluzDeviceA2dpConnectionListener(getBluzDeviceA2dpConnectionListener());
                    skipBluetoothService.addOnCustomCommandListener(getCustomCommandListener());
                    skipBluetoothService.setBluzConnector();
                }
                refreshA2dpState();
                refreshSppState();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                skipBluetoothService = null;
            }
        };

        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

//    /**
//     * 开启跳绳蓝牙连接service
//     */
//    private void startSkipBluetoothService() {
//        Intent i = new Intent(this, SkipBluetoothService.class);
//        Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --->  startSkipBluetoothService()");
//        startService(i);
//    }

    private SkipBluetoothService.OnIBluzDeviceConnectionListener getBluzDeviceConnectionListener() {
        if (mOnIBluzDeviceConnectionListener == null) {
            mOnIBluzDeviceConnectionListener = new SkipBluetoothService.OnIBluzDeviceConnectionListener() {
                @Override
                public void onConnected(BluetoothDevice device) {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --- > mOnConnectionListener --- > onConnected");
                    sppCheckByProgram(true);
                    //startSkipBluetoothService();
                }

                @Override
                public void onDisconnected(BluetoothDevice device) {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --- > mOnConnectionListener --- > onDisconnected");
                    sppCheckByProgram(false);
                }
            };
        }
        return mOnIBluzDeviceConnectionListener;
    }

    private h getBluzDeviceA2dpConnectionListener() {
        if (a2dpListener == null) {
            a2dpListener = new h() {
                @Override
                public void a() {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --- > getA2dpConnectLister() --- a()");
                }

                @Override
                public void h() {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --- > getA2dpConnectLister() --- h()");
                }

                @Override
                public void a(BluetoothDevice device, int state) {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity --- > aBluetoothDevice  : " + device.getName() + " state : " + state);
                    //if (device != null && !TextUtils.isEmpty(device.getName()) && device.getName().contains("Geekery Rope")) {
                    switch (state) {
                        case 1:
                            showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                            a2dpCheckByProgram(true);
                            break;
                        case 2:
                            //showAppMessage(R.string.bt_connecting, AppMsg.STYLE_INFO);
                            break;
                        case 3:
                            showAppMessage(R.string.a2dp_disconnected, AppMsg.STYLE_INFO);
                            a2dpCheckByProgram(false);
                            break;
                        case 4:
                            showAppMessage(R.string.bt_connect_fail, AppMsg.STYLE_ALERT);
                            break;
                        case 5:
                            showAppMessage("配对中", AppMsg.STYLE_INFO);
                            break;

                    }
                }
                //}
            };
        }
        return a2dpListener;
    }

    private SkipBluetoothService.OnCustomCommandListener getCustomCommandListener() {
        if (mOnCustomCommandListener == null) {
            mOnCustomCommandListener = new SkipBluetoothService.OnCustomCommandListener() {
                @Override
                public void onReady(int i, int i1, int i2, byte[] bytes) {
                    processData(i, i1, i2, bytes);
                }
            };
        }
        return mOnCustomCommandListener;
    }

    /**
     * 设置模式之后的数据处理
     *
     * @param btConnectStatus 蓝牙连接状态
     * @param command         命令  cmd (8bit) + Status (8bit) + Reserve (16bit);
     * @param jumpNumber      跳绳个数  Jump_counter (16bit) +  Num_counter(16bit);
     * @param bytes           当前时间 和 偏移时间值
     */
    private void processData(int btConnectStatus, int command, int jumpNumber, byte[] bytes) {
        if (btConnectStatus == SkipCommandHelper.getSkipDeviceVersionResponseKey()) {//获取当前跳绳的版本号
            if (bytes != null && bytes.length > 0) {
                StringBuilder stringBuilder = new StringBuilder();
                for (byte b : bytes) {
                    char a = (char) b;
                    stringBuilder.append(a);
                }
                Toast.makeText(this, "当前跳绳版本 : " + stringBuilder.toString(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * 解绑跳绳服务
     */
    private void disconnectToSkipBluetoothService() {
        if (skipBluetoothService != null) {
            skipBluetoothService.removeOnIBluzDeviceConnectionListener(mOnIBluzDeviceConnectionListener);
            skipBluetoothService.removeOnCustomCommandListener(mOnCustomCommandListener);
            skipBluetoothService.removeOnIBluzDeviceA2dpConnectionListener();
            skipBluetoothService.removeDiscoveryListener();
        }
        mOnIBluzDeviceConnectionListener = null;
        mOnCustomCommandListener = null;
        onDiscoveryListener = null;
        a2dpListener = null;
        if (serviceConnection != null) {
            unbindService(serviceConnection);
            serviceConnection = null;
        }
    }

    //endregion ====================================== 与SkipService交互相关 ======================================

    /**
     * 刷新状态
     */
    private void refresh() {
        String voiceTypeName = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_NAME, getString(R.string.activity_siri_setting_female_tone));
        String voiceType = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
        if (voiceType.equals("female")) {
            if (tv_siri_set != null)
                tv_siri_set.setText(R.string.activity_siri_setting_female_tone);
        } else {
            if (tv_siri_set != null)
                tv_siri_set.setText(voiceTypeName);
        }

        int defaultSiriRate = PrefsHelper.with(PairSkipActivity.this, Config.PREFS_SPORT).readInt(Config.SY_KEY_SIRI_RATE_SKIP, Config.SY_KEY_SIRI_RATE_SKIP_DEFAULT);
        String array[] = getResources().getStringArray(R.array.skip_siri_mode);
        if (defaultSiriRate == -1) {
            spinner_skip_rate.setSelection(0);
        } else {
            String siriRateString = String.valueOf(defaultSiriRate);
            for (int i = 1; i < array.length; i++) {
                if (array[i].equals(siriRateString)) {
                    spinner_skip_rate.setSelection(i);
                    break;
                }
            }
        }

        refreshA2dpState();
        refreshSppState();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        tv_siri_set = (TextView) findViewById(R.id.tv_siri_set);
        ckb_a2dp_connect = (CheckBox) findViewById(R.id.ckb_a2dp_connect);
        ckb_spp_connect = (CheckBox) findViewById(R.id.ckb_spp_connect);
//        tvSkipMode = (TextView) findViewById(R.id.tv_skip_mode);
//        tvSkipMode.setOnClickListener(this);
//        int ledMode = SettingsHelper.getInt("skip_led_mode", 0);
//        ledMode = ledMode < 0 ? 0 : ledMode > 3 ? 3 : ledMode;
//        tvSkipMode.setText(getResources().getStringArray(R.array.skip_led_mode)[ledMode]);
        spinner_skip_rate = (Spinner) findViewById(R.id.spinner_siri_rate);
        spinner_skip_rate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String array[] = getResources().getStringArray(R.array.skip_siri_mode);
                if (position != 0) {
                    String rate = array[position];
                    int rate_value = Integer.valueOf(rate);
                    PrefsHelper.with(PairSkipActivity.this, Config.PREFS_SPORT).writeInt(Config.SY_KEY_SIRI_RATE_SKIP, rate_value);
                } else {
                    PrefsHelper.with(PairSkipActivity.this, Config.PREFS_SPORT).writeInt(Config.SY_KEY_SIRI_RATE_SKIP, -1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ckb_a2dp_connect.setOnCheckedChangeListener(this);
        ckb_spp_connect.setOnCheckedChangeListener(this);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 52://完成使用我的设备配对一次金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            coinTaskPairBtFinished = true;
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成任务

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 52://设备配对一次金币任务
                    if (bean.getCode() == 9002) {//该任务已完成
                        coinTaskPairBtFinished = true;
                        SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成
                    }
                    break;
            }
        }
    }

//    /**
//     * 设置跳绳灯光模式
//     *
//     * @param position 选择的模式位置
//     */
//    private void setLedMode(int position) {
//        if (position != 2) {
//            if (skipBluetoothService != null) {
//                skipBluetoothService.sendCustomCommand(SkipCommandHelper.getSetLedModeKey(), position + 1);
//            }
//        } else {//如果选择的是激励模式 则需要传递设置的跳频bpm
//            showSkipBpmSelectDialog(position, true);
//        }
//    }

//    /**
//     * 显示操作dialog
//     */
//    private void showSkipBpmSelectDialog(final int position, boolean showBpm) {
//        SkipSelectDialog bpmSelectDialog = new SkipSelectDialog();
//        if (showBpm) {
//            bpmSelectDialog.setCurrentType(SkipSelectDialog.ACTION_BPM);
//        } else {
//            bpmSelectDialog.setCurrentType(SkipSelectDialog.ACTION_MODE);
//        }
//        bpmSelectDialog.setOnActionClickListener(new SkipSelectDialog.ActionTypeClickListener() {
//            @Override
//            public void onBpmSelect(int bpm) {
//                Toast.makeText(PairSkipActivity.this, "设置的激励 bpm : " + bpm, Toast.LENGTH_LONG).show();
//                if (skipBluetoothService != null) {
//                    skipBluetoothService.sendCustomCommand(SkipCommandHelper.getSetLedModeKey(), position + 1, bpm, null);
//                }
//            }
//
//            @Override
//            public void onActionClick(String mode, int position) {
//                setLedMode(position);
//                if (tvSkipMode != null)
//                    tvSkipMode.setText(mode);
//                SettingsHelper.putInt("skip_led_mode", position);
//            }
//        });
//        bpmSelectDialog.show(this.getSupportFragmentManager(), "bpmSelectDialog");
//    }

    /**
     * 设置跳绳的播报频率
     *
     * @param position 选择的频率位置
     */
    private void setSkipRate(int position) {

    }

    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if (mBluetoothAdapter == null) {
            showAppMessage(R.string.bt_not_supported, AppMsg.STYLE_ALERT);
        }
        return mBluetoothAdapter;
    }

    /**
     * 根据蓝牙连接状态刷新界面
     */
    private void refreshA2dpState() {
        if (getSkipBluetoothService() == null) return;
        int state = getBluetoothAdapter()
                .getProfileConnectionState(BluetoothProfile.A2DP);
        switch (state) {
            case BluetoothProfile.STATE_CONNECTED:
                if (a2dpState != state) {
                    connectA2dpDevice();
                    //showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                }
                break;
            case BluetoothProfile.STATE_DISCONNECTED:
            case BluetoothProfile.STATE_DISCONNECTING:
                if (a2dpState != state) {
                    showAppMessage(R.string.a2dp_disconnected, AppMsg.STYLE_INFO);
                    a2dpCheckByProgram(false);
                }
                break;

            case BluetoothProfile.STATE_CONNECTING:
                if (a2dpState != state) {
                    showAppMessage(R.string.bt_connecting, AppMsg.STYLE_INFO);
                }
                break;
        }
        a2dpState = state;
    }

    /**
     * 根据蓝牙连接状态刷新界面
     */
    private void refreshSppState() {
        if (getSkipBluetoothService() == null) return;
        SkipBluetoothService.ConnectionState connectionState = skipBluetoothService.getConnectState();
        if (connectionState == null) return;
        int state = connectionState.getSppState();
        switch (state) {
            case SkipBluetoothService.ConnectionState.SPP_CONNECTED:
                sppCheckByProgram(true);
                break;
            case SkipBluetoothService.ConnectionState.SPP_CONNECTING:
            case SkipBluetoothService.ConnectionState.SPP_DISCONNECTED:
                sppCheckByProgram(false);
                break;
        }
    }

    private void connectA2dpDevice() {
        if (getSkipBluetoothService() != null) {
            Set<BluetoothDevice> bondedDevices = getBluetoothAdapter().getBondedDevices();
            List<BluetoothDevice> bondedDeviceList = new ArrayList<>();
            if (bondedDevices != null) {
                for (BluetoothDevice device : bondedDevices) {
                    if (device != null) {
                        bondedDeviceList.add(device);
                    }
                }
            }
            if (bondedDeviceList.size() > 0 &&
                    bondedDeviceList.get(0).getName() != null && bondedDeviceList.get(0).getName().contains("Geekery Rope")) {
                getSkipBluetoothService().connectBluetoothDeviceByA2dp(null);
                showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                a2dpCheckByProgram(true);
            }
        }
    }

    /**
     * a2dp CheckBox由程序设定值
     *
     * @param isCheck true:选中,false:不选中
     */
    private void a2dpCheckByProgram(boolean isCheck) {
        if (ckb_a2dp_connect != null) {
            checkByMan = false;
            ckb_a2dp_connect.setChecked(isCheck);
            checkByMan = true;
        }
        if (isCheck) {
            SettingsHelper.putBoolean(Config.CONNECTED_SKIP_DEVICE, true);
            if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                finishPairBtCoinTask();
            }
        }
    }

    /**
     * spp CheckBox由程序设定值
     *
     * @param isCheck true:选中,false:不选中
     */
    private void sppCheckByProgram(boolean isCheck) {
        if (ckb_spp_connect != null) {
            checkByMan = false;
            ckb_spp_connect.setChecked(isCheck);
            checkByMan = true;
        }
        if (isCheck) {
            SettingsHelper.putBoolean(Config.CONNECTED_SKIP_DEVICE, true);
            if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                finishPairBtCoinTask();
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (checkByMan) {
            switch (buttonView.getId()) {
                case R.id.ckb_a2dp_connect:
                    if (isChecked) {
                        if (getSkipBluetoothService() != null) {
                            if (getSkipBluetoothService().getSkipSppConnectDevice() != null) {
                                getSkipBluetoothService().connectBluetoothDeviceByA2dp(getSkipBluetoothService().getSkipSppConnectDevice());
                            } else {
                                gotoBluetoothSettings();
                            }
                        }
                    } else {
                        if (getSkipBluetoothService() != null) {
                            if (getSkipBluetoothService().getSkipA2dpLinkDevice() != null) {
                                getSkipBluetoothService().disConnectA2dpDevice(getSkipBluetoothService().getSkipA2dpLinkDevice());
                            }
                        }
                    }
                    a2dpCheckByProgram(!isChecked);
                    break;

                case R.id.ckb_spp_connect:
//                    int state = getBluetoothAdapter()
//                            .getProfileConnectionState(BluetoothProfile.A2DP);

                    if (getSkipBluetoothService() == null) return;
                    //int state = getSkipBluetoothService().getConnectState().getA2dpState();
                    sppCheckByProgram(!isChecked);
                    if (isChecked) {
                        // if (state != BluetoothProfile.STATE_CONNECTED) {
                        //if (state != SkipBluetoothService.ConnectionState.A2DP_CONNECTED) {

                        if (getSkipBluetoothService() != null) {
                            if (getSkipBluetoothService().isEnabled()) {
                                createAlertDialog();
                                getSkipBluetoothService().discoveryBluetoothDevice(getOnDiscoveryListener());
                                getSkipBluetoothService().startDiscovery();
                            } else {//蓝牙没有连接上时,打开系统蓝牙设置界面
                                gotoBluetoothSettings();
                            }
                        }

//                        if (!ckb_a2dp_connect.isChecked()) {
//                            if (getSkipBluetoothService() != null) {
//                                if (getSkipBluetoothService().isEnabled()) {
//                                    createAlertDialog();
//                                    getSkipBluetoothService().discoveryBluetoothDevice(getOnDiscoveryListener());
//                                    getSkipBluetoothService().startDiscovery();
//                                } else {//蓝牙没有连接上时,打开系统蓝牙设置界面
//                                    gotoBluetoothSettings();
//                                }
//                            }
//                        } else {
//                            createAlertDialog();
//                            getBluetoothDevicesAdapter().clearData();
//                            Set<BluetoothDevice> bondedDevices = getBluetoothAdapter().getBondedDevices();
//                            if (bondedDevices != null) {
//                                for (BluetoothDevice device : bondedDevices) {
//                                    if (device != null && device.getBondState() == BluetoothDevice.BOND_BONDED) {
//                                        if (!TextUtils.isEmpty(device.getName())) {
//                                            getBluetoothDevicesAdapter().getBluetoothDeviceList().add(device);
//                                            getBluetoothDevicesAdapter().notifyDataSetChanged();
//                                        }
//                                    }
//                                }
//                            }
//                        }
                    } else {
                        //断开跳绳蓝牙数据连接
                        if (getSkipBluetoothService() != null) {
                            getSkipBluetoothService().disConnectBluetoothDevice();
                        }
                    }
                    break;
                case R.id.ckb_led:
                    break;
            }
        }

    }

    private IBluzDevice.OnDiscoveryListener getOnDiscoveryListener() {
        if (onDiscoveryListener == null) {
            onDiscoveryListener = new IBluzDevice.OnDiscoveryListener() {
                @Override
                public void onConnectionStateChanged(BluetoothDevice bluetoothDevice, int i) {

                }

                @Override
                public void onDiscoveryStarted() {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity ---- > onDiscoveryStarted()");
                    if (progressBar != null) {
                        progressBar.setVisibility(View.VISIBLE);
                    }
                    if (discovery_title != null) {
                        discovery_title.setText("扫描设备中，请稍后...");
                    }
                    getBluetoothDevicesAdapter().clearData();
                    //添加已绑定的设备
                    Set<BluetoothDevice> bondedDevices = getBluetoothAdapter().getBondedDevices();
                    if (bondedDevices != null) {
                        for (BluetoothDevice device : bondedDevices) {
                            if (device != null && device.getBondState() == BluetoothDevice.BOND_BONDED) {
                                if (!TextUtils.isEmpty(device.getName())) {
                                    if (device.getName().startsWith("Geekery Rope")) {
                                        getBluetoothDevicesAdapter().getBluetoothDeviceList().add(device);
                                    }
                                }
                            }
                        }
                    }
                    getBluetoothDevicesAdapter().notifyDataSetChanged();
                }

                @Override
                public void onDiscoveryFinished() {
                    Logger.i(Logger.DEBUG_TAG, "PairSkipActivity ---- > onDiscoveryFinished()");
                    removeDiscoverListener();
                    if (progressBar != null) {
                        progressBar.setVisibility(View.GONE);
                    }
                    if (discovery_title != null) {
                        discovery_title.setText("请选择要连接的跳绳设备");
                    }
                }

                @Override
                public void onFound(BluetoothDevice bluetoothDevice) {
                    if ((bluetoothDevice != null) && !TextUtils.isEmpty(bluetoothDevice.getName()) && bluetoothDevice.getName().equals("Geekery Rope")) {
                        getBluetoothDevicesAdapter().getBluetoothDeviceList().add(bluetoothDevice);
                        getBluetoothDevicesAdapter().notifyDataSetChanged();
                    }
                }
            };
        }
        return onDiscoveryListener;
    }

    private void removeDiscoverListener() {
        if (getSkipBluetoothService() != null) {
            getSkipBluetoothService().removeDiscoveryListener();
        }
    }

    private BluetoothDevicesAdapter bluetoothDevicesAdapter;
    private IBluzDevice.OnDiscoveryListener onDiscoveryListener;
    private MaterialDialog dialog;
    private MaterialProgressBar progressBar;
    private TextView discovery_title;
    private BluetoothDevice bluetoothdevice;

    private void createAlertDialog() {
        View convertView = getLayoutInflater().inflate(R.layout.dialog_bluetooth_list_view, null);
        ListView listView = (ListView) convertView.findViewById(R.id.lv_bluetooth_list);
        progressBar = (MaterialProgressBar) convertView.findViewById(R.id.discovery_progressbar);
        discovery_title = (TextView) convertView.findViewById(R.id.discovery_title);
        listView.setAdapter(getBluetoothDevicesAdapter());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (getSkipBluetoothService() != null) {
                    bluetoothdevice = getBluetoothDevicesAdapter().getBluetoothDeviceList().get(position);
                    if (bluetoothdevice != null)
                        getSkipBluetoothService().connectBluetoothDevice(bluetoothdevice);
                }
                if (dialog != null) {
                    dialog.dismiss();
                }
                getBluetoothDevicesAdapter().clearData();
            }
        });
        dialog = new MaterialDialog.Builder(this)
                .customView(convertView, true)
                .negativeText(R.string.cancel)
                .cancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        getBluetoothDevicesAdapter().clearData();
                        removeDiscoverListener();
                    }
                })
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case NEGATIVE:
                                getBluetoothDevicesAdapter().clearData();
                                removeDiscoverListener();
                                break;
                        }
                    }
                })
                .cancelable(false)
                .show();
    }

    private BluetoothDevicesAdapter getBluetoothDevicesAdapter() {
        if (bluetoothDevicesAdapter == null) {
            bluetoothDevicesAdapter = new BluetoothDevicesAdapter(this);
        }
        return bluetoothDevicesAdapter;
    }

    /**
     * 导航到系统蓝牙设置
     */
    private void gotoBluetoothSettings() {
        Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        if (intent != null && intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_ENABLE_BLUETOOTH);
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_send:
                //TODO 给跳绳传递参数
//                if (skipBluetoothService != null) {
//                    skipBluetoothService.sendCustomCommand(SkipCommandHelper.getSkipDeviceVersionKey(), 1);
//                }
                break;
            case R.id.iv_skip_image:
                if (skipBluetoothService != null) {
                    skipBluetoothService.sendCustomCommand(SkipCommandHelper.getSkipDeviceVersionKey(), 1);
                }
                break;
            case R.id.ll_set_siri:
                Intent intent = new Intent(PairSkipActivity.this, VoiceManagerActivity.class);
                startActivity(intent);
                break;

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_ENABLE_BLUETOOTH == requestCode) {
            Logger.i(Logger.DEBUG_TAG, "resultCode:" + resultCode);
            refreshA2dpState();


        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
//            case R.id.tv_skip_mode:
//                showSkipBpmSelectDialog(-1, false);
//                break;

        }
    }

    //region  ============================= 金币任务 =============================

    /**
     * 完成使用我的设备配对一次任务
     */
    private void finishPairBtCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_PAIRING_BT, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion ============================= 金币任务 =============================
}
