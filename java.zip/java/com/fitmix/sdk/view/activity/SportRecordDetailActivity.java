package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStub;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateJsonInfo;
import com.fitmix.sdk.bean.RunDataInfo;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.RunStepInfo;
import com.fitmix.sdk.bean.TrailInfo;
import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.common.maps.AMapHelper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.database.WatchSportRecord;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.task.SyncRunRecordTask;
import com.fitmix.sdk.view.adapter.FragmentViewPagerAdapter;
import com.fitmix.sdk.view.bean.RunPaceListItemInfo;
import com.fitmix.sdk.view.fragment.DataFragment;
import com.fitmix.sdk.view.fragment.GraphFragment;
import com.fitmix.sdk.view.fragment.TrackFragment;
import com.fitmix.sdk.view.fragment.WatchGraphFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.GiftRainView;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.bean.WatchGraph;
import com.fitmix.sdk.watch.bean.WatchPressureLog;
import com.fitmix.sdk.watch.bean.WatchSportLog;
import com.fitmix.sdk.watch.bean.WatchTemperatureLog;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.lang.ref.WeakReference;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class SportRecordDetailActivity extends BaseActivity implements TrackFragment.TrackFragmentCallback {

    private ViewStub viewStub_indoor, viewStub_outdoor;
    private ViewPager viewpager_indoor, viewpager_outdoor;
    private FragmentViewPagerAdapter adapter_indoor, adapter_outdoor;
    //记录当前Fragment
    private int mCurrentFragment = 0;
    private GraphFragment graphFragment;
    private WatchGraphFragment watchGraphFragment;
    private DataFragment dataFragment;
    private TrackFragment trackFragment;
    private RadioGroup radioGroup_indoor, radioGroup_outdoor;
    private RadioButton radioButton_data_indoor, radioButton_graph_indoor,
            radioButton_track_outdoor, radioButton_data_outdoor, radioButton_graph_outdoor;
    private GiftRainView giftRainView;

    private List<TrailInfo> mTrailInfoList;//轨迹点信息集合
    private List<RunStepInfo> mRunStepList;//步数信息集合

    private List<WatchTemperatureLog> mWatchTemperatureLogList;//手表温度记录集合
    private List<WatchPressureLog> mWatchPressureLogList;//手表压强记录集合

    private int mUid;//乐享动uid
    private long mStartTime;//运动记录开始时间,时间戳
    private int height = 0;//用户身高,单位为厘米
    private int gender = 0;//用户性别,1:男,2:女
    //    private int age = 0;//用户年龄
    private RunLogInfo runLog;//乐享动app产生的记录
    private WatchSportLog mWatchSportLog;//手表产生的记录

    private int dataSource;//数据来源 0:乐享动app,1:手表产生
    /**
     * 本地轨迹文件路径
     */
    private String trailFilename;
    /**
     * 本地计步文件路径
     */
    private String stepFileName;
    /**
     * 本地压强文件路径
     */
    private String pressureFileName;
    /**
     * 本地温度文件路径
     */
    private String tempFileName;
    /**
     * 保存到本地的手表运动记录文件压缩文件名
     */
    private String watchLocalZipFile;
    private long enterTime;//页面停留时长,友盟u-d plus统计用到
    private DownloadService mService;
    private DownloadInfoListener downloadListener;
    private ServiceConnection serviceConnection;

    /**
     * 是否从RunMainActivity导航过来
     */
    private boolean fromRunMain = false;
    private int environment;//1:室外,2:室内
    private View outdoor_view, indoor_view;

    private MyHandler mHandler = new MyHandler(this);//记录上传UI提示回调
    private int watchSportType;

    private MenuItem mShareMenu;//分享menu,室外运动时,只有显示TrackFragment时才显示此菜单,防止分享没有轨迹截图
    private String pace;
    private DataFragment.DataFragmentViewModel viewModel;

    public static class MyHandler extends Handler {
        private WeakReference<SportRecordDetailActivity> mActivity;

        public MyHandler(SportRecordDetailActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            if (mActivity != null && mActivity.get() != null) {
                SportRecordDetailActivity activity = mActivity.get();
                if (activity != null) {
                    int resultCode = msg.arg1;
                    long startTime = 0;
                    if (msg.obj != null) {
                        startTime = (long) msg.obj;
                    }
                    activity.handleUploadRecord(resultCode, startTime);
                }
            }
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport_record_detail);
        setPageName("SportRecordDetailActivity");
        clear();
        enterTime = System.currentTimeMillis();
        Intent intent = getIntent();
        if (intent == null) {
            showAppMessage(R.string.activity_run_record_invalid_record, AppMsg.STYLE_ALERT);
            finish();
            return;
        }
        mUid = intent.getIntExtra("uid", 0);
        mStartTime = intent.getLongExtra("startTime", 0);
        if (mUid <= 0 || mStartTime <= 0) {//记录有效性判断
            showAppMessage(R.string.activity_run_record_invalid_record, AppMsg.STYLE_ALERT);
            finish();
            return;
        }
        pace = intent.getStringExtra("pace");
        Logger.d(Logger.DEBUG_TAG, "onCreate pace:" + pace);
        environment = intent.getIntExtra("environment", 1);
        dataSource = intent.getIntExtra("dataSource", 0);
        watchSportType = intent.getIntExtra("watchSportType", 0);
        fromRunMain = intent.getBooleanExtra("fromRunMain", false);
        trailFilename = Config.PATH_DOWN_TRAIL + mUid + "_" + mStartTime + ".json";
        stepFileName = Config.PATH_DOWN_STEP + mUid + "_" + mStartTime + ".step";
        watchLocalZipFile = Config.PATH_LOCAL_TEMP + mUid + "_" + mStartTime + ".zip";
        pressureFileName = Config.PATH_WATCH_LOG_DATA + mUid + "_" + mStartTime + Config.PATH_SENSOR_PRESSURE_END;
        tempFileName = Config.PATH_WATCH_LOG_DATA + mUid + "_" + mStartTime + Config.PATH_SENSOR_TEMPERATURE_END;
        initToolbar();
        initViews();

        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            bindDownloadService();
            getRunRecordFromDb(mUid, mStartTime);
        } else {
            if (permissionIsGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                bindDownloadService();
                getRunRecordFromDb(mUid, mStartTime);
            } else {
                getPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);//申请写存储器权限
            }
        }
        refreshTitle();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        if (1 == environment) {//室外
            initAppOutdoorView();
        } else if (2 == environment) {//室内
            initAppIndoorView();
        } else {
            finish();
        }

        giftRainView = (GiftRainView) findViewById(R.id.gift_rain_view);
    }

    private void initAppIndoorView() {
        viewStub_indoor = (ViewStub) findViewById(R.id.viewStub_indoor);
        indoor_view = viewStub_indoor.inflate();

        radioGroup_indoor = (RadioGroup) indoor_view.findViewById(R.id.radioGroup_indoor);
        radioButton_data_indoor = (RadioButton) indoor_view.findViewById(R.id.radioButton_data_indoor);
        radioButton_graph_indoor = (RadioButton) indoor_view.findViewById(R.id.radioButton_graph_indoor);
        viewpager_indoor = (ViewPager) indoor_view.findViewById(R.id.viewpager_run_record_indoor);
        List<Fragment> fragments = new ArrayList<>();
        dataFragment = new DataFragment();
        graphFragment = new GraphFragment();
        fragments.add(dataFragment);
        if (0 == dataSource) {//乐享动
            graphFragment = new GraphFragment();
            fragments.add(graphFragment);
        } else if (1 == dataSource) {//手表
            watchGraphFragment = new WatchGraphFragment();
            fragments.add(watchGraphFragment);
        }
        adapter_indoor = new FragmentViewPagerAdapter(getSupportFragmentManager(), fragments);
        viewpager_indoor.setAdapter(adapter_indoor);
        viewpager_indoor.setCurrentItem(mCurrentFragment);
        viewpager_indoor.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //不处理
            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        radioButton_data_indoor.setChecked(true);
                        break;
                    case 1:
                        radioButton_graph_indoor.setChecked(true);
                        break;

                }
                mCurrentFragment = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                //不处理
            }
        });

        radioGroup_indoor.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (ftCanCommit) {
                    getSupportFragmentManager().popBackStackImmediate();
                }
                int checkedItem = 0;
                switch (checkedId) {
                    case R.id.radioButton_data_indoor:
                        checkedItem = 0;
                        break;
                    case R.id.radioButton_graph_indoor:
                        checkedItem = 1;
                        break;
                }
                mCurrentFragment = checkedItem;
                viewpager_indoor.setCurrentItem(checkedItem);
            }
        });
    }

    private void initAppOutdoorView() {
        viewStub_outdoor = (ViewStub) findViewById(R.id.viewStub_outdoor);
        outdoor_view = viewStub_outdoor.inflate();
        radioGroup_outdoor = (RadioGroup) outdoor_view.findViewById(R.id.radioGroup_outdoor);
        radioButton_data_outdoor = (RadioButton) outdoor_view.findViewById(R.id.radioButton_data_outdoor);
        radioButton_track_outdoor = (RadioButton) outdoor_view.findViewById(R.id.radioButton_trail_outdoor);
        radioButton_graph_outdoor = (RadioButton) outdoor_view.findViewById(R.id.radioButton_graph_outdoor);
        viewpager_outdoor = (ViewPager) outdoor_view.findViewById(R.id.viewpager_run_record_outdoor);
        List<Fragment> fragments = new ArrayList<>();
        trackFragment = new TrackFragment();
        trackFragment.setFragmentCallback(this);
        dataFragment = new DataFragment();

        fragments.add(trackFragment);
        fragments.add(dataFragment);
        if (0 == dataSource) {//乐享动
            graphFragment = new GraphFragment();
            fragments.add(graphFragment);
        } else if (1 == dataSource) {//手表
            watchGraphFragment = new WatchGraphFragment();
            fragments.add(watchGraphFragment);
        }

        adapter_outdoor = new FragmentViewPagerAdapter(getSupportFragmentManager(), fragments);
        viewpager_outdoor.setAdapter(adapter_outdoor);
        viewpager_outdoor.setCurrentItem(mCurrentFragment);
        viewpager_outdoor.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //不处理
            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        radioButton_track_outdoor.setChecked(true);
                        if (trackFragment != null) {
                            trackFragment.showTrailTrack();
                        }
                        if (mShareMenu != null) {
                            mShareMenu.setVisible(true);
                        }
                        break;
                    case 1:
                        radioButton_data_outdoor.setChecked(true);
                        if (mShareMenu != null) {
                            mShareMenu.setVisible(false);
                        }
                        break;
                    case 2:
                        radioButton_graph_outdoor.setChecked(true);
                        if (mShareMenu != null) {
                            mShareMenu.setVisible(false);
                        }
                        break;
                }
                mCurrentFragment = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                //不处理
            }
        });

        radioGroup_outdoor.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                Logger.d(Logger.DEBUG_TAG, "SportRecordDetailActivity-->onCheckedChanged checkedId:" + checkedId);
                if (ftCanCommit) {
                    getSupportFragmentManager().popBackStackImmediate();
                }
                int checkedItem = 0;
                switch (checkedId) {
                    case R.id.radioButton_trail_outdoor:
                        checkedItem = 0;
                        break;
                    case R.id.radioButton_data_outdoor:
                        checkedItem = 1;
                        break;
                    case R.id.radioButton_graph_outdoor:
                        checkedItem = 2;
                        break;
                }
                mCurrentFragment = checkedItem;
                viewpager_outdoor.setCurrentItem(checkedItem);
            }
        });

    }

    /**
     * 设置界面标题
     */
    private void refreshTitle() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(mStartTime);
        String sportType = getResources().getString(R.string.run_type);
        if (0 == dataSource) {
            if (1 == environment) {
                sportType = getResources().getString(R.string.outdoors_run);
            } else {
                sportType = getResources().getString(R.string.indoors_run);
            }
        } else {
            if (WatchDataProtocol.SPORTS_TYPE_RUN_OUTDOOR == watchSportType) {//室外跑
                sportType = getResources().getString(R.string.outdoors_run);
            } else if (WatchDataProtocol.SPORTS_TYPE_RUN_INDOOR == watchSportType) {//室内跑
                sportType = getResources().getString(R.string.indoors_run);
            } else if (WatchDataProtocol.SPORTS_TYPE_WALK == watchSportType) {//徒步
                sportType = getResources().getString(R.string.on_foot);
            } else if (WatchDataProtocol.SPORTS_TYPE_MOUNTAINS_CLIMB == watchSportType) {//爬山 登山
                sportType = getResources().getString(R.string.climb);
            } else if (WatchDataProtocol.SPORTS_TYPE_RIDE_CROSSCOUNTRY == watchSportType) {//山地车
                sportType = getResources().getString(R.string.cycling_mountain);
            } else if (WatchDataProtocol.SPORTS_TYPE_RIDE == watchSportType) {//公路车
                sportType = getResources().getString(R.string.cycling);
            }else if (WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR == watchSportType){//室内游泳
                sportType = getResources().getString(R.string.swimming_pool);
            }else if (WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR == watchSportType){//室外游泳
                sportType = getResources().getString(R.string.public_waters);
            }else if (WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB == watchSportType){//攀岩
                sportType = getResources().getString(R.string.rock_climbing);
            }
        }

        String sTitle = String.format("%s %04d/%02d/%02d", sportType,
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
        setUiTitle(sTitle);
    }

    /**
     * 从数据库中获取跑步记录
     */
    private void getRunRecordFromDb(final int uid, long startTime) {
        if (dataSource == 1) {//手表产生的记录
            WatchSportDataHelper.asyncGetRecords(this, uid, startTime, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    final WatchSportRecord watchSportRecord = (WatchSportRecord) operation.getResult();
                    if (watchSportRecord != null) {
                        mWatchSportLog = new WatchSportLog();
                        mWatchSportLog.setUid(watchSportRecord.getUid());//用户ID
                        mWatchSportLog.setStartTime(watchSportRecord.getStartTime());//运动开始时间戳
                        mWatchSportLog.setSportType(watchSportRecord.getSportType());//运动类型，与枚举对应
                        Logger.d(Logger.DEBUG_TAG, "detailActivity runTime:" + watchSportRecord.getSportDuration());
                        mWatchSportLog.setSportDuration(watchSportRecord.getSportDuration());//运动持续时长,单位为秒
                        Logger.d(Logger.DEBUG_TAG, "detailActivity realRunTime:" + watchSportRecord.getSportTime());
                        mWatchSportLog.setRealSportTime(watchSportRecord.getSportTime());//真正运动时长,单位为秒
                        String pause = watchSportRecord.getPauseDetail();
                        if (pause != null) {
                            List<WatchSportLog.SportPauseDetail> pauseDetail = JsonHelper.getList(pause, new TypeToken<List<WatchSportLog.SportPauseDetail>>() {
                            }.getType());
                            mWatchSportLog.setPause_detail(pauseDetail);
                        }

                        mWatchSportLog.setTotalCalorie(watchSportRecord.getCalorie());//运动卡路里
                        mWatchSportLog.setFatBurst(watchSportRecord.getFatBurn());//脂肪燃烧克数
                        mWatchSportLog.setLactateThreshold(watchSportRecord.getLactateThreshold());//乳酸阈值
                        mWatchSportLog.setMaxSportHR(watchSportRecord.getMaxSportHR());//最大运动心率
                        mWatchSportLog.setAvgSportHR(watchSportRecord.getAvgSportHR());//平均运动心率
                        mWatchSportLog.setMaxHR(watchSportRecord.getMaxHR());//最大心率,画图表用
                        mWatchSportLog.setRestHR(watchSportRecord.getRestHR());//静息心率,画图表用
                        String hrStat = watchSportRecord.getHrStatistics();
                        if (hrStat != null) {
                            List<WatchSportLog.HrStatistic> hr = JsonHelper.getList(hrStat, new TypeToken<List<WatchSportLog.HrStatistic>>() {
                            }.getType());
                            mWatchSportLog.setHrStatistics(hr);
                        }
                        mWatchSportLog.setTotalDistance(watchSportRecord.getDistance());//运动距离,单位为米
                        mWatchSportLog.setTotalSteps(watchSportRecord.getStep());//运动步数
                        mWatchSportLog.setMaxPace(watchSportRecord.getMaxPace());//最高配速,单位为秒
                        mWatchSportLog.setMaxFrequency(watchSportRecord.getMaxFrequency());//最快步频
                        mWatchSportLog.setTotalDown(watchSportRecord.getTotalDown());//下降高度
                        mWatchSportLog.setTotalUp(watchSportRecord.getTotalUp());//上升高度
                        mWatchSportLog.setPeakAltitude(watchSportRecord.getPeakAltitude());//峰值海拔
                        mWatchSportLog.setTroughAltitude(watchSportRecord.getTroughAltitude());//波谷海拔
                        String groupRecord = watchSportRecord.getGroupRecord();
                        if (groupRecord != null) {//运动分组记录
                            List<WatchSportLog.SportGroupRecord> group = JsonHelper.getList(groupRecord, new TypeToken<List<WatchSportLog.SportGroupRecord>>() {
                            }.getType());
                            mWatchSportLog.setGroupRecords(group);
                        }

                        mWatchSportLog.setRunPower(watchSportRecord.getRunPower());//跑力
                        mWatchSportLog.setRidePower(watchSportRecord.getRidePower());//骑行功率

                        mWatchSportLog.setSwimPoolLength(watchSportRecord.getSwimPoolLength());//泳池长度
                        mWatchSportLog.setSwimStyle(watchSportRecord.getSwimStyle());//泳姿
                        mWatchSportLog.setSwimTrips(watchSportRecord.getSwimTrips());//往返次数

                        mWatchSportLog.setStartAltitude(watchSportRecord.getStartAltitude());//开始海拔
                        mWatchSportLog.setStartPressure(watchSportRecord.getStartPressure());//开始气压
                        mWatchSportLog.setStartTemperature(watchSportRecord.getStartTemperature());//开始温度
                        mWatchSportLog.setZipFile(watchSportRecord.getZipFile());//运动记录对应的文件压缩包下载地址
                        String other = watchSportRecord.getOther();
                        if (other != null) {
                            WatchSportLog.WatchSportLogSup sup = JsonHelper.getObject(other, WatchSportLog.WatchSportLogSup.class);
                            mWatchSportLog.setOther(sup);
                        }

                        //加载完成后,初始化地图
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                downloadGraphData();
                                if (isOutDoor()) {
                                    if (mCurrentFragment == 0) {
                                        if (trackFragment != null) {
                                            TrackFragment.TrackFragmentViewModel viewModel = new TrackFragment.TrackFragmentViewModel();
                                            viewModel.setUid(mWatchSportLog.getUid());
                                            viewModel.setStartTime(mWatchSportLog.getStartTime());
                                            viewModel.setDuration(mWatchSportLog.getSportDuration());
                                            viewModel.setRealSportTime(mWatchSportLog.getRealSportTime());
                                            viewModel.setDistance(mWatchSportLog.getTotalDistance());
                                            if (TextUtils.isEmpty(pace)){
                                                viewModel.setPace(FormatUtil.formatSpeed(mWatchSportLog.getTotalDistance(),mWatchSportLog.getSportDuration()));
                                            }else {
                                                viewModel.setPace(pace);
                                            }
                                            if (mWatchSportLog.getSportType() == WatchDataProtocol.SPORTS_TYPE_RUN_INDOOR) {
                                                viewModel.setEnvironment(2);
                                            } else {
                                                viewModel.setEnvironment(1);
                                                viewModel.setWatchSportType(mWatchSportLog.getSportType());
                                                viewModel.setPeakAltitude(mWatchSportLog.getPeakAltitude());
                                            }
                                            trackFragment.setViewModel(viewModel);
                                        }
                                    }
                                }

                                if (dataFragment != null) {
                                    if (viewModel == null)
                                        viewModel = new DataFragment.DataFragmentViewModel();

                                    String altitudeFile = Config.PATH_WATCH_LOG_DATA + mUid + "_" +
                                            mStartTime + Config.ALTITUDE_CHART_SUFFIX;
                                    String altitudeCon = FileUtils.readFileContent(altitudeFile);
                                    WatchGraph altitudeGraph = JsonHelper.getObject(altitudeCon, WatchGraph.class);
                                    if (altitudeGraph != null) {//海拔除以10
                                        float avg = altitudeGraph.getAvg() / 10.0f;
                                        viewModel.setAverageAltitude(avg);
                                    }

                                    viewModel.setPeakAltitude(mWatchSportLog.getPeakAltitude());
                                    viewModel.setTroughAltitude(mWatchSportLog.getTroughAltitude());
                                    viewModel.setTotalDown(mWatchSportLog.getTotalDown());
                                    viewModel.setTotalUp(mWatchSportLog.getTotalUp());
                                    viewModel.setWatchSportType(mWatchSportLog.getSportType());
                                    viewModel.setMaxPace(mWatchSportLog.getMaxPace());
                                    viewModel.setUid(mWatchSportLog.getUid());
                                    viewModel.setStartTime(mWatchSportLog.getStartTime());
                                    viewModel.setDuration(mWatchSportLog.getSportDuration());
                                    viewModel.setRealSportDuration(mWatchSportLog.getRealSportTime());
                                    viewModel.setDistance(mWatchSportLog.getTotalDistance());
                                    viewModel.setSwimPoolLength(mWatchSportLog.getSwimPoolLength());
                                    viewModel.setSwimTrips(mWatchSportLog.getSwimTrips());
                                    viewModel.setSwimStyle(mWatchSportLog.getSwimStyle());
                                    if (mWatchSportLog.getSportType() == WatchDataProtocol.SPORTS_TYPE_RUN_INDOOR) {
                                        viewModel.setEnvironment(2);
                                    } else {
                                        viewModel.setEnvironment(1);
                                    }
                                    viewModel.setCalorie(mWatchSportLog.getTotalCalorie());
                                    viewModel.setStep(mWatchSportLog.getTotalSteps());
                                    if (watchSportRecord.getSportTime() > 0) {
                                        int bpm = (int) (mWatchSportLog.getTotalSteps() * 60 / watchSportRecord.getSportTime());
                                        viewModel.setBpm(bpm);
                                    }
                                    viewModel.setGroupRecords(mWatchSportLog.getGroupRecords());//运动分组记录

                                    viewModel.setFatBurn(mWatchSportLog.getFatBurst());
                                    List<WatchSportLog.HrStatistic> hrStatistics = mWatchSportLog.getHrStatistics();
                                    if (hrStatistics != null && hrStatistics.size() == 5) {//心率统计
                                        UserHeartRate userHeartRate = new UserHeartRate();
                                        userHeartRate.setWarmNum((int) hrStatistics.get(0).getTime());//热身
                                        userHeartRate.setFatBurningNum((int) hrStatistics.get(1).getTime());//燃脂
                                        userHeartRate.setAerobicNum((int) hrStatistics.get(2).getTime());//有氧
                                        userHeartRate.setAnaerobicNum((int) hrStatistics.get(3).getTime());//无氧
                                        userHeartRate.setMaxNum((int) hrStatistics.get(4).getTime());//最大
                                        userHeartRate.setHeartRateAvg(mWatchSportLog.getAvgSportHR());//平均心率
                                        viewModel.setUserHeartRate(userHeartRate);
                                    }

                                    List<RunPaceListItemInfo> runPaceListItemInfoList = getPaceListArray();
                                    if (runPaceListItemInfoList != null && runPaceListItemInfoList.size() > 0) {
                                        viewModel.setRunPaceListItemInfoList(runPaceListItemInfoList);
                                    }else {
                                        setStepData();
                                    }

                                    dataFragment.setViewModel(viewModel);

                                }

                                if (mWatchSportLog != null) {
                                    DecimalFormat df1 = new DecimalFormat("0.00");
                                    DecimalFormat df2 = new DecimalFormat("0.0");

                                    double ftDistance1 = Double.parseDouble(df1.format(mWatchSportLog.getTotalDistance() / 1000D));
                                    double ftDistance2 = Double.parseDouble(df2.format(mWatchSportLog.getTotalDistance() / 1000D));
                                    if (0.25 == ftDistance1 || 2.50 == ftDistance2 || 12.25 == ftDistance1 || 25 == mWatchSportLog.getTotalDistance() / 1000) {
                                        if (giftRainView != null) {
                                            mHandler.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    giftRainView.setImages(R.drawable.candy, R.drawable.suger, R.drawable.red_tree,
                                                            R.drawable.green_tree, R.drawable.gift);
                                                    giftRainView.setDuration(5000);
                                                    giftRainView.startRain();
                                                }
                                            }, 700);
                                        }
                                    }
                                }

                                getWatchPressureLogList();
                                getWatchTempLogList();
                            }
                        });
                    }
                }
            });
        } else {
            SportRecordsHelper.asyncGetRunRecords(this, uid, startTime, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    SportRecord sportRecord = (SportRecord) operation.getResult();
                    if (sportRecord != null) {
                        runLog = new RunLogInfo();
                        runLog.setUid(sportRecord.getUid());
                        runLog.setStartTime(sportRecord.getStartTime());
                        runLog.setMode(environment);
                        runLog.setEndTime(sportRecord.getEndTime());
                        runLog.setType(sportRecord.getType());//运动类型0,1:乐享动app跑步,2:跳绳,3:手表
                        runLog.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                        runLog.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                        runLog.setLocationType(sportRecord.getLocationType());//定位类型,1:GPS定位,2:LBS定位
                        runLog.setDistance(sportRecord.getDistance());//运动距离,单位米
                        runLog.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                        runLog.setStartLat(sportRecord.getStartLat());//开始点经度
                        runLog.setStartLng(sportRecord.getStartLng());//开始点经度
                        runLog.setEndLat(sportRecord.getEndLat());//结束点纬度
                        runLog.setEndLng(sportRecord.getEndLng());//结束点经度
                        runLog.setStep(sportRecord.getStep());//步数
                        runLog.setCalorie(sportRecord.getCalorie());//卡路里
                        runLog.setStepData(sportRecord.getStepData());//计步文件下载url
                        runLog.setTrail(sportRecord.getTrail());//轨迹文件下载url
                        runLog.setUploaded(sportRecord.getUploaded());
                        runLog.setBpmMatch(sportRecord.getBpmMatch() == null ? 0 : sportRecord.getBpmMatch());//步数是否异常,-2表示异常
                        if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {
                            runLog.setHeartRateDate(sportRecord.getHeartRateDate());//心率data
                        } else {
                            Logger.e(Logger.DEBUG_TAG, "RunRecordActivity-->getRunRecordFromDb(),heartRateData==null ,startTime==" + sportRecord.getStartTime());
                        }
                        runLog.setConsumeFat(sportRecord.getConsumeFat() == null ? 0 : sportRecord.getConsumeFat());//燃脂量
                        runLog.setElevation(sportRecord.getElevation() == null ? 0 : sportRecord.getElevation());//累积爬升
                        //加载完成后,初始化地图
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (fromRunMain) {//上传记录
                                    uploadRunLog();
                                }

                                if (isOutDoor()) {
                                    if (mCurrentFragment == 0) {
                                        if (trackFragment != null) {//轨迹界面
                                            TrackFragment.TrackFragmentViewModel viewModel = new TrackFragment.TrackFragmentViewModel();
                                            viewModel.setUid(runLog.getUid());
                                            viewModel.setStartTime(runLog.getStartTime());
                                            viewModel.setDuration(runLog.getRunTime() / 1000);
                                            viewModel.setRealSportTime(runLog.getRealRunTime() / 1000);
                                            viewModel.setDistance(runLog.getDistance());
                                            if (TextUtils.isEmpty(pace)){
                                                viewModel.setPace(FormatUtil.formatSpeed(runLog.getDistance(),runLog.getRunTime() / 1000));
                                            }else {
                                                viewModel.setPace(pace);
                                            }
                                            viewModel.setEnvironment(runLog.getMode());
                                            trackFragment.setViewModel(viewModel);
                                        }
                                    }
                                }
                                downloadGraphData();
                                if (dataFragment != null) {//数据界面
                                    if (viewModel == null)
                                        viewModel = new DataFragment.DataFragmentViewModel();
                                    viewModel.setUid(runLog.getUid());
                                    viewModel.setStartTime(runLog.getStartTime());
                                    viewModel.setDuration(runLog.getRunTime() / 1000);
                                    viewModel.setDistance(runLog.getDistance());
                                    viewModel.setEnvironment(runLog.getMode());
                                    viewModel.setCalorie(runLog.getCalorie());
                                    viewModel.setStep(runLog.getStep());
                                    viewModel.setBpm(runLog.getBpm());
                                    viewModel.setFatBurn(runLog.getConsumeFat());
                                    String hrStr = runLog.getHeartRateDate();
                                    if (hrStr != null) {
                                        UserHeartRate userHeartRate = JsonHelper.getObject(hrStr, UserHeartRate.class);
                                        viewModel.setUserHeartRate(userHeartRate);
                                    }

                                    List<RunPaceListItemInfo> runPaceListItemInfoList = getPaceListArray();
                                    if (runPaceListItemInfoList != null && runPaceListItemInfoList.size() > 0) {
                                        viewModel.setRunPaceListItemInfoList(runPaceListItemInfoList);
                                    }

                                    dataFragment.setViewModel(viewModel);
                                }

                                if (getRunLog() != null) {
                                    DecimalFormat df1 = new DecimalFormat("0.00");
                                    DecimalFormat df2 = new DecimalFormat("0.0");

                                    double ftDistance1 = Double.parseDouble(df1.format(getRunLog().getDistance() / 1000D));
                                    double ftDistance2 = Double.parseDouble(df2.format(getRunLog().getDistance() / 1000D));
                                    if (0.25 == ftDistance1 || 2.50 == ftDistance2 || 12.25 == ftDistance1 || 25 == getRunLog().getDistance() / 1000) {
                                        if (giftRainView != null) {
                                            mHandler.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    giftRainView.setImages(R.drawable.candy, R.drawable.suger, R.drawable.red_tree,
                                                            R.drawable.green_tree, R.drawable.gift);
                                                    giftRainView.setDuration(5000);
                                                    giftRainView.startRain();
                                                }
                                            }, 700);
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
            });
        }
    }

    /**
     * 获取运动记录对应的用户uid
     */
    public int getUid() {
        return mUid;
    }

    /**
     * 获取运动记录开始时间
     */
    public long getStartTime() {
        return mStartTime;
    }

    /**
     * @return 是否室外模式
     */
    private boolean isOutDoor() {
        return environment == 1;
    }

    private void clear() {
        trailFilename = null;
        stepFileName = null;
        adapter_outdoor = null;
        adapter_indoor = null;
        viewpager_outdoor = null;
        viewpager_indoor = null;
        pressureFileName = null;
        tempFileName = null;
    }

    /**
     * 获取乐享动app产生的运动记录
     */
    public RunLogInfo getRunLog() {
        return runLog;
    }

    /**
     * 获取用户身高,单位为厘米
     */
    public int getHeight() {
        if (height <= 0) {
            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        }
        return height;
    }

    /**
     * 获取用户性别,1:男,2:女
     */
    public int getGender() {
        if (gender == 0) {
            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        }
        return gender;
    }

//    /**
//     * 获取用户年龄
//     */
//    private int getAge() {
//        if (age == 0) {
//            age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
//        }
//        return age;
//    }

    /**
     * 获取当前运动详情界面展示的数据来源 0:乐享动app,1:手表产生
     */
    public int getDataSource() {
        return dataSource;
    }

    /**
     * 处理上传跑步记录回调
     *
     * @param resultCode 同步结果
     * @param startTime  运动开始时间,用作运动记录编号
     */
    private void handleUploadRecord(int resultCode, long startTime) {
        if (resultCode == 404 || startTime == 0) {
            showAppMessage(R.string.activity_runmain_add_record_fail, AppMsg.STYLE_ALERT);
            return;
        }

        if (getRunLog() != null && getRunLog().getStartTime() == startTime) {
            if (resultCode == 0 || resultCode == 4003) {//同步成功后,更新同步状态
                getRunLog().setUploaded(1);
                showAppMessage(R.string.activity_runmain_add_record_success, AppMsg.STYLE_INFO);
            } else {
                showAppMessage(R.string.activity_runmain_add_record_fail, AppMsg.STYLE_ALERT);
            }
        }
    }

    /**
     * 上传运动记录
     */
    public void uploadRunLog() {
        if (getRunLog() == null) return;
        Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->uploadRunLog stepFileName:" + stepFileName
                + "\nisStepFileCompleted:" + FileUtils.isStepFileCompleted(stepFileName));

        //记录上传方式改为task方式,防止界面销毁后不再更新同步状态
        Toast.makeText(SportRecordDetailActivity.this, R.string.activity_runmain_add_record_busy, Toast.LENGTH_SHORT).show();
        ThreadManager.executeOnNetWorkThread(new SyncRunRecordTask(getRunLog(), mHandler));
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 61://完成每日分享运动记录金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_RECORD, System.currentTimeMillis());//设置完成任务时间
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        //不处理
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_run_record, menu);
        mShareMenu = menu.findItem(R.id.menu_share_record);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://返回
                if (fromRunMain) {
                    Intent intent = new Intent(this, SportRecordActivity.class);
                    startActivity(intent);
                    finish();
                    overridePendingTransition(R.anim.push_right_in, R.anim.push_right_out);
                } else {
                    finish();
                }
                break;

            case R.id.menu_share_record://分享记录
                if (isOutDoor()) {
                    if (mCurrentFragment == 0) {
                        if (trackFragment != null) {
                            trackFragment.onTrailAnimEndAndShare();
                        }
                    } else {
                        gotoShareActivity();
                    }
                } else {
                    gotoShareActivity();
                }
                break;
        }
        return true;
    }

    /**
     * 导航到运动记录分享界面
     */
    private void gotoShareActivity() {
        //区分是手表产生的记录还是app产生的
        if (dataSource == 1) {//手表产生
            if (mWatchSportLog == null)
                return;
            //V2.3.8版本以后图片分享方式
            Intent intent = new Intent(this, ShareActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("uid", mWatchSportLog.getUid());
            bundle.putLong("startTime", mWatchSportLog.getStartTime());
            bundle.putInt("environment", environment);
            bundle.putInt("dataSource", dataSource);
            bundle.putDouble("totalUp", mWatchSportLog.getTotalUp());//累计爬升

            //手表登山相关数据
            bundle.putFloat("highValue", mWatchSportLog.getPeakAltitude());//最高海拔

            //手表骑行相关数据
            int maxPace = mWatchSportLog.getMaxPace();
            if (maxPace != 0) {
                String maxSpeed = FormatUtil.getTwoPointsNumber(1.0d / (maxPace / 3600.0d));
                bundle.putString("maxSpeed", maxSpeed);//最高时速
            } else {
                bundle.putString("maxSpeed", "0.00");//最高时速
            }
            if (mWatchSportLog.getTotalDistance() >0){
                String avgSpeed = FormatUtil.getTwoPointsNumber(mWatchSportLog.getTotalDistance() / 1000.0d / (mWatchSportLog.getRealSportTime() / 3600.0d));
                bundle.putString("avgSpeed",avgSpeed);
            }else {
                bundle.putString("avgSpeed","0.00");
            }
            bundle.putDouble("totalDown", mWatchSportLog.getTotalDown());//累计下降
            bundle.putDouble("fatBurn",mWatchSportLog.getFatBurst());
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            if (getRunLog() == null) return;
            //V2.3.8版本以后图片分享方式
            Intent intent = new Intent(this, ShareActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("uid", getRunLog().getUid());
            bundle.putLong("startTime", getRunLog().getStartTime());
            bundle.putInt("environment", getRunLog().getMode());
            bundle.putInt("dataSource", dataSource);

            intent.putExtras(bundle);
            startActivity(intent);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putLong("startTime", mStartTime);
        savedInstanceState.putInt("uid", mUid);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        long duration = System.currentTimeMillis() - enterTime;
        UmengAnalysisHelper.getInstance().runRecordDuration(this, duration);//统计记录详情界面停留时长

        unbindDownloadService();

        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
        if (giftRainView != null) {
            giftRainView.stopRainNow();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Logger.i(Logger.DEBUG_TAG, "RunRecordActivity onActivityResult resultCode:" + resultCode + ",requestCode:" + requestCode + ",data is null:" + (data == null));
        if (data == null)
            return;

        switch (requestCode) {
            default:
//                if (resultCode == Activity.RESULT_OK) {//三方分享
                String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                switch (requestCode) {
                    case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                    case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                    case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                    case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                    case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        if (!TextUtils.isEmpty(resultStr)) {
                            showAppMessage(resultStr, AppMsg.STYLE_INFO);
                        }
                        if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                            finishShareRecordCoinTask();//完成每日分享运动记录金币任务
                        }
                        break;
//                    }
                }
                break;
        }
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        switch (permissionName) {
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                bindDownloadService();
                if (mUid > 0 || mStartTime > 0) {
                    getRunRecordFromDb(mUid, mStartTime);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        switch (permissionName) {
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                showAppMessage(R.string.activity_run_record_permission_forbid, AppMsg.STYLE_ALERT);
                break;
            default:
                break;
        }
    }

    //region ========================= TrackFragment =========================
    @Override
    public void onMapShotDone() {
        gotoShareActivity();
    }

    //endregion ========================= TrackFragment =========================

    //region ================================== 计步文件和轨迹文件下载 ==================================

    /**
     * 绑定下载或上传服务
     */
    private void bindDownloadService() {
        //1.创建 运动轨迹下载文件夹和计步文件夹
        FileUtils.makeDirs(Config.PATH_DOWN_STEP);
        FileUtils.makeDirs(Config.PATH_DOWN_TRAIL);

        //2.初始化下载回调
        downloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                if (downloadInfo != null) {
                    if (dataSource == 1) {//手表
                        //解压下载的压缩文件
                        if (FileUtils.isFileExist(watchLocalZipFile)) {
                            FileUtils.unZipFiles(watchLocalZipFile, Config.PATH_LOCAL_TEMP);

                            String prefix = mUid + "_" + mStartTime;
                            List<String> files = FileUtils.getFilesByPrefix(Config.PATH_LOCAL_TEMP, prefix);
                            if (files != null) {
                                try {
                                    //1.将文件移到相应的文件夹下
                                    Logger.i(Logger.DEBUG_TAG, "SportRecordDetailActivity-->download onCompleted files size:" + files.size());
                                    String extension;
                                    for (String fileName : files) {
                                        if (fileName.endsWith(".zip")) {
                                            //zip包不处理保存在temp文件夹下,app下次启动自动清理temp文件夹
                                        } else if (fileName.endsWith(".step")) {//计步文件
                                            FileUtils.moveFile(fileName, Config.PATH_DOWN_STEP + prefix + ".step");
                                        } else if (fileName.endsWith(".json")) {//轨迹文件
                                            FileUtils.moveFile(fileName, Config.PATH_DOWN_TRAIL + prefix + ".json");
                                        } else {//其它文件统一移到手表log文件夹下
                                            extension = FileUtils.getFileExtension(fileName);
                                            if (extension != null) {
                                                FileUtils.moveFile(fileName, Config.PATH_WATCH_LOG_DATA + prefix + "." + extension);
                                            }
                                        }
                                    }
                                    //2.设置数据
                                    setStepData();
                                    if (isOutDoor()) {
                                        Logger.d(Logger.DEBUG_TAG, "bindDownloadService ->1");
                                        setTrailData();
                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }
                    } else {
                        String url = downloadInfo.getRemoteUrl();
                        if (getRunLog() != null && !TextUtils.isEmpty(url)) {
                            String stepData = getRunLog().getStepData();
                            String trail = getRunLog().getTrail();
                            if (url.equals(stepData)) {
                                setStepData();
                            } else if (url.equals(trail)) {
                                Logger.d(Logger.DEBUG_TAG, "bindDownloadService ->2");
                                setTrailData();
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                //不处理
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                //不处理
            }
        };

        //3.开启绑定
        Intent intent = new Intent(this, DownloadService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
//                Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->onServiceConnected");
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mService = ((DownloadService.GetServiceClass) service).getService();
                    if (mService == null)
                        return;

                    if (downloadListener != null) {//注册下载状态监听
//                        Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->onServiceConnected addDownloadListener");
                        mService.addDownloadListener(downloadListener);
                    }

                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mService == null)
                        return;
                    if (downloadListener != null) {//注销下载状态监听
                        mService.removeDownloadListener(downloadListener);
                    }
                }
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑下载或上传服务
     */
    private void unbindDownloadService() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        serviceConnection = null;
        downloadListener = null;
    }

    /**
     * 下载轨迹和计步文件、以及心率图表数据
     */
    private void downloadGraphData() {
        if (dataSource == 1) {//手表
            if (!checkWatchFile()) {
                downloadWatchFiles();
            } else {
                setStepData();
                if (isOutDoor()) {
                    setTrailData();
                }
            }
        } else {
            if (isOutDoor()) {
                if (!checkTrail()) {
                    downloadTrail();
                } else {
                    setTrailData();
                }
            }
            if (!checkStepData()) {
                downloadStep();
            } else {
                setStepData();
            }
        }
    }

    /**
     * 下载轨迹文件
     */
    private void downloadTrail() {
        if (!isOutDoor())
            return;

        if (getRunLog() == null)
            return;
        String url = getRunLog().getTrail();

        if (TextUtils.isEmpty(url))
            return;
        if (trailFilename == null || TextUtils.isEmpty(trailFilename))
            return;
        DownloadService.makeDownload(this, url, trailFilename, DownloadType.TYPE_FILE);
        if (mCurrentFragment == 0) {
            if (trackFragment != null) {
                trackFragment.setProgressTrailVisible(true);
            }
        }
    }

    /**
     * 设置地图轨迹数据
     */
    private void setTrailData() {
        if (!isOutDoor())
            return;
        if (TextUtils.isEmpty(trailFilename))
            return;

        mTrailInfoList = JsonHelper.readRunTrailFile(trailFilename);
        if (mTrailInfoList == null)
            return;

        if (mCurrentFragment == 0) {
            if (trackFragment != null) {
                trackFragment.setProgressTrailVisible(false);
                trackFragment.setMapTrail(mTrailInfoList);
            }
        }
    }

    /**
     * 获取轨迹信息列表
     */
    public List<TrailInfo> getTrailInfoList() {
        if (isOutDoor()) {
            if (!TextUtils.isEmpty(trailFilename)) {
                mTrailInfoList = JsonHelper.readRunTrailFile(trailFilename);
            }
        }
        return mTrailInfoList;
    }




    /**
     * 获取手表轨迹列表,已圆润处理(测试用)
     */
    public List<TrailInfo> getSmoothTrailList() {
        if (dataSource == 1) {
            if (smoothTrailList == null) {
                if (mTrailInfoList != null) {
                    smoothTrailList = AMapHelper.bSpline(mTrailInfoList);
                }
            }
            return smoothTrailList;
        }
        return null;
    }

    private List<TrailInfo> rawTrailList;
    private List<TrailInfo> rawSmoothTrailList;
    private List<TrailInfo> smoothTrailList;

    /**
     * 获取手表原始的轨迹列表,(测试用)
     */
    public List<TrailInfo> getRawTrailList() {
        if (dataSource == 1) {
            if (rawTrailList == null) {
                String rawTrailFile = Config.PATH_DOWN_TRAIL + mUid + "_" + mStartTime + ".rawJson";
                if (!TextUtils.isEmpty(rawTrailFile)) {
                    rawTrailList = JsonHelper.readRunTrailFile(rawTrailFile);
                }
            }
            return rawTrailList;
        }
        return null;
    }

    /**
     * 获取手表原始的轨迹列表,已圆润处理(测试用)
     */
    public List<TrailInfo> getRawSmoothTrailList() {
        if (dataSource == 1) {
            if (rawSmoothTrailList == null) {
                if (rawTrailList != null) {
                    rawSmoothTrailList = AMapHelper.bSpline(rawTrailList);
                }
            }
            return rawSmoothTrailList;
        }
        return null;
    }

    /**
     * 下载手表运动记录对应的文件压缩包
     */
    private void downloadWatchFiles() {
        if (mWatchSportLog == null)
            return;
        String url = mWatchSportLog.getZipFile();
        if (TextUtils.isEmpty(url))
            return;
        if (TextUtils.isEmpty(watchLocalZipFile)) {
            return;
        }
        DownloadService.makeDownload(this, url, watchLocalZipFile, DownloadType.TYPE_FILE);
    }

    /**
     * 下载计步数据
     */
    private void downloadStep() {
        if (getRunLog() == null)
            return;
        String sStep = getRunLog().getStepData();
        if (TextUtils.isEmpty(sStep))
            return;
        if (TextUtils.isEmpty(stepFileName))
            return;
        DownloadService.makeDownload(this, sStep, stepFileName, DownloadType.TYPE_FILE);
    }

    /**
     * 从计步文件获取所有计步信息、心率图表数据
     */
    private void setStepData() {
        if (TextUtils.isEmpty(stepFileName))
            return;
        mRunStepList = JsonHelper.readRunStepFile(stepFileName, dataSource);
        List<RunPaceListItemInfo> runPaceListItemInfoList = getPaceListArray();
        if (dataFragment != null) {
            if (viewModel != null){
                viewModel.setRunPaceListItemInfoList(runPaceListItemInfoList);
                dataFragment.setViewModel(viewModel);
            }
        }
    }

    /**
     * 获取心率图表数据点集合
     */
    public List<RunDataInfo> getHeartRateGraphDataList() {
        if (stepFileName == null) return null;
        List<HeartRateJsonInfo> mHeartRateList = JsonHelper.readHeartRateFile(stepFileName, dataSource);//心率信息集合
        if (mHeartRateList == null || mHeartRateList.size() == 0) {
            return null;
        } else {
            List<RunDataInfo> dataInfoList = new ArrayList<>();
            for (int i = 0; i < mHeartRateList.size(); i++) {//转换成心率图表数据点集合
                RunDataInfo runDataInfo = new RunDataInfo();
                runDataInfo.setTime(mHeartRateList.get(i).getTime() - mStartTime);
                runDataInfo.setData(mHeartRateList.get(i).getHeartrate());
                dataInfoList.add(runDataInfo);
            }
            return dataInfoList;
        }
    }

    /**
     * 获取手表运动记录气温图表数据点集合
     */
    public List<RunDataInfo> getWatchTempLogList() {
        if (tempFileName == null) return null;

        if (mWatchTemperatureLogList == null || mWatchTemperatureLogList.size() == 0) {
            mWatchTemperatureLogList = JsonHelper.readWatchTempFile(tempFileName);
        }

        if (mWatchTemperatureLogList != null) {
            List<RunDataInfo> dataInfoList = new ArrayList<>();
            WatchTemperatureLog temperatureLog;
            for (int i = 0; i < mWatchTemperatureLogList.size(); i++) {//转换成手表运动记录气温图表数据点集合
                temperatureLog = mWatchTemperatureLogList.get(i);

                if (temperatureLog.getTemperature() != 0) {//去掉不合格的点
                    float temperature = temperatureLog.getTemperature() / 100.0f - 273.15f;//开尔文温度转摄氏度
                    RunDataInfo runDataInfo = new RunDataInfo();
                    runDataInfo.setTime(temperatureLog.getTime() - mStartTime);
                    runDataInfo.setData(temperature);
                    dataInfoList.add(runDataInfo);
                }
            }
            return dataInfoList;
        }
        return null;
    }


    /**
     * 获取手表运动记录气压图表数据点集合
     */
    public List<RunDataInfo> getWatchPressureLogList() {
        if (pressureFileName == null) return null;

        if (mWatchPressureLogList == null || mWatchPressureLogList.size() == 0) {
            mWatchPressureLogList = JsonHelper.readWatchPressureFile(pressureFileName);
        }

        if (mWatchPressureLogList != null) {
            List<RunDataInfo> dataInfoList = new ArrayList<>();

            WatchPressureLog pressureLog;
            for (int i = 0; i < mWatchPressureLogList.size(); i++) {//转换成手表运动记录气压图表数据点集合
                pressureLog = mWatchPressureLogList.get(i);

                if (pressureLog.getPressure() != 0) {//去掉不合格的点
                    RunDataInfo runDataInfo = new RunDataInfo();
                    runDataInfo.setTime(pressureLog.getTime() - mStartTime);
                    runDataInfo.setData(pressureLog.getPressure() / 100.0f);//转换成百帕斯卡
                    dataInfoList.add(runDataInfo);
                }
            }
            return dataInfoList;
        }
        return null;
    }

    /**
     * 从计步文件获取所有计步信息
     */
    public List<RunStepInfo> getRunStepList() {
        if (mRunStepList == null || mRunStepList.size() == 0) {
            if (!TextUtils.isEmpty(stepFileName))
                mRunStepList = JsonHelper.readRunStepFile(stepFileName, dataSource);
        }
        return mRunStepList;
    }

    /**
     * 从步数信息集合,得到路段配速信息集合
     */
    public List<RunPaceListItemInfo> getPaceListArray() {
        if ((mRunStepList == null) || (mRunStepList.size() <= 1)) return null;
        int iLen = mRunStepList.size();
        long distanceSpace;    //最多每多少米一条记录
        if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR ||
                watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR){//100米一条记录
            distanceSpace = 100;
        }else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB){//10米一条记录
            distanceSpace = 10;
        }else {//1000米一条记录
            distanceSpace = 1000;
        }
        int index = 0;

        //以防第一个记录点时间戳为0的情况
        long startTime = 0;
        for (int s = 0; s < mRunStepList.size(); s++) {
            if (mRunStepList.get(s).getTime() != 0) {
                startTime = mRunStepList.get(s).getTime();
                break;
            }
        }

        List<RunPaceListItemInfo> list = new ArrayList<>();

        SparseIntArray milestone = new SparseIntArray();//键值为里程数,值为最接近里程的下标
        for (int i = 0; i < iLen; i++) {
            if (mRunStepList.get(i) != null) {
                int nowIndex = (int) (mRunStepList.get(i).getDistance() / distanceSpace);
                if (nowIndex != index) {
                    index = nowIndex;
                    milestone.put(index, i);
                }
            }
        }

        if (milestone.size() > 0) {
            for (int i = 0; i < milestone.size(); i++) {
                int key = milestone.keyAt(i);
                int value = milestone.valueAt(i);
                if (value > iLen) {
                    return list;
                }
                if (mRunStepList.get(value) != null) {//计算每个公里区间的平均配速
                    RunPaceListItemInfo info = new RunPaceListItemInfo();
                    //info.setDistance(String.format("%.1f", (i+1)*1.0f));

                    if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR ||
                            watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR){//100米一条记录
                        info.setDistanceValue(key);
                        info.setDistance(String.format("%.1f", key * 100.0f));

                        long time = (mRunStepList.get(value).getTime() - startTime);

                        info.setTime(time);
                        if (i == 0) {//100m
                            info.setDuration(time);
                        } else {
                            int pre = milestone.valueAt(i - 1);
                            long duration = (mRunStepList.get(value).getTime() - mRunStepList.get(pre).getTime());
                            info.setDuration(duration);
                        }
                    }else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB){//10米一条记录
                        info.setDistanceValue(key);
                        info.setDistance(String.format("%.1f", key * 10.0f));

                        long time = (mRunStepList.get(value).getTime() - startTime);

                        info.setTime(time);
                        if (i == 0) {//10m
                            info.setDuration(time);
                        } else {
                            int pre = milestone.valueAt(i - 1);
                            long duration = (mRunStepList.get(value).getTime() - mRunStepList.get(pre).getTime());
                            info.setDuration(duration);
                        }
                    }else {//1000米一条记录
                        info.setDistanceValue(key);
                        info.setDistance(String.format("%.1f", key * 1.0f));

                        long time = (mRunStepList.get(value).getTime() - startTime);

                        info.setTime(time);
                        if (i == 0) {//1公里
                            info.setDuration(time);
                        } else {
                            int pre = milestone.valueAt(i - 1);
                            long duration = (mRunStepList.get(value).getTime() - mRunStepList.get(pre).getTime());
                            info.setDuration(duration);
                        }
                    }

                    list.add(info);
                }
            }

            int lastKey = milestone.keyAt(milestone.size() - 1);
            int lastMileIndex = milestone.valueAt(milestone.size() - 1);
            if (lastMileIndex < iLen) {//最后一段距离
                RunPaceListItemInfo info = new RunPaceListItemInfo();
                //info.setDistance(String.format("<%.1f", (milestone.size()+1)*1.0f));


                if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR ||
                        watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR){//100米一条记录
                    info.setDistanceValue(lastKey + 1);
                    info.setDistance(String.format("<%.1f", (lastKey + 1) * 100.0f));
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    info.setTime(duration);
                    long distance = mRunStepList.get(iLen - 1).getDistance() - mRunStepList.get(lastMileIndex).getDistance();
                    long time = mRunStepList.get(iLen - 1).getTime() - mRunStepList.get(lastMileIndex).getTime();
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (time * (100.0f / distance));
                        info.setDuration(estimateTime);
                    }
                }else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB){//10米一条记录
                    info.setDistanceValue(lastKey + 1);
                    info.setDistance(String.format("<%.1f", (lastKey + 1) * 10.0f));
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    info.setTime(duration);
                    long distance = mRunStepList.get(iLen - 1).getDistance() - mRunStepList.get(lastMileIndex).getDistance();
                    long time = mRunStepList.get(iLen - 1).getTime() - mRunStepList.get(lastMileIndex).getTime();
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (time * (10.0f / distance));
                        info.setDuration(estimateTime);
                    }
                }else {//1000米一条记录
                    info.setDistanceValue(lastKey + 1);
                    info.setDistance(String.format("<%.1f", (lastKey + 1) * 1.0f));
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    info.setTime(duration);
                    long distance = mRunStepList.get(iLen - 1).getDistance() - mRunStepList.get(lastMileIndex).getDistance();
                    long time = mRunStepList.get(iLen - 1).getTime() - mRunStepList.get(lastMileIndex).getTime();
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (time * (1000.0f / distance));
                        info.setDuration(estimateTime);
                    }
                }

                list.add(info);
            }

            for (int i = 1; i < list.size(); i++) {//计算相邻公里区间的速度变化值
                if (list.get(i) != null && list.get(i - 1) != null) {
                    long durationDiff = list.get(i).getDuration() - list.get(i - 1).getDuration();
                    list.get(i).setDeviation(durationDiff);
                }
            }

        } else {//总里程小于多少m
            if (mRunStepList.get(iLen - 1) != null) {
                RunPaceListItemInfo info = new RunPaceListItemInfo();

                if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR ||
                        watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR){//100米一条记录
                    info.setDistanceValue(100);
                    info.setDistance(String.format("<%.1f", 100.0f));
                    long distance = mRunStepList.get(iLen - 1).getDistance();
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (1.0 * duration * (100L / distance));
                        info.setDuration(estimateTime);
                    }
                    info.setTime(duration);
                    info.setDeviation(0);
                }else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB){//10米一条记录
                    info.setDistanceValue(10);
                    info.setDistance(String.format("<%.1f", 10.0f));
                    long distance = mRunStepList.get(iLen - 1).getDistance();
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (1.0 * duration * (10L / distance));
                        info.setDuration(estimateTime);
                    }
                    info.setTime(duration);
                    info.setDeviation(0);
                }else {//1000米一条记录
                    info.setDistanceValue(1);
                    info.setDistance(String.format("<%.1f", 1.0f));
                    long distance = mRunStepList.get(iLen - 1).getDistance();
                    long duration = (mRunStepList.get(iLen - 1).getTime() - startTime);
                    if (distance > 0) {
                        //距离不够1公里,按比例估算
                        long estimateTime = (long) (1.0 * duration * (1000L / distance));
                        info.setDuration(estimateTime);
                    }
                    info.setTime(duration);
                    info.setDeviation(0);
                }

                list.add(info);
            }
        }

        return list;
    }


    /**
     * @return 检查轨迹文件是否存在
     */
    private boolean checkTrail() {
        if (TextUtils.isEmpty(trailFilename))
            return false;
        File f = new File(trailFilename);
        return f.exists();
    }

    /**
     * @return 检查计步文件是否存在
     */
    private boolean checkStepData() {
        if (TextUtils.isEmpty(stepFileName))
            return false;
        File f = new File(stepFileName);
        return f.exists();
    }

    /**
     * 检查手表相应的文件是否存在
     */
    private boolean checkWatchFile() {
        if (mWatchSportLog == null)
            return true;

        int sportType = mWatchSportLog.getSportType();
        switch (sportType) {
            case WatchDataProtocol.SPORTS_TYPE_RUN_OUTDOOR://室外跑
            case WatchDataProtocol.SPORTS_TYPE_RUN_INDOOR://室内跑
            case WatchDataProtocol.SPORTS_TYPE_WALK://徒步
            case WatchDataProtocol.SPORTS_TYPE_MOUNTAINS_CLIMB://登山
            case WatchDataProtocol.SPORTS_TYPE_RIDE_CROSSCOUNTRY://山地车
            case WatchDataProtocol.SPORTS_TYPE_RIDE://公路车
                //判断计步文件是否存在
                return checkStepData();
            default://TODO 其它运动类型需要增加相应的判断标准

                break;
        }

        return false;
    }

    //endregion ================================== 计步文件和轨迹文件下载 ==================================

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动记录金币任务
     */
    private void finishShareRecordCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_RECORD, 0);
        Logger.i(Logger.DEBUG_TAG, "finishShareRecordCoinTask is today:" + FitmixUtil.isToday(lastShareTime));
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareRecordCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }
    //endregion ============================= 金币任务 =============================


}
