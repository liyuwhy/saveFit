package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.TimeCountUtil;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.countrypicker.Country;
import com.fitmix.sdk.view.countrypicker.CountryPicker;
import com.fitmix.sdk.view.countrypicker.OnCountryPickerListener;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

public class ForgotPasswordActivity extends BaseActivity {

    //    private final int REQUEST_TYPE_GET_AUTH_CODE = 0;
//    private final int REQUEST_TYPE_RETRIEVE_EMAIL = 1;
//    private final int REQUEST_TYPE_RETRIEVE_PHONE = 2;
    private RadioGroup rg_forget_pwd;
    private EditText txt_account;
    private EditText txt_phone;

    private TextView txt_china_phone;
    private EditText txt_new_password;
    private EditText txt_confirm_password;
    private EditText txt_auth_code;
    private Button btn_get_auth_code;

    private EditText txt_email_auth_code;
    private Button btn_get_email_auth_code;
    private LinearLayout ll_register_area;
    private TextView tv_label_area;

    private String mEmailAddress;
    private String mPhoneNumber;
    private String mTempPhoneNumber;
    private String mTempEmail;//保存获取邮箱验证码时的邮箱,防止用户在注册时用另外的邮箱注册
    private String mPassword;
    private String mConfirmPwd;

    public boolean isEmailFind = false;

    private String validationCode;//客户端输入的验证码

//    private static String serverValidationCode;//服务器端获取的验证码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        setPageName("ForgotPasswordActivity");
        initToolbar();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        initViews();
    }

    /**
     * 初始化控件
     */
    protected void initViews() {
        rg_forget_pwd = (RadioGroup) findViewById(R.id.rg_forget_pwd);
        txt_account = (EditText) findViewById(R.id.txt_account);

        txt_phone = (EditText) findViewById(R.id.txt_phone_number);
        txt_china_phone =  findViewById(R.id.txt_china_number);
        txt_china_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             /*   txt_china_phone.setFocusable(true);
                txt_china_phone.setFocusableInTouchMode(true);*/
                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(ForgotPasswordActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog
            }
        });

        txt_new_password = (EditText) findViewById(R.id.txt_new_password);
        txt_confirm_password = (EditText) findViewById(R.id.txt_confirm_password);
        ll_register_area = findViewById(R.id.ll_register_area);
        tv_label_area = findViewById(R.id.tv_label_area);
        ll_register_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(ForgotPasswordActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                        tv_label_area.setText(country.getName());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog
            }
        });
        txt_auth_code = (EditText) findViewById(R.id.txt_auth_code);
        btn_get_auth_code = (Button) findViewById(R.id.btn_get_auth_code);
        btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));

        txt_email_auth_code = (EditText) findViewById(R.id.txt_mail_auth_code);
        btn_get_email_auth_code = (Button) findViewById(R.id.btn_get_mail_auth_code);
        btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));


        rg_forget_pwd.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup rg, int id) {
                switch (id) {
                    case R.id.radio_phone_forget_pwd://手机找回
                        ll_register_area.setVisibility(View.VISIBLE);
                        txt_account.setVisibility(View.GONE);
                        txt_phone.setVisibility(View.VISIBLE);
                        txt_china_phone.setVisibility(View.VISIBLE);
                        txt_china_phone.setText(getResources().getString(R.string.china_phone_code));

                        txt_auth_code.setVisibility(View.VISIBLE);
                        btn_get_auth_code.setVisibility(View.VISIBLE);

                        txt_email_auth_code.setVisibility(View.GONE);
                        btn_get_email_auth_code.setVisibility(View.GONE);

                        txt_new_password.setVisibility(View.VISIBLE);
                        txt_confirm_password.setVisibility(View.VISIBLE);

                        isEmailFind = false;
                        break;
                    case R.id.radio_email_forget_pwd://邮箱找回
                        ll_register_area.setVisibility(View.GONE);
                        txt_account.setVisibility(View.VISIBLE);

                        txt_phone.setVisibility(View.GONE);
                        txt_china_phone.setVisibility(View.GONE);

                        txt_auth_code.setVisibility(View.GONE);
                        btn_get_auth_code.setVisibility(View.GONE);

                        txt_email_auth_code.setVisibility(View.VISIBLE);
                        btn_get_email_auth_code.setVisibility(View.VISIBLE);

                        txt_new_password.setVisibility(View.VISIBLE);
                        txt_confirm_password.setVisibility(View.VISIBLE);
                        isEmailFind = true;
                        break;
                }
            }
        });
    }




//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        String result = dataReqResult.getResult();
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_USER + 10://请求手机验证码
//                AuthCode authCode = JsonHelper.getObject(dataReqResult.getResult(), AuthCode.class);
//                if (authCode != null)
//                    serverValidationCode = authCode.getData();
                BaseBean authCodeResult = JsonHelper.getObject(result, BaseBean.class);
                if (authCodeResult != null && authCodeResult.getCode() == 0) {
                    showAppMessage(R.string.activity_register_get_auth_code_success, AppMsg.STYLE_INFO);
                }
                break;
            case Config.MODULE_USER + 11://请求邮箱验证码
                BaseBean emailAuthCodeResult = JsonHelper.getObject(result, BaseBean.class);
                if (emailAuthCodeResult != null && emailAuthCodeResult.getCode() == 0) {
                    showAppMessage(R.string.activity_register_get_email_auth_code_success, AppMsg.STYLE_INFO);
                }
                break;
            case Config.MODULE_USER + 22://邮箱找回密码
                hideLoadingDialog();
                afterSendEmailForgetPWD(dataReqResult.getResult());
                break;
            case Config.MODULE_USER + 23://手机找回密码
                hideLoadingDialog();
                afterSendMobileForgetPWD(dataReqResult.getResult());
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 10://请求验证码
            case Config.MODULE_USER + 11://请求邮箱验证码
            case Config.MODULE_USER + 22://邮箱找回密码
            case Config.MODULE_USER + 23://手机找回密码
                hideLoadingDialog();
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timeCountUtil != null) {
            timeCountUtil.cancel();
            timeCountUtil = null;
        }

        if (emailAuthCodeTimeCount != null) {
            emailAuthCodeTimeCount.cancel();
            emailAuthCodeTimeCount = null;
        }
    }

    /**
     * 获取手机验证码倒计时
     */
    private TimeCountUtil timeCountUtil = new TimeCountUtil(60 * 1000, 1000, new TimeCountUtil.ITimeCountListener() {
        @Override
        public void onTick(long millisUntilFinished) {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "(", String.valueOf(millisUntilFinished / 1000), ")"));
            btn_get_auth_code.setEnabled(false);
            txt_phone.setEnabled(false);
        }

        @Override
        public void onFinish() {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));
            btn_get_auth_code.setEnabled(true);
        }
    });

    /**
     * 获取邮箱验证码倒计时
     */
    private TimeCountUtil emailAuthCodeTimeCount = new TimeCountUtil(60 * 1000, 1000, new TimeCountUtil.ITimeCountListener() {
        @Override
        public void onTick(long millisUntilFinished) {
            btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "(", String.valueOf(millisUntilFinished / 1000), ")"));
            btn_get_email_auth_code.setEnabled(false);
        }

        @Override
        public void onFinish() {
            btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));
            btn_get_email_auth_code.setEnabled(true);
        }
    });


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_retrieve:
                processSubmit();
                break;
            case R.id.btn_get_auth_code://获取手机验证码
                changeBtnGetCode();
                break;

            case R.id.btn_get_mail_auth_code://获取邮箱验证码
                changeBtnGetEmailAuthCode();
                break;

        }
    }

    /**
     * 提交任务
     */
    private void processSubmit() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        if (isEmailFind) {
            getPasswordInNetwork();
        } else {
            sendChangePwdRequest();
        }
    }


    /**
     * 获取手机验证码
     */
    private void changeBtnGetCode() {
        mPhoneNumber = txt_phone.getText().toString();
        String countryCode = txt_china_phone.getText().toString();
        if (countryCode.contains("86")){
            if (!FitmixUtil.isMobileNumber(mPhoneNumber)) {
                showAppMessage(R.string.activity_register_error_phone, AppMsg.STYLE_ALERT);
                return;
            }
        }
        getAuthCode();//获取验证码
        timeCountUtil.start();
    }

    /**
     * 获取邮箱验证码
     */
    private void changeBtnGetEmailAuthCode() {
        mEmailAddress = txt_account.getText().toString();
        if (!FitmixUtil.isEmail(mEmailAddress)) {
            showAppMessage(R.string.rsp_error_email_empty, AppMsg.STYLE_ALERT);
            return;
        }
        getEmailAuthCode();//获取邮箱验证码
        emailAuthCodeTimeCount.start();
    }

    /**
     * 获取手机验证码
     */
    private void getAuthCode() {
        mTempPhoneNumber = mPhoneNumber;
        String countryCode = txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        int requestId = UserDataManager.getInstance().getAuthCode(countryCode+mPhoneNumber, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取邮箱验证码
     */
    private void getEmailAuthCode() {
        mTempEmail = mEmailAddress;
        int requestId = UserDataManager.getInstance().getEmailAuthCode(mEmailAddress, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 邮箱找回密码
     */
    private void getPasswordInNetwork() {
        int requestId = UserDataManager.getInstance().forgetEmailPassword(mEmailAddress, validationCode, mConfirmPwd, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 手机找回密码
     */
    private void sendChangePwdRequest() {
        showLoadingDialog(R.string.activity_forgot_password_retrieving, 1000);
        String countryCode = txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        int requestId = UserDataManager.getInstance().forgetMobilePassword(countryCode+mPhoneNumber, validationCode, mPassword, true);
        registerDataReqStatusListener(requestId);

    }

    private void afterSendEmailForgetPWD(String sResult) {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_forgot_password_reset_by_phone) //activity_forgot_password_reset
                .positiveText(android.R.string.ok)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        finish();
                    }
                }).show();
    }

    private void afterSendMobileForgetPWD(String sResult) {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_forgot_password_reset_by_phone)
                .positiveText(android.R.string.ok)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        finish();
                    }
                }).show();
    }

    /**
     * 检查错误
     *
     * @return Config.ERROR_NO_ERROR   成功
     * 其它                             错误代码
     */
    private int checkInputError() {
        mPassword = txt_new_password.getText().toString();
        mConfirmPwd = txt_confirm_password.getText().toString();

        if (isEmailFind) {
            mEmailAddress = txt_account.getText().toString();
            validationCode = txt_email_auth_code.getText().toString().trim();
            if (!FitmixUtil.isEmail(mEmailAddress)) {
                return Config.ERROR_FORMAT_ERROR;
            }

            if (TextUtils.isEmpty(validationCode)) {
                return Config.ERROR_EDIT_AUTH_CODE;
            }

            if (!mEmailAddress.equals(mTempEmail)) {
                return Config.ERROR_EMAIL_NOT_MATCH;
            }

        } else {
            String countryCode = txt_china_phone.getText().toString();
            mPhoneNumber = txt_phone.getText().toString();
            validationCode = txt_auth_code.getText().toString().trim();

            if (countryCode.contains("86")){
                if (!FitmixUtil.isMobileNumber(mPhoneNumber))
                    return Config.ERROR_PHONE_DATA;

                if (!mPhoneNumber.equals(mTempPhoneNumber)) {
                    return Config.ERROR_PHONE_NUMBER_NOT_MATCH;
                }
            }

//            if (TextUtils.isEmpty(serverValidationCode)) {//不再在客户端验证
//                return Config.ERROR_GET_AUTH_CODE;
//            }

            if (TextUtils.isEmpty(validationCode)) {
                return Config.ERROR_EDIT_AUTH_CODE;
            }

//            if (!validationCode.equals(serverValidationCode)) {//不再在客户端验证
//                return Config.ERROR_AUTH_CODE_WRONG;
//            }


        }

        if (mPassword == null || mPassword.length() < Config.PASSWORD_LENGTH_MIN)
            return Config.ERROR_PASSWORD_TOO_SHORT;

        if (!mPassword.equals(mConfirmPwd))
            return Config.ERROR_PASSWORD_NOT_MATCH;

        return Config.ERROR_NO_ERROR;
    }
}
