package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.common.ExpectancyTable;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.ble.HRSManager;
import com.fitmix.sdk.common.bluetooth.scanner.ScannerFragment;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.common.sound.VoiceManager;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.RestHeartRate;
import com.fitmix.sdk.model.database.RestHeartRateHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.service.WatchRunService;
import com.fitmix.sdk.view.dialog.ContinueFinishDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.HeartRateFragment;
import com.fitmix.sdk.view.fragment.RunMainFinishFragment;
import com.fitmix.sdk.view.fragment.RunMainMapFragment;
import com.fitmix.sdk.view.fragment.RunMainMusicFragment;
import com.fitmix.sdk.view.fragment.RunSettingBaseFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.SlideButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
//import com.squareup.leakcanary.RefWatcher;

public class RunMainActivity extends BaseActivity implements RunMainMapFragment.RunMainMapFragmentBack, HeartRateFragment.HeartRateFragmentBack, ScannerFragment.OnDeviceSelectedListener {
    /**
     * 选择音乐请求
     */
    private static final int REQUEST_SELECT_MUSIC = 457;

    //region ==================== 开场倒计时 ====================
    private View viewCountDownGroup;
    private Animation anim_count_down;
    private TextView textCountDown;
    private int mCountDownTime = 3;//3秒

    //endregion ==================== 开场倒计时 ====================

    private FrameLayout run_main_container;
    private SlideButton slideButton;//滑动暂停按钮
    private SlideButton.OnSlideListener slideListener;
    private RunMainMusicFragment mainMusicFragment;
    private HeartRateFragment mainHeartRateFragment;
    private RunMainMapFragment mainMapFragment;
    private RunMainFinishFragment finishFragment;
    /**
     * 由RunMainFinishFragment从数据库加载刚完成跑步的数据,用于上传记录
     */
    private RunLogInfo mRunLogInfo;
    private Music mMusicInfo;
    private boolean bMusicPlayed = false;

    private boolean bUseMetronome;
    /**
     * 是否正在处理运动完成,防止多次点击运动完成按钮
     */
    private boolean handlingRunFinish = false;
    /**
     * 计步文件本地绝对路径
     */
    private String stepFileName;
    /**
     * 轨迹文件本地绝对路径
     */
    private String trailFileName;

    //region ==================== 任务计划 ====================
    private boolean bTaskComplete;
    private long taskObject;
    private int taskType;
    private boolean fromWatchRunService;
    //    private int userCoachMode;
//    private long allTime;

    //endregion ==================== 任务计划 ====================

    /**
     * 自定义handler
     */
    private static class MyHandler extends WeakHandler {
        public MyHandler(RunMainActivity runMainActivity) {
            super(runMainActivity);
        }

        public void handleMessage(Message msg) {
            RunMainActivity activity = (RunMainActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case Config.MSG_ANIMATION_TIMER://运动开始倒计时
                    activity.processAnimation();
                    break;

                case Config.MSG_REPEAT_EVERY_SECOND:
                    activity.refreshRunInfo();
                    activity.getHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND, 1000);
                    break;

            }
        }
    }

    /**
     * RunMainActivity页面中定义的handler
     */
    private MyHandler mHandler;

    /**
     * 获取RunMainActivity页面中定义的handler
     */
    private MyHandler getHandler() {
        if (mHandler == null) {
            mHandler = new MyHandler(this);
        }
        return mHandler;
    }

    /**
     * @return 获取音乐信息
     */
    public Music getMusicInfo() {
        return mMusicInfo;
    }

    //region ====================================== 与RunService交互相关 ======================================

    private RunService runService;

    /**
     * 获取跑步主服务
     */
    public RunService getRunService() {
        return runService;
    }

    private ServiceConnection serviceConnection;

    /**
     * 绑定主跑服务
     */
    private void connectToRunService() {

        Intent intent = new Intent(this, RunService.class);
        startService(intent);//增加一直在后台运行方式,运动完成后如果没有后台计步,则自动销毁
        serviceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(RunService.SERVICE_NAME))
                    return;
                runService = ((RunService.LocalBinder) service).getService();
                if (runService == null) {
                    RunMainActivity.this.finish();
                    return;
                }
                if (runService.isInRunDuration()) {//运动中
                    if (userHeartRateFinish != null) {
                        runService.setUserHeartRateFinish(userHeartRateFinish);//activity被销毁过的话，回调需要重新设置
                    }
                    return;
                }
                //1.准备新运动
                runService.prepareRun();
                //2.根据运动环境决定是否要检测GPS状态
                int sportEnvironment = SettingsHelper.getInt(Config.SETTING_SPORT_ENVIRONMENT, 0);
                if (sportEnvironment == RunLogInfo.SPORT_MODE_OUTDOOR) {
                    if (!FitmixUtil.isGpsEnable(RunMainActivity.this)) {//室外模式未开启定位时,提示用户打开GPS
                        new MaterialDialog.Builder(RunMainActivity.this)
                                .title(R.string.prompt)
                                .content(R.string.activity_runmain_open_gps)
                                .positiveText(android.R.string.ok)
                                .negativeText(R.string.cancel)
                                .cancelable(false)
                                .onAny(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.dismiss();
                                        boolean bStartCountDown = true;
                                        switch (which) {
                                            case POSITIVE:
                                                FitmixUtil.enableGPS(RunMainActivity.this);//打开GPS
                                                bStartCountDown = false;
                                                break;
                                            case NEGATIVE:
                                                break;
                                        }
                                        if (bStartCountDown) startCountDown();
                                    }
                                }).show();
                    } else {//室外模式已开启定位
                        startCountDown();
                    }
                } else {//室内模式
                    startCountDown();
                }

                //静息心率,数据库搜索最近一次的静息心率记录,设置回调
                RestHeartRate info = RestHeartRateHelper.getInstance().getLatestHeartRateInfo(UserDataManager.getUid());
                runService.setLatestRestHeartRate((info != null && info.getHeart_rate_record() != null) ? info.getHeart_rate_record() : Config.HEART_RATE_DEFAULT_REST_HR);
                runService.setUserHeartRateFinish(userHeartRateFinish);

                //设置运动目标
                long value = taskObject;
                if (taskType == RunSettingBaseFragment.TASK_TYPE_TIME) {
                    value *= 1000;//转换成毫秒
                }
                runService.setTaskTypeAndValue(value, taskType);

            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                runService = null;
            }
        };

        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);


    }

    /**
     * 解绑主跑服务
     */
    private void disconnectToRunService() {
        if (serviceConnection != null) {
            if (getRunService() != null) {
                getRunService().setUserHeartRateFinish(null);
            }
            unbindService(serviceConnection);
        }
        serviceConnection = null;
    }

    /**
     * 从RunService获取当前跑步信息
     */
    private RunLogInfo getRunLog() {
        if (getRunService() == null) return null;
        return getRunService().getRunLogInfo();
    }


    //endregion ====================================== 与RunService交互相关 ======================================

    //region ====================================== 与HeartRateService交互相关 ======================================

    //当运动结束时的回调
    private RunService.UserHeartRateFinish userHeartRateFinish = new RunService.UserHeartRateFinish() {
        @Override
        public void doUserHeartRateFinish() {
            if (heartRateService == null) {
                return;
            }
            Logger.d(Logger.DEBUG_TAG, "RunMainActivity-->doUserHeartRateFinish()");
            if (heartRateService.getHeartRateSize() > 0) { //只要有心率值,便是心率跑
                UserHeartRate userHeartRate = new UserHeartRate();

                userHeartRate.setAerobicNum(heartRateService.getAerobicNum());
                userHeartRate.setAnaerobicNum(heartRateService.getAnaerobicNum());
                userHeartRate.setFatBurningNum(heartRateService.getFatBurningNum());
                userHeartRate.setMaxNum(heartRateService.getMaxNum());
                userHeartRate.setWarmNum(heartRateService.getWarmNum());
                userHeartRate.setMaxHeartRate(heartRateService.getMaxHeartRate());
                userHeartRate.setMinHeartRate(heartRateService.getMinHeartRate());
                if (heartRateService.getHeartRateSize() == 0 || heartRateService.getSumHeartRate() == 0) {
                    userHeartRate.setHeartRateAvg(0);
                } else {
                    userHeartRate.setHeartRateAvg(heartRateService.getSumHeartRate() / heartRateService.getHeartRateSize());
                }

                userHeartRate.setLastUpdated(System.currentTimeMillis());
                //增加的年龄与静息心率
                int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
                userHeartRate.setCurrentAge(age > 0 ? age : Config.USER_DEFAULT_AGE);
                userHeartRate.setCurrentRestHeartRate(heartRateService.getLatestRestHeartRate());
                userHeartRate.setVoMax(heartRateService.getTheMaxVo2());
                userHeartRate.setHrMax(SettingsHelper.getInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age > 0 ? age : Config.USER_DEFAULT_AGE)));

                if (getRunService() != null) {
                    if (getRunService().getRunLogInfo() != null) {
                        userHeartRate.setConsumptionSpendTime(getRunService().getRunLogInfo().getRunTime());//运动时长//TODO bug:存在为空的情况
                    }
                    String heartRateString = JsonHelper.createJsonString(userHeartRate);
                    getRunService().getRunLogInfo().setHeartRateDate(heartRateString);
                    Logger.i(Logger.DEBUG_TAG, "RunService.UserHeartRateFinish doUserHeartRateFinish heartRateData:" + heartRateString);
                }
            } else {
                Logger.i(Logger.DEBUG_TAG, "#####################doUserHeartRateFinish(),getHeartRateSize() == 0");
            }
        }

        @Override
        public UserHeartRate getUserHeartRate() {
            if (heartRateService == null) {
                return null;
            }
            if (heartRateService.getHeartRateSize() > 0) { // 只要有心率值,便是心率跑
                UserHeartRate userHeartRate = new UserHeartRate();

                userHeartRate.setAerobicNum(heartRateService.getAerobicNum());
                userHeartRate.setAnaerobicNum(heartRateService.getAnaerobicNum());
                userHeartRate.setFatBurningNum(heartRateService.getFatBurningNum());
                userHeartRate.setMaxNum(heartRateService.getMaxNum());
                userHeartRate.setWarmNum(heartRateService.getWarmNum());
                userHeartRate.setMaxHeartRate(heartRateService.getMaxHeartRate());
                userHeartRate.setMinHeartRate(heartRateService.getMinHeartRate());
                if (heartRateService.getHeartRateSize() == 0 || heartRateService.getSumHeartRate() == 0) {
                    userHeartRate.setHeartRateAvg(0);
                } else {
                    userHeartRate.setHeartRateAvg(heartRateService.getSumHeartRate() / heartRateService.getHeartRateSize());
                }

                userHeartRate.setLastUpdated(System.currentTimeMillis());
                //增加的年龄与静息心率
                int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
                userHeartRate.setCurrentAge(age > 0 ? age : Config.USER_DEFAULT_AGE);
                userHeartRate.setCurrentRestHeartRate(heartRateService.getLatestRestHeartRate());
                userHeartRate.setVoMax(heartRateService.getTheMaxVo2());
                userHeartRate.setHrMax(SettingsHelper.getInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(age > 0 ? age : Config.USER_DEFAULT_AGE)));
                //注意,该字段故意先不写运动耗时信息
                return userHeartRate;
            } else {
                return null;
            }
        }
    };

    //HeartRateService 心率事件回调
    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {
            SettingsHelper.putString(Config.SETTING_HR_FIRMWARE_VERSION_CODE, firmwareVersion);
        }

        @Override
        public void onDeviceConnected() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(RunMainActivity.this, getResources().getString(R.string.gatt_connected), Toast.LENGTH_SHORT).show();
                    if (mainHeartRateFragment != null && mainHeartRateFragment.isAdded()) {
                        mainHeartRateFragment.gattCheckByProgram(true);
                    }
                    playLAVAConnectedVoice();
                }
            });
            startHeartRateService();
            Logger.i(Logger.DEBUG_TAG, "RunMainActivity--->onDeviceConnected()");
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.i(Logger.DEBUG_TAG, "RunMainActivity--->onDeviceDisconnected");
//            //取消连接成功
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mainHeartRateFragment != null) {
                        mainHeartRateFragment.gattCheckByProgram(false);
                    }
                }
            });
            //断开了也要设服务的最新心率为0
            if (getRunService() != null) {
                getRunService().setLatestHeartRate(getLatestHeartRate());
            }
            stopHeartRateService();
        }


        @Override
        public void onError() {
            Logger.i(Logger.DEBUG_TAG, "RunMainActivity,onError()");
        }

        @Override
        public void onHRValueReceived() {
            if (getRunService() != null) {
                getRunService().setLatestHeartRate(getLatestHeartRate());
                Logger.d(Logger.DEBUG_TAG, "RunMainActivity HR：" + getLatestHeartRate());
            }
        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, int signalValue) {
            if (heartRateService == null) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mainHeartRateFragment != null && mainHeartRateFragment.isVisible() && heartRateService.getRefreshSignalStrength() != -1) {
                        mainHeartRateFragment.setSignalValue(heartRateService.getRefreshSignalStrength());
                    }
                }
            });
        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {
            if (mainHeartRateFragment != null) { //该fragment还没初始化,因此无法加入心率历史记录点
                mainHeartRateFragment.addLineChartValueList(list, false);
            } else {
                //存下状态,//存下数据
                needToAddHistoryHR = true;
                historyHRList = list;
            }
        }

        /**
         * 心率图表刷新
         */
        @Override
        public void reDrawHeartRateData() {
            if (mainHeartRateFragment == null) {
                return;
            }
            /**
             * java.lang.IllegalStateException: Fragment HeartRateFragment{43159c70} not attached to Activity
             * at android.support.v4.app.Fragment.getResources(Fragment.java:639)
             * at com.fitmix.sdk.view.fragment.HeartRateFragment.setHeartRate(HeartRateFragment.java:280)
             * at com.fitmix.sdk.view.activity.RunMainActivity$3.reDrawHeartRateData(RunMainActivity.java:442)
             * */
            if (mainHeartRateFragment.isVisible()) {
                mainHeartRateFragment.setHeartRate(getLatestHeartRate(), getHeartRateService() != null ? getHeartRateService().getLatestRestHeartRate() : Config.HEART_RATE_DEFAULT_REST_HR);
                mainHeartRateFragment.setCurrentHeartRateText(getHeartRateService() != null && getHeartRateService().getDevice() != null, getLatestHeartRate(), getHeartRateService().getLatestRestHeartRate());
            }

            //心率服务中必须要有刷新时间,-1的话会造成异常
            if (heartRateService == null || heartRateService.getRefreshTime() == -1) {
                return;
            }

            /**
             * 解决bug
             * java.lang.NullPointerException
             * at com.fitmix.sdk.view.activity.RunMainActivity$3.reDrawHeartRateData(RunMainActivity.java:445)
             * at com.fitmix.sdk.service.HeartRateService.refresh(HeartRateService.java:208)
             * */
            if (mainHeartRateFragment != null && mainHeartRateFragment.getLineChartValueSize() == 0) {
                mainHeartRateFragment.addLineChartValue(new HeartRateChartInfo(getLatestHeartRate(), heartRateService.getRefreshTime()), ifScreenOff());//表格数据需要一直增加,无论mainHeartRateFragment是否可见
            } else {
                if (mainHeartRateFragment != null && getLatestHeartRate() != 0) {
                    mainHeartRateFragment.addLineChartValue(new HeartRateChartInfo(getLatestHeartRate(), heartRateService.getRefreshTime()), ifScreenOff());//表格数据需要一直增加,无论mainHeartRateFragment是否可见
                }
            }
        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                              int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                              boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {
            //TODO 如果当时有其他语音正在播放,需要等到当前语音播放完毕后才播放此语音
            if (getRunService() != null) {
                getRunService().playHRMessageVoice(latestHeartRate, restHeartRate, inCoachModeAllTime, lowZoneTime, inZoneTime, upZoneTime, superZoneTime,
                        isNotFirstInHotMode, isNotFirstInFatMode, isNotFirstInHeartLungMode, isNotFirstInBodyMode, isNotFirstInSuperMode);
//                Logger.e(Logger.DEBUG_TAG, "RunMainActivity inCoachModeAllTime:" + inCoachModeAllTime + " inZoneTime:" + inZoneTime +
//                        " lowZoneTime:" + lowZoneTime + " upZoneTime:" + upZoneTime + " superZoneTime:" + superZoneTime + " isNotFirstInHotMode:" + isNotFirstInHotMode);
//                Logger.e(Logger.DEBUG_TAG, " isNotFirstInFatMode:" + isNotFirstInFatMode + " isNotFirstInHeartLungMode:" + isNotFirstInHeartLungMode +
//                        " isNotFirstInBodyMode:" + isNotFirstInBodyMode + " isNotFirstInSuperMode:" + isNotFirstInSuperMode);
            }

        }
    };

    private HeartRateService heartRateService;

    /**
     * 获取心率服务
     */
    public HeartRateService getHeartRateService() {
        return heartRateService;
    }

    private ServiceConnection heartRateServiceConnection;

//    /**
//     * 运动开始前发送运动相关设置指令
//     */
//    private void sendClearSportDataCmd() {
//        if (heartRateService == null) {
//            return;
//        }
//        if (heartRateService.getDevice() != null) {
//            if (heartRateService.getDevice().getName().contains("H10")) {
//                if (heartRateService.getWatchManager() != null) {
//                    heartRateService.getWatchManager().sendHRCmd(4);
//                }
//            }
//        }
//    }

    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);
        heartRateServiceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService == null)
                    return;

                //静息心率,数据库搜索最近一次的静息心率记录
                RestHeartRate info = RestHeartRateHelper.getInstance().getLatestHeartRateInfo(UserDataManager.getUid());
                heartRateService.setLatestRestHeartRate((info != null && info.getHeart_rate_record() != null) ? info.getHeart_rate_record() : Config.HEART_RATE_DEFAULT_REST_HR);

                heartRateService.setIfBindWithRunMain(true);
                heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);
//                sendClearSportDataCmd();//TODO 一开始就发送清空心率耳机统计数据的命令

                if (runService != null && runService.isInRunDuration()) {//运动中
                    if (heartRateService != null) {
                        getHeartRateService().searchHeartRateListHistory();
                    }
                    pushHeartRateFragment();
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };

        bindService(intent, heartRateServiceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (heartRateService != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                heartRateService.removeHeartRateItem(mPageName);
            }
        }
        if (heartRateServiceConnection != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(heartRateServiceConnection);
            }
        }
        heartRateServiceConnection = null;
    }

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Intent i = new Intent(this, HeartRateService.class);
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity --->  startHeartRateService()");
        startService(i);
    }

    /**
     * 播报LAVA耳机连接成功后的语音
     */
    private void playLAVAConnectedVoice() {
        if (getRunService() != null) {
            getRunService().playLAVAConnectedVoice();
        }
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity --->stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    /**
     * UI界面上更新心率数值
     *
     * @return
     */
    public int getLatestHeartRate() {
        if (heartRateService != null && heartRateService.getDevice() != null) {
            return heartRateService.getLatestHeartRate();
        } else { // 设备断开情况
            return 0;
        }
    }

    //endregion ====================================== 与HeartRateService交互相关 ======================================

    //region ====================================== Activity 生命周期相关 ======================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity,onCreate()");
        super.onCreate(savedInstanceState);
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_run_main);
        setPageName("RunMainActivity");

        //Android 6.0申请权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            getPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.BODY_SENSORS,
                    Manifest.permission.ACCESS_FINE_LOCATION});
        }

        if (PlayerController.getInstance().isMusicPlaying()) {//正在播放音乐
            PlayerController.getInstance().pauseMusic();
            bMusicPlayed = true;
        } else {
            PlayerController.getInstance().stopMusic();
        }

        initViews();
        init(savedInstanceState);

    }

    /**
     * 添加主跑界面音乐fragment
     */
    private void addMusicFragment() {
        mainMusicFragment = new RunMainMusicFragment();
        //音乐播放按钮状态监听
        mainMusicFragment.setMusicPlayControlChangeListener(new RunMainMusicFragment.OnMusicPlayControlChangeListener() {
            @Override
            public void onCheckedChanged(boolean isPlaying) {
                Music info = getMyConfig().getPlayer().getCurrentMusic();
                if (isPlaying) {
                    pauseMusic();
                    if (info != null) {
                        UmengAnalysisHelper.getInstance().musicReportPlus(RunMainActivity.this, "运动中音乐暂停", info.getId());
                    }
                } else {
                    playMusic();
                    if (info != null) {
                        UmengAnalysisHelper.getInstance().musicReportPlus(RunMainActivity.this, "运动中音乐继续", info.getId());
                    }
                }
            }
        });
        //节拍器选择回调事件
        mainMusicFragment.setMetronomeSelectedListener(new RunMainMusicFragment.OnMetronomeSelectedListener() {
            @Override
            public void onMetronomeSelected(int index, String value) {
                int dpm = 0;
                if ((value != null) && (!TextUtils.isEmpty(value)))
                    try {
                        dpm = Integer.parseInt(value);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                setMetronome(dpm);
            }
        });
        getSupportFragmentManager().beginTransaction()
                .add(R.id.run_main_container, mainMusicFragment, RunMainMusicFragment.TAG).commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity-->onResume");
        getHandler().sendEmptyMessageDelayed(Config.MSG_REPEAT_EVERY_SECOND, 1000);
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity-->onResumeFragments mainMusicFragment is null:" + (mainMusicFragment == null)
                + ",runService is null:" + (runService == null) + ",runId:" + (runService != null ? runService.getRunStartTime() : "n/a"));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://切换到音乐fragment,只需要移除并切换回之前的toolbar即可
                removeMapFragment();
                break;
        }
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        /** V2.0.3 java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState*/
        if (outState != null) {
            //finishFragment不为空,说明运动已结束
            if (finishFragment != null) {
                outState.putInt("sportState", 2);
            } else {
                outState.putInt("sportState", 1);
            }
            if (getRunLog() != null) {
                outState.putLong("runId", getRunLog().getStartTime());
            }
        }
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity-->onSaveInstanceState outState:" + outState + ",sportState:" + outState.getInt("sportState"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity-->onPause");
        getHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);
    }

    @Override
    protected void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "RunMainActivity,onDestroy()");
        super.onDestroy();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
        if (loadingDialog != null) {
            loadingDialog.dismiss();
        }
        loadingDialog = null;
        disconnectToHeartRateService();
        disconnectToRunService();
        releaseResource();
    }

    @Override
    protected void onMusicChanged() {
        super.onMusicChanged();
        this.mMusicInfo = PlayerController.getInstance().getCurrentMusic();
        if( mMusicInfo != null && mainMusicFragment != null){
            mainMusicFragment.refreshMusicInfo();
        }
    }

    /**
     * 初始化
     */
    private void init(Bundle savedInstanceState) {
        /**
         * bug:长时间运动过程中,RunMainActivity以及PersonInfo中的uid可能会被回收,造成用户查看运动或想结束运动时,提示未登录
         * 原因:内存中的变量随时会被回收
         * */
        //1.检查当前运动用户UID是否有效
        int uid = UserDataManager.getUid();
        if (uid < 0) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.login_the_sport)
                    .positiveText(android.R.string.ok)
                    .cancelable(false)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            finish();
                        }
                    }).show();
            return;
        }
        //2.获取音乐信息和运动计划
        Intent intent = getIntent();
        if (intent == null)
            return;

        String musicString = intent.getStringExtra("musicInfo");
        fromWatchRunService = intent.getBooleanExtra("fromWatchRunService", false);
        if (!TextUtils.isEmpty(musicString)) {
            mMusicInfo = JsonHelper.getObject(musicString, Music.class);
            Logger.d(Logger.DEBUG_TAG, "music name:" + mMusicInfo.getName());
        }
        if (mMusicInfo == null) {
            if (PlayerController.getInstance().getIsActionPlay()) {
                PlayerController.getInstance().pauseMusic();
            }
        }
        taskObject = intent.getLongExtra("taskObject", 0);
        taskType = intent.getIntExtra("taskType", 0);

        //3.判断activity被回收时运动完成还是仍在运动,仍在运动则显示RunMainMusicFragment
        // 否则显示RunMainFinishFragment
        if (savedInstanceState != null) {
            if (savedInstanceState.getInt("sportState") == 2) {//最后在运动结束fragment,activity被回收
                long runId = savedInstanceState.getLong("runId");
                recoveryFinishShare(uid, runId);
                return;
            }
        }

        addMusicFragment();
        //4.绑定主跑服务
        connectToRunService();
        //5.绑定心率服务
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {//ble
            connectToHeartRateService();
        }

    }

    protected void initViews() {
        //toolbar 初始化RunMainMusicFragment
        run_main_container = (FrameLayout) findViewById(R.id.run_main_container);

        slideButton = (SlideButton) findViewById(R.id.slideButton);
        slideListener = new SlideButton.OnSlideListener() {
            @Override
            public void onSlide() {//滑动暂停事件
                pauseRun(false);
            }
        };
        slideButton.setOnSlideListener(slideListener);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        if (requestId == (Config.MODULE_USER + 24)) {//向后台服务器发送用户统计数据
            return;//不需要从数据库查询请求结果
        }
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //V2.3.6仿咕咚流程后不再需要
    }

    @Override
    protected void processReqError(int requestId, String error) {
        hideLoadingDialog();
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 24://用户统计不提示
                    break;
            }
        }
    }

    /**
     * 启动跑步记录详情界面
     *
     * @param uid          跑步记录对应的用户uid
     * @param runStartTime 跑步记录的开始时间,单位为毫秒
     * @param environment  1:室外,2:室内
     */
    private void startRunRecordActivity(int uid, long runStartTime, int environment) {
//        Intent intent = new Intent(this, RunRecordActivity.class);
        Intent intent = new Intent(this, SportRecordDetailActivity.class);
        Bundle bundle = new Bundle();
        bundle.putInt("uid", uid);
        bundle.putLong("startTime", runStartTime);
        bundle.putInt("environment", environment);
        bundle.putInt("dataSource", 0);
        bundle.putBoolean("fromRunMain", true);

        intent.putExtras(bundle);
        startActivity(intent);
        finish();//销毁activity
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
    }

    //endregion ====================================== Activity 生命周期相关 ======================================

    //region ====================================== 跑步相关 ======================================

    /**
     * 初始化倒计时控件
     */
    private void initCountDown() {
        anim_count_down = AnimationUtils.loadAnimation(this, R.anim.count_down);
        viewCountDownGroup = findViewById(R.id.count_down_group);
        textCountDown = (TextView) findViewById(R.id.count_down_text);
        viewCountDownGroup.setVisibility(View.VISIBLE);
        int toneType = SettingsHelper.getInt(Config.SETTING_SIRI_TONE_TYPE, Config.SIRI_TONE_TYPE_FEMALE);
        if (getRunService() != null) {//设置语调
            getRunService().getVoiceManager().setToneType(toneType);
        }
    }

    /**
     * 开始运动前判断
     */
    private void startCountDown() {
        if (getRunService() == null)
            return;

        //1.上一次运动正常结束,则开启新的运动
        if (getRunService().isLastRunFinished()) {
            initCountDown();
            startCountDownTimer();
            userBehaviorStat();
        } else {//上一次非正常结束
            if (SportRecordsHelper.getUncompletedRunRecords(this, UserDataManager.getUid(), getRunService().getRunStartTime()) == null) {
                //但是上一次的运动记录为空,(原因1.上一次不满足数据库操作的要求：运动距离没有超过100米,),因此重新新的运动
                getRunService().setRunFinishFlag(true);
                getRunService().clearRunData();
                getRunService().setRunFinishFlag(true);
                initCountDown();
                startCountDownTimer();
                userBehaviorStat();
                return;
            }

            long now = System.currentTimeMillis();
            long old = getRunService().getRunLogInfo().getEndTime();
            if (old == 0) {//上一次记录非正常结束,并且运动距离小于100米时,endTime还未更新
                old = PrefsHelper.with(this, Config.PREFS_SPORT).readLong(Config.SP_KEY_START_TIME);
//                old = getRunService().getRunLogInfo().getStartTime();
            }
            if (fromWatchRunService) {//进程死掉后直接继续运动
                getRunService().setRunFinishFlag(true);
                getRunService().clearRunData();
                getRunService().setRunFinishFlag(true);
                initCountDown();
                startCountDownTimer();
                //playMusic();
                userBehaviorStat();
            } else {
                new MaterialDialog.Builder(this)
                        .title(R.string.information)
                        .content(FormatUtil.formatRunTime((now - old) / 1000) + getResources().getString(R.string.run_log_recovery))
                        .positiveText(R.string.run_log_recovery_new)
                        .negativeText(R.string.run_log_recovery_continue)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        getRunService().setRunFinishFlag(true);
                                        getRunService().clearRunData();
                                        getRunService().setRunFinishFlag(true);
                                        initCountDown();
                                        startCountDownTimer();
                                        //playMusic();
                                        userBehaviorStat();
                                        break;
                                    case NEGATIVE:
                                        getRunService().setRunFinishFlag(false);
                                        runStart();
                                        //playMusic();
                                        break;
                                }
                            }
                        }).show();
            }

        }
    }

    /**
     * 开始运动倒计时
     */
    private void startCountDownTimer() {
        SettingsHelper.putBoolean(Config.SP_KEY_RUNNING_IF_KILLED,false);
        if (mCountDownTime < 0)
            return;
        if (mCountDownTime > 0) {
            textCountDown.setText(String.valueOf(mCountDownTime));
        } else {
            textCountDown.setText("GO");
        }
        //语音播报321 GO并设置音调
        if ((getRunService() != null) && (mCountDownTime == 3)) {
            boolean sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
            if (sportWithVoice) {
                if (getHeartRateService() != null && getHeartRateService().getDevice() != null) {
                    getRunService().getVoiceManager().playCounterDownAndHeartRateMessage();
                } else {
                    getRunService().getVoiceManager().playCounterDown();
                }

            }
        }
        if (anim_count_down != null)
            anim_count_down.cancel();
        if (viewCountDownGroup != null)
            viewCountDownGroup.startAnimation(anim_count_down);
        getHandler().sendEmptyMessageDelayed(Config.MSG_ANIMATION_TIMER, 1000);
    }

    /**
     * 处理运动开始倒计时动画
     */
    private void processAnimation() {
        mCountDownTime--;
        if (mCountDownTime < 0) {
            runStart();
        } else {
            startCountDownTimer();
        }
    }

    /**
     * 开始运动
     */
    private void runStart() {
        if (viewCountDownGroup != null)
            viewCountDownGroup.setVisibility(View.GONE);
        if (getRunService() == null) {
            return;
        }

       // WatchRunService.isRunning = true;
        WatchRunService.setRunningStatus(true);
        playMusic();

        if (heartRateService != null) {
            getHeartRateService().startExercise();
        }

        if (!runService.isInRunDuration()) {
            getRunService().startRun();
        }

        if (taskType == RunSettingBaseFragment.TASK_TYPE_PACE) {
            //根据配速算步频
            if (getMusicInfo() == null && mainMusicFragment != null) {//当前没有音乐,并且是节拍器有效时
                int height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
                if (height == 0) {
                    height = Config.USER_DEFAULT_HEIGHT;
                }
                if (taskObject > 0 && height > 0) {
                    int bpm = ExpectancyTable.getFitBpmByPace(height, (int) taskObject);
                    mainMusicFragment.playMetronome(bpm);
                }
            }
        }
        pushHeartRateFragment();
    }

    /**
     * 运动继续
     */
    public void runContinue() {
        if (getRunService() == null)
            return;
        getRunService().continueRun();


        if (getHeartRateService() != null) {
            getHeartRateService().continueExercise();
        }
        continueVoice();
        if (slideButton != null && slideButton.getVisibility() == View.GONE) {
            slideButton.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 运动暂停
     *
     * @param bHideDialog 是否隐藏继续运动和暂停运动的对话框
     */
    public void pauseRun(boolean bHideDialog) {
        if (getRunService() == null) {
            return;
        }
        getRunService().pauseRun();

        if (getHeartRateService() != null) {
            getHeartRateService().pauseExercise();
        }

        pauseVoice();
        if (!bHideDialog) {
            /** 解决bug: java.lang.NullPointerException: Attempt to invoke virtual method 'void com.fitmix.sdk.view.widget.SlideButton.setVisibility(int)'
             * on a null object reference*/
            if (slideButton != null) {
                slideButton.setVisibility(View.GONE);//隐藏滑动暂停
            }
            final ContinueFinishDialog dialog = new ContinueFinishDialog(RunMainActivity.this,
                    new ContinueFinishDialog.OnButtonClickListener() {
                        @Override
                        public void sportContinue() {
                            RunMainActivity.this.runContinue();
                            if (slideButton != null) {
                                slideButton.setVisibility(View.VISIBLE);//显示滑动暂停
                            }
                        }

                        @Override
                        public void sportFinish() {
                            RunMainActivity.this.runFinish();
                        }
                    });
            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    dialog.dismiss();
                    runContinue();
                }
            });
            dialog.show();
        }
    }

    /**
     * 运动结束
     */
    private void runFinish() {
        if (getRunService() == null)
            return;
        if (handlingRunFinish) {
            return;
        }
       //  WatchRunService.isRunning = false;
        WatchRunService.setRunningStatus(false);
        handlingRunFinish = true;
        //1.停止音乐和节拍器
        stopVoice();
        //2.停止运动
        final int uid = UserDataManager.getUid();
        final long runId = getRunService().getRunStartTime();
        stepFileName = Config.PATH_DOWN_STEP + uid + "_" + runId + ".step";
        trailFileName = Config.PATH_DOWN_TRAIL + uid + "_" + runId + ".json";

        //3.停止RunMainActivity的每秒刷新
        getHandler().removeMessages(Config.MSG_REPEAT_EVERY_SECOND);

        //两服务的停止顺序不可颠倒,因为心率数据的写文件操作在跑步服务的写文件模块中
        if (getHeartRateService() != null) {
            getHeartRateService().stopExercise();
            //只有当正常运动结束时才设为false。当RunMainActivity在运动过程中被销毁时，解绑心率服务不执行setIfBindWithRunMain(false)，因为该标示代表心率服务下跑步界面特有的功能
            heartRateService.setIfBindWithRunMain(false);
            Logger.d(Logger.DEBUG_TAG, "runFinish sportT:" + getHeartRateService().getCurrentZoneTime());
            getRunService().stopRun(getHeartRateService().getCurrentZoneTime());
//            Logger.e(Logger.DEBUG_TAG, "runFinish allTime:" + allTime);
        }


        //4.运动时长小于1秒,或者运动距离小于100米并且步数小于200步,给用户提示并不保存记录
        boolean quitSave = false;
        if (getRunService().getRunTime() <= 1000 || getRunService().getRunDistance() <= 0) {
            quitSave = true;
        }
        if ((getRunService().getRunDistance() < 100)
                && (getRunService().getRunSteps() <= 200)) {
            quitSave = true;
        }
        SettingsHelper.putBoolean(Config.SP_KEY_RUNNING_IF_KILLED,false);
        if (quitSave) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.activity_runmain_distance_too_short)
                    .positiveText(R.string.i_know)
                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            SportRecordsHelper.asyncDeleteRunRecord(RunMainActivity.this, uid, runId, null);
                            FileUtils.deleteFile(stepFileName);
                            FileUtils.deleteFile(trailFileName);
                            stopRunServiceWhenDaemonStepOff();
                            dialog.dismiss();
                            finish();//结束Activity

                        }
                    }).cancelable(false).show();
            return;
        }
        refreshRunStatisticsInfo(true);
        removeMapFragmentDirect();
        runFinishShare(uid, runId);
        stopRunServiceWhenDaemonStepOff();
    }

    private void releaseResource() {
        if (anim_count_down != null) {
            anim_count_down.cancel();
            anim_count_down = null;
        }
        if (viewCountDownGroup != null)
            viewCountDownGroup.clearAnimation();
        viewCountDownGroup = null;
        mCountDownTime = 0;
        mainMusicFragment = null;
        mainMapFragment = null;
        finishFragment = null;
        PlayerController.getInstance().stopMusic();

        //心率相关资源清除
        historyHRList = null;
        needToAddHistoryHR = false;
        userHeartRateFinish = null;
    }

    /**
     * 没开启后台计步时,销毁主跑服务
     */
    private void stopRunServiceWhenDaemonStepOff() {
        boolean daemonStepCount = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        if (!daemonStepCount) {//没开启后台计步时,销毁主跑服务
            Intent intent = new Intent(this, RunService.class);
            stopService(intent);
        }
    }

    /**
     * 用户行为统计
     */
    private void userBehaviorStat() {
        int mid = -1;
        if (getMusicInfo() != null)
            mid = getMusicInfo().getId();
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().reportUserBehavior(uid, mid, 2, 0, 0);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 判断是否息屏
     *
     * @return
     */
    private boolean ifScreenOff() {
        if (getRunService() != null) {
            return getRunService().isScreenOff();
        }
        return false;
    }

    /**
     * 刷新界面上的跑步信息
     */
    private void refreshRunInfo() {
        if (getRunService() == null || getRunLog() == null)
            return;

        //1.刷新界面信息
        String sRunTime = FormatUtil.formatRunTime(getRunLog().getRunTime() / 1000);
        String sRunDistance = FormatUtil.formatDistance(getRunLog().getDistance());
        long calorie = getRunLog().getCalorie();
        int steps = getRunLog().getStep();
        String speed = FormatUtil.formatSpeedUseInRunMainActivity(getRunService().getRunSpeed());
        String pace = String.valueOf(getRunService().getRunBpm());
        if (mainMusicFragment != null && !mainMusicFragment.isHidden()) {
            mainMusicFragment.setRunDuration(sRunTime);
            mainMusicFragment.setRunDistance(sRunDistance);
            mainMusicFragment.setRunCalorie(String.valueOf(calorie));
            mainMusicFragment.setRunSpeed(speed);
            mainMusicFragment.setHeartRate(getLatestHeartRate());
            mainMusicFragment.setRunPace(pace);
            mainMusicFragment.setGpsSignal(getRunService().getGpsSignalLevel());
            mainMusicFragment.setPlayingTime();
//            mainMusicFragment.setTestString(getRunService().getTestString());
        }
        if (mainMapFragment != null && mainMapFragment.isVisible()) {
            mainMapFragment.setRunDuration(sRunTime);
            mainMapFragment.setRunDistance(sRunDistance);
            mainMapFragment.setRunStep(String.valueOf(steps));
            mainMapFragment.setRunCalorie(String.valueOf(calorie));
            mainMapFragment.setRunSpeed(speed);
            mainMapFragment.refreshMapTrail(getRunService().getLocationPoint());
        }
        if (mainHeartRateFragment != null && mainHeartRateFragment.isAdded() && mainHeartRateFragment.isVisible()) {
            mainHeartRateFragment.setRunDuration(sRunTime);
            mainHeartRateFragment.setPace(speed);
            mainHeartRateFragment.setDistance(sRunDistance);
            mainHeartRateFragment.setCalorie(String.valueOf(calorie));
            if (getHeartRateService() != null) {
                mainHeartRateFragment.setMaxVo2(getHeartRateService().getTheMaxVo2());
            }
            if (getRunService() != null) {
                if (getHeartRateService() != null) {
                    mainHeartRateFragment.setFatBurn(getRunService().getFatBurn(), getLatestHeartRate(), getHeartRateService() != null ? getHeartRateService().getLatestRestHeartRate() : Config.HEART_RATE_DEFAULT_REST_HR);
                } else {
                    mainHeartRateFragment.setFatBurn(getRunService().getFatBurn());
                }
            }
        }
        //2.检测任务计划
        if ((!bTaskComplete) && getRunService().isTaskComplete()) {
            bTaskComplete = true;
            String sItemFormat = getResources().getString(R.string.task_complete);
            String sContent = String.format(sItemFormat, getTaskString());

            new MaterialDialog.Builder(this)
                    .title(R.string.information)
                    .content(sContent)
                    .positiveText(R.string.i_know)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                        }
                    }).show();
        }
    }

    /**
     * 刷新运动总数据(运动时长,卡路里,步数,距离)
     *
     * @param bAdd 是否增加数量
     */
    private void refreshRunStatisticsInfo(boolean bAdd) {
        RunLogInfo runLogInfo = null;
        if (getRunService() != null)
            runLogInfo = getRunService().getRunLogInfo();
        if (runLogInfo == null)
            return;

        if (bAdd) {
            //1.更新在登录接口结果中的个人信息(运动总时长、总消耗、总步数、总距离)
            int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
            int requestId = -1;
            if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
                requestId = UserDataManager.getInstance().generateRequestId(2);
            } else if (loginType == 2) {//表示QQ授权登录
                requestId = UserDataManager.getInstance().generateRequestId(3);
            } else if (loginType == 3) {//表示微信授权登录
                requestId = UserDataManager.getInstance().generateRequestId(5);
            } else if (loginType == 4) {//表示新浪微博授权登录
                requestId = UserDataManager.getInstance().generateRequestId(4);
            }
            if (requestId > 0) {
                DataReqStatus dataReqStatus = DataReqStatusHelper.getInstance().getDataReqStatusById(requestId);
                if (dataReqStatus != null) {
                    String result = dataReqStatus.getResult();
                    Login login = JsonHelper.getObject(result, Login.class);
                    if (login != null && login.getUser() != null) {
                        long totalRunTime = login.getUser().getRunTime() + (runLogInfo.getRunTime() / 60000);//单位为分钟
                        login.getUser().setRunTime(totalRunTime);
                        long totalCalorie = login.getUser().getCalorie() + runLogInfo.getCalorie();
                        login.getUser().setCalorie(totalCalorie);
                        long totalDistance = login.getUser().getDistance() + runLogInfo.getDistance();
                        login.getUser().setDistance(totalDistance);
                        long totalSteps = login.getUser().getStep() + runLogInfo.getStep();
                        login.getUser().setStep(totalSteps);
                        //心率相关数据更新,如果当前运动记录的时间大于上一次静息心率记录的时间,则更新
                        if (!TextUtils.isEmpty(runLogInfo.getHeartRateDate())) {//当前记录有心率记录
                            UserHeartRate userData_new = JsonHelper.getObject(runLogInfo.getHeartRateDate(), UserHeartRate.class);
                            if (userData_new != null) {
                                if (login.getUser().getLastRunHeartRate() != null) {//上一次有心率记录
                                    UserHeartRate userDataOld = login.getUser().getLastRunHeartRate();
                                    if (userDataOld != null && userDataOld.getLastUpdated() < userData_new.getLastUpdated()) {
                                        login.getUser().setLastRunHeartRate(userData_new);
                                    }
                                } else {
                                    login.getUser().setLastRunHeartRate(userData_new);
                                }
                            }
                        }
                        login.getUser().setConsumeFatSum(login.getUser().getConsumeFatSum() + runLogInfo.getConsumeFat());//脂肪燃烧量增加
                        String newResult = JsonHelper.createJsonString(login);
                        if (!TextUtils.isEmpty(newResult)) {
                            dataReqStatus.setResult(newResult);
                            DataReqStatusHelper.getInstance().updateDataReqStatus(dataReqStatus);
                        }
                    }
                }
            }

        }
//        else { //TODO
//            RunLogInfo tempInfo = new RunLogInfo();
//            tempInfo.setCalorie(-runLogInfo.getCalorie());
//            tempInfo.setRunTime(-runLogInfo.getRunTime());
//            tempInfo.setDistance(-runLogInfo.getDistance());
//            tempInfo.setStep(-runLogInfo.getStep());
//        }
    }

    //endregion ====================================== 跑步相关 ======================================

    //region ====================================== RunMainMusic相关 ======================================

    public void switchToMusic() {
        if (getRunService() == null)
            return;
        VoiceManager voiceManager = getRunService().getVoiceManager();
        voiceManager.stopMetronome();
        playMusic();
    }

    public void switchToMetronome(int bpm) {
        if (getRunService() == null)
            return;
        pauseMusic();
        VoiceManager voiceManager = getRunService().getVoiceManager();
//        voiceManager.setMetronomeDpm(bpm);
//        voiceManager.startMetronome();
        voiceManager.runMetronome(bpm);
    }

    private void checkStartPlay() {
        if (bMusicPlayed)
            return;
        if (getMusicInfo() == null)
            return;

        if (getMusicInfo().getLocalFlag() == 1) {
            startPlayMusic();
            return;
        }
        if ((!FitmixUtil.isExistCacheFile(getMusicInfo().getUrl(), getMusicInfo().getId(),
                Config.DOWNLOAD_FORMAT_MUSIC) && MixApp.getProxy(this) != null && !MixApp.getProxy(this).isCached(getMusicInfo().getUrl()))) {

            String sLocalFile = FitmixUtil.getTempMusicPath(getMusicInfo());

            if (FitmixUtil.checkMusicDownloadParamValid(sLocalFile, true)) {
                showAppMessage(getResources()
                        .getText(R.string.activity_play_music_play_downloading_music).toString(), AppMsg.STYLE_CONFIRM);

            } else {
                if (!FitmixUtil.checkNetworkStateForMusic(getMusicInfo())) {
                    showAppMessage(getResources()
                            .getText(R.string.check_network).toString(), AppMsg.STYLE_CONFIRM);
                    return;
                }
                if (ApiUtils.getNetworkType() != Config.NETWORK_TYPE_WIFI) {
                    /** bug v2.0.3 com.fitmix.sdk.dialog.material.MaterialDialog$DialogException:
                     //Bad window token, you cannot show a dialog before an Activity is
                     created or after it's hidden.*/
                    new MaterialDialog.Builder(this)//页面消失后弹框失败
                            .title(R.string.warning)
                            .content(R.string.downstream_control)
                            .positiveText(android.R.string.ok)
                            .negativeText(R.string.cancel)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            startPlayMusic();//非WIFI环境下,播放音乐
                                            break;
                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                    return;
                }
            }
        }
        startPlayMusic();
    }

    private void playMusic() {
        if (!checkMusicReady())
            return;
        if ((!FitmixUtil.isExistCacheFile(getMusicInfo().getUrl(), getMusicInfo().getId(),
                Config.DOWNLOAD_FORMAT_MUSIC) && MixApp.getProxy(this) != null && !MixApp.getProxy(this).isCached(getMusicInfo().getUrl()))) {
            String sLocalFile = FitmixUtil.getTempMusicPath(getMusicInfo());

            if (FitmixUtil.checkMusicDownloadParamValid(sLocalFile, true)) {
                showAppMessage(R.string.activity_play_music_play_downloading_music, AppMsg.STYLE_INFO);
            } else {
                if (!FitmixUtil.checkNetworkStateForMusic(getMusicInfo())) {
                    showAppMessage(R.string.check_network, AppMsg.STYLE_CONFIRM);
                }
            }
        }
        if (!bMusicPlayed) {
            checkStartPlay();
        } else {
            if (getMyConfig().getPlayer().getIsActionPlay())
                return;
            getMyConfig().getPlayer().resumeMusic();
        }
    }

    private void pauseMusic() {
        if (!checkMusicReady())
            return;
        if (!getMyConfig().getPlayer().getIsActionPlay())
            return;
        getMyConfig().getPlayer().pauseMusic();
    }

    private void startPlayMusic() {
        if (!checkMusicReady())
            return;
        if (getMyConfig().getPlayer().getIsActionPlay()) {
            getMyConfig().getPlayer().stopMusic();
        }
        if (getMusicInfo() == null) return;
        getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);// XXX
        getMyConfig().getPlayer().playMusic(getMusicInfo(), true);
        bMusicPlayed = true;
    }



    private boolean checkMusicReady() {
        return getMusicInfo() != null;
    }

    private void playPauseMusic() {
        if (!checkMusicReady())
            return;
        if (!bMusicPlayed) {
            checkStartPlay();
        } else {
            if (getMyConfig().getPlayer().getIsActionPlay()) {
                pauseMusic();
            } else {
                playMusic();
            }
        }
    }

    private void playNextSegment() {
        getMyConfig().getPlayer().playNextSegment();

    }

    /**
     * 暂停播放音乐或节拍器
     */
    private void pauseVoice() {
        if (bUseMetronome) {
            if (getRunService() != null)
                getRunService().getVoiceManager().stopMetronome();
        } else {
            pauseMusic();
        }
    }

    private void stopVoice() {
        if (getRunService() != null)
            getRunService().getVoiceManager().stopMetronome();
        PlayerController.getInstance().stopMusic();
    }

    /**
     * 继续播放音乐或节拍器
     */
    private void continueVoice() {
        if (bUseMetronome) {
            if (getRunService() != null)
                getRunService().getVoiceManager().startMetronome();
        } else {
            playMusic();
        }
    }

    /**
     * 设置节拍器节奏
     *
     * @param dpm 节拍
     */
    private void setMetronome(int dpm) {
        if ((getRunService() == null)
                || (getRunService().getVoiceManager() == null))
            return;
        getRunService().getVoiceManager().runMetronome(dpm);
    }

    /**
     * 设置是否节拍器模式
     *
     * @param useMetronome 是否节拍器模式
     */
    public void setUseMetronome(boolean useMetronome) {
        bUseMetronome = useMetronome;
    }

    /**
     * 导航选择音乐列表
     */
    private void gotoMusicList() {
        Intent intent = new Intent(this, CreatePlaylistActivity.class);
        intent.putExtra("single", true);
        startActivityForResult(intent, REQUEST_SELECT_MUSIC);
    }

    /**
     * 播放选择的音乐
     */
    private void loadMusicBySelectId() {
        //mMusicInfo = getMyConfig().getMemExchange().getCurrentMusic();
        bMusicPlayed = false;
        playMusic();
    }

    //endregion ====================================== RunMainMusic相关 ======================================

    //region ====================================== RunMainMap相关 ======================================

    @Override
    public void destroyMapFragment() {
        removeMapFragment();
    }

    /**
     * 显示map fragment
     */
    public void pushMapFragment() {
        if (mainMapFragment == null) {
            mainMapFragment = new RunMainMapFragment();
            mainMapFragment.setFragmentBack(this);//设置回调
            if (getRunService() != null) {
                int uid = UserDataManager.getUid();
                long runStartTime = getRunService().getRunStartTime();
                Bundle bundle = new Bundle();
                bundle.putInt("uid", uid);
                bundle.putLong("runStartTime", runStartTime);
                mainMapFragment.setArguments(bundle);
            }
        }

        /**
         * 解决bug
         * java.lang.IllegalStateException: Fragment already added: RunMainMapFragment
         * */
        if (mainMapFragment.isAdded() || mainMapFragment.isVisible()) {
            return;
        }

        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .addToBackStack(null)
                    .setCustomAnimations(0, R.anim.push_right_out)
                    .add(R.id.run_main_container, mainMapFragment, RunMainMapFragment.TAG)
                    .commit();
        }
    }

    /**
     * 销毁map fragment
     */
    public void removeMapFragmentDirect() {
        final Fragment mapFragment = getSupportFragmentManager().findFragmentByTag(RunMainMapFragment.TAG);
        if (mapFragment == null) return;
        run_main_container.setVisibility(View.VISIBLE);
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .remove(mapFragment).commitAllowingStateLoss();//允许保持状态后提交
        }
        mainMapFragment = null;
    }

    /**
     * 销毁map fragment
     */
    public void removeMapFragment() {
        final Fragment mapFragment = getSupportFragmentManager().findFragmentByTag(RunMainMapFragment.TAG);
        if (mapFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .remove(mapFragment).commit();
        }
    }

    //endregion ====================================== RunMainMap相关 ======================================

    //region ====================================== HeartRateFragment相关 ======================================

    private boolean needToAddHistoryHR;
    private List<HeartRateChartInfo> historyHRList;
    private boolean heartRateFragmentIsHide = true;

    @Override
    public void destroyHeartRateFragment() {
        hideHeartRateFragment();
    }

    /**
     * 显示 mainHeartRateFragment
     */
    public void pushHeartRateFragment() {
        if (mainHeartRateFragment == null) {
            mainHeartRateFragment = new HeartRateFragment();
            mainHeartRateFragment.setFragmentBack(this);//设置回调
        }
        /**
         * 解决bug
         * java.lang.IllegalStateException: Fragment already added: RunMainMapFragment
         * */
        if (mainHeartRateFragment.isAdded()) {
            return;
        }
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .addToBackStack(null)
                    .setCustomAnimations(0, R.anim.push_right_out)
                    .add(R.id.run_main_container, mainHeartRateFragment, HeartRateFragment.TAG).hide(mainHeartRateFragment)
                    .commitAllowingStateLoss();
        }
    }

    /**
     * 恢复心率服务的相关UI,根据服务是否连接,UI变化
     */
    public void restoreHeartRateState() {
        //界面更新
        if (getHeartRateService() != null && getHeartRateService().getDevice() != null) {
            if (mainHeartRateFragment != null) {
                mainHeartRateFragment.gattCheckByProgram(true);
                if (getHeartRateService().getRefreshSignalStrength() != -1) {
                    mainHeartRateFragment.setSignalValue(getHeartRateService().getRefreshSignalStrength());
                }
            }
        } else {
            if (mainHeartRateFragment != null) {
                mainHeartRateFragment.gattCheckByProgram(false);
            }
        }
    }

    /**
     * 当HeartRateRecordFragment初始化完成后,恢复运动异常结束情况下心率点的绘制
     */
    public void restoreHeartRateRecordInfo() {
        if (needToAddHistoryHR) {
            if (mainHeartRateFragment != null) { //TODO 该fragment还没初始化,因此无法加入心率历史记录点
                if (historyHRList == null || historyHRList.size() == 0) {
                    return;
                }
                mainHeartRateFragment.addLineChartValueList(historyHRList, false);
                heartRateService.setRefreshTime(historyHRList.get(historyHRList.size() - 1).getTime());//心率历史记录的最后一点的时间戳作为运动的开始时间
                needToAddHistoryHR = false;
                historyHRList = null;
            }
        }
    }

    /**
     * 隐藏HeartRateFragment
     */
    public void hideHeartRateFragment() {
        Fragment musicFragment = getSupportFragmentManager().findFragmentByTag(RunMainMusicFragment.TAG);
        if (musicFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction().show(musicFragment).commit();
        }
        Fragment heartRateFragment = getSupportFragmentManager().findFragmentByTag(HeartRateFragment.TAG);
        if (heartRateFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .hide(heartRateFragment).commit();
            heartRateFragmentIsHide = true;
        }
    }

    /**
     * 显示HeartRateFragment
     */
    public void showHeartRateFragment() {
        Fragment heartRateFragment = getSupportFragmentManager().findFragmentByTag(HeartRateFragment.TAG);
        if (heartRateFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction().show(heartRateFragment).commit();
            heartRateFragmentIsHide = false;
        }
        Fragment musicFragment = getSupportFragmentManager().findFragmentByTag(RunMainMusicFragment.TAG);
        if (musicFragment != null && ftCanCommit) {
            getSupportFragmentManager().beginTransaction().hide(musicFragment).commit();
        }
    }

    //region ##################### BLEDialog相关 #####################

    //ScannerFragment的两个回调方法
    @Override
    public void onDeviceSelected(BluetoothDevice device, String name) {

        Logger.i("TT", "onDeviceSelected(),连接蓝牙,存下连接的蓝牙设备标示");
        if (heartRateService != null) {
            heartRateService.setDevice(device);
            if (heartRateService.getBleManager() != null) {
                heartRateService.getBleManager().disconnect();
//                heartRateService.getBleManager().setAutoConnect(false);//自动连接,连接比较慢,数据连接较稳定
                heartRateService.getBleManager().connect(device);
            }
        }

        Logger.i(Logger.DEBUG_TAG, device.getAddress());

    }

    @Override
    public void onDialogCanceled() {
    }


    //endregion ##################### BLEDialog相关 #####################

    //endregion ====================================== HeartRateFragment相关 ======================================

    //region ====================================== 训练计划相关 ======================================

    private String getTaskString() {
        String sResult = "";
        switch (taskType) {
            case RunSettingBaseFragment.TASK_TYPE_DISTANCE:
                sResult = getResources().getString(R.string.sport) + FormatUtil.formatDistance(taskObject) + getResources().getString(R.string.kilometer);
                break;
            case RunSettingBaseFragment.TASK_TYPE_TIME:
                sResult = getResources().getString(R.string.sport) + FormatUtil.formatRunTime(taskObject);
                break;
            case RunSettingBaseFragment.TASK_TYPE_CALORIE:
                sResult = getResources().getString(R.string.sport) + taskObject + getResources().getString(R.string.calorie);
                break;

        }
        return sResult;
    }

    //endregion ====================================== 训练计划相关 ======================================

    //region ====================================== RunMainFinish相关 ======================================

    /**
     * 运动完成并分享,替换RunMainFinishFragment
     *
     * @param uid   用户uid
     * @param runId 跑步编号
     */
    private void runFinishShare(int uid, long runId) {
        Logger.i(Logger.DEBUG_TAG, "runFinishShare uid:" + uid + ",runId:" + runId);
        if (finishFragment == null) {
            finishFragment = new RunMainFinishFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("uid", uid);
            bundle.putLong("runStartTime", runId);
            finishFragment.setArguments(bundle);
        }
        if (!isFinishing() && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out)
                    .replace(R.id.run_main_container, finishFragment, RunMainFinishFragment.TAG)
                    .commitAllowingStateLoss();//替换之前的RunMainMusic或RunMainMap fragment
            mainMusicFragment = null;
            mainMapFragment = null;
            mainHeartRateFragment = null;

            //隐藏滑动暂停按钮,并更改toolbar标题
            if (toolbar != null) {
                toolbar.removeAllViews();
                SimpleDateFormat formatter = new SimpleDateFormat(
                        "yyyy-MM-dd", Locale.getDefault());
                Date curDate = new Date(getRunService().getRunLogInfo().getStartTime());
                String sTime = formatter.format(curDate);
                setUiTitle(sTime);
            }

            if (slideButton != null) {
                slideButton.setVisibility(View.GONE);
                slideButton.setOnSlideListener(null);
                slideListener = null;
            }
            slideButton = null;
            showAppMessage(R.string.activity_runmain_save_record_busy, AppMsg.STYLE_INFO);//提示记录保存中
            UmengAnalysisHelper.getInstance().reportEventPlus(this, "运动记录已保存");
        }
    }

    /**
     * 恢复运动完成fragment
     *
     * @param uid   用户uid
     * @param runId 跑步编号
     */
    private void recoveryFinishShare(int uid, long runId) {
        Logger.i(Logger.DEBUG_TAG, "recoveryFinishShare uid:" + uid + ",runId:" + runId);
        if (finishFragment == null) {
            finishFragment = new RunMainFinishFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("uid", uid);
            bundle.putLong("runStartTime", runId);
            finishFragment.setArguments(bundle);
        }
        if (!isFinishing() && ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.run_main_container, finishFragment, RunMainFinishFragment.TAG)
                    .commitAllowingStateLoss();
            mainMusicFragment = null;
            mainMapFragment = null;

            //隐藏滑动暂停按钮,并更改toolbar标题
            if (toolbar != null) {
                toolbar.removeAllViews();
                SimpleDateFormat formatter = new SimpleDateFormat(
                        "yyyy-MM-dd", Locale.getDefault());
                Date curDate = new Date(getRunService().getRunLogInfo().getStartTime());
                String sTime = formatter.format(curDate);
                setUiTitle(sTime);
            }

            if (slideButton != null) {
                slideButton.setVisibility(View.GONE);
                slideButton.setOnSlideListener(null);
                slideListener = null;
            }
            slideButton = null;
        }

        //设置计步文件名称
        stepFileName = Config.PATH_DOWN_STEP + uid + "_" + runId + ".step";
    }

    /**
     * 根据数据库里查询出来的跑步记录结果,设置成上传运动记录所需要的实体
     */
    public void setRunLogInfo(SportRecord sportRecord) {
        if (sportRecord == null) {
            return;
        }
        mRunLogInfo = new RunLogInfo();
        mRunLogInfo.setUid(sportRecord.getUid());//用户ID
        mRunLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
        mRunLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
        mRunLogInfo.setType(sportRecord.getType());//运动类型(跑步,骑行),跑步为1
        mRunLogInfo.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
        mRunLogInfo.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
        mRunLogInfo.setLocationType(sportRecord.getLocationType());//定位类型,1:GPS定位,2:LBS定位
        mRunLogInfo.setDistance(sportRecord.getDistance());//运动距离,单位米
        mRunLogInfo.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
        mRunLogInfo.setStartLat(sportRecord.getStartLat());//开始点经度
        mRunLogInfo.setStartLng(sportRecord.getStartLng());//开始点经度
        mRunLogInfo.setEndLat(sportRecord.getEndLat());//结束点纬度
        mRunLogInfo.setEndLng(sportRecord.getEndLng());//结束点经度
        mRunLogInfo.setStep(sportRecord.getStep());//步数
        mRunLogInfo.setCalorie(sportRecord.getCalorie() == null ? 0 : sportRecord.getCalorie());//卡路里
        mRunLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
        mRunLogInfo.setConsumeFat(sportRecord.getConsumeFat() == null ? 0 : sportRecord.getConsumeFat());//脂肪燃烧克数
        mRunLogInfo.setHeartRateDate(sportRecord.getHeartRateDate());//心率数据

    }

    /**
     * 放弃跑步记录
     */
    private void quitRunRecord() {
        //deleteRunLogInLocale();
        refreshRunStatisticsInfo(false);
        finish();
    }

    /**
     * 保存并上传记录
     */
    private void saveRunRecordAndUpload() {
        //1.文件完整性验证
        if (!FileUtils.isStepFileCompleted(stepFileName)) {
            showAppMessage(R.string.activity_runmain_save_record_busy, AppMsg.STYLE_INFO);
            return;
        }
        //2.微信步数同步
        FitmixUtil.syncWeChatStep(this, true);
        //3.仿咕咚直接跳转到运动记录详情界面
        if (mRunLogInfo != null) {
            startRunRecordActivity(mRunLogInfo.getUid(), mRunLogInfo.getStartTime(), mRunLogInfo.getMode());
        }
    }

    //endregion ====================================== RunMainFinish相关 ======================================

    //region ====================================== 分享相关 ======================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case Config.REQUEST_ENABLE_GPS://运动开始前GPS权限请求
                startCountDown();
                break;
            case Config.BLE_REQUEST_ENABLE_GPS://BLE功能请求GPS权限
                if (RESULT_OK == resultCode) {//成功授权
                    if (mainHeartRateFragment != null && ftCanCommit) {
                        mainHeartRateFragment.showDeviceScanningDialog(HRSManager.HR_SERVICE_UUID);
                    }
                    return;
                }
                //GPS开启失败
                Toast.makeText(RunMainActivity.this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                break;
            case REQUEST_SELECT_MUSIC:
                if (resultCode == RESULT_OK) {
                    if (data == null) return;
                    String musicString = data.getStringExtra("musicString");
                    if (!TextUtils.isEmpty(musicString)) {
                        mMusicInfo = JsonHelper.getObject(musicString, Music.class);
                        if (mMusicInfo != null)
                            loadMusicBySelectId();
                    }
                }
                break;

            default:
                break;
        }

    }

    //endregion ====================================== 分享相关 ======================================

    public void doClick(View v) {
        switch (v.getId()) {
            ///////////////////////////// music fragment toolbar//////////////////////////////////////
            case R.id.btn_nav_map://切换到地图fragment
                pushMapFragment();
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "运动中查看地图");
                break;

            //只有在运动设置时选择了心率运动模式才显示
            case R.id.btn_heart_rate://心率
//                pushHeartRateFragment();
                if (heartRateFragmentIsHide) {
                    showHeartRateFragment();
                } else {
                    hideHeartRateFragment();
                }
                break;
            case R.id.btn_music_playlist://播放列表
                gotoMusicList();
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "运动中选择歌曲");
                break;

            case R.id.btn_music_forward://音乐快进
                playNextSegment();
                UmengAnalysisHelper.getInstance().reportEventPlus(this, "运动中音乐快进");
                break;

            ///////////////////////////// finish fragment toolbar///////////////////////////////////
            case R.id.btn_force_quit://放弃
                quitRunRecord();
                break;

            case R.id.btn_save_upload://保存并上传
                saveRunRecordAndUpload();
                break;

            case R.id.img_step_abnormal://步数异常标示图标点击
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.fm_runmain_finish_step_abnormal)
                        .positiveText(R.string.i_know)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(MaterialDialog dialog, DialogAction which) {
                                dialog.dismiss();
                            }
                        }).show();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if ((getRunService() != null) && getRunService().isInRunDuration()) {
            if (getRunService().isRunning()) {
                pauseRun(false);
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT://87
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS://88
            case KeyEvent.KEYCODE_MEDIA_PAUSE://127
            case KeyEvent.KEYCODE_MEDIA_PLAY://126
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE://85
            case KeyEvent.KEYCODE_HEADSETHOOK://79
                bResult = true;
                break;
        }
        if (!bResult)
            return super.onKeyDown(keyCode, event);
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        boolean bResult = false;
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                playNextSegment();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS://上一首,如果还在运动过程中,触发滑动暂停或继续
                if (runService != null) {
                    if (runService.isInRunDuration()) {//还在运动过程中
                        if (runService.isRunning()) {
                            pauseRun(true);//运动暂停,隐藏显示对话框,防止丢失key focus
                        } else {
                            runContinue();//运动继续
                        }
                    }
                }
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                pauseVoice();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                continueVoice();
                bResult = true;
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK:
                if (bUseMetronome) {
                    if (getRunService().getVoiceManager().isMetronomeWorking())
                        getRunService().getVoiceManager().stopMetronome();
                    else
                        getRunService().getVoiceManager().startMetronome();
                } else {
                    playPauseMusic();
                }
                bResult = true;
                break;
        }
        if (!bResult)
            return super.onKeyUp(keyCode, event);
        return true;
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        super.handlePermissionAllowed(permissionName);
        switch (permissionName) {
            case Manifest.permission.ACCESS_FINE_LOCATION:

                break;

            case Manifest.permission.WRITE_EXTERNAL_STORAGE:

                break;
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        super.handlePermissionForbidden(permissionName);
        switch (permissionName) {
            case Manifest.permission.ACCESS_FINE_LOCATION:

                break;

            case Manifest.permission.WRITE_EXTERNAL_STORAGE:

                break;
        }
    }

    @Override
    protected void clickToRun() {//该activity不做操作
    }
}
