package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.UserDevice;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.watch.bean.WatchInfo;

import java.util.List;


public class EquipmentActivity extends BaseActivity {

//    private String mBoltUrl;//B1耳机购买地址
//    private String mShineUrl;//E11耳机购买地址
//    private String mLightUrl;//G-light购买地址

    /**
     * 使用我的设备配对一次任务是否完成键值
     */
    public static final String INTENT_EXTRA_PAIR_BT_TASK = "coinTaskPairBt";

    /**
     * 金币任务,使用我的设备配对一次任务是否完成
     */
    private boolean coinTaskPairBtFinished;

    /**
     * 上一次点击时间戳
     */
    private long lastClickTime;

    private boolean sendBindCmd;//是否需要向手表发送绑定指令

    //region ======================================== Activity生命周期 ========================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equipment);
        setPageName("EquipmentActivity");
        if (getIntent() != null && getIntent().getExtras() != null){
            sendBindCmd = getIntent().getBooleanExtra("sendBindCmd",false);
        }

        initToolbar();
        initViews();
        getUserDevice();
        coinTaskPairBtFinished = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);
    }


    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
//            case Config.MODULE_USER + 1://App初始化
//                Init init = JsonHelper.getObject(dataReqResult.getResult(), Init.class);
//                if (init != null) {
//                    mBoltUrl = init.getBOLTPayAddress();
//                    mShineUrl = init.getSHINEPayAddress();
//                    mLightUrl = init.getLIGHTPayAddress();
//                }
//                break;
            case Config.MODULE_USER + 47://查找用户设备信息,例如用户购买的手表、耳机等等
                handleUserDevices(result);
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        //不处理
    }

    /**
     * 获取当前用户的智能设备信息
     */
    private void getUserDevice() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().findUserDevices(uid, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 处理用户设备信息
     */
    private void handleUserDevices(String result) {
        UserDevice userDevice = JsonHelper.getObject(result, UserDevice.class);
        if (userDevice != null) {
            List<UserDevice.SmartDevicesBean> smartDevices = userDevice.getSmartDevices();
            if (smartDevices != null) {
                UserDevice.SmartDevicesBean.DeviceInfoBean deviceInfo;
                String localMac, mac;
                if (smartDevices.size() == 0) {
                    SettingsHelper.putString(Config.SETTING_WATCH_INFO, "");//清除本地手表信息
                } else {
                    for (UserDevice.SmartDevicesBean smartDevice : smartDevices) {
                        if (smartDevice.getType() == 1) {//手表
                            deviceInfo = smartDevice.getDeviceInfo();
                            if (deviceInfo != null) {
                                String watchInfoStr = SettingsHelper.getString(Config.SETTING_WATCH_INFO, "");
                                WatchInfo localWatchInfo = JsonHelper.getObject(watchInfoStr, WatchInfo.class);
                                mac = deviceInfo.getIRONCLOUD_MAC();
                                if (localWatchInfo != null) {
                                    localMac = localWatchInfo.getMac();
                                    if (mac != null && mac.equalsIgnoreCase(localMac)) {//本地已保存,不处理
                                        return;
                                    } else {//更新本地信息
                                        localWatchInfo.setMac(deviceInfo.getIRONCLOUD_MAC());
                                        localWatchInfo.setChipId(deviceInfo.getIRONCLOUD_CHIPID());
                                        localWatchInfo.setSerialNum(deviceInfo.getIRONCLOUD_SN());
                                        String info = JsonHelper.createJsonString(localWatchInfo);
                                        SettingsHelper.putString(Config.SETTING_WATCH_INFO, info);//保存手表信息
                                        sendBindCmd = true;
                                    }
                                } else {//保存到本地
                                    localWatchInfo = new WatchInfo();
                                    localWatchInfo.setMac(deviceInfo.getIRONCLOUD_MAC());
                                    localWatchInfo.setChipId(deviceInfo.getIRONCLOUD_CHIPID());
                                    localWatchInfo.setSerialNum(deviceInfo.getIRONCLOUD_SN());
                                    String info = JsonHelper.createJsonString(localWatchInfo);
                                    SettingsHelper.putString(Config.SETTING_WATCH_INFO, info);//保存手表信息
                                    sendBindCmd = true;
                                }
                            } else {//清除本地手表信息
                                SettingsHelper.putString(Config.SETTING_WATCH_INFO, "");
                            }
                        }
                    }
                }

            }
        }
    }

    //endregion ======================================== Activity生命周期 ========================================


    //region ================================ 启动其它Activity ================================

    /**
     * 启动手表详情界面
     */
    private void startWatchActivity() {
        Intent intent = new Intent();
        intent.setClass(EquipmentActivity.this, WatchSearchActivity.class);
        intent.putExtra(INTENT_EXTRA_PAIR_BT_TASK, coinTaskPairBtFinished);
        intent.putExtra("sendBindCmd", sendBindCmd);
        startActivity(intent);
    }

    /**
     * 启动心率耳机界面
     */
    private void startPairHeartRateHeadSetSkipActivity() {
        Intent intent = new Intent();
        //    intent.setClass(EquipmentActivity.this,PairHeartRateSearchActivity.class);
        intent.setClass(EquipmentActivity.this, PairHeartRateConnectActivity.class);
        startActivity(intent);
    }

    /**
     * 启动智能跳绳界面
     */
    private void startPairGeekerySkipActivity() {
        Intent intent = new Intent();
        intent.setClass(EquipmentActivity.this, PairSkipActivity.class);
        intent.putExtra(INTENT_EXTRA_PAIR_BT_TASK, coinTaskPairBtFinished);
        startActivity(intent);
    }

    /**
     * 启动GEEKERY BOLT界面
     */
    private void startPairGeekeryBoltActivity() {
        Intent intent = new Intent();
        intent.setClass(EquipmentActivity.this, PairGeekeryBoltActivity.class);
        intent.putExtra(INTENT_EXTRA_PAIR_BT_TASK, coinTaskPairBtFinished);
        startActivity(intent);
    }

    /**
     * 启动E11界面
     */
    private void startPairHeadSetActivity() {
        Intent intent = new Intent();
        intent.setClass(EquipmentActivity.this, PairHeadSetActivity.class);
        intent.putExtra(INTENT_EXTRA_PAIR_BT_TASK, coinTaskPairBtFinished);
        startActivity(intent);
    }

    /**
     * 启动智能灯泡界面
     */
    private void startPairShineActivity() {
        Intent intent = new Intent();
        intent.setClass(EquipmentActivity.this, PairShineActivity.class);
        startActivity(intent);
    }

//    /**
//     * 启动网页
//     *
//     * @param url   网址
//     * @param title 网页标题
//     */
//    private void startWebViewActivity(String url, String title) {
//        if (url == null) return;
//        Intent intent = new Intent();
//        intent.setClass(EquipmentActivity.this, WebViewActivity.class);
//        intent.putExtra("url", url);
//        intent.putExtra("title", title);
//        startActivity(intent);
//    }


    //endregion ================================ 启动其它Activity ================================

    public void doClick(View v) {
        if (System.currentTimeMillis() - lastClickTime < 1000) {//防止快速点击
            return;
        }
        lastClickTime = System.currentTimeMillis();
        switch (v.getId()) {
            case R.id.btn_geekery_bolt://B1 耳机配对Activity
                startPairGeekeryBoltActivity();
                break;

//            case R.id.btn_puchase_geekery_bolt://购买B1耳机
//                if (!TextUtils.isEmpty(mBoltUrl))
//                    startWebViewActivity(mBoltUrl,
//                            getResources().getString(R.string.fm_mine_my_equipment_geekery_bolt));
//                break;

            case R.id.btn_geekery_shine://灯泡配对Activity
                startPairShineActivity();
                break;

//            case R.id.btn_puchase_geekery_shine:
//                if (!TextUtils.isEmpty(mShineUrl))
//                    startWebViewActivity(mShineUrl,
//                            getResources().getString(R.string.fm_mine_my_equipment_geekery_shine));
//                break;

            case R.id.btn_geekery_headset://E11 耳机配对Activity
                startPairHeadSetActivity();
                break;

//            case R.id.btn_puchase_geekery_headset://购买E11耳机
//                if (!TextUtils.isEmpty(mLightUrl))
//                    startWebViewActivity(mLightUrl,
//                            getResources().getString(R.string.fm_mine_my_equipment_geekery_shine));
//                break;
            case R.id.btn_geekery_skip://跳绳配对Activity
                startPairGeekerySkipActivity();
                break;
            case R.id.btn_geekery_heart_rate_headset://心率耳机配对Activity
                startPairHeartRateHeadSetSkipActivity();
                break;
//            case R.id.btn_puchase_geekery_skip://购买跳绳
//                startWebViewActivity(mLightUrl,
//                        getResources().getString(R.string.fm_mine_my_equipment_geekery_shine));
//                break;
//            case R.id.btn_puchase_geekery_heart_rate_headset://购买心率耳机
//                break;
            case R.id.btn_geekery_watch:
                startWatchActivity();
                break;

            case R.id.btn_geekery_skip_new:
                Intent intent = new Intent();
                intent.setClass(EquipmentActivity.this, NewSkipActivity.class);
                intent.putExtra(INTENT_EXTRA_PAIR_BT_TASK, coinTaskPairBtFinished);
                intent.putExtra("newSkip", true);
                startActivity(intent);
                break;
        }
    }

}
