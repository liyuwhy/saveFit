package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.SelectSongsAdapter;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.dialog.SelectCustomAlbumDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.ArrayList;
import java.util.List;


public class SelectSongActivity extends BaseActivity {

    /** */
    public static final int SELECT_SONG_ADD_TO_MUSIC_LIST = 187;
    public static final int SELECT_SONG_TO_DOWNLOAD = 188;

    private CheckBox ckb_select_all;
    String format;
    private List<Music> listDatas;
    private ListView list_songs;
    private SelectSongsAdapter adapter;
    private ViewGroup action_placeholder;
    private Button btn_choose_playlist;//添加歌单按钮
    private Button btn_download;//下载按钮
    private Button btn_delete;//下载按钮
    private Button btn_cancel_favorite;//取消收藏按钮
    private int albumId;
    private Boolean fromAlbum;
    private Boolean bCanChecked = true;
    private ArrayList<Integer> musicIdList;
    private List<Music> tempMusicList;//用于收藏
    private int listType;

    public static final String NET_TOAST_TO_SHOW = "net_toast_to_show";
    public static final String IS_SUCCESS = "net_is_successful";//网络访问操作默认是失败
    private String toast_to_show;//在本activity进行网络访问,服务器返回的信息,将此String在setResult()返回

    private List<Music> getMusicList() {
        return listDatas;
    }

    private SelectSongsAdapter getSelectSongsAdapter() {
        if (adapter == null) adapter = new SelectSongsAdapter(this);
        return adapter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_songs);
        setPageName("SelectSongActivity");
        albumId = getIntent().getIntExtra("currentAlbumId", -1);
        fromAlbum = getIntent().getBooleanExtra("FromAlbum", false);
        listType = getIntent().getIntExtra("ListType", -1);
        initToolbar();
        initData();
        initViews();
    }

    private void initData() {
        listDatas = getMyConfig().getMemExchange().getListMusicSelect();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        list_songs = (ListView) findViewById(R.id.bounceList);
        list_songs.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        emptyView.setText(getString(R.string.activity_select_songs_empty_hint));
        list_songs.setEmptyView(emptyView);

        getSelectSongsAdapter().setMusicList(getMusicList());
        list_songs.setAdapter(getSelectSongsAdapter());
        list_songs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (!bCanChecked) return;
                bCanChecked = false;
                boolean isChecked = ((CheckBox) view.findViewById(R.id.ckb_select_song)).isChecked();
                ((CheckBox) view.findViewById(R.id.ckb_select_song)).setChecked(!isChecked);
                bCanChecked = true;
            }
        });

        ckb_select_all = (CheckBox) findViewById(R.id.ckb_select_all);
        format = getResources().getString(R.string.activity_select_songs_select_all_format);
        ckb_select_all.setText(String.format(format, getSelectSongsAdapter().getCount()));
        ckb_select_all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                getSelectSongsAdapter().setSelectAllItems(isChecked);
            }
        });

        action_placeholder = (ViewGroup) findViewById(R.id.action_placeholder);
        action_placeholder.post(new Runnable() {
            @Override
            public void run() {
                int placeHolderWidth = action_placeholder.getWidth();
                int placeHolderHeight = action_placeholder.getHeight();
                initAction(placeHolderWidth, placeHolderHeight);
            }
        });

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_MUSIC + 5:
                Logger.i(Logger.DEBUG_TAG, "MainActivity--> 收藏音乐 requestId:" + dataReqResult.getRequestId() + " result:" + dataReqResult.getResult());
                cancelFavoriteByList(tempMusicList);
                Intent intent = new Intent();
                intent.putExtra(NET_TOAST_TO_SHOW, getResources().getString(R.string.activity_main_album_remove_favorite_tip));
                intent.putExtra(IS_SUCCESS, true);
                setResult(Activity.RESULT_OK, intent);
                finish();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean.getCode() == -1) {
            toast_to_show = getResources().getString(R.string.rsp_error_unknown_error);
        } else {
            toast_to_show = bean.getMsg();
        }
        Intent intent = new Intent();
        intent.putExtra(NET_TOAST_TO_SHOW, toast_to_show);
        intent.putExtra(IS_SUCCESS, false);
        setResult(Activity.RESULT_OK, intent);
        finish();
    }

    /**
     * 根据来源不同,创建不同的底部按钮
     *
     * @param placeHolderWidth  容器宽
     * @param placeHolderHeight 容器高
     */
    private void initAction(int placeHolderWidth, int placeHolderHeight) {
        switch (listType) {
            case Config.LIST_TYPE_SCENE:
                createChoosePlaylistButton(placeHolderWidth / 2, placeHolderHeight);
                createDownloadButton(placeHolderWidth / 2, placeHolderHeight);
                break;
            case Config.LIST_TYPE_FAVORITE:
                //添加歌单按钮
                createChoosePlaylistButton(placeHolderWidth / 3, placeHolderHeight);
                //添加下载按钮
                createDownloadButton(placeHolderWidth / 3, placeHolderHeight);
                //添加取消收藏按钮
                createCancelFavoriteButton(placeHolderWidth / 3, placeHolderHeight);
                break;
            case Config.LIST_TYPE_LOCAL:
                //添加歌单按钮
                createChoosePlaylistButton(placeHolderWidth / 2, placeHolderHeight);
                //添加删除按钮
                createDeleteButton(placeHolderWidth / 2, placeHolderHeight);
                break;
            case Config.LIST_TYPE_SELF:
                //添加歌单按钮
                createChoosePlaylistButton(placeHolderWidth / 2, placeHolderHeight);
                //添加删除按钮
                createDeleteButton(placeHolderWidth, placeHolderHeight);
                break;
            case Config.LIST_TYPE_DOWNLOADED:
                //添加歌单按钮
                createChoosePlaylistButton(placeHolderWidth / 2, placeHolderHeight);
                //添加删除按钮
                createDeleteButton(placeHolderWidth / 2, placeHolderHeight);
                break;
            case Config.LIST_TYPE_RECENT:
                createChoosePlaylistButton(placeHolderWidth / 2, placeHolderHeight);
                createDownloadButton(placeHolderWidth / 2, placeHolderHeight);
                break;
        }

    }


    /**
     * 创建添加歌单按钮
     *
     * @param width  按钮宽度
     * @param height 按钮高度
     */
    private void createChoosePlaylistButton(int width, int height) {
        btn_choose_playlist = new Button(this);
        btn_choose_playlist.setWidth(width);
        btn_choose_playlist.setHeight(height);
        btn_choose_playlist.setText(R.string.activity_select_songs_choose_playlist);
//        btn_choose_playlist.setTextColor(ContextCompat.getColorStateList(this, R.drawable.text_white_to_gray));
        btn_choose_playlist.setBackgroundColor(ContextCompat.getColor(this, R.color.fitmix_light_gray));
        btn_choose_playlist.setBackgroundResource(R.drawable.btn_color_2);
        btn_choose_playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSelectSongsAdapter().isNoneSelected()) {
                    String info = getResources().getString(R.string.activity_select_songs_none_select_tip1);
                    showAppMessage(info, AppMsg.STYLE_CONFIRM);
                } else {//弹出歌单列表,选中的下标用adapter.getCheckedIndexArray().keyAt(i)获取
                    showSelectAlbumPopWindow();
                }
            }
        });
        action_placeholder.addView(btn_choose_playlist);
    }


    /**
     * 创建下载按钮
     *
     * @param width  按钮宽度
     * @param height 按钮高度
     */
    private void createDownloadButton(int width, int height) {
        btn_download = new Button(this);
        btn_download.setWidth(width);
        btn_download.setHeight(height);
        btn_download.setText(R.string.activity_select_songs_download);
        btn_download.setTextColor(ContextCompat.getColorStateList(this, R.color.full_white_text));
        btn_download.setBackgroundResource(R.drawable.btn_color_1);
        btn_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSelectSongsAdapter().isNoneSelected()) {
                    String info = getResources().getString(R.string.activity_select_songs_none_select_tip2);
                    showAppMessage(info, AppMsg.STYLE_CONFIRM);
                } else {//弹出歌单列表
                    if (!checkDownload()) return;
                    downloadSelectedSongs();

                }
            }
        });
        action_placeholder.addView(btn_download);
    }

    /**
     * 创建删除按钮
     *
     * @param width  按钮宽度
     * @param height 按钮高度
     */
    private void createDeleteButton(int width, int height) {
        btn_delete = new Button(this);
        btn_delete.setWidth(width);
        btn_delete.setHeight(height);
        btn_delete.setText(R.string.activity_select_songs_delete);
        btn_delete.setTextColor(ContextCompat.getColorStateList(this, R.color.full_white_text));
        btn_delete.setBackgroundResource(R.drawable.btn_color_1);
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getSelectSongsAdapter().isNoneSelected()) {
                    String info = getResources().getString(R.string.activity_select_songs_none_select_tip3);
                    showAppMessage(info, AppMsg.STYLE_CONFIRM);
                } else {//弹出歌单列表
                    // if(!checkDownload())return;
                    deleteSelectedSongs();
                }
            }
        });
        action_placeholder.addView(btn_delete);
    }

    /**
     * 创建取消收藏按钮
     *
     * @param width  按钮宽度
     * @param height 按钮高度
     */
    private void createCancelFavoriteButton(int width, int height) {
        btn_cancel_favorite = new Button(this);
        btn_cancel_favorite.setWidth(width);
        btn_cancel_favorite.setHeight(height);
        btn_cancel_favorite.setText(R.string.activity_select_songs_cancel_favorite);
        btn_cancel_favorite.setTextColor(ContextCompat.getColorStateList(this, R.color.text_white_to_gray));
//        btn_cancel_favorite.setBackgroundColor(ContextCompat.getColor(this, R.color.fitmix_light_gray));
        btn_cancel_favorite.setBackgroundResource(R.drawable.btn_color_2);
        btn_cancel_favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelFavorite();
            }
        });
        action_placeholder.addView(btn_cancel_favorite);
    }


    /**
     * 显示选择歌单弹出框
     **/
    private void showSelectAlbumPopWindow() {
        final List<Album> albums = OperateMusicUtils.getAlbumList();
        Album album = new Album();
        album.setName(getString(R.string.fm_music_create_album));
        albums.add(album);
        final SelectCustomAlbumDialog dialog = new SelectCustomAlbumDialog();
        dialog.setAlbums(albums);
        dialog.setItemClickListener(new SelectCustomAlbumDialog.ItemClickListener() {
            @Override
            public void onItemClick(int position) {
                dialog.dismiss();
                Album album = albums.get(position);
                SparseBooleanArray array = getSelectSongsAdapter().getCheckedIndexArray();
                List<Music> musicList = getSelectSongsAdapter().getMusicList();
                if (array == null) return;
                if (position == albums.size() - 1) {
                    musicIdList = new ArrayList<>();
                    for (int i = 0; i < array.size(); i++) {
                        if (!array.get(i)) continue;
                        /**
                         * 解决bug java.lang.IndexOutOfBoundsException: Invalid index 30, size is 30
                         *  at java.util.ArrayList.throwIndexOutOfBoundsException(ArrayList.java:255)
                         */
                        if (i < musicList.size() && musicList.get(i) != null) {
                            musicIdList.add(musicList.get(i).getId());
                        }
                    }
                    Intent intent = new Intent(SelectSongActivity.this, CreatePlaylistActivity.class);
                    intent.putIntegerArrayListExtra("MusicId", musicIdList);
                    intent.putExtra("FromAlbum", fromAlbum);
                    startActivity(intent);
                    finish();
                } else {
                    for (int i = 0; i < array.size(); i++) {
                        if (!array.get(i)) continue;
                        /**
                         * 解决bug java.lang.IndexOutOfBoundsException: Invalid index 8, size is 8
                         * at java.util.ArrayList.throwIndexOutOfBoundsException(ArrayList.java:255)
                         * at java.util.ArrayList.get(ArrayList.java:308)
                         * at com.fitmix.sdk.view.activity.SelectSongActivity$8.onItemClick(SelectSongActivity.java:380)
                         */
                        if (i < musicList.size() && musicList.get(i) != null) {
                            OperateMusicUtils.addCustomAlbumList(album.getId(), musicList.get(i).getId());
                        }
                    }
                    setResult(SELECT_SONG_ADD_TO_MUSIC_LIST);
                    finish();
                }
            }
        });
        if (ftCanCommit)
            dialog.show(getFragmentManager(), "selectCustomAlbum");
    }

    //region =============================操作======================

    /**
     * 下载歌曲
     */
    private void downloadSelectedSongs() {
        SparseBooleanArray array = getSelectSongsAdapter().getCheckedIndexArray();
        if (array == null) return;
        for (int i = 0; i < array.size(); i++) {
            if (!array.get(i)) continue;
            Music music = getMusicList().get(i);
            OperateMusicUtils.downloadMusic(music);
            if (music != null) {
                UmengAnalysisHelper.getInstance().musicReportPlus(SelectSongActivity.this, "音乐下载", music.getId());
            }
        }
        Intent intent = new Intent();
        intent.putExtra(NET_TOAST_TO_SHOW, getResources().getString(R.string.added_downloading));
        intent.putExtra(IS_SUCCESS, true);
        setResult(SelectSongActivity.SELECT_SONG_TO_DOWNLOAD);
        finish();
    }

    /**
     * 删除歌曲
     */
    private void deleteSelectedSongs() {
        SparseBooleanArray array = getSelectSongsAdapter().getCheckedIndexArray();
        if (array == null) return;
        List<Music> musicList = new ArrayList<>();
        /** 解决bug:java.lang.IndexOutOfBoundsException: Invalid index 104, size is 104
         *  at java.util.ArrayList.throwIndexOutOfBoundsException(ArrayList.java:255)*/
        int size = getMusicList() != null ? getMusicList().size() : 0;
        switch (listType) {
            case Config.LIST_TYPE_LOCAL:
                for (int i = 0; i < array.size(); i++) {
                    if (!array.get(i)) continue;
                    if (i >= size) {
                        continue;
                    }
                    Music music = getMusicList().get(i);
                    OperateMusicUtils.deleteMusic(music, Config.LIST_TYPE_LOCAL);
                    musicList.add(music);
                    array.put(i, false);
                }
                break;
            case Config.LIST_TYPE_SELF:
                for (int i = 0; i < array.size(); i++) {
                    if (!array.get(i)) continue;
                    if (i >= size) {
                        continue;
                    }
                    Music music = getMusicList().get(i);
                    OperateMusicUtils.deleteMusicInAlbumList(albumId, music.getId());
                    musicList.add(music);
                    array.put(i, false);
                }
                break;
            case Config.LIST_TYPE_DOWNLOADED:
                for (int i = 0; i < array.size(); i++) {
                    if (!array.get(i)) continue;
                    if (i >= size) {
                        continue;
                    }
                    Music music = getMusicList().get(i);
                    OperateMusicUtils.deleteMusicDownloadedFile(music);
                    musicList.add(music);
                    array.put(i, false);
                }
                break;
        }
        listDatas.removeAll(musicList);
        ckb_select_all.setText(String.format(format, getSelectSongsAdapter().getCount()));
        if (listDatas.size() > 0) {
            adapter.notifyDataSetChanged();
        } else {
            finish();
        }
    }

    /**
     * 取消收藏
     */
    private void cancelFavorite() {
        SparseBooleanArray array = getSelectSongsAdapter().getCheckedIndexArray();
        if (array == null) return;
        List<Music> listFavorite = new ArrayList<>();
        for (int i = 0; i < array.size(); i++) {
            if (!array.get(i)) continue;
            listFavorite.add(getMusicList().get(i));
        }
        cancelFavoritesInNet(listFavorite);
        listFavorite.clear();
    }

    private void cancelFavoriteByList(List<Music> list) {
        if (list == null)
            return;
        for (int i = 0; i < list.size(); i++) {
            OperateMusicUtils.deleteMusic(list.get(i), Config.LIST_TYPE_FAVORITE);
        }
    }

    /**
     * 发送批量收藏或取消收藏的请求
     */
    private void favoriteMusicListChange(List<Integer> listid) {
        int requestId = MusicDataManager.getInstance().favoriteMusicListChange(UserDataManager.getUid(), listid, true);
        registerDataReqStatusListener(requestId);
    }

    private void cancelFavoritesInNet(List<Music> list) {
        if (list == null || list.size() <= 0)
            return;
        tempMusicList = new ArrayList<>();
        tempMusicList.addAll(list);
        List<Integer> listid = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            listid.add(list.get(i).getId());
        }
        favoriteMusicListChange(listid);
    }

    private boolean checkMusicExist(Music music) {
        if (music == null) return false;
        return FitmixUtil.isExistCacheFile(music.getUrl(), music.getId(),
                Config.DOWNLOAD_FORMAT_MUSIC);
    }

    private boolean checkDownload() {
        if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_NONE) {
            showAppMessage(R.string.check_network, AppMsg.STYLE_CONFIRM);
            return false;
        }
        if (ApiUtils.getNetworkType() != Config.NETWORK_TYPE_WIFI) {
            new MaterialDialog.Builder(this)
                    .title(R.string.warning)
                    .content(R.string.downstream_control)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE://下载歌曲
                                    downloadSelectedSongs();
                                    break;
                                case NEGATIVE:
                                    break;
                            }
                        }
                    }).show();
            return false;
        }
        return true;
    }


    //endregion =============================操作======================
}
