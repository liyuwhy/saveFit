package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.RunDataInfo;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.bean.SkipNumberInfo;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.RunGraphHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.model.api.bean.AddSkipRecord;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.RunRecordShare;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.BesselLineChart;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class SkipRecordActivity extends BaseActivity {

    private TextView tv_skip_number;
    private TextView tv_skip_pace;
    private TextView tv_skip_calorie;
    private TextView tv_skip_duration;
    private TextView tv_skip_heart_rate;
    private BesselLineChart paceChart;//本次跳绳记录的跳频曲线图

//    private int height = 0;//用户身高,单位为厘米
//    private int gender = 0;//用户性别,1:男,2:女

    private DownloadService mService;
    private DownloadInfoListener downloadListener;

    private ServiceConnection serviceConnection;

    private long enterTime;//页面停留时长,友盟u-d plus统计用到
    private SkipLogInfo skipLog;
    private String shareFilename;
    /**
     * 本地跳绳文件路径
     */
    private String skipFileName;

    /**
     * @return 获取跳绳记录
     */
    private SkipLogInfo getSkipLog() {
        return skipLog;
    }

//    /**
//     * 获取用户身高,单位为厘米
//     */
//    private int getHeight() {
//        if (height == 0) {
//            height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
//        }
//        return height;
//    }
//
//    /**
//     * 获取用户性别,1:男,2:女
//     */
//    private int getGender() {
//        if (gender == 0) {
//            gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
//        }
//        return gender;
//    }


    //region ================================== Activity生命周期 ==================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skip_record);
        setPageName("SkipRecordActivity");
        enterTime = System.currentTimeMillis();
        Intent intent = getIntent();
        if (intent == null) {
            showAppMessage(R.string.activity_run_record_invalid_record, AppMsg.STYLE_ALERT);
            finish();
            return;
        }
        int uid = intent.getIntExtra("uid", 0);
        long startTime = intent.getLongExtra("startTime", 0);

        skipLog = new SkipLogInfo();
        skipLog.setUid(uid);
        skipLog.setStartTime(startTime);
        skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + startTime + ".skip";
        shareFilename = Config.PATH_LOCAL_TEMP + uid + "_" + startTime + ".jpg";

        initToolbar();
        initViews();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            bindDownloadService();
            getRunRecordFromDb(uid, startTime);
        } else {
            if (permissionIsGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                bindDownloadService();
                getRunRecordFromDb(uid, startTime);
            } else {
                getPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);//申请写存储器权限
            }
        }
        refreshTitle();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_run_record, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_share_record://分享记录
                shareLog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        long duration = System.currentTimeMillis() - enterTime;
        UmengAnalysisHelper.getInstance().runRecordDuration(this, duration);
        unbindDownloadService();
    }

    /**
     * 绑定下载或上传服务
     */
    private void bindDownloadService() {
        //创建 运动轨迹下载文件夹和计步文件夹
        FileUtils.makeDirs(Config.PATH_DOWN_SKIP);
        Intent intent = new Intent(this, DownloadService.class);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->onServiceConnected");
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mService = ((DownloadService.GetServiceClass) service).getService();
                    if (mService == null)
                        return;

                    if (downloadListener != null) {//注册下载状态监听
                        Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->onServiceConnected addDownloadListener");
                        mService.addDownloadListener(downloadListener);
                    }

                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mService == null)
                        return;
                    if (downloadListener != null) {//注销下载状态监听
                        mService.removeDownloadListener(downloadListener);
                    }
                }
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑下载或上传服务
     */
    private void unbindDownloadService() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        serviceConnection = null;
        downloadListener = null;
    }

    /**
     * 设置界面标题
     */
    private void refreshTitle() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(getSkipLog().getStartTime());
        String sTitle = String.format("%s %04d/%02d/%02d", getResources().getString(R.string.app_name),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
        setUiTitle(sTitle);
    }

    /**
     * 从数据库中获取跳绳记录
     */
    private void getRunRecordFromDb(int uid, long startTime) {
        SportRecordsHelper.asyncGetSkipRecords(this, uid, startTime, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                SportRecord sportRecord = (SportRecord) operation.getResult();
                if (sportRecord != null) {
                    skipLog.setEndTime(sportRecord.getEndTime());
                    skipLog.setSkipTime(sportRecord.getRunTime());
                    skipLog.setStartTime(sportRecord.getStartTime());
                    skipLog.setBpm(sportRecord.getBpm());
                    skipLog.setSkipNumber(sportRecord.getStep());//步数
                    skipLog.setCalorie(sportRecord.getCalorie());//卡路里
                    skipLog.setUploaded(sportRecord.getUploaded());
                    skipLog.setSkipDataPath(sportRecord.getStepData());
                    //加载完成后,初始化地图
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            refreshSkipLogData();
                            downloadGraphData();
                        }
                    });
                }
            }
        });
    }


    /**
     * 下载跳绳计数文件
     */
    private void downloadGraphData() {
        if (!checkSkipData()) {
            downloadStep();
        } else {
            setSkipData();
        }
    }

    //endregion ================================== Activity生命周期 ==================================

    //region ================================== 跳绳文件下载 ==================================

    /**
     * 下载跳绳计数数据
     */
    private void downloadStep() {
        if (getSkipLog() == null)
            return;
        String sStep = getSkipLog().getSkipDataPath();
        if (sStep == null || sStep.isEmpty())
            return;
        if (skipFileName == null || TextUtils.isEmpty(skipFileName))
            return;
        DownloadService.makeDownload(this, sStep, skipFileName, DownloadType.TYPE_FILE);
    }

    /**
     * 从跳绳计数文件获取所有跳绳信息
     */
    private void setSkipData() {
        if (TextUtils.isEmpty(skipFileName))
            return;
        refreshGraph(skipFileName);
    }

    /**
     * @return 检查跳绳计数文件是否存在
     */
    private boolean checkSkipData() {
        if (TextUtils.isEmpty(skipFileName))
            return false;
        File f = new File(skipFileName);
        return f.exists();
    }

    //endregion ================================== 跳绳文件下载 ==================================

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        tv_skip_number = (TextView) findViewById(R.id.tv_skip_number);
        tv_skip_pace = (TextView) findViewById(R.id.tv_skip_pace);
        tv_skip_calorie = (TextView) findViewById(R.id.tv_skip_calorie);
        tv_skip_duration = (TextView) findViewById(R.id.tv_skip_duration);
        tv_skip_heart_rate = (TextView) findViewById(R.id.tv_skip_heart_rate);
        paceChart = (BesselLineChart) findViewById(R.id.line_chart_pace);
        downloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                if (downloadInfo != null) {
                    String url = downloadInfo.getRemoteUrl();
                    Logger.i(Logger.DEBUG_TAG, "RunRecordActivity-->dispatch DownCompleted url:" + url);
                    if (getSkipLog() != null && !TextUtils.isEmpty(url)) {
                        String stepData = getSkipLog().getSkipDataPath();
                        if (url.equals(stepData)) {
                            setSkipData();
                        }
                    }
                }
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                //不处理
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                //不处理
            }
        };

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_SPORT + 13://分享跳绳记录
                Logger.i(Logger.DEBUG_TAG, "分享跳绳记录 dataReqResult:" + dataReqResult);
                RunRecordShare runRecordShare = JsonHelper.getObject(result, RunRecordShare.class);
                if (runRecordShare != null) {
                    String sRemote = runRecordShare.getShare();
                    if (TextUtils.isEmpty(shareFilename) || TextUtils.isEmpty(sRemote))
                        return;
                    shareSkipScore(shareFilename, sRemote);
                }
                break;
            case Config.MODULE_SPORT + 10://添加运动记录
                AddSkipRecord addSkipRecord = JsonHelper.getObject(result, AddSkipRecord.class);
                if (addSkipRecord != null) {
                    handleUploadRecord(addSkipRecord);
                }
                break;

            case Config.MODULE_USER + 61://完成每日分享运动记录金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_RECORD, System.currentTimeMillis());//设置完成任务时间
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            switch (requestId) {
                case Config.MODULE_SPORT + 13://分享跳绳记录
                    showAppMessage(R.string.error, AppMsg.STYLE_ALERT);
                    break;
                case Config.MODULE_SPORT + 10://添加跳绳记录到后台服务器
                    if (errorCode < 1000) {
                        showAppMessage(R.string.error, AppMsg.STYLE_ALERT);
                    }
                    break;
            }
        }
    }

    /**
     * 处理上传跳绳记录回调
     */
    private void handleUploadRecord(AddSkipRecord addSkipRecord) {
        if (addSkipRecord == null) {
            showAppMessage(R.string.activity_runmain_add_record_fail, AppMsg.STYLE_ALERT);
            return;
        }
        if (addSkipRecord.getCode() == 0) {//上传成功后
            AddSkipRecord.UserSkipRopeBean userSkipRopeBean = addSkipRecord.getUserSkipRope();
            if (userSkipRopeBean != null) {
                int uid = userSkipRopeBean.getUid();
                long startTime = userSkipRopeBean.getStartTime();
                //上传成功后更新跳绳记录同步状态
                SportRecordsHelper.updateSkipSportRecordSyncState(uid, startTime, userSkipRopeBean.getSkipDetail(), 1);
                int requestId = SportDataManager.getInstance().shareSkipRecord(startTime, shareFilename, "file");
                registerDataReqStatusListener(requestId);
                return;
            }
        }
        //上传失败
        showAppMessage(R.string.error, AppMsg.STYLE_ALERT);
    }


    //region ================================== 数据详情报表相关 ==================================

    /**
     * 设置数据详情报表
     */
    private void refreshSkipLogData() {
        tv_skip_number.setText(String.valueOf(getSkipLog().getSkipNumber()));
        tv_skip_pace.setText(String.valueOf(getSkipLog().getBpm()));
        tv_skip_calorie.setText(String.valueOf((int) getSkipLog().getCalorie()));
        tv_skip_duration.setText(FormatUtil.formatRunTime(getSkipLog().getSkipTime() / 1000));
        tv_skip_heart_rate.setText("-");
    }

    //endregion ================================== 数据详情报表相关 ==================================

    //region ================================== 图表分析报表相关 ==================================

    /**
     * 刷新图表
     *
     * @param skipFileName 文件地址
     */
    private void refreshGraph(String skipFileName) {
        if (paceChart == null) {
            return;
        }
        int color;
        double space;
        double length;
        double ratio;
        String sXUnit;
        String sYUnit = getResources().getString(R.string.activity_skip_record_speed_unit);
        List<SkipNumberInfo> skipNumberInfoList = JsonHelper.readSkipNumberFile(skipFileName);
        if (skipNumberInfoList.size() == 0) return;
        space = RunGraphHelper.getAxisTimeSpaceSkipType(skipLog.getSkipTime(), 5);
        length = RunGraphHelper.getSkipDuration(skipNumberInfoList, skipLog.getEndTime(), skipLog.getStartTime());
        if (space < 1000) {
            ratio = 1;
            sXUnit = getResources().getString(R.string.millisecond);
        } else if (space < 60000) {
            ratio = 1000;
            sXUnit = getResources().getString(R.string.second);
        } else if (space < 3600000) {
            ratio = 60 * 1000;
            sXUnit = getResources().getString(R.string.minute);
        } else {
            ratio = 60 * 60 * 1000;
            sXUnit = getResources().getString(R.string.hour);
        }
        List<BesselLineChart.Point> dataList = new ArrayList<>();
        List<RunDataInfo> listSpeed = RunGraphHelper.getSpeedArrayBySkipInfo(skipNumberInfoList, skipLog.getStartTime(), 60);
        if (listSpeed != null) {
            for (RunDataInfo runDataInfo : listSpeed) {
                BesselLineChart.Point point = new BesselLineChart.Point(runDataInfo.getTime() / ratio, runDataInfo.getData());
                dataList.add(point);
            }
            listSpeed.clear();
        }
        color = 0xFF8E65E3;
        paceChart.clear();
        paceChart.setYAxisMax(350);
        paceChart.setYAxisMin(0);
        paceChart.setDataList(dataList, 0, false);
        paceChart.setXLength(length / ratio);
        paceChart.setXSpace(space / ratio);
        paceChart.setXUnit(sXUnit);
        paceChart.setYUnit(sYUnit);
        paceChart.setColor(color);
        paceChart.startLineAnimator();
    }
    //endregion ================================== 图表分析报表相关 ==================================

    //region ================================== 分享相关 ==================================

    private void shareLog() {
        saveScreen();
        shareInServer();
    }

    private void saveScreen() {
        View decorView = getWindow().getDecorView();
        Bitmap bitmapScreen = null;
        if (decorView != null) {
            decorView.setDrawingCacheEnabled(true);
            decorView.buildDrawingCache();
            bitmapScreen = decorView.getDrawingCache();
        }
        if (bitmapScreen == null)
            return;
        try {
            File file = new File(shareFilename);
            FileOutputStream fos;
            fos = new FileOutputStream(file);
            if (fos != null) {
                bitmapScreen.compress(Bitmap.CompressFormat.JPEG, 90, fos);
                fos.flush();
                fos.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (decorView != null)
            decorView.destroyDrawingCache();
        if (bitmapScreen != null)
            bitmapScreen.recycle();
    }

    private void shareInServer() {
        if (getSkipLog() == null) return;

        if (getSkipLog().getUploaded() == 0) {//记录未同步到服务器
            UploadSkipLog();
        } else {
            shareSkipLog();
        }
    }

    /**
     * 上传运动记录
     */
    private void UploadSkipLog() {
        if (getSkipLog() == null) return;
        String files = "";
        String fileTags = "";
        if (!TextUtils.isEmpty(skipFileName)) {
            files += skipFileName;
            fileTags += "file";
        }

        int requestId = SportDataManager.getInstance().addSkipSportRecordWithHeartRate(getSkipLog(), files, fileTags, true);//不考虑之前的请求结果
        registerDataReqStatusListener(requestId);
    }

    /**
     * 向服务器发送获取分享页面地址的请求
     */
    private void shareSkipLog() {
        if (getSkipLog() == null) return;
        int requestId = SportDataManager.getInstance().shareSkipRecord(getSkipLog().getStartTime(), shareFilename, "file");
        registerDataReqStatusListener(requestId);
        showAppMessage(R.string.info_shareing, AppMsg.STYLE_INFO);
    }


    /**
     * 运动成绩分享
     *
     * @param locale  分享图片的本地路径
     * @param sRemote 分享网页的地址
     */
    private void shareSkipScore(String locale, String sRemote) {
        if (getSkipLog() == null) return;
        String skipNumber = String.format(getString(R.string.share_skip_number), getSkipLog().getSkipNumber());
        String time = FormatUtil.formatTimeChinaStyle(getSkipLog().getSkipTime() / 1000);
        String bpm = String.format(getString(R.string.share_skip_bpm), getSkipLog().getBpm());
        String sTitle = String.format(getResources().getString(R.string.my_score), (int) getSkipLog().getCalorie());// 分享标题
        String sContent = String.format(getResources().getString(R.string.share_skip_content), skipNumber, time, bpm);

        ShareManager share = new ShareManager(this);
        share.setContent(sContent);
        share.setFilename(locale);
        share.setTitle(sTitle);
        share.setUrl(sRemote);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_RUN_SCORE);//分享类别为运动成绩,用于友盟分享统计
        share.share();
    }
    //endregion ================================== 分享相关 ==================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    if (data == null) return;
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }

                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareRecordCoinTask();//完成每日分享运动记录金币任务
                            }
                            break;
                    }
                }
                break;
        }
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        switch (permissionName) {
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                bindDownloadService();
                if (skipLog != null)
                    getRunRecordFromDb(skipLog.getUid(), skipLog.getStartTime());
                break;
            default:
                break;
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        switch (permissionName) {
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                showAppMessage(R.string.activity_run_record_permission_forbid, AppMsg.STYLE_ALERT);
                break;
            default:
                break;
        }
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动记录金币任务
     */
    private void finishShareRecordCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_RECORD, 0);
        Logger.i(Logger.DEBUG_TAG, "finishShareRecordCoinTask is today:" + FitmixUtil.isToday(lastShareTime));
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareRecordCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================

}
