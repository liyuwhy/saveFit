package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.TwoNumberPickerView;
import com.fitmix.sdk.view.widget.spinnerwheel.AbstractWheel;

public class HeartRateCoachModeActivity extends BaseActivity {

    private RadioGroup radioGroup;
    private RadioButton freeMode, customMode, limitMode, bodyMode, heartLungMode, fatMode;
    private LinearLayout freeModeNoteView, customModeNoteView, fatModeNoteView,
            heartLungModeNoteView, limitModeNoteView, bodyModeNoteView;
    private TwoNumberPickerView twoNumberPickerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hear_rate_coach_mode);
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        radioGroup = (RadioGroup) findViewById(R.id.coach_mode_rg);
        freeModeNoteView = (LinearLayout) findViewById(R.id.free_mode_note_view);
        customModeNoteView = (LinearLayout) findViewById(R.id.custom_mode_note_view);
        fatModeNoteView = (LinearLayout) findViewById(R.id.fat_mode_note_view);
        heartLungModeNoteView = (LinearLayout) findViewById(R.id.heart_lung_mode_note_view);
        limitModeNoteView = (LinearLayout) findViewById(R.id.limit_mode_note_view);
        bodyModeNoteView = (LinearLayout) findViewById(R.id.body_mode_note_view);
        twoNumberPickerView = (TwoNumberPickerView) findViewById(R.id.picker_number);
        freeMode = (RadioButton) findViewById(R.id.btn_free_mode);
        customMode = (RadioButton) findViewById(R.id.btn_custom_mode);
        limitMode = (RadioButton) findViewById(R.id.btn_limit_mode);
        bodyMode = (RadioButton) findViewById(R.id.btn_body_mode);
        heartLungMode = (RadioButton) findViewById(R.id.btn_heart_lung_mode);
        fatMode = (RadioButton) findViewById(R.id.btn_fat_mode);

        Logger.d(Logger.DEBUG_TAG, "setting low hr:" + SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MIM_VALUE, twoNumberPickerView.getCurrentLowHr()) +
                " setting high hr:" + SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MAX_VALUE, twoNumberPickerView.getCurrentHighHr()));
        int lowValue = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MIM_VALUE, twoNumberPickerView.getCurrentLowHr());
        int highValue = SettingsHelper.getInt(Config.CUSTOM_COACH_MODE_MAX_VALUE, twoNumberPickerView.getCurrentHighHr());
        Logger.d(Logger.DEBUG_TAG, "last low hr:" + lowValue +
                " last high hr:" + highValue);
        twoNumberPickerView.setLowAndHighValue(lowValue, highValue);

        twoNumberPickerView.listener = new TwoNumberPickerView.HrValuesNotifyListener() {
            @Override
            public void notify(AbstractWheel wheel) {
                Logger.d(Logger.DEBUG_TAG, "select low hr:" + twoNumberPickerView.getCurrentLowHr() +
                        " select high hr:" + twoNumberPickerView.getCurrentHighHr());
                if (twoNumberPickerView.getCurrentLowHr() > twoNumberPickerView.getCurrentHighHr()) {
                    showAppMessage(R.string.hr_value_setting_wrong_note, AppMsg.STYLE_ALERT);
                } else {//保存设置的心率区间值
                    SettingsHelper.putInt(Config.CUSTOM_COACH_MODE_MIM_VALUE, twoNumberPickerView.getCurrentLowHr());
                    SettingsHelper.putInt(Config.CUSTOM_COACH_MODE_MAX_VALUE, twoNumberPickerView.getCurrentHighHr());
                }
            }
        };


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.btn_free_mode://自由 int value:7
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 7);
                        setFreeModeVisible();
                        break;
                    case R.id.btn_custom_mode://自定义 int value:6
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 6);
                        setCustomVisible();
                        break;
                    case R.id.btn_limit_mode://极限 int value:5
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 5);
                        setLimitVisible();
                        break;
                    case R.id.btn_body_mode://强化机能 int value:4
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 4);
                        setBodyVisible();
                        break;

                    case R.id.btn_heart_lung_mode://强化心肺 int value:3
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 3);
                        setHeartLungVisible();
                        break;

                    case R.id.btn_fat_mode://燃脂 int value:2
                        SettingsHelper.putInt(Config.HEART_RATE_COACH_MODE, 2);
                        setFatVisible();
                        break;
                }
            }
        });

        //根据上次设置结果初始化radiobutton的状态
        initRadioButtonState();
    }

    private void initRadioButtonState() {
        switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
            case 7:
                freeMode.setChecked(true);
                setFreeModeVisible();
                break;
            case 6:
                customMode.setChecked(true);
                setCustomVisible();
                break;
            case 5:
                limitMode.setChecked(true);
                setLimitVisible();
                break;
            case 4:
                bodyMode.setChecked(true);
                setBodyVisible();
                break;
            case 3:
                heartLungMode.setChecked(true);
                setHeartLungVisible();
                break;
            case 2:
                fatMode.setChecked(true);
                setFatVisible();
                break;
        }
    }

    /**
     * 选中燃脂模式
     */
    private void setFatVisible() {
        freeModeNoteView.setVisibility(View.GONE);
        customModeNoteView.setVisibility(View.GONE);
        fatModeNoteView.setVisibility(View.VISIBLE);
        heartLungModeNoteView.setVisibility(View.GONE);
        limitModeNoteView.setVisibility(View.GONE);
        bodyModeNoteView.setVisibility(View.GONE);
    }

    /**
     * 选中机能模式
     */
    private void setBodyVisible() {
        freeModeNoteView.setVisibility(View.GONE);
        customModeNoteView.setVisibility(View.GONE);
        fatModeNoteView.setVisibility(View.GONE);
        heartLungModeNoteView.setVisibility(View.GONE);
        limitModeNoteView.setVisibility(View.GONE);
        bodyModeNoteView.setVisibility(View.VISIBLE);
    }

    /**
     * 选中自定义模式
     */
    private void setCustomVisible() {
        freeModeNoteView.setVisibility(View.GONE);
        customModeNoteView.setVisibility(View.VISIBLE);
        fatModeNoteView.setVisibility(View.GONE);
        heartLungModeNoteView.setVisibility(View.GONE);
        limitModeNoteView.setVisibility(View.GONE);
        bodyModeNoteView.setVisibility(View.GONE);
    }

    /**
     * 选中自由模式
     */
    private void setFreeModeVisible() {
        freeModeNoteView.setVisibility(View.VISIBLE);
        customModeNoteView.setVisibility(View.GONE);
        fatModeNoteView.setVisibility(View.GONE);
        heartLungModeNoteView.setVisibility(View.GONE);
        limitModeNoteView.setVisibility(View.GONE);
        bodyModeNoteView.setVisibility(View.GONE);
    }

    /**
     * 选中心肺模式
     */
    private void setHeartLungVisible() {
        freeModeNoteView.setVisibility(View.GONE);
        customModeNoteView.setVisibility(View.GONE);
        fatModeNoteView.setVisibility(View.GONE);
        heartLungModeNoteView.setVisibility(View.VISIBLE);
        limitModeNoteView.setVisibility(View.GONE);
        bodyModeNoteView.setVisibility(View.GONE);
    }

    /**
     * 选中极限模式
     */
    private void setLimitVisible() {
        freeModeNoteView.setVisibility(View.GONE);
        customModeNoteView.setVisibility(View.GONE);
        fatModeNoteView.setVisibility(View.GONE);
        heartLungModeNoteView.setVisibility(View.GONE);
        limitModeNoteView.setVisibility(View.VISIBLE);
        bodyModeNoteView.setVisibility(View.GONE);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void dataUpdateNotify(int requestId) {

    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {

    }

}
