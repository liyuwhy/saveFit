package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.fragment.WatchAlarmNotifyFragment;
import com.fitmix.sdk.view.fragment.WatchAlarmSettingFragment;

/**
 * 手表闹钟提醒管理界面
 */
public class WatchAlarmNotifyActivity extends BaseActivity implements WatchAlarmNotifyFragment.WatchAlarmNotifyFragmentCallback {

    private WatchAlarmNotifyFragment watchAlarmNotifyFragment;
    private WatchAlarmSettingFragment watchAlarmSettingFragment;

    private int alarmIndex;//固定4个闹钟,记录设置哪个闹钟

    private boolean alarm1On;//闹钟1是否开启
    private boolean alarm2On;//闹钟2是否开启
    private boolean alarm3On;//闹钟3是否开启
    private boolean alarm4On;//闹钟4是否开启

    private String alarm1Time;//闹钟1时间
    private String alarm2Time;//闹钟2时间
    private String alarm3Time;//闹钟3时间
    private String alarm4Time;//闹钟4时间

    private String alarm1Mode;//闹钟1重复模式
    private String alarm2Mode;//闹钟2重复模式
    private String alarm3Mode;//闹钟3重复模式
    private String alarm4Mode;//闹钟4重复模式

    private String alarm1AlertMode;//闹钟1提醒模式
    private String alarm2AlertMode;//闹钟2提醒模式
    private String alarm3AlertMode;//闹钟3提醒模式
    private String alarm4AlertMode;//闹钟4提醒模式


    private boolean settingChanged = false;//是否有设置更改

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_notify_base);
        Intent intent = getIntent();
        if (intent != null) {
            String alarm1 = intent.getStringExtra("alarm1");
            String alarm2 = intent.getStringExtra("alarm2");
            String alarm3 = intent.getStringExtra("alarm3");
            String alarm4 = intent.getStringExtra("alarm4");
            split(1, alarm1);
            split(2, alarm2);
            split(3, alarm3);
            split(4, alarm4);
        }

        initToolbar();
        initViews();

        if (savedInstanceState == null) {
            watchAlarmNotifyFragment = new WatchAlarmNotifyFragment();
            watchAlarmNotifyFragment.setCallback(this);
            watchAlarmNotifyFragment.setAlarm(1, alarm1On, alarm1Time, alarm1Mode);
            watchAlarmNotifyFragment.setAlarm(2, alarm2On, alarm2Time, alarm2Mode);
            watchAlarmNotifyFragment.setAlarm(3, alarm3On, alarm3Time, alarm3Mode);
            watchAlarmNotifyFragment.setAlarm(4, alarm4On, alarm4Time, alarm4Mode);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.mainContainer, watchAlarmNotifyFragment, WatchAlarmNotifyFragment.TAG)
                    .commit();
        }
    }

    /**
     * 根据闹钟编号,闹钟字符串获取闹钟开关状态,时间,重复模式以及提醒模式
     *
     * @param index    index     1:闹钟1,2:闹钟2,3:闹钟3,4:闹钟4
     * @param alarmStr 闹钟设置字符串,格式为总开关,时间,重复模式,震动模式
     */
    private void split(int index, String alarmStr) {
        if (alarmStr != null) {
            String[] sets = alarmStr.split(",");
            if (sets != null && sets.length == 4) {
                try {
                    int on = Integer.parseInt(sets[0]);//总开关
                    String time = sets[1];//时间
                    String mode = sets[2];//重复模式
                    String alert = sets[3];//提醒模式

                    switch (index) {
                        case 1://闹钟1
                            alarm1On = (on == 1);
                            alarm1Time = time;
                            alarm1Mode = mode;
                            alarm1AlertMode = alert;
                            break;
                        case 2:
                            alarm2On = (on == 1);
                            alarm2Time = time;
                            alarm2Mode = mode;
                            alarm2AlertMode = alert;
                            break;
                        case 3:
                            alarm3On = (on == 1);
                            alarm3Time = time;
                            alarm3Mode = mode;
                            alarm3AlertMode = alert;
                            break;
                        case 4:
                            alarm4On = (on == 1);
                            alarm4Time = time;
                            alarm4Mode = mode;
                            alarm4AlertMode = alert;
                            break;
                    }
                    return;//正常返回
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        switch (index) {//异常情况下给默认
            case 1:
                alarm1On = false;
                alarm1Time = "0000";
                alarm1Mode = "0";//只响一次
                alarm1AlertMode = "0";//响铃
                break;
            case 2:
                alarm2On = false;
                alarm2Time = "0000";
                alarm2Mode = "0";//只响一次
                alarm2AlertMode = "0";//响铃
                break;
            case 3:
                alarm3On = false;
                alarm3Time = "0000";
                alarm3Mode = "0";//只响一次
                alarm3AlertMode = "0";//响铃
                break;
            case 4:
                alarm4On = false;
                alarm4Time = "0000";
                alarm4Mode = "0";//只响一次
                alarm4AlertMode = "0";//响铃
                break;
        }


    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    public void doClick(View view) {
        watchAlarmSettingFragment = new WatchAlarmSettingFragment();
        switch (view.getId()) {
            case R.id.btn_alarm1://闹钟1
                alarmIndex = 1;
                watchAlarmSettingFragment.setAlarm(alarm1Time, alarm1Mode, alarm1AlertMode);
                break;
            case R.id.btn_alarm2://闹钟2
                alarmIndex = 2;
                watchAlarmSettingFragment.setAlarm(alarm2Time, alarm2Mode, alarm2AlertMode);
                break;
            case R.id.btn_alarm3://闹钟3
                alarmIndex = 3;
                watchAlarmSettingFragment.setAlarm(alarm3Time, alarm3Mode, alarm3AlertMode);
                break;
            case R.id.btn_alarm4://闹钟4
                alarmIndex = 4;
                watchAlarmSettingFragment.setAlarm(alarm4Time, alarm4Mode, alarm4AlertMode);
                break;
        }

        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                    .add(R.id.mainContainer, watchAlarmSettingFragment, WatchAlarmSettingFragment.TAG)
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //回退fragment栈
        int stackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        if (stackEntryCount > 0) {
            if (ftCanCommit) {
                getSupportFragmentManager().popBackStack();
            }
            setToolbar(true, R.string.title_activity_watch_alarm_notify);
        } else {
            setResult();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                onBackPressed();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 设置页面结果给请求activity
     */
    private void setResult() {
        if (settingChanged) {//有变更设置
            Intent data = new Intent();
            data.putExtra("alarm1", String.format("%s,%s,%s,%s", alarm1On ? "1" : "0", alarm1Time, alarm1Mode, alarm1AlertMode));//总开关,时间,重复模式,震动模式
            data.putExtra("alarm2", String.format("%s,%s,%s,%s", alarm2On ? "1" : "0", alarm2Time, alarm2Mode, alarm2AlertMode));//总开关,时间,重复模式,震动模式
            data.putExtra("alarm3", String.format("%s,%s,%s,%s", alarm3On ? "1" : "0", alarm3Time, alarm3Mode, alarm3AlertMode));//总开关,时间,重复模式,震动模式
            data.putExtra("alarm4", String.format("%s,%s,%s,%s", alarm4On ? "1" : "0", alarm4Time, alarm4Mode, alarm4AlertMode));//总开关,时间,重复模式,震动模式
            data.putExtra("isOn", alarm1On || alarm2On || alarm3On || alarm4On);//是否有开启闹钟
            setResult(RESULT_OK, data);
        } else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }


    /**
     * 设置 toolbar
     *
     * @param showBack   是否显示返回按钮
     * @param titleResId toolbar标题字符串资源ID
     */
    public void setToolbar(boolean showBack, int titleResId) {
        if (toolbar == null) return;
        TextView btn_left = (TextView) toolbar.findViewById(R.id.btn_left);
        TextView btn_right = (TextView) toolbar.findViewById(R.id.btn_right);
        if (showBack) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            }
            btn_left.setVisibility(View.GONE);
            btn_right.setVisibility(View.VISIBLE);
            btn_left.setText(R.string.ok);
            btn_right.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (watchAlarmSettingFragment != null) {//获取设置结果
                        String alarmResult = watchAlarmSettingFragment.getAlarmString();
                        String[] results = alarmResult.split(",");
                        if (results != null && results.length == 3) {
                            switch (alarmIndex) {
                                case 1:
                                    alarm1Time = results[0];
                                    alarm1Mode = results[1];
                                    alarm1AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm1On, alarm1Time, alarm1Mode);
                                    }
                                    break;
                                case 2:
                                    alarm2Time = results[0];
                                    alarm2Mode = results[1];
                                    alarm2AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm2On, alarm2Time, alarm2Mode);
                                    }
                                    break;
                                case 3:
                                    alarm3Time = results[0];
                                    alarm3Mode = results[1];
                                    alarm3AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm3On, alarm3Time, alarm3Mode);
                                    }
                                    break;
                                case 4:
                                    alarm4Time = results[0];
                                    alarm4Mode = results[1];
                                    alarm4AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm4On, alarm4Time, alarm4Mode);
                                    }
                                    break;
                            }
                        }
                    }
                    settingChanged = true;
                    onBackPressed();
                }
            });
        } else {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            }
            btn_left.setText(R.string.cancel);
            btn_right.setText(R.string.ok);
            btn_left.setVisibility(View.VISIBLE);
            btn_right.setVisibility(View.VISIBLE);
            btn_left.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            btn_right.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (watchAlarmSettingFragment != null) {//获取设置结果
                        String alarmResult = watchAlarmSettingFragment.getAlarmString();
                        Logger.d(Logger.DEBUG_TAG,"alarmResult:"+alarmResult);
                        String[] results = alarmResult.split(",");
                        if (results != null && results.length == 3) {
                            switch (alarmIndex) {
                                case 1:
                                    alarm1Time = results[0];
                                    alarm1Mode = results[1];
                                    alarm1AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm1On, alarm1Time, alarm1Mode);
                                    }
                                    break;
                                case 2:
                                    alarm2Time = results[0];
                                    alarm2Mode = results[1];
                                    alarm2AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm2On, alarm2Time, alarm2Mode);
                                    }
                                    break;
                                case 3:
                                    alarm3Time = results[0];
                                    alarm3Mode = results[1];
                                    alarm3AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm3On, alarm3Time, alarm3Mode);
                                    }
                                    break;
                                case 4:
                                    alarm4Time = results[0];
                                    alarm4Mode = results[1];
                                    alarm4AlertMode = results[2];
                                    if (watchAlarmNotifyFragment != null) {//更新第一个界面
                                        watchAlarmNotifyFragment.setAlarm(alarmIndex, alarm4On, alarm4Time, alarm4Mode);
                                    }
                                    break;
                            }
                        }
                    }
                    settingChanged = true;
                    onBackPressed();
                }
            });
        }

        String title = getString(titleResId);
        if (!TextUtils.isEmpty(title)) {
            setUiTitle(title);
        }
    }

    //region ============================= WatchAlarmNotifyFragment =============================
    @Override
    public void alarmSwitchChange(int index, boolean isChecked) {
        switch (index) {
            case 1:
                alarm1On = isChecked;
                break;
            case 2:
                alarm2On = isChecked;
                break;
            case 3:
                alarm3On = isChecked;
                break;
            case 4:
                alarm4On = isChecked;
                break;
        }
        settingChanged = true;
    }

    //endregion ============================= WatchAlarmNotifyFragment =============================
}
