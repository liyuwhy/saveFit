package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.SwitchCompat;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.service.WatchService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.WatchAppNotify;
import com.fitmix.sdk.watch.bean.WatchSetting;


/**
 * 手表通知选项界面
 */

public class WatchNotifySettingActivity extends BaseWatchActivity implements CompoundButton.OnCheckedChangeListener {

    /**
     * APP通知设置请求
     */
    private static final int REQUEST_WATCH_APP_NOTIFY = 803;

    /**
     * 手表闹钟设置请求
     */
    private static final int REQUEST_WATCH_ALARM = 804;
    /**
     * 久坐提醒设置请求
     */
    private static final int REQUEST_WATCH_LONG_REST = 805;

    /**
     * 请求电话权限
     */
    private static final int REQUEST_CALL_PERMISSION = 806;

    /**
     * 请求短信权限
     */
    private static final int REQUEST_SMS_PERMISSION = 807;

//    private SwitchCompat switch_notification_allow;

    private SwitchCompat switch_call_reminder;//来电提醒
    private SwitchCompat switch_sms_reminder;//短信提醒
    private SwitchCompat switch_storm_warning;//风暴提醒

    private TextView tv_app_notify;//APP通知开启状态
    private TextView tv_alarm_notify;//闹钟开启状态
    private TextView tv_sit_notify;//久坐提醒开启状态

    private boolean isAppNotifyEnable;
    private boolean isAlarmEnable;//是否开启闹钟提醒
    private boolean isSitNotifyEnable;

    private String watchSettingStr;
    private WatchSetting watchSetting;

    /**
     * 保存由WatchSitNotifyActivity返回的久坐提醒设置,设置成功后替换
     */
    private String longRest;
    /**
     * 保存由WatchAlarmNotifyActivity返回的闹钟设置,设置成功后替换
     */
    private String alarm1;
    private String alarm2;
    private String alarm3;
    private String alarm4;

    /**
     * 是否由人为点击开关
     */
    private boolean toggleByMan = true;
    private boolean settingChanged = false;//是否有设置更改

    //region================================== Activity生命周期相关 ==================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_notify_setting);
        setPageName("WatchNotifySettingActivity");
        initToolbar();
        initViews();
        Intent intent = getIntent();
        if (intent != null) {
            watchSettingStr = intent.getStringExtra("watchSettingStr");
            Logger.v(Logger.DEBUG_TAG,"watchSettingStr:"+watchSettingStr);
        }
        initData();
        bindWatchService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        toggleByMan = false;
//        switch_notification_allow.setChecked(isEnabled());
        toggleByMan = true;
        refreshUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindWatchService();
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        switch_call_reminder = (SwitchCompat) findViewById(R.id.switch_call_reminder);
        switch_call_reminder.setOnCheckedChangeListener(this);
        switch_sms_reminder = (SwitchCompat) findViewById(R.id.switch_sms_reminder);
        switch_sms_reminder.setOnCheckedChangeListener(this);

        toggleByMan = false;
        boolean callRemind = PrefsHelper.with(this, Config.PREFS_USER).readBoolean(Config.SP_KEY_WATCH_CALL_NOTIFY, false);
        switch_call_reminder.setChecked(callRemind);
        boolean smsRemind = PrefsHelper.with(this, Config.PREFS_USER).readBoolean(Config.SP_KEY_WATCH_SMS_NOTIFY, false);
        switch_sms_reminder.setChecked(smsRemind);
        toggleByMan = true;


        switch_storm_warning = (SwitchCompat) findViewById(R.id.switch_storm_warning);
        switch_storm_warning.setOnCheckedChangeListener(this);

        tv_app_notify = (TextView) findViewById(R.id.tv_app_notify);
        String appNotifyStr = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_APP_NOTIFY);
        WatchAppNotify appNotify = JsonHelper.getObject(appNotifyStr, WatchAppNotify.class);
        if (appNotify != null) {
            isAppNotifyEnable = appNotify.isAppNotify();
        }
        tv_alarm_notify = (TextView) findViewById(R.id.tv_alarm_notify);
        tv_sit_notify = (TextView) findViewById(R.id.tv_sit_notify);

//        switch_notification_allow = (SwitchCompat) findViewById(R.id.switch_notification_allow);
//        switch_notification_allow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if (toggleByMan) {
//                    requestNotificationListener();
//                }
//            }
//        });
    }

    private void initData() {
        if (watchSettingStr == null) {
            watchSettingStr = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_SETTING);
        }
        if (watchSettingStr != null) {
            watchSetting = JsonHelper.getObject(watchSettingStr, WatchSetting.class);
            if (watchSetting != null) {
                String stormAlert = watchSetting.getStormAlert();
                String longRestAlert = watchSetting.getLongRestAlert();
                String alarm1 = watchSetting.getAlarm1();
                String alarm2 = watchSetting.getAlarm2();
                String alarm3 = watchSetting.getAlarm3();
                String alarm4 = watchSetting.getAlarm4();
                Logger.i(Logger.DEBUG_TAG, "WatchNotifySettingActivity-->initData stormAlert:" + stormAlert
                        + ",longRestAlert:" + longRestAlert + ",alarm1:" + alarm1 + ",alarm2:" + alarm2
                        + ",alarm3:" + alarm3 + ",alarm4:" + alarm4);
                if (stormAlert != null) {//风暴预警
                    try {
                        int state = Integer.parseInt(stormAlert);
                        if (switch_storm_warning != null) {
                            toggleByMan = false;
                            switch_storm_warning.setChecked(state == 1);
                            toggleByMan = true;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                if (longRestAlert != null) {//久坐提醒
                    try {
                        String[] longRests = longRestAlert.split(",");//总开关,午休免扰开关,开始时间,结束时间
                        if (longRests != null && longRests.length > 0) {
                            int state = Integer.parseInt(longRests[0]);
                            isSitNotifyEnable = (state == 1);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                if (alarm1 != null) {//闹钟1
                    try {
                        String[] alarm = alarm1.split(",");//总开关,时间,重复模式,震动模式
                        if (alarm != null && alarm.length > 0) {
                            int state = Integer.parseInt(alarm[0]);
                            if (state == 1) {
                                isAlarmEnable = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (alarm2 != null) {//闹钟2
                    try {
                        String[] alarm = alarm2.split(",");//总开关,时间,重复模式,震动模式
                        if (alarm != null && alarm.length > 0) {
                            int state = Integer.parseInt(alarm[0]);
                            if (state == 1) {
                                isAlarmEnable = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (alarm3 != null) {//闹钟3
                    try {
                        String[] alarm = alarm3.split(",");//总开关,时间,重复模式,震动模式
                        if (alarm != null && alarm.length > 0) {
                            int state = Integer.parseInt(alarm[0]);
                            if (state == 1) {
                                isAlarmEnable = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (alarm4 != null) {//闹钟4
                    try {
                        String[] alarm = alarm4.split(",");//总开关,时间,重复模式,震动模式
                        if (alarm != null && alarm.length > 0) {
                            int state = Integer.parseInt(alarm[0]);
                            if (state == 1) {
                                isAlarmEnable = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                refreshUi();
            }
        }
    }

    /**
     * 刷新界面提示
     */
    private void refreshUi() {
        //APP通知开启状态
        if (isAppNotifyEnable) {
            if (tv_app_notify != null) {
                tv_app_notify.setText(R.string.activity_watch_notify_setting_on);
                tv_app_notify.setTextColor(ContextCompat.getColor(this, R.color.orange_text));
            }
        } else {
            if (tv_app_notify != null) {
                tv_app_notify.setText(R.string.activity_watch_notify_setting_off);
                tv_app_notify.setTextColor(ContextCompat.getColor(this, R.color.white_new_text));
            }
        }

        //闹钟开启状态
        if (isAlarmEnable) {
            if (tv_alarm_notify != null) {
                tv_alarm_notify.setText(R.string.activity_watch_notify_setting_on);
                tv_alarm_notify.setTextColor(ContextCompat.getColor(this, R.color.orange_text));
            }
        } else {
            if (tv_alarm_notify != null) {
                tv_alarm_notify.setText(R.string.activity_watch_notify_setting_off);
                tv_alarm_notify.setTextColor(ContextCompat.getColor(this, R.color.white_new_text));
            }
        }

        //久坐提醒开启状态
        if (isSitNotifyEnable) {
            if (tv_sit_notify != null) {
                tv_sit_notify.setText(R.string.activity_watch_notify_setting_on);
                tv_sit_notify.setTextColor(ContextCompat.getColor(this, R.color.orange_text));
            }
        } else {
            if (tv_sit_notify != null) {
                tv_sit_notify.setText(R.string.activity_watch_notify_setting_off);
                tv_sit_notify.setTextColor(ContextCompat.getColor(this, R.color.white_new_text));
            }
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                setResult();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                setResult();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 设置页面结果给请求activity
     */
    private void setResult() {
        if (settingChanged) {//通知WatchActivity重新查询手表设置
            setResult(RESULT_OK);
        } else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    //endregion================================== Activity生命周期相关 ==================================

    //region ========================== Override 父类方法 ==========================
    @Override
    protected void initWatchServiceFunction() {
        mWatchServiceFun = new WatchService.ServiceFunction() {

            @Override
            public void onDeviceConnected() {
                //不处理
            }

            @Override
            public void onDeviceReady() {
                //不处理
            }

            @Override
            public void onDeviceDisconnected() {
                //不处理
            }

            @Override
            public void onResponse(int groupTag, final int cell, int iPos, final int result) {
                switch (groupTag) {
                    case WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS://APP端其它手表设置
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (result == WatchDataProtocol.PACKAGE_RESULT_SUCCESS) {
                                    switch (cell) {
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_STORM_ALERT:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_storm_success, Toast.LENGTH_SHORT).show();
                                            break;
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_LONG_REST_ALERT:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_rest_success, Toast.LENGTH_SHORT).show();
                                            if (longRest != null && watchSetting != null) {
                                                watchSetting.setLongRestAlert(longRest);
                                            }
                                            break;
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM1:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM2:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM3:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM4:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_alarm_success, Toast.LENGTH_SHORT).show();
                                            if (watchSetting != null) {
                                                watchSetting.setAlarm1(alarm1);
                                                watchSetting.setAlarm2(alarm2);
                                                watchSetting.setAlarm3(alarm3);
                                                watchSetting.setAlarm4(alarm4);
                                            }
                                            break;
                                    }

                                } else {
                                    switch (cell) {
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_STORM_ALERT:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_storm_fail, Toast.LENGTH_SHORT).show();
                                            break;
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_LONG_REST_ALERT:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_rest_fail, Toast.LENGTH_SHORT).show();
                                            break;
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM1:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM2:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM3:
                                        case WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM4:
                                            Toast.makeText(WatchNotifySettingActivity.this, R.string.activity_watch_notify_setting_alarm_fail, Toast.LENGTH_SHORT).show();
                                            break;
                                    }
                                }
                            }
                        });
                        break;
                }
            }

            @Override
            public void onReceiveDataRefreshUi(int groupTag, final String dataJson) {
                if (groupTag == WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS && dataJson != null) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            watchSettingStr = dataJson;//更新设置
                            initData();
                        }
                    });
                }
            }
        };
    }

    //endregion ========================== Override 父类方法 ==========================

    //region ================================== 手表通讯指令相关 ==================================

//    /**
//     * 查询手表设置
//     */
//    private void querySettings() {
//        if (watchService != null && watchService.ifBLEFunctionOk()) {
//            byte[] data = WatchFormatManager.getWatchOtherSettingData();
//            if (watchService != null) {
//                int tag = WatchFormatManager.generateTag(
//                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_QUERY);
//                watchService.sendTotallyDataCmd(tag, data);
//            }
//
//        } else {
//            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
//        }
//    }

    /**
     * 设置风暴预警
     *
     * @param stormAlert true:开启风暴预警,false:关闭风暴预警
     */
    private void setStormAlert(boolean stormAlert) {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getStormAlert(stormAlert);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_STORM_ALERT);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置久坐提醒
     *
     * @param longRest 久坐提醒设置,总开关,午休免扰开关,开始时间,结束时间
     */
    private void setLongSitAlert(String longRest) {
        Logger.d(Logger.DEBUG_TAG, "久坐提醒设置:" + longRest);
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getLongSitAlert(longRest);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_LONG_REST_ALERT);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置闹钟提醒
     *
     * @param alarm1 闹钟1设置,格式为总开关,时间,重复模式,震动模式
     * @param alarm2 闹钟2设置,格式为总开关,时间,重复模式,震动模式
     * @param alarm3 闹钟3设置,格式为总开关,时间,重复模式,震动模式
     * @param alarm4 闹钟4设置,格式为总开关,时间,重复模式,震动模式
     */
    private void setAlarms(String alarm1, String alarm2, String alarm3, String alarm4) {
        Logger.d(Logger.DEBUG_TAG, "设置闹钟提醒:" + alarm1);
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getAlarms(alarm1, alarm2, alarm3, alarm4);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_ALARM1);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }


    //endregion ================================== 手表通讯指令相关 ==================================

    //region================================== 来电监听、短信监听相关 ==================================


    /**
     * 请求电话权限
     */
    public void requestPhonePermission() {
        String message = String.format(getString(R.string.request_permission_format), getString(R.string.phone_state_permission_concise));
        permissionDialog = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .content(message)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                Intent intent = getAppDetailSettingIntent();
                                startActivityForResult(intent, REQUEST_CALL_PERMISSION);
                                break;
                        }
                    }
                }).build();
        if (permissionDialog != null) {
            permissionDialog.show();
        }
    }

    /**
     * 请求短信权限
     */
    public void requestSmsPermission() {
        String message = String.format(getString(R.string.request_permission_format), getString(R.string.sms_permission_concise)
                + "\n" + getString(R.string.read_sms_permission_concise));
        permissionDialog = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .content(message)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                Intent intent = getAppDetailSettingIntent();
                                startActivityForResult(intent, REQUEST_SMS_PERMISSION);
                                break;
                        }
                    }
                }).build();
        if (permissionDialog != null) {
            permissionDialog.show();
        }
    }

    /**
     * 获取应用详情页面intent
     *
     * @return
     */
    private Intent getAppDetailSettingIntent() {
        Intent localIntent = new Intent();
        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        if (Build.VERSION.SDK_INT >= 9) {
        localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        localIntent.setData(Uri.fromParts("package", getPackageName(), null));
//        } else if (Build.VERSION.SDK_INT <= 8) {
//            localIntent.setAction(Intent.ACTION_VIEW);
//            localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
//            localIntent.putExtra("com.android.settings.ApplicationPkgName", getPackageName());
//        }
        return localIntent;
    }

    //endregion================================== 来电监听、短信监听相关 ==================================

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (toggleByMan) {
            switch (buttonView.getId()) {
                case R.id.switch_call_reminder://来电提醒
                    //请求监听电话权限
                    if (isChecked) {
                        if (permissionIsGranted(Manifest.permission.READ_PHONE_STATE)) {
                            PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_CALL_NOTIFY, true);
                        } else {
                            requestPhonePermission();
                            if (switch_call_reminder != null) {//状态回滚
                                toggleByMan = false;
                                switch_call_reminder.setChecked(false);
                                toggleByMan = true;
                            }
                        }
                    } else {
                        PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_CALL_NOTIFY, false);
                    }
                    break;

                case R.id.switch_sms_reminder://短信提醒
                    //请求监听短信权限
                    if (isChecked) {
                        if (permissionIsGranted(Manifest.permission.RECEIVE_SMS) &&
                                permissionIsGranted(Manifest.permission.READ_SMS)) {
                            PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_SMS_NOTIFY, true);
                        } else {
                            requestSmsPermission();
                            if (switch_sms_reminder != null) {//状态回滚
                                toggleByMan = false;
                                switch_sms_reminder.setChecked(false);
                                toggleByMan = true;
                            }
                        }
                    } else {
                        PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_SMS_NOTIFY, false);
                    }
                    break;

                case R.id.switch_storm_warning://风暴提醒
                    settingChanged = true;
                    setStormAlert(isChecked);
                    break;
            }
        }
    }

    public void doClick(View view) {
        Intent intent = new Intent();
        switch (view.getId()) {
            case R.id.btn_app_notify://APP通知
                intent.setClass(this, WatchAppNotifyActivity.class);
                startActivityForResult(intent, REQUEST_WATCH_APP_NOTIFY);
                break;

            case R.id.btn_alarm_notify://闹钟提醒
                intent.setClass(this, WatchAlarmNotifyActivity.class);
                if (watchSetting != null) {
                    intent.putExtra("alarm1", watchSetting.getAlarm1());
                    intent.putExtra("alarm2", watchSetting.getAlarm2());
                    intent.putExtra("alarm3", watchSetting.getAlarm3());
                    intent.putExtra("alarm4", watchSetting.getAlarm4());
                }
                startActivityForResult(intent, REQUEST_WATCH_ALARM);
                break;

            case R.id.btn_sit_notify://久坐提醒
                intent.setClass(this, WatchSitNotifyActivity.class);
                if (watchSetting != null) {
                    intent.putExtra("longRest", watchSetting.getLongRestAlert());
                }
                startActivityForResult(intent, REQUEST_WATCH_LONG_REST);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Logger.i(Logger.DEBUG_TAG, "WatchNotifySettingActivity-->onActivityResult requestCode:" + requestCode
                + ",resultCode:" + resultCode);
        switch (requestCode) {
            case REQUEST_WATCH_APP_NOTIFY:
                String appNotifyStr = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_APP_NOTIFY);//重新获取状态
                WatchAppNotify appNotify = JsonHelper.getObject(appNotifyStr, WatchAppNotify.class);
                if (appNotify != null) {
                    isAppNotifyEnable = appNotify.isAppNotify();
                }
                refreshUi();
                break;

            case REQUEST_WATCH_ALARM:
                if (resultCode == RESULT_OK) {
                    settingChanged = true;
                    if (data != null) {
                        alarm1 = data.getStringExtra("alarm1");
                        alarm2 = data.getStringExtra("alarm2");
                        alarm3 = data.getStringExtra("alarm3");
                        alarm4 = data.getStringExtra("alarm4");
                        isAlarmEnable = data.getBooleanExtra("isOn", false);
                        setAlarms(alarm1, alarm2, alarm3, alarm4);
                        Logger.i(Logger.DEBUG_TAG, "WatchNotifySettingActivity-->onActivityResult alarm1:" + alarm1 + ",alarm2:" + alarm2
                                + ",alarm3:" + alarm3 + ",alarm4:" + alarm4 + "isAlarmEnable:" + isAlarmEnable);
                        refreshUi();
                    }
                }
                break;
            case REQUEST_WATCH_LONG_REST:
                if (resultCode == RESULT_OK) {
                    settingChanged = true;
                    if (data != null) {
                        longRest = data.getStringExtra("longRest");
                        isSitNotifyEnable = data.getBooleanExtra("isOn", false);
                        if (longRest != null) {
                            setLongSitAlert(longRest);
                            Logger.i(Logger.DEBUG_TAG, "WatchNotifySettingActivity-->onActivityResult longRest:" + longRest);
                        }
                        refreshUi();
                    }
                }
                break;

            case REQUEST_CALL_PERMISSION:
                if (permissionIsGranted(Manifest.permission.READ_PHONE_STATE)) {//再次检查权限
                    if (switch_call_reminder != null) {
                        toggleByMan = false;
                        switch_call_reminder.setChecked(true);
                        toggleByMan = true;
                    }
                    PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_CALL_NOTIFY, true);
                }
                break;

            case REQUEST_SMS_PERMISSION:
                if (permissionIsGranted(Manifest.permission.RECEIVE_SMS) &&
                        permissionIsGranted(Manifest.permission.READ_SMS)) {//再次检查权限
                    if (switch_sms_reminder != null) {
                        toggleByMan = false;
                        switch_sms_reminder.setChecked(true);
                        toggleByMan = true;
                    }
                    PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_WATCH_SMS_NOTIFY, true);
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
