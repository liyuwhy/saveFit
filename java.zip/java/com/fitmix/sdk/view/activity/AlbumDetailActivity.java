package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.DataSource;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.MixPageInfo;
import com.fitmix.sdk.model.api.bean.RecommendMixList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MusicInfo;
import com.fitmix.sdk.model.database.MusicInfoHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.RecommendMixAdapter;
import com.fitmix.sdk.view.adapter.SongsAdapter;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.dialog.MoreActionDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class AlbumDetailActivity extends BaseActivity {
    private static final int CHANGE_ALBUM_INFO = 123;
    private static final int SELECT_SONG_ADD_TO_LIST = 125;
    private SimpleDraweeView img_album_cover;
    private TextView tv_album_name;
    private TextView tv_album_pace;
    private TextView tv_album_bpm;
    private TextView tv_album_description;
    private CheckBox ckb_play_all;
    private LinearLayout gridView_container;//推荐歌曲容器

    private SongsAdapter adapter;
    private RecommendMixAdapter mixAdapter;
    private Album album;
    private int index = 0;
    private SwipeLoadLayout swipeLayout;
    private Music tempMusic;//用来处理收藏等操作的中间变量
    private Music tempMusic_share;//用于分享操作的中间变量

    public static final int SORT_TYPE_RECENTLY = 1;
    public static final int SORT_TYPE_HOTEST = 2;

    private int contentType;//本activity有两种类型（音乐和电台）,代表内容为运动歌单详情（1）或者电台详情（2）
    private RadioGroup rg_sort_type;//排序类别的radioGroup
    private RadioButton rb_recently;
    private RadioButton rb_hotest;
    private ImageButton btn_edit_album;//当为自建歌单的情况下显示的编辑按钮

    private LinearLayout ll_music_pace;//配速的linearLayout
    private LinearLayout ll_music_bpm;//节拍的linearLayout

    private ListView list_songs;//歌曲列表
    private GridView gv_recommend;//推荐歌曲存放的gridview,四个item

    //private DownloadInfoListener downloadInfoListener;//下载管理监听器

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //透明导航栏
            //getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album_detail);
        setPageName("AlbumDetailActivity");
        contentType = getIntent().getIntExtra("ContentType", Config.REQUEST_MUSIC_ALBUM);
        String albumString = getIntent().getStringExtra("albumString");
        if (!TextUtils.isEmpty(albumString))
            album = JsonHelper.getObject(albumString, Album.class);
        initToolbar();
        initViews();
        //android 6.0权限
        getPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);//下载音乐用到
        startRefreshList();
    }

    //region =============================initView======================
    protected void initViews() {
        rg_sort_type = (RadioGroup) findViewById(R.id.rg_sort_type);
        rb_recently = ((RadioButton) findViewById(R.id.rb_recently));
        rb_hotest = ((RadioButton) findViewById(R.id.rb_hotest));
        rb_recently.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.fitmix_yellow));
        rb_hotest.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.white_text));

        rg_sort_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_recently:
                        index = 0;
                        rb_recently.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.fitmix_yellow));
                        rb_hotest.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.white_text));
                        sendListRequestAndRefresh();
                        if (gv_recommend != null) {
                            if (list_songs != null) {
                                list_songs.smoothScrollToPositionFromTop(1, 0);
                            }
                        } else {
                            if (list_songs != null) {
                                list_songs.smoothScrollToPositionFromTop(0, 0);
                            }
                        }
                        break;
                    case R.id.rb_hotest:
                        index = 0;
                        rb_recently.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.white_text));
                        rb_hotest.setTextColor(ContextCompat.getColor(AlbumDetailActivity.this, R.color.fitmix_yellow));
                        sendListRequestAndRefresh();

                        if (gv_recommend != null) {
                            if (list_songs != null) {
                                list_songs.smoothScrollToPositionFromTop(1, 0);
                            }
                        } else {
                            if (list_songs != null) {
                                list_songs.smoothScrollToPositionFromTop(0, 0);
                            }
                        }
                        break;
                }
            }
        });


        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        img_album_cover = (SimpleDraweeView) findViewById(R.id.img_album_cover);
        tv_album_name = (TextView) findViewById(R.id.tv_album_name);
        tv_album_pace = (TextView) findViewById(R.id.tv_album_pace);
        tv_album_bpm = (TextView) findViewById(R.id.tv_album_bpm);
        tv_album_description = (TextView) findViewById(R.id.tv_album_description);
        btn_edit_album = (ImageButton) findViewById(R.id.btn_edit_album);

        ll_music_pace = (LinearLayout) findViewById(R.id.ll_music_pace);
        ll_music_bpm = (LinearLayout) findViewById(R.id.ll_music_bpm);


        if (contentType == Config.REQUEST_RADIO_ALBUM) {
            ll_music_pace.setVisibility(View.GONE);
            ll_music_bpm.setVisibility(View.INVISIBLE);
            btn_edit_album.setVisibility(View.GONE);
        } else {
            ll_music_pace.setVisibility(View.VISIBLE);
            ll_music_bpm.setVisibility(View.VISIBLE);

            if (getAlbum() != null && getAlbum().getValue() == 0) {//自建歌单,可修改歌单信息
                btn_edit_album.setVisibility(View.VISIBLE);
                rg_sort_type.setVisibility(View.GONE);
            } else {
                btn_edit_album.setVisibility(View.GONE);
                rg_sort_type.setVisibility(View.VISIBLE);
            }
        }

        ckb_play_all = (CheckBox) findViewById(R.id.ckb_play_all);
        ckb_play_all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ckb_play_all.setChecked(false);
                playAll();
//                if(getMusicList()!=null && getMusicList().size()>0){
//                    gotoPlayMusicActivity(0);
//                }
            }
        });

        list_songs = (ListView) findViewById(R.id.swipe_target);

        list_songs.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        emptyView.setText(getString(R.string.fm_album_detail_list_empty_hint));
        list_songs.setEmptyView(emptyView);

        if (contentType == Config.REQUEST_MUSIC_ALBUM) {//仅仅为歌单详情的情况下有girdview
            if (getAlbum() != null && getAlbum().getValue() != 0) {//自建歌单,可修改歌单信息
                View view = LayoutInflater.from(this).inflate(R.layout.activity_album_detail_mix, null);
                gv_recommend = (GridView) view.findViewById(R.id.music_list_topView);
                gridView_container = (LinearLayout) view.findViewById(R.id.gridView_container);
                gv_recommend.setAdapter(getMixAdapter());

                getMixAdapter().setOnMixActionClickListener(new RecommendMixAdapter.MixActionClickListener() {
                    @Override
                    public void onMixPlayActionClick(int position, int musicID) {
                        gotoPlayingScreen(position, musicID);
                    }
                });
                list_songs.addHeaderView(view);

            }
        }
        swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
        swipeLayout.setLoadMoreEnabled(false);
        swipeLayout.setOnLoadMoreListener(new SwipeLoadLayout.OnLoadMoreListener() {

            @Override
            public void onLoadMore() {
                sendListRequestAndRefresh();
            }
        });

        //当为本地或者推荐专辑时 不可以上拉加载
        if ((album != null && album.getValue() == 0) || contentType == Config.REQUEST_RECOMMEND_ALBUM) {
            swipeLayout.setLoadMoreEnabled(false);
        }
        list_songs.setAdapter(getSongsAdapter());

        getSongsAdapter().setOnSonsActionClickListener(new SongsAdapter.SongsActionClickListener() {
            @Override
            public void onSongPlayActionClick(int position, int musicID) {
                gotoPlayingScreen(position, musicID);
            }

            @Override
            public void onSongMoreActionClick(int musicID) {
                showMoreActionDialog(getMusic(musicID), getListType());
            }
        });

        list_songs.setOnItemClickListener(null);

    }
    //endregion =============================initView======================

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        switch (requestId) {
            case Config.MODULE_MUSIC + 3://获取音乐列表
            case Config.MODULE_MUSIC + 7://获取电台详情列表
                refreshList(dataReqResult.getResult());
                break;
            case Config.MODULE_MUSIC + 4://音乐收藏或者取消
                favoriteSwitchInLocale(tempMusic);
                break;
            case Config.MODULE_MUSIC + 10://获取推荐专辑详情列表
                refreshListForRecommend(dataReqResult.getResult());
                break;

            case Config.MODULE_USER + 59://完成每日分享音乐金币任务
            case Config.MODULE_USER + 62://完成每日播放音乐金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            if (requestId == Config.MODULE_USER + 59) {//分享音乐
                                SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_MIX, System.currentTimeMillis());//设置完成任务时间
                            } else {//播放音乐
                                SettingsHelper.putLong(Config.SETTING_COIN_TASK_PLAY_MIX, System.currentTimeMillis());//设置完成任务时间
                            }

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

//    @Override
//    protected void processReqError(int errorCode) {
//        stopLoadError();
//        super.processReqError(errorCode);
//    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_MUSIC + 3://获取音乐列表
            case Config.MODULE_MUSIC + 7://获取电台详情列表
                stopLoadError();
                break;
            case Config.MODULE_MUSIC + 4://音乐收藏或者取消
            case Config.MODULE_MUSIC + 10://获取推荐专辑详情列表
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }


    //region =============================刷新======================

    @Override
    protected void onMusicChanged() {
        getSongsAdapter().notifyDataSetChanged();
        getMixAdapter().notifyDataSetChanged();
        super.onMusicChanged();
    }

    @Override
    protected void onMusicPlayStateChanged() {
        getSongsAdapter().notifyDataSetChanged();
        getMixAdapter().notifyDataSetChanged();
        super.onMusicPlayStateChanged();

        finishPlayMixCoinTask();//完成每日播放歌曲金币任务
    }

    @Override
    public void onResume() {
        super.onResume();
        if (album == null) {//用来刷新图像显示
            refreshJustOne();
        }
        if (getAlbum() != null && getAlbum().getValue() == 0) {
            getSongsAdapter().setMusicList(OperateMusicUtils.getMusicByAlbumId(getAlbum().getId()));
        }
        //setDownLoadListener();
        getMixAdapter().notifyDataSetChanged();
        getSongsAdapter().notifyDataSetChanged();
    }

    @Override
    protected void onStop() {
        //removeDownLoadListener();
        super.onStop();
    }

    /**
     * 显示加载完成
     */
    public void stopLoading() {
        if (swipeLayout != null) {
            swipeLayout.setLoadMoreEnabled(true);//当列表内有数据的时候才可以上拉加载
            swipeLayout.setLoadingMore(false);
        }
    }

    /**
     * 显示没有更多
     */
    public void stopLoadNothing() {
        if (swipeLayout != null)
            swipeLayout.setLoadingNothing();
    }

    /**
     * 显示加载失败
     */
    public void stopLoadError() {
        if (swipeLayout != null)
            swipeLayout.setLoadingError();
    }

    /**
     * @return 歌曲封面是否存在于本地文件中
     */
    private boolean checkAlbumCoverExist(Album album) {
        if (album == null) return false;
        String s = FitmixUtil.getCoverPath() + album.getId() + ".jpg";
        File file = new File(s);
        return file.exists();
    }

    private void setHeadView() {
        if (getAlbum() == null || getAlbum().getAlbumInfo() == null || TextUtils.isEmpty(getAlbum().getAlbumInfo().getImage())) {
            return;
        }
        BaseBitmapDataSubscriber baseBitmapDataSubscriber = new BaseBitmapDataSubscriber() {
            @Override
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                convertBmp(bitmap);
            }

            @Override
            public void onFailureImpl(DataSource dataSource) {
                convertBmp(null);
            }
        };
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(getAlbum().getAlbumInfo().getImage()))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, this);
        dataSource.subscribe(baseBitmapDataSubscriber, CallerThreadExecutor.getInstance());
    }

    public void convertBmp(Bitmap bmp) {
        if (bmp == null) {
            img_album_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_album)).build());
        } else {
            try {
                int w = bmp.getWidth();
                int h = bmp.getHeight();
                Matrix matrix = new Matrix();
                //matrix.postScale(1, -1); //镜像垂直翻转
                matrix.postScale(-1, 1); //镜像水平翻转
                //matrix.postRotate(-90); //旋转-90度
                Bitmap convertBmp = Bitmap.createBitmap(bmp, 0, 0, w, h, matrix, false);
                img_album_cover.setScaleType(ImageView.ScaleType.FIT_XY);
                img_album_cover.setImageBitmap(convertBmp);
            } catch (Exception e) {
                img_album_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_album)).build());
            }

        }
    }


    /**
     * 只需要刷新一次
     */
    private void refreshJustOne() {
        if (getAlbum() == null) finish();
        if (getAlbum().getValue() == 0) {
            if (checkAlbumCoverExist(album)) {
                img_album_cover.setImageURI(Uri.fromFile(new File(album.getAlbumInfo().getImage())));
            } else {
                img_album_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_album)).build());
            }
        } else {
            if (checkAlbumCoverExist(album)) {
                String localFile = FitmixUtil.getCoverPath() + album.getId() + ".jpg";
                Uri uri = Uri.parse(localFile);
                Bitmap bmp = BitmapFactory.decodeFile(uri.toString());
                convertBmp(bmp);
            } else {
                if (getAlbum().getAlbumInfo() != null) {
                    if (TextUtils.isEmpty(getAlbum().getAlbumInfo().getImage())) {//默认专辑图片
                        img_album_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_album)).build());
                    } else {
                        if (contentType == SORT_TYPE_RECENTLY) {//专辑
                            setHeadView();
                        } else {//电台
                            img_album_cover.setImageURI(Uri.parse(getAlbum().getAlbumInfo().getImage()));
                        }
                    }
                }
            }
        }
        if (getAlbum() != null) {
            if (!TextUtils.isEmpty(getAlbum().getName())) {
                tv_album_name.setText(getAlbum().getName().trim());//专辑名称
            } else {
                tv_album_name.setText(getAlbum().getName());//专辑名称
            }

            if (getAlbum().getAlbumInfo() != null) {
                if (!TextUtils.isEmpty(getAlbum().getAlbumInfo().getPaceSpeed())) {
                    tv_album_pace.setText(getAlbum().getAlbumInfo().getPaceSpeed().trim());//运动配速
                } else {
                    tv_album_pace.setText(getAlbum().getAlbumInfo().getPaceSpeed());//运动配速
                }
                if (!TextUtils.isEmpty(getAlbum().getAlbumInfo().getRhythm())) {
                    tv_album_bpm.setText(getAlbum().getAlbumInfo().getRhythm().trim());//节拍
                } else {
                    tv_album_bpm.setText(getAlbum().getAlbumInfo().getRhythm());//节拍
                }
                if (!TextUtils.isEmpty(getAlbum().getAlbumInfo().getDesc())) {
                    tv_album_description.setText(getAlbum().getAlbumInfo().getDesc().trim());//说明
                } else {
                    tv_album_description.setText(getAlbum().getAlbumInfo().getDesc());//说明
                }
            }
        }
    }

//    /**
//     * 移除监听
//     */
//    private void removeDownLoadListener() {
//        getDownloadController().removeDownloadListener();
//    }

//    /**
//     * 设置下载的监听器
//     */
//    private void setDownLoadListener() {
//        if (downloadInfoListener == null) {
//            downloadInfoListener = new DownloadInfoListener() {
//                @Override
//                public void onPrepare(DownloadInfo downloadInfo) {
//
//                }
//
//                @Override
//                public void onDownloading(DownloadInfo downloadInfo) {
//
//                }
//
//                @Override
//                public void onPause(DownloadInfo downloadInfo) {
//
//                }
//
//                @Override
//                public void onCompleted(DownloadInfo downloadInfo) {
//                    getSongsAdapter().notifyDataSetChanged();
//                }
//
//                @Override
//                public void onCancel(DownloadInfo downloadInfo) {
//                }
//
//                @Override
//                public void onFail(DownloadInfo downloadInfo, String errorMsg) {
//                }
//
//                @Override
//                public void onExist(DownloadInfo downloadInfo) {
//
//                }
//            };
//        }
//        getDownloadController().setDownloadListener(downloadInfoListener);
//    }

//    private DownloadUploadController getDownloadController() {
//        return DownloadUploadController.getInstance();
//    }

    //endregion =============================刷新======================

    //region =============================音乐请求操作======================

    public void startRefreshList() {
        if (getAlbum() != null) {
            refreshJustOne();
            if (getAlbum().getValue() == 0) {//本地专辑
                if (contentType == Config.REQUEST_MUSIC_ALBUM) {
                    getSongsAdapter().setMusicList(OperateMusicUtils.getMusicByAlbumId(getAlbum().getId()));
                }
            } else {
                sendListRequestAndRefresh();
            }
        }
    }

    /**
     * 发送请求并刷新当前的页面
     */
    private void sendListRequestAndRefresh() {
        int sort_type = SORT_TYPE_RECENTLY;
        if (!rb_recently.isChecked()) {
            sort_type = SORT_TYPE_HOTEST;
        }
        int requestId = -1;
        switch (contentType) {
            case Config.REQUEST_MUSIC_ALBUM:
                requestId = MusicDataManager.getInstance().getMusicListFromServerBySceneAndIndex(getAlbum().getValue(), index, contentType, sort_type, true);
                break;
            case Config.REQUEST_RADIO_ALBUM:
                requestId = MusicDataManager.getInstance().getRadioListFromServerBySceneAndIndex(getAlbum().getValue(), index, contentType, sort_type, true);
                break;
            case Config.REQUEST_RECOMMEND_ALBUM:
                requestId = MusicDataManager.getInstance().getRadioListFromServerByAlbumId(getAlbum().getId(), true);
                break;
        }
        registerDataReqStatusListener(requestId);
    }

    //endregion =============================音乐请求操作======================

    //region =============================音乐适配器 和 歌曲数据 等数据获取======================

    /**
     * @return 获取专辑信息
     */
    public Album getAlbum() {
        if (album == null) album = getMyConfig().getMemExchange().getCurrentAlbum();
        return album;
    }

    /**
     * @return 获取适配器
     */
    private SongsAdapter getSongsAdapter() {
        if (adapter == null) adapter = new SongsAdapter(this);
        return adapter;
    }

    /**
     * @return 总列表 包括推荐音乐列表 和 正常音乐列表
     */
    private List<Music> getPlayList() {
        List<Music> list = new ArrayList<>();
        list.addAll(getRecommendList());
        list.addAll(getMusicList());
        return list;
    }

    /**
     * @return 获取适配器
     */

    private RecommendMixAdapter getMixAdapter() {
        if (mixAdapter == null) mixAdapter = new RecommendMixAdapter(this);
        return mixAdapter;
    }

    /**
     * @return 获取歌曲列表
     */
    private List<Music> getMusicList() {
        return getSongsAdapter().getMusicList();
    }

    /**
     * @return 获取推荐歌曲列表
     */
    private List<Music> getRecommendList() {
        return getMixAdapter().getList();
    }

    /**
     * @return 列表类型
     */
    public int getListType() {
        if (getAlbum() == null) finish();
        return getAlbum().getValue() == 0 ? Config.LIST_TYPE_SELF : Config.LIST_TYPE_SCENE;
    }
    //endregion =============================音乐适配器 和 歌曲数据 等数据获取======================

    //region =============================点击操作======================

    /**
     * 播放全部
     */
    public void playAll() {
        if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_MOBILE) {
            new MaterialDialog.Builder(this)
                    .title(R.string.warning)
                    .content(R.string.downstream_control)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE://开始播放
                                    SettingsHelper.putInt(Config.SETTING_PLAY_MODE, 1);
                                    getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);
                                    getMyConfig().getPlayer().setPlayList(getPlayList());
                                    getMyConfig().getPlayer().playHeadOfList(true);
                                    invalidateOptionsMenu();
                                    break;
                                case NEGATIVE:
                                    break;
                            }
                        }
                    }).show();
        } else if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_WIFI) {
            SettingsHelper.putInt(Config.SETTING_PLAY_MODE, 1);
            getMyConfig().getPlayer().setPlayMode(PlayerController.MODE_REPEAT_ALL);
            getMyConfig().getPlayer().setPlayList(getPlayList());
            getMyConfig().getPlayer().playHeadOfList(true);
            invalidateOptionsMenu();
        } else {
            String info = getResources().getString(R.string.check_network);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
        }
    }

    private void gotoPlayingScreen(int index, int musicId) {
        getMyConfig().getPlayer().setPlayList(getPlayList());
        OperateMusicUtils.setPlayingMusic(musicId);
        Intent intent = new Intent(this, PlayMusicActivity.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }

    public void setTotalMusic() {
        getMyConfig().getMemExchange().setListMusicSelect(getPlayList());
    }

    /**
     * 选歌
     */
    public void selectSongs() {
        setTotalMusic();
        Intent intent = new Intent(this, SelectSongActivity.class);
        intent.putExtra("currentAlbumId", getAlbum().getId());
        intent.putExtra("FromAlbum", true);
        intent.putExtra("ListType", getListType());
        startActivityForResult(intent, SELECT_SONG_ADD_TO_LIST);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_edit_album://编辑自定义专辑
                Intent intent = new Intent(this, EditPlaylistActivity.class);
                Bundle mBundle = new Bundle();
                String albumString = JsonHelper.createJsonString(getAlbum());
                mBundle.putString("currentAlbum", albumString);
                intent.putExtras(mBundle);
                startActivityForResult(intent, CHANGE_ALBUM_INFO);
                getMyConfig().getMemExchange().setCurrentAlbum(album);
                album = null;
                break;

            case R.id.btn_choose_song://选择歌曲
                selectSongs();
                break;
        }
    }

    //endregion =============================点击操作======================

    //region =============================音乐更多操作======================

    /**
     * 显示更多操作栏
     *
     * @param music    要进行操作的音乐
     * @param listType 列表类型 用来控制 操作的不同方式
     */
    public void showMoreActionDialog(final Music music, final int listType) {
        if (music == null) {
            return;
        }
        MoreActionDialog moreActionDialog = new MoreActionDialog();
        moreActionDialog.setListType(listType);
        moreActionDialog.setMusic(music);
        moreActionDialog.setOnActionClickListener(new MoreActionDialog.ActionTypeClickListener() {
            @Override
            public void onActionClick(int type) {//根据选择的按钮不同 选择不同的回调方法
                doMoreAction(music, type, listType);
            }
        });
        moreActionDialog.show(this.getSupportFragmentManager(), "moreActionDialog");
    }

    private Music getMusic(int musicID) {
        return MusicInfoHelper.getInstance().getMusicByID(musicID);
    }

    /**
     * 做更多操作
     *
     * @param music    要进行操作的音乐
     * @param type     操作的类型
     * @param listType 列表的类型
     */
    private void doMoreAction(final Music music, int type, int listType) {
        switch (type) {
            case MoreActionDialog.ACTION_TYPE_MUSIC_FAVORITE://收藏
                favoriteSwitchMusic(music);
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_DOWNLOAD://下载
                if (OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_DOWNLOADED)) {
                    deleteDownloadedMusic(music);
                } else {
                    OperateMusicUtils.downloadMusic(music);
                    //setDownLoadListener();//如果一开始没有下载service,initView()中即无法开启监听,此时点击下载即启动service,开始监听
                    showAppMessage(R.string.added_downloading, AppMsg.STYLE_INFO);
                    if (music != null) {
                        UmengAnalysisHelper.getInstance().musicReportPlus(AlbumDetailActivity.this, "音乐下载", music.getId());
                    }
                }
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_SHARE://分享
                tempMusic_share = music;
                ShareUtils.getInstance().shareMusic(this, music);
                break;
            case MoreActionDialog.ACTION_TYPE_MUSIC_DELETE://删除
                if (music != null) {
                    OperateMusicUtils.deleteMusicInAlbumList(getAlbum().getId(), music.getId(), new AsyncOperationListener() {
                        @Override
                        public void onAsyncOperationCompleted(AsyncOperation operation) {
                            //删除成功之后对列表重新赋值
                            startRefreshList();
                        }
                    });
                }
                break;
        }
    }


    /**
     * 刷新
     *
     * @param sResult
     */
    private void refreshList(String sResult) {
        MixPageInfo musicList = JsonHelper.getObject(sResult, MixPageInfo.class);
        if (musicList != null) {
            List<Music> page = musicList.getList();//头部的四条数据
            List<Music> list = null;
            if (musicList.getPage() != null) {
                list = musicList.getPage().getResult();//全部二十条数据
            }
            if (list == null || list.size() <= 0) {
                stopLoadNothing();
                return;
            } else {
                MusicInfoHelper.getInstance().asyncWriteMusicInfoList(list);
                stopLoading();
            }
            if (index != 0) {
                getSongsAdapter().getMusicList().addAll(list);
                getSongsAdapter().notifyDataSetChanged();
            } else {
                if (page != null) {
                    if (page.size() > 0) {
                        getMixAdapter().setList(page);
                        MusicInfoHelper.getInstance().asyncWriteMusicInfoList(page);
                        getSongsAdapter().setRecomentListSize(page.size());
                        if (gridView_container != null)
                            gridView_container.setVisibility(View.VISIBLE);
                    }
                }
                getSongsAdapter().setMusicList(list);
            }
            index = index + 1;
        } else {
            stopLoadError();
        }
    }

    private void refreshListForRecommend(String sResult) {
        RecommendMixList recommendMixList = JsonHelper.getObject(sResult, RecommendMixList.class);
        if (recommendMixList != null) {
            RecommendMixList.RecommendList recommendList = recommendMixList.getData();
            List<Music> list = new ArrayList<>();
            if (recommendList != null) {
                List<Music> musicList = recommendList.getMixList();//全部列表数据
                if (musicList != null && musicList.size() > 0)
                    list = musicList;
            }
            MusicInfoHelper.getInstance().asyncWriteMusicInfoList(list);
            getSongsAdapter().setMusicList(list);
        }
    }

    private void deleteDownloadedMusic(final Music music) {
        if (music == null) return;
        new MaterialDialog.Builder(this)
                .title(R.string.delete)
                .content(R.string.delete_tip)
                .positiveText(R.string.delete)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://删除已下载的音乐
//                                OperateMusicUtils.deleteDownLoadMusic(music, new AsyncOperationListener() {
//                                    @Override
//                                    public void onAsyncOperationCompleted(AsyncOperation operation) {
                                if (OperateMusicUtils.deleteMusicDownloadedFile(music)) {
                                    //TODO 删除完成之后怎么做
                                    getSongsAdapter().notifyDataSetChanged();
                                    getMixAdapter().notifyDataSetChanged();
                                }
//                                    }
//                                });
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 收藏歌曲或者取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchMusic(Music music) {
        if (music == null) return;
        favoriteSwitchInNet(music);
    }

    /**
     * 在服务器收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInNet(Music music) {
        tempMusic = music;
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);

        int requestId = MusicDataManager.getInstance().favoriteMusicChange(UserDataManager.getUid(), music.getId(), false);
        registerDataReqStatusListener(requestId);

        showAppMessage(
                bFavorite ? R.string.activity_main_unfavoriting : R.string.activity_main_favoriting, AppMsg.STYLE_INFO);
        if (!bFavorite) {
            UmengAnalysisHelper.getInstance().musicReportPlus(this, "音乐收藏", music.getId());
        }
    }

    /**
     * 在本地收藏或取消收藏
     *
     * @param music 操作的音乐
     */
    private void favoriteSwitchInLocale(Music music) {
        if (music == null) return;
        OperateMusicUtils.favoriteSwitchInLocale(music);
        boolean bFavorite = OperateMusicUtils.checkMusicExist(music, Config.LIST_TYPE_FAVORITE);
        getSongsAdapter().notifyDataSetChanged();
        getSongsAdapter().setMusicItem(MusicInfoHelper.getInstance().getMusicByID(music.getId()));
        showAppMessage(
                bFavorite ? R.string.activity_main_album_add_favorite_tip : R.string.activity_main_album_remove_favorite_tip, AppMsg.STYLE_INFO);
        tempMusic = null;
    }

//    private void updateSingleRow(ListView listView, long id) {
//        if (listView != null) {
//            int start = listView.getFirstVisiblePosition();
//            for (int i = start, j = listView.getLastVisiblePosition(); i <= j; i++)
//                if (id == ((Messages) listView.getItemAtPosition(i)).getId()) {
//                    View view = listView.getChildAt(i - start);
//                    getSongsAdapter().getView(i, view, listView);
//                    break;
//                }
//        }
//    }

    /**
     * 分享的次数增加
     */
    private void updateShareCount() {
        if (tempMusic_share == null) return;
        MusicInfo musicInfo = MusicInfoHelper.getInstance().getMusicInfoByID(tempMusic_share.getId());
        if (musicInfo != null) {
            musicInfo.setShareCount(musicInfo.getShareCount() + 1);
            MusicInfoHelper.getInstance().asyncWriteMusicInfo(musicInfo);
        }
        tempMusic_share.setShareCount(tempMusic_share.getShareCount() + 1);
        if (getMusicList() == null || getMusicList().size() == 0) return;
        for (int i = 0; i < getMusicList().size(); i++) {
            if (getMusicList().get(i).getId() == tempMusic_share.getId()) {
                getMusicList().get(i).setShareCount(tempMusic_share.getShareCount());
            }
        }
        getSongsAdapter().notifyDataSetChanged();
        tempMusic_share = null;
    }


    //endregion =============================音乐更多操作======================

    //region =============================onActivityResult========================
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CHANGE_ALBUM_INFO:
                if (resultCode == RESULT_OK) {
                    setResult(RESULT_OK);
                    finish();
                    return;
                }
                if (data == null) return;
                String albumString = data.getStringExtra("currentAlbum");
                album = JsonHelper.getObject(albumString, Album.class);
                break;
            case SELECT_SONG_ADD_TO_LIST:
                if (resultCode == SelectSongActivity.SELECT_SONG_ADD_TO_MUSIC_LIST) {//添加到歌单操作
                    String info = getString(R.string.activity_select_songs_choose_playlist_success);
                    showAppMessage(info, AppMsg.STYLE_INFO);
                } else if (resultCode == SelectSongActivity.SELECT_SONG_TO_DOWNLOAD) {//下载操作
                    String info = getString(R.string.added_downloading);
                    showAppMessage(info, AppMsg.STYLE_INFO);//提示操作后的信息（错误或者成功）
                }
                break;
            default:
                if (resultCode == Activity.RESULT_OK) {//三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                                if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                    updateShareCount();
                                    finishShareMixCoinTask();
                                }
                            }
                            break;
                    }
                }
                break;
        }
        // super.onActivityResult(requestCode, resultCode, data);
    }
    //endregion =============================onActivityResult========================

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享歌曲金币任务
     */
    private void finishShareMixCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_MIX, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareMixCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * 完成每日播放歌曲金币任务
     */
    private void finishPlayMixCoinTask() {
        long lastPlayTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_PLAY_MIX, 0);
        if (!FitmixUtil.isToday(lastPlayTime)) {//今日已播放过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishPlayMixCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================

}
