package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.base.MyLifecycleHandler;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.memoryleak.LeakHandler;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusDao;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.model.services.DataHandleService;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.NewVPIndicator;
import com.tencent.android.tpush.XGPushClickedResult;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.xdandroid.hellodaemon.IntentWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;
import de.greenrobot.dao.async.AsyncSession;
import de.greenrobot.dao.query.QueryBuilder;

/**
 * Activity虚拟基类,用于APP所有Activity继承
 */
public abstract class BaseActivity extends AppCompatActivity implements AsyncOperationListener {

    /**
     * 申请单个权限的请求
     */
    private static final int REQUEST_CODE_ASK_PERMISSIONS = 185;
    /**
     * 申请多个权限的请求
     */
    private static final int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 186;

    private SparseIntArray requestIds;//本Activity对数据更新事件感兴趣的数据请求编号列表
    private BroadcastReceiver requestReceiver;//数据请求状态
    private PlayStatusReceiver mPlayStatusReceiver;//歌曲播放状态
    private HardwareReceiver hardwareReceiver;//心率耳机广播
    private BluetoothStatusReceiver bluetoothStatusReceiver;//蓝牙状态广播
//    /**
//     * 当前页面处于请求忙线中的数据请求个数,此数字大于0表示可以显示进度条
//     */
//    protected int requestingCount = 0;
    /**
     * 异步查询数据请求状态(DataReqStatus)表 Session
     */
    private List<AsyncSession> asyncSessionList;
    protected String mPageName;
    protected Toolbar toolbar;
    /**
     * 数据加载,正在忙提示框
     */
    protected MaterialDialog loadingDialog;
    private TextView tv_title;
    private NewVPIndicator toolbarIndicator;
    protected boolean canShowDialog = false;//防止延时弹出加载框,隐藏后再次显示
    protected MaterialDialog permissionDialog;
    /**
     * 音乐播放状态导航菜单是否跳动,默认不跳动
     */
    protected boolean musicPlaying = false;
    /**
     * 是否显示音乐播放状态导航菜单,默认不显示
     */
    protected boolean showGoToPlayMusicMenu = false;
    private MenuItem menuGoToPlayMusic;//音乐播放状态导航菜单 消息导航菜单

    /**
     * AppMsg上一次提示的时间
     */
    private long lastShowTime;
    /**
     * AppMsg上一次提示的消息
     */
    private String lastMsg;

    /**
     * fragment transaction是否可以提交
     */
    protected boolean ftCanCommit;

    //region ================================= Activity生命周期相关 =================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this,R.color.windowDarkBackground));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerRequestReceiver();
        registerPlayStateReceiver();
        registerHardwareReceiver();
        registerBluetoothStatusReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ftCanCommit = true;
        invalidateOptionsMenu();
        //setMusicPlayStatus(PlayerController.getInstance().getIsActionPlay());
        UmengAnalysisHelper.getInstance().onActivityResume(this, mPageName);

        //信鸽需要   解决点击通知消息跳转到指定界面停留几秒的问题
        XGPushClickedResult clickedResult = XGPushManager.onActivityStarted(this);
        if (clickedResult != null) { //判断是否来自信鸽的打开方式,notificationActionType==1为Activity，2为url，3为intent
            Logger.i(Logger.XG_TAG, "SplashActivity-->start from XG,activity name:" + clickedResult.getActivityName()
                    + ",content:" + clickedResult.getContent() + ",NotificationActionType:" + clickedResult.getNotificationActionType());
            //从推送通知栏打开-Service打开Activity会重新执行Launcher流程
            //查看是不是全新打开的面板
            if (isTaskRoot()) {
                return;
            }
            //如果有面板存在则关闭当前的面板
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ftCanCommit = false;
        UmengAnalysisHelper.getInstance().onActivityPause(this, mPageName);
        //信鸽需要   解决点击通知消息跳转到指定界面停留几秒的问题
        XGPushManager.onActivityStoped(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterRequestReceiver();
        unregisterPlayStateReceiver();
        unregisterHeartRateReceiver();
        unregisterBluetoothStatusReceiver();
        hideLoadingDialog();

        sendAppActiveStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (permissionDialog != null) {
            permissionDialog.dismiss();
        }
        permissionDialog = null;
        LeakHandler.fixInputMethodManagerLeak(this);
    }

    //endregion ================================= Activity生命周期相关 =================================

    //region ================================= 子类继承或调用方法相关 =================================


    //是否是华为手机
    public static int getEmuiLeval() {
        // Finals 2016-6-14 如果获取过了就不用再获取了，因为读取配置文件很慢
        Logger.d(Logger.LOG_TAG, "emuiLevel: BRAND:" + android.os.Build.BRAND +
                " model:" + Build.MODEL + " manufacturer" + android.os.Build.MANUFACTURER);
        String brand = android.os.Build.BRAND;
        String manufacturer = Build.MANUFACTURER;

        if (brand.contains("HUAWEI") || manufacturer.contains("HUAWEI")) {
            return 1;
        }
        return 0;
    }

    /**
     * 忽略电池优化
     */
    protected void ignoreBatteryOptimization(Activity activity) {
        //  二十个小时提醒一次
        final long timeInterval = 1000 * 60 * 60 * 200;
        long lastTime = SettingsHelper.getLong("whiteCheckTime", 0);
        Logger.d(Logger.LOG_TAG, "ignoreBatteryOptimization emuiLeve" + getEmuiLeval() + "lastTime:" + lastTime + " " +
                "currentTime:" + System.currentTimeMillis() + " distance" + (lastTime - System.currentTimeMillis()));
        if (getEmuiLeval() > 0 && System.currentTimeMillis() - lastTime > timeInterval) {
            SettingsHelper.putLong("whiteCheckTime", System.currentTimeMillis());
            IntentWrapper.whiteListMatters(this, "手表服务的长连接");
        } else {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                boolean hasIgnored = powerManager.isIgnoringBatteryOptimizations(activity.getPackageName());
                //  判断当前APP是否有加入电池优化的白名单，如果没有，弹出加入电池优化的白名单的设置对话框。
                if (!hasIgnored) {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + activity.getPackageName()));
                    startActivity(intent);
                }
            }
        }
    }

    /**
     * 初始化控件以及注册控件事件
     */
    protected abstract void initViews();

    /**
     * 设置页面标题,用于友盟统计
     */
    protected void setPageName(String name) {
        mPageName = name;
    }

    /**
     * 点击空白位置 隐藏软键盘
     */
    public boolean onTouchEvent(MotionEvent event) {
        hideInputMethod();
        return super.onTouchEvent(event);
    }

    /**
     * 隐藏键盘
     */
    protected void hideInputMethod() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if ((imm != null) && (getCurrentFocus() != null)) {
            imm.hideSoftInputFromWindow(getCurrentFocus()
                    .getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    /**
     * 初始化tool bar
     */
    protected void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tv_title = (TextView) findViewById(R.id.tv_title);
        toolbarIndicator = (NewVPIndicator) findViewById(R.id.indicator);
        setSupportActionBar(toolbar);

        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            if (toolbar.getTitle() != null) {
                setUiTitle(toolbar.getTitle().toString());
            }
            actionBar.setDisplayShowTitleEnabled(false);//取消默认的title
        }
    }

    /**
     * 设置界面标题,自定义标题居中
     */
    protected void setUiTitle(String title) {
        if (title != null && tv_title != null) {
            if (toolbarIndicator != null) {
                toolbarIndicator.setVisibility(View.GONE);
            }
            tv_title.setVisibility(View.VISIBLE);
            tv_title.setText(title);
        }
    }

    /**
     * 设置界面标题,viewpager
     */
    protected void setUiIndicator(ViewPager viewpager, String[] titles) {
        if (toolbarIndicator != null && viewpager != null) {
            tv_title.setVisibility(View.GONE);
            toolbarIndicator.setVisibility(View.VISIBLE);
            toolbarIndicator.setTitles(titles);
            toolbarIndicator.setViewPager(viewpager);
        }
    }


    protected MyConfig getMyConfig() {
        return MyConfig.getInstance();
    }

    //endregion ================================= 子类继承或调用方法相关 =================================

    //region ================================= AppMsg、菜单设置及对话框提示 =================================

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (showGoToPlayMusicMenu) {
            List<Music> musicList = OperateMusicUtils.getMusicPlayingList();
            int index = OperateMusicUtils.getIndexInPlayingList();//如果没有最近的播放列表则不显示
            if (musicList != null && musicList.size() > 0 && index > -1) {
                menuGoToPlayMusic = menu.add(0, Menu.FIRST + 5, 5, R.string.menu_music_playing).setIcon(R.drawable.equalizer1);
                menuGoToPlayMusic.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);//总是显示
                menuGoToPlayMusic.setActionView(R.layout.menu_music_playing);
                ImageView equalizer = (ImageView) menuGoToPlayMusic.getActionView().findViewById(R.id.equalizer);
                equalizer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onOptionsItemSelected(menuGoToPlayMusic);
                    }
                });
                setMusicPlayStatus(PlayerController.getInstance().getIsActionPlay());
            }
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://返回
                finish();
                break;

            case Menu.FIRST + 5://导航到音乐播放界面
                startPlayMusicActivity();
                break;

//            case Menu.FIRST +4://导航到第二个菜单项
//                clickSecondMenu();
//                break;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * 根据错误编号,显示错误提示
     *
     * @param error 错误编号,参考 {@link com.fitmix.sdk.Config#ERROR_AGE_ERROR} 等
     */
    public void showErrorMsg(int error) {
        if (error == Config.ERROR_NO_ERROR)
            return;
        int msg = getErrorString(error);

        String sInfo;

        if (msg != Config.ERROR_NO_ERROR)
            sInfo = getString(msg);
        else {
            sInfo = "Error:" + error;
        }
        showAppMessage(sInfo, AppMsg.STYLE_ALERT);
    }

    /**
     * 根据错误码,返回错误提示信息字符串
     *
     * @param error 错误码
     * @return 错误提示信息字符串
     */
    private int getErrorString(int error) {
        int msg = Config.ERROR_NO_ERROR;
        switch (error) {
            case Config.ERROR_USERNAME_TOO_SHORT://输入的用户名字符太少
                msg = R.string.rsp_error_username_length_error;
                break;
            case Config.ERROR_PASSWORD_TOO_SHORT://输入的密码长度太小
                msg = R.string.rsp_error_password_length_error;
                break;
            case Config.ERROR_FORMAT_ERROR://输入的用户名格式错误
                msg = R.string.rsp_error_email_error;
                break;

            case Config.ERROR_AGE_ERROR://输入的年龄错误
                msg = R.string.rsp_error_age_error;
                break;
            case Config.ERROR_NO_NETWORK://网络不好
                msg = R.string.check_network;
                break;
            case Config.ERROR_PERSON_DATA://输入的个人信息(年龄、身高、体重)为0错误
                msg = R.string.person_info_data_error;
                break;
            case Config.ERROR_UNKNOWN://未知错误
                msg = R.string.rsp_error_unknown_error;
                break;
            case Config.URL_RET_CODE_USER_EXIST://邮箱已存在错误
                msg = R.string.rsp_error_user_exist;
                break;
            case Config.URL_RET_CODE_USER_NAME_EMPTY://用户名为空错误
                msg = R.string.rsp_error_username_empty;
                break;
            case Config.URL_RET_CODE_EMAIL_EMPTY://邮箱格式错误
                msg = R.string.rsp_error_email_empty;
                break;
            case Config.URL_RET_CODE_EMAIL_EXIST://邮箱已存在错误
                msg = R.string.rsp_error_email_exist;
                break;
            case Config.URL_RET_AGE_ERROR://年龄错误
                msg = R.string.rsp_error_age_error;
                break;
            case Config.URL_RET_SEX_ERROR://性别错误
                msg = R.string.rsp_error_sex_error;
                break;
            case Config.URL_RET_USER_TYPE_ERROR://用户类型错误
                msg = R.string.rsp_error_user_type_error;
                break;
            case Config.URL_RET_PASSWORD_ERROR://密码错误
                msg = R.string.rsp_error_password_error;
                break;
            case Config.URL_RET_CODE_USER_NOT_EXIST://用户名不存在错误
            case Config.URL_RET_CODE_USER_NOT_EXIST2://用户名不存在错误
                msg = R.string.rsp_error_user_not_exist;
                break;
            case Config.ERROR_DATA_TOO_LONG://输入的数据过长
                //msg = "data too long";
                break;
            case Config.ERROR_PHONE_DATA://输入的手机号码错误
                msg = R.string.activity_register_error_phone;
                break;
            case Config.ERROR_PASSWORD_NOT_MATCH://输入的密码不一致错误
                msg = R.string.activity_forgot_password_reset_new_password_wrong;
                break;
            case Config.ERROR_GET_AUTH_CODE://获取验证码错误
                msg = R.string.activity_register_please_get_auth_code;
                break;
            case Config.ERROR_EDIT_AUTH_CODE://输入验证码错误
                msg = R.string.activity_register_please_edit_auth_code;
                break;
            case Config.ERROR_AUTH_CODE_WRONG://验证码错误
                msg = R.string.activity_register_auth_code_wrong;
                break;
            case Config.ERROR_PHONE_NUMBER_NOT_MATCH://输入的手机号码不匹配错误
                msg = R.string.activity_register_phone_number_not_match;
                break;
            case Config.ERROR_EMAIL_NOT_MATCH://输入的邮箱不匹配错误
                msg = R.string.activity_register_email_not_match;
                break;
            case Config.ERROR_NOTICE_NAME_INVALID://俱乐部公告名称不合格错误
                msg = R.string.activity_club_detail_notice_name_invalid;
                break;
            case Config.ERROR_NOTICE_ADDRESS_INVALID://俱乐部公告地址不合格错误
                msg = R.string.activity_club_detail_notice_address_invalid;
                break;
            case Config.ERROR_TIME_INVALID://俱乐部公告结束时间小于开始时间错误
                msg = R.string.activity_club_detail_notice_time_invalid;
                break;
            case Config.ERROR_COVER_NOT_EXIST://俱乐部公告封面不存在
                msg = R.string.activity_club_detail_notice_cover_not_exist;
                break;
            case Config.ERROR_CLUB_NAME_ERROR://俱乐部名称错误
                msg = R.string.fm_create_club_club_name_hint;
                break;
            case Config.ERROR_CLUB_DESC_ERROR://俱乐部描述错误
                msg = R.string.fm_create_club_club_desc;
                break;
            case Config.ERROR_NO_LOCATION_INFO://没有定位信息错误
                msg = R.string.activity_runmain_no_location_income;
                break;
            case Config.ERROR_NICKNAME_EMPTY://用户昵称不能为空
                msg = R.string.activity_edit_profile_nickname_empty;
                break;
            case Config.ERROR_SIGNATURE_EMPTY://个性签名不能为空
                msg = R.string.activity_edit_profile_signature_empty;
                break;
        }
        return msg;
    }

    /**
     * 在窗口顶部弹出信息
     *
     * @param msg   消息
     * @param style AppMsg.STYLE_ALERT   AppMsg.STYLE_CONFIRM   AppMsg.STYLE_INFO三选一
     */
    public void showAppMessage(String msg, AppMsg.Style style) {
        if (TextUtils.isEmpty(msg))
            msg = getResources().getString(R.string.rsp_error_unknown_error);
        showAppMessage(msg, style, Gravity.TOP);
    }

    /**
     * 在窗口顶部弹出信息
     *
     * @param strResId 消息内容字符串资源id
     * @param style    AppMsg.STYLE_ALERT   AppMsg.STYLE_CONFIRM   AppMsg.STYLE_INFO三选一
     */
    protected void showAppMessage(int strResId, AppMsg.Style style) {
        showAppMessage(getResources().getString(strResId), style, Gravity.TOP);
    }

    /**
     * 在窗口顶部弹出信息
     *
     * @param msg     消息
     * @param style   AppMsg.STYLE_ALERT/AppMsg.STYLE_CONFIRM/AppMsg.STYLE_INFO三选一
     * @param gravity 消息显示位置,如Gravity.BOTTOM,默认显示在顶部
     */
    protected void showAppMessage(String msg, AppMsg.Style style, int gravity) {
        if (TextUtils.isEmpty(msg))
            return;
        long now = System.currentTimeMillis();

        if (((now - lastShowTime) < 2000) && msg.equals(lastMsg)) {//防止短时间内同一消息内容提示多次
            lastShowTime = now;
            lastMsg = msg;
            return;
        }
        AppMsg appMsg = AppMsg.makeText(this, msg, style);
        appMsg.setAnimation(R.anim.app_msg_in, R.anim.app_msg_out);
        //(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        //appMsg.setParent(mAltParent);//用于显示在指定父布局内
        appMsg.setLayoutGravity(gravity);
        appMsg.show();
        lastShowTime = now;
        lastMsg = msg;
    }

    /**
     * 显示加载对话框
     *
     * @param resId         对话框显示的内容消息资源ID
     * @param delayShowTime 延迟显示对话框的时间,单位为毫秒,取0时表示立即显示,其它值必须大于等于1000
     */
    protected void showLoadingDialog(int resId, long delayShowTime) {
        loadingDialog = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .content(resId)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                    }
                }).build();
        canShowDialog = true;
        if (delayShowTime == 0) {
            if (loadingDialog != null) {
                loadingDialog.show();
            }
        } else if (delayShowTime >= 1000) {
            ThreadManager.getMainHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (loadingDialog != null && canShowDialog) {
                        loadingDialog.show();
                    }
                }
            }, delayShowTime);
        }
    }

    /**
     * 立即显示加载对话框
     *
     * @param resId 对话框显示的内容消息资源ID
     */
    protected void showLoadingDialog(int resId) {
        showLoadingDialog(resId, 0);
    }

    /**
     * 隐藏加载对话框
     */
    protected void hideLoadingDialog() {
        if (loadingDialog != null) {
            loadingDialog.dismiss();
            canShowDialog = false;
        }
        loadingDialog = null;
    }

    //endregion ================================= AppMsg、菜单设置及对话框提示 =================================

    //region ================================= 数据请求相关 =================================

    /**
     * 注册数据请求结果广播
     */
    private void registerRequestReceiver() {
        IntentFilter filter = new IntentFilter(DataHandleService.ACTION_REQUEST_RESULT);
        requestReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int requestId = intent.getIntExtra(DataHandleService.EXTRA_REQUEST_ID, -1);
//                Logger.i(Logger.DEBUG_TAG, "Received intent " + intent.getAction() + ", request ID "
//                        + requestId);
                if (requestIds != null && requestIds.get(requestId) == requestId) {
//                    requestingCountChang(--requestingCount);//递减当前页面处于请求忙线中的数据请求个数,并通知
//                    if (requestingCount < 0) {
//                        requestingCount = 0;
//                    }
                    int resultCode = intent.getIntExtra(DataHandleService.EXTRA_BROADCAST_RESULT_CODE, 0);
//                    Logger.i(Logger.DEBUG_TAG, "Result code = " + resultCode);
                    if (resultCode == DataHandleService.RESULT_BROADCAST_CODE_SUCCESS) {
                        dataUpdateNotify(requestId);
                    } else if (resultCode == DataHandleService.RESULT_BROADCAST_CODE_FAIL) {
                        String error = intent.getStringExtra(DataHandleService.EXTRA_BROADCAST_RESULT_STR);
                        if (!TextUtils.isEmpty(error)) {//处理数据请求失败
                            processReqError(requestId, error);
                        }
                    }
                }
            }
        };
        try {
            this.registerReceiver(requestReceiver, filter);
            Logger.d(Logger.DEBUG_TAG, "registerRequestReceiver");
        } catch (Exception e) {
            Logger.e(Logger.DEBUG_TAG, "registerRequestReceiver-->error");
        }
    }

    /**
     * 注销数据请求结果广播
     */
    private void unregisterRequestReceiver() {
        if (requestReceiver != null) {
            try {
                this.unregisterReceiver(requestReceiver);
            } catch (IllegalArgumentException e) {
                Logger.e(Logger.DEBUG_TAG, e.getLocalizedMessage(), e);
            }
            Logger.d(Logger.DEBUG_TAG, "unregisterReceiver-->requestReceiver");
        }
        if (asyncSessionList != null) {
            for (AsyncSession asyncSession : asyncSessionList) {
                if (asyncSession != null) {
                    asyncSession.setListenerMainThread(null);
                }
            }
            asyncSessionList.clear();
        }
        asyncSessionList = null;
    }

    /**
     * 注册当前登录用户指定数据请求编号的结果更新监听
     *
     * @param requestId 要监听的数据请求编号
     */
    protected void registerDataReqStatusListener(int requestId) {
        // 1.将要监听的数据请求编号添加到当前页面的监听列表
        if (requestIds == null) {
            requestIds = new SparseIntArray();
        }
        if (requestIds.get(requestId, -1) == -1) {//添加数据请求编号
            requestIds.put(requestId, requestId);
//            requestingCountChang(++requestingCount);//递增当前页面处于请求忙线中的数据请求个数,并通知
//        } else {
//            requestingCountChang(++requestingCount);//仅通知
        }
    }

    /**
     * 取消指定的数据请求
     *
     * @param requestId 要取消的数据编号
     */
    protected void cancelRequest(int requestId) {
        //将指定的数据请求编号从数据请求编号列表移除并在相应的DataManager中取消请求忙碌状态
        if (requestIds != null && requestIds.get(requestId, -1) == requestId) {
            requestIds.delete(requestId);
//            requestingCountChang(--requestingCount);
//            int module = requestId / 10000 * 10000;
//            Logger.i(Logger.DEBUG_TAG, "cancelRequest module:" + module);
//            switch (module) {
//                case Config.MODULE_USER:
//                    UserDataManager.getInstance().cancelRequest(requestId);
//                    break;
//                case Config.MODULE_CLUB:
//                    ClubDataManager.getInstance().cancelRequest(requestId);
//                    break;
//                case Config.MODULE_MUSIC:
//                    MusicDataManager.getInstance().cancelRequest(requestId);
//                    break;
//                case Config.MODULE_SPORT:
//                    SportDataManager.getInstance().cancelRequest(requestId);
//                    break;
//                case Config.MODULE_COMPETITION:
//                    DiscoverDataManager.getInstance().cancelRequest(requestId);
//                    break;
//            }
        }
    }

    /**
     * 根据数据请求编号,异步获取数据请求结果
     *
     * @param requestId 数据请求编号
     * @return 数据请求结果字符串
     */
    protected void getDataReqStatusAsync(int requestId) {
        final DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(this).getDataReqStatusDao();
        QueryBuilder<DataReqStatus> qb = dataReqStatusDao.queryBuilder();
        qb.where(DataReqStatusDao.Properties.RequestId.eq(requestId)).limit(1);
        if (asyncSessionList == null) {
            asyncSessionList = new ArrayList<>();
        }
        AsyncSession asyncSession = MixApp.getDaoSession(this).startAsyncSession();
        asyncSession.setListenerMainThread(this);
        asyncSession.queryUnique(qb.build());
        asyncSessionList.add(asyncSession);
    }

    @Override
    public void onAsyncOperationCompleted(AsyncOperation operation) {
//        Logger.i(Logger.DEBUG_TAG, "BaseActivity-->getDataReqStatusAsync onAsyncOperationCompleted current Thread:" + Thread.currentThread().getId());
        try {
            DataReqStatus dataReqStatus = (DataReqStatus) operation.getResult();
            if (dataReqStatus != null) {
                getDataReqStatusNotify(dataReqStatus);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //    /**
//     * 当前页面处于请求忙线中的数据请求个数变化事件
//     *
//     * @param requestingCount 当前页面此时处于请求忙线中的数据请求个数
//     */
//    protected abstract void requestingCountChang(int requestingCount);

    /**
     * 底层数据更新通知
     *
     * @param requestId 数据请求编号
     */
    protected abstract void dataUpdateNotify(int requestId);

    /**
     * 异步从数据状态表获取数据请求结果回调
     *
     * @param dataReqResult 数据状态
     */
    protected abstract void getDataReqStatusNotify(DataReqStatus dataReqResult);

    /**
     * 错误码小于1000的错误码是APP定义的,因此即可转换定义并提示用户即可
     *
     * @param errorCode 错误码
     */
    protected void processReqError(int errorCode) {
        switch (errorCode) {
            case ApiUtils.HTTP_NETWORK_FAIL:
                showAppMessage(R.string.check_network_out_time, AppMsg.STYLE_ALERT);//提示网络异常
                break;
            case 400://Bad Request
            case 401://Unauthorized
            case 402://Payment Required
            case 403://Forbidden
            case 404://Not Found
            case 405://Method Not Allowed
            case 406://Not Acceptable
                String invalidError = String.format("%s:%s", errorCode, getString(R.string.rsp_error_invalid_request));
                showAppMessage(invalidError, AppMsg.STYLE_ALERT);//提示请求非法
                break;

            case -1://服务器异常
            case 500://Internal Server Error
            case 501:// Not Implemented
            case 502:// Bad Gateway
            case 503:// Service Unavailable
            case 504:// Gateway Timeout
            case 505:// HTTP Version Not Supported
            case ApiUtils.HTTP_REQUEST_EXCEPTION:
            case ApiUtils.ADD_OR_UPDATE_REQ_STATUS_FAIL:
                String unknownError = String.format("%s:%s", errorCode, getString(R.string.rsp_error_unknown_error));
                showAppMessage(unknownError, AppMsg.STYLE_ALERT);//提示未知错误
                break;
        }
    }

    /**
     * 处理由服务器定义的错误码大于等于1000错误,需要根据不同接口进行转义
     * <p>比如:登录接口返回2000表示用户名不存在</p>
     *
     * @param requestId 数据请求编号
     * @param error     数据请求失败的结果
     */
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            if (errorCode < 1000) {
                processReqError(errorCode);
            }
        }
    }

    /**
     * 设（DataReqStatus）表中,用户信息列过期
     */
    protected void setUserDataUseLess() {
        //上传成功了,更改数据库个人信息的有效期为过期
        int userInfoRequestId = getUserInfoRequestIdByLoginType();
        if (userInfoRequestId == -1) return;
        DataReqStatusHelper.getInstance().setDataReqStatusCacheUseless(userInfoRequestId);
    }

    /**
     * 根据登录类型,获取登录接口的数据请求id
     *
     * @return 100002:邮箱登录,100003:QQ授权登录,100004:新浪微博授权登录,100005:微信授权登录
     */
    public static int getUserInfoRequestIdByLoginType() {
        int loginType = PrefsHelper.with(MixApp.getContext(), Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        int userInfoRequestId = -1;
        if (loginType == 1 || loginType == 5) {//邮箱
            userInfoRequestId = UserDataManager.getInstance().generateRequestId(2);
        } else if (loginType == 2) {//QQ
            userInfoRequestId = UserDataManager.getInstance().generateRequestId(3);
        } else if (loginType == 3) {//微信
            userInfoRequestId = UserDataManager.getInstance().generateRequestId(5);
        } else if (loginType == 4) {//新浪微博
            userInfoRequestId = UserDataManager.getInstance().generateRequestId(4);
        }
        return userInfoRequestId;
    }

    //endregion ================================= 数据请求相关 =================================

    //region  ================================= 音乐播放事件相关 =================================

    /**
     * 注册歌曲播放广播
     */
    protected void registerPlayStateReceiver() {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Config.MUSIC_PLAY_START);
        filter.addAction(Config.MUSIC_PLAY_STATE_CHANGED);
        filter.addAction(Config.MUSIC_PLAY_STOP);
        filter.addAction(Config.MUSIC_CHANGED_PREV);
        filter.addAction(Config.MUSIC_CHANGED_NEXT);
        filter.addAction(Config.MUSIC_PLAY_DEFAULT);
        filter.addAction(Config.COIN_TASK_RUN_RECORD_BROADCAST);//用户跑步记录上传后,有关金币任务的广播,暂时用到音乐这里
        filter.addAction(Config.MUSIC_PREPARED);
        filter.addAction(Config.MUSIC_BUFFERINGUPDATE);
        mPlayStatusReceiver = new PlayStatusReceiver();
        lbm.registerReceiver(mPlayStatusReceiver, filter);
    }

    /**
     * 注销歌曲播放广播
     */
    protected void unregisterPlayStateReceiver() {
        if (mPlayStatusReceiver != null) {
            try {
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
                lbm.unregisterReceiver(mPlayStatusReceiver);
            } catch (IllegalArgumentException e) {
                Logger.e(Logger.DEBUG_TAG, e.getLocalizedMessage(), e);
            }
        }
        mPlayStatusReceiver = null;
    }

    /**
     * 歌曲播放状态接收
     */
    private class PlayStatusReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String action = intent.getAction();
                if (action == null) return;
                switch (action) {
                    case Config.MUSIC_PLAY_START: //开始播放歌曲(包括歌曲切换); 用于歌曲列表播放状态更新
                        onMusicChanged();
                        break;
                    case Config.MUSIC_PLAY_STATE_CHANGED: //歌曲播放状态改变; 播放状态按钮更新 以及equalizer 是否播放
                        onMusicPlayStateChanged();
                        break;
                    case Config.MUSIC_PREPARED: //歌曲在不自动播放的情况下，当资源加载完成，需要通知界面进行更新
                        onMusicPrepared();
                        break;
                    case Config.MUSIC_BUFFERINGUPDATE:
                        onMusicBufferingUpdate();
                        break;
                    case Config.COIN_TASK_RUN_RECORD_BROADCAST: //用户跑步记录上传后,有关金币任务的广播
                        int flag = intent.getIntExtra("flag", 0);//广播类型,1:用户等级升级金币,2:每日三公里

                        int coin = intent.getIntExtra("coin", 0);
                        String taskName = intent.getStringExtra("taskName");
                        Logger.i(Logger.DEBUG_TAG, "BaseActivity-->onReceive activity name:" + mPageName + ",flag:" + flag + ",taskName:" + taskName + ",coin:" + coin);
                        switch (flag) {
                            case 1://用户升级金币
                                if (coin > 0) {
                                    int prevLevel = intent.getIntExtra("prevLevel", 0);
                                    int level = intent.getIntExtra("level", 0);
                                    showLevelUpgradeDialog(coin, taskName, prevLevel, level);
                                }
                                break;

                            case 2://完成每日三公里任务金币
                                if (coin > 0) {
                                    showQuestRewardsDialog(coin, taskName);
                                }
                                break;
                        }

                        break;
                }
            }
        }
    }

    /**
     * 切换音乐
     */
    protected void onMusicChanged() {
//        Logger.i(Logger.DEBUG_TAG, "BaseActivity --->  onMusicChanged()");
    }

    /**
     * 音乐播放状态改变
     */
    protected void onMusicPlayStateChanged() {
        setMusicPlayStatus(PlayerController.getInstance().getIsActionPlay());
//        Logger.i(Logger.DEBUG_TAG, "BaseActivity ---> onMusicPlayStateChanged()");
    }

    /**
     * 音乐加载完成（仅在加载完成但是不自动播放时调用）
     */
    protected void onMusicPrepared() {
    }

    /**
     * 音乐缓冲加载进度通知
     */
    protected void onMusicBufferingUpdate() {
    }

    /**
     * 设置音乐播放状态指示器
     *
     * @param playing true:正在播放,false:暂停
     */
    protected void setMusicPlayStatus(boolean playing) {
        musicPlaying = playing;
        if (menuGoToPlayMusic != null) {
            ImageView equalizer = (ImageView) menuGoToPlayMusic.getActionView().findViewById(R.id.equalizer);
            if (equalizer != null) {
                AnimationDrawable drawable = (AnimationDrawable) equalizer.getDrawable();
                if (drawable != null && playing) {
                    drawable.start();
                } else if (drawable != null) {
                    drawable.stop();
                }
            }
        }
    }

    /**
     * 导航到播放音乐界面
     */
    private void startPlayMusicActivity() {
        Intent intent = new Intent();
        intent.setClass(this, PlayMusicActivity.class);
        startActivity(intent);
    }

    //endregion  ================================= 音乐播放事件相关 =================================

    //region ================================= 蓝牙事件相关 =================================

    /**
     * 蓝牙状态广播
     */
    private class BluetoothStatusReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int state = intent.getIntExtra(BluetoothAdapter.EXTRA_CONNECTION_STATE, 0);
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (device != null) {
                executeBluetoothStateChange(state, device);
            }
        }
    }

    /**
     * 蓝牙设备连接状态改变
     *
     * @param state
     * @param device
     */
    private void executeBluetoothStateChange(int state, BluetoothDevice device) {
        if (state == BluetoothAdapter.STATE_CONNECTED) {
            String lastAddress = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_HEART_RATE_HEAD_SET_MAC_ADDRESS);
            if (!TextUtils.isEmpty(lastAddress) && !TextUtils.isEmpty(device.getAddress()) && device.getAddress().equals(lastAddress)) {
                Logger.i(Logger.DEBUG_TAG, "自动连接上一次BLE设备");
                Intent intent = new Intent(this, HeartRateService.class);
                Bundle bundle = new Bundle();
                bundle.putParcelable("bleAddress", device);
                intent.putExtras(bundle);
                startService(intent);
            }
        }
    }

    /**
     * 注册蓝牙状态广播
     */
    protected void registerBluetoothStatusReceiver() {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        bluetoothStatusReceiver = new BluetoothStatusReceiver();
        lbm.registerReceiver(bluetoothStatusReceiver, filter);
    }

    /**
     * 注销蓝牙状态广播
     */
    protected void unregisterBluetoothStatusReceiver() {
        if (bluetoothStatusReceiver != null) {
            try {
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
                lbm.unregisterReceiver(bluetoothStatusReceiver);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            bluetoothStatusReceiver = null;
        }
    }

    protected void openBluetooth() {

    }

    //endregion ================================= 蓝牙事件相关 =================================

    //region ============================== Android M 权限 ==============================

    /**
     * 检查是否获得了指定权限
     *
     * @param permissionName 权限名称,如 Manifest.permission.ACCESS_FINE_LOCATION
     * @return true:已获取了权限,false:未获取权限
     */
    protected boolean permissionIsGranted(String permissionName) {
        if (TextUtils.isEmpty(permissionName))
            return false;
        return ContextCompat.checkSelfPermission(this, permissionName) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * 检查并处理权限申请
     *
     * @param permissionName permissionName 权限名称,如 Manifest.permission.ACCESS_FINE_LOCATION等
     */
    protected void getPermission(final String permissionName) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        boolean hasPermission = permissionIsGranted(permissionName);
        if (!hasPermission) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissionName)) {
                String message = String.format(getString(R.string.request_permission_format), getPermissionConciseName(permissionName));
                permissionDialog = new MaterialDialog.Builder(this)
                        .iconRes(R.drawable.notification_icon)
                        .title(R.string.prompt)
                        .content(message)
                        .positiveText(R.string.ok)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                ActivityCompat.requestPermissions(BaseActivity.this, new String[]{permissionName},
                                        REQUEST_CODE_ASK_PERMISSIONS);
                                dialog.dismiss();
                            }
                        }).build();
                if (permissionDialog != null) {
                    permissionDialog.show();
                }
            } else {
                ActivityCompat.requestPermissions(BaseActivity.this, new String[]{permissionName},
                        REQUEST_CODE_ASK_PERMISSIONS);
            }
        }
    }

    /**
     * 检查并处理单个或多个权限申请
     *
     * @param permissionNames 权限名称组成的字符串数组,如Manifest.permission.ACCESS_FINE_LOCATION等
     */
    protected void getPermissions(String[] permissionNames) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        List<String> permissionsNeeded = new ArrayList<>();
        final List<String> permissionsList = new ArrayList<>();

        if (permissionNames == null)
            return;

        for (String permissionName : permissionNames) {
            if (!addPermission(permissionsList, permissionName)) {
                permissionsNeeded.add(getPermissionConciseName(permissionName));
            }
        }

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                // Need Rationale
                StringBuilder sb = new StringBuilder(permissionsNeeded.get(0));
                for (int i = 1; i < permissionsNeeded.size(); i++) {
                    sb.append("\n\t");
                    sb.append(permissionsNeeded.get(i));
                }

                String msg = String.format(getString(R.string.request_permission_format), sb.toString());
                permissionDialog = new MaterialDialog.Builder(this)
                        .iconRes(R.drawable.notification_icon)
                        .title(R.string.prompt)
                        .content(msg)
                        .positiveText(R.string.ok)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                ActivityCompat.requestPermissions(BaseActivity.this,
                                        permissionsList.toArray(new String[permissionsList.size()]),
                                        REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                                dialog.dismiss();
                            }
                        }).build();
                if (permissionDialog != null) {
                    permissionDialog.show();
                }
                return;
            }
            ActivityCompat.requestPermissions(this,
                    permissionsList.toArray(new String[permissionsList.size()]),
                    REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
        }
    }

    /**
     * 判断指定权限是否已经被获取
     *
     * @param permissionsList 需要请求权限的权限集合
     * @param permission      指定的权限名称
     * @return true:已获取权限,false:未获取权限
     */
    private boolean addPermission(List<String> permissionsList, String permission) {
        if (!permissionIsGranted(permission)) {
            permissionsList.add(permission);
            // Check for Rationale Option
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission))
                return false;
        }
        return true;
    }

    /**
     * 根据android manifest权限名转换成相应的权限提示信息
     *
     * @param permission manifest权限名,如Manifest.permission.READ_EXTERNAL_STORAGE 等
     */
    private String getPermissionConciseName(String permission) {
        if (TextUtils.isEmpty(permission))
            return "";
        switch (permission) {
            case Manifest.permission.READ_EXTERNAL_STORAGE://读写外部存储器权限
            case Manifest.permission.WRITE_EXTERNAL_STORAGE:
                return getString(R.string.external_storage_permission_concise);
            case Manifest.permission.ACCESS_COARSE_LOCATION://定位权限
            case Manifest.permission.ACCESS_FINE_LOCATION:
                return getString(R.string.location_permission_concise);
            case Manifest.permission.BODY_SENSORS://传感器
                return getString(R.string.sensor_permission_concise);
            case Manifest.permission.RECORD_AUDIO://麦克风
                return getString(R.string.microphone_permission_concise);
            case Manifest.permission.READ_PHONE_STATE://电话状态,高德地图用到
                return getString(R.string.phone_permission_concise);
            case Manifest.permission.CAMERA://相机
                return getString(R.string.camera_permission_concise);
            case Manifest.permission.RECEIVE_SMS:
                return getString(R.string.sms_permission_concise);
            case Manifest.permission.READ_SMS:
                return getString(R.string.read_sms_permission_concise);
        }
        return "";
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        for (int i = 0; i < permissions.length && i < grantResults.length; i++) {
//            Logger.i(Logger.DEBUG_TAG, "onRequestPermissionsResult-->permission:" + permissions[i] + " status:" + grantResults[i]);
//        }
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS://单个权限请求
                if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {//权限被允许
                    if (permissions != null && permissions.length > 0) {
                        handlePermissionAllowed(permissions[0]);
                    }
                } else {//权限被禁止
                    if (permissions != null && permissions.length > 0 && permissions[0] != null) {
                        String message = String.format(Locale.getDefault(), getString(R.string.permission_forbid_message_format),
                                getPermissionConciseName(permissions[0]));
                        showAppMessage(message, AppMsg.STYLE_ALERT);
                        handlePermissionForbidden(permissions[0]);
                    }
                }
                break;
            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS://多个权限请求
                String msg = "";
                if (permissions != null && grantResults != null) {
                    for (int i = 0; i < permissions.length && i < grantResults.length; i++) {
                        if (permissions[i] != null) {
                            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {//权限被允许
                                handlePermissionAllowed(permissions[i]);
                            } else {//权限被禁止
                                msg += "\n\t\t" + getPermissionConciseName(permissions[i]);
                                handlePermissionForbidden(permissions[i]);
                            }
                        }
                    }
                    if (msg.length() > 0) {
                        String message = String.format(Locale.getDefault(), getString(R.string.permission_forbid_message_format), msg);
                        if (message != null)
                            permissionDialog = new MaterialDialog.Builder(this)
                                    .iconRes(R.drawable.notification_icon)
                                    .title(R.string.prompt)
                                    .content(message)
                                    .positiveText(R.string.ok)
                                    .negativeText(R.string.cancel)
                                    .onAny(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            dialog.dismiss();
                                            switch (which) {
                                                case POSITIVE:
                                                    openAppDetail();
                                                    break;
                                            }
                                        }
                                    }).build();
                        if (permissionDialog != null) {
                            permissionDialog.show();
                        }
                    }
                }
                break;
//            default:
//                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    /**
     * 应用权限被禁止后续处理
     *
     * @param permissionName manifest权限名,如Manifest.permission.READ_EXTERNAL_STORAGE 等
     */
    protected void handlePermissionForbidden(String permissionName) {
    }

    /**
     * 应用权限被允许后续处理
     *
     * @param permissionName manifest权限名,如Manifest.permission.READ_EXTERNAL_STORAGE 等
     */
    protected void handlePermissionAllowed(String permissionName) {
    }

    /**
     * 打开系统设置中的乐享动详情界面
     */
    protected void openAppDetail() {
        Intent intent = new Intent();
        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    //endregion ============================== Android M 权限 ==============================

    //region ============================== 金币任务相关 ==============================

    /**
     * 弹出奖励金币对话框
     *
     * @param rewardCoin           任务奖励金币数量
     * @param taskName             金币任务名称
     * @param rewardsDialogDismiss 对话框消失事件回调
     */
    protected void showQuestRewardsDialog(int rewardCoin, String taskName, QuestRewardsDialog.OnQuestRewardsDialogDismiss rewardsDialogDismiss) {
        QuestRewardsDialog dialog = new QuestRewardsDialog();
        dialog.setRewardCoin(rewardCoin)
                .setTaskName(taskName);
        if (rewardsDialogDismiss != null) {
            dialog.setOnQuestRewardsDialogDismiss(rewardsDialogDismiss);
        }
        if (ftCanCommit) {
            dialog.show(getSupportFragmentManager(), QuestRewardsDialog.TAG);
        }
    }

    /**
     * 弹出奖励金币对话框
     *
     * @param rewardCoin 任务奖励金币数量
     * @param taskName   金币任务名称
     */
    protected void showQuestRewardsDialog(int rewardCoin, String taskName) {
        Intent intent = new Intent(this, DialogContainerActivity.class);
        intent.putExtra("dialogType", 2);//1.用户等级升级,2:金币奖励
        intent.putExtra("rewardCoin", rewardCoin);
        intent.putExtra("taskName", taskName);

        startActivity(intent);

    }

    /**
     * 弹出用户跑步等级升级动画以及金币奖励对话框
     *
     * @param rewardCoin 升级奖励金币数量
     * @param taskName   升级任务名称
     * @param prevLevel  用户升级前的等级,[0,15]
     * @param level      用户升级后的等级,[1,16]
     */
    protected void showLevelUpgradeDialog(int rewardCoin, String taskName, int prevLevel, int level) {
        if (prevLevel >= 0 && prevLevel < level && level < 17) {

            Intent intent = new Intent(this, DialogContainerActivity.class);
            intent.putExtra("dialogType", 1);//1.用户等级升级,2:金币奖励
            intent.putExtra("rewardCoin", rewardCoin);
            intent.putExtra("taskName", taskName);
            intent.putExtra("prevLevel", prevLevel);
            intent.putExtra("level", level);

            startActivity(intent);
        }
    }

    //endregion ============================== 金币任务相关 ==============================

    //region ============================== 智能设备相关 ==============================

    /**
     * 注册智能穿戴设备相关广播
     */
    protected void registerHardwareReceiver() {
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Config.HEART_RATE_CLICK_TO_RUN);//心率耳机
        hardwareReceiver = new HardwareReceiver();
        lbm.registerReceiver(hardwareReceiver, filter);
    }

    /**
     * 注销心率耳机广播
     */
    protected void unregisterHeartRateReceiver() {
        if (hardwareReceiver != null) {
            try {
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
                lbm.unregisterReceiver(hardwareReceiver);
            } catch (IllegalArgumentException e) {
                Logger.e(Logger.DEBUG_TAG, e.getLocalizedMessage());
            }
        }
        hardwareReceiver = null;
    }

    /**
     * 智能穿戴设备广播
     */
    private class HardwareReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String action = intent.getAction();
                if (action != null && action.equals(Config.HEART_RATE_CLICK_TO_RUN)) {
                    if (mPageName == null)
                        return;
                    if (mPageName.contains("PairHeartRateConnectActivity") || mPageName.contains("FirmwareUpdateActivity")) {
                        return;
                    }
                    if (mPageName.contains("RunMainActivity")) {
                        RunMainActivity runMainActivity = (RunMainActivity) BaseActivity.this;
                        if (runMainActivity.getRunService() != null) {
                            if (runMainActivity.getRunService().isInRunDuration()) {//还在运动过程中
                                if (runMainActivity.getRunService().isRunning()) {
                                    runMainActivity.pauseRun(true);//运动暂停,隐藏显示对话框,防止丢失key focus
                                } else {
                                    runMainActivity.runContinue();//运动继续
                                }
                            }
                        } else {
                            clickToRun();
                        }
                    } else {
                        clickToRun();
                    }
                }
            }
        }
    }

    /**
     * 一键运动
     */
    protected void clickToRun() {
        Intent intent = new Intent(this, RunMainActivity.class);
        if (PlayerController.getInstance().isMusicPlaying()) {
            intent.putExtra("musicInfo", JsonHelper.createJsonString(PlayerController.getInstance().getCurrentMusic()));
        }
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
    //endregion ============================== 智能设备相关 ==============================

    //region ============================== 信鸽消息推送相关 ==============================

    /**
     * 发送app活跃状态
     */
    private void sendAppActiveStatus() {
        if (!MyLifecycleHandler.isApplicationInForeground()) {
            if (!TextUtils.isEmpty(XGPushConfig.getToken(this))) {
                uploadDeviceStatus(0, XGPushConfig.getToken(this));//取消app的活跃状态
            }
        }
    }

    /**
     * 上传app活跃状态
     *
     * @param active      app活跃状态,0:app休眠,1:app活跃
     * @param deviceToken 信鸽deviceToken
     */
    protected void uploadDeviceStatus(int active, String deviceToken) {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().uploadDeviceStatus(active, deviceToken, true);
        registerDataReqStatusListener(requestId);
    }

    //endregion  ============================== 信鸽消息推送相关 ==============================

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        Logger.i(Logger.DEBUG_TAG, "onKeyDown keyCode:" + keyCode);
        boolean bResult = false;
        switch (keyCode) {
            case 88://KeyEvent.KEYCODE_MEDIA_PREVIOUS
                bResult = true;
                break;
        }

        if (bResult) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
//        Logger.i(Logger.DEBUG_TAG, "onKeyUp keyCode:" + keyCode);
        boolean bResult = false;
        switch (keyCode) {
            case 88://KeyEvent.KEYCODE_MEDIA_PREVIOUS
                bResult = true;
                break;

        }
        if (bResult) {
            //检测到上一首手势,除了正在主跑界面和音乐播放界面外,一键运动
            if (mPageName != null) {
                //保存uid到sharedPreference中,临时解决RunMainActivity和PersonInfo中的uid在运动过程中被回收提示未登录问题
                Intent intent = new Intent(this, RunMainActivity.class);
                startActivity(intent);
            }
            return true;
        }
        /**
         * java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
         * at android.support.v4.app.FragmentManagerImpl.checkStateLoss(FragmentManager.java:1489)
         * at android.support.v4.app.FragmentManagerImpl.popBackStackImmediate(FragmentManager.java:584)
         * at android.support.v4.app.FragmentActivity.onBackPressed(FragmentActivity.java:169)
         * at android.app.Activity.onKeyUp(Activity.java:2684)
         * */
        if (ftCanCommit) {//
            return super.onKeyUp(keyCode, event);
        }
        return false;
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {//java.lang.NullPointerException: Attempt to invoke virtual method 'boolean android.content.Intent.migrateExtraStreamToClipData()' on a null object reference
        //at android.app.Instrumentation.execStartActivity(Instrumentation.java:1516)
        //at android.app.Activity.startActivityForResult(Activity.java:4030)

        try {
            if (intent == null) {
                intent = new Intent();
            }
            super.startActivityForResult(intent, requestCode);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }

    }

}
