package com.fitmix.sdk.view.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.SyncToQQResult;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;

public class SyncToQQActivity extends BaseActivity {
    private boolean isChange = false;
    private boolean toggleByMan = false;
    private LinearLayout container;
    private SwitchCompat syncToQQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync_to_qq);
        setPageName("SyncToQQActivity");
        initToolbar();
        initViews();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_SPORT + 6://同步
                String syncResult = DataReqStatusHelper.getInstance().getDataReqResult(Config.MODULE_SPORT + 6);
                if (TextUtils.isEmpty(syncResult)) return;
                SyncToQQResult syncToQQResult = JsonHelper.getObject(syncResult, SyncToQQResult.class);
                if (syncToQQResult != null) {
                    int ret = syncToQQResult.getRet();
                    if (ret != 0) {
                        showFailureDialog();
                    } else {
                        showSuccessDialog();
                    }
                }
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_SPORT + 6://同步
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    }
                }
                break;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (isChange && getIsHaveQQToken()) {
            SettingsHelper.putBoolean(Config.SETTING_SYNC_TO_QQ_SPORT, true);
        }
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        boolean syncToQQSport;
        if (loginType == 2) {
            syncToQQSport = SettingsHelper.getBoolean(Config.SETTING_SYNC_TO_QQ_SPORT, true);
        } else {
            syncToQQSport = SettingsHelper.getBoolean(Config.SETTING_SYNC_TO_QQ_SPORT, false);
        }

        if (getIsHaveQQToken() && syncToQQSport) {
            container.setVisibility(View.VISIBLE);
            toggleByMan = false;
            syncToQQ.setChecked(true);
            toggleByMan = true;
        } else {
            container.setVisibility(View.GONE);
            toggleByMan = false;
            syncToQQ.setChecked(false);
            toggleByMan = true;
        }
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        container = (LinearLayout) findViewById(R.id.sync_qq_more_group);
        syncToQQ = (SwitchCompat) findViewById(R.id.sync_to_qq_health);
        syncToQQ.setChecked(getIsHaveQQToken());
        syncToQQ.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (toggleByMan) {
                    if (isChecked) {
                        startQQLogin();
                    } else {
                        cleanQQToken();
                        refresh();
                    }
                }
            }
        });
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.go_to_qq_health:
                startQQ();
                break;
            case R.id.sync_to_qq:
                FitmixUtil.syncToQQHealth(this);
                registerDataReqStatusListener(Config.MODULE_SPORT + 6);
                break;
        }
    }

    private void showSuccessDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.fm_mine_more_qq_health_success)
                .positiveText(R.string.ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://开始下载
                                finish();
                                break;
                        }
                    }
                }).show();
    }

    private void showFailureDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.fm_mine_more_qq_health_failure)
                .positiveText(R.string.fm_mine_more_qq_health_again)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://再次同步
                                FitmixUtil.syncToQQHealth(SyncToQQActivity.this);
                                registerDataReqStatusListener(Config.MODULE_SPORT + 6);
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 启动隐私
     */
    private void startQQ() {
        Intent intent = new Intent();
        intent.setClass(this, WebViewActivity.class);
        intent.putExtra("url", "http://jiankang.qq.com/?_wv=2163715&_bid=233");
        intent.putExtra("title", "QQ健康");
        startActivity(intent);
    }

    public void startQQLogin() {
        isChange = true;
        Intent intent = new Intent();
        intent.setClass(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_QQ_LOGIN);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_LOGIN);
    }

    public void cleanQQToken() {
        AccessTokenKeeper.clearQQ(this);
        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_QQ_LOGOUT);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_LOGOUT);
    }

    private boolean getIsHaveQQToken() {
        SharedPreferences sp = getSharedPreferences(AccessTokenKeeper.QQ_OAUTH_NAME, Context.MODE_PRIVATE);
        String openid = sp.getString(AccessTokenKeeper.KEY_OPENID, "");
        String tokenid = sp.getString(AccessTokenKeeper.KEY_ACCESS_TOKEN, "");
        return !TextUtils.isEmpty(openid) && !TextUtils.isEmpty(tokenid);
    }
}
