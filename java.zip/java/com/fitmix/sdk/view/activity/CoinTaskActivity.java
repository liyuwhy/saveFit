package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.model.api.bean.AlbumList;
import com.fitmix.sdk.model.api.bean.BannerList;
import com.fitmix.sdk.model.api.bean.ClubList;
import com.fitmix.sdk.model.api.bean.VideoList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.bean.Video;
import com.fitmix.sdk.view.fragment.ClubFragment;
import com.fitmix.sdk.view.fragment.DiscoveryFragment;
import com.fitmix.sdk.view.fragment.MusicFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * 金币任务界面点击[立即开始]时,用于加载原先嵌于MainActivity的一些Fragment,减少MainActivity代码量,清晰调用逻辑
 */
public class CoinTaskActivity extends BaseActivity implements MusicFragment.MusicFragmentCallback, DiscoveryFragment.DiscoveryFragmentCallback {

    private static final int PICK_CLUB_ID = 123;
    /**
     * 需要加载的Fragment类型
     * <p>
     * 1:MusicFragment
     * 2:DiscoveryFragment
     * 3:ClubFragment
     */
    private int fragmentType;

    //    private int competitionListIndex;
    private int videoListIndex;

    private Uri mCropImageUri;
    private int avatarId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_task);
        setPageName("CoinTaskActivity");

        if (getIntent() != null) {
            fragmentType = getIntent().getIntExtra(CoinQuestActivity.INTENT_EXTRA_FRAGMENT_TYPE, 0);
        } else {
            finish();
        }

        if (fragmentType == 0) {
            finish();
        }

        initToolbar();
        initViews();
    }

    /**
     * 设置 toolbar
     *
     * @param showBack   是否显示返回按钮
     * @param titleResId toolbar标题字符串资源ID
     */
    public void setToolbar(boolean showBack, int titleResId) {
        if (toolbar == null) return;
        toolbar.setNavigationIcon(null);
        toolbar.setNavigationOnClickListener(null);
        if (showBack) {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        } else {
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            }

        }
        String title = getString(titleResId);
        if (!TextUtils.isEmpty(title)) {
            setUiTitle(title);
        }
    }

    /**
     * 设置标题是否有viewPager
     *
     * @param viewPager viewPager,注意要作为Fragment的field,否则造成内存泄漏.
     */
    public void setIndicator(ViewPager viewPager, String[] titles) {
        setUiIndicator(viewPager, titles);
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        switch (fragmentType) {
            case 1://MusicFragment
                loadDataForMusicFragment();
                MusicFragment musicFragment = new MusicFragment().setFragmentCallback(this);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.mainContainer, musicFragment, MusicFragment.TAG).commit();
                break;

            case 2://DiscoveryFragment
                loadDataForDiscoveryFragment();
                DiscoveryFragment discoveryFragment = new DiscoveryFragment().setFragmentCallback(this);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.mainContainer, discoveryFragment, DiscoveryFragment.TAG).commit();
                break;

            case 3://ClubFragment
                loadDataForClubFragment();
                ClubFragment clubFragment = new ClubFragment();
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.mainContainer, clubFragment, ClubFragment.TAG).commit();
                break;
        }

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "CoinTaskActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {

            //region =================================== MusicFragment ===================================
            case Config.MODULE_MUSIC + 1://获取专辑列表
                MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                if (fragment != null) {
                    stopRefreshMusicFragmentAlbumList(dataReqResult.getResult());
                }
                break;
            case Config.MODULE_MUSIC + 2://获取Banner列表
                MusicFragment fragment2 = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
                if (fragment2 != null) {
                    stopRefreshMusicFragmentBannerList(dataReqResult.getResult());
                }
                break;
            case Config.MODULE_MUSIC + 6://获取电台列表
                stopRefreshMusicFragmentRadioList(dataReqResult.getResult());
                break;
            //endregion =================================== MusicFragment ===================================

            //region =================================== DiscoveryFragment ===================================
//            case Config.MODULE_COMPETITION + 1:
//                stopRefreshCompetitionList(result);
//                break;
            case Config.MODULE_COMPETITION + 2:
                stopRefreshVideoList(result);
                break;
//            case Config.MODULE_COMPETITION + 3:
//                stopRefreshCompetitionList(result);
//                break;
            case Config.MODULE_COMPETITION + 4:
                stopRefreshVideoList(result);
                break;
            //endregion =================================== DiscoveryFragment ===================================

            //region =================================== ClubFragment ===================================
            case Config.MODULE_CLUB + 1://获取俱乐部列表
                stopRefreshClubFragmentList(result);
                break;
            case Config.MODULE_CLUB + 14://创建俱乐部
                afterCreateClub(true);
                break;
            //endregion =================================== ClubFragment ===================================

        }
    }

    //region ====================================== MusicFragment 相关 ======================================
    @Override
    public void onSportPageRefresh() {
        startRefreshMusicFragment(true);
    }

    @Override
    public void onRadioPageRefresh() {
        startRefreshMusicFragmentRadio(true);
    }

    /**
     * 加载MusicFragment需要的数据
     */
    private void loadDataForMusicFragment() {
        startRefreshMusicFragment(false);
        startRefreshMusicFragmentRadio(false);
    }

    /**
     * 刷新 musicFragment
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshMusicFragment(boolean ignorePreCache) {
        int requestId = MusicDataManager.getInstance().getAlbumList(Config.REQUEST_MUSIC_ALBUM, ignorePreCache);
        registerDataReqStatusListener(requestId);

        int requestId2 = MusicDataManager.getInstance().getBannerList(ignorePreCache);
        registerDataReqStatusListener(requestId2);

    }

    /**
     * 刷新 musicFragment电台
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshMusicFragmentRadio(boolean ignorePreCache) {
        int requestId3 = MusicDataManager.getInstance().getAlbumRadioList(Config.REQUEST_RADIO_ALBUM, ignorePreCache);
        registerDataReqStatusListener(requestId3);
    }

    /**
     * 刷新专辑列表
     */
    public void stopRefreshMusicFragmentAlbumList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
            if (albumList == null || albumList.getList() == null || albumList.getList().size() <= 0)
                return;
            List<Album> list = new ArrayList<>();
            list.addAll(albumList.getList());
            if (OperateMusicUtils.getAlbumNumber() > 0) {
                list.addAll(OperateMusicUtils.getAlbumList());
            }
            fragment.showAlbumList(list);
        }
    }

    /**
     * 刷新电台
     */
    public void stopRefreshMusicFragmentRadioList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
            if (albumList == null || albumList.getList() == null || albumList.getList().size() <= 0)
                return;
            List<Album> list = new ArrayList<>();
            list.addAll(albumList.getList());
            fragment.showRadioList(list);
        }
    }

    /**
     * 刷新banner
     */
    public void stopRefreshMusicFragmentBannerList(String sResult) {
        MusicFragment fragment = (MusicFragment) getSupportFragmentManager().findFragmentByTag(MusicFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            BannerList bannerList = JsonHelper.getObject(sResult, BannerList.class);
            if (bannerList == null || bannerList.getData() == null || bannerList.getData().size() <= 0)
                return;
            fragment.showBanner(bannerList.getData());
        }
    }

    //endregion ====================================== MusicFragment 相关 ======================================

    //region ====================================== DiscoveryFragment 相关 ======================================

    @Override
    public void onTopicRefresh(int topicListOrderType) {
        //不处理
    }

    @Override
    public void onTopicLoadMore(int topicListOrderType) {
        //不处理
    }

//    @Override
//    public void onCompetitionRefresh() {
//        //不处理
////        startRefreshCompetitionList(true);
//    }
//
//    @Override
//    public void onCompetitionLoadMore() {
//        startLoadMoreCompetitionList();
//    }

    @Override
    public void onVideoRefresh() {
        startRefreshVideoList(true);
    }

    @Override
    public void onVideoLoadMore() {
        startLoadMoreVideoList();
    }

    /**
     * 加载DiscoveryFragment需要的数据
     */
    private void loadDataForDiscoveryFragment() {
        startRefreshDiscoveryFragmentList(false);
    }

    /**
     * 请求赛事列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshDiscoveryFragmentList(boolean ignorePreCache) {
        startRefreshVideoList(ignorePreCache);
//        startRefreshCompetitionList(ignorePreCache);
    }

    /**
     * 请求运动视频列表
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshVideoList(boolean ignorePreCache) {
        videoListIndex = 1;
        int requestId = DiscoverDataManager.getInstance().getVideoList(videoListIndex, ignorePreCache);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 加载更多视频信息
     */
    public void startLoadMoreVideoList() {
        int requestId = DiscoverDataManager.getInstance().getVideoListForLoadMore(videoListIndex, true);
        registerDataReqStatusListener(requestId);
    }

//    /**
//     * 请求运动赛事列表
//     *
//     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
//     */
//    public void startRefreshCompetitionList(boolean ignorePreCache) {
//        competitionListIndex = 1;
//        int requestId = DiscoverDataManager.getInstance().getCompetitionList(competitionListIndex, ignorePreCache);
//        registerDataReqStatusListener(requestId);
//    }

//    /**
//     * 加载更多赛事列表
//     */
//    public void startLoadMoreCompetitionList() {
//        int requestId = DiscoverDataManager.getInstance().getCompetitionListForLoadMore(competitionListIndex, true);
//        registerDataReqStatusListener(requestId);
//    }

    public void stopRefreshVideoList(String sResult) {
        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            VideoList videoList = JsonHelper.getObject(sResult, VideoList.class);
            List<Video> list = new ArrayList<>();
            if (videoList != null && videoList.getPage() != null) {
                list.addAll(videoList.getPage().getResult());
            }
            fragment.showVideoList(list, videoListIndex);
            if (list.size() > 0) videoListIndex++;
        }
    }


//    public void stopRefreshCompetitionList(String sResult) {
//        DiscoveryFragment fragment = (DiscoveryFragment) getSupportFragmentManager().findFragmentByTag(DiscoveryFragment.TAG);
//        if (fragment != null && fragment.isVisible()) {
//            CompetitionList competitionList = JsonHelper.getObject(sResult, CompetitionList.class);
//            if (competitionList != null) {
//                List<Competition> list = new ArrayList<>();
//                if (competitionList.getPage() != null) {
//                    list.addAll(competitionList.getPage().getResult());
//                }
//                long serverTime = competitionList.getSYSTIME();
//                fragment.showCompetitionList(list, serverTime, competitionListIndex);
//                if (list.size() > 0) competitionListIndex++;
//            }
//        }
//    }

    //endregion ====================================== DiscoveryFragment 相关 ======================================

    //region ====================================== ClubFragment 相关 ======================================

    /**
     * 添加Fragment到back stack
     *
     * @param fragment 要添加的fragment
     * @param tag      fragment tag
     */
    public void pushFragment(Fragment fragment, String tag) {
//        Log.i("TT", "pushFragment-->Tag:" + tag);
        if (fragment == null) return;
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                    //.setCustomAnimations(R.animator.push_left_in, R.animator.push_left_out, R.animator.push_right_in, R.animator.push_right_out)
                    .addToBackStack(null)
                    .replace(R.id.mainContainer, fragment, tag)
                    .commit();
        }
    }


    private void loadDataForClubFragment() {
        startRefreshClubFragmentList(false);
    }

    /**
     * 加载ClubFragment需要的数据
     *
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    public void startRefreshClubFragmentList(boolean ignorePreCache) {
        int uid = UserDataManager.getUid();
        int requestId = ClubDataManager.getInstance().getClubList(uid, ignorePreCache);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void createClub(String clubName, String clubDesc, String fileName) {
        int requestId = ClubDataManager.getInstance().createClub(clubName, clubDesc, fileName, "image", false);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void afterCreateClub(boolean isSuccess) {
        if (isSuccess) {
            onBackPressed();
            startRefreshClubFragmentList(true);
        }
    }

    public void stopRefreshClubFragmentList(String sResult) {
        ClubFragment fragment = (ClubFragment) getSupportFragmentManager().findFragmentByTag(ClubFragment.TAG);
        if (fragment != null && fragment.isVisible()) {
            ClubList clubListInfo = JsonHelper.getObject(sResult, ClubList.class);
            if (clubListInfo != null) {
                List<Club> clubList = clubListInfo.getList();
                if (clubList != null) {
                    for (int i = 0; i < clubList.size(); i++) {
                        if (clubList.get(i).getType() == 2) {//2是开放俱乐部的标志 俱乐部假退出功能
                            boolean showOpenCLub = SettingsHelper.getBoolean(Config.SETTING_SHOW_OPEN_CLUB, true);
                            if (!showOpenCLub) {
                                clubList.remove(clubList.get(i));
                            }
                            break;
                        }
                    }
                    Club club = new Club();
                    club.setName(getResources().getString(R.string.fm_club_create_club));
                    club.setBackImageUrl(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.add_club)).build().toString());
                    clubList.add(club);
                    fragment.stopRefresh(clubList);
                }
            }
        }
    }

    /**
     * 从相册或相机获取图片
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
        avatarId = view.getId();//保存ID,之后图片设置用
    }

    /**
     * 剪裁图片
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(43, 58)//172 232
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    //endregion ====================================== ClubFragment 相关 ======================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;
            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    View v = findViewById(avatarId);
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (v != null && bitmap != null) {
                        ImageHelper.adjustPhotoToFitSize(bitmap, Config.USER_CLUB_WIDTH, Config.USER_CLUB_HEIGHT, FitmixUtil.getTempPhotoFile());
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;
        }
    }

}
