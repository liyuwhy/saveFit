package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.PushMessageBody;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.User;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.FavoriteMusicHelper;
import com.fitmix.sdk.model.database.MessageHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.countrypicker.Country;
import com.fitmix.sdk.view.countrypicker.CountryPicker;
import com.fitmix.sdk.view.countrypicker.OnCountryPickerListener;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

import java.util.List;


public class LoginActivity extends BaseActivity {

//    public static final int REQUEST_CODE_FITMIX_RESERVED = 20;

    /**
     * 邮箱注册成功后,自动登录
     */
    public final static int REQUEST_REGISTER = 40;

    /**
     * 登录类型为邮箱账号
     */
    private final String EMAIL_LOGIN = "fitmix";
    /**
     * 登录类型为QQ
     */
    private final String QQ_LOGIN = "qq";
    /**
     * 登录类型为微信
     */
    private final String WEXIN_LOGIN = "weixin";
    /**
     * 登录类型为新浪微博
     */
    private final String WEIBO_LOGIN = "weibo";
    /**
     * 防止短时间内多次启动MainActivity
     */
    private boolean startMainActivityOnce = true;

    private RadioGroup rg_login;
    private FrameLayout fl_login_phone;
    private EditText txt_account_email;
    private EditText txt_account_phone;
    private TextView txt_china_phone;
    private EditText txt_password;
   // private EditText txt_china_phone;

    private LinearLayout ll_register_area;
    private TextView tv_label_area;
    private String mAccount;
    private String mPassword;
    private String loginType;
    //    private boolean bStartMain;
    private MaterialDialog dialog;

    private int clickNum;
    private boolean debug = false;
    private boolean isPhoneLoginType = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setPageName("LoginActivity");
        //android 6.0权限
        getPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        initToolbar();
        initViews();
        initData();
    }


    @Override
    protected void onResume() {
        super.onResume();
      //  refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        debug = false;
        clickNum = 0;
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    @Override
    protected void clickToRun() {
    }//该activity不做操作


    protected void initViews() {
        txt_account_email = (EditText) findViewById(R.id.txt_account_email);
        txt_account_phone = (EditText) findViewById(R.id.txt_account_phone);
        txt_password = (EditText) findViewById(R.id.txt_password);
        txt_china_phone = (TextView) findViewById(R.id.txt_china_number);
        fl_login_phone = (FrameLayout)findViewById(R.id.fl_login_phone);
        rg_login = (RadioGroup) findViewById(R.id.rg_login);
        ll_register_area = findViewById(R.id.ll_register_area);
        tv_label_area = findViewById(R.id.tv_label_area);
        txt_password.setOnKeyListener(new EditText.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_ENTER) {
                    emailLogin();//点击回车,登录
                    return true;
                }
                return false;
            }
        });
        rg_login.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radio_phone_login:
                        isPhoneLoginType = true;
                        ll_register_area.setVisibility(View.VISIBLE);
                        fl_login_phone.setVisibility(View.VISIBLE);
                        txt_account_email.setVisibility(View.GONE);
                        txt_account_phone.setText("");
                        txt_china_phone.setText(getResources().getString(R.string.china_phone_code));
                        break;
                    case R.id.radio_email_login:
                        isPhoneLoginType = false;
                        ll_register_area.setVisibility(View.GONE);
                        txt_account_email.setVisibility(View.VISIBLE);
                        fl_login_phone.setVisibility(View.GONE);
                        txt_account_email.setText("");
                        break;
                }
                txt_password.setText("");
            }
        });

        ll_register_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(LoginActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                        tv_label_area.setText(country.getName());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog
            }
        });

    }

    /**
     * 初始化数据
     */
    private void initData() {
        mAccount = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER, "");
        mAccount = mAccount.replace("+","%2b");
        mPassword = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD, "");

//        Intent intent = getIntent();
//        if (intent != null) bStartMain = intent.getBooleanExtra("startMain", false);
    }

    /**
     * 刷新界面
     */
    private void refresh() {
        if (!TextUtils.isEmpty(mAccount)) {
            if (mAccount.contains("+")){//手机号登录
                rg_login.check(R.id.radio_phone_login);
                fl_login_phone.setVisibility(View.VISIBLE);
                txt_account_email.setVisibility(View.GONE);
                txt_account_phone.setText(mAccount);
                txt_account_phone.setSelection(mAccount.length());
            }else {//邮箱登录
                txt_account_email.setVisibility(View.VISIBLE);
                fl_login_phone.setVisibility(View.GONE);
                rg_login.check(R.id.radio_email_login);
                txt_account_email.setText(mAccount);
                txt_account_email.setSelection(mAccount.length());
            }
        }
        if (!TextUtils.isEmpty(mPassword)) {
            txt_password.setText(mPassword);
            txt_password.setSelection(mPassword.length());
        }
    }

    /**
     * 启动注册Activity
     */
    private void startRegisterActivity() {
        Intent intent = new Intent();
        intent.setClass(LoginActivity.this, RegisterActivity.class);
        startActivityForResult(intent, REQUEST_REGISTER);
    }

    /**
     * 启动忘记密码Activity
     */
    private void startForgotPasswordActivity() {
        Intent intent = new Intent();
        intent.setClass(LoginActivity.this, ForgotPasswordActivity.class);
        startActivity(intent);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_sign_in://登录
                emailLogin();
                break;

            case R.id.btn_register://注册
                startRegisterActivity();
                break;

            case R.id.btn_forgot_password://忘记密码
                startForgotPasswordActivity();
                break;

            case R.id.btn_weixin_login://微信登录
                loginByWeiXin();
                break;

            case R.id.btn_qq_login://QQ登录
                loginByQQ();
                break;

            case R.id.btn_weibo_login://微博登录
                loginByWeiBo();
                break;

            case R.id.img_logo://调试查看用户记录用
                clickNum++;
                if (clickNum > 20) {
                    debug = true;//查看用户打开即可
                }
                break;
            default:
                break;
        }
    }

    /**
     * 获取登陆类型
     *
     * @return 登陆类型
     */
    private String getLoginType() {
        return loginType;
    }

    /**
     * 设置登陆类型
     *
     * @param sType 登陆类型
     */
    private void setLoginType(String sType) {
        this.loginType = sType;
    }

    /**
     * 邮件登录
     */
    private void emailLogin() {
        mPassword = txt_password.getText().toString();
        if (isPhoneLoginType){//号码登录
            String countryCode = txt_china_phone.getText().toString();
            countryCode = countryCode.replace("+","%2b");
            Logger.i(Logger.DATA_FLOW_TAG,"countryCode:"+countryCode);
            mAccount = txt_account_phone.getText().toString();
            mAccount = countryCode + mAccount;
        }else {//邮箱登录
            mAccount = txt_account_email.getText().toString();
            if (!FitmixUtil.isEmail(mAccount)) {
                showAppMessage(R.string.rsp_error_email_error, AppMsg.STYLE_ALERT);
                return;
            }
        }

        if (mPassword.length() < Config.PASSWORD_LENGTH_MIN) {
            showAppMessage(R.string.rsp_error_password_length_error, AppMsg.STYLE_ALERT);
            return;
        }
        setLoginType(EMAIL_LOGIN);
        //不考虑缓存
        int requestId = UserDataManager.getInstance().emailLogin(mAccount, mPassword, true);
        registerDataReqStatusListener(requestId);

        showLoginDialog();
    }

    /**
     * 显示登录对话框
     */
    private void showLoginDialog() {
        View convertView = getLayoutInflater().inflate(R.layout.dialog_progress, null);
        TextView textView = (TextView) convertView.findViewById(R.id.tv_content);
        textView.setText(R.string.activity_login_logining);
        dialog = new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .customView(convertView, true)
                .negativeText(android.R.string.cancel)
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        cancelRequest(Config.MODULE_USER + 2);//取消登录
                        dialog.dismiss();
                    }
                }).show();
    }

    /**
     * 启动主界面
     */
    private void startMainActivity() {
        if (startMainActivityOnce) {
            startMainActivityOnce = false;
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    /**
     * 处理登陆
     */
    private void processLogin() {
        String account = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER, "");
        String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD, "");
        if (TextUtils.isEmpty(account) || TextUtils.isEmpty(password)) return;
        if (account.contains("+")){
            mAccount = account.replace("+","%2b");
        }else {
            mAccount = account;
        }
        mPassword = password;
        int requestId = UserDataManager.getInstance().emailLogin(mAccount, password, true);
        registerDataReqStatusListener(requestId);
        showLoginDialog();
    }

    /**
     * 通过以前记录的tokenid和openid登录
     *
     * @return true:通过旧信息登录成功,false:失败
     */
    private boolean loginBySavedInfo() {
        /**Bug java.lang.RuntimeException: Failure delivering result ResultInfo{who=null, request=1000, result=-1, data=Intent { (has extras) }}
         * to activity {com.fitmix.sdk/com.fitmix.sdk.LoginActivity}: java.lang.NullPointerException*/
        if (getLoginType() == null) {//登录类型为空判断
            return false;
        }
        String openid;
        String tokenId;
        String sPreference;
        if (getLoginType().equals(WEXIN_LOGIN)) {
            sPreference = AccessTokenKeeper.WECHAT_OAUTH_NAME;
            openid = PrefsHelper.with(this, sPreference).read(AccessTokenKeeper.KEY_OPENID);
            tokenId = PrefsHelper.with(this, sPreference).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {// 如果不为空,直接访问我们自己的服务器
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
                showAppMessage(R.string.activity_login_logining, AppMsg.STYLE_INFO);
                return true;
            }
        } else if (getLoginType().equals(QQ_LOGIN)) {
            sPreference = AccessTokenKeeper.QQ_OAUTH_NAME;
            openid = PrefsHelper.with(this, sPreference).read(AccessTokenKeeper.KEY_OPENID);
            tokenId = PrefsHelper.with(this, sPreference).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {// 如果不为空,直接访问我们自己的服务器
                Logger.i(Logger.DEBUG_TAG, "openid:" + openid + " tokenId:" + tokenId);
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
                showAppMessage(R.string.activity_login_logining, AppMsg.STYLE_INFO);
                return true;
            }
        } else if (getLoginType().equals(WEIBO_LOGIN)) {
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            openid = weiboToken.getUid();
            tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {// 如果不为空,直接访问我们自己的服务器
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
                showAppMessage(R.string.activity_login_logining, AppMsg.STYLE_INFO);
                return true;
            }
        }
        return false;
    }

    /**
     * 微信登录
     */
    private void loginByWeiXin() {
        setLoginType(WEXIN_LOGIN);
        if (loginBySavedInfo()) return;

        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_WECHAT_LOGIN);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_WECHAT_LOGIN);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);

    }

    /**
     * 微博登录
     */
    private void loginByWeiBo() {
        setLoginType(WEIBO_LOGIN);
        if (loginBySavedInfo()) return;

        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_SINA_LOGIN);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_SINA_LOGIN);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);

    }

    /**
     * QQ登录
     */
    private void loginByQQ() {
        setLoginType(QQ_LOGIN);
        if (loginBySavedInfo()) return;

        Intent intent = new Intent(this, AuthShareHelper.class);
        intent.putExtra(AuthShareHelper.KEY_REQUESTCODE, AuthShareHelper.REQUESTCODE_QQ_LOGIN);
        startActivityForResult(intent, AuthShareHelper.REQUESTCODE_QQ_LOGIN);
        showAppMessage(R.string.activity_login_authorizing, AppMsg.STYLE_INFO);

    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 2://邮箱登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录

                Login login = JsonHelper.getObject(result, Login.class);
                if (login != null && login.getUser() != null) {
                    //登录成功,保存uid,登录类型,登录账号,密码,身高,体重,跳转到主界面
                    int uid = login.getUser().getId();
                    if (login.getCollectIds() != null) {
                        FavoriteMusicHelper.getInstance().insertFavoriteMusicList(login.getCollectIds());
                    }
                    UserDataManager.setUid(uid);
                    PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, login.getUser().getLoginType());

                    String userName = "";
                    if (login.getUser().getLoginType() == 1) {
                        userName = login.getUser().getEmail();
                    } else if (login.getUser().getLoginType() == 5) {
                        userName = login.getUser().getMobile();
                    }
                    if (!TextUtils.isEmpty(userName)) {//如果是邮箱或者手机登录的情况，记录保存账号
                        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_USER, mAccount);
                        if (!TextUtils.isEmpty(mPassword)) {//如果是邮箱或者手机登录的情况,记录保存密码
                            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_PWD, mPassword);
                        }
                    }
                    setUserInfoToSettingConfigs(login);
                    setUserMessageInfo(login);

                    //友盟统计登录
                    UmengAnalysisHelper.getInstance().loginReportPlus(this, getLoginType());
                    startMainActivity();
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            switch (requestId) {
                case Config.MODULE_USER + 2://邮箱登录错误
                    if (errorCode == 2000) {//用户不存在
                        showAppMessage(R.string.rsp_error_user_not_exist, AppMsg.STYLE_ALERT);
                    } else if (errorCode == 2001) {//用户名或密码错误
                        showAppMessage(R.string.rsp_error_password_error, AppMsg.STYLE_ALERT);
                    } else if (errorCode == 2002) {//账号不可用,联系客服
                        showAppMessage(R.string.rsp_error_service_unavailable, AppMsg.STYLE_ALERT);
                    } else if (errorCode == 2004) {//需要重新登录
                        showAppMessage(R.string.fm_mine_more_force_logout_tip, AppMsg.STYLE_ALERT);
                    }
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    break;
                case Config.MODULE_USER + 3://QQ授权登录
                case Config.MODULE_USER + 4://新浪微博授权登录
                case Config.MODULE_USER + 5://微信授权登录
                    if (errorCode == 9800) {
                        showAppMessage(R.string.rsp_error_auth_error, AppMsg.STYLE_ALERT);
                    }
                    break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_REGISTER) {
            if (resultCode == RESULT_OK) {
                setLoginType(EMAIL_LOGIN);
                SettingsHelper.putInt(Config.SP_KEY_LAST_LOGIN_TYPE, 1);
                processLogin();
            }
            return;
        }

        if (data == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        if (resultCode == Activity.RESULT_OK) {     //三方登录
            int rCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, 0);
            String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
            switch (requestCode) {
                case AuthShareHelper.REQUESTCODE_QQ_LOGIN://QQ登录
                case AuthShareHelper.REQUESTCODE_SINA_LOGIN://微博登录
                case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN://微信登录
                    if (rCode == AuthShareHelper.RESULTCODE_SUCCESS) {//成功
                        loginBySavedInfo();
                    } else {
                        if (!TextUtils.isEmpty(resultStr)) {
                            showAppMessage(resultStr, AppMsg.STYLE_INFO);
                        }
                    }
                    break;
            }
        }
    }

    /**
     * 设置重要的用户信息到SettingConfigs数据库表中
     */
    private void setUserInfoToSettingConfigs(Login login) {
        User user = login.getUser();
        if (user == null)
            return;

        //绑定Activity相关的参数,等等
        SettingsHelper.putString(Config.SETTING_USER_EMAIL, user.getEmail());
        SettingsHelper.putString(Config.SETTING_USER_MOBILE, user.getMobile());
        SettingsHelper.putString(Config.SETTING_USER_QQ_NAME, user.getQqName());
        SettingsHelper.putString(Config.SETTING_USER_WB_NAME, user.getWbName());
        SettingsHelper.putString(Config.SETTING_USER_WX_NAME, user.getWxName());
        SettingsHelper.putString(Config.SETTING_USER_QQ_OPENID, user.getQqOpenid());
        SettingsHelper.putString(Config.SETTING_USER_WX_OPENID, user.getWxOpenid());
        SettingsHelper.putString(Config.SETTING_USER_WB_OPENID, user.getWbOpenid());
        if (user.getUserRealInfo() != null) {
            SettingsHelper.putString(Config.SETTING_USER_ID_CARD, user.getUserRealInfo().getIdCard());
        }
        SettingsHelper.putInt(Config.SETTING_USER_ID, user.getId());
        SettingsHelper.putInt(Config.SETTING_USER_GENDER, user.getGender());
        SettingsHelper.putInt(Config.SETTING_USER_AGE, user.getAge() > 0 ? user.getAge() : Config.USER_DEFAULT_AGE);

        if (user.getType() == 2) {//英制转公制
            SettingsHelper.putInt(Config.SETTING_USER_HEIGHT, (int) (user.getHeight() * 2.54f));
            SettingsHelper.putInt(Config.SETTING_USER_WEIGHT, (int) (user.getWeight() * 0.4535924f));
        } else {
            SettingsHelper.putInt(Config.SETTING_USER_HEIGHT, user.getHeight());
            SettingsHelper.putInt(Config.SETTING_USER_WEIGHT, user.getWeight());
        }
        SettingsHelper.putInt(Config.HEART_RATE_MAX, FitmixUtil.getMaxHeartRate(login.getUser().getAge() > 0 ? login.getUser().getAge() : Config.USER_DEFAULT_AGE));//存储最大心率
        SettingsHelper.putString(Config.SETTING_USER_AVATAR, user.getAvatar());
        SettingsHelper.putString(Config.SETTING_USER_NAME, user.getName());
    }

    /**
     * 设置未读消息到数据库中
     */
    private void setUserMessageInfo(Login login) {
        MessageHelper.getInstance().getMessageDao().deleteAll();
        if (login != null) {
            PushMessageBody pushMessageBody = login.getBodys();
            if (pushMessageBody != null) {
                List<PushMessageBody.ActivitysBean> list = pushMessageBody.getActivitys();
                if (list == null) return;
                if (list.size() > 0) {
                    MessageHelper.getInstance().insertMessage(3);
                }
                List<PushMessageBody.ClubsBean> clubsBeanList = pushMessageBody.getClubs();
                if (clubsBeanList != null && clubsBeanList.size() > 0) {
                    for (PushMessageBody.ClubsBean clubsBean : clubsBeanList) {
                        String clubsBeanS = JsonHelper.createJsonString(clubsBean);
                        Logger.i(Logger.DEBUG_TAG, "clubsBeanS : " + clubsBeanS);
                        //int type = Integer.getInteger(clubsBean.getPushType());
                        int type = clubsBean.getPushType();
                        //int clubID = Integer.getInteger(clubsBean.getClubId());
                        int clubID = clubsBean.getClubId();
                        int number = clubsBean.getNum();
                        switch (type) {
                            case 11://留言消息
                                MessageHelper.getInstance().insertMessage(clubID, 4, number);
                                break;
                            case 12://公告消息
                                MessageHelper.getInstance().insertMessage(clubID, 2, number);
                                break;
                        }
                    }
                }
            }
        }
    }


}

