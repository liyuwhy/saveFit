package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.RankListLevelData;
import com.fitmix.sdk.bean.RankListPkData;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.FragmentViewPagerAdapter;
import com.fitmix.sdk.view.bean.RankListData;
import com.fitmix.sdk.view.fragment.RankFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RankListActivity extends BaseActivity {

    private RelativeLayout rank_list_avatar_bg;
    private RadioGroup rank_list_rg;
    private RadioButton rank_list_bronze, rank_list_silver, rank_list_gold, rank_list_platinum, rank_list_diamond;

    private TextView rank_list_user_name_tv, rank_list_distance_tv;
    private SimpleDraweeView rank_list_avatar;

    //    private TextView rank_list_this_date_tv,
    private TextView rank_list_this_level_section_name, rank_list_this_level_score_name;
    private ImageView rank_list_this_score_status_iv;

    //    private TextView rank_list_last_date_tv,
    private TextView rank_list_last_level_section_name, rank_list_last_level_score_name;
    private long lastMonthTimes;
    private long lastMonthTimeStamp;
    /**
     * 上个界面是否是MainActivity,如果是表明界面为本月排行数据,否则为上月排行数据
     */
    private boolean isFromHome;
    /**
     * 当前青铜数据请求页码
     */
    private int pageNoBronze = 1;
    /**
     * 当前白银数据请求页码
     */
    private int pageNoSilver = 1;
    /**
     * 当前黄金数据请求页码
     */
    private int pageNoGold = 1;
    /**
     * 当前铂金数据请求页码
     */
    private int pageNoPlatinum = 1;
    /**
     * 当前钻石数据请求页码
     */
    private int pageNoDiamond = 1;
    private int level;
    private List<RankListLevelData.PageBean.ResultBean> bronzeRankList = new ArrayList<>();
    private List<RankListLevelData.PageBean.ResultBean> silverRankList = new ArrayList<>();
    private List<RankListLevelData.PageBean.ResultBean> goldRankList = new ArrayList<>();
    private List<RankListLevelData.PageBean.ResultBean> platinumRankList = new ArrayList<>();
    private List<RankListLevelData.PageBean.ResultBean> diamondRankList = new ArrayList<>();

    private int pkPosition;
    private boolean showLastMonthRank = false;
    private int thisMonth;
    private int monthLevel = 0;
    private int thisRank = 0;
    private int distance = 0;
    private ViewPager rank_list_vp;
    //记录当前Fragment
    private int mCurrentFragmentIndex = 0;
    private List<Fragment> fragments = new ArrayList<>();//viewPager fragment集合

    private RankFragment bronzeFragment;
    private RankFragment silverFragment;
    private RankFragment goldFragment;
    private RankFragment platinumFragment;
    private RankFragment diamondFragment;

    private int nextPage;
    private int sumDistanceValidBefore;
    private int rankBefore = 0;
    private int levelBefore = 0;
    private int monthLast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_list);
        setPageName("RankListActivity");
        lastMonthTimeStamp = getIntent().getLongExtra("lastMonthTimeStamp", System.currentTimeMillis());
        isFromHome = getIntent().getBooleanExtra("isFromHome", false);
        sumDistanceValidBefore = getIntent().getIntExtra("sumDistanceValid_before", 0);
        initToolbar();
        initViews();
        getRankListData();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void initViews() {
        if (isFromHome) {
            setUiTitle(getResources().getString(R.string.this_month_rank_list));
        } else {
            setUiTitle(getResources().getString(R.string.last_month_rank_list));
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        //1.初始化5个排行榜的fragment
        initBronzeFragment();
        initSilverFragment();
        initGoldFragment();
        initPlatinumFragment();
        initDiamondFragment();

        fragments.add(bronzeFragment);
        fragments.add(silverFragment);
        fragments.add(goldFragment);
        fragments.add(platinumFragment);
        fragments.add(diamondFragment);

        rank_list_avatar_bg = (RelativeLayout) findViewById(R.id.rank_list_avatar_bg);
        rank_list_user_name_tv = (TextView) findViewById(R.id.rank_list_user_name_tv);
        rank_list_distance_tv = (TextView) findViewById(R.id.rank_list_distance_tv);
        rank_list_avatar = (SimpleDraweeView) findViewById(R.id.rank_list_avatar);
        rank_list_this_score_status_iv = (ImageView) findViewById(R.id.rank_list_this_score_status_iv);

        rank_list_user_name_tv.setText(SettingsHelper.getString(Config.SETTING_USER_NAME, ""));
        rank_list_avatar.setImageURI(Uri.parse(SettingsHelper.getString(Config.SETTING_USER_AVATAR, "")));

        rank_list_this_level_section_name = (TextView) findViewById(R.id.rank_list_this_level_section_name);
        rank_list_this_level_score_name = (TextView) findViewById(R.id.rank_list_this_level_score_name);

        rank_list_last_level_section_name = (TextView) findViewById(R.id.rank_list_last_level_section_name);
        rank_list_last_level_score_name = (TextView) findViewById(R.id.rank_list_last_level_score_name);

        rank_list_rg = (RadioGroup) findViewById(R.id.rank_list_rg);
        rank_list_bronze = (RadioButton) findViewById(R.id.rank_list_bronze);
        rank_list_silver = (RadioButton) findViewById(R.id.rank_list_silver);
        rank_list_gold = (RadioButton) findViewById(R.id.rank_list_gold);
        rank_list_platinum = (RadioButton) findViewById(R.id.rank_list_platinum);
        rank_list_diamond = (RadioButton) findViewById(R.id.rank_list_diamond);

        rank_list_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (ftCanCommit) {
                    getSupportFragmentManager().popBackStackImmediate();
                }
                int checkedItem = 0;
                switch (checkedId) {
                    case R.id.rank_list_bronze://青铜选项卡
                        checkedItem = 0;
                        bronzeRankList.clear();
                        if (pageNoBronze > 1) {
                            pageNoBronze = 1;
                            getRankListLevelData(1, pageNoBronze, true);
                        } else {
                            pageNoBronze = 1;
                            getRankListLevelData(1, pageNoBronze, false);
                        }
                        break;
                    case R.id.rank_list_silver://白银选项卡
                        checkedItem = 1;
                        silverRankList.clear();
                        if (pageNoSilver > 1) {
                            pageNoSilver = 1;
                            getRankListLevelData(2, pageNoSilver, true);
                        } else {
                            pageNoSilver = 1;
                            getRankListLevelData(2, pageNoSilver, false);
                        }
                        break;
                    case R.id.rank_list_gold://黄金选项卡
                        checkedItem = 2;
                        goldRankList.clear();
                        if (pageNoGold > 1) {
                            pageNoGold = 1;
                            getRankListLevelData(3, pageNoGold, true);
                        } else {
                            pageNoGold = 1;
                            getRankListLevelData(3, pageNoGold, false);
                        }
                        break;
                    case R.id.rank_list_platinum://铂金选项卡
                        checkedItem = 3;
                        platinumRankList.clear();
                        if (pageNoPlatinum > 1) {
                            pageNoPlatinum = 1;
                            getRankListLevelData(4, pageNoPlatinum, true);
                        } else {
                            pageNoPlatinum = 1;
                            getRankListLevelData(4, pageNoPlatinum, false);
                        }
                        break;
                    case R.id.rank_list_diamond://钻石选项卡
                        checkedItem = 4;
                        diamondRankList.clear();
                        if (pageNoDiamond > 1) {
                            pageNoDiamond = 1;
                            getRankListLevelData(5, pageNoDiamond, true);
                        } else {
                            pageNoDiamond = 1;
                            getRankListLevelData(5, pageNoDiamond, false);
                        }
                        break;

                }
                mCurrentFragmentIndex = checkedItem;
                rank_list_vp.setCurrentItem(mCurrentFragmentIndex);
            }
        });

        rank_list_vp = (ViewPager) findViewById(R.id.rank_list_vp);
        FragmentViewPagerAdapter adapter = new FragmentViewPagerAdapter(getSupportFragmentManager(), fragments);
        rank_list_vp.setAdapter(adapter);
        rank_list_vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //不处理
            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        rank_list_bronze.setChecked(true);
                        break;
                    case 1:
                        rank_list_silver.setChecked(true);
                        break;
                    case 2:
                        rank_list_gold.setChecked(true);
                        break;
                    case 3:
                        rank_list_platinum.setChecked(true);
                        break;
                    case 4:
                        rank_list_diamond.setChecked(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                //不处理
            }
        });

        if (isFromHome) {//本月排行榜数据
            int thisLevel = getIntent().getIntExtra("thisLevel", 1);
            if (0 == thisLevel) {
                rank_list_vp.setCurrentItem(0);
                getRankListLevelData(1, 1, true);
            } else {
                rank_list_vp.setCurrentItem(thisLevel - 1);
                getRankListLevelData(thisLevel, 1, true);//不加的话，不知为啥取的是上次的缓存
            }
            switch (thisLevel) {
                case 1:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_copper_level);
                    }
                    break;
                case 2:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_silver_level);
                    }
                    break;
                case 3:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_yellow_golden_level);
                    }
                    break;
                case 4:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_bo_golden_level);
                    }
                    break;
                case 5:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_diamond_level);
                    }
                    break;
                default:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_copper_level);
                    }
                    break;

            }
        } else {//上月排行榜数据
            int beforeLevel = getIntent().getIntExtra("beforeLevel", 1);
            if (0 == beforeLevel) {
                rank_list_vp.setCurrentItem(0);
                getRankListLevelData(1, 1, true);
            } else {
                rank_list_vp.setCurrentItem(beforeLevel - 1);
                getRankListLevelData(beforeLevel, 1, true);//不加的话，不知为啥取的是上次的缓存
            }

            switch (beforeLevel) {
                case 1:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_copper_level);
                    }
                    break;
                case 2:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_silver_level);
                    }
                    break;
                case 3:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_yellow_golden_level);
                    }
                    break;
                case 4:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_bo_golden_level);
                    }
                    break;
                case 5:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_diamond_level);
                    }
                    break;
                default:
                    if (rank_list_avatar_bg != null) {
                        rank_list_avatar_bg.setBackgroundResource(R.drawable.rank_list_copper_level);
                    }
                    break;
            }
        }
    }

    /**
     * 初始化青铜fragment
     */
    private void initBronzeFragment() {
        bronzeFragment = new RankFragment().setFragmentCallback(new RankFragment.RankListCallback() {
            @Override
            public void onLoadMore() {
                if (1 == level) {
                    if (pageNoBronze < nextPage) {
                        bronzeFragment.setLoadingData();
                        pageNoBronze++;
                        getRankListLevelData(level, pageNoBronze, true);
                    } else {
                        if (bronzeFragment != null) {
                            bronzeFragment.setLoadMoreNothing();
                        }
                    }
                }
            }

            @Override
            public void clickPK(int position) {
                if (position < bronzeRankList.size()) {
                    pkPosition = position;
                    int targetUid = bronzeRankList.get(position).getUid();
                    getRankListPkData(targetUid);
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putInt("type", 1);
        bronzeFragment.setArguments(bundle);
    }

    /**
     * 初始化白银fragment
     */
    private void initSilverFragment() {
        silverFragment = new RankFragment().setFragmentCallback(new RankFragment.RankListCallback() {
            @Override
            public void onLoadMore() {
                if (2 == level) {
                    if (pageNoSilver < nextPage) {
                        silverFragment.setLoadingData();
                        pageNoSilver++;
                        getRankListLevelData(level, pageNoSilver, true);
                    } else {
                        if (silverFragment != null) {
                            silverFragment.setLoadMoreNothing();
                        }
                    }
                }
            }

            @Override
            public void clickPK(int position) {
                if (position < silverRankList.size()) {
                    pkPosition = position;
                    int targetUid = silverRankList.get(position).getUid();
                    getRankListPkData(targetUid);
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putInt("type", 2);
        silverFragment.setArguments(bundle);
    }

    /**
     * 初始化黄金fragment
     */
    private void initGoldFragment() {
        goldFragment = new RankFragment().setFragmentCallback(new RankFragment.RankListCallback() {
            @Override
            public void onLoadMore() {
                if (3 == level) {
                    if (pageNoGold < nextPage) {
                        goldFragment.setLoadingData();
                        pageNoGold++;
                        getRankListLevelData(level, pageNoGold, true);
                    } else {
                        if (goldFragment != null) {
                            goldFragment.setLoadMoreNothing();
                        }
                    }
                }
            }

            @Override
            public void clickPK(int position) {
                if (position < goldRankList.size()) {
                    pkPosition = position;
                    int targetUid = goldRankList.get(position).getUid();
                    getRankListPkData(targetUid);
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putInt("type", 3);
        goldFragment.setArguments(bundle);
    }

    /**
     * 初始化铂金fragment
     */
    private void initPlatinumFragment() {
        platinumFragment = new RankFragment().setFragmentCallback(new RankFragment.RankListCallback() {
            @Override
            public void onLoadMore() {
                if (4 == level) {
                    if (pageNoPlatinum < nextPage) {
                        platinumFragment.setLoadingData();
                        pageNoPlatinum++;
                        getRankListLevelData(level, pageNoPlatinum, true);
                    } else {
                        if (platinumFragment != null) {
                            platinumFragment.setLoadMoreNothing();
                        }
                    }
                }
            }

            @Override
            public void clickPK(int position) {
                if (position < platinumRankList.size()) {
                    pkPosition = position;
                    int targetUid = platinumRankList.get(position).getUid();
                    getRankListPkData(targetUid);
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putInt("type", 4);
        platinumFragment.setArguments(bundle);
    }

    /**
     * 初始化钻石fragment
     */
    private void initDiamondFragment() {
        diamondFragment = new RankFragment().setFragmentCallback(new RankFragment.RankListCallback() {
            @Override
            public void onLoadMore() {
                if (5 == level) {
                    if (pageNoDiamond < nextPage) {
                        diamondFragment.setLoadingData();
                        pageNoDiamond++;
                        getRankListLevelData(level, pageNoDiamond, true);
                    } else {
                        if (diamondFragment != null) {
                            diamondFragment.setLoadMoreNothing();
                        }
                    }
                }
            }

            @Override
            public void clickPK(int position) {
                if (position < diamondRankList.size()) {
                    pkPosition = position;
                    int targetUid = diamondRankList.get(position).getUid();
                    getRankListPkData(targetUid);
                }
            }
        });
        Bundle bundle = new Bundle();
        bundle.putInt("type", 5);
        diamondFragment.setArguments(bundle);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_SPORT + 36://获取用户月运动排行榜数据
                processMonthRankList(result);
                break;
            case Config.MODULE_SPORT + 38://获取各个赛段的排名数据  青铜
            case Config.MODULE_SPORT + 39://获取各个赛段的排名数据  白银
            case Config.MODULE_SPORT + 40://获取各个赛段的排名数据  黄金
            case Config.MODULE_SPORT + 41://获取各个赛段的排名数据  铂金
            case Config.MODULE_SPORT + 42://获取各个赛段的排名数据  钻石

            case Config.MODULE_SPORT + 43://获取各个赛段的排名数据  青铜 上月
            case Config.MODULE_SPORT + 44://获取各个赛段的排名数据  白银 上月
            case Config.MODULE_SPORT + 45://获取各个赛段的排名数据  黄金 上月
            case Config.MODULE_SPORT + 46://获取各个赛段的排名数据  铂金 上月
            case Config.MODULE_SPORT + 47://获取各个赛段的排名数据  钻石 上月
                setRankList(result);
                break;

            case Config.MODULE_SPORT + 37://获取两两pk信息
                setPkDataResult(result);
                break;
        }
    }


    /**
     * 设置排行榜数据显示
     */
    private void setRankList(String result) {
        RankListLevelData rankListLevelData = JsonHelper.getObject(result, RankListLevelData.class);
        if (rankListLevelData != null) {
            RankListLevelData.PageBean page = rankListLevelData.getPage();
            if (page != null) {
                if (page.getFilter() != null) {
                    level = page.getFilter().getLevel();
                } else {
                    Logger.e(Logger.DEBUG_TAG, "RankListActivity-->setRankList page.getFilter() is null!");
                }
                int pageNo = page.getPageNo();
                nextPage = page.getNextPage();
                List<RankListLevelData.PageBean.ResultBean> resultBeanList = page.getResult();
                switch (level) {
                    case 1:
                        if (rank_list_bronze.isChecked()) {
                            if (pageNo < 2)
                                bronzeRankList.clear();
                            bronzeRankList.addAll(resultBeanList);
                            bronzeFragment.setResultBeanList(bronzeRankList);

                            if (pageNoBronze == nextPage) {
                                bronzeFragment.setLoadMoreNothing();
                            } else {
                                bronzeFragment.setRecyclerViewFooterEmpty();
                            }
                            if (resultBeanList.size() == 0) {
                                bronzeFragment.setEmptyViewOrNot();
                            }
                        }
                        break;
                    case 2:
                        if (rank_list_silver.isChecked()) {
                            if (pageNo < 2)
                                silverRankList.clear();
                            silverRankList.addAll(resultBeanList);
                            silverFragment.setResultBeanList(silverRankList);

                            if (pageNoSilver == nextPage) {
                                silverFragment.setLoadMoreNothing();
                            } else {
                                silverFragment.setRecyclerViewFooterEmpty();
                            }
                            if (resultBeanList.size() == 0) {
                                silverFragment.setEmptyViewOrNot();
                            }
                        }
                        break;
                    case 3:
                        if (rank_list_gold.isChecked()) {
                            if (pageNo < 2)
                                goldRankList.clear();
                            goldRankList.addAll(resultBeanList);
                            goldFragment.setResultBeanList(goldRankList);

                            if (pageNoGold == nextPage) {
                                goldFragment.setLoadMoreNothing();
                            } else {
                                goldFragment.setRecyclerViewFooterEmpty();
                            }
                            if (resultBeanList.size() == 0) {
                                goldFragment.setEmptyViewOrNot();
                            }
                        }
                        break;
                    case 4:
                        if (rank_list_platinum.isChecked()) {
                            if (pageNo < 2)
                                platinumRankList.clear();
                            platinumRankList.addAll(resultBeanList);
                            platinumFragment.setResultBeanList(platinumRankList);

                            if (pageNoPlatinum == nextPage) {
                                platinumFragment.setLoadMoreNothing();
                            } else {
                                platinumFragment.setRecyclerViewFooterEmpty();
                            }
                            if (resultBeanList.size() == 0) {
                                platinumFragment.setEmptyViewOrNot();
                            }
                        }
                        break;
                    case 5:
                        if (rank_list_diamond.isChecked()) {
                            if (pageNo < 2)
                                diamondRankList.clear();

                            diamondRankList.addAll(resultBeanList);
                            diamondFragment.setResultBeanList(diamondRankList);

                            if (pageNoDiamond == nextPage) {
                                diamondFragment.setLoadMoreNothing();
                            } else {
                                diamondFragment.setRecyclerViewFooterEmpty();
                            }

                            if (resultBeanList.size() == 0) {
                                diamondFragment.setEmptyViewOrNot();
                            }
                        }
                        break;
                }
                hideLoadingDialog();
            }
        }
    }

    /**
     * 设置用户月运动排行榜数据
     */
    private void processMonthRankList(String result) {
        RankListData rankListData = JsonHelper.getObject(result, RankListData.class);
        hideLoadingDialog();
        if (rankListData != null) {
            //当月排名
            RankListData.MonthRank month = rankListData.getMonth();
            thisRank = 0;
            if (month != null) {
                thisRank = month.getRank();
                monthLevel = month.getLevel();
                if (0 != monthLevel) {
                    setRankText(monthLevel);
                }

                distance = month.getSumDistanceValid();
                if (isFromHome) {
                    if (rank_list_distance_tv != null) {//本月有效里程
                        rank_list_distance_tv.setText(FormatUtil.formatDistance(distance) + "km");
                    }
                } else {
                    if (rank_list_distance_tv != null) {//上月有效里程
                        rank_list_distance_tv.setText(FormatUtil.formatDistance(sumDistanceValidBefore) + "km");
                    }
                }

                if (rank_list_this_level_score_name != null) {//排名
                    if (0 != thisRank) {
                        rank_list_this_level_score_name.setText(String.format(getString(R.string.rank_list_score_level), String.valueOf(thisRank)));
                    } else {
                        rank_list_this_level_score_name.setText("10w+");
                    }
                }

                String statTime = month.getStatTime();
                if (statTime != null) {
                    try {
                        int year = Integer.parseInt(statTime.substring(0, 4));
                        int currentMonth = Integer.parseInt(statTime.substring(5, 7));
                        thisMonth = currentMonth;
                        if (0 == (currentMonth - 1)) {
                            lastMonthTimes = FormatUtil.dateToStamp(FormatUtil.getLastDayOfMonth(year - 1, 12));
                        } else {
                            lastMonthTimes = FormatUtil.dateToStamp(FormatUtil.getLastDayOfMonth(year, currentMonth - 1));
                        }
//                        Logger.e(Logger.DEBUG_TAG, "year:" + year + " last month:" + (currentMonth - 1) + " lastMonthTimes:" + lastMonthTimes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {//本月排行数据为空
                if (rank_list_this_level_score_name != null) {
                    rank_list_this_level_score_name.setText("10w+");
                }
                Calendar calendar = Calendar.getInstance();
                thisMonth = calendar.get(Calendar.MONTH) + 1;
                if (isFromHome) {
                    if (rank_list_distance_tv != null) {
                        rank_list_distance_tv.setText(FormatUtil.formatDistance(distance) + "km");
                    }
                    setRankText(monthLevel);
                } else {
                    if (rank_list_distance_tv != null) {
                        rank_list_distance_tv.setText(FormatUtil.formatDistance(sumDistanceValidBefore) + "km");
                    }
                }
            }

            //前个月排名数据
            RankListData.MonthRank beforeMonth = rankListData.getBeforeMonth();
            if (beforeMonth != null) {
                sumDistanceValidBefore = beforeMonth.getSumDistanceValid();
                rankBefore = beforeMonth.getRank();
                levelBefore = beforeMonth.getLevel();
                if (monthLevel > levelBefore) {//本月等级比上个月有提升
                    if (rank_list_this_score_status_iv != null) {
                        rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                        rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_rise);
                    }
                } else if (monthLevel < levelBefore) {//本月等级比上个月有下降
                    if (rank_list_this_score_status_iv != null) {
                        rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                        rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_fall);
                    }
                } else {//本月等级与上个月等级一样
                    if (0 == rankBefore) {
                        if (0 != thisRank) {//本月排名上升
                            if (rank_list_this_score_status_iv != null) {
                                rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                                rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_rise);
                            }
                        } else {
                            if (rank_list_this_score_status_iv != null) {
                                rank_list_this_score_status_iv.setVisibility(View.GONE);
                            }
                        }
                    } else {
                        if (0 == thisRank) {//本月排名下降
                            if (rank_list_this_score_status_iv != null) {
                                rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                                rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_fall);
                            }
                        } else {//本月和上月都有排名
                            if (thisRank > rankBefore) {//本月排名下降
                                if (rank_list_this_score_status_iv != null) {
                                    rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                                    rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_fall);
                                }
                            } else if (thisRank == rankBefore) {
                                if (rank_list_this_score_status_iv != null) {
                                    rank_list_this_score_status_iv.setVisibility(View.GONE);
                                }
                            } else {//本月排名上升
                                if (rank_list_this_score_status_iv != null) {
                                    rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                                    rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_rise);
                                }
                            }
                        }
                    }
                }

                String statTime = beforeMonth.getStatTime();
                if (statTime != null) {
                    try {
                        int year = Integer.parseInt(statTime.substring(0, 4));
                        monthLast = Integer.parseInt(statTime.substring(5, 7));
                        if (12 == monthLast) {
                            thisMonth = 1;
                        } else {
                            thisMonth = monthLast + 1;
                        }
                        lastMonthTimes = FormatUtil.dateToStamp(FormatUtil.getLastDayOfMonth(year, monthLast));
//                        Logger.e(Logger.DEBUG_TAG, "year:" + year + " monthLast:" + monthLast + " lastMonthTimes:" + lastMonthTimes);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }

                if (0 == rankBefore) {//上月排名
                    if (rank_list_last_level_score_name != null) {
                        rank_list_last_level_score_name.setText("10w+");
                    }
                } else if (0 != rankBefore) {
                    if (rank_list_last_level_score_name != null) {
                        rank_list_last_level_score_name.setText(String.format(getString(R.string.rank_list_score_level), String.valueOf(rankBefore)));
                    }
                }
                setLastRankText(levelBefore);
            } else {//上月排行数据为空
                if (0 != thisRank) {
                    if (rank_list_this_score_status_iv != null) {
                        rank_list_this_score_status_iv.setVisibility(View.VISIBLE);
                        rank_list_this_score_status_iv.setBackgroundResource(R.drawable.rank_list_rise);
                    }
                } else {
                    if (rank_list_this_score_status_iv != null) {
                        rank_list_this_score_status_iv.setVisibility(View.GONE);
                    }
                }

                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_bronze_state));
                }

                if (rank_list_last_level_score_name != null) {
                    rank_list_last_level_score_name.setText("10w+");
                }
                try {
                    String lastDayOfLastMonth = FormatUtil.getLastDayOfLastMonth();
                    lastMonthTimes = FormatUtil.dateToStamp(lastDayOfLastMonth);
                    Logger.i(Logger.DEBUG_TAG, "lastDayOfLastMonth:" + lastDayOfLastMonth + ",lastMonthTimes:" + lastMonthTimes);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Calendar calendar = Calendar.getInstance();
                monthLast = calendar.get(Calendar.MONTH);
                if (monthLast == 0) {
                    monthLast = 12;
                }
            }
        }
    }

    /**
     * 设置两两PK信息
     */
    private void setPkDataResult(String result) {
        RankListPkData pkData = JsonHelper.getObject(result, RankListPkData.class);
        hideLoadingDialog();
        if (pkData != null) {
            RankListPkData.PkData targetStat = pkData.getTargetStat();
            if (targetStat != null) {
                level = targetStat.getLevel();
                switch (level) {
                    case 1:
                        if (bronzeRankList.size() == 0 || pkPosition >= bronzeRankList.size()) {
                            return;
                        }
                        bronzeRankList.get(pkPosition).setPkData(pkData);
                        if (bronzeFragment != null) {
                            bronzeFragment.setResultBeanList(bronzeRankList);
                        }
                        break;

                    case 2:
                        if (silverRankList.size() == 0 || pkPosition >= silverRankList.size()) {
                            return;
                        }
                        silverRankList.get(pkPosition).setPkData(pkData);
                        if (silverFragment != null) {
                            silverFragment.setResultBeanList(silverRankList);
                        }
                        break;

                    case 3:
                        if (goldRankList.size() == 0 || pkPosition >= goldRankList.size()) {
                            return;
                        }
                        goldRankList.get(pkPosition).setPkData(pkData);
                        if (goldFragment != null) {
                            goldFragment.setResultBeanList(goldRankList);
                        }
                        break;

                    case 4:
                        if (platinumRankList.size() == 0 || pkPosition >= platinumRankList.size()) {
                            return;
                        }
                        platinumRankList.get(pkPosition).setPkData(pkData);
                        if (platinumFragment != null) {
                            platinumFragment.setResultBeanList(platinumRankList);
                        }
                        break;

                    case 5:
                        if (diamondRankList.size() == 0 || pkPosition >= diamondRankList.size()) {
                            return;
                        }
                        diamondRankList.get(pkPosition).setPkData(pkData);
                        if (diamondFragment != null) {
                            diamondFragment.setResultBeanList(diamondRankList);
                        }
                        break;
                }
            }

        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_SPORT + 36://获取用户月运动排行榜数据
            case Config.MODULE_SPORT + 37://获取两两pk信息
                hideLoadingDialog();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem menuRankList = menu.add(0, Menu.FIRST + 7, 7, R.string.this_month_rank_list).setIcon(R.drawable.rank_list_note_icon);
        menuRankList.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menuRankList.setActionView(R.layout.menu_rank_list);
        ImageView rank_list_history = (ImageView) menuRankList.getActionView().findViewById(R.id.rank_list_history);
        ImageView rank_list_note = (ImageView) menuRankList.getActionView().findViewById(R.id.rank_list_note);

        if (showLastMonthRank) {
            rank_list_history.setVisibility(View.VISIBLE);
        } else {
            rank_list_history.setVisibility(View.GONE);
        }
        rank_list_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRankListHistory();
            }
        });

        rank_list_note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRankListNote();
            }
        });
        return true;
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        rank_list_vp.setCurrentItem(mCurrentFragmentIndex);
    }

    /**
     * 切换到排行榜说明界面
     */
    private void startRankListNote() {
        Intent intent = new Intent();
        intent.setClass(this, RankListRuleActivity.class);
        startActivity(intent);
    }

    /**
     * 切换到排行榜历史界面
     */
    private void startRankListHistory() {
        Intent intent = new Intent();
        try {
            intent.putExtra("isFromHome", false);
            intent.putExtra("lastMonthTimeStamp", lastMonthTimes);
            intent.putExtra("sumDistanceValid_before", sumDistanceValidBefore);
            intent.putExtra("beforeLevel", levelBefore);
            intent.setClass(this, RankListActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 根据上月等级设置相应的等级文字
     */
    private void setLastRankText(int levelBefore) {
        switch (levelBefore) {
            case 1:
                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_bronze_state));
                }
                break;
            case 2:
                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_silver_state));
                }
                break;
            case 3:
                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_gold_state));
                }
                break;
            case 4:
                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_platinum_state));
                }
                break;
            case 5:
                if (rank_list_last_level_section_name != null) {
                    rank_list_last_level_section_name.setText(getResources().getString(R.string.rank_list_diamond_state));
                }
                break;
        }
    }

    /**
     * 根据本月当前等级设置相应的等级文字
     */
    private void setRankText(int monthLevel) {
        switch (monthLevel) {
            case 2:
                if (rank_list_this_level_section_name != null) {
                    rank_list_this_level_section_name.setText(getResources().getString(R.string.rank_list_silver_state));
                }
                break;
            case 3:
                if (rank_list_this_level_section_name != null) {
                    rank_list_this_level_section_name.setText(getResources().getString(R.string.rank_list_gold_state));
                }
                break;
            case 4:
                if (rank_list_this_level_section_name != null) {
                    rank_list_this_level_section_name.setText(getResources().getString(R.string.rank_list_platinum_state));
                }
                break;
            case 5:
                if (rank_list_this_level_section_name != null) {
                    rank_list_this_level_section_name.setText(getResources().getString(R.string.rank_list_diamond_state));
                }
                break;
            case 1:
            default://默认为青铜
                if (rank_list_this_level_section_name != null) {
                    rank_list_this_level_section_name.setText(getResources().getString(R.string.rank_list_bronze_state));
                }
                break;
        }
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.rank_list_share_iv:
                Intent intent = new Intent(this, RankListShareActivity.class);
                if (isFromHome) {
                    intent.putExtra("month", thisMonth);
                    intent.putExtra("level", monthLevel);
                    intent.putExtra("rank", thisRank);
                    intent.putExtra("distance", distance);
                    Logger.d(Logger.DATA_FLOW_TAG, "thisMonth:" + thisMonth + " monthLevel:" + monthLevel);
                } else {
                    intent.putExtra("month", monthLast);
                    intent.putExtra("level", levelBefore);
                    intent.putExtra("rank", rankBefore);
                    intent.putExtra("distance", sumDistanceValidBefore);
                    Logger.d(Logger.DATA_FLOW_TAG, "monthLast:" + monthLast + " levelBefore:" + levelBefore);
                }
                startActivity(intent);
                break;
        }
    }

    /**
     * 获取排行榜数据
     *
     * @param level          排行榜级别
     * @param pageNo         分页页码
     * @param ignorePreCache 数据请求是否忽略之前的缓存结果
     */
    private void getRankListLevelData(int level, int pageNo, boolean ignorePreCache) {
        switch (level) {
            case 1:
                if (isFromHome) {
                    int requestId = SportDataManager.getInstance().getBronzeRankListLevelData(UserDataManager.getUid(), System.currentTimeMillis(), pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                } else {
                    int requestId = SportDataManager.getInstance().getLastBronzeRankListLevelData(UserDataManager.getUid(), lastMonthTimeStamp, pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                }
                break;
            case 2:
                if (isFromHome) {
                    int requestId = SportDataManager.getInstance().getSilverRankListLevelData(UserDataManager.getUid(), System.currentTimeMillis(), pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                } else {
                    int requestId = SportDataManager.getInstance().getLastSilverRankListLevelData(UserDataManager.getUid(), lastMonthTimeStamp, pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                }
                break;
            case 3:
                if (isFromHome) {
                    int requestId = SportDataManager.getInstance().getGoldRankListLevelData(UserDataManager.getUid(), System.currentTimeMillis(), pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                } else {
                    int requestId = SportDataManager.getInstance().getLastGoldRankListLevelData(UserDataManager.getUid(), lastMonthTimeStamp, pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                }
                break;
            case 4:
                if (isFromHome) {
                    int requestId = SportDataManager.getInstance().getPlatinumRankListLevelData(UserDataManager.getUid(), System.currentTimeMillis(), pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                } else {
                    int requestId = SportDataManager.getInstance().getLastPlatinumRankListLevelData(UserDataManager.getUid(), lastMonthTimeStamp, pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                }
                break;
            case 5:
                if (isFromHome) {
                    int requestId = SportDataManager.getInstance().getDiamondRankListLevelData(UserDataManager.getUid(), System.currentTimeMillis(), pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                } else {
                    int requestId = SportDataManager.getInstance().getLastDiamondRankListLevelData(UserDataManager.getUid(), lastMonthTimeStamp, pageNo, ignorePreCache);
                    registerDataReqStatusListener(requestId);
                }
                break;
        }
    }

    /**
     * 获取用户排名数据
     */
    private void getRankListData() {
        if (isFromHome) {
            showLastMonthRank = true;
            int requestId = SportDataManager.getInstance().getRankListData(UserDataManager.getUid(), System.currentTimeMillis(), false);
            registerDataReqStatusListener(requestId);
        } else {
            showLastMonthRank = false;
            int requestId = SportDataManager.getInstance().getRankListData(UserDataManager.getUid(), System.currentTimeMillis(), false);
            registerDataReqStatusListener(requestId);
        }

    }

    /**
     * 获取用户PK对比数据
     */
    private void getRankListPkData(int targetUid) {
        if (isFromHome) {
            int requestId = SportDataManager.getInstance().getRankListPKData(UserDataManager.getUid(), System.currentTimeMillis(), targetUid, true);
            registerDataReqStatusListener(requestId);
        } else {
            int requestId = SportDataManager.getInstance().getRankListPKData(UserDataManager.getUid(), lastMonthTimeStamp, targetUid, true);
            registerDataReqStatusListener(requestId);
        }

        //  showLoadingDialog(R.string.busying);
    }

}
