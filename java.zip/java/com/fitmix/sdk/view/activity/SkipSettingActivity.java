package com.fitmix.sdk.view.activity;


import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.common.bluetooth.skip.SkipBluetoothService;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.SkipService;
import com.fitmix.sdk.view.adapter.RunSettingImageAdapter;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.SkipSettingBaseFragment;
import com.fitmix.sdk.view.fragment.SkipSettingCalorieFragment;
import com.fitmix.sdk.view.fragment.SkipSettingFreeFragment;
import com.fitmix.sdk.view.fragment.SkipSettingNumberFragment;
import com.fitmix.sdk.view.fragment.SkipSettingTaskFragment;
import com.fitmix.sdk.view.fragment.SkipSettingTimeFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.spinnerwheel.AbstractWheel;
import com.fitmix.sdk.view.widget.spinnerwheel.OnWheelChangedListener;
import com.fitmix.sdk.view.widget.spinnerwheel.WheelHorizontalView;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class SkipSettingActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener {
    /**
     * 编辑个人信息请求
     */
    private final int EDIT_PROFILE = 1;
    /**
     * 设置蓝牙连接
     */
    private final int SET_SKIP_CONNECT = 2;

    private WheelHorizontalView wheel_run_type;
    private int[] imageResIds = {R.drawable.skip_setting_free, R.drawable.run_setting_time, R.drawable.skip_setting_number, R.drawable.run_setting_calorie, R.drawable.skip_setting_task};

    private int[] runTypeStrResIds = {R.string.activity_skip_setting_skip_type_free,
            R.string.activity_skip_setting_skip_type_time, R.string.activity_skip_setting_skip_type_number,
            R.string.activity_skip_setting_skip_type_calorie, R.string.activity_skip_setting_skip_type_task};

    private TextView tv_run_type;
    private CheckBox ckb_music;
    private CheckBox ckb_siri;
    private int taskType;
    private boolean toggleByMan;//是否由用户触发Check事件
    private SkipSettingBaseFragment currentFragment;
    private SkipSettingFreeFragment skipSettingFreeFragment;
    private String musicString;
    private Button btn_start;
    /**
     * 最近14条跑步记录
     */
    private List<SkipLogInfo> skipLogInfoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skip_setting);
        setPageName("SkipSettingActivity");
        Intent intent = getIntent();
        if (intent != null) musicString = intent.getStringExtra("musicInfo");
        initToolbar();

        if (savedInstanceState == null) {
            skipSettingFreeFragment = new SkipSettingFreeFragment();
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                    .replace(R.id.mainContainer, skipSettingFreeFragment, "runFree").commit();
        }
        skipLogInfoList = new ArrayList<>();
        loadSkipRecords();
        initViews();
        connectToSkipService();

        //Android 6.0申请权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            getPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.BODY_SENSORS,
                    Manifest.permission.ACCESS_FINE_LOCATION});
        }
    }

    /**
     * 从数据库加载最近14条跑步记录,根据{@link SkipSettingBaseFragment#refreshBarChart 方法中的LINES_IN_CHART而定}
     */
    private void loadSkipRecords() {
        int uid = UserDataManager.getUid();
        SportRecordsHelper.asyncGetLimitSkipRecords(this, uid, 14, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SportRecord> sportRecordList = (List<SportRecord>) operation.getResult();
                if (sportRecordList != null && sportRecordList.size() > 0) {
//                    runLogInfoList = new ArrayList<>();
                    for (SportRecord sportRecord : sportRecordList) {
                        SkipLogInfo skipLogInfo = new SkipLogInfo();
                        skipLogInfo.setUid(sportRecord.getUid());//用户ID
                        skipLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                        skipLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                        skipLogInfo.setType(sportRecord.getType());//运动类型 0或1表示跑步2表示跳绳
                        skipLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                        skipLogInfo.setSkipNumber(sportRecord.getStep());//跳跃个数
                        skipLogInfo.setSkipTime(sportRecord.getRunTime());//运动时长,单位毫秒
                        skipLogInfo.setBpm(sportRecord.getBpm());//平均跳频(每分钟个数)
                        skipLogInfo.setCalorie(sportRecord.getCalorie());//卡路里
                        skipLogInfoList.add(skipLogInfo);
                    }

                    if (skipLogInfoList.get(0) != null) {
                        final int number = skipLogInfoList.get(0).getSkipNumber();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Fragment fragment = getSupportFragmentManager().findFragmentByTag("runFree");
                                if (fragment != null && fragment.isVisible()) {
                                    ((SkipSettingFreeFragment) fragment).setLastSkipNumber(number);
                                }
                            }
                        });
                    }
                }
            }
        });
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        tv_run_type = (TextView) findViewById(R.id.tv_run_type);
        wheel_run_type = (WheelHorizontalView) findViewById(R.id.wheel_run_type);
        RunSettingImageAdapter adapter = new RunSettingImageAdapter(this, imageResIds);

        wheel_run_type.setViewAdapter(adapter);
        wheel_run_type.addChangingListener(new OnWheelChangedListener() {
            @Override
            public void onChanged(AbstractWheel wheel, int oldValue, int newValue) {
                tv_run_type.setText(runTypeStrResIds[newValue]);
                switch (newValue) {
                    case 0://自由跳绳
                        currentFragment = null;
                        taskType = SkipService.TASK_TYPE_FREE;
                        SkipSettingFreeFragment skipSettingFreeFragment = new SkipSettingFreeFragment();
                        if (ftCanCommit) {
                            getSupportFragmentManager().beginTransaction()
                                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                                    .replace(R.id.mainContainer, skipSettingFreeFragment, "skipFree").commit();
                        }
                        if (skipLogInfoList != null && skipLogInfoList.size() > 0) {
                            if (skipLogInfoList.get(0) != null) {
                                int number = skipLogInfoList.get(0).getSkipNumber();
                                skipSettingFreeFragment.setLastSkipNumber(number);
                            }
                        }
                        break;
                    case 1://计时跳绳
                        taskType = SkipService.TASK_TYPE_TIME;
                        currentFragment = new SkipSettingTimeFragment();
                        if (ftCanCommit) {
                            getSupportFragmentManager().beginTransaction()
                                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                                    .replace(R.id.mainContainer, currentFragment, "skipTime").commit();
                        }
                        currentFragment.setSkipLogInfoList(skipLogInfoList);
                        break;
                    case 2://计数跳绳
                        taskType = SkipService.TASK_TYPE_NUMBER;
                        currentFragment = new SkipSettingNumberFragment();
                        if (ftCanCommit) {
                            getSupportFragmentManager().beginTransaction()
                                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                                    .replace(R.id.mainContainer, currentFragment, "skipNumber").commit();
                        }
                        currentFragment.setSkipLogInfoList(skipLogInfoList);
                        break;
                    case 3: //卡路里跳绳
                        taskType = SkipService.TASK_TYPE_CALORIE;
                        currentFragment = new SkipSettingCalorieFragment();
                        if (ftCanCommit) {
                            getSupportFragmentManager().beginTransaction()
                                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                                    .replace(R.id.mainContainer, currentFragment, "skipCalorie").commit();
                        }
                        currentFragment.setSkipLogInfoList(skipLogInfoList);
                        break;
                    case 4://训练计划跳绳
                        taskType = SkipService.TASK_TYPE_SPORT_PLAN;
                        currentFragment = new SkipSettingTaskFragment();
                        if (ftCanCommit) {
                            getSupportFragmentManager().beginTransaction()
                                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                                    .replace(R.id.mainContainer, currentFragment, "skipTask").commit();
                        }
                        currentFragment.setSkipLogInfoList(skipLogInfoList);
                        break;
                }
            }
        });
        btn_start = (Button) findViewById(R.id.btn_start);
        btn_start.setOnTouchListener(touchListener);

        ckb_music = (CheckBox) findViewById(R.id.ckb_music);
        ckb_siri = (CheckBox) findViewById(R.id.ckb_siri);

        ckb_music.setOnCheckedChangeListener(this);
        ckb_siri.setOnCheckedChangeListener(this);
        //屏蔽check更改回调
        toggleByMan = false;
        boolean sportWithMusic = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_MUSIC, false);
        if (!sportWithMusic) {//音乐关
            ckb_music.setChecked(false);
            ckb_music.setText(getString(R.string.activity_run_setting_checkbox_music_off));
        } else {
            ckb_music.setChecked(true);
            ckb_music.setText(getString(R.string.activity_run_setting_checkbox_music_on));
        }
        boolean sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
        if (sportWithVoice) {//语音播报
            ckb_siri.setChecked(true);
            ckb_siri.setText(getString(R.string.activity_run_setting_checkbox_siri_on));
        } else {
            ckb_siri.setChecked(false);
            ckb_siri.setText(getString(R.string.activity_run_setting_checkbox_siri_off));
        }

        toggleByMan = true;
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    private final View.OnTouchListener touchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Button button = (Button) v;
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                button.setAlpha(0.7f);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                button.setAlpha(1.0f);
            } else if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                button.setAlpha(1.0f);
            }

            return false;
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnectToSkipBluetoothService();
        wheel_run_type = null;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.ckb_music://音乐
                if (toggleByMan) {
                    if (isChecked) {
                        ckb_music.setText(getString(R.string.activity_run_setting_checkbox_music_on));
                        showAppMessage(R.string.activity_run_setting_music_on, AppMsg.STYLE_INFO);
                    } else {
                        ckb_music.setText(getString(R.string.activity_run_setting_checkbox_music_off));
                        showAppMessage(R.string.activity_run_setting_music_off, AppMsg.STYLE_INFO);
                    }
                }
                break;
            case R.id.ckb_siri://语音提示
                if (toggleByMan) {
                    if (isChecked) {
                        ckb_siri.setText(getString(R.string.activity_run_setting_checkbox_siri_on));
                        showAppMessage(R.string.activity_run_setting_siri_on, AppMsg.STYLE_INFO);
                    } else {
                        ckb_siri.setText(getString(R.string.activity_run_setting_checkbox_siri_off));
                        showAppMessage(R.string.activity_run_setting_siri_off, AppMsg.STYLE_INFO);
                    }
                }
                break;
        }
    }

    /**
     * 开始跳绳
     */
    private void gotoSkipMain() {
        if (ckb_music != null) {
            SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_MUSIC, ckb_music.isChecked());
        }
        if (ckb_siri != null) {
            SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_VOICE, ckb_siri.isChecked());
        }

        Intent intent = new Intent(SkipSettingActivity.this, SkipMainActivity.class);
        if ((!TextUtils.isEmpty(musicString)) && (ckb_music.isChecked())) {
            intent.putExtra("musicInfo", musicString);
        }
        if (currentFragment != null) {
            intent.putExtra("taskObject", currentFragment.getTaskObject());
            intent.putExtra("taskType", taskType);
        }
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
    }

    private void gotoEditProfile() {
        Intent intent = new Intent(SkipSettingActivity.this, EditProfileActivity.class);
        startActivityForResult(intent, EDIT_PROFILE);
        overridePendingTransition(0, 0);
    }

    private void gotoSetBluetoothConnect() {
        Intent intent = new Intent(SkipSettingActivity.this, PairSkipActivity.class);
        startActivityForResult(intent, SET_SKIP_CONNECT);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_start:
//                gotoSkipMain();
                if (getSkipConnectSate() != SkipBluetoothService.ConnectionState.SPP_CONNECTED) {
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.activity_skip_setting_skip_not_connect)
                            .positiveText(R.string.ok)
                            .negativeText(R.string.cancel)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            gotoSetBluetoothConnect();
                                            break;
                                        case NEGATIVE:
                                            break;
                                    }
                                }
                            }).show();
                } else {
                    int height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, 0);
                    int weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, 0);
                    if (height == 0 || weight == 0) {
                        new MaterialDialog.Builder(this)
                                .title(R.string.warning)
                                .content(R.string.edit_profile_tip)
                                .positiveText(R.string.ok)
                                .negativeText(R.string.cancel)
                                .onAny(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        dialog.dismiss();
                                        switch (which) {
                                            case POSITIVE:
                                                gotoEditProfile();
                                                break;
                                            case NEGATIVE:
                                                gotoSkipMain();
                                                break;
                                        }
                                    }
                                }).show();
                        return;
                    }
                    gotoSkipMain();
                    break;
                }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //定义退出动画
        finish();
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case EDIT_PROFILE:
                gotoSkipMain();
                break;
        }
    }

    //region ================================ 跳绳蓝牙服务相关 ================================

    private ServiceConnection serviceConnection;
    private SkipBluetoothService skipService;

    /**
     * 绑定跳绳蓝牙服务
     */
    private void connectToSkipService() {
        Intent intent = new Intent(this, SkipBluetoothService.class);
        serviceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(SkipBluetoothService.SERVICE_NAME))
                    return;
                skipService = ((SkipBluetoothService.LocalBinder) service).getService();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private int getSkipConnectSate() {
        int state = SkipBluetoothService.ConnectionState.STATE_INIT;
        if (skipService != null) {
            state = skipService.getConnectState().getSppState();
        }
        return state;
    }

    /**
     * 解绑跳绳蓝牙服务
     */
    private void disconnectToSkipBluetoothService() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
    }

    //endregion ================================ 跳绳蓝牙服务相关 ================================
}
