package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.A2dpServiceListener;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.ShineImageAdapter;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.spinnerwheel.AbstractWheel;
import com.fitmix.sdk.view.widget.spinnerwheel.OnWheelChangedListener;
import com.fitmix.sdk.view.widget.spinnerwheel.WheelHorizontalView;

import java.util.Timer;
import java.util.TimerTask;

/**
 * E11发光耳机
 */
public class PairHeadSetActivity extends BaseActivity {
//    private final static String SHINE_HEADSET_PREFIX = "SHINE";
    /**
     * 打开系统蓝牙设置界面
     */
    private final static int REQUEST_ENABLE_BLUETOOTH = 21;
    /**
     * 从系统相册中选择图片请求
     */
    private final static int REQUEST_CODE_CAPTURE_CAMERIA = 22;

    private TextView tv_connect_status, tv_connect_tip;

    private ImageView img_shine;
    private ImageView img_block_shine;
    private MyTimerTask mTimerTask;
    private Timer mTimer;

    private MyHandlerX mHandlerX;

    private BluetoothAdapter mBluetoothAdapter;

    private int a2dpState = BluetoothProfile.STATE_DISCONNECTED;
    private Animation anim_shine;

    private static final int MSG_REFRESH_STATUS = 111;
    private boolean bSendingCmd = false;
    private int iCmdSendIndex = -1;
    private final int array_color[] = {R.drawable.activity_pair_shine_block_red,
            R.drawable.activity_pair_shine_block_orange, R.drawable.activity_pair_shine_block_yellow,
            R.drawable.activity_pair_shine_block_green, R.drawable.activity_pair_shine_block_cyan,
            R.drawable.activity_pair_shine_block_blue, R.drawable.activity_pair_shine_block_purple,
            R.drawable.activity_pair_shine_block_white, R.drawable.activity_pair_shine_block_color};

    private final int array_color_shine[] = {R.drawable.activity_pair_shine_block_red_shine,
            R.drawable.activity_pair_shine_block_orange_shine, R.drawable.activity_pair_shine_block_yellow_shine,
            R.drawable.activity_pair_shine_block_green_shine, R.drawable.activity_pair_shine_block_cyan_shine,
            R.drawable.activity_pair_shine_block_blue_shine, R.drawable.activity_pair_shine_block_purple_shine,
            R.drawable.activity_pair_shine_block_white_shine, R.drawable.activity_pair_shine_block_color_shine};

    private final int array_line[] = {R.drawable.activity_pair_shine_red,
            R.drawable.activity_pair_shine_orange, R.drawable.activity_pair_shine_yellow,
            R.drawable.activity_pair_shine_green, R.drawable.activity_pair_shine_cyan,
            R.drawable.activity_pair_shine_blue, R.drawable.activity_pair_shine_purple,
            R.drawable.activity_pair_shine_white, 0};
    private int cmdIndex;
    private final String sDtmfCmd[] = {"#810#", "#830#", "#630#", "#770#",
            "#791#", "#783#", "#813#", "#888#", "#000#"};
    private WheelHorizontalView wheel_color_type;
    private ToneGenerator toneGenerator;

    private Bitmap mBmp;
    private int mTempTimeCount = 0;
    private final boolean bTestShineHeadTest = false;

    /**
     * 金币任务,使用我的设备配对一次任务是否完成
     */
    private boolean coinTaskPairBtFinished = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_headset);
        setPageName("PairHeadSetActivity");
        initToolbar();
        if (mHandlerX == null) {
            mHandlerX = new MyHandlerX(this);
        }
        initViews();

        if (getIntent() != null) {
            coinTaskPairBtFinished = getIntent().getBooleanExtra(EquipmentActivity.INTENT_EXTRA_PAIR_BT_TASK, true);
        }

    }

    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if (mBluetoothAdapter == null) {
            showAppMessage(R.string.bt_not_supported, AppMsg.STYLE_ALERT);
        }
        return mBluetoothAdapter;
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        anim_shine = AnimationUtils.loadAnimation(this,
                R.anim.image_shine);

        tv_connect_status = (TextView) findViewById(R.id.tv_connect_status);
        tv_connect_tip = (TextView) findViewById(R.id.tv_connect_tip);

        img_shine = (ImageView) findViewById(R.id.img_shine);
        img_block_shine = (ImageView) findViewById(R.id.img_block_shine);
        wheel_color_type = (WheelHorizontalView) findViewById(R.id.wheel_color_type);

        ShineImageAdapter adapter = new ShineImageAdapter(this, array_color);
        wheel_color_type.setViewAdapter(adapter);
        int iSelect = array_line.length / 2;
        wheel_color_type.setCurrentItem(iSelect);
        cmdIndex = iSelect;
        img_block_shine.setImageResource(array_color_shine[iSelect]);
        img_shine.setImageResource(array_line[iSelect]);
        wheel_color_type.addChangingListener(new OnWheelChangedListener() {
            @Override
            public void onChanged(AbstractWheel wheel, int oldValue, int newValue) {
                if ((newValue < 0) || (newValue >= array_line.length))
                    return;
                int color = array_line[newValue];
                if (newValue == array_line.length - 1)
                    color = array_line[(int) (Math.random() * array_line.length) % array_line.length];
                img_shine.setImageResource(color);
                img_block_shine.setImageResource(array_color_shine[newValue]);
                cmdIndex = newValue;
            }
        });
        img_shine.startAnimation(anim_shine);
        img_block_shine.startAnimation(anim_shine);

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 52://完成使用我的设备配对一次金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            coinTaskPairBtFinished = true;
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成任务

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 52://设备配对一次金币任务
                    if (bean.getCode() == 9002) {//该任务已完成
                        coinTaskPairBtFinished = true;
                        SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成
                    }
                    break;
            }
        }
    }

    private void releaseResource() {
        if (mBmp != null)
            mBmp.recycle();
        mBmp = null;

        if (mTimer != null) {
            mTimer.cancel();
            mTimer.purge();
        }
        mTimer = null;

        if (mTimerTask != null)
            mTimerTask.cancel();
        mTimerTask = null;
        if (toneGenerator != null)
            toneGenerator.release();
        toneGenerator = null;

    }

    @Override
    protected void onDestroy() {
        mHandlerX.setDiscardMsgFlag(true);
        releaseResource();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandlerX.removeMessages(MSG_REFRESH_STATUS);
    }

    /**
     * 根据蓝牙连接状态刷新界面
     */
    private void refreshA2dpState() {
        if (getBluetoothAdapter() == null) return;
        int state = getBluetoothAdapter()
                .getProfileConnectionState(BluetoothProfile.A2DP);
        switch (state) {
            case BluetoothProfile.STATE_CONNECTED:
                Drawable connectedDrawable = getResources().getDrawable(
                        R.drawable.checkbox_connect_bt_selected);
                connectedDrawable.setBounds(0, 0,
                        connectedDrawable.getMinimumWidth(),
                        connectedDrawable.getMinimumHeight());
                tv_connect_status.setText(R.string.activity_pair_headset_connected);
                tv_connect_status.setCompoundDrawables(null, null,
                        connectedDrawable, null);
                tv_connect_tip.setText(R.string.activity_pair_headset_disconnect_tip);
                if (a2dpState != state) {
                    showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                }

                if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                    finishPairBtCoinTask();
                }
                break;
            case BluetoothProfile.STATE_DISCONNECTED:
            case BluetoothProfile.STATE_DISCONNECTING:
                Drawable disconnectDrawable = getResources().getDrawable(
                        R.drawable.checkbox_connect_bt_normal);
                disconnectDrawable.setBounds(0, 0,
                        disconnectDrawable.getMinimumWidth(),
                        disconnectDrawable.getMinimumHeight());
                tv_connect_status.setText(R.string.shine_headset_disconnected);
                tv_connect_status.setCompoundDrawables(null, null,
                        disconnectDrawable, null);
                tv_connect_tip.setText(R.string.activity_pair_headset_connect_tip);

                if (a2dpState != state) {
                    showAppMessage(R.string.a2dp_disconnected, AppMsg.STYLE_INFO);
                }
                break;

            case BluetoothProfile.STATE_CONNECTING:
                if (a2dpState != state) {
                    showAppMessage(R.string.bt_connecting, AppMsg.STYLE_INFO);
                }
                break;
        }

        a2dpState = state;
    }

    private void refresh() {
        mHandlerX.sendEmptyMessageDelayed(MSG_REFRESH_STATUS, 1000);

        refreshA2dpState();
        if (bSendingCmd) selectColorByIndex(cmdIndex);
        if ((cmdIndex == array_line.length - 1) && ((System.currentTimeMillis() / 1000) % 2 == 0)) {
            int color = array_line[(int) (Math.random() * array_line.length) % array_line.length];
            img_shine.setImageResource(color);
        }
    }

    /**
     * 自定义
     */
    public static class MyHandlerX extends WeakHandler {

        public MyHandlerX(Activity activity) {
            super(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            PairHeadSetActivity activity = (PairHeadSetActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case A2dpServiceListener.MSG_A2DP_CONNECT_SUCCESS:
                    activity.showAppMessage("设备蓝牙连接成功", AppMsg.STYLE_INFO);
                    break;

                case A2dpServiceListener.MSG_A2DP_CONNECT_FAIL:
                    activity.showAppMessage("设备蓝牙连接失败", AppMsg.STYLE_ALERT);
                    break;

                case MSG_REFRESH_STATUS:
                    activity.refresh();
                    break;
            }
        }
    }

    private void switchToNextColor() {
        cmdIndex++;
        if (cmdIndex >= sDtmfCmd.length) cmdIndex = 0;

    }

    private void playSingleDtmf() {
        String sCmd = sDtmfCmd[cmdIndex];
        int iTempTimeCount = mTempTimeCount++;
        int iSendTime = 2;

        if (iCmdSendIndex == 0)
            iSendTime = 3;

        if (iTempTimeCount == 0) {

        } else if (iTempTimeCount < iSendTime) {
            return;
        } else if (iTempTimeCount == iSendTime) {
            if (toneGenerator != null) {
                toneGenerator.stopTone();
            }
            if (iCmdSendIndex >= sCmd.length()) {
                iCmdSendIndex = 0;
                stopDtmfTone();
                if (bTestShineHeadTest) switchToNextColor();
            }
            return;

        } else if (iTempTimeCount < (3 + iSendTime)) {
            return;
        } else {
            mTempTimeCount = 0;
            return;
        }

        char cTone = sCmd.charAt(iCmdSendIndex++);

        int iTone = ToneGenerator.TONE_DTMF_P;
        switch (cTone) {
            case '#':
                iTone = ToneGenerator.TONE_DTMF_P;
                break;
            case '0':
                iTone = ToneGenerator.TONE_DTMF_0;
                break;
            case '1':
                iTone = ToneGenerator.TONE_DTMF_1;
                break;
            case '2':
                iTone = ToneGenerator.TONE_DTMF_2;
                break;
            case '3':
                iTone = ToneGenerator.TONE_DTMF_3;
                break;
            case '4':
                iTone = ToneGenerator.TONE_DTMF_4;
                break;
            case '5':
                iTone = ToneGenerator.TONE_DTMF_5;
                break;
            case '6':
                iTone = ToneGenerator.TONE_DTMF_6;
                break;
            case '7':
                iTone = ToneGenerator.TONE_DTMF_7;
                break;
            case '8':
                iTone = ToneGenerator.TONE_DTMF_8;
                break;
            case '9':
                iTone = ToneGenerator.TONE_DTMF_9;
                break;
            case '*':
                iTone = ToneGenerator.TONE_DTMF_S;
                break;
        }

        if (toneGenerator == null) {
            toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
            setVolumeControlStream(AudioManager.STREAM_DTMF);
        }
        toneGenerator.startTone(iTone);

    }

    private void stopDtmfTone() {
        bSendingCmd = false;
        iCmdSendIndex = 0;
        if (mTimer != null) {
            mTimer.cancel();
            mTimer.purge();
        }
        mTimer = null;

        if (mTimerTask != null)
            mTimerTask.cancel();
        mTimerTask = null;
    }

    private void playDtmfTone() {
        if (bSendingCmd)
            return;
        bSendingCmd = true;
        iCmdSendIndex = 0;
        mTempTimeCount = 0;
        if (mTimer == null)
            mTimer = new Timer();
        mTimerTask = new MyTimerTask();
        mTimer.scheduleAtFixedRate(mTimerTask, 0, 100);

    }

    private class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            playSingleDtmf();
        }
    }


    public void doClick(View v) {
        if (getBluetoothAdapter() == null)
            return;
        switch (v.getId()) {
            case R.id.img_shine://连接或断开蓝牙
                if (a2dpState != BluetoothProfile.STATE_CONNECTED) {
                    gotoBluetoothSettings();
                }
                break;

            case R.id.btn_send:
                playDtmfTone();
                break;

            case R.id.btn_pick_color_from_camera:
                if (permissionIsGranted(Manifest.permission.CAMERA)) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CODE_CAPTURE_CAMERIA);
                } else {
                    getPermission(Manifest.permission.CAMERA);
                }

                break;
        }

    }


    /**
     * 导航到系统蓝牙设置
     */
    private void gotoBluetoothSettings() {
        Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        if (intent != null && intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_ENABLE_BLUETOOTH);
        }
    }

    private int getIndexByColor(int color) {
        int index = -1;
        int r = ((color & 0x00FF0000) >> 16);
        int g = ((color & 0x0000FF00) >> 8);
        int b = (color & 0x000000FF);

        if (r == 0 && g == 0 && b == 0) {

        } else if (r >= g && r >= b) { // r max
            float gr = (float) (g * 1.0 / r);
            float br = (float) (b * 1.0 / r);
            if (gr >= 0.7) {
                if (br >= 0.7)
                    index = 7;
                else
                    index = 2;
            } else if (gr >= 0.3)
                index = 1;
            else if (gr < 0.7 && br < 0.7) {
                index = 0;
            }

        } else if (g >= r && g >= b) { // g max
            float rg = (float) (r * 1.0 / g);
            float bg = (float) (b * 1.0 / g);
            if (rg >= 0.7) {
                if (bg >= 0.7)
                    index = 7;
                else
                    index = 2;
            } else if (bg >= 0.7 && rg < 0.5)
                index = 4;
            else if (rg < 0.7 && bg < 0.7)
                index = 3;

        } else { // b max
            float rb = (float) (r * 1.0 / b);
            float gb = (float) (g * 1.0 / b);
            if (gb >= 0.7) {
                if (rb >= 0.7)
                    index = 7;
                else
                    index = 4;
            } else if ((rb >= 0.3) && (gb < 0.5))
                index = 6;
            else if (rb < 0.7 && gb < 0.7)
                index = 5;
        }
        return index;
    }

    private void selectColorByIndex(int iIndex) {
        wheel_color_type.setCurrentItem(iIndex);
        img_shine.setImageResource(array_line[iIndex]);
        img_block_shine.setImageResource(array_color_shine[iIndex]);
        cmdIndex = iIndex;
        wheel_color_type.invalidate();
    }

    private Bitmap getCalculateBitmapFromThumb(Bitmap bmp) {
        final int ZOOM_SIZE = 32;
        Matrix matrix = new Matrix();
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int size = (w > h) ? h : w;
        size *= 0.5;
        matrix.postScale((float) (ZOOM_SIZE * 1.0 / size),
                (float) (ZOOM_SIZE * 1.0 / size));

        int iLeft = (w - size) / 2;
        int iTop = (h - size) / 2;

//        Bitmap bmp2 = Bitmap.createBitmap(bmp, iLeft, iTop, size, size, matrix,
//                true);
        return Bitmap.createBitmap(bmp, iLeft, iTop, size, size, matrix,
                true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_ENABLE_BLUETOOTH == requestCode) {
            Logger.i(Logger.DEBUG_TAG, "resultCode:" + resultCode);
            refreshA2dpState();
//            if(!coinTaskPairBtFinished){
//                finishPairBtCoinTask();
//            }
        }

        if (requestCode == REQUEST_CODE_CAPTURE_CAMERIA) {
            if (resultCode == RESULT_OK) {
                /** 解决bug:java.lang.NullPointerException: Attempt to invoke virtual method
                 * 'android.os.Parcelable android.content.Intent.getParcelableExtra(java.lang.String)' on a null object reference
                 * at com.fitmix.sdk.view.activity.PairHeadSetActivity.onActivityResult(PairHeadSetActivity.java:538)*/
                if (data == null) {
                    return;
                }
                Bitmap bmp = data.getParcelableExtra("data");
                int color = ImageHelper.getMainColorOfBitmap(bmp);
                if (bmp != null)
                    bmp.recycle();
                int index = getIndexByColor(color);
                if (index <= -1) {
                    showAppMessage(R.string.activity_pair_headset_no_approximate_color, AppMsg.STYLE_INFO);
                    return;
                }
                selectColorByIndex(index);
            }
        }
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        super.handlePermissionAllowed(permissionName);
        if (Manifest.permission.CAMERA.equals(permissionName)) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, REQUEST_CODE_CAPTURE_CAMERIA);
        }
    }

    //region  ============================= 金币任务 =============================

    /**
     * 完成使用我的设备配对一次任务
     */
    private void finishPairBtCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_PAIRING_BT, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion ============================= 金币任务 =============================


}
