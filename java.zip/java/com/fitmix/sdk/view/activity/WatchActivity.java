package com.fitmix.sdk.view.activity;

import android.app.Dialog;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.LocationInfo;
import com.fitmix.sdk.common.DeviceLocalUtil;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.bluetooth.ble.WatchManager;
import com.fitmix.sdk.common.bluetooth.scanner.ScannerFragment;
import com.fitmix.sdk.common.download.DownloadInfoListener;
import com.fitmix.sdk.common.download.DownloadService;
import com.fitmix.sdk.common.download.DownloadType;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.WatchUpgrade;
import com.fitmix.sdk.model.api.bean.Weather;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DownloadInfo;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.WatchService;
import com.fitmix.sdk.view.adapter.WatchPlateAdapter;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.HorizontalListView;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.WatchFormatManager;
import com.fitmix.sdk.watch.bean.WatchDailyData;
import com.fitmix.sdk.watch.bean.WatchInfo;
import com.fitmix.sdk.watch.bean.WatchSportLogSyncProgress;
import com.fitmix.sdk.watch.bean.WatchVersion;
import com.fitmix.sdk.watch.bean.WatchWeather;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/**
 * 手表管理主界面
 */

public class WatchActivity extends BaseWatchActivity implements ScannerFragment.OnDeviceSelectedListener, WatchService.SportLogListener {

    /**
     * 手表设置请求,当有设置更改时,需要重新查询手表设置
     */
    private static final int REQUEST_WATCH_SETTING = 800;
    /**
     * 手表通知选项请求,当有设置更改时,需要重新查询手表设置
     */
    private static final int REQUEST_WATCH_NOTIFY_SETTING = 801;

    private MenuItem menuToConnect;//连接设备
    private Button bt_connect_watch;

    private HorizontalListView list_watch_plate;//表盘列表
    private WatchPlateAdapter adapter;
    private int[] watchPlates = new int[]{R.drawable.activity_watch_screen_1, R.drawable.activity_watch_screen_2, R.drawable.activity_watch_screen_3,
            R.drawable.activity_watch_screen_4, R.drawable.activity_watch_screen_5, R.drawable.activity_watch_screen_6};

    private ImageView img_watch_plate;//表盘

    private int nowLargeIndex = 0;//当前选择的图标index

    private Button btn_sync_sport_record;//同步
    private Button btn_search_watch;//寻找手表

    private TextView tv_connect_status;//蓝牙连接状态
    private TextView tv_battery;//电池电量
    private TextView tv_last_sync;//最近同步
    private ImageView img_has_new_version;//是否有新版本

    private WatchVersion watchVersion;//手表返回的固件信息
    private WatchUpgrade watchUpgrade;//服务器返回的手表固件升级信息
    private WatchUpgrade apollo;//服务器返回的阿波罗固件升级信息
    private String apolloFileName;//阿波罗下载文件名

    private String watchMacAddress;
    private BluetoothDevice mWatch;
    private boolean sendBindCmd;//是否需要向手表发送绑定指令

    private String watchSettingStr;//APP端其它手表设置
    private boolean force = false;
    private boolean isShowUpdateDailog = false;//是否在显示固件升级提示
    private String versionName;
    private int newVersion;
    private int watchApolloVersionNum;
    private ScannerFragment dialog;
    private Dialog tipDialog;
    private int total;
    private int index;

    public static class MyHandler extends Handler {
        private WeakReference<WatchActivity> mActivity;

        public MyHandler(WatchActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (mActivity == null || mActivity.get() == null) {
                return;
            }
            WatchActivity activity = mActivity.get();
            switch (msg.what) {
                case 7://查找手表动画
                    if (activity.btn_search_watch != null) {
                        activity.btn_search_watch.setEnabled(true);
                    }
                    activity.updateWatchPlate();
                    break;
            }
        }
    }

    private Handler mHandler;

    //region================================== Activity生命周期相关 ==================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch);
        setPageName("WatchActivity");
        initToolbar();
        initViews();
        mHandler = new MyHandler(this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            mWatch = getIntent().getExtras().getParcelable("watch");
            watchMacAddress = getIntent().getStringExtra("macAddress");
            sendBindCmd = getIntent().getBooleanExtra("sendBindCmd", false);
            Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onCreate watchMacAddress:" + watchMacAddress);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            bindWatchService();
        }
    }

    @Override
    protected void initViews() {
        showGoToPlayMusicMenu = false;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        img_watch_plate = (ImageView) findViewById(R.id.img_watch_plate);

        list_watch_plate = (HorizontalListView) findViewById(R.id.list_watch_plate);
        adapter = new WatchPlateAdapter(this);

        adapter.setPlateResIds(watchPlates);
        list_watch_plate.setAdapter(adapter);

        list_watch_plate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //1.更新界面表盘图标
                nowLargeIndex = position;
                updateWatchPlate();

                //2.发送更新表盘命令
                int dialId;
                if (position == 4) {//模拟表盘
                    dialId = 0;
                } else if (position == 5) {//模拟表盘
                    dialId = 1;
                } else {
                    dialId = 100 + position;
                }
                setWatchPlate(String.valueOf(dialId), "plate" + position, null);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //不处理
            }
        });


        btn_sync_sport_record = (Button) findViewById(R.id.btn_sync_sport_record);
        btn_search_watch = (Button) findViewById(R.id.btn_search_watch);

        tv_connect_status = (TextView) findViewById(R.id.tv_connect_status);
        tv_battery = (TextView) findViewById(R.id.tv_battery);
        tv_last_sync = (TextView) findViewById(R.id.tv_last_sync);
        img_has_new_version = (ImageView) findViewById(R.id.img_has_new_version);

    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null)
            return;

        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);

        switch (requestId) {
            case Config.MODULE_USER + 29://检测服务器上手表固件最新版本信息//TODO
                watchUpgrade = JsonHelper.getObject(result, WatchUpgrade.class);
                judgeFirmUpdate(result);
                break;

            case Config.MODULE_USER + 80://服务器上手表阿波罗固件最新版本信息
                apollo = JsonHelper.getObject(result, WatchUpgrade.class);
                if (apollo != null) {
                    //下载阿波罗升级包
                    if (apollo.getFileType() == 22 && apollo.getUrl() != null) {
                        if (!TextUtils.isEmpty(apollo.getNewVersion())) {
                            if (Integer.parseInt(apollo.getNewVersion()) > watchApolloVersionNum) {
                                initDownloadListener();
                                bindDownloadService();
                                int index = apollo.getUrl().lastIndexOf("/");
                                if (index != -1) {
                                    apolloFileName = Config.PATH_LOCAL_FIRMWARE_VERSION_FILE + apollo.getUrl().substring(index + 1, apollo.getUrl().length());
                                    DownloadService.makeDownload(this, apollo.getUrl(), apolloFileName, DownloadType.TYPE_FILE);
                                }
                            }
                        }
                    }
                }
                break;
            case Config.MODULE_USER + 202://请求天气
                sendWeather(result);
                break;

            case Config.MODULE_USER + 203: // 上传错误报告到服务器成功
                hideLoadingDialog();
                showAppMessage(getString(R.string.upload_error_report_success), AppMsg.STYLE_INFO);
                break;
        }
    }

    private void judgeFirmUpdate(String result) {
        if (watchUpgrade == null || TextUtils.isEmpty(watchUpgrade.getNewVersion())) {//没有新版本 或 手表更新类里没有新版本号
            Logger.i(Logger.DEBUG_TAG, "没有新版本 或 手表更新类里没有新版本号");
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, 0);
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, 0);
            SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, "");
            SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_NEWEST, 0);
            SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, false);
            SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
            return;
        }
        Logger.i(Logger.DEBUG_TAG, "watchUpgradeVersion:" + watchUpgrade.getNewVersion());
        int newVersion = Integer.parseInt(watchUpgrade.getNewVersion());
        SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_NEWEST, newVersion);
        String isForce = watchUpgrade.getIsForce();
        if (watchVersion != null && watchVersion.getVersionNum() != null) {
            Logger.d(Logger.DEBUG_TAG, "后台 versionNum:" + newVersion + " ,手表 watchVersion：" + watchVersion.getVersionNum());
            try {

                int version = Integer.parseInt(watchVersion.getVersionNum());
                if (version < newVersion) {//TODO 手表固件升级提示
                    SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, result);
                    if (!isShowUpdateDailog) {//防止弹窗两次
                        isShowUpdateDailog = true;

                        int isUpdatingFirmVersion = SettingsHelper.getInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, 0);//上次固件传输的版本号
                        int firmSendProgress = SettingsHelper.getInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS, 0);//上次固件传输的进度
                        Logger.d(Logger.DEBUG_TAG, "isUpdatingFirmVersion:" + isUpdatingFirmVersion + ",firmSendProgress:" + firmSendProgress);
                        if (isUpdatingFirmVersion == newVersion) {
                            if (firmSendProgress == 100) return;
                        }
                        if (isUpdatingFirmVersion < newVersion) {//在更新的版本小于最新版本
                            if (firmSendProgress > 50 && firmSendProgress < 100) {//正在传输的进度在50到100之间，不提示升级

                            } else {
                                if (img_has_new_version != null) {
                                    img_has_new_version.setVisibility(View.VISIBLE);
                                }
                                if (isForce.equals("0")) {
                                    showNoticeDialog();
                                } else if (isForce.equals("1")) {
                                    showNoticeDialogForce();
                                }
                            }
                        } else {//在更新的版本跟最新版本一致

                            boolean forceUpdate = SettingsHelper.getBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, false);
                            boolean selectUpdate = SettingsHelper.getBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
                            if (forceUpdate || selectUpdate) return;

                            if (img_has_new_version != null) {
                                img_has_new_version.setVisibility(View.VISIBLE);
                            }

                            if (isForce.equals("0")) {
                                showNoticeDialog();
                            } else if (isForce.equals("1")) {
                                showNoticeDialogForce();
                            }
                        }

                    }

                } else {
                    SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, "");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    @Override
    protected void processReqError(int requestId, String error) {
        if (requestId == Config.MODULE_USER + 29
                || requestId == Config.MODULE_USER + 80
                || requestId == Config.MODULE_USER + 202) {//检测服务器上手表固件最新版本信息、天气出错不提示用户
            return;
        }

        if (requestId == Config.MODULE_USER + 203) {// 上传错误报告到服务器成功 失败时隐藏提示框
            hideLoadingDialog();
        }
        super.processReqError(requestId, error);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (img_has_new_version != null) {
            img_has_new_version.setVisibility(View.GONE);
        }
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            gattCheckByProgram(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
        unbindDownloadService();
        unbindWatchService();
        stopScan();
        Logger.i(Logger.LOG_TAG, "WatchActivity onDestroy()");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menuToConnect = menu.add(0, Menu.FIRST + 6, 6, R.string.menu_music_playing);
        menuToConnect.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);//总是显示
        menuToConnect.setActionView(R.layout.menu_device_connect);
        bt_connect_watch = (Button) menuToConnect.getActionView().findViewById(R.id.cb_connect_watch);

        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            bt_connect_watch.setText(getResources().getString(R.string.ble_equipment_connected));
            bt_connect_watch.setBackgroundResource(R.drawable.heart_rate_connected_bg);
            menuToConnect.setVisible(false);
        } else {
            bt_connect_watch.setText(getResources().getText(R.string.ble_to_connect));
            bt_connect_watch.setBackgroundResource(R.drawable.fragment_connect_selector);
            menuToConnect.setVisible(true);
        }

        bt_connect_watch.setOnClickListener(connectClickListener);
        return true;
    }

    /**
     * menu 连接手表按钮点击事件
     */
    private View.OnClickListener connectClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //蓝牙已开启的前提下
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                if (mWatchService == null)
                    return;
                if (mWatchService.getDevice() == null) {
                    //打开手机蓝牙
                    openBluetooth(new OpenBluetoothResult() {
                        @Override
                        public void openSuccess() {
                            showDeviceScanningDialog(getFilterUUID());
                        }

                        @Override
                        public void openFail() {
                            //不处理
                        }
                    });
                } else {
                    mWatchService.disconnectDevice();//断开连接
                    showDeviceScanningDialog(getFilterUUID());
                }
            } else {
                Toast.makeText(WatchActivity.this, getResources().getString(R.string.heart_rate_warn_sdk_version), Toast.LENGTH_SHORT).show();
            }
        }
    };

    /**
     * 从服务器获取手表固件升级包
     *
     * @param versionNum 当前手表固件版本号
     */
    public void getWatchUpgrade(String versionNum) {
        int requestId = UserDataManager.getInstance().watchFirmwareVersion(versionNum, true);//
        registerDataReqStatusListener(requestId);
    }


    /**
     * 从服务器获取手表阿波罗固件升级包
     *
     * @param versionNum 当前手表阿波罗固件版本号
     */
    public void getApolloUpgrade(String versionNum) {
        int requestId = UserDataManager.getInstance().watchApolloVersion(versionNum, true);//
        registerDataReqStatusListener(requestId);
    }


    /**
     * 从服务器获取天气
     *
     * @param locationInfo 最近一次定位信息
     */
    private void requestWeather(LocationInfo locationInfo) {
        if (SettingsHelper.getBoolean(Config.SETTING_IS_ABROAD, false)) {//在国外
            getBestLocation(this);//通过google获取经纬度并请求天气接口获取当前国家
        } else {//在国内
            if (locationInfo == null) {
                //重新获取最近一次定位信息
                locationInfo = getLastLocationInfo();
            }

            String lngLat = null;
            //检查定位信息有效性
            if (locationInfo != null) {
                long time = System.currentTimeMillis() - locationInfo.getLocationTime();
                if (time > 10800000L || (locationInfo.getLat() == 0 && locationInfo.getLng() == 0)) {//定位信息大于3小时或00点无效
                    getLocate();//重新定位
                    return;
                }
                lngLat = locationInfo.getLng() + "," + locationInfo.getLat();//"120.38,36.07";//
            }

            //发送天气请求
            if (lngLat != null) {
                int requestId = UserDataManager.getInstance().getCityWeather(lngLat, true);
                registerDataReqStatusListener(requestId);
            }
        }

    }


    private void requestUpload(String errorLogfileName) {
        String info = SettingsHelper.getString(Config.SETTING_WATCH_INFO, "");
        WatchInfo watchInfo = JsonHelper.getObject(info, WatchInfo.class);
        if (watchInfo == null) {
            return;
        }
        int requestId = UserDataManager.getInstance().uploadUserErrorLog(String.valueOf(UserDataManager.getUid()),
                watchInfo.getChipId(), errorLogfileName);
        registerDataReqStatusListener(requestId);
    }

    //endregion================================== Activity生命周期相关 ==================================

    //region================================== 界面相关 ==================================

    /**
     * 设置蓝牙连接状态
     *
     * @param isCheck true:已连接,false:未连接
     */
    public void gattCheckByProgram(final boolean isCheck) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isCheck) {
                    if (bt_connect_watch != null) {
                        bt_connect_watch.setText(getResources().getString(R.string.ble_equipment_connected));
                        bt_connect_watch.setBackgroundResource(R.drawable.heart_rate_connected_bg);
                    }

                    if (menuToConnect != null) {//隐藏
                        menuToConnect.setVisible(false);
                    }

                    if (tv_connect_status != null) {//连接状态
                        tv_connect_status.setText(R.string.activity_watch_connect);
                        tv_connect_status.setTextColor(ContextCompat.getColor(WatchActivity.this, R.color.orange_text));
                    }

                    String dailyStr = PrefsHelper.with(WatchActivity.this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_DAILY, "");
                    setDailyText(dailyStr);
                } else {
                    if (bt_connect_watch != null) {
                        bt_connect_watch.setText(getResources().getText(R.string.ble_to_connect));
                        bt_connect_watch.setBackgroundResource(R.drawable.fragment_connect_selector);
                    }

                    if (menuToConnect != null) {//隐藏
                        menuToConnect.setVisible(true);
                    }

                    if (tv_connect_status != null) {//连接状态
                        tv_connect_status.setText(R.string.activity_watch_not_connect);
                        tv_connect_status.setTextColor(ContextCompat.getColor(WatchActivity.this, R.color.white_new_text));
                    }

                    if (tv_battery != null) {//手表电量
                        tv_battery.setVisibility(View.GONE);
                    }
                }

            }
        });
    }

    /**
     * 更新表盘
     */
    private void updateWatchPlate() {
        if (img_watch_plate != null && watchPlates != null) {
            if (nowLargeIndex < watchPlates.length) {
                img_watch_plate.setImageResource(watchPlates[nowLargeIndex]);
            }
        }
    }

    /**
     * 更新手表运动记录同步完成状态文字
     *
     * @param lastSyncTime 最近一次同步时间
     */
    private void updateSyncDoneText(String lastSyncTime) {
        if (btn_sync_sport_record != null) {
            btn_sync_sport_record.setEnabled(true);
            btn_sync_sport_record.setText(R.string.activity_watch_sync);
        }

        if (tv_last_sync != null && lastSyncTime != null) {//更新同步时间
            tv_last_sync.setText(String.format(getString(R.string.activity_watch_last_sync), lastSyncTime));
        }
    }

    /**
     * 设置日常数据信息
     */
    private void setDailyText(String dailyDataStr) {
        if (TextUtils.isEmpty(dailyDataStr))
            return;

        WatchDailyData watchDailyData = JsonHelper.getObject(dailyDataStr, WatchDailyData.class);
        if (watchDailyData == null)
            return;
        String battery = watchDailyData.getBattery() + "%";
        if (tv_battery != null) {//手表电量
            String batteryStr = String.format(getString(R.string.activity_watch_battery), battery);
            tv_battery.setText(batteryStr);
            tv_battery.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 显示正在同步运动记录
     */
    private void showInSyncRecord() {
        if (btn_sync_sport_record != null) {
            btn_sync_sport_record.setEnabled(false);
        }
        if (tv_last_sync != null) {
            tv_last_sync.setText(R.string.activity_watch_is_sync_record);
        }
    }

    //手表新版本强制提示框
    private void showNoticeDialogForce() {
        new MaterialDialog.Builder(this)
                .title(R.string.new_watch_version_tip)
                .content(R.string.watch_version_force_tip)
                .cancelable(false)
                .positiveText(R.string.update_ok)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                startVersionInfoActivity(true, false);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE, true);
                                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT, false);
                                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION, Integer.parseInt(watchUpgrade.getNewVersion()));
                                break;

                            case NEGATIVE://取消下载
                                finish();
                                break;
                        }
                    }
                }).show();
    }

    //手表新版本提示框
    private void showNoticeDialog() {
        Logger.d(Logger.DEBUG_TAG, "showNoticeDialog");
        new MaterialDialog.Builder(this)
                .title(R.string.new_watch_version_tip)
                .content(R.string.watch_version_select_tip)
                .positiveText(R.string.update_now)
                .negativeText(R.string.update_later)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://显示下载对话框
                                startVersionInfoActivity(false, false);
                                break;

                            case NEGATIVE://取消下载

                                break;
                        }
                    }
                }).show();
    }


    //endregion================================== 界面相关 ==================================

    //region ================================== Override 父类方法 ==================================


    @Override
    protected void onLocateSuccess(LocationInfo locationInfo) {
        if (!SettingsHelper.getBoolean(Config.SETTING_IS_ABROAD, false)) {
            Logger.d(Logger.DEBUG_TAG, "WatchActivity onLocateSuccess");
            requestWeather(locationInfo);
        }
    }

    @Override
    protected void initWatchServiceFunction() {
        mWatchServiceFun = new WatchService.ServiceFunction() {

            @Override
            public void onDeviceConnected() {
                Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onDeviceConnected()");
                startWatchService();
                if (dialog != null && dialog.isVisible()) {
                    dialog.dismiss();
                }
            }

            @Override
            public void onDeviceReady() {
                //查询手表设置、手表固件版本 获取手表当前表盘
                Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onDeviceReady()");
                gattCheckByProgram(true);
                ThreadManager.getMainHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        sendInitCmd(true);
                    }
                }, 1000);//延迟一秒再请求,手表反应不够快
            }

            @Override
            public void onDeviceDisconnected() {
                Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onDeviceDisconnected()");
                gattCheckByProgram(false);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mWatchService != null && mWatchService.isSyncRecord()) {
                            showUseTip(getResources().getString(R.string.sport_log_disconnect_tip), getResources().getString(R.string.update_ok), false);
                        }
                    }
                });

                // autoConnectWatch();//蓝牙断开后,尝试自动连接
            }

            @Override
            public void onResponse(int groupTag, int cell, int iPos, final int result) {
                switch (groupTag) {
                    case WatchDataProtocol.TAG_GROUP_FIND://查找手表
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (result == WatchDataProtocol.PACKAGE_RESULT_SUCCESS) {
                                    showAppMessage(R.string.activity_watch_search_success, AppMsg.STYLE_INFO);
                                } else {
                                    showAppMessage(R.string.activity_watch_search_fail, AppMsg.STYLE_ALERT);
                                }
                            }
                        });
                        break;
                }
            }

            @Override
            public void onReceiveDataRefreshUi(int groupTag, final String dataJson) {
                switch (groupTag) {
                    case WatchDataProtocol.TAG_GROUP_WEATHER://天气
                        Logger.d(Logger.DEBUG_TAG, "WatchActivity onReceiveDataRefreshUi");
                        requestWeather(null);
                        break;
                    case WatchDataProtocol.TAG_GROUP_DAILY_DATA://日常数据
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                setDailyText(dataJson);
                            }
                        });
                        break;

                    case WatchDataProtocol.TAG_GROUP_UPGRADE://查询手表固件版本 手表返回两次结果：固件版本和aplo版本
                        watchVersion = JsonHelper.getObject(dataJson, WatchVersion.class);
                        if (watchVersion != null) {
                            final String versionNum = watchVersion.getVersionNum();
                            versionName = watchVersion.getVersionName();
                            final String apolloVersionNum = watchVersion.getApolloVersionNum();
                            watchApolloVersionNum = Integer.parseInt(apolloVersionNum);
                            Logger.i(Logger.DEBUG_TAG, "查询手表固件版本 versionNum:" + versionNum + ",versionName:" + versionName
                                    + ",apolloVersionNum:" + apolloVersionNum);
                            if (versionNum != null) {
                                getWatchUpgrade(versionNum);
                            }
                            if (apolloVersionNum != null) {
                                getApolloUpgrade(apolloVersionNum);
                            }
                            SettingsHelper.putInt(Config.SETTING_WATCH_VERSIONNUM, Integer.parseInt(versionNum));
                        }
                        break;

                    case WatchDataProtocol.TAG_GROUP_ADD_LOG://同步记录
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showInSyncRecord();
                            }
                        });
                        break;

                    case WatchDataProtocol.TAG_GROUP_SYN_LOG_CONTROL://运动记录同步控制
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (dataJson != null) {//
                                    WatchSportLogSyncProgress progress = JsonHelper.getObject(dataJson, WatchSportLogSyncProgress.class);
                                    if (progress != null) {
                                        total = progress.getTotal();
                                        index = progress.getIndex();
                                        if (total == 0) {
                                            showUseTip(getResources().getString(R.string.sport_log_no_data_tip), getResources().getString(R.string.update_ok), false);
                                            String lastSyncTime = progress.getLastSyncTime();
                                            updateSyncDoneText(lastSyncTime);
                                        } else {
                                            if (total == index) {//同步完成
                                                String lastSyncTime = progress.getLastSyncTime();
                                                if (btn_sync_sport_record != null) {
                                                    btn_sync_sport_record.setText(String.format(getString(R.string.activity_watch_sync_format), 100 + "%"));
                                                }
                                                if (mHandler != null) {
                                                    mHandler.postDelayed(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            updateSyncDoneText(lastSyncTime);
                                                        }
                                                    }, 250);
                                                }
                                            }
                                        }

                                    }
                                } else {
                                    updateSyncDoneText(null);
                                }
                            }
                        });
                        break;
                    case WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS://APP 端其它手表设置
                        watchSettingStr = dataJson;//更新设置
                        Logger.v(Logger.DEBUG_TAG, "watchSettingStr:" + watchSettingStr);
                        break;
                    case WatchDataProtocol.TAG_GROUP_ERROR_REPORT:// 错误报告
                        Logger.d(Logger.DEBUG_TAG, "TAG_GROUP_ERROR_REPORT 错误报告----接收完毕 上传到后台start");
                        requestUpload(Config.PATH_WATCH_ERROR_LOG + Config.LOG_NAME);
                        break;
                }
            }
        }

        ;
    }


    @Override
    protected void onWatchServiceConnected() {
        Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onWatchServiceConnected()");
        // 忽略省电优化
        ignoreBatteryOptimization(this);
        //绑定成功后,连接设备,更新相应的界面提示
        if (mWatchService != null) {
            if (mWatchService.getDevice() == null && mWatch != null) {//连接设备
                mWatchService.connectDevice(mWatch);
                if (tv_connect_status != null) {
                    tv_connect_status.setText(R.string.activity_watch_connecting);
                }
            }
            if (mWatchService.getDevice() != null && !mWatchService.ifBLEFunctionOk()) {
                if (tv_connect_status != null) {
                    tv_connect_status.setText(R.string.activity_watch_connecting);
                }
            }
            if (mWatchService.ifBLEFunctionOk()) {
                gattCheckByProgram(true);
                if (!mWatchService.isSyncRecord()) {//没有传输运动记录时,再次发送命令
                    sendInitCmd(false);
                }
            }
            if (mWatchService.isSyncRecord()) {//判断是否正在同步记录
                if (btn_sync_sport_record != null) {
                    btn_sync_sport_record.setEnabled(false);
                }
                if (tv_last_sync != null) {
                    tv_last_sync.setText(R.string.activity_watch_is_sync_record);
                }
                showInSyncRecord();
            }

            mWatchService.setListener(this);
        }

    }

    @Override
    protected void onWatchServiceDisconnected() {
        Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onWatchServiceDisconnected()");
        gattCheckByProgram(false);
    }

    //endregion ================================== Override 父类方法 ==================================

    //region ================================== 蓝牙设备搜索相关 ==================================
    //ScannerFragment的两个回调方法
    @Override
    public void onDeviceSelected(BluetoothDevice device, String name) {
        Logger.i("TT", "WatchActivity-->onDeviceSelected()");
        if (mWatchService != null) {
            mWatchService.connectDevice(device);
            DeviceLocalUtil.putDevice2Local(device);
            if (tv_connect_status != null) {
                tv_connect_status.setText(R.string.activity_watch_connecting);
            }
        }
    }

    @Override
    public void onDialogCanceled() {
        Logger.e(Logger.DEBUG_TAG, "onDialogCanceled()");
    }

    private UUID getFilterUUID() {
        return WatchManager.HR_SERVICE_UUID;
    }

    /**
     * Shows the scanner fragment.
     *
     * @param filter the UUID filter used to filter out available devices. The fragment will always show all bonded devices as there is no information about their
     *               services
     * @see #getFilterUUID()
     */
    private void showDeviceScanningDialog(final UUID filter) {
        if (dialog == null)
            dialog = ScannerFragment.getInstance(filter);
        dialog.setMacAddress(watchMacAddress);//只显示用户已绑定的手表
        dialog.show(getSupportFragmentManager(), "scan_fragment");
    }

    /**
     * 自动连接手表
     */
    private void autoConnectWatch() {
        //1.检查用户是否有手表设备
        String info = SettingsHelper.getString(Config.SETTING_WATCH_INFO, "");
        WatchInfo watchInfo = JsonHelper.getObject(info, WatchInfo.class);
        String watchMacAddress;
        if (watchInfo == null)
            return;
        watchMacAddress = watchInfo.getMac();
        if (watchMacAddress == null)
            return;

        //2.检查当前手机蓝牙是否开启,当开启时查找手表并连接
        if (isBluetoothReady()) {
            Logger.d(Logger.DEBUG_TAG, "WatchActivity isSearching------");
            searchWatch(watchMacAddress, 24000);
        }
    }

    //endregion ================================== 蓝牙设备搜索相关 ==================================

    //region ================================== 手表通讯指令相关 ==================================

    /**
     * 告诉手表当前手机系统类型为android
     */
    private void phoneTypeSetting() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getAndroidPhoneInfo();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_PHONE_SYSTEM);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            //    showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 查询手表设置
     */
    private void querySettings() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getWatchOtherSettingData();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_QUERY);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置手表语言
     */
    private void languageSetting() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            String lan = "1";//默认为中文
            String appLan = ApiUtils.getLanguage();
            if (appLan != null && !appLan.endsWith("zh")) {
                lan = "0";
            }
            byte[] data = WatchFormatManager.getLanguageSettingData(lan);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS, WatchDataProtocol.OTHER_SETTINGS_BLE_LANGUAGE);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 查询手表版本 包括固件和aplo
     */
    private void queryWatchVersion() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            int uid = UserDataManager.getUid(); //后续带乐享动uid
            byte[] data = WatchFormatManager.getWatchVersion(uid);
//            byte[] data = WatchFormatManager.getWatchVersion();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_QUERY);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 向手表发送用户信息
     */
    private void setUserInfo() {
        int gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);
        int height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, Config.USER_DEFAULT_HEIGHT);
        int weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, Config.USER_DEFAULT_WEIGHT);

        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getUserInfo(gender, age, height, weight * 10);
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_USERINFO, WatchDataProtocol.USERINFO_BLE_RESERVED);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //  showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

//    /**
//     * 查询表盘
//     */
//    private void queryWatchPlate() {
//        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
//            byte[] data = WatchFormatManager.getDialPlate();
//            if (mWatchService != null) {
//                int tag = WatchFormatManager.generateTag(
//                        WatchDataProtocol.TAG_GROUP_DIAL_PLATE, WatchDataProtocol.DIAL_BLE_QUERY);
//                mWatchService.sendTotallyDataCmd(tag, data);
//            }
//        } else {
//            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
//        }
//    }

    /**
     * 设置表盘
     *
     * @param dialId   表盘ID,100以上是内置表盘,0以上是自定义表盘,需要data
     * @param dialName 表盘名称
     * @param dialData 表盘数据包
     */
    private void setWatchPlate(String dialId, String dialName, byte[] dialData) {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getDialData(dialId, dialName, dialData);//目前不需要data部分
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(
                        WatchDataProtocol.TAG_GROUP_DIAL_PLATE, WatchDataProtocol.DIAL_BLE_RESERVED);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //  showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 设置手表日期时间为手机当前日期和时间
     */
    private void syncWatchDateAndTime() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            long time = System.currentTimeMillis();
            SimpleDateFormat formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_DATA_FORMAT,
                    Locale.getDefault());

            Date curDate = new Date(time);
            String date = formatterTime.format(curDate);
            formatterTime = new SimpleDateFormat(WatchDataProtocol.WATCH_TIME_FORMAT, Locale.getDefault());
            String currentTime = formatterTime.format(curDate);
            int timeZone = TimeZone.getDefault().getOffset(time) / 3600000;
            byte[] data = WatchFormatManager.getSynchronizeTime(date, currentTime, String.valueOf(timeZone));
            if (data.length != 0) {
                int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_TIME, WatchDataProtocol.TIME_BLE_RESERVED);
                mWatchService.sendTotallyDataCmd(tag, data);
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

//    /**
//     * 手表恢复出厂设置后,从服务器下载最近15条运动记录,发送回手表
//     * 目前不需要考虑
//     */
//    private void syncSportRecord() {
//        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
//            byte[] data = WatchFormatManager.getRequestDownload("5");
//            if (data.length != 0) {
//                //cell本来是要传WatchDataProtocol.DOWNLOAD_LOG_LOGS,但手表对此请求回复结果的tag是0000f701
//                int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_DOWNLOAD_LOGS, WatchDataProtocol.DOWNLOAD_LOG_RESERVED);
//                mWatchService.sendTotallyDataCmd(tag, data);
//            } else {
//                Toast.makeText(WatchActivity.this, "data.length == 0", Toast.LENGTH_SHORT).show();
//            }
//        } else {
//            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
//        }
//    }

    /**
     * 查找手表
     */
    private void findWatch() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getFindWatchData();
            if (mWatchService != null) {
                int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_FIND, WatchDataProtocol.FIND_BLE_FINDWATCH);
                mWatchService.sendTotallyDataCmd(tag, data);
            }

            if (btn_search_watch != null) {
                btn_search_watch.setEnabled(false);
            }

            if (img_watch_plate != null) {
                img_watch_plate.setImageResource(R.drawable.activity_watch_search_watch);

                AnimationDrawable animationDrawable = (AnimationDrawable) img_watch_plate.getDrawable();
                if (animationDrawable != null) {
                    animationDrawable.start();
                }
            }
            if (mHandler != null) {
                mHandler.sendEmptyMessageDelayed(7, 5000);//5秒后结束动画
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

//    /**
//     * 绑定手表,新绑定解绑流程不再需要向手表发送
//     */
//    private void bindWatch() {
//        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
//            int uid = UserDataManager.getUid();
//            byte[] data = WatchFormatManager.getBindUnbindWatchData(true, String.valueOf(uid));//, true
//            if (mWatchService != null) {
//                int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_BIND, WatchDataProtocol.BIND_BLE_RESERVED);
//                mWatchService.sendTotallyDataCmd(tag, data);
//            }
//        } else {
//            showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
//        }
//    }

    /**
     * 绑定手表结果
     */
    private void bindWatchResult(boolean bindResult) {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
//            int uid = UserDataManager.getUid();
            byte[] data = WatchFormatManager.getBindUnbindWatchResult(true, bindResult);
            int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_BIND, WatchDataProtocol.BIND_BLE_BIND);
            mWatchService.sendTotallyDataCmd(tag, data);
            Logger.d(Logger.DEBUG_TAG, "groupTag ------>发送绑定");
            sendBindCmd = false;
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 手机主动请求手表电量的指令
     */
    private void syncBatteryVolume() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            if (btn_sync_sport_record != null) {
                btn_sync_sport_record.setEnabled(false);
            }

            byte[] data = WatchFormatManager.getWatchDailyData();
            int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_DAILY_DATA, WatchDataProtocol.DAILY_BLE_QUERY);
            mWatchService.sendTotallyDataCmd(tag, data);
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 手机主动请求手表运动记录同步的指令
     */
    private void syncSportRecords() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            if (btn_sync_sport_record != null) {
                btn_sync_sport_record.setEnabled(false);
            }

            byte[] data = WatchFormatManager.getSyncSportLog();
            int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_SYN_LOG_CONTROL, WatchDataProtocol.SYN_CONTROL_BLE_RESERVED);
            mWatchService.sendTotallyDataCmd(tag, data);
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 向手表发送阿波罗升级包
     */
    private void sendAploUpgrade() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            if (mWatchService != null) {
                mWatchService.sendBigFile(WatchDataProtocol.TAG_GROUP_UPGRADE, WatchDataProtocol.UPGRADE_BLE_APOLLO, apolloFileName, 0);
            }
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 向手表发送天气
     */
    private void sendWeather(String result) {
        Weather weather = JsonHelper.getObject(result, Weather.class);
        if (weather != null) {
            String loc = weather.getSurprise().getUpdate().getLoc().trim();
            String lastLoc = SettingsHelper.getString(Config.LAST_WATCH_FRESH_WEATHER_TIME, "").trim();
            if (TextUtils.isEmpty(lastLoc) || !loc.equalsIgnoreCase(lastLoc)) {
                SettingsHelper.putString(Config.LAST_WATCH_FRESH_WEATHER_TIME, loc);

                WatchWeather watchTodayWeather = new WatchWeather(weather, 0);//今天天气
                if (watchTodayWeather.getUpdateDate() != null && watchTodayWeather.getUpdateTime() != null
                        && watchTodayWeather.getDate() != null) {
                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                        byte[] data = WatchFormatManager.getWeather(watchTodayWeather);
                        int tag = WatchFormatManager.generateTag(
                                WatchDataProtocol.TAG_GROUP_WEATHER, WatchDataProtocol.WEATHER_BLE_RESERVED);
                        mWatchService.sendTotallyDataCmd(tag, data);
                    } else {
                        //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
                    }
                }

                WatchWeather watchTomorrowWeather = new WatchWeather(weather, 1);//明天天气
                if (watchTomorrowWeather.getUpdateDate() != null && watchTomorrowWeather.getUpdateTime() != null
                        && watchTomorrowWeather.getDate() != null) {
                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                        byte[] data = WatchFormatManager.getWeather(watchTomorrowWeather);
                        int tag = WatchFormatManager.generateTag(
                                WatchDataProtocol.TAG_GROUP_WEATHER, WatchDataProtocol.WEATHER_BLE_RESERVED);
                        mWatchService.sendTotallyDataCmd(tag, data);
                    } else {
                        //    showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
                    }
                }

                WatchWeather watchDatWeather = new WatchWeather(weather, 2);//后天天气
                if (watchDatWeather.getUpdateDate() != null && watchDatWeather.getUpdateTime() != null
                        && watchDatWeather.getDate() != null) {
                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                        byte[] data = WatchFormatManager.getWeather(watchDatWeather);
                        int tag = WatchFormatManager.generateTag(
                                WatchDataProtocol.TAG_GROUP_WEATHER, WatchDataProtocol.WEATHER_BLE_RESERVED);
                        mWatchService.sendTotallyDataCmd(tag, data);
                    } else {
                        //  showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
                    }
                }

                WatchWeather watchTdWeather = new WatchWeather(weather, 3);//大后天天气 three days from now
                if (watchTdWeather.getUpdateDate() != null && watchTdWeather.getUpdateTime() != null
                        && watchTdWeather.getDate() != null) {
                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                        byte[] data = WatchFormatManager.getWeather(watchTdWeather);
                        int tag = WatchFormatManager.generateTag(
                                WatchDataProtocol.TAG_GROUP_WEATHER, WatchDataProtocol.WEATHER_BLE_RESERVED);
                        mWatchService.sendTotallyDataCmd(tag, data);
                    } else {
                        //  showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
                    }
                }
            } else if (!TextUtils.isEmpty(lastLoc) && loc.equalsIgnoreCase(lastLoc)) {
                if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                    int tag = WatchFormatManager.generateTag(
                            WatchDataProtocol.TAG_GROUP_WEATHER, WatchDataProtocol.WEATHER_BLE_QUERY);
                    mWatchService.sendWatchResponseCmd(tag, 0, WatchDataProtocol.PACKAGE_RESULT_SUCCESS);//向手表发送response包
                }
            }

        }
    }

    /**
     * 蓝牙连接手表后,需要发送的一系列指令
     *
     * @param firstConnect 手机是否与手表第一次连接 true:是,false:否
     */
    private void sendInitCmd(boolean firstConnect) {
        Logger.d(Logger.DEBUG_TAG, "groupTag" + "sendInitCmd---->");

        int watchVersionNum = SettingsHelper.getInt(Config.SETTING_WATCH_VERSIONNUM, 0);
        if (watchVersionNum > 7) {//大于7版本则每次发送绑定结果给手表
            bindWatchResult(true);//向手表发送后台绑定结果
        } else {
            if (sendBindCmd) {
                bindWatchResult(true);//向手表发送后台绑定结果
            }
        }
        querySettings();//查询手表设置
        queryWatchVersion();//查询手表固件版本,并带上乐享动uid

        if (firstConnect) {
            phoneTypeSetting();//通知手表当前手机系统类型
            syncWatchDateAndTime();//同步时间
            languageSetting();//设置手表语言
            setUserInfo();//设置用户信息
        } else {
            requestWeather(null);
        }

    }

    //endregion ================================== 手表通讯指令相关 ==================================

    //region ================================== 页面跳转 ==================================

    /**
     * 启动手表固件版本查看、升级界面
     *
     * @param force         是否强制升级
     * @param unUpdateClick 非弹窗点击跳转
     */
    private void startVersionInfoActivity(boolean force, boolean unUpdateClick) {
        Intent intent = new Intent(this, WatchVersionInfoActivity.class);
        intent.putExtra("macAddress", watchMacAddress);//当前连接的设备地址
        if (watchVersion != null) {
            intent.putExtra("curVersionName", versionName);
        }
        if (!unUpdateClick) {
            if (force) {
                intent.putExtra("forceUpdateClick", true);
            } else {
                intent.putExtra("selectUpdateClick", true);
            }
        }
        startActivity(intent);
    }

    /**
     * 启动手机使用帮助界面
     */
    private void startUsageHelpActivity() {
      /*  Intent intent = new Intent(this, WatchUsageHelpActivity.class);
        startActivity(intent);*/
        Intent intent = new Intent();
        intent.setClass(this, WebViewActivity.class);
        intent.putExtra("url", ApiConstants.appHelpUrl());
        intent.putExtra("title", getResources().getString(R.string.title_activity_watch_usage_help));
        startActivity(intent);
    }

    /**
     * 启动手表消息选项界面
     */
    private void startWatchSettingNotifyActivity() {
        Intent intent = new Intent(this, WatchNotifySettingActivity.class);
        intent.putExtra("watchSettingStr", watchSettingStr);
        startActivityForResult(intent, REQUEST_WATCH_NOTIFY_SETTING);
    }

    /**
     * 启动手表设置界面
     */
    private void startWatchSettingAppActivity() {
        Intent intent = new Intent(this, WatchSettingActivity.class);
        intent.putExtra("watchSettingStr", watchSettingStr);
        startActivityForResult(intent, REQUEST_WATCH_SETTING);
    }

    //endregion ================================== 页面跳转 ==================================

    //region ================================== 下载相关 ==================================

    private ServiceConnection downloadServiceConnection;//下载服务
    private DownloadInfoListener downloadListener;
    private DownloadService mService;

    /**
     * 绑定下载服务
     */
    private void bindDownloadService() {
        FileUtils.makeDirs(Config.PATH_LOCAL_FIRMWARE_VERSION_FILE);//创建文件夹
        Intent intent = new Intent(this, DownloadService.class);
        downloadServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Logger.i(Logger.DEBUG_TAG, "WatchActivity-->download service onServiceConnected");
                if (DownloadService.NAME.equals(name.getClassName())) {
                    mService = ((DownloadService.GetServiceClass) service).getService();
                    if (mService == null)
                        return;

                    if (downloadListener != null) {//注册下载状态监听
                        Logger.i(Logger.DEBUG_TAG, "WatchActivity-->download service onServiceConnected addDownloadListener");
                        mService.addDownloadListener(downloadListener);
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                if (DownloadService.NAME.equals(name.getClassName())) {
                    if (mService == null)
                        return;
                    if (downloadListener != null) {//注销下载状态监听
                        mService.removeDownloadListener(downloadListener);
                    }
                }
            }
        };
        bindService(intent, downloadServiceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑下载服务
     */
    private void unbindDownloadService() {
        if (downloadServiceConnection != null) {
            unbindService(downloadServiceConnection);
        }
        downloadServiceConnection = null;
        downloadListener = null;
    }

    /**
     * 实例化下载服务监听回调
     */
    private void initDownloadListener() {
        downloadListener = new DownloadInfoListener() {
            @Override
            public void onPrepare(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onDownloading(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onPause(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onCompleted(DownloadInfo downloadInfo) {
                Logger.d(Logger.DEBUG_TAG, "onCompleted:" + downloadInfo.getLocalPath()
                        + ",filePath:" + apolloFileName);
                if (!TextUtils.isEmpty(apolloFileName)) {
                    sendAploUpgrade();
                }
            }

            @Override
            public void onCancel(DownloadInfo downloadInfo) {
                //不处理
            }

            @Override
            public void onFail(DownloadInfo downloadInfo, String errorMsg) {
                Logger.e(Logger.DEBUG_TAG, "onFail:" + errorMsg);
                if (apollo != null && !TextUtils.isEmpty(apollo.getUrl())) {
                    String downUrl = apollo.getUrl();
                    if (mService != null) {
                        mService.cancelDownload(downUrl);
                    }
                    if (!TextUtils.isEmpty(apolloFileName)) {
                        String tmpPath = apolloFileName + ".tmp";
                        FileUtils.deleteFile(tmpPath);//删除下载的临时文件
                    }
                }
            }

            @Override
            public void onExist(DownloadInfo downloadInfo) {
                Logger.d(Logger.DEBUG_TAG, "WatchActivity onExist:" + downloadInfo.getLocalPath()
                        + ",filePath:" + apolloFileName);
                if (!TextUtils.isEmpty(apolloFileName)) {
                    sendAploUpgrade();
                }
            }
        };
    }

    //endregion ================================== 下载相关 ==================================

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.tv_watch_now_version://当前版本
                startVersionInfoActivity(false, true);
                break;
            case R.id.tv_watch_usage_help://使用帮助
                startUsageHelpActivity();
                break;
            case R.id.tv_watch_notify://通知选项
                startWatchSettingNotifyActivity();
                break;

            case R.id.tv_watch_setting://手表设置
                startWatchSettingAppActivity();
                break;
            case R.id.btn_sync_sport_record://同步运动记录
                syncSportRecords();
                int watchVersionNum = SettingsHelper.getInt(Config.SETTING_WATCH_VERSIONNUM, 0);
                if (watchVersionNum >= 7) {//大于7版本则每次发送绑定结果给手表
                    syncBatteryVolume();
                }
                break;
            case R.id.btn_search_watch://寻找手表
                findWatch();
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_WATCH_SETTING:
            case REQUEST_WATCH_NOTIFY_SETTING:
                Logger.i(Logger.DEBUG_TAG, "WatchActivity-->onActivityResult REQUEST_WATCH_SETTING..... resultCode:" + resultCode);
                if (resultCode == RESULT_OK) {
                    querySettings();
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 显示使用提示窗口
     */
    private void showUseTip(String tipContent, String buttonText, boolean isToBindWatch) {
        if (tipDialog == null) {
            tipDialog = new Dialog(this, R.style.dialog);
        }
        View tipView = LayoutInflater.from(this).inflate(R.layout.static_heart_rate_tip_view, null);
        TextView tipTv = (TextView) tipView.findViewById(R.id.tip_content_tv);
        Button button = (Button) tipView.findViewById(R.id.confirm_btn);
        tipTv.setText(tipContent);
        button.setText(buttonText);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tipDialog.dismiss();
            }
        });

        tipDialog.setCancelable(false);
        tipDialog.setCanceledOnTouchOutside(true);
        tipDialog.setContentView(tipView);
        tipDialog.show();
    }

    @Override
    public void progress(int progress) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mWatchService == null) return;
                total = mWatchService.getTotalLog();
                if (total == 0) return;
                if (btn_sync_sport_record != null) {
                    if (1 == total) {
                        btn_sync_sport_record.setText(String.format(getString(R.string.activity_watch_sync_format), progress + "%"));
                    } else {
                        index = mWatchService.getIndexLog();
                        for (int i = 0; i < total; i++) {
                            if (i == index) {
                                int showProgress = (int) ((double) (1) / ((double) total) * progress) + (int) ((double) (i) / ((double) total) * 100d);
                                btn_sync_sport_record.setText(String.format(getString(R.string.activity_watch_sync_format), showProgress + "%"));
                            }
                        }

                    }

                }
                showInSyncRecord();
            }
        });

    }

}
