package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.TopicAnswer;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.StringUtils;
import com.fitmix.sdk.model.api.bean.AddTopicAnswer;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.UploadImage;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.AddTopicAnswerFragment;
import com.fitmix.sdk.view.fragment.InviteAnswerFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.ClearEditText;
import com.fitmix.sdk.view.widget.cropper.CropImage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 添加话题答案界面
 */
public class AddTopicAnswerActivity extends BaseActivity {
    /**
     * 回答话题类型,我来回答
     */
    public final static int ANSWER_TYPE_NEW = 1;
    /**
     * 回答话题类型,邀请回答
     */
    public final static int ANSWER_TYPE_INVITE = 2;

    /**
     * 回答话题类型,重新编辑
     */
    public final static int ANSWER_TYPE_EDIT = 3;

    private AddTopicAnswerFragment addTopicAnswerFragment;
    private InviteAnswerFragment inviteAnswerFragment;

//    private Uri mCropImageUri;

    private int topicId;

    private TextView tv_title;
    private View layout_invite;
    private ClearEditText searchEditText;
    private TextView tv_search;

    private int answerId;
    private int answerType;

    private String answerDraftFile;//答案草稿文件名全路径

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_topic_answer);
        setPageName("AddTopicAnswerActivity");

        initToolbar();
        initViews();
        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }
        topicId = intent.getIntExtra("topicId", -1);
        answerId = intent.getIntExtra("answerId", -1);
        if (topicId == -1) {
            finish();
            return;
        }
        answerType = intent.getIntExtra("answerType", ANSWER_TYPE_NEW);
        answerDraftFile = FitmixUtil.getTopicPath() + topicId + "_" + UserDataManager.getUid() + "_answerDraft";
        if (savedInstanceState == null) {
            if (answerType == ANSWER_TYPE_NEW) {
                addTopicAnswerFragment = new AddTopicAnswerFragment();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, addTopicAnswerFragment, AddTopicAnswerFragment.TAG)
                        .commit();
            }
//            else if (answerType == ANSWER_TYPE_INVITE) {//暂时不做
//                inviteAnswerFragment = new InviteAnswerFragment();
//                getSupportFragmentManager().beginTransaction()
//                        .replace(R.id.mainContainer, inviteAnswerFragment, InviteAnswerFragment.TAG)
//                        .commit();
//            }
            else if (answerType == ANSWER_TYPE_EDIT) {
                addTopicAnswerFragment = new AddTopicAnswerFragment();
                String contentKey = topicId + "_" + UserDataManager.getUid() + "_answer";
                String content = MyConfig.getInstance().getMemExchange().getTopicContent(contentKey);
                if (content != null) {
                    try {
                        content = java.net.URLDecoder.decode(content, "UTF-8");//URL加密
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                addTopicAnswerFragment.setContent(content);
                MyConfig.getInstance().getMemExchange().removeTopicContent(contentKey);
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, addTopicAnswerFragment, AddTopicAnswerFragment.TAG)
                        .commit();
            }
        }

        if (FileUtils.isFileExist(answerDraftFile)) {//读取草稿内容
            String content = readTopicAnswerDraft(answerDraftFile);
            if (addTopicAnswerFragment != null) {
                addTopicAnswerFragment.setContent(content);
            }
        }

    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        tv_title = (TextView) findViewById(R.id.tv_title);
        layout_invite = findViewById(R.id.layout_invite);
        searchEditText = (ClearEditText) findViewById(R.id.searchView);
        searchEditText.setClearButtonClickListener(new ClearEditText.OnClearButtonClickListener() {
            @Override
            public void onClearButtonClick() {
                //TODO
            }
        });
        tv_search = (TextView) findViewById(R.id.tv_search);

        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {//软键盘的搜索键
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                doSearch();
                return false;
            }
        });
        searchEditText.addTextChangedListener(new TextWatcher() {//输入框内容监听
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (TextUtils.isEmpty(s)) {
                    tv_search.setEnabled(false);//无内容为不可用
                    searchEditText.setClearIconVisible(false);
                } else {
                    tv_search.setEnabled(true);
                    searchEditText.setClearIconVisible(true);
                }
            }
        });

    }

    /**
     * 显示标题
     *
     * @param show true:显示标题,false:显示搜索
     */
    public void showTitle(boolean show) {
        if (show) {
            if (tv_title != null) {
                tv_title.setVisibility(View.VISIBLE);
            }
            if (layout_invite != null) {
                layout_invite.setVisibility(View.GONE);
            }
        } else {
            if (tv_title != null) {
                tv_title.setVisibility(View.GONE);
            }
            if (layout_invite != null) {
                layout_invite.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_COMPETITION + 12://提交话题回答
                Logger.i(Logger.DATA_FLOW_TAG, "提交话题回答:" + result);
                AddTopicAnswer addTopicAnswer = JsonHelper.getObject(result, AddTopicAnswer.class);
                if (addTopicAnswer != null) {
                    TopicAnswer topicAnswer = addTopicAnswer.getTheme();
                    if (addTopicAnswer.getCode() == 0 || topicAnswer != null) {
                        showAppMessage(R.string.activity_add_topic_answer_success, AppMsg.STYLE_INFO);

                        //中转话题答案
                        String newTopicAnswerJsonStr = JsonHelper.createJsonString(topicAnswer);
                        if (newTopicAnswerJsonStr != null) {
                            MyConfig.getInstance().getMemExchange().setTopicContent(topicId + "_new_answer", newTopicAnswerJsonStr);
                            setResult(RESULT_OK);//回调成功
                        }

                        deleteTopicAnswerDraft();//删除草稿
                        destroyActivityDelay();
                    } else {
                        if (!TextUtils.isEmpty(addTopicAnswer.getMsg())) {
                            showAppMessage(addTopicAnswer.getMsg(), AppMsg.STYLE_ALERT);
                        }
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 15://上传图片
                Logger.i(Logger.DATA_FLOW_TAG, "上传图片:" + result);
                setUploadStatus(false);
                UploadImage uploadImage = JsonHelper.getObject(result, UploadImage.class);
                if (uploadImage != null) {
                    String link = uploadImage.getLink();
                    if (!TextUtils.isEmpty(link)) {
                        if (addTopicAnswerFragment != null) {
                            addTopicAnswerFragment.insertImageTag(link);
                        }
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 17://编辑话题回答
                Logger.i(Logger.DATA_FLOW_TAG, "编辑话题回答:" + result);
                AddTopicAnswer editTopicAnswer = JsonHelper.getObject(result, AddTopicAnswer.class);
                if (editTopicAnswer != null) {
                    if (editTopicAnswer.getCode() == 0 || editTopicAnswer.getTheme() != null) {
                        showAppMessage(R.string.activity_add_topic_answer_success, AppMsg.STYLE_INFO);
                        //中转话题答案
                        if (addTopicAnswerFragment != null) {
                            String newTopicAnswerJsonStr = addTopicAnswerFragment.getContent();
                            String encodeContent = newTopicAnswerJsonStr;
                            try {//需要对内容进行一次URLEncode
                                encodeContent = URLEncoder.encode(newTopicAnswerJsonStr, "UTF-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            if (encodeContent != null) {
                                MyConfig.getInstance().getMemExchange().setTopicContent(topicId + "_edit_answer", encodeContent);
                                setResult(RESULT_OK);//回调成功
                            }
                        }
                        deleteTopicAnswerDraft();
                        destroyActivityDelay();
                    } else {
                        if (!TextUtils.isEmpty(editTopicAnswer.getMsg())) {
                            showAppMessage(editTopicAnswer.getMsg(), AppMsg.STYLE_ALERT);
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            String msg = bean.getMsg();
            switch (requestId) {
                case Config.MODULE_COMPETITION + 12://提交话题回答
                case Config.MODULE_COMPETITION + 17://编辑话题回答
                    if (!TextUtils.isEmpty(msg)) {
                        showAppMessage(msg, AppMsg.STYLE_ALERT);
                    }
                    break;

                case Config.MODULE_COMPETITION + 15://上传图片
                    if (!TextUtils.isEmpty(msg)) {
                        showAppMessage(msg, AppMsg.STYLE_ALERT);
                    }
                    setUploadStatus(false);
                    break;
            }
        }
        super.processReqError(requestId, error);
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.btn_insert_pic://AddTopicAnswerFragent 提交图片
                CropImage.startPickImageActivity(this);
//                if (addTopicAnswerFragment != null) {
//                    addTopicAnswerFragment.insertImageTag("http://yyssb.ifitmix.com/1003/e75cdc45dfa34d7b8d87d14ddb4d2d47.jpg");
//                }
                break;

            case R.id.tv_search://InviteAnswerFragment 搜索
                doSearch();
                break;
        }
    }


    //region ========================== AddTopicAnswerFragment ==========================

    /**
     * 上传图片
     */
    private void uploadImage(Uri imageUri) {
        if (imageUri == null || TextUtils.isEmpty(imageUri.getPath())) {
            showAppMessage(R.string.activity_add_topic_add_image_fail, AppMsg.STYLE_ALERT);
            return;
        }

        //1.先调整图片大小
        String rawFile = FitmixUtil.getRealPathFromUri(this, imageUri);
        String photoFile = FitmixUtil.getTempPath() + System.currentTimeMillis() + ".jpg";
        boolean isRestricted = ImageHelper.restrictPhotoToScreenWidth(this, rawFile, photoFile);
        Logger.i(Logger.DEBUG_TAG, "imageUri.getPath():" + imageUri.getPath() + ",rawFile:" + rawFile + ",photoFile:" + photoFile + ",isRestricted:" + isRestricted);
        setUploadStatus(true);
        int requestId = DiscoverDataManager.getInstance().uploadImage(isRestricted ? photoFile : rawFile, true);
        registerDataReqStatusListener(requestId);
    }


    /**
     * 设置图片上传状态
     *
     * @param isUploading true:显示忙碌状态,false:隐藏忙碌状态
     */
    public void setUploadStatus(boolean isUploading) {
        if (addTopicAnswerFragment != null) {
            addTopicAnswerFragment.setUploadStatus(isUploading);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;

            case Menu.FIRST://提交答案
                submit();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 提交答案
     */
    private void submit() {
        if (addTopicAnswerFragment != null) {
            String content = addTopicAnswerFragment.getContent();
            if (content != null) {//全为html空格情况
                String cleaned = content.replace("&nbsp;", "");
                if (StringUtils.isBlank(cleaned)) {
                    showAppMessage(R.string.activity_add_topic_answer_empty, AppMsg.STYLE_ALERT);
                    if (addTopicAnswerFragment.getAnswerContentEditor() != null) {
                        addTopicAnswerFragment.getAnswerContentEditor().focusEditor();
                    }
                    return;
                }
            }

            if (TextUtils.isEmpty(content)) {
                showAppMessage(R.string.activity_add_topic_answer_empty, AppMsg.STYLE_ALERT);
                if (addTopicAnswerFragment.getAnswerContentEditor() != null) {
                    addTopicAnswerFragment.getAnswerContentEditor().focusEditor();
                }
                return;
            }
            String contentKey = topicId + "_" + System.currentTimeMillis() + "_answer";
            Logger.i(Logger.DEBUG_TAG, "AddTopicAnswerActivity-->submit content:" + content);
            String encodeContent = content;
            try {//需要对内容进行一次URLEncode
                encodeContent = URLEncoder.encode(content, "UTF-8");
                Logger.i(Logger.DEBUG_TAG, "AddTopicAnswerActivity-->submit Url encode content:" + encodeContent);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            MyConfig.getInstance().getMemExchange().setTopicContent(contentKey, encodeContent);
            if (answerType == ANSWER_TYPE_NEW) {//第一次回答
                int requestId = DiscoverDataManager.getInstance().addTopicAnswer(topicId, contentKey, true);
                registerDataReqStatusListener(requestId);
            } else if (answerType == ANSWER_TYPE_EDIT) {//重新编辑
                int requestId = DiscoverDataManager.getInstance().editTopicAnswer(answerId, contentKey, true);
                registerDataReqStatusListener(requestId);
            }
        } else {
            showAppMessage(R.string.activity_add_topic_submit_answer_fail, AppMsg.STYLE_ALERT);
        }

    }


    //endregion ========================== AddTopicAnswerFragment ==========================

    //region ========================== InviteAnswerFragment ==========================

    /**
     * 搜索邀请人员
     */
    public void doSearch() {
        //TODO
    }

    //endregion ========================== InviteAnswerFragment ==========================

//    @Override
//    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
//        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//            //上传图片
//            uploadImage();
//        } else {
//            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
//        }
//    }

    /**
     * 1秒后销毁Activity
     */
    private void destroyActivityDelay() {
        if (tv_title != null) {
            tv_title.postDelayed(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            }, 1000);
        }
    }

    @Override
    public void onBackPressed() {
        //添加答案界面,如果内容不为空,回退时添加提示
        if (addTopicAnswerFragment != null) {
            final String content = addTopicAnswerFragment.getContent();
            if (!TextUtils.isEmpty(content)) {
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.activity_add_topic_exit_prompt)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE://保存草稿
                                        boolean saved = saveTopicAnswerDraft(content);
                                        if (saved) {
                                            showAppMessage(R.string.activity_add_topic_save_draft_success, AppMsg.STYLE_INFO);
                                            destroyActivityDelay();
                                        } else {
                                            showAppMessage(R.string.activity_add_topic_save_draft_fail, AppMsg.STYLE_INFO);
                                        }
                                        break;

                                    case NEGATIVE:
                                        deleteTopicAnswerDraft();
                                        finish();
                                        break;
                                }
                            }
                        }).show();
                return;
            }
        }
        finish();//结束
    }

    /**
     * 读取回答草稿内容
     *
     * @param fileName 草稿文件名
     */
    public String readTopicAnswerDraft(String fileName) {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(new File(fileName)));
            while ((line = in.readLine()) != null) sb.append(line);
        } catch (FileNotFoundException e) {
            Logger.e(Logger.DEBUG_TAG, "readTopicAnswerDraft error:" + e.getMessage());
        } catch (IOException e) {
            Logger.e(Logger.DEBUG_TAG, "readTopicAnswerDraft error:" + e.getMessage());
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return sb.toString();
    }

    /**
     * 保存回答内容到草稿
     *
     * @param content 回答内容
     * @return true:保存成功,false:保存失败
     */
    private boolean saveTopicAnswerDraft(String content) {
        if (content != null && answerDraftFile != null) {
            FileWriter out = null;
            try {
                File file = new File(answerDraftFile);
                out = new FileWriter(file, false);
                out.write(content);
                out.close();
                return true;
            } catch (IOException e) {
                Logger.e(Logger.DEBUG_TAG, "saveTopicAnswerDraft error:" + e.getMessage());
                return false;
            } finally {
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return false;
    }

    /**
     * 删除草稿
     */
    private void deleteTopicAnswerDraft() {
        if (FileUtils.isFileExist(answerDraftFile)) {
            FileUtils.deleteFile(answerDraftFile);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
//                    Logger.i(Logger.DEBUG_TAG, "AddTopicAnswerActivity uri:" + imageUri);
                    if (imageUri != null) {
                        //上传图片
                        uploadImage(imageUri);
                    }


//                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
//                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
//                        // request permissions and handle the result in onRequestPermissionsResult()
//                        mCropImageUri = imageUri;
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
//                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
//                    } else {
//                      //上传图片
//                      uploadImage();
//                    }
                }
                break;
        }
    }

}
