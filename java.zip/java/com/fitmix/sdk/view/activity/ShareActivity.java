package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.IdRes;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.UserHeartRate;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.User;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.database.WatchSportRecord;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.SharePicAdapter;
import com.fitmix.sdk.view.dialog.datepicker.TypefaceHelper;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.HorizontalListView;
import com.fitmix.sdk.view.widget.ViewUtils;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

/**
 * 分享界面
 */
public class ShareActivity extends BaseActivity {
    private ImageView share_pic_photo, share_pic_base_iv, share_pic_update_iv, share_pic_line_iv, share_photo_pic_preview_iv;
    private HorizontalListView myListView;
    private SharePicAdapter sharePicAdapter;
    private TextView view1_speed_tv, view1_distance_tv, view1_duration_tv, view2_distance_tv,
            view3_cal_tv, view4_days_tv, view5_distance_tv, view5_duration_tv, view5_speed_tv, view5_km_tv;
    private View share_pic_view;
    private View view1, view4, view5;

    private int[] pics = {R.drawable.share_pic_model1, R.drawable.share_pic_model2,
            R.drawable.share_pic_model3, R.drawable.share_pic_model4, R.drawable.share_pic_model5};

    private int[] baseModels = {R.drawable.share_pic_base_model1, R.drawable.share_pic_base_model2,
            R.drawable.share_pic_base_model3, R.drawable.share_pic_base_model4, R.drawable.share_pic_base_model5};
    private String distance, duration, days, speed, cal;
    //调用系统相册-选择图片
    private static final int PHOTOALBUM = 1;
    //调用系统拍照
    private static final int TAKEPHOTO = 2;

    //    private static final int REQUEST_TAKE_PHOTO_PERMISSION = 3;
    private int pic_type = 0;// 0 相机  1 相册

    private String sharePic;//分享图片文件名
//    private String sharePhotoPic;//分享相册图片文件名

    private RadioGroup rg_share_type;//分享类型(数据、照片)
    private RadioGroup rg_data_share_type;//数据分享类型(h5、图片)
    private TextView tv_share;

    private ImageView img_preview;//数据分享类型时,图片预览
    private ImageView share_data_line_iv;//分隔线
    private View btn_select_photo;//照片分享
    private View rootView, share_photo_crop_screen;//截屏用的根布局
    private View dataView, photoView;
    private Bitmap shareBitmap;//图片分享位图
    private Bitmap sharePhotoBitmap;//照片分享位图

    /**
     * 运动记录环境,1:室外,2:室内
     */
    private int environment;

    private int uid;//用户Uid
    private long startTime;//运动开始时间
    private int dataSource;//数据来源 0:乐享动app,1:手表产生

    /**
     * 分享类型,1:室内H5分享,2:室内截图分享,3:室外H5分享,4:室外截图分享,5:照片分享
     */
    private int shareType;
    /**
     * 字体
     */
    private Typeface typeface_steelfish, typeface_russoOne;

    private RunLogInfo runLog;
    private Login login;//登录信息,包括用户信息和运动天数

    private TextView tv_distance;//运动距离,单位为公里
    private TextView tv_distance_unit;//运动距离单位
    private ImageView img_user_avatar;//用户头像
    private TextView tv_user_name;//用户名
    private TextView tv_start_time;//运动开始时间
    private TextView tv_run_day;//持续运动天数
    private TextView tv_pace;//配速,单位为分钟/公里
    private TextView tv_pace_unit;
    private TextView tv_calorie;//卡路里,单位大卡
    private TextView tv_duration;//运动时长
    private TextView tv_speed;//时速,单位公里/小时
    private TextView tv_speed_unit;//时速,单位公里/小时
    private TextView tv_step;//总步数
    private TextView tv_step_unit;//总步数单位名称
    private TextView tv_bpm;//步频,单位步/每分钟
    private TextView tv_bpm_unit;
    private TextView tv_stride;//步幅,单位米/每步
    private TextView tv_stride_unit;
    private TextView tv_heart_rate;//心率
    private ImageView img_trail;//运动轨迹
    //    private SimpleDraweeView img_qr_code;//app下载二维码
    private boolean isShowPicView = false;
    private float highValue;//最高海拔
    private String maxSpeed;//最高时速
    private double totalUp;//累计爬升
    private double totalDown;//累计下降
    private String avgSpeed;
    private View line4;
    private double fatBurn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        setPageName("ShareActivity");

        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }
        Bundle bundle = intent.getExtras();
        uid = bundle.getInt("uid", 0);
        startTime = bundle.getLong("startTime", 0);
        environment = bundle.getInt("environment", 2);
        dataSource = bundle.getInt("dataSource", 0);
        totalUp = bundle.getDouble("totalUp", 0);//累计爬升

        //手表登山相关数据
        highValue = bundle.getFloat("highValue", 0);//最高海拔

        //手表骑行相关数据
        maxSpeed = bundle.getString("maxSpeed");//最高时速
        avgSpeed = bundle.getString("avgSpeed");
        totalDown = bundle.getDouble("totalDown", 0);//累计下降
        fatBurn = bundle.getDouble("fatBurn", 0);

        sharePic = FitmixUtil.getTempPath() + uid + "_" + startTime + "_share.jpg";
        initData();
        initToolbar();
        initViews();
    }

    /**
     * 获取相关数据
     */
    private void initData() {
        loadUserInfo();
        runLog = new RunLogInfo();
        getRunRecordFromDb(uid, startTime);
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        if (window != null) {
            window.setFormat(PixelFormat.RGBA_8888);
        }
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        if (getAssets() != null) {
            typeface_steelfish = TypefaceHelper.get(this, "SteelFish");
            typeface_russoOne = TypefaceHelper.get(this, "Russo_one");
        }

//        Calendar calendar = Calendar.getInstance();
//        int year = calendar.get(Calendar.YEAR);
//        int month = calendar.get(Calendar.MONTH) + 1;
//        int day = calendar.get(Calendar.DAY_OF_MONTH);

        //region ==================== 显示选择水印布局 ====================
        share_photo_crop_screen = LayoutInflater.from(this).inflate(R.layout.activity_share_pic_photo, null);
        photoView = findViewById(R.id.share_photo_pic_fl);
        share_photo_pic_preview_iv = (ImageView) findViewById(R.id.share_photo_pic_preview_iv);
        share_pic_line_iv = (ImageView) findViewById(R.id.share_pic_line_iv);
        view1 = share_photo_crop_screen.findViewById(R.id.base_model_view1);
        view4 = share_photo_crop_screen.findViewById(R.id.base_model_view4_view);
        view5 = share_photo_crop_screen.findViewById(R.id.base_model_view5_view);
        share_pic_view = share_photo_crop_screen.findViewById(R.id.share_pic_view);
        myListView = (HorizontalListView) findViewById(R.id.share_pic_lv);
        share_pic_photo = (ImageView) share_photo_crop_screen.findViewById(R.id.share_take_photo_iv);
        share_pic_base_iv = (ImageView) share_photo_crop_screen.findViewById(R.id.share_pic_base_iv);
        view1_distance_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view1_distance_tv);
        view1_duration_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view1_duration_time_tv);
        view1_speed_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view1_speed_tv);
        view2_distance_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view2_distance_tv);
        view3_cal_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view3_cal_tv);
        view4_days_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view4_days_tv);
        view5_distance_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view5_distance_tv);
        view5_duration_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view5_durance_time_tv);
        view5_speed_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view5_speed_tv);
        view5_km_tv = (TextView) share_photo_crop_screen.findViewById(R.id.base_model_view5_km_tv);
        share_pic_update_iv = (ImageView) findViewById(R.id.share_pic_update_iv);

        sharePicAdapter = new SharePicAdapter(this);

        sharePicAdapter.setPicsList(pics);
        sharePicAdapter.setSelectIndex(0);
        myListView.setAdapter(sharePicAdapter);

        myListView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sharePicAdapter.setSelectIndex(position);
                share_pic_base_iv.setImageResource(baseModels[position]);
                switch (position) {
                    case 0:
                        view1.setVisibility(View.VISIBLE);

                        view2_distance_tv.setVisibility(View.GONE);
                        view3_cal_tv.setVisibility(View.GONE);
                        view4.setVisibility(View.GONE);
                        view5.setVisibility(View.GONE);
                        break;
                    case 1:
                        view1.setVisibility(View.GONE);

                        view2_distance_tv.setVisibility(View.VISIBLE);

                        view3_cal_tv.setVisibility(View.GONE);
                        view4.setVisibility(View.GONE);
                        view5.setVisibility(View.GONE);
                        break;
                    case 2:
                        view1.setVisibility(View.GONE);
                        view2_distance_tv.setVisibility(View.GONE);

                        view3_cal_tv.setVisibility(View.VISIBLE);
                        view4.setVisibility(View.GONE);
                        view5.setVisibility(View.GONE);
                        break;
                    case 3:
                        view1.setVisibility(View.GONE);
                        view2_distance_tv.setVisibility(View.GONE);
                        view3_cal_tv.setVisibility(View.GONE);

                        view4.setVisibility(View.VISIBLE);
                        view5.setVisibility(View.GONE);
                        break;
                    case 4:
                        view1.setVisibility(View.GONE);
                        view2_distance_tv.setVisibility(View.GONE);
                        view3_cal_tv.setVisibility(View.GONE);
                        view4.setVisibility(View.GONE);

                        view5.setVisibility(View.VISIBLE);
                        break;

                }

                sharePhotoBitmap = getScreenShot(share_photo_crop_screen,
                        ViewUtils.dp2px(ShareActivity.this, 310), ViewUtils.dp2px(ShareActivity.this, 310));
                Logger.d(Logger.DEBUG_TAG, "sharePhotoBitmap=======压缩后图片的大小" + (sharePhotoBitmap.getByteCount() / 1024 / 1024)
                        + "M宽度为" + sharePhotoBitmap.getWidth() + "高度为" + sharePhotoBitmap.getHeight());
                share_photo_pic_preview_iv.setImageBitmap(sharePhotoBitmap);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //不处理
            }
        });

        //设置字体样式
        if (typeface_steelfish != null && typeface_russoOne != null) {
            view1_distance_tv.setTypeface(typeface_steelfish);
            view2_distance_tv.setTypeface(typeface_russoOne);
            view3_cal_tv.setTypeface(typeface_russoOne);
            view4_days_tv.setTypeface(typeface_russoOne);
            view5_distance_tv.setTypeface(typeface_russoOne);
            view1_distance_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 30);//与设计图对应
            view2_distance_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);//与设计图对应
            view3_cal_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);//与设计图对应
            view4_days_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);//与设计图对应
            view5_distance_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 30);//与设计图对应

            view1_speed_tv.setTypeface(typeface_steelfish);
            view5_speed_tv.setTypeface(typeface_russoOne);
            view1_speed_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 30);//与设计图对应
            view5_speed_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);//与设计图对应


            view1_duration_tv.setTypeface(typeface_steelfish);
            view5_duration_tv.setTypeface(typeface_russoOne);
            view5_km_tv.setTypeface(typeface_russoOne);
            view5_km_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12);//与设计图对应
            view5_duration_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);//与设计图对应
            view1_duration_tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 30);//与设计图对应

        }
        //endregion ==================== 显示选择水印布局 ====================

        share_data_line_iv = (ImageView) findViewById(R.id.share_data_line_iv);
        dataView = findViewById(R.id.shareContainer);
        rg_share_type = (RadioGroup) findViewById(R.id.rg_share_type);
        rg_share_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.radio_data://数据类型分享
                        if (rg_data_share_type != null) {
                            switch (rg_data_share_type.getCheckedRadioButtonId()) {
                                case R.id.radio_h5://H5
                                    shareType = (environment == 1) ? 3 : 1;
                                    break;
                                case R.id.radio_screen_shot://图片分享
                                    shareType = (environment == 1) ? 4 : 2;
                                    break;
                            }
                        }
                        showPictureShareLayout(false);
                        break;
                    case R.id.radio_pic://照片分享
                        getPermission(Manifest.permission.CAMERA);
                        showPictureShareLayout(true);
                        shareType = 5;
                        break;
                }
            }
        });

        rg_data_share_type = (RadioGroup) findViewById(R.id.rg_data_share_type);
        rg_data_share_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.radio_h5://H5
                        shareType = (environment == 1) ? 3 : 1;
                        break;
                    case R.id.radio_screen_shot://图片分享
                        shareType = (environment == 1) ? 4 : 2;
                        break;
                }
            }
        });

        tv_share = (TextView) findViewById(R.id.tv_share);
        img_preview = (ImageView) findViewById(R.id.img_preview);
        btn_select_photo = findViewById(R.id.btn_select_photo);


        if (environment == 1) {//室外
            rootView = LayoutInflater.from(this).inflate(R.layout.activity_share_data_outdoor, null);

            //添加室外圣诞背景
//            if (2017 == year && 12 == month && day > 22 && day < 26) {
//                rootView.setBackgroundResource(R.drawable.outdoor_share_bg);
//            }

            img_trail = (ImageView) rootView.findViewById(R.id.img_trail);
            tv_distance = (TextView) rootView.findViewById(R.id.tv_distance);
            tv_distance_unit = (TextView) rootView.findViewById(R.id.tv_distance_unit);
            img_user_avatar =  rootView.findViewById(R.id.img_user_avatar);
            tv_user_name = (TextView) rootView.findViewById(R.id.tv_user_name);
            tv_start_time = (TextView) rootView.findViewById(R.id.tv_start_time);
            tv_run_day = (TextView) rootView.findViewById(R.id.tv_run_day);
            tv_pace = (TextView) rootView.findViewById(R.id.tv_pace);
            tv_pace_unit = (TextView) rootView.findViewById(R.id.tv_pace_unit);
            tv_calorie = (TextView) rootView.findViewById(R.id.tv_calorie);
            tv_duration = (TextView) rootView.findViewById(R.id.tv_duration);
            tv_step = (TextView) rootView.findViewById(R.id.tv_step);
            tv_step_unit = (TextView) rootView.findViewById(R.id.tv_step_unit);
            tv_bpm = (TextView) rootView.findViewById(R.id.tv_bpm);
            tv_bpm_unit = (TextView) rootView.findViewById(R.id.tv_bpm_unit);
            tv_stride = (TextView) rootView.findViewById(R.id.tv_stride);
            tv_stride_unit = (TextView) rootView.findViewById(R.id.tv_stride_unit);
//            img_qr_code = (SimpleDraweeView) rootView.findViewById(R.id.img_qr_code);

            //设置字体样式
            if (typeface_steelfish != null) {

                tv_distance.setTypeface(typeface_steelfish);
                tv_distance.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 90);//与设计图对应
                tv_pace.setTypeface(typeface_steelfish);
                tv_pace.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_calorie.setTypeface(typeface_steelfish);
                tv_calorie.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_duration.setTypeface(typeface_steelfish);
                tv_duration.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_step.setTypeface(typeface_steelfish);
                tv_step.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_bpm.setTypeface(typeface_steelfish);
                tv_bpm.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_stride.setTypeface(typeface_steelfish);
                tv_stride.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
            }
            shareType = 4;//室外时默认截图分享
        } else {
            rootView = LayoutInflater.from(this).inflate(R.layout.activity_share_data_indoor, null);
            //添加室内圣诞背景
//            if (2017 == year && 12 == month && day > 22 && day < 26) {
//                rootView.setBackgroundResource(R.drawable.indoor_share_bg);
//            }

            tv_distance = (TextView) rootView.findViewById(R.id.tv_distance);
            tv_distance_unit = (TextView) rootView.findViewById(R.id.tv_distance_unit);
            img_user_avatar =  rootView.findViewById(R.id.img_user_avatar);
            tv_user_name = (TextView) rootView.findViewById(R.id.tv_user_name);
            tv_start_time = (TextView) rootView.findViewById(R.id.tv_start_time);
            tv_run_day = (TextView) rootView.findViewById(R.id.tv_run_day);
            tv_pace = (TextView) rootView.findViewById(R.id.tv_pace);
            tv_pace_unit = (TextView) rootView.findViewById(R.id.tv_pace_unit);
            tv_calorie = (TextView) rootView.findViewById(R.id.tv_calorie);
            tv_duration = (TextView) rootView.findViewById(R.id.tv_duration);
            tv_speed = (TextView) rootView.findViewById(R.id.tv_speed);
            tv_speed_unit = (TextView) rootView.findViewById(R.id.tv_speed_unit);
            tv_step = (TextView) rootView.findViewById(R.id.tv_step);
            tv_step_unit = (TextView) rootView.findViewById(R.id.tv_step_unit);
            tv_bpm = (TextView) rootView.findViewById(R.id.tv_bpm);
            tv_bpm_unit = (TextView) rootView.findViewById(R.id.tv_bpm_unit);
            tv_stride = (TextView) rootView.findViewById(R.id.tv_stride);
            tv_stride_unit = (TextView) rootView.findViewById(R.id.tv_stride_unit);
            tv_heart_rate = (TextView) rootView.findViewById(R.id.tv_heart_rate);
            line4 = rootView.findViewById(R.id.line4_view);
//            img_qr_code = (SimpleDraweeView) rootView.findViewById(R.id.img_qr_code);

            //设置字体样式
            if (typeface_steelfish != null) {
                tv_distance.setTypeface(typeface_steelfish);
                tv_distance.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 100);//与设计图对应
                tv_pace.setTypeface(typeface_steelfish);
                tv_pace.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_calorie.setTypeface(typeface_steelfish);
                tv_calorie.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_duration.setTypeface(typeface_steelfish);
                tv_duration.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_speed.setTypeface(typeface_steelfish);
                tv_speed.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_step.setTypeface(typeface_steelfish);
                tv_step.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_bpm.setTypeface(typeface_steelfish);
                tv_bpm.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_stride.setTypeface(typeface_steelfish);
                tv_stride.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
                tv_heart_rate.setTypeface(typeface_steelfish);
                tv_heart_rate.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 32);//与设计图对应
            }
            shareType = 2;//室内时默认截图分享
        }

//        String appDownload = PrefsHelper.with(this, Config.PREFS_SPORT).read(Config.SP_KEY_APP_DOWNLOAD_QR);
//        if (!TextUtils.isEmpty(appDownload)) {//app下载二维码,暂时不从服务器下载
//            if (img_qr_code != null) {
//                img_qr_code.setImageURI(Uri.parse(appDownload));
//            }
//        }
    }

    /**
     * 根据个人信息数据、运动数据刷新预览图片
     */
    private void refreshPreview() {
        if (login != null) {
            int day = login.getDayNum();//运动天数
            if (tv_run_day != null) {
                tv_run_day.setText(String.format(getString(R.string.activity_share_run_day_format), day));
            }

            User user = login.getUser();
            if (user != null) {//设置个人信息
                if (tv_user_name != null) {
                    tv_user_name.setText(user.getName());//昵称
                }
            }

        }

        if (runLog != null) {
            String localFile = FitmixUtil.getPhotoPath() + runLog.getUid() + "_avatar.jpg";
            if (FileUtils.isFileExist(localFile)) {//本地有图片,则从本地加载
                if (img_user_avatar != null) {//头像
                    img_user_avatar.setImageURI(Uri.fromFile(new File(localFile)));
                }
            } else {
                if (img_user_avatar != null) {//头像
                    img_user_avatar.setImageResource(R.drawable.default_avatar);
                   // img_user_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
                }
            }

            if (tv_start_time != null) {//运动日期
                SimpleDateFormat formatterTime = new SimpleDateFormat("yyyy-MM-dd HH:mm",
                        Locale.getDefault());

                Date curDate = new Date(runLog.getStartTime());
                String sTime = formatterTime.format(curDate);
                tv_start_time.setText(sTime);
            }

            if (tv_duration != null) {//时长
                tv_duration.setText(FormatUtil.formatRunTime(runLog.getRunTime() / 1000));
            }

            if (tv_calorie != null) {//卡路里
                tv_calorie.setText(String.valueOf(runLog.getCalorie()));
            }


            if (tv_speed != null) {//平均速度
                long distance = runLog.getDistance();
                long duration = runLog.getRunTime() / 1000;
                double speed = (duration == 0 ? 0 : 3.6f * distance / duration);
                tv_speed.setText(String.format("%.2f", speed));
            }


            if (!TextUtils.isEmpty(runLog.getHeartRateDate())) {//心率
                UserHeartRate userHeartRate = JsonHelper.getObject(runLog.getHeartRateDate(), UserHeartRate.class);
                if (userHeartRate != null) {
                    if (tv_heart_rate != null) {
                        tv_heart_rate.setText(String.valueOf((int) userHeartRate.getHeartRateAvg()));
                    }
                }
            }

            if (img_trail != null) {//地图轨迹
                String trail = Config.PATH_LOCAL_TEMP + runLog.getUid() + "_" + runLog.getStartTime() + ".jpg";
                if (FileUtils.isFileExist(trail)) {//本地有图片,则从本地加载
                    img_trail.setImageURI(Uri.fromFile(new File(trail)));
                    Logger.i(Logger.DEBUG_TAG, "setInfo img_trail set!!!!");
                }
            }

            int watchSportType = runLog.getWatchSportType();
            if (watchSportType == WatchDataProtocol.SPORTS_TYPE_MOUNTAINS_CLIMB) {//手表爬山 登山
                if (tv_distance != null) {//最高海拔
                    tv_distance.setText(FormatUtil.getIntNumber(highValue));
                    tv_distance_unit.setText(getResources().getString(R.string.meter));
                }
                if (tv_step != null) {//步数
                    tv_step.setText(String.valueOf(runLog.getStep()));
                }
                if (tv_bpm != null) {//累计爬升
                    tv_bpm.setText(String.valueOf(totalUp));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totalup);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_bpm.setCompoundDrawables(null, null, image, null);
                    tv_bpm_unit.setText(getResources().getString(R.string.meter));
                }

                if (tv_pace != null) {//里程
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_pace.setText("0.00");
                    } else {
                        tv_pace.setText(FormatUtil.formatDistance(runLog.getDistance()));
                    }
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totaldistance);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_pace.setCompoundDrawables(null, null, image, null);
                    tv_pace_unit.setText(getResources().getString(R.string.activity_run_record_data_analyse_km));
                }

                if (tv_stride != null) {//时速
                    tv_stride.setText(avgSpeed);
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_average_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_stride.setCompoundDrawables(null, null, image, null);
                    tv_stride_unit.setText(getResources().getString(R.string.activity_run_record_speed_unit));
                }

            } else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB) {//手表 攀岩
                line4.setVisibility(View.GONE);
                if (tv_distance != null) {//最高海拔
                    tv_distance.setText(FormatUtil.getIntNumber(highValue));
                    tv_distance_unit.setText(getResources().getString(R.string.meter));
                }
                if (tv_step != null) {//累计爬升
                    tv_step.setText(String.valueOf(totalUp));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totalup);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_step.setCompoundDrawables(null, null, image, null);
                    tv_step_unit.setText(getResources().getString(R.string.watch_run_log_total_up) + getResources().getString(R.string.meter));
                }
                if (tv_bpm != null) {//燃脂
                    tv_bpm.setText(String.valueOf(runLog.getConsumeFat()));
                    Drawable image = getResources().getDrawable(R.drawable.activity_share_calorie);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_bpm.setCompoundDrawables(null, null, image, null);
                    tv_bpm_unit.setText(getResources().getString(R.string.run_main_heart_rate_fat_burn) + getResources().getString(R.string.run_main_heart_rate_fat_burn_unit));
                }


                if (tv_pace != null) {//里程
                    tv_pace.setText(FormatUtil.formatRunTargetPace((long) (runLog.getRunTime() / (runLog.getMostHigh() - runLog.getTroughAltitude()) / 100)));
                }

                if (tv_speed != null) {//时速
                    if (runLog.getRealRunTime() > 0) {
                        tv_speed.setText(FormatUtil.getTwoPointsNumber(3600f * totalUp / runLog.getRealRunTime()));
                    } else {
                        tv_speed.setText(FormatUtil.getTwoPointsNumber(3600f * totalUp / runLog.getRunTime()));
                    }
                    Drawable image = getResources().getDrawable(R.drawable.average_up_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_speed.setCompoundDrawables(null, null, image, null);
                    tv_speed_unit.setText(getResources().getString(R.string.fragment_data_average_speed_up) + ":" + getResources().getString(R.string.activity_run_record_speed_unit));
                }

            } else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR) {//室内游泳
                line4.setVisibility(View.GONE);
                if (tv_distance != null) {//距离
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_distance.setText("0.00");
                    } else {
                        tv_distance.setText(FormatUtil.getIntNumber(runLog.getDistance()));
                    }
                }
                tv_distance_unit.setText(getResources().getString(R.string.meter));
                tv_step.setText(String.valueOf(runLog.getSwimTrips()));
                Drawable image_swim = getResources().getDrawable(R.drawable.share_activity_totalup);
                image_swim.setBounds(0, 0, image_swim.getMinimumWidth(), image_swim.getMinimumHeight());
                tv_step.setCompoundDrawables(null, null, image_swim, null);
                tv_step_unit.setText(getResources().getString(R.string.activity_reentry_times));

                if (tv_bpm != null) {//步频
                    tv_bpm.setText(String.valueOf(runLog.getConsumeFat()));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totaldown);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_bpm.setCompoundDrawables(null, null, image, null);
                    tv_bpm_unit.setText(getResources().getString(R.string.run_main_heart_rate_fat_burn) + getResources().getString(R.string.run_main_heart_rate_fat_burn_unit));
                }

                if (tv_pace != null) {//配速
                    if (runLog.getRealRunTime() > 0) {
                        if (runLog.getDistance() > 0){
                            tv_pace.setText(FormatUtil.formatRunTargetPace(runLog.getRealRunTime() / runLog.getDistance() / 10));
                        }else {
                            tv_pace.setText("99'59''");
                        }
                    } else {
                        if (runLog.getDistance() > 0){
                            tv_pace.setText(FormatUtil.formatRunTargetPace(runLog.getRunTime() / runLog.getDistance() / 10));
                        }else {
                            tv_pace.setText("99'59''");
                        }
                    }
                }

                if (tv_stride != null) {//平均时速
                    tv_stride.setText(avgSpeed);
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_average_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_stride.setCompoundDrawables(null, null, image, null);
                    tv_stride_unit.setText(getResources().getString(R.string.activity_run_record_speed_unit));
                }

            } else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_SWIM_OUTDOOR) {//公共水域
                if (tv_distance != null) {//距离
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_distance.setText("0.00");
                    } else {
                        tv_distance.setText(FormatUtil.getIntNumber(runLog.getDistance()));
                    }
                }
                tv_distance_unit.setText(getResources().getString(R.string.meter));
                tv_step.setText(String.valueOf(runLog.getSwimTrips()));
                Drawable image_swim = getResources().getDrawable(R.drawable.zhe_fan);
                image_swim.setBounds(0, 0, image_swim.getMinimumWidth(), image_swim.getMinimumHeight());
                tv_step.setCompoundDrawables(null, null, image_swim, null);
                tv_step_unit.setText(getResources().getString(R.string.activity_reentry_times));

                if (tv_bpm != null) {//步频
                    tv_bpm.setText(String.valueOf(runLog.getConsumeFat()));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totaldown);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_bpm.setCompoundDrawables(null, null, image, null);
                    tv_bpm_unit.setText(getResources().getString(R.string.run_main_heart_rate_fat_burn) + getResources().getString(R.string.run_main_heart_rate_fat_burn_unit));
                }

                if (tv_pace != null) {//配速
                    if (runLog.getRealRunTime() > 0) {
                        if (runLog.getDistance() > 0){
                            tv_pace.setText(FormatUtil.formatRunTargetPace(runLog.getRealRunTime() / runLog.getDistance() / 10));
                        }else {
                            tv_pace.setText("99'59''");
                        }

                    } else {
                        if (runLog.getDistance() > 0){
                            tv_pace.setText(FormatUtil.formatRunTargetPace(runLog.getRunTime() / runLog.getDistance() / 10));
                        }else {
                            tv_pace.setText("99'59''");
                        }
                    }
                }

                if (tv_pace != null) {//平均时速
                    tv_stride.setText(avgSpeed);
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_average_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_stride.setCompoundDrawables(null, null, image, null);
                    tv_stride_unit.setText(getResources().getString(R.string.activity_run_record_speed_unit));
                }

            } else if (watchSportType == WatchDataProtocol.SPORTS_TYPE_RIDE || watchSportType == WatchDataProtocol.SPORTS_TYPE_RIDE_CROSSCOUNTRY) {//手表骑行
                if (tv_distance != null) {//距离
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_distance.setText("0.00");
                    } else {
                        tv_distance.setText(FormatUtil.formatDistance(runLog.getDistance()));
                    }
                }
                if (tv_step != null) {//累计爬升
                    tv_step.setText(String.valueOf(totalUp));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totalup);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_step.setCompoundDrawables(null, null, image, null);
                    tv_step_unit.setText(getResources().getString(R.string.meter));
                }

                if (tv_bpm != null) {//累计下降
                    tv_bpm.setText(String.valueOf(totalDown));
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_totaldown);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_bpm.setCompoundDrawables(null, null, image, null);
                    tv_bpm_unit.setText(getResources().getString(R.string.meter));
                }
                if (tv_pace != null) {//平均时速
                    tv_pace.setText(avgSpeed);
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_average_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_pace.setCompoundDrawables(null, null, image, null);
                    tv_pace_unit.setText(getResources().getString(R.string.activity_run_record_speed_unit));
                }

                if (tv_stride != null) {//最高时速
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_stride.setText("0.00");
                    } else {
                        tv_stride.setText(maxSpeed);
                    }
                    Drawable image = getResources().getDrawable(R.drawable.share_activity_max_speed);
                    image.setBounds(0, 0, image.getMinimumWidth(), image.getMinimumHeight());
                    tv_stride.setCompoundDrawables(null, null, image, null);
                    tv_stride_unit.setText(getResources().getString(R.string.activity_run_record_speed_unit));
                }
            } else {//其他（户内与户外徒步）
                if (tv_distance != null) {//距离
                    long distance = runLog.getDistance();
                    if (distance <= 0) {
                        tv_distance.setText("0.00");
                    } else {
                        tv_distance.setText(FormatUtil.formatDistance(runLog.getDistance()));
                    }
                }
                if (tv_step != null) {//步数
                    tv_step.setText(String.valueOf(runLog.getStep()));
                }

                if (tv_bpm != null) {//步频
                    int bpm;
                    if (runLog.getRealRunTime() > 0) {
                        bpm = (int) (runLog.getStep() / (runLog.getRealRunTime() / 1000 / 60D));
                    } else {
                        bpm = (int) (runLog.getStep() / (runLog.getRunTime() / 1000 / 60D));
                    }
                    tv_bpm.setText(String.valueOf(bpm));
                }

                if (tv_pace != null) {//配速
                    if (runLog.getRealRunTime() > 0) {
                        tv_pace.setText(FormatUtil.formatSpeed(runLog.getDistance(), runLog.getRealRunTime() / 1000));
                    } else {
                        tv_pace.setText(FormatUtil.formatSpeed(runLog.getDistance(), runLog.getRunTime() / 1000));
                    }
                }

                if (tv_stride != null) {//步幅
                    float stride;
                    if (runLog.getStep() > 0) {
                        stride = runLog.getDistance() * 1.0f / (runLog.getStep());
                    } else {
                        stride = 0;
                    }
                    tv_stride.setText(FormatUtil.getTwoPointsNumber(stride));
                }
            }


        }

        if (rootView != null) {
            int width = ViewUtils.dp2px(ShareActivity.this, 375);
            int height = ViewUtils.dp2px(ShareActivity.this, 667);
            shareBitmap = getScreenShot(rootView, width, height);
            Logger.i(Logger.DEBUG_TAG, "ShareActivity-->refreshPreview bitmap is null:" + (shareBitmap == null));
            if (img_preview != null && shareBitmap != null) {
                img_preview.setImageBitmap(shareBitmap);
            }
        }

    }

    /**
     * 是否显示照片分享相关的布局
     *
     * @param show true:是,false:否
     */
    private void showPictureShareLayout(boolean show) {
        if (show) {
            if (rg_data_share_type != null) {//隐藏数据分享类型选择
                rg_data_share_type.setVisibility(View.GONE);
            }
            if (tv_share != null) {
                tv_share.setVisibility(View.GONE);
            }
            if (img_preview != null) {
                img_preview.setVisibility(View.GONE);
            }
            if (btn_select_photo != null) {
                btn_select_photo.setVisibility(View.VISIBLE);
            }
        } else {
            if (rg_data_share_type != null) {//显示数据分享类型选择
                rg_data_share_type.setVisibility(View.VISIBLE);
            }

            if (tv_share != null) {
                tv_share.setVisibility(View.VISIBLE);
            }

            if (img_preview != null) {
                img_preview.setVisibility(View.VISIBLE);
            }
            if (btn_select_photo != null) {
                btn_select_photo.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 2://邮箱或者手机账号登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录
                login = JsonHelper.getObject(result, Login.class);
                refreshPreview();
                break;

            case Config.MODULE_USER + 61://完成每日分享运动记录金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);

                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_RECORD, System.currentTimeMillis());//设置完成任务时间
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }

    }


    /**
     * 加载个人信息
     */
    private void loadUserInfo() {
        //1.加载个人信息(在登录接口中)
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (!TextUtils.isEmpty(email) || !TextUtils.isEmpty(password)) {
                int requestId = UserDataManager.getInstance().emailLogin(email, password);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        }
    }

    /**
     * 从数据库中获取跑步记录
     */
    private void getRunRecordFromDb(int uid, long startTime) {
        if (dataSource == 1) {//手表
            WatchSportDataHelper.asyncGetRecords(this, uid, startTime, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    final WatchSportRecord watchSportRecord = (WatchSportRecord) operation.getResult();
                    if (watchSportRecord != null) {//只设置本页面需要的数据
                        runLog.setUid(watchSportRecord.getUid());//uid
                        runLog.setStartTime(watchSportRecord.getStartTime());//开始时间
                        runLog.setDistance(watchSportRecord.getDistance());//运动距离,单位米
                        runLog.setRunTime(watchSportRecord.getSportTime() * 1000);//运动时长,单位毫秒
                        runLog.setStep(watchSportRecord.getStep());//步数
                        runLog.setCalorie(watchSportRecord.getCalorie());//卡路里
                        runLog.setWatchSportType(watchSportRecord.getSportType());//手表运动类型
                        runLog.setSwimStyle(watchSportRecord.getSwimStyle());
                        runLog.setSwimPoolLength(watchSportRecord.getSwimPoolLength());
                        runLog.setSwimTrips(watchSportRecord.getSwimTrips());
                        runLog.setMostHigh(watchSportRecord.getPeakAltitude());
                        runLog.setTroughAltitude(watchSportRecord.getTroughAltitude());
                        runLog.setConsumeFat(watchSportRecord.getFatBurn());
                        UserHeartRate userHeartRate = new UserHeartRate();
                        int avgHr = watchSportRecord.getAvgSportHR();
                        userHeartRate.setHeartRateAvg(avgHr);
                        String heartData = JsonHelper.createJsonString(userHeartRate);
                        if (heartData != null) {
                            runLog.setHeartRateDate(heartData);//心率data
                        }

                        if (runLog.getRunTime() > 0) {
                            int bpm = (int) (runLog.getStep() * 60000 / runLog.getRunTime());
                            runLog.setBpm(bpm);//平均步频(每分钟步数)
                        }

                        //加载完成后,初始化界面
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Logger.i(Logger.DEBUG_TAG, "ShareActivity-->getRunRecordFromDb watch finish..");
                                refreshPreview();
                            }
                        });
                    }
                }
            });
        } else {
            SportRecordsHelper.asyncGetRunRecords(this, uid, startTime, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    SportRecord sportRecord = (SportRecord) operation.getResult();
                    if (sportRecord != null) {
                        runLog.setUid(sportRecord.getUid());//uid
                        runLog.setStartTime(sportRecord.getStartTime());//开始时间
                        runLog.setEndTime(sportRecord.getEndTime());//结束时间
                        runLog.setType(sportRecord.getType());//运动类型(跑步,骑行),目前没有用到,默认0即可
                        runLog.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                        runLog.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                        runLog.setLocationType(sportRecord.getLocationType());//定位类型,1:GPS定位,2:LBS定位
                        runLog.setDistance(sportRecord.getDistance());//运动距离,单位米
                        runLog.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                        runLog.setStartLat(sportRecord.getStartLat());//开始点经度
                        runLog.setStartLng(sportRecord.getStartLng());//开始点经度
                        runLog.setEndLat(sportRecord.getEndLat());//结束点纬度
                        runLog.setEndLng(sportRecord.getEndLng());//结束点经度
                        runLog.setStep(sportRecord.getStep());//步数
                        runLog.setCalorie(sportRecord.getCalorie());//卡路里
                        runLog.setStepData(sportRecord.getStepData());//计步文件下载url
                        runLog.setTrail(sportRecord.getTrail());//轨迹文件下载url
                        runLog.setUploaded(sportRecord.getUploaded());
                        runLog.setBpmMatch(sportRecord.getBpmMatch() == null ? 0 : sportRecord.getBpmMatch());//步数是否异常,-2表示异常
                        if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {
                            runLog.setHeartRateDate(sportRecord.getHeartRateDate());//心率data
                        }
                        runLog.setConsumeFat(sportRecord.getConsumeFat());//燃脂量

                        //加载完成后,初始化界面
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Logger.i(Logger.DEBUG_TAG, "ShareActivity-->getRunRecordFromDb app finish..");
                                refreshPreview();
                            }
                        });

                    }
                }
            });
        }
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.tv_share://继续分享
                share();
                break;

            case R.id.btn_select_photo://选择图片
                if (permissionIsGranted(Manifest.permission.CAMERA)) {
                    CropImage.startPickImageActivity(this);
                } else {
                    getPermission(Manifest.permission.CAMERA);
                }
                break;

            case R.id.share_pic_update_iv://更换图片
                if (pic_type == 1) {//调用相册
                    Intent intent = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, PHOTOALBUM);
                } else {//调用相机
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    Uri outputFileUri = CropImage.getCaptureImageOutputUri(this);
                    Logger.i(Logger.DEBUG_TAG, "调用相机 outputFileUri:" + outputFileUri);
                    if (outputFileUri != null) {
                        Logger.i(Logger.DEBUG_TAG, "outputFileUri is not null:" + outputFileUri);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
                    }
                    startActivityForResult(intent, TAKEPHOTO);
                }
                break;
        }
    }


    /**
     * 获取截屏
     *
     * @param view   要截屏的view
     * @param width  View的宽度,单位为像素,如果View有完整展示在界面上可以传0
     * @param height View的高度,单位为像素,如果View有完整展示在界面上可以传0
     * @return 位图
     */
    private Bitmap getScreenShot(View view, int width, int height) {
        if (view == null)
            return null;
        view.clearFocus();
        view.setPressed(false);
//        boolean willNotCache = view.willNotCacheDrawing();
        view.setWillNotCacheDrawing(false);
        //清除背景色
        int color = view.getDrawingCacheBackgroundColor();
        view.setDrawingCacheBackgroundColor(0);
        if (color != 0) {
            view.destroyDrawingCache();
        }
        if (width > 0 && height > 0) {
            //测量并布局
            view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        }

        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        view.draw(c);

//        view.buildDrawingCache();
//        Bitmap cacheBitmap = view.getDrawingCache();
//        if (cacheBitmap == null) {
//            return null;
//        }
//        Bitmap bitmap = Bitmap.createBitmap(cacheBitmap);
//        view.destroyDrawingCache();
//        view.setWillNotCacheDrawing(willNotCache);
//        view.setDrawingCacheBackgroundColor(color);
        return bitmap;
    }

    //region ============================== 分享相关 ==============================

    /**
     * 数据类型分享操作
     */
    private void share() {
        if (runLog == null) return;

        ShareManager share = new ShareManager(this);
        String baseUrl = PrefsHelper.with(this, Config.PREFS_SPORT).read(Config.SP_KEY_RUN_SHARE_URL);
        if (!TextUtils.isEmpty(baseUrl)) {
            String shareUrl = baseUrl + "?startTime=" + runLog.getStartTime() + "&uid=" + runLog.getUid();
            share.setUrl(shareUrl);
        }
        String distance = String.format(getString(R.string.share_distance), FormatUtil.formatDistance(runLog.getDistance()));
        String time = FormatUtil.formatTimeChinaStyle(runLog.getRunTime() / 1000);
        String pace = FormatUtil.formatSpeed(runLog.getDistance(), runLog.getRunTime() / 1000);
        String step = String.format(getString(R.string.share_step), runLog.getStep());
        String sTitle = String.format(getResources().getString(R.string.my_score), runLog.getCalorie());// 分享标题
        String sContent = String.format(getResources().getString(R.string.share_content), distance, time, pace, step);

        String avatar = FitmixUtil.getPhotoPath() + runLog.getUid() + "_avatar.jpg";//头像
        String sharePhotoPic;
        switch (shareType) {
            case 1://室内H5分享
            case 3://室外H5分享
                share.setContentType(ShareManager.SHARE_TYPE_WEB_PAGE);
                share.setFilename(avatar);//头像
                break;

            case 2://室内截图分享
            case 4://室外截图分享
                if (shareBitmap != null && !TextUtils.isEmpty(sharePic)) {//保存相应的分享图片
                    ImageHelper.saveBitmap2File(shareBitmap, sharePic);
                }
                if (TextUtils.isEmpty(sharePic) || !FileUtils.isFileExist(sharePic)) {
                    return;
                }
                share.setContentType(ShareManager.SHARE_TYPE_PIC);
                share.setFilename(sharePic);//截图
                break;

            case 5://照片分享
                sharePhotoPic = FitmixUtil.getTempPath() + uid + "_" + System.currentTimeMillis() + "_share_photo.jpg";
                if (sharePhotoBitmap != null && !TextUtils.isEmpty(sharePhotoPic)) {//保存相应的分享图片
                    ImageHelper.saveBitmap2File(sharePhotoBitmap, sharePhotoPic);
                }
                if (TextUtils.isEmpty(sharePhotoPic) || !FileUtils.isFileExist(sharePhotoPic)) {
                    return;
                }
                share.setContentType(ShareManager.SHARE_TYPE_PIC);
                share.setFilename(sharePhotoPic);//截图
                break;
        }
//        Logger.i(Logger.DEBUG_TAG, "share type:" + shareType
//                + "\nsharePic:" + sharePic != null ? sharePic : "" + "\nsharePhotoPic:" + sharePhotoPic != null ? sharePhotoPic : "");
        share.setContent(sContent);
        share.setTitle(sTitle);
        share.setShareCategory(ShareManager.SHARE_CATEGORY_RUN_SCORE);//分享类别为运动成绩,用于友盟分享统计
        share.share();
    }

    /**
     * 启动图片剪裁界面
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(1, 1)
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://返回
                if (isShowPicView) {
                    showSelectLastView();
                    return true;
                } else {
                    finish();
                }
                break;
        }
        return false;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                if (isShowPicView) {
                    showSelectLastView();
                } else {
                    finish();
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void handlePermissionAllowed(String permissionName) {
        super.handlePermissionAllowed(permissionName);
        if (Manifest.permission.CAMERA.equals(permissionName)) {
            CropImage.startPickImageActivity(this);
        }
    }

    @Override
    protected void handlePermissionForbidden(String permissionName) {
        super.handlePermissionForbidden(permissionName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Logger.i(Logger.DEBUG_TAG, "ShareActivity onActivityResult resultCode:" + resultCode + ",requestCode:" + requestCode + ",data is null:" + (data == null));
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    Logger.i(Logger.DEBUG_TAG, "ShareActivity-->onActivityResult PICK_IMAGE_CHOOSER_REQUEST_CODE imageUri:" + imageUri);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
//                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        Logger.e(Logger.DEBUG_TAG, "data:" + (data == null));
                        if (data == null) {
                            pic_type = 0;
                        } else {
                            pic_type = 1;
                        }
                        startCropImageActivity(imageUri);
                    }
                }
                break;

            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    Bitmap bitmap1 = ImageHelper.adjustPhotoToFitSize(bitmap, ViewUtils.dp2px(this, 315), ViewUtils.dp2px(this, 315));
//                    Logger.e(Logger.DEBUG_TAG, "bitmap=======压缩后图片的大小" + (bitmap1.getByteCount() / 1024 / 1024)
//                            + "M宽度为" + bitmap1.getWidth() + "高度为" + bitmap1.getHeight());

                    if (bitmap1 != null) {//use bitmap
                        share_pic_photo.setImageBitmap(bitmap1);

                        cal = String.valueOf(runLog.getCalorie());
                        if (login != null) {
                            days = String.valueOf(login.getDayNum());
                        }
                        Logger.d(Logger.DEBUG_TAG, "day:" + days);
                        speed = FormatUtil.formatSpeed(runLog.getDistance(), runLog.getRunTime() / 1000);
                        duration = FormatUtil.formatRunTime(runLog.getRunTime() / 1000);
                        distance = FormatUtil.formatDistance(runLog.getDistance());

                        isShowPicView = true;
                        showSelectWaterView();
                    }

                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

            case PHOTOALBUM:
                if (resultCode == Activity.RESULT_OK && data != null) {
                    pic_type = 1;
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    startCropImageActivity(imageUri);
                }

                break;
            case TAKEPHOTO:
//                if (resultCode == Activity.RESULT_OK && data != null) {  去掉判断，由于各个手机系统拍照返回resultCode不一定是ResultOK
                pic_type = 0;
                Uri imageUri = CropImage.getPickImageResultUri(this, data);
//                    Logger.i(Logger.DEBUG_TAG, "ShareActivity-->onActivityResult TAKEPHOTO imageUri:" + imageUri);
                startCropImageActivity(imageUri);
//                }
                break;

            default:// 三方分享
                if (data == null) return;
                String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                switch (requestCode) {
                    case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                    case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                    case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                    case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                    case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        if (!TextUtils.isEmpty(resultStr)) {
                            showAppMessage(resultStr, AppMsg.STYLE_INFO);
                        }
                        if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                            finishShareRecordCoinTask();//完成每日分享运动记录金币任务
                        }
                        break;
                }
                break;
        }
    }

    /**
     * 显示水印布局
     */
    private void showSelectWaterView() {
        photoView.setVisibility(View.VISIBLE);
        share_pic_line_iv.setVisibility(View.VISIBLE);
        share_pic_view.setVisibility(View.VISIBLE);
        share_pic_update_iv.setVisibility(View.VISIBLE);
        myListView.setVisibility(View.VISIBLE);
        tv_share.setVisibility(View.VISIBLE);


        share_data_line_iv.setVisibility(View.GONE);
        dataView.setVisibility(View.GONE);
        rg_data_share_type.setVisibility(View.GONE);
        rg_share_type.setVisibility(View.GONE);
        btn_select_photo.setVisibility(View.GONE);

        view4_days_tv.setText(days);
        view1_distance_tv.setText(distance);
        view2_distance_tv.setText(distance);
        view5_distance_tv.setText(distance);

        view1_duration_tv.setText(duration);
        view5_duration_tv.setText(duration);

        view1_speed_tv.setText(speed);
        view5_speed_tv.setText(speed);

        view3_cal_tv.setText(cal);

        sharePhotoBitmap = getScreenShot(share_photo_crop_screen,
                ViewUtils.dp2px(ShareActivity.this, 310), ViewUtils.dp2px(ShareActivity.this, 310));
        Logger.d(Logger.DEBUG_TAG, "sharePhotoBitmap=======压缩后图片的大小" + (sharePhotoBitmap.getByteCount() / 1024 / 1024)
                + "M宽度为" + sharePhotoBitmap.getWidth() + "高度为" + sharePhotoBitmap.getHeight());
        share_photo_pic_preview_iv.setImageBitmap(sharePhotoBitmap);
    }

    /**
     * 显示原先布局
     */
    private void showSelectLastView() {
        share_pic_view.setVisibility(View.GONE);
        share_pic_update_iv.setVisibility(View.GONE);
        myListView.setVisibility(View.GONE);
        tv_share.setVisibility(View.GONE);
        photoView.setVisibility(View.GONE);
        share_pic_line_iv.setVisibility(View.GONE);
        btn_select_photo.setVisibility(View.GONE);

        share_data_line_iv.setVisibility(View.VISIBLE);
        dataView.setVisibility(View.VISIBLE);
        rg_share_type.setVisibility(View.VISIBLE);
        rg_share_type.check(R.id.radio_data);//重新选择数据
        rg_data_share_type.setVisibility(View.VISIBLE);
        isShowPicView = false;
    }

    //endregion ============================== 分享相关 ==============================

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动记录金币任务
     */
    private void finishShareRecordCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_RECORD, 0);
        Logger.i(Logger.DEBUG_TAG, "finishShareRecordCoinTask is today:" + FitmixUtil.isToday(lastShareTime));
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareRecordCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }


    //endregion ============================= 金币任务 =============================

}
