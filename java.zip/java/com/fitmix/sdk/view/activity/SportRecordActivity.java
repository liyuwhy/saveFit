package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.bean.SkipLogInfo;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.database.WatchSportDataHelper;
import com.fitmix.sdk.model.database.WatchSportRecord;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.task.SyncRunRecordTask;
import com.fitmix.sdk.task.SyncSkipRecordTask;
import com.fitmix.sdk.task.SyncWatchRecordTask;
import com.fitmix.sdk.view.adapter.SportRecordActivityListAdapter;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.bean.WatchSportLog;
import com.google.gson.reflect.TypeToken;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class SportRecordActivity extends BaseActivity {

    //private RunLogListAdapter adapter;
    private SportRecordActivityListAdapter adapter;
    private TextView btn_sync_run_record;
    private MyHandler mHandler;

    private List<RunLogInfo> runLogInfoList;//跑步记录集合,乐享动app产生的+手表产生的
    private List<RunLogInfo> appRunLogInfoList;//乐享动app产生的记录
    private List<RunLogInfo> watchRunLogInfoList;//手表产生的记录

    public static class MyHandler extends Handler {
        private WeakReference<BaseActivity> mActivity;

        public MyHandler(BaseActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            if (mActivity != null && mActivity.get() != null) {
                SportRecordActivity activity = (SportRecordActivity) mActivity.get();
                if (activity != null) {
                    int resultCode = msg.arg1;
                    long startTime = 0;
                    if (msg.obj != null) {
                        startTime = (long) msg.obj;
                    }
                    activity.updateRunLogList(resultCode, startTime);
                }
            }
        }
    }

    private MyHandler getHandler() {
        if (mHandler == null) {
            mHandler = new MyHandler(SportRecordActivity.this);
        }
        return mHandler;
    }

    //region ======================================== Activity生命周期 ========================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_mine_viewpager_history);
        setPageName("SportRecordActivity");
        initToolbar();
        initViews();
        getHandler();//先在主线程生成handler
        loadSportData();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        ListView list_run_record = (ListView) findViewById(R.id.swipe_target);
        btn_sync_run_record = (TextView) findViewById(R.id.btn_sync_run_record);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        emptyView.setText(getString(R.string.fm_mine_history_empty_hint));
        list_run_record.setEmptyView(emptyView);
        adapter = new SportRecordActivityListAdapter(this);
        list_run_record.setAdapter(adapter);
        list_run_record.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                if (getRunLogList() == null) return;
                RunLogInfo info = getRunLogList().get(position);
                if (info != null && info.getUid() > 0) {
                    String pace = FormatUtil.formatSpeed(info.getDistance(), info.getRealRunTime() / 1000);
                    startRecordActivity(pace,info.getUid(), info.getStartTime(), info.getMode(), info.getType(), info.getDataSource(), info.getWatchSportType());
                }
            }
        });
        list_run_record.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (getRunLogList() == null) return false;
                final RunLogInfo info = getRunLogList().get(position);
                if (info.getUid() < 0) return false;
                deleteSportRecord(info.getType(), info.getUid(), info.getStartTime(), info.getDataSource());
                return true;
            }
        });
    }

    /**
     * 删除运动记录
     *
     * @param type         运动类型,目前没有用到
     * @param uid          乐享动用户uid
     * @param runStartTime 运动开始时间戳
     * @param dataSource   运动数据来源,0:乐享动app,1:手表
     */
    private void deleteSportRecord(final int type, final int uid, final long runStartTime, final int dataSource) {
        new MaterialDialog.Builder(SportRecordActivity.this)
                .title(R.string.prompt)
                .content(R.string.delete_tip)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                if (dataSource == 1) {//手表
                                    deleteWatchRecordInDB(uid, runStartTime);
                                    deleteRunRecordInNet(uid, runStartTime);
                                    refreshRunLogList();
                                } else {//APP
                                    switch (type) {
                                        case 0:
                                        case 1:
                                            deleteRunRecordInDB(uid, runStartTime);
                                            deleteRunRecordInNet(uid, runStartTime);
                                            refreshRunLogList();
                                            break;
                                        case 2:
                                            deleteSkipRecordInDB(uid, runStartTime);
                                            deleteSkipRecordInNet(uid, runStartTime);
                                            refreshSkipLogList();

                                    }
                                }
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "MainActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {

            case Config.MODULE_SPORT + 2://从后台服务器获取用户历史跑步记录
                //setRunRecordList(result);
                break;

            case Config.MODULE_SPORT + 5://删除后台服务器上的跑步记录
            case Config.MODULE_SPORT + 11://删除后台服务器上的跳绳记录
                BaseBean baseBean = JsonHelper.getObject(result, BaseBean.class);
                if (baseBean != null) {
                    int code = baseBean.getCode();
                    if (code == 0) {
                        showAppMessage(R.string.activity_main_delete_run_record_success, AppMsg.STYLE_INFO);
                    }
                }
                break;
            case Config.MODULE_SPORT + 12://从后台服务器获取用户历史跳绳记录
                //setSkipRecordList(result);
                break;
            //endregion =================================== MineFragment ===================================
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "MainActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                //region =================================== MineFragment ===================================
                case Config.MODULE_SPORT + 2://从后台服务器获取用户历史跑步记录
                    //setRunRecordList(null);//请求发生错误时,从本地数据库加载记录
                    break;
                case Config.MODULE_SPORT + 12://从后台服务器获取用户历史跳绳记录
                    //setSkipRecordList(null);//请求发生错误时,从本地数据库加载记录
                    break;
                //endregion =================================== MineFragment ===================================
            }
        }
    }

    //endregion ======================================== Activity生命周期 ========================================

    //region ================================ 运动记录相关 ================================

    /**
     * 获取跑步记录列表
     */
    public List<RunLogInfo> getRunLogList() {
        return getRunLogListAdapter().getList();
    }

    /**
     * 获取适配器
     */
    public SportRecordActivityListAdapter getRunLogListAdapter() {
        if (adapter == null) adapter = new SportRecordActivityListAdapter(this);
        return adapter;
    }

    /**
     * 加载数据
     */
    private void loadSportData() {
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        if (sportType == Config.SPORT_TYPE_RUN) {
            refreshRunLogList();
        } else if (sportType == Config.SPORT_TYPE_SKIP) {
            refreshSkipLogList();
        }
    }

    /**
     * 判断跑步记录是否全部与服务器同步
     *
     * @param list 跑步记录列表
     * @return false:表示有未同步的数据
     */
    private boolean recordSynced(List<RunLogInfo> list) {
        if (list == null || list.size() == 0) {
            return true;
        }
        for (RunLogInfo log : list) {
            if (log.getUid() > 0 && log.getUploaded() == 0) {//月总记录的数据uid是小于0的,不用同步在此过滤掉.
                return false;
            }
        }
        return true;
    }

    /**
     * 刷新跳绳记录ListView
     */
    public void refreshSkipLogList() {
        showLoadingDialog(R.string.activity_main_run_log_loading, 1000);
        int uid = UserDataManager.getUid();
        SportRecordsHelper.asyncGetAllSkipRecords(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SportRecord> sportRecords = (List<SportRecord>) operation.getResult();
                final List<RunLogInfo> list = new ArrayList<>();
                list.clear();
                //数据库运动记录实体(SportRecord)转换为界面上用的运动记录实体(RunLogInfo)
                for (SportRecord sportRecord : sportRecords) {
                    RunLogInfo runLogInfo = new RunLogInfo();
                    runLogInfo.setUid(sportRecord.getUid());//用户ID
                    runLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                    runLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                    runLogInfo.setType(sportRecord.getType());//运动类型 3表示跳绳
                    runLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    runLogInfo.setStep(sportRecord.getStep());//跳绳个数
                    runLogInfo.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                    runLogInfo.setRealRunTime(sportRecord.getRunTime());
                    runLogInfo.setCalorie(sportRecord.getCalorie());//卡路里
                    if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {//心率
                        runLogInfo.setHeartRateDate(sportRecord.getHeartRateDate());
                    }
                    list.add(runLogInfo);
                }
                runOnUiThread(new Runnable() {//切换到UI线程
                    @Override
                    public void run() {
                        hideLoadingDialog();
                        if (!recordSynced(list)) {//如果有未同步的数据,在listView顶部显示同步按钮
                            setSyncButtonVisible(View.VISIBLE);
                        }
                        getRunLogListAdapter().setList(list);
                    }
                });
            }
        });
    }

    /**
     * 刷新跑步记录ListView
     */
    public void refreshRunLogList() {
        showLoadingDialog(R.string.activity_main_run_log_loading, 1000);
        int uid = UserDataManager.getUid();
        //1.乐享动app产生的
        SportRecordsHelper.asyncGetAllRunRecords(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SportRecord> sportRecords = (List<SportRecord>) operation.getResult();
                appRunLogInfoList = new ArrayList<>();
                appRunLogInfoList.clear();
                //数据库运动记录实体(SportRecord)转换为界面上用的运动记录实体(RunLogInfo)
                for (SportRecord sportRecord : sportRecords) {
                    RunLogInfo runLogInfo = new RunLogInfo();
                    runLogInfo.setUid(sportRecord.getUid());//用户ID
                    runLogInfo.setType(sportRecord.getType());//运动类型 0或1表示跑步
                    runLogInfo.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                    runLogInfo.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                    //runLogInfo.setBpmMatch(20);//不考虑,平均步频与音乐BPM匹配度 (平均步频/音乐BPM)*100%
                    runLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    //runLogInfo.setScore(100);//不考虑,运动成绩
                    runLogInfo.setDistance(sportRecord.getDistance());//运动距离,单位米
                    runLogInfo.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                    runLogInfo.setRealRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                    runLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                    runLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                    runLogInfo.setStartLng(sportRecord.getStartLng());//开始点经度
                    runLogInfo.setEndLng(sportRecord.getEndLng());//结束点经度
                    runLogInfo.setStartLat(sportRecord.getStartLat());//开始点纬度
                    runLogInfo.setEndLat(sportRecord.getEndLat());//结束点纬度
                    runLogInfo.setStep(sportRecord.getStep());//步数
                    runLogInfo.setCalorie(sportRecord.getCalorie() == null ? 0 : sportRecord.getCalorie());//卡路里
                    runLogInfo.setDataSource(0);//数据来源于乐享动app
                    if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {//心率
                        runLogInfo.setHeartRateDate(sportRecord.getHeartRateDate());
                    } else {
                        runLogInfo.setHeartRateDate("");
                    }
                    appRunLogInfoList.add(runLogInfo);
                }

                runOnUiThread(new Runnable() {//切换到UI线程
                    @Override
                    public void run() {
                        hideLoadingDialog();
                        if (!recordSynced(appRunLogInfoList)) {//如果有未同步的数据,在listView顶部显示同步按钮
                            setSyncButtonVisible(View.VISIBLE);
                        }
                        updateDataSet();
                    }
                });
            }
        });

        //2.手表产生的
        WatchSportDataHelper.asyncGetAllWatchRunRecords(this, uid, new AsyncOperationListener() {

            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<WatchSportRecord> watchSportRecords = (List<WatchSportRecord>) operation.getResult();
                watchRunLogInfoList = new ArrayList<>();
                watchRunLogInfoList.clear();
                //数据库运动记录实体(WatchSportRecord)转换为界面上用的运动记录实体(RunLogInfo)
                for (WatchSportRecord watchSportRecord : watchSportRecords) {
                    RunLogInfo runLogInfo = new RunLogInfo();
                    runLogInfo.setUid(watchSportRecord.getUid());//用户ID
                    runLogInfo.setStartTime(watchSportRecord.getStartTime());//开始时间,单位毫秒
                    runLogInfo.setType(3);//运动类型 0或1表示跑步
                    runLogInfo.setWatchSportType(watchSportRecord.getSportType());//手表运动记录类型
                    if (watchSportRecord.getSportType() == WatchDataProtocol.SPORTS_TYPE_RUN_INDOOR ||
                            watchSportRecord.getSportType() == WatchDataProtocol.SPORTS_TYPE_SWIM_INDOOR ||
                            watchSportRecord.getSportType() == WatchDataProtocol.SPORTS_TYPE_ROCK_CLIMB) {
                        runLogInfo.setMode(2);//运动环境(1:室外,2:室内)
                    } else {
                        runLogInfo.setMode(1);//运动环境(1:室外,2:室内)
                    }
                    runLogInfo.setUploaded(watchSportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    runLogInfo.setDistance(watchSportRecord.getDistance());//运动距离,单位米
                    runLogInfo.setRunTime(watchSportRecord.getSportTime() * 1000);//运动时长,单位毫秒
                    runLogInfo.setRealRunTime(watchSportRecord.getSportTime() * 1000);//真正运动时长,单位毫秒
                    runLogInfo.setStep(watchSportRecord.getStep());//步数
                    runLogInfo.setCalorie(watchSportRecord.getCalorie() == null ? 0 : watchSportRecord.getCalorie());//卡路里
                    runLogInfo.setMostHigh(watchSportRecord.getPeakAltitude());
                    runLogInfo.setTroughAltitude(watchSportRecord.getTroughAltitude());
                    runLogInfo.setDataSource(1);//数据来源于手表

                    watchRunLogInfoList.add(runLogInfo);
                }

                runOnUiThread(new Runnable() {//切换到UI线程
                    @Override
                    public void run() {
                        hideLoadingDialog();
                        if (!recordSynced(watchRunLogInfoList)) {//如果有未同步的数据,在listView顶部显示同步按钮
                            setSyncButtonVisible(View.VISIBLE);
                        }
                        updateDataSet();
                    }
                });
            }
        });
    }

    /**
     * 更新数据集
     */
    public void updateDataSet() {
        if (runLogInfoList == null) {
            runLogInfoList = new ArrayList<>();
        }

        runLogInfoList.clear();
        //1.遍历乐享动记录和手表记录,按时间排序
        if (appRunLogInfoList != null && watchRunLogInfoList != null) {
            runLogInfoList.addAll(appRunLogInfoList);
            runLogInfoList.addAll(watchRunLogInfoList);
            Collections.sort(runLogInfoList);
        } else if (appRunLogInfoList != null) {
            runLogInfoList.addAll(appRunLogInfoList);
        } else if (watchRunLogInfoList != null) {
            runLogInfoList.addAll(watchRunLogInfoList);
        }

        //2.设置数据集
        getRunLogListAdapter().setList(runLogInfoList);
    }

    /**
     * 设置同步跑步记录按钮的可见性
     *
     * @param visibility view的可见性,View.GONE,View.VISIBLE等
     */
    public void setSyncButtonVisible(int visibility) {
        if (btn_sync_run_record != null) {
            btn_sync_run_record.setVisibility(visibility);
        }
    }

    /**
     * 删除后台服务器上的跑步记录
     *
     * @param uid          跑步记录对应的用户uid
     * @param runStartTime 跑步记录的开始时间,单位为毫秒
     */
    private void deleteRunRecordInNet(int uid, long runStartTime) {
        int requestId = SportDataManager.getInstance().deleteRunRecord(uid, runStartTime);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 删除本地数据库中指定用户的指定的跑步记录
     *
     * @param uid          跑步记录对应的用户uid
     * @param runStartTime 跑步记录的开始时间,单位为毫秒
     */
    private void deleteRunRecordInDB(int uid, long runStartTime) {
        final String trailFileName = Config.PATH_DOWN_TRAIL + uid + "_" + runStartTime + ".json";
        final String stepFileName = Config.PATH_DOWN_STEP + uid + "_" + runStartTime + ".step";
        SportRecordsHelper.asyncDeleteRunRecord(this, uid, runStartTime, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                FileUtils.deleteFile(trailFileName);
                FileUtils.deleteFile(stepFileName);
            }
        });
    }


    /**
     * 删除本地数据库中手表运动记录
     *
     * @param uid          记录对应的用户uid
     * @param runStartTime 记录的开始时间,单位为毫秒
     */
    private void deleteWatchRecordInDB(int uid, long runStartTime) {
        final String trailFileName = Config.PATH_DOWN_TRAIL + uid + "_" + runStartTime + ".json";
        final String stepFileName = Config.PATH_DOWN_STEP + uid + "_" + runStartTime + ".step";
        WatchSportDataHelper.asyncDeleteRecord(this, uid, runStartTime, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                FileUtils.deleteFile(trailFileName);
                FileUtils.deleteFile(stepFileName);
            }
        });
    }

//    /**
//     * 设置我的跑步记录列表
//     *
//     * @param result 网络请求返回的结果
//     */
//    public void setRunRecordList(String result) {
//        RunRecordList runRecordList = JsonHelper.getObject(result, RunRecordList.class);
//        if (runRecordList != null) {
//            //1.更新最近一次获取用户历史跑步记录的时间戳
//            long lastUpdateTime = runRecordList.getLastAddTime();
//            SettingsHelper.putLong(Config.SETTING_RUN_RECORD_SYNC_TIME, lastUpdateTime);
//            List<RunRecordList.RunRecord> runRecords = runRecordList.getRunRecords();
//            if (runRecords != null && runRecords.size() > 0) {
//                //2.将跑步记录与本地数据库记录同步
//                boolean success = SportRecordsHelper.getInstance().bulkAddOrUpdateRunRecords(runRecords);
//                //3.从数据请求状态表中,清除还在缓存有效期内的请求结果
//                if (success) {
//                    UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(2));
//                }
//            }
//        }
//        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
//        if (sportType == Config.SPORT_TYPE_RUN) {
//            refreshRunLogList();
//        }
//    }

    /**
     * 刷新跑步记录集合同步状态
     *
     * @param resultCode 同步结果
     * @param startTime  运动开始时间,用作运动记录编号
     */
    private void updateRunLogList(int resultCode, long startTime) {
        if (resultCode == 404 || startTime == 0) {
            showAppMessage(R.string.fm_mine_history_sync_fail, AppMsg.STYLE_ALERT);
            return;
        }
        List<RunLogInfo> runLogInfoList = getRunLogList();
        if (runLogInfoList != null) {
            for (RunLogInfo runLogInfo : runLogInfoList) {
                if (runLogInfo != null && runLogInfo.getStartTime() == startTime) {
                    if (resultCode == 0 || resultCode == 4003) {//同步成功后,更新同步状态
                        runLogInfo.setUploaded(1);
                    } else {
                        showAppMessage(R.string.fm_mine_history_sync_fail, AppMsg.STYLE_ALERT);
                    }
                }
            }
        }
        getRunLogListAdapter().notifyDataSetChanged();
    }

    /**
     * 同步未与服务器同步的跑步记录
     */
    private void syncRunRecord() {
        int uid = UserDataManager.getUid();
        //1.乐享动app产生的
        SportRecordsHelper.asyncUnSyncRunRecords(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SportRecord> sportRecords = (List<SportRecord>) operation.getResult();
                if (sportRecords == null || sportRecords.size() <= 0) {
                    return;
                }
                final List<RunLogInfo> list = new ArrayList<>();
                //数据库运动记录实体(SportRecord)转换为界面上用的运动记录实体(RunLogInfo)
                for (SportRecord sportRecord : sportRecords) {
                    RunLogInfo runLogInfo = new RunLogInfo();
                    runLogInfo.setUid(sportRecord.getUid());//用户ID
                    runLogInfo.setType(sportRecord.getType());//运动类型 0或1表示跑步
                    runLogInfo.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                    runLogInfo.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                    //runLogInfo.setBpmMatch(20);//不考虑,平均步频与音乐BPM匹配度 (平均步频/音乐BPM)*100%
                    runLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    //runLogInfo.setScore(100);//不考虑,运动成绩
                    runLogInfo.setDistance(sportRecord.getDistance());//运动距离,单位米
                    runLogInfo.setRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                    runLogInfo.setRealRunTime(sportRecord.getRunTime());//运动时长,单位毫秒
                    runLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                    runLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                    runLogInfo.setStartLng(sportRecord.getStartLng());//开始点经度
                    runLogInfo.setEndLng(sportRecord.getEndLng());//结束点经度
                    runLogInfo.setStartLat(sportRecord.getStartLat());//开始点纬度
                    runLogInfo.setEndLat(sportRecord.getEndLat());//结束点纬度
                    runLogInfo.setStep(sportRecord.getStep());//步数
                    runLogInfo.setCalorie(sportRecord.getCalorie() == null ? 0 : sportRecord.getCalorie());//卡路里
                    runLogInfo.setConsumeFat(sportRecord.getConsumeFat() == null ? 0 : sportRecord.getConsumeFat());//脂肪消耗
                    if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {//心率
                        runLogInfo.setHeartRateDate(sportRecord.getHeartRateDate());
                    } else {
                        Logger.e(Logger.DEBUG_TAG, "SportRecordActivity-->heartRateData == null");
                    }

                    list.add(runLogInfo);
                }
                if (list != null && list.size() > 0) {
                    ThreadManager.executeOnNetWorkThread(new SyncRunRecordTask(list, mHandler));
                }
            }
        });
        //2.手表产生的
        WatchSportDataHelper.asyncUnSyncWatchRecords(this, uid, new AsyncOperationListener() {

            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<WatchSportRecord> watchSportRecords = (List<WatchSportRecord>) operation.getResult();
                if (watchSportRecords == null || watchSportRecords.size() <= 0) {
                    return;
                }
                final List<WatchSportLog> list = new ArrayList<>();
                //数据库运动记录实体(WatchSportRecord)转换为界面上用的运动记录实体(WatchSportLog)
                for (WatchSportRecord watchSportRecord : watchSportRecords) {
                    WatchSportLog watchSportLog = new WatchSportLog();
                    watchSportLog.setUid(watchSportRecord.getUid());//用户ID
                    watchSportLog.setStartTime(watchSportRecord.getStartTime());//运动开始时间戳
                    watchSportLog.setSportType(watchSportRecord.getSportType());//运动类型，与枚举对应
                    watchSportLog.setSportDuration(watchSportRecord.getSportDuration());//运动持续时长,单位为秒
                    watchSportLog.setRealSportTime(watchSportRecord.getSportTime());//真正运动时长,单位为秒
                    String pause = watchSportRecord.getPauseDetail();
                    if (pause != null) {
                        List<WatchSportLog.SportPauseDetail> pauseDetail = JsonHelper.getList(pause, new TypeToken<List<WatchSportLog.SportPauseDetail>>() {
                        }.getType());
                        watchSportLog.setPause_detail(pauseDetail);
                    }
                    watchSportLog.setTotalCalorie(watchSportRecord.getCalorie());//运动卡路里
                    watchSportLog.setFatBurst(watchSportRecord.getFatBurn());//脂肪燃烧克数
                    watchSportLog.setLactateThreshold(watchSportRecord.getLactateThreshold());//乳酸阈值
                    watchSportLog.setMaxSportHR(watchSportRecord.getMaxSportHR());//最大运动心率
                    watchSportLog.setAvgSportHR(watchSportRecord.getAvgSportHR());//平均运动心率
                    watchSportLog.setMaxHR(watchSportRecord.getMaxHR());//最大心率,画图表用
                    watchSportLog.setRestHR(watchSportRecord.getRestHR());//静息心率,画图表用
                    String hrStat = watchSportRecord.getHrStatistics();
                    if (hrStat != null) {//心率区间时长统计
                        List<WatchSportLog.HrStatistic> hr = JsonHelper.getList(hrStat, new TypeToken<List<WatchSportLog.HrStatistic>>() {
                        }.getType());
                        watchSportLog.setHrStatistics(hr);
                    }

                    watchSportLog.setTotalDistance(watchSportRecord.getDistance());//运动距离,单位为米
                    watchSportLog.setTotalSteps(watchSportRecord.getStep());//运动步数
                    watchSportLog.setMaxPace(watchSportRecord.getMaxPace());//最高配速,单位为秒
                    watchSportLog.setMaxFrequency(watchSportRecord.getMaxFrequency());//最快步频
                    watchSportLog.setTotalDown(watchSportRecord.getTotalDown());//下降高度
                    watchSportLog.setTotalUp((watchSportRecord.getTotalUp()));//上升高度
                    watchSportLog.setPeakAltitude(watchSportRecord.getPeakAltitude());//峰值海拔
                    watchSportLog.setTroughAltitude(watchSportRecord.getTroughAltitude());//波谷海拔
                    String groupRecord = watchSportRecord.getGroupRecord();
                    if (groupRecord != null) {//运动分组记录
                        List<WatchSportLog.SportGroupRecord> group = JsonHelper.getList(groupRecord, new TypeToken<List<WatchSportLog.SportGroupRecord>>() {
                        }.getType());
                        watchSportLog.setGroupRecords(group);
                    }

                    watchSportLog.setRunPower(watchSportRecord.getRunPower());//跑力
                    watchSportLog.setRidePower(watchSportRecord.getRidePower());//骑行功率

                    watchSportLog.setSwimPoolLength(watchSportRecord.getSwimPoolLength());//泳池长度
                    watchSportLog.setSwimStyle(watchSportRecord.getSwimStyle());//泳姿
                    watchSportLog.setSwimTrips(watchSportRecord.getSwimTrips());//往返次数

                    watchSportLog.setStartAltitude(watchSportRecord.getStartAltitude());//开始海拔
                    watchSportLog.setStartPressure(watchSportRecord.getStartPressure());//开始气压
                    watchSportLog.setStartTemperature(watchSportRecord.getStartTemperature());//开始温度
                    String other = watchSportRecord.getOther();
                    if (other != null) {
                        WatchSportLog.WatchSportLogSup sup = JsonHelper.getObject(other, WatchSportLog.WatchSportLogSup.class);
                        watchSportLog.setOther(sup);
                    }

                    list.add(watchSportLog);
                }
                if (list != null && list.size() > 0) {
                    ThreadManager.executeOnNetWorkThread(new SyncWatchRecordTask(list, mHandler));
                }
            }
        });

        //3.隐藏同步按钮
        setSyncButtonVisible(View.GONE);
    }

    /**
     * 同步运动记录 根据当前选择的不同运动类型
     */
    private void syncSportRecord() {
        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        switch (sportType) {
            case Config.SPORT_TYPE_RUN:
                syncRunRecord();
                break;
            case Config.SPORT_TYPE_SKIP:
                syncSkipRecord();
                break;
        }
    }

//    /**
//     * 设置我的跳绳记录列表
//     *
//     * @param result 网络请求返回的结果
//     */
//    public void setSkipRecordList(String result) {
//        SkipRecordList skipRecordList = JsonHelper.getObject(result, SkipRecordList.class);
//        if (skipRecordList != null) {
//            //1.更新最近一次获取用户历史跑步记录的时间戳
//            long lastUpdateTime = skipRecordList.getLastAddTime();
//            SettingsHelper.putLong(Config.SETTING_SKIP_RECORD_SYNC_TIME, lastUpdateTime);
//            List<SkipRecordList.SkipRecord> skipRecords = skipRecordList.getNewX();
//            if (skipRecords != null && skipRecords.size() > 0) {
//                //2.将跑步记录与本地数据库记录同步
//                boolean success = SportRecordsHelper.getInstance().bulkAddOrUpdateSkipRecords(skipRecords);
//                //3.从数据请求状态表中,清除还在缓存有效期内的请求结果
//                if (success) {
//                    UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(2));
//                }
//            }
//        }
//        int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
//        if (sportType == Config.SPORT_TYPE_SKIP) {
//            refreshSkipLogList();
//        }
//    }

    /**
     * 同步未与服务器同步的跳绳记录
     */
    private void syncSkipRecord() {
        int uid = UserDataManager.getUid();
        SportRecordsHelper.asyncUnSyncSkipRecords(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                List<SportRecord> sportRecords = (List<SportRecord>) operation.getResult();
                if (sportRecords == null || sportRecords.size() <= 0) {
                    return;
                }
                final List<SkipLogInfo> list = new ArrayList<>();
                //数据库运动记录实体(SportRecord)转换为界面上用的运动记录实体(RunLogInfo)
                for (SportRecord sportRecord : sportRecords) {
                    SkipLogInfo skipLogInfo = new SkipLogInfo();
                    skipLogInfo.setUid(sportRecord.getUid());//用户ID
                    skipLogInfo.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                    skipLogInfo.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                    skipLogInfo.setType(sportRecord.getType());//运动类型 0或1表示跑步2表示跳绳
                    skipLogInfo.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    skipLogInfo.setSkipTime(sportRecord.getRunTime());//运动时长,单位毫秒
                    skipLogInfo.setSkipNumber(sportRecord.getStep());//跳绳个数
                    if (sportRecord.getBpm() != null){
                        skipLogInfo.setBpm(sportRecord.getBpm());//平均步频(每分钟步数)
                    }
                    skipLogInfo.setCalorie(sportRecord.getCalorie());//卡路里

                    if (!TextUtils.isEmpty(sportRecord.getHeartRateDate())) {//心率
                        skipLogInfo.setHeartRateDate(sportRecord.getHeartRateDate());
                    }

                    list.add(skipLogInfo);
                }
                if (list != null && list.size() > 0) {//目前一次只同步最后一条
                    for (SkipLogInfo skipLogInfo : list) {
                        ThreadManager.executeOnNetWorkThread(new SyncSkipRecordTask(SportRecordActivity.this, skipLogInfo));
                    }
                }
            }
        });
        setSyncButtonVisible(View.GONE);
    }

    /**
     * 删除后台服务器上的跳绳记录
     *
     * @param uid           跳绳记录对应的用户uid
     * @param skipStartTime 跳绳记录的开始时间,单位为毫秒
     */
    private void deleteSkipRecordInNet(int uid, long skipStartTime) {
        int requestId = SportDataManager.getInstance().deleteSkipRecord(uid, skipStartTime);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 删除后台服务器上的跳绳记录
     *
     * @param uid           跳绳记录对应的用户uid
     * @param skipStartTime 跳绳记录的开始时间,单位为毫秒
     */
    private void deleteSkipRecordInDB(int uid, long skipStartTime) {
        final String skipFileName = Config.PATH_DOWN_SKIP + uid + "_" + skipStartTime + ".skip";
        SportRecordsHelper.asyncDeleteSkipRecord(this, uid, skipStartTime, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                FileUtils.deleteFile(skipFileName);
            }
        });
    }

    //endregion ================================ 运动记录相关 ================================

    //region ================================ 启动其它Activity ================================

    /**
     * 启动记录详情界面
     *
     * @param pace 记录对应的配速
     * @param uid            记录对应的用户uid
     * @param runStartTime   记录的开始时间,单位为毫秒
     * @param environment    1:室外,2:室内
     * @param type           运动类型,0,1:跑步,2:跳绳,3:手表
     * @param dataSource     数据来源,0:乐享动app ,1:手表
     * @param watchSportType 手表运动记录运动类型,具体含义参考{@link com.fitmix.sdk.watch.WatchDataProtocol#SPORTS_TYPE_RUN_OUTDOOR} 等
     */
    private void startRecordActivity(String pace,int uid, long runStartTime, int environment, int type, int dataSource, int watchSportType) {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        if (type == 2) {//跳绳
            intent.setClass(this, SkipRecordActivity.class);
            bundle.putInt("uid", uid);
            bundle.putLong("startTime", runStartTime);
            bundle.putInt("environment", environment);
        } else {
            // intent.setClass(this, RunRecordActivity.class);
            intent.setClass(this, SportRecordDetailActivity.class);
            bundle.putInt("uid", uid);
            bundle.putLong("startTime", runStartTime);
            bundle.putInt("environment", environment);
            bundle.putString("pace",pace);
            if (dataSource == 1) {//手表
                bundle.putInt("dataSource", 1);
                bundle.putInt("watchSportType", watchSportType);
            }
        }
        intent.putExtras(bundle);
        startActivity(intent);
    }


    //endregion ================================ 启动其它Activity ================================

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_sync_run_record://同步跑步记录按钮
                syncSportRecord();
                break;
        }
    }
}
