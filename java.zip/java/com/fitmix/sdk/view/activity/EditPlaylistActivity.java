package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.imagepipeline.core.ImagePipeline;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

import java.io.File;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

import static com.facebook.drawee.backends.pipeline.Fresco.getImagePipeline;

public class EditPlaylistActivity extends BaseActivity {
    private static final int CHANGE_PLAYLIST_ID = 890;
    private ImageView img_playlist_change_cover;
    private EditText txt_playlist_name;
    private EditText txt_playlist_description;
    private TextView tv_desc_number_limit;
    private Bitmap bitmap;
    private Album album;
    private int photoId;
    private Uri mCropImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_playlist);
        setPageName("EditPlaylistActivity");
        String albumString = getIntent().getStringExtra("currentAlbum");
        album = JsonHelper.getObject(albumString, Album.class);
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            getSupportActionBar().setTitle(getString(R.string.activity_edit_playlist));
        }
        img_playlist_change_cover = (ImageView) findViewById(R.id.img_playlist_change_cover);
        txt_playlist_name = (EditText) findViewById(R.id.txt_playlist_name);
        txt_playlist_description = (EditText) findViewById(R.id.txt_playlist_description);

        tv_desc_number_limit = (TextView) findViewById(R.id.tv_desc_number_limit);
        tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_playlist_playlist_description_tips), 100));
        txt_playlist_description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int number = txt_playlist_description.getText().length();
                tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_playlist_playlist_description_tips), 100 - number));
            }
        });

        if (album == null) return;
        if (checkAlbumCoverExist(album)) {
            img_playlist_change_cover.setImageURI(Uri.fromFile(new File(album.getAlbumInfo().getImage())));
        } else {
            img_playlist_change_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_album)).build());
        }
        txt_playlist_name.setText(album.getName());
        txt_playlist_description.setText(album.getAlbumInfo().getDesc());
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
    }

    @Override
    protected void processReqError(int requestId, String error) {

    }

    private boolean checkAlbumCoverExist(Album album) {//歌曲封面是否存在于本地文件中
        if (album == null) return false;
        String s = Config.PATH_LOCAL_COVER + album.getId() + ".jpg";
        File file = new File(s);
        return file.exists();
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.img_playlist_change_cover://修改歌单封面
                onPickImage(v);
                break;

            case R.id.btn_edit_playlist://修改歌单
                changeAlbum();
                break;
            case R.id.btn_delete_playlist://删除歌单
                deleteAlbum();
                break;
        }
    }

    /**
     * 删除歌单
     */
    private void deleteAlbum() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(String.format(getString(R.string.remove_Album), album.getName()))
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                           @Override
                           public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                               dialog.dismiss();
                               switch (which) {
                                   case POSITIVE:
                                       //移除歌单封面
                                       deleteLocaleAlbumCover(album);//从本地删除自建歌单封面
                                       OperateMusicUtils.deleteCustomAlbum(album.getId(), new AsyncOperationListener() {
                                           @Override
                                           public void onAsyncOperationCompleted(AsyncOperation operation) {
                                               setResult(RESULT_OK);
                                               finish();
                                           }
                                       });
                                   case NEGATIVE:
                                       break;
                               }
                           }
                       }

                ).
                show();
    }

    private void deleteLocaleAlbumCover(Album album) {
        String sFilename = FitmixUtil.getLocalFilePath(album.getAlbumInfo().getImage(),
                album.getId(), Config.DOWNLOAD_LOCAL_COVER);
        if (sFilename == null)
            return;
        File f = new File(sFilename);
        if (f.exists())
            f.delete();
    }

    /**
     * 选取图像
     *
     * @param view 图像view
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
        photoId = view.getId();//保存ID,之后图片设置用
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
//            case CHANGE_PLAYLIST_ID:
//                bitmap = ImagePicker.getImageFromResult(this, resultCode, data);
//                if (bitmap != null) {
//                    ((ImageView) img_playlist_change_cover).setImageBitmap(bitmap);
//                }
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;

            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    View v = findViewById(photoId);
                    if (v != null && bitmap != null) {
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(75, 32)// 750 * 320
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    protected void changeAlbum() {
        if (album == null) {
            return;
        }
        int AlbumId = album.getId();
        String name = txt_playlist_name.getText().toString();
        String desc = txt_playlist_description.getText().toString();
        if (bitmap != null) {
            //当修改的时候进行保存选中的图片
            ImageHelper.adjustPhotoToFitSize(bitmap, Config.USER_ALBUM_WIDTH, Config.USER_ALBUM_HEIGHT, FitmixUtil.getPlayListPhotoFile(AlbumId));
        }
        if (TextUtils.isEmpty(name)) {
            String info = getResources().getString(R.string.title_activity_create_playlist_name_error);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
        } else if (TextUtils.isEmpty(desc)) {
            String info = getResources().getString(R.string.title_activity_create_playlist_desc_error);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
        } else {
            //清除自建歌单的封面缓存
            ImagePipeline imagePipeline = getImagePipeline();
            Uri uri = Uri.fromFile(new File(album.getAlbumInfo().getImage()));
            imagePipeline.evictFromMemoryCache(uri);
            imagePipeline.evictFromDiskCache(uri);

            final Album albumNew = new Album();
            albumNew.setId(AlbumId);
            albumNew.setName(name);
            albumNew.setValue(0);
            Album.AlbumInfo albumInfo = new Album.AlbumInfo();
            albumInfo.setImage(album.getAlbumInfo().getImage());
            albumInfo.setDesc(desc);
            albumNew.setAlbumInfo(albumInfo);

            String albumString = JsonHelper.createJsonString(albumNew);
            Intent intent = new Intent();
            intent.putExtra("currentAlbum", albumString);
            setResult(Activity.RESULT_OK, intent);

            OperateMusicUtils.updateCustomAlbum(albumNew, new AsyncOperationListener() {
                @Override
                public void onAsyncOperationCompleted(AsyncOperation operation) {
                    finish();
                }
            });

        }
    }
}
