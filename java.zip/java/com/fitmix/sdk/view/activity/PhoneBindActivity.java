package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.TimeCountUtil;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.countrypicker.Country;
import com.fitmix.sdk.view.countrypicker.CountryPicker;
import com.fitmix.sdk.view.countrypicker.OnCountryPickerListener;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.widget.AppMsg;

public class PhoneBindActivity extends BaseActivity {


    public static final int BIND_TYPE_BY_PHONE = 5;
    public static final int BIND_TYPE_BY_PHONE_WITH_PWD = 6;
    private EditText txt_phone;

    private EditText txt_password;
    private EditText txt_confirm_password;
    private EditText txt_auth_code;
    private Button btn_get_auth_code;
    private Button btn_bind;
    private TextView txt_china_phone;

    private String mPhoneNumber;
    private String mTempPhoneNumber;
    private String mPassword;
    private String mConfirmPwd;

    private boolean isPhoneBindWithPWD;//没有设置过密码的手机绑定
    private boolean isPhoneBind;//手机绑定
    private boolean isGoToContestantActivity;//去往赛事信息页面
//    private int act_type ;//网络请求类型 //三种：REQUEST_TYPE_GET_AUTH_CODE、BIND_TYPE_BY_PHONE、BIND_TYPE_BY_PHONE_WITH_PWD
    /**
     * 客户端输入的验证码
     */
    private String validationCode;

//    /**
//     * 服务器端获取的验证码
//     */
//    private static String serverValidationCode;

    /**
     * 金币任务,手机绑定是否完成
     */
    private boolean coinTaskPhoneBind;
    private TextView tv_label_area;
    private LinearLayout ll_register_area;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_phone);
        setPageName("PhoneBindActivity");

        isPhoneBindWithPWD = getIntent().getBooleanExtra("PhoneBindWithPWD", false);
        isPhoneBind = getIntent().getBooleanExtra("PhoneBind", false);
        isGoToContestantActivity = getIntent().getBooleanExtra("isGoToContestantActivity", false);
        initToolbar();
        initViews();

        coinTaskPhoneBind = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_BIND_PHONE, true);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        refresh();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timeCountUtil != null) {
            timeCountUtil.cancel();
        }
        timeCountUtil = null;
    }

    /**
     * 初始化视图
     */
    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        txt_phone = (EditText) findViewById(R.id.txt_phone_number);
        txt_china_phone = (TextView) findViewById(R.id.txt_china_number);
        txt_china_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_china_phone.setFocusable(true);
                txt_china_phone.setFocusableInTouchMode(true);
            }
        });
        txt_password = (EditText) findViewById(R.id.txt_password);
        txt_confirm_password = (EditText) findViewById(R.id.txt_confirm_password);

        txt_auth_code = (EditText) findViewById(R.id.txt_auth_code);
        btn_get_auth_code = (Button) findViewById(R.id.btn_get_auth_code);

        btn_bind = (Button) findViewById(R.id.btn_bind);

        btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));

        if (isPhoneBind) {
            txt_password.setVisibility(View.GONE);
            txt_confirm_password.setVisibility(View.GONE);
        }

        ll_register_area = findViewById(R.id.ll_register_area);
        tv_label_area = findViewById(R.id.tv_label_area);
        ll_register_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(PhoneBindActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                        tv_label_area.setText(country.getName());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog
            }
        });

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 10://获取验证码
//            AuthCode authCode = JsonHelper.getObject(dataReqResult.getResult(), AuthCode.class);
//            if (authCode != null)
//                serverValidationCode = authCode.getData();
                BaseBean authCodeResult = JsonHelper.getObject(result, BaseBean.class);
                if (authCodeResult != null && authCodeResult.getCode() == 0) {
                    showAppMessage(R.string.activity_register_get_auth_code_success, AppMsg.STYLE_INFO);
                }
                break;
            case Config.MODULE_USER + 36://手机绑定
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表存手机号
                SettingsHelper.putString(Config.SETTING_USER_MOBILE, mPhoneNumber);

                if (!coinTaskPhoneBind) {
                    finishBindPhoneCoinTask();
                } else {
                    setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                    if (isGoToContestantActivity) {
                        startToContestantActivity();
                    }
                    finish();
                }
                break;
            case Config.MODULE_USER + 38://手机绑定
//                PersonInfo.getInstance().setMobile(mPhoneNumber);
                //数据库设个人信息过期,用户信息表更新
                setUserDataUseLess();
                //个人信息数据库表存手机号
                SettingsHelper.putString(Config.SETTING_USER_MOBILE, mPhoneNumber);
                //本地存的个人密码更改
                PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_PWD, mPassword);
//                    getMyConfig().getSystemConfig().setLastPassword(mPassword);
                if (!coinTaskPhoneBind) {
                    finishBindPhoneCoinTask();
                } else {
                    setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                    if (isGoToContestantActivity) {
                        startToContestantActivity();
                    }
                    finish();
                }
                break;

            case Config.MODULE_USER + 64://完成绑定手机金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        //弹窗
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_BIND_PHONE, true);//绑定手机金币任务完成

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription(),
                                    new QuestRewardsDialog.OnQuestRewardsDialogDismiss() {
                                        @Override
                                        public void onRewardsDialogDismiss() {//奖励金币确定后,继续返回状态给AccountSetActivity
                                            if (isGoToContestantActivity) {
                                                startToContestantActivity();
                                            }
                                            setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                                            finish();
                                        }
                                    });

                            return;
                        }
                    }
                }
                setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                finish();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 10://获取验证码
            case Config.MODULE_USER + 36://手机绑定
            case Config.MODULE_USER + 38://手机绑定
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
            case Config.MODULE_USER + 64://绑定手机金币任务
                setResult(Config.REQUEST_BIND_PHONE_EMAIL_RESULT_CODE);
                finish();
                break;
        }
    }

    /**
     * 检验手机号码是否合法
     */
    private int checkPhoneNumber() {
        mPhoneNumber = txt_phone.getText().toString();
        if (!FitmixUtil.isMobileNumber(mPhoneNumber))
            return Config.ERROR_PHONE_DATA;

        return Config.ERROR_NO_ERROR;
    }

    /**
     * 手机绑定
     */
    private void bindInServer() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        if (isPhoneBind) {//绑定手机
            sendBindRequest();
        } else if (isPhoneBindWithPWD) {//没有设置过密码的绑定
            sendBindRequestWithPWD();
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_get_auth_code://获取验证码
                changeBtnGetCode();
                break;
            case R.id.btn_bind://绑定
                bindInServer();
                break;
        }
    }

    private void changeBtnGetCode() {
        String countryCode = txt_china_phone.getText().toString();
        mPhoneNumber = txt_phone.getText().toString();
        if (countryCode.contains("86")){
            int error = checkPhoneNumber();
            if (error != Config.ERROR_NO_ERROR) {
                showErrorMsg(error);
                return;
            }
        }
        getAuthCode();//获取验证码
        timeCountUtil.start();
    }

    /**
     * 执行倒计时
     */
    private TimeCountUtil timeCountUtil = new TimeCountUtil(60 * 1000, 1000, new TimeCountUtil.ITimeCountListener() {
        @Override
        public void onTick(long millisUntilFinished) {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "(", String.valueOf(millisUntilFinished / 1000), ")"));
            btn_get_auth_code.setEnabled(false);
        }

        @Override
        public void onFinish() {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));
            btn_get_auth_code.setEnabled(true);
        }
    });


    /**
     * 发送绑定的请求 绑定手机
     */
    private void sendBindRequest() {
        String countryCode = txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        //不考虑缓存
        int requestId = UserDataManager.getInstance().userBind(countryCode+mPhoneNumber, countryCode+mPhoneNumber, BIND_TYPE_BY_PHONE, true);
        registerDataReqStatusListener(requestId);
    }


    /**
     * 发送绑定的请求 绑定手机 并且带着密码的绑定
     */
    private void sendBindRequestWithPWD() {
        String countryCode = txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        //不考虑缓存
        int requestId = UserDataManager.getInstance().userBindWithPWD(countryCode+mPhoneNumber, countryCode+mPhoneNumber, BIND_TYPE_BY_PHONE_WITH_PWD, mPassword, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取验证码
     */

    private void getAuthCode() {
        mTempPhoneNumber = mPhoneNumber;
        String countryCode = txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        int requestId = UserDataManager.getInstance().getAuthCode(countryCode+mPhoneNumber, true);
        registerDataReqStatusListener(requestId);
    }

//    /**
//     * 刷新界面
//     */
//    private void refresh() {
//        txt_password.setText(mPassword);
//        txt_account.setText(mEmailAddress);
//    }

    /**
     * 检查输入错误
     *
     * @return Config.ERROR_NO_ERROR   正确
     * 其它                             错误码
     */

    private int checkInputError() {
        mPhoneNumber = txt_phone.getText().toString();
        validationCode = txt_auth_code.getText().toString().trim();

        String countryCode = txt_china_phone.getText().toString();
        if (countryCode.contains("86")){
            if (!FitmixUtil.isMobileNumber(mPhoneNumber))
                return Config.ERROR_PHONE_DATA;

            if (!mPhoneNumber.equals(mTempPhoneNumber)) {
                return Config.ERROR_PHONE_NUMBER_NOT_MATCH;
            }
        }

        if (TextUtils.isEmpty(validationCode)) {
            return Config.ERROR_EDIT_AUTH_CODE;
        }

//        if (!validationCode.equals(serverValidationCode)) {//不再在客户端验证
//            return Config.ERROR_AUTH_CODE_WRONG;
//        }

        if (isPhoneBindWithPWD) {//有填写密码的选项时

            mPassword = txt_password.getText().toString();

            mConfirmPwd = txt_confirm_password.getText().toString();

            if (mPassword.length() < Config.PASSWORD_LENGTH_MIN)
                return Config.ERROR_PASSWORD_TOO_SHORT;

            if (!mPassword.equals(mConfirmPwd))
                return Config.ERROR_PASSWORD_NOT_MATCH;
        }
        return Config.ERROR_NO_ERROR;
    }

    private void startToContestantActivity() {
        if (TextUtils.isEmpty(SettingsHelper.getString(Config.SETTING_USER_ID_CARD, "")))// 该用户是否填写过资料
            startContestantInfoEditActivity();
        else
            startContestantInfoActivity();
    }

    private void startContestantInfoActivity() {
        Intent intent = new Intent();
        intent.putExtra("isModify", true);
        intent.setClass(this, ContestantInfoEditActivity.class);
        startActivity(intent);
    }

    private void startContestantInfoEditActivity() {
        Intent intent = new Intent();
        intent.setClass(this, ContestantInfoEditActivity.class);
        startActivity(intent);
    }

    //region  ============================= 金币任务 =============================

    /**
     * 完成绑定手机金币任务
     */
    private void finishBindPhoneCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishPhoneBindCoinTask(uid, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion  ============================= 金币任务 =============================

}
