package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.bean.ClubNotice;
import com.fitmix.sdk.view.dialog.datepicker.date.DatePickerDialog;
import com.fitmix.sdk.view.dialog.datepicker.time.RadialPickerLayout;
import com.fitmix.sdk.view.dialog.datepicker.time.TimePickerDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class PublishNoticeActivity extends BaseActivity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {
    /**
     * 公告图片宽度
     */
    private static final int USER_NOTICE_WIDTH = 700;
    /**
     * 公告图片高度
     */
    private static final int USER_NOTICE_HEIGHT = 350;

    private int photoId;

    private SimpleDraweeView btn_notice_cover;
    private EditText txt_notice_subject;
    private EditText txt_notice_place;
    private EditText txt_notice_description;

    private TextView tv_notice_start_date;
    private TextView tv_notice_start_time;
    private TextView tv_notice_end_date;
    private TextView tv_notice_end_time;
    private TextView tv_desc_number_limit;//
    //    private Button btn_publish_notice;//
    private Button btn_save;//
    private String title;
    private String description;
    private long lStartTime;
    private long lEndTime;
    private String address;
    private int dateType;//0:开始时间,1:结束时间
    private ClubNotice notice;

    private Uri mCropImageUri;
    private boolean bAddOperate = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPageName("PublishNoticeActivity");

        Intent intent = getIntent();
        bAddOperate = intent.getBooleanExtra("isAddOperate", false);
        setContentView(isbAddOperate() ? R.layout.activity_publish_notice : R.layout.activity_view_club_notice);
        initToolbar();
        if (!bAddOperate) {
            setUiTitle(getString(R.string.title_activity_check_notice));
            String clubNoticeString = getIntent().getStringExtra("clubNoticeString");
            notice = JsonHelper.getObject(clubNoticeString, ClubNotice.class);
        }
        initViews();
        FitmixUtil.deleteTempPhotoFile();
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        btn_notice_cover = (SimpleDraweeView) findViewById(R.id.btn_notice_cover);

        txt_notice_subject = (EditText) findViewById(R.id.txt_notice_subject);
        txt_notice_place = (EditText) findViewById(R.id.txt_notice_place);
        txt_notice_description = (EditText) findViewById(R.id.txt_notice_description);


        if (bAddOperate) {
            tv_desc_number_limit = (TextView) findViewById(R.id.tv_desc_number_limit);
            tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_playlist_playlist_description_tips), 100));
//            btn_publish_notice = (Button) findViewById(R.id.btn_publish_notice);
            txt_notice_description.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    int number = txt_notice_description.getText().length();
                    tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_playlist_playlist_description_tips), 100 - number));
                }
            });
        } else {
            btn_save = (Button) findViewById(R.id.btn_save);
        }

        tv_notice_start_date = (TextView) findViewById(R.id.tv_notice_start_date);
        tv_notice_start_time = (TextView) findViewById(R.id.tv_notice_start_time);

        tv_notice_end_date = (TextView) findViewById(R.id.tv_notice_end_date);
        tv_notice_end_time = (TextView) findViewById(R.id.tv_notice_end_time);

        if (isbAddOperate()) {
            Calendar c = Calendar.getInstance();
            lStartTime = c.getTimeInMillis();
            tv_notice_start_date.setText(String.format("%d/%02d/%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));
            c.setTimeInMillis(c.getTimeInMillis() + 1000 * 60 * 60 * 24);
            lEndTime = c.getTimeInMillis();
            tv_notice_end_date.setText(String.format("%d/%02d/%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));
            btn_notice_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.icon_add_notice)).build());
            //初始化活动期间为当天09:00至18:00
            tv_notice_start_time.setText("09:00");
            tv_notice_end_time.setText("18:00");

        } else {
            if (notice == null) {
                return;
            }
            if (TextUtils.isEmpty(notice.getBackImageUrl())) {
                btn_notice_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_club_notice)).build());
            } else {
                btn_notice_cover.setImageURI(Uri.parse(notice.getBackImageUrl()));
            }
            if (!TextUtils.isEmpty(notice.getName())) {
                txt_notice_subject.setText(notice.getName());
            }
            if (!TextUtils.isEmpty(notice.getAddress())) {
                txt_notice_place.setText(notice.getAddress());//活动地点
            }

            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(notice.getBeginTime());

            tv_notice_start_date.setText(String.format("%d/%d/%d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));
            tv_notice_start_time.setText(String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));

            c.setTimeInMillis(notice.getEndTime());
            tv_notice_end_date.setText(String.format("%d/%d/%d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));

            tv_notice_end_time.setText(String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));

            if (!TextUtils.isEmpty(notice.getDesc())) {
                txt_notice_description.setText(notice.getDesc());//活动描述
            }


            TextView tv_notice_status = (TextView) findViewById(R.id.tv_notice_status);
            TextView tv_notice_sponsor = (TextView) findViewById(R.id.tv_notice_sponsor);

            long now = Calendar.getInstance().getTimeInMillis();
            if (now > notice.getEndTime()) {
                tv_notice_status.setText(R.string.club_notice_end);

            } else if (now < notice.getBeginTime()) {
                String format = getString(R.string.activity_view_club_notice_status_format);
                long hour = (notice.getBeginTime() - now) / 1000 / 3600;
                String status = String.format(format, hour);
                tv_notice_status.setText(Html.fromHtml(status));
            } else {
                tv_notice_status.setText(R.string.club_notice_in_duration);

            }

            if (notice.getUser() != null && !TextUtils.isEmpty(notice.getUser().getName())) {
                tv_notice_sponsor.setText(notice.getUser().getName());//活动发起人
            }

            lStartTime = notice.getBeginTime();
            lEndTime = notice.getEndTime();

            if (isNoticeCreator()) {//如果当前用户是通知创建者
                findViewById(R.id.layout_notice_manager).setVisibility(View.VISIBLE);
            } else {
                setTitle(R.string.title_activity_view_club_notice);
                btn_notice_cover.setClickable(false);
                tv_notice_start_date.setClickable(false);
                tv_notice_end_date.setClickable(false);
                txt_notice_subject.setEnabled(false);
                txt_notice_place.setEnabled(false);
                txt_notice_description.setEnabled(false);
            }
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_CLUB + 17://创建俱乐部公告
            case Config.MODULE_CLUB + 18://更改俱乐部公告
            case Config.MODULE_CLUB + 19://删除俱乐部公告
                finish();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_CLUB + 17://创建俱乐部公告
            case Config.MODULE_CLUB + 18://更改俱乐部公告
            case Config.MODULE_CLUB + 19://删除俱乐部公告
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }

    private boolean isbAddOperate() {
        return bAddOperate;
    }

    /**
     * @return 是否俱乐部创建者
     */
    public boolean isNoticeCreator() {
        if (notice == null) return false;
        return notice.getUid() == UserDataManager.getUid();
    }

    /**
     * 选择日期
     *
     * @param type 0:开始日期,1:结束日期
     */
    public void pickDate(final int type) {
        dateType = type;//设置日期类型,用于回调

        Calendar now = Calendar.getInstance();
        DatePickerDialog dpd = DatePickerDialog.newInstance(PublishNoticeActivity.this,
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
        );
        dpd.setThemeDark(true);//暗色主题
        dpd.setMinDate(now);//最小日期为今天
        dpd.dismissOnPause(true);//Activity onPause时销毁对话框
        dpd.showYearPickerFirst(false);
        if (dateType == 0) {
            dpd.setTitle(getString(R.string.dialog_pick_start_time_title));//标题
        } else {
            dpd.setTitle(getString(R.string.dialog_pick_end_time_title));//标题
        }
        if (ftCanCommit)
            dpd.show(getFragmentManager(), "datePickerDialog");
    }

    /**
     * 选择时间
     *
     * @param type 0:开始时间,1:结束时间
     */
    private void pickTime(int type) {
        dateType = type;

        Calendar now = Calendar.getInstance();
        TimePickerDialog tpd = TimePickerDialog.newInstance(PublishNoticeActivity.this,
                now.get(Calendar.HOUR_OF_DAY),
                now.get(Calendar.MINUTE),
                false);//时间为12小时格式
        tpd.setThemeDark(true);//暗色主题
        tpd.dismissOnPause(true);//Activity onPause时销毁对话框
        tpd.enableSeconds(false);//不显示秒
        if (dateType == 0) {
            tpd.setTitle(getString(R.string.dialog_pick_start_time_title));//标题
        } else {
            tpd.setTitle(getString(R.string.dialog_pick_end_time_title));//标题
        }
        tpd.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
            }
        });
        if (ftCanCommit)
            tpd.show(getFragmentManager(), "timePickerDialog");

    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_notice_cover://选择活动公告图片
                onPickImage(v);
                break;

            case R.id.tv_notice_start_date://选择活动开始日期
                pickDate(0);
                break;

            case R.id.tv_notice_start_time://选择活动开始时间
                pickTime(0);
                break;

            case R.id.tv_notice_end_date://选择活动结束日期
                pickDate(1);
                break;

            case R.id.tv_notice_end_time://选择活动结束时间
                pickTime(1);
                break;

            case R.id.btn_publish_notice://发布活动公告
                processCreateNotice();
                break;

            case R.id.btn_delete_notice://删除俱乐部
                removeNotice();
                break;

            case R.id.btn_save://保存修改
                processModifyNotice();
                break;
        }
    }

//    /**
//     * @return 获取当前公告
//     */
//    private ClubNotice getClubNotice() {
//        return getMyConfig().getMemExchange().getCurrentNotice();
//    }

    /**
     * 添加公告
     */
    public void sendAddNoticeRequest() {
        if (getMyConfig().getMemExchange().getCurrentClub() == null) return;
        int clubId = getMyConfig().getMemExchange().getCurrentClub().getId();
        int requestId = ClubDataManager.getInstance().createClubNotice(clubId, title, "", address, lStartTime, lEndTime, description, FitmixUtil.getTempPhotoFile(), "image", true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 更改俱乐部公告
     */
    private void modifyNotice() {
        if (getMyConfig().getMemExchange().getCurrentClub() == null) return;
        btn_save.setClickable(false);
        int clubId = getMyConfig().getMemExchange().getCurrentClub().getId();
//        if (!bAddOperate) {
//            Bitmap bitmap = btn_notice_cover.getDrawingCache();
//            FitmixUtil.adjustPhotoToFitSize(bitmap, USER_NOTICE_WIDTH, USER_NOTICE_HEIGHT, FitmixUtil.getTempPhotoFile());
//        }
        int requestId = ClubDataManager.getInstance().modifyClubNotice(notice.getId(), clubId, title, "", address, lStartTime, lEndTime, description, FitmixUtil.getTempPhotoFile(), "image", true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 删除俱乐部公告
     */
    private void removeNotice() {
        if (notice == null) return;
        if (getMyConfig().getMemExchange().getCurrentClub() == null) return;

        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_view_club_delete_notice)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                int clubId = getMyConfig().getMemExchange().getCurrentClub().getId();
                                int requestId = ClubDataManager.getInstance().deleteClubNotice(notice.getId(), clubId, true);
                                registerDataReqStatusListener(requestId);
                                break;

                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();


    }

    /**
     * 创建公告
     */
    private void processCreateNotice() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        sendAddNoticeRequest();
    }

    /**
     * 修改公告
     */
    private void processModifyNotice() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        modifyNotice();
    }

    /**
     * 输入错误检查
     */
    private int checkInputError() {
        title = txt_notice_subject.getText().toString();
        description = txt_notice_description.getText().toString();
        address = txt_notice_place.getText().toString();

//        if (bAddOperate) {
//            File file = new File(FitmixUtil.getTempPhotoFile());
//            if (!file.exists()) return Config.ERROR_COVER_NOT_EXIST;
//        }

        if (title.isEmpty()) return Config.ERROR_NOTICE_NAME_INVALID;
        else if (address.isEmpty()) return Config.ERROR_NOTICE_ADDRESS_INVALID;
        else if (lStartTime >= lEndTime) return Config.ERROR_TIME_INVALID;
        return Config.ERROR_NO_ERROR;
    }

    /**
     * 从相册或相机获取图片
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
//        Intent chooseImageIntent = ImagePicker.getPickImageIntent(this);
        photoId = view.getId();//保存ID,之后图片设置用
//        startActivityForResult(chooseImageIntent, PICK_NOTICE_ID);
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        //日期选择回调
        String dateStr = String.format("%d/%02d/%02d", year, monthOfYear + 1, dayOfMonth);
        DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
        Date date = null;
        try {
            date = formatter.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar c = Calendar.getInstance();
        if (date != null) {
            if (dateType == 0) {//开始日期
                c.setTimeInMillis(lStartTime);
                c.set(Calendar.YEAR, year);
                c.set(Calendar.MONTH, monthOfYear);
                c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                lStartTime = c.getTimeInMillis();
                tv_notice_start_date.setText(dateStr);
            } else if (dateType == 1) {//结束日期
                c.setTimeInMillis(lEndTime);
                c.set(Calendar.YEAR, year);
                c.set(Calendar.MONTH, monthOfYear);
                c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                lEndTime = c.getTimeInMillis();
                tv_notice_end_date.setText(dateStr);
            }
            pickTime(dateType);//继续选择时间
        }
    }

    @Override
    public void onTimeSet(RadialPickerLayout view, int hourOfDay, int minute, int second) {
        //时间选择回调
        String timeStr = String.format("%02d:%02d", hourOfDay, minute);
        DateFormat formatter = new SimpleDateFormat("hh:mm", Locale.getDefault());
        Date date = null;
        try {
            date = formatter.parse(timeStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar c = Calendar.getInstance();


        if (date != null) {
            if (dateType == 0) {//开始时间
                c.setTimeInMillis(lStartTime);
                c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                c.set(Calendar.MINUTE, minute);
                c.set(Calendar.SECOND, second);
                lStartTime = c.getTimeInMillis();
                tv_notice_start_time.setText(timeStr);
            } else if (dateType == 1) {//结束时间
                c.setTimeInMillis(lEndTime);
                c.set(Calendar.HOUR_OF_DAY, hourOfDay);
                c.set(Calendar.MINUTE, minute);
                c.set(Calendar.SECOND, second);
                lEndTime = c.getTimeInMillis();
                tv_notice_end_time.setText(timeStr);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;
            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    View v = findViewById(photoId);
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (v != null && bitmap != null) {
                        ImageHelper.adjustPhotoToFitSize(bitmap, USER_NOTICE_WIDTH, USER_NOTICE_HEIGHT, FitmixUtil.getTempPhotoFile());
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;
            default:
                super.onActivityResult(requestCode, resultCode, data);
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    /**
     * 剪裁图片
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(2, 1)//700 350
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }
}
