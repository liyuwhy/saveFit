package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.LocationInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.bluetooth.scanner.BluetoothLeScannerCompat;
import com.fitmix.sdk.common.bluetooth.scanner.ScanCallback;
import com.fitmix.sdk.common.bluetooth.scanner.ScanFilter;
import com.fitmix.sdk.common.bluetooth.scanner.ScanResult;
import com.fitmix.sdk.common.bluetooth.scanner.ScanSettings;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.WatchService;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.ArrayList;
import java.util.List;

/**
 * 手表相关功能虚拟Activity基类,提供的功能封装有:
 * <br/>
 * <li>1.绑定/解绑WatchService,启动/停止WatchService</li>
 * <li>检测手机蓝牙状态、启动手机蓝牙</li>
 * <li>蓝牙查找、连接手表</li>
 * <li>手机定位</li>
 */
public abstract class BaseWatchActivity extends BaseActivity {
    //定位都要通过LocationManager这个类实现
    LocationManager locationManager;
    private boolean isLocateSuccess = false;//是否定位成功

    protected ServiceConnection mWatchServiceCon;
    protected WatchService mWatchService;
    protected WatchService.ServiceFunction mWatchServiceFun;
    protected AMapLocationClient mLocationClient;//定位城市,用于天气等

    /**
     * 手机当前蓝牙是否为打开可用状态,true:是,false:否
     */
    protected boolean mBluetoothReady;

    /**
     * 是否正在搜索蓝牙
     */
    private static boolean mIsScanning = false;
    private boolean isDestroied = false;

    /**
     * 打开手机蓝牙结果回调
     */
    public interface OpenBluetoothResult {
        /**
         * 手机蓝牙打开成功
         */
        void openSuccess();

        /**
         * 手机蓝牙打开失败
         */
        void openFail();

    }

    /**
     * 打开手机蓝牙结果回调
     */
    private OpenBluetoothResult mOpenBtResult;

    private String watchAddress;

    /**
     * 蓝牙搜索回调
     */
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            if (result != null) {
                BluetoothDevice device = result.getDevice();
                Logger.i(Logger.DEBUG_TAG,"BaseWatchActivity onBatchScanResult address:"+result.getDevice().getAddress());
                if (mIsScanning && device != null && device.getAddress() != null && device.getAddress().equalsIgnoreCase(watchAddress)) {
                    Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity ---> onScanResult results found!! address:" + device.getAddress());
                    onSearchWatchSuccess(device);
                    return;
                }
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            if (results != null && results.size() > 0) {
                for (ScanResult result : results) {
                    BluetoothDevice device = result.getDevice();
                    Logger.i(Logger.DEBUG_TAG,"BaseWatchActivity onBatchScanResults address:"+result.getDevice().getAddress());
                    if (mIsScanning && device != null && device.getAddress() != null && device.getAddress().equalsIgnoreCase(watchAddress)) {
                        Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity onBatchScanResults results found!!");
                        onSearchWatchSuccess(device);
                        return;
                    }
                }
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Logger.e(Logger.DEBUG_TAG, "onScanFailed errorCode:" + errorCode);
            onSearchWatchFail();
        }
    };


    //region ==================== Activity生命周期相关 ====================

    @Override
    protected void onPause() {
        super.onPause();
        stopScan();//停止查找手表
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseLocateSource();
        if (mWatchService != null) {
            unbindWatchService();
        }
        mWatchService = null;
        unregisterBluetoothStatusReceiver();
        isDestroied = true;
    }

    //endregion ==================== Activity生命周期相关 ====================

    //region ==================== 子类继承方法相关 ====================

    /**
     * 初始化WatchService 蓝牙事件回调
     */
    protected abstract void initWatchServiceFunction();

    /**
     * 绑定WatchService成功,子类可复写用于处理连接成功后的操作
     */
    protected void onWatchServiceConnected() {
        //空方法,子类可复写使用
    }

    /**
     * 解绑WatchService成功,子类可复写用于处理解绑后的操作
     */
    protected void onWatchServiceDisconnected() {
        //空方法,子类可复写使用
    }

    /**
     * 查找手表成功
     *
     * @param device 查找到的手表蓝牙实例
     */
    protected void onSearchWatchSuccess(BluetoothDevice device) {
        //空方法,子类可复写使用
    }

    /**
     * 查找手表失败
     */
    protected void onSearchWatchFail() {
        //空方法,子类可复写使用
    }

    /**
     * 查找手表停止
     */
    protected void onSearchWatchStop() {
        //空方法,子类可复写使用
    }

    /**
     * 定位成功
     *
     * @param locationInfo 定位信息
     */
    protected void onLocateSuccess(LocationInfo locationInfo) {

    }
    //endregion ==================== 子类继承方法相关 ====================

    //region ==================== 检测手机蓝牙状态、启动手机蓝牙相关 ====================

    /**
     * 手机当前蓝牙是否为可用状态
     *
     * @return true:是,false:否
     */
    protected boolean isBluetoothReady() {
        if (FitmixUtil.isBLEEnabled(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return FitmixUtil.isGpsEnable(this);//开了GPS
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     * 打开手机蓝牙
     *
     * @param activateCallback 打开手机蓝牙结果回调
     */
    protected void openBluetooth(OpenBluetoothResult activateCallback) {
        mOpenBtResult = activateCallback;
        if (FitmixUtil.isBLEEnabled(this)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (FitmixUtil.isGpsEnable(this)) {//开了GPS
                    bluetoothIsReady();
                } else {
                    Toast.makeText(this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                    FitmixUtil.enableBleGPS(this);//去开启GPS
                }
            } else {
                bluetoothIsReady();
            }
        } else {
            FitmixUtil.requestBlueTooth(this);
        }
    }

    /**
     * 手机蓝牙已准备好
     */
    private void bluetoothIsReady() {
        mBluetoothReady = true;
        if (mOpenBtResult != null) {
            mOpenBtResult.openSuccess();
        }
    }

    //endregion ==================== 检测手机蓝牙状态、启动手机蓝牙相关 ====================

    //region ==================== 启动/停止、绑定/解绑 WatchService ====================

    /**
     * 绑定手表服务
     */
    protected void bindWatchService() {
        initWatchServiceFunction();
        Intent intent = new Intent(this, WatchService.class);
        mWatchServiceCon = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(WatchService.SERVICE_NAME))
                    return;
                mWatchService = ((WatchService.LocalBinder) service).getService();
//                Logger.w(Logger.DEBUG_TAG, "BaseWatchActivity-->onServiceConnected mPageName:" + mPageName
//                        + ",mWatchServiceFun is null:" + (mWatchServiceFun == null));
                if (mWatchService != null) {
                    if (mWatchServiceFun != null && mPageName != null) {
                        mWatchService.addServiceFunction(mPageName, mWatchServiceFun);
                    }
                }
                onWatchServiceConnected();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                Logger.d(Logger.LOG_TAG, "onServiceDisconnected -" + name + " this:" + this);
                if (mWatchService != null && mPageName != null) {
                    mWatchService.removeServiceFunction(mPageName);
                    Toast.makeText(getApplicationContext(), getResources().getText(R.string.a2dp_disconnected), Toast.LENGTH_SHORT).show();
                }
                mWatchService = null;
                onWatchServiceDisconnected();
            }
        };
        bindService(intent, mWatchServiceCon, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑手表服务
     */
    protected void unbindWatchService() {
        if (mWatchServiceCon != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(mWatchServiceCon);
            }
        }
        mWatchServiceCon = null;
    }

    /**
     * 开启WatchService
     */
    protected void startWatchService() {
        Intent i = new Intent(this, WatchService.class);
        startService(i);
    }

    /**
     * 停止WatchService
     */
    protected void stopWatchService() {
        Intent i = new Intent(this, WatchService.class);
        stopService(i);
    }

    //endregion ==================== 启动/停止、绑定/解绑 WatchService ====================

    //region ==================== 蓝牙查找、连接手表 ====================

    /**
     * 根据mac地址搜索手表
     *
     * @param watchMacAddress 手表蓝牙mac地址
     * @param searchDuration  搜索持续时长,单位为毫秒
     */
    protected void searchWatch(final String watchMacAddress, long searchDuration) {
        watchAddress = watchMacAddress;
        if (isDestroied) {
            stopScan();
            return;
        }
        if (searchDuration < 5000 || searchDuration > 70000) {
            searchDuration = 60000;//默认30秒
        }
        if (watchMacAddress != null) {//开启搜索
            Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity-->searchWatch watchMacAddress:" + watchMacAddress);
            final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
            final ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(1000).setUseHardwareBatchingIfSupported(false).build();
            final List<ScanFilter> filters = new ArrayList<>();
            ScanFilter filter = new ScanFilter.Builder()
                    .build();
            mIsScanning = true;
            filters.add(filter);
            if (mScanCallback == null)
                mScanCallback = new ScanCallback() {
                    @Override
                    public void onScanResult(int callbackType, ScanResult result) {
                        super.onScanResult(callbackType, result);
                        if (result != null) {
                            BluetoothDevice device = result.getDevice();
                            Logger.i(Logger.DEBUG_TAG,"BaseWatchActivity onBatchScanResult address:"+result.getDevice().getAddress());
                            if (mIsScanning && device != null && device.getAddress() != null && device.getAddress().equalsIgnoreCase(watchMacAddress)) {
                                Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity ---> onScanResult results found!! address:" + device.getAddress());
                                onSearchWatchSuccess(device);
                                return;
                            }
                        }
                    }

                    @Override
                    public void onBatchScanResults(List<ScanResult> results) {
                        if (results != null && results.size() > 0) {
                            for (ScanResult result : results) {
                                BluetoothDevice device = result.getDevice();
                                Logger.i(Logger.DEBUG_TAG,"BaseWatchActivity onBatchScanResults address:"+result.getDevice().getAddress());
                                if (mIsScanning && device != null && device.getAddress() != null && device.getAddress().equalsIgnoreCase(watchMacAddress)) {
                                    Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity onBatchScanResults results found!!");
                                    onSearchWatchSuccess(device);
                                    return;
                                }
                            }
                        }
                    }

                    @Override
                    public void onScanFailed(int errorCode) {
                        super.onScanFailed(errorCode);
                        Logger.e(Logger.DEBUG_TAG, "onScanFailed errorCode:" + errorCode);
                        onSearchWatchFail();
                    }
                };

            try {
                scanner.startScan(filters, settings, mScanCallback);
            } catch (Exception ex) {
                if (mScanCallback != null) {
                    mScanCallback.onScanFailed(-1);
                }
                showAppMessage(R.string.scanner_empty, AppMsg.STYLE_ALERT);
            }
            ThreadManager.getMainHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopScan();
                }
            }, searchDuration);
        }
    }

    /**
     * 停止蓝牙搜索
     */
    protected void stopScan() {
        Logger.i(Logger.DEBUG_TAG, "BaseWatchActivity-->stopScan");
        final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        if (mScanCallback != null) {
            scanner.stopScan(mScanCallback);
        }
        mScanCallback = null;
        mIsScanning = false;
        onSearchWatchStop();
    }
    //endregion ==================== 蓝牙查找、连接手表 ====================

    //region ==================== gps定位相关 ====================

    /**
     * 获取定位信息 用于天气等
     */
    protected void getLocate() {
        //1.初始化定位
        if (mLocationClient == null) {
            mLocationClient = new AMapLocationClient(this);
        }
        //2.设置定位参数
        AMapLocationClientOption mLocationOption = new AMapLocationClientOption();
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Battery_Saving);
        mLocationOption.setOnceLocation(true);
        mLocationOption.setHttpTimeOut(30000);// 定位时间
        mLocationOption.setNeedAddress(true);
        //3.设置定位回调监听
        mLocationClient.setLocationListener(new AMapLocationListener() {
            @Override
            public void onLocationChanged(AMapLocation aMapLocation) {
                Logger.i(Logger.DEBUG_TAG, "aMapLocation : " + aMapLocation.toString());
                onLocated(aMapLocation);
            }
        });
        //4.启动定位
        mLocationClient.startLocation();
    }

    /**
     * 设置定位得到的城市
     *
     * @param aMapLocation 定位点
     */
    private void onLocated(AMapLocation aMapLocation) {
        if (aMapLocation != null && !TextUtils.isEmpty(aMapLocation.getCity())) {
            String city = aMapLocation.getCity();
            if (city != null && city.length() > 2) {//对得到的城市名称处理 服务器端 只能解析如 "深圳"
                if (city.endsWith("市")) {
                    city = city.substring(0, city.length() - 1);
                }
            }
            String province = aMapLocation.getProvince();
            if (province.length() > 2) {
                if (province.endsWith("省")) {
                    province = province.substring(0, province.length() - 1);
                }
            }
            double latitude = aMapLocation.getLatitude();
            double longitude = aMapLocation.getLongitude();

            Logger.d("TT", "latitude:" + latitude + ",longitude:" + longitude + ",SETTING_IS_ABROAD:" + SettingsHelper.getBoolean(Config.SETTING_IS_ABROAD, false));
            //保存定位信息
            LocationInfo locationInfo = new LocationInfo();
            locationInfo.setLocationTime(System.currentTimeMillis());
            locationInfo.setCity(city);
            locationInfo.setLat(latitude);
            locationInfo.setLng(longitude);
            locationInfo.setProvince(province);

            String locationStr = JsonHelper.createJsonString(locationInfo);
            SettingsHelper.putString(Config.SETTING_LOCATION_INFO, locationStr != null ? locationStr : "");

            //定位成功回调
            onLocateSuccess(locationInfo);
        }
        releaseLocateSource();
    }

    /**
     * 获取最好的定位方式
     */
    protected void getBestLocation(Context context) {
        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        Location location = null;
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);//低精度，如果设置为高精度，依然获取不了location。
        criteria.setAltitudeRequired(false);//不要求海拔
        criteria.setBearingRequired(false);//不要求方位
        criteria.setCostAllowed(true);//允许有花费
        criteria.setPowerRequirement(Criteria.POWER_LOW);//低功耗

        //从可用的位置提供器中，匹配以上标准的最佳提供器
        String locationProvider = locationManager.getBestProvider(criteria, true);
        if (Build.VERSION.SDK_INT >= 23) {
            //如果用户并没有同意该权限
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //申请权限
                //requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
            } else {
                //有权限直接获取地理位置
                location = locationManager.getLastKnownLocation(locationProvider);
            }
        } else {//低版本手机，直接获取位置信息
            location = locationManager.getLastKnownLocation(locationProvider);
        }
        if (location != null) {
            //不为空,显示地理位置经纬度
            isLocateSuccess = true;
            requestWeatherApi(location);
        }
        if (locationProvider != null) {
            //监视地理位置变化
            locationManager.requestLocationUpdates(locationProvider, 60 * 60 * 1000, 5 * 1000, locationListener);
        }

    }

    LocationListener locationListener = new LocationListener() {

        @Override
        public void onStatusChanged(String provider, int status, Bundle arg2) {

        }

        @Override
        public void onProviderEnabled(String provider) {
            Logger.d(Logger.DEBUG_TAG, "onProviderEnabled: " + provider + ".." + Thread.currentThread().getName());
        }

        @Override
        public void onProviderDisabled(String provider) {
            Logger.d(Logger.DEBUG_TAG, "onProviderDisabled: " + provider + ".." + Thread.currentThread().getName());
        }

        @Override
        public void onLocationChanged(Location location) {
            Logger.d(Logger.DEBUG_TAG, "onLocationChanged: " + ".." + Thread.currentThread().getName());
            if (!isLocateSuccess) {
                //首次没有定位成功，则执行获取天气
                requestWeatherApi(location);
            }

        }
    };

    protected void requestWeatherApi(Location location) {
        if (location != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            String lngLat = longitude + "," + latitude;
            Logger.d(Logger.DEBUG_TAG, "latitude:" + latitude + ",longitude" + longitude);
            int requestId = UserDataManager.getInstance().getCityWeather(lngLat, true);
            registerDataReqStatusListener(requestId);
        }
    }


    /**
     * 释放定位资源
     */
    protected void releaseLocateSource() {
        if (mLocationClient != null) {
            mLocationClient.stopLocation();
            mLocationClient.onDestroy();
        }
        mLocationClient = null;
        if (locationManager != null) {
            locationManager.removeUpdates(locationListener);
        }
        locationManager = null;
    }

    /**
     * 获取保存在最近一次的定位信息
     */
    protected LocationInfo getLastLocationInfo() {
        LocationInfo locationInfo = null;
        String locationStr = SettingsHelper.getString(Config.SETTING_LOCATION_INFO, "");
        if (!TextUtils.isEmpty(locationStr)) {
            locationInfo = JsonHelper.getObject(locationStr, LocationInfo.class);
        }

        return locationInfo;
    }

    //endregion ==================== gps定位相关 ====================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case Config.REQUEST_ENABLE_BLUETOOTH:
                if (RESULT_OK == resultCode) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (FitmixUtil.isGpsEnable(this)) {//开了GPS
                            bluetoothIsReady();
                        } else {
                            Toast.makeText(this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                            FitmixUtil.enableBleGPS(this);//去开启GPS
                        }
                    } else {
                        bluetoothIsReady();
                    }
                    break;
                }
                //蓝牙开启失败
                Toast.makeText(this, getString(R.string.activity_watch_search_bt_fail), Toast.LENGTH_SHORT).show();
                if (mOpenBtResult != null) {
                    mOpenBtResult.openFail();
                }
                break;

            case Config.BLE_REQUEST_ENABLE_GPS://BLE功能请求GPS权限
                if (RESULT_OK == resultCode || FitmixUtil.isGpsEnable(this)) {//成功授权
                    bluetoothIsReady();
                    break;
                }
                //GPS开启失败
                Toast.makeText(this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                if (mOpenBtResult != null) {
                    mOpenBtResult.openFail();
                }
                break;
        }
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {//java.lang.NullPointerException: Attempt to invoke virtual method 'boolean android.content.Intent.migrateExtraStreamToClipData()' on a null object reference
        //at android.app.Instrumentation.execStartActivity(Instrumentation.java:1516)
        //at android.app.Activity.startActivityForResult(Activity.java:4030)
        try {
            if (intent == null) {
                intent = new Intent();
            }
            super.startActivityForResult(intent, requestCode);
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }

}
