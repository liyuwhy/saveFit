package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.TimeCountUtil;
import com.fitmix.sdk.model.api.ApiConstants;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.countrypicker.Country;
import com.fitmix.sdk.view.countrypicker.CountryPicker;
import com.fitmix.sdk.view.countrypicker.OnCountryPickerListener;
import com.fitmix.sdk.view.widget.AppMsg;

/**
 * 注册界面
 */
public class RegisterActivity extends BaseActivity {


    //    private final int REQUEST_TYPE_GET_AUTH_CODE = 0;
//    private final int REQUEST_TYPE_REGIST_EMAIL = 1;
//    private final int REQUEST_TYPE_REGIST_PHONE = 2;
    private RadioGroup rg_register;
    private LinearLayout ll_register_area;
    private EditText txt_phone;
    private TextView txt_china_phone;
    private EditText txt_account;
    //private EditText txt_nickname;
    private EditText txt_password;
    private EditText txt_confirm_password;
    private EditText txt_auth_code;
    private Button btn_get_auth_code;
    private Button btn_sign_up;
    private CheckBox cb_agree;
    private TextView tv_label_area;

    private EditText txt_email_auth_code;//邮箱验证码
    private Button btn_get_email_auth_code;//获取邮箱验证码

    private String mEmailAddress;
    private String mPhoneNumber;
    private String mTempPhoneNumber;
    private String mTempEmail;//保存获取邮箱验证码时的邮箱,防止用户在注册时用另外的邮箱注册
    //    private String mUsername;
    private String mPassword;
    private String mConfirmPwd;
//    private String sLoginString;

    public boolean isEmailRegister = false;
    private String validationCode;//客户端输入的验证码

//    private static String serverValidationCode;//服务器端获取的验证码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        setPageName("RegisterActivity");
        initToolbar();
        initViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        if (timeCountUtil != null) {
            timeCountUtil.cancel();
            timeCountUtil = null;
        }

        if (emailAuthCodeTimeCount != null) {
            emailAuthCodeTimeCount.cancel();
            emailAuthCodeTimeCount = null;
        }

        super.onDestroy();
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        rg_register = (RadioGroup) findViewById(R.id.rg_regist);
        ll_register_area = findViewById(R.id.ll_register_area);
        tv_label_area = findViewById(R.id.tv_label_area);
        txt_phone = (EditText) findViewById(R.id.txt_phone_number);
        txt_china_phone = (TextView) findViewById(R.id.txt_china_number);
        txt_china_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(RegisterActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                        tv_label_area.setText(country.getName());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog

            }
        });
     /*   txt_china_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_china_phone.setFocusable(true);
                txt_china_phone.setFocusableInTouchMode(true);
            }
        });*/
        txt_account = (EditText) findViewById(R.id.txt_account);
        //txt_nickname = (EditText) findViewById(R.id.txt_nickname);
        txt_password = (EditText) findViewById(R.id.txt_password);
        txt_confirm_password = (EditText) findViewById(R.id.txt_confirm_password);

        txt_auth_code = (EditText) findViewById(R.id.txt_auth_code);
        btn_get_auth_code = (Button) findViewById(R.id.btn_get_auth_code);
        btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));

        txt_email_auth_code = (EditText) findViewById(R.id.txt_mail_auth_code);
        btn_get_email_auth_code = (Button) findViewById(R.id.btn_get_mail_auth_code);
        btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));

        cb_agree = (CheckBox) findViewById(R.id.cb_agree);
        btn_sign_up = (Button) findViewById(R.id.btn_sign_up);
        cb_agree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    setRegisterBtnEnable(true);
                } else {
                    setRegisterBtnEnable(false);
                }
            }
        });

        ll_register_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CountryPicker countryPicker =
                        new CountryPicker.Builder().with(RegisterActivity.this)
                                .listener(new OnCountryPickerListener() {
                                    @Override public void onSelectCountry(Country country) {
                                        txt_china_phone.setText(country.getDialCode());
                                        tv_label_area.setText(country.getName());
                                    }
                                })
                                .build();
                countryPicker.showDialog(getSupportFragmentManager()); // Show the dialog
            }
        });



        rg_register.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup rg, int id) {
                switch (id) {
                    case R.id.radio_phone_regist://手机注册
                        refreshPwd();
                        ll_register_area.setVisibility(View.VISIBLE);
                        txt_account.setVisibility(View.GONE);
                        txt_phone.setVisibility(View.VISIBLE);
                        txt_china_phone.setVisibility(View.VISIBLE);
                        txt_china_phone.setText(getResources().getString(R.string.china_phone_code));
                        txt_auth_code.setVisibility(View.VISIBLE);
                        btn_get_auth_code.setVisibility(View.VISIBLE);
                        txt_email_auth_code.setVisibility(View.GONE);
                        btn_get_email_auth_code.setVisibility(View.GONE);
                        isEmailRegister = false;
                        break;
                    case R.id.radio_email_regist://邮箱注册
                        refreshPwd();
                        ll_register_area.setVisibility(View.GONE);
                        txt_account.setVisibility(View.VISIBLE);
                        txt_phone.setVisibility(View.GONE);
                        txt_china_phone.setVisibility(View.GONE);
                        txt_auth_code.setVisibility(View.GONE);
                        btn_get_auth_code.setVisibility(View.GONE);
                        txt_email_auth_code.setVisibility(View.VISIBLE);
                        btn_get_email_auth_code.setVisibility(View.VISIBLE);
                        isEmailRegister = true;
                        break;
                }
            }
        });
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "RegisterActivity-->requestId:" + requestId + "  result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 10://请求手机验证码
//                AuthCode authCode = JsonHelper.getObject(dataReqResult.getResult(), AuthCode.class);
//                if (authCode != null)
//                    serverValidationCode = authCode.getData();
                BaseBean authCodeResult = JsonHelper.getObject(result, BaseBean.class);
                if (authCodeResult != null && authCodeResult.getCode() == 0) {
                    showAppMessage(R.string.activity_register_get_auth_code_success, AppMsg.STYLE_INFO);
                }
                break;
            case Config.MODULE_USER + 11://请求邮箱验证码
                BaseBean emailAuthCodeResult = JsonHelper.getObject(result, BaseBean.class);
                if (emailAuthCodeResult != null && emailAuthCodeResult.getCode() == 0) {
                    showAppMessage(R.string.activity_register_get_email_auth_code_success, AppMsg.STYLE_INFO);
                }
                break;
            case Config.MODULE_USER + 20://邮箱注册
                hideLoadingDialog();
                afterEmailRegister(true);
                break;
            case Config.MODULE_USER + 21://手机注册
                hideLoadingDialog();
                afterMobileRegister(true);
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 10://请求手机验证码
            case Config.MODULE_USER + 11://请求邮箱验证码
            case Config.MODULE_USER + 20://邮箱注册
            case Config.MODULE_USER + 21://手机注册
                hideLoadingDialog();
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                setRegisterBtnEnable(true);
                break;
        }
    }

    /**
     * 邮箱注册结果
     *
     * @param isSuccess 注册成功与否
     */
    private void afterEmailRegister(boolean isSuccess) {
        if (isSuccess) {
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_USER, mEmailAddress);
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_PWD, mPassword);
            PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_IS_NEW_EMAIL_REGISTER, true);
            setResult(RESULT_OK);
            finish();
        }
    }

    /**
     * 手机注册结果
     *
     * @param isSuccess 注册成功与否
     */
    private void afterMobileRegister(boolean isSuccess) {
        if (isSuccess) {
            String countryCode = txt_china_phone.getText().toString();
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_USER, countryCode+mPhoneNumber);
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_LAST_PWD, mPassword);
            PrefsHelper.with(this, Config.PREFS_USER).writeBoolean(Config.SP_KEY_IS_NEW_PHONE_REGISTER, true);
            setResult(RESULT_OK);
            finish();
        }
    }

    /**
     * 检验手机号码是否合法
     */
    private int checkPhoneNumber() {
        mPhoneNumber = txt_phone.getText().toString();
        if (!FitmixUtil.isMobileNumber(mPhoneNumber))
            return Config.ERROR_PHONE_DATA;

        return Config.ERROR_NO_ERROR;
    }

    /**
     * 检验邮箱是否合法
     */
    private int checkEmail() {
        mEmailAddress = txt_account.getText().toString();
        if (!FitmixUtil.isEmail(mEmailAddress))
            return Config.URL_RET_CODE_EMAIL_EMPTY;

        return Config.ERROR_NO_ERROR;
    }

    /**
     * 注册
     */
    private void register() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        registerInNetwork();
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_sign_up://注册
                if (cb_agree.isChecked())
                    register();
                break;
            case R.id.btn_get_auth_code://获取手机验证码
                changeBtnGetCode();
                break;

            case R.id.btn_get_mail_auth_code://获取邮箱验证码
                changeBtnGetEmailAuthCode();
                break;

            case R.id.txt_user_agreement://协议
                startPrivacy();
                break;
        }
    }

    /**
     * 启动隐私
     */
    private void refreshPwd() {
        txt_password.setText("");
        txt_confirm_password.setText("");
    }


    /**
     * 启动隐私
     */
    private void startPrivacy() {
        Intent intent = new Intent();
        intent.setClass(this, WebViewActivity.class);
        intent.putExtra("url", ApiConstants.appPrivacyPolicy());
        intent.putExtra("title", getResources().getString(R.string.activity_about_us_privacy));
        startActivity(intent);
    }

    /**
     * 获取手机验证码
     */
    private void changeBtnGetCode() {
        String countryCode =txt_china_phone.getText().toString();
        mPhoneNumber = txt_phone.getText().toString();
        if (countryCode.contains("86")){
            int error = checkPhoneNumber();
            if (error != Config.ERROR_NO_ERROR) {
                showErrorMsg(error);
                return;
            }
        }
        getAuthCode();//获取手机验证码
        timeCountUtil.start();
    }

    /**
     * 获取邮箱验证码
     */
    private void changeBtnGetEmailAuthCode() {
        int error = checkEmail();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        getEmailAuthCode();//获取邮箱验证码
        emailAuthCodeTimeCount.start();
    }

    /**
     * 获取手机验证码倒计时
     */
    private TimeCountUtil timeCountUtil = new TimeCountUtil(60 * 1000, 1000, new TimeCountUtil.ITimeCountListener() {
        @Override
        public void onTick(long millisUntilFinished) {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "(", String.valueOf(millisUntilFinished / 1000), ")"));
            btn_get_auth_code.setEnabled(false);
        }

        @Override
        public void onFinish() {
            btn_get_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));
            btn_get_auth_code.setEnabled(true);
        }
    });

    /**
     * 获取邮箱验证码倒计时
     */
    private TimeCountUtil emailAuthCodeTimeCount = new TimeCountUtil(60 * 1000, 1000, new TimeCountUtil.ITimeCountListener() {
        @Override
        public void onTick(long millisUntilFinished) {
            btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "(", String.valueOf(millisUntilFinished / 1000), ")"));
            btn_get_email_auth_code.setEnabled(false);
        }

        @Override
        public void onFinish() {
            btn_get_email_auth_code.setText(String.format(getString(R.string.activity_register_get_auth_code), "", "", ""));
            btn_get_email_auth_code.setEnabled(true);
        }
    });


    /**
     * 网络注册
     */
    private void registerInNetwork() {
        showLoadingDialog(R.string.activity_register_registering, 1000);
        if (isEmailRegister) {
//            int requestId = UserDataManager.getInstance().emailRegister(mEmailAddress,
//                    mEmailAddress, mPassword, true);
            int requestId = UserDataManager.getInstance().emailRegister(mEmailAddress,
                    validationCode, mPassword, true);
            registerDataReqStatusListener(requestId);
        } else {
            String countryCode = txt_china_phone.getText().toString();
            countryCode = countryCode.replace("+","%2b");
            int requestId = UserDataManager.getInstance().mobileRegister(countryCode+mPhoneNumber, validationCode, mPassword, true);
            registerDataReqStatusListener(requestId);

        }

        //防止重复点击
        setRegisterBtnEnable(false);
    }

    /**
     * 设置注册按钮可用性
     */
    private void setRegisterBtnEnable(boolean enable) {
        if (btn_sign_up != null) {
            btn_sign_up.setEnabled(enable);
        }
    }

    /**
     * 获取手机验证码
     */
    private void getAuthCode() {
        mTempPhoneNumber = mPhoneNumber;
        String countryCode =txt_china_phone.getText().toString();
        countryCode = countryCode.replace("+","%2b");
        int requestId = UserDataManager.getInstance().getAuthCode(countryCode+mPhoneNumber, true);
        registerDataReqStatusListener(requestId);

    }

    /**
     * 获取邮箱验证码
     */
    private void getEmailAuthCode() {
        mTempEmail = mEmailAddress;
        int requestId = UserDataManager.getInstance().getEmailAuthCode(mEmailAddress, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 刷新界面
     */
    private void refresh() {
        txt_password.setText(mPassword);
        txt_account.setText(mEmailAddress);
    }

    /**
     * 检查输入错误
     *
     * @return Config.ERROR_NO_ERROR   正确
     * 其它                             错误码
     */

    private int checkInputError() {
        mPassword = txt_password.getText().toString();
        mConfirmPwd = txt_confirm_password.getText().toString();


        if (isEmailRegister) {
            mEmailAddress = txt_account.getText().toString();
            validationCode = txt_email_auth_code.getText().toString().trim();
            if (!FitmixUtil.isEmail(mEmailAddress)) {
                return Config.ERROR_FORMAT_ERROR;
            }

            if (TextUtils.isEmpty(validationCode)) {
                return Config.ERROR_EDIT_AUTH_CODE;
            }

            if (!mEmailAddress.equals(mTempEmail)) {
                return Config.ERROR_EMAIL_NOT_MATCH;
            }
        } else {
            String countryCode = txt_china_phone.getText().toString();
            mPhoneNumber = txt_phone.getText().toString();
            validationCode = txt_auth_code.getText().toString().trim();
            if (countryCode.contains("86")){
                if (!FitmixUtil.isMobileNumber(mPhoneNumber))
                    return Config.ERROR_PHONE_DATA;

                if (!mPhoneNumber.equals(mTempPhoneNumber)) {
                    return Config.ERROR_PHONE_NUMBER_NOT_MATCH;
                }
            }

//            if (TextUtils.isEmpty(serverValidationCode)) {//不再在客户端验证
//                return Config.ERROR_GET_AUTH_CODE;
//            }
            if (TextUtils.isEmpty(validationCode)) {
                return Config.ERROR_EDIT_AUTH_CODE;
            }
//            if (!validationCode.equals(serverValidationCode)) {//不再在客户端验证
//                return Config.ERROR_AUTH_CODE_WRONG;
//            }

        }

        if (mPassword.length() < Config.PASSWORD_LENGTH_MIN)
            return Config.ERROR_PASSWORD_TOO_SHORT;

        if (!mPassword.equals(mConfirmPwd))
            return Config.ERROR_PASSWORD_NOT_MATCH;
        return Config.ERROR_NO_ERROR;
    }

    @Override
    protected void clickToRun() {
    }//该activity不做操作

}
