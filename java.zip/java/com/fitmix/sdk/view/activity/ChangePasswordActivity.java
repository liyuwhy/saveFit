package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;

public class ChangePasswordActivity extends BaseActivity {

    private EditText txt_old_password;
    private EditText txt_new_password;
    private EditText txt_confirm_password;

    private String sOldPassword;
    private String sNewPassword;
    private String sConfirmPassword;


    /**
     * 初始化控件
     */
    protected void initViews() {
        txt_old_password = (EditText) findViewById(R.id.txt_old_password);
        txt_new_password = (EditText) findViewById(R.id.txt_new_password);
        txt_confirm_password = (EditText) findViewById(R.id.txt_confirm_password);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        switch (requestId) {
            case Config.MODULE_USER + 12://更换密码
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.activity_change_password_change_password_sucess)
                        .positiveText(android.R.string.ok)
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                setResult(RESULT_OK);
                                finish();
                            }
                        }).show();
                break;
        }

    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 12://更换密码
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        setPageName("ChangePasswordActivity");
        initToolbar();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        initViews();
    }

    /**
     * 检查旧密码是否正确
     *
     * @return true        检验正确
     * false       验证失败
     */
    private boolean checkOldPassword() {
        return sOldPassword.equals(PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD, ""));

    }

    /**
     * 检查新密码是否一致
     *
     * @return true        检验正确
     * false       验证失败
     */
    private boolean checkNewPassword() {
        return sNewPassword.equals(sConfirmPassword);
    }

    /**
     * 检验输入是否争取
     *
     * @return true    检验成功
     * false      检验失败
     */
    private boolean checkInput() {
        sOldPassword = txt_old_password.getText().toString();
        sNewPassword = txt_new_password.getText().toString();
        sConfirmPassword = txt_confirm_password.getText().toString();
        if (TextUtils.isEmpty(sOldPassword) || TextUtils.isEmpty(sNewPassword) || TextUtils.isEmpty(sConfirmPassword)) {
            showAppMessage(R.string.un_fill_in, AppMsg.STYLE_ALERT);
            return false;
        }
        if (!checkOldPassword()) {
            showAppMessage(R.string.activity_change_password_old_password_wrong, AppMsg.STYLE_ALERT);
            return false;
        }
        if (!checkNewPassword()) {
            showAppMessage(R.string.activity_change_password_new_password_wrong, AppMsg.STYLE_ALERT);
            return false;
        }
        return true;
    }

    /**
     * 提交任务
     */
    private void processSubmit() {
        if (!checkInput()) return;
        //不考虑缓存
        int requestId = UserDataManager.getInstance().changePassword(sOldPassword, sNewPassword, true);
        registerDataReqStatusListener(requestId);
        showAppMessage(R.string.info_setting, AppMsg.STYLE_INFO);
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_change://修改密码
                processSubmit();

                break;
        }
    }

}
