package com.fitmix.sdk.view.activity;

import android.os.Bundle;

import com.fitmix.sdk.R;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.adapter.FaqAdapter;
import com.fitmix.sdk.view.bean.FaqEntity;
import com.fitmix.sdk.view.widget.BounceListView;

import java.util.ArrayList;

public class FaqActivity extends BaseActivity {

    private BounceListView list_faq;
    private FaqAdapter adapter;
    private ArrayList<FaqEntity> faqs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
        setPageName("FaqActivity");
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        list_faq = (BounceListView) findViewById(R.id.list_faq);
        faqs = new ArrayList<>();
        adapter = new FaqAdapter(this, faqs);
        list_faq.setAdapter(adapter);
        String language = ApiUtils.getLanguage();
        if (language == null || language.endsWith("zh")) {//中文
            faqs.add(new FaqEntity("1、如何绑定微信运动?", "点击:“我的设置”-“我的微信排名”-“同步并查看排名”-“绑定设备”即可绑定微信运动。"));
            faqs.add(new FaqEntity("2、微信运动步数为0?", "点击:“我的设置”-“我的微信排名”-“同步并查看排名”,会有详细情况解释。"));

            faqs.add(new FaqEntity("3、APP无法计步/步数偏少?", "(一)原因一:手机管理系统禁止乐享动在后台计步<br/>&nbsp;&nbsp;解决方案:在手机“设置或者安全中心”页面,开启【乐享动】自启动、授权后台运行权限,或者将手机添加为“省电模式”、“垃圾清理”的白名单。<br/><br/>具体品牌操作指导<br/>" +
                    "小米手机:&nbsp;(1)设置-授权管理-自启动管理-允许乐享动自启动;&nbsp;(2)设置-电量和性能-神隐模式-应用配置-乐享动-无限制。<br/><br/>华为手机:&nbsp;(1)设置-授权管理-应用-乐享动-设置单项权限-信任此应用、开机自动启动;&nbsp;(2)设置-受保护的后台应用-开启乐享动。<br/><br/>" +
                    "魅族手机:&nbsp;(1)安全中心-授权管理-自启动-乐享动;&nbsp;(2)安全中心-清理垃圾-右上角{设置}-进程和后台服务白名单-添加-乐享动;&nbsp;(3)安全中心-省电模式—智能省电模式-开启乐享动。<br/><br/>OPPO手机:&nbsp;(1)设置-授权管理-常规-安全服务-纯净后台-添加程序-选择乐享动。<br/><br/>" +
                    "(二)原因二:部分品牌手机不支持息屏计步功能。<br/>&nbsp;&nbsp;解决方案:点击“我的设置”-“检测传感器”,检测手机是否支持息屏计步功能。"));

            faqs.add(new FaqEntity("4、APP在运动过程闪退?", "原因:手机管理系统禁止乐享动在后台运行。<br/>&nbsp;&nbsp;解决方案:在手机“设置或者安全中心”页面,开启【乐享动】自启动、授权后台运行权限,或者将手机添加为“省电模式”、“垃圾清理”的白名单。" +
                    "<br/><br/>具体品牌操作<br/>小米手机:&nbsp;(1)设置-授权管理-自启动管理-允许乐享动自启动;&nbsp;(2)设置-电量和性能-神隐模式-应用配置-乐享动-无限制。<br/><br/>华为手机:&nbsp;(1)设置-授权管理-应用-乐享动-信任此应用、开机自动启动;&nbsp;(2)设置-受保护的后台应用-开启乐享动。<br/><br/>" +
                    "魅族手机:&nbsp;(1)安全中心-授权管理-自启动-乐享动;&nbsp;(2)安全中心-清理垃圾-右上角{设置}-进程和后台服务白名单-添加-乐享动;&nbsp;(3)安全中心-省电模式—智能省电模式-开启乐享动。<br/><br/>OPPO手机:&nbsp;(1)设置-授权管理-常规-安全服务-纯净后台-添加程序-选择乐享动。"));

            faqs.add(new FaqEntity("5、室外运动模式,APP里程不准确?", "        原因:GPS信号弱,可能是由于障碍物阻挡、天气影响等等。<br/>解决方案:尽量走到开阔的地方运动,运动前可查看GPS信号强弱与否。"));
            faqs.add(new FaqEntity("6、如何采集心率?", "        先将心率设备打开,点击乐享动APP:我的-静息心率-连接心率设备,搜索设备连接即可。注:乐享动可以连接大部分心率设备,但不保证所有心率设备都可以连接。"));
            faqs.add(new FaqEntity("7、节拍器在哪里?", "        点击:开始运动-开始,在运动界面上方,音乐播放按钮左滑。"));
            faqs.add(new FaqEntity("8、室内和户外运动有什么区别?", "        室内和户外运动的数据计算方式不一样,请选择对应的运动模式,否则可能导致运动数据统计有误。"));
            faqs.add(new FaqEntity("9、怎么导入本地音乐?", "        在“动听”页面,选择“我的音乐”,点击“本地音乐”-“导入歌曲”就可以自动扫描导入手机里的本地音乐啦~(AMR 、WAV、AWB格式不会导入)"));
            faqs.add(new FaqEntity("10、其他问题可直接联系我们:\n(1)关注“乐享动”微信公众号,详细描述问题发送给我们;\n(2)乐享动用户QQ群:515536404,咨询群管理;\n(3)电话:0755-26413937(工作日9:00-18:30)。", null));
        } else {
            faqs.add(new FaqEntity("1、How to bind WeRun with my Fitmix?", "Click on: settings-WeRun ranking-sync and check the ranking-tap “follow” button."));
            faqs.add(new FaqEntity("2、Why my WeChat sport step data is zero?", "Click on: settings-WeChat sport ranking-sync and check the ranking-find solutions."));

            faqs.add(new FaqEntity("3、App is not working properly to collect step data?", "(A) Cause one: The mobile phone operating system doesn’t allow a background task to run, so the Fitmix app fails to collect step data.<br/> Suggested solution: click on your phone setting option, enable the Fitmix app running automatically or add Fitmix into \"Power-Saving Mode\", \"Garbage Disposal\" White lists.<br/><br/>" +
                    "(B) Cause two: Some smartphone doesn’t collect the step data when it’s screen turning off.<br/>Suggested solution: click on setting option –detector, make sure the smart-phone can collect the step data when it’s screen turning off."));

            faqs.add(new FaqEntity("4、Fitmix app crashes when doing workout?", "Cause:The mobile phone operating system does not allow a background task to run.<br/><br/> Suggested solution: click on your phone setting option or privacy option, enable the Fitmix app running automatically or add Fitmix into \"Power-Saving Mode\", \"Garbage Disposal\" White lists."));

            faqs.add(new FaqEntity("5、Outdoor sports mode, the app is not accurate enough to give the data you need?", "        Cause:GPS signal is weak, the tall buildings，weather conditions make for inaccuracies.<br/>Suggested solution: Try to choose outdoor routes along open, relatively flat areas whenever possible, see the GPS signal strength before doing workout."));
            faqs.add(new FaqEntity("6、How to collect the heart rate data?", "Turn on the heart rate monitor and click on Fitmix APP: mine-resting rate heart –pair with devices.<br/>Note: Fitmix can pair with most of the heart rate monitors."));
            faqs.add(new FaqEntity("7、Where is the Sports metronome?", "Click on: Run-Go button，go into the exercise menu, and then swipe the music button(in left direction"));
            faqs.add(new FaqEntity("8、What is the difference between indoor and outdoor mode?", "Sports data is calculated in different ways. Please choose the correct mode, otherwise the final data may be wrong."));
            faqs.add(new FaqEntity("9、How to import local music?", "Click :Music - Local - Local Music - Import songs"));
            faqs.add(new FaqEntity("10、Contact us:\n(1)Follow us on our official WeChat account:\"乐享动\",and please provide as detailed information as possible when reporting a problem;\n(2)QQ group: 515536404;\n(3)Telephone：0755-26413937.", null));
        }
        adapter.notifyDataSetChanged();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

}
