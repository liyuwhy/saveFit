package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.model.api.bean.ClubShareInfo;
import com.fitmix.sdk.model.api.bean.ModifyClub;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

public class EditClubActivity extends BaseActivity {
    //    private final int USER_LOGIN = 456;
//    private final int REQUEST_TYPE_REMOVE = 1;
//    private final int REQUEST_TYPE_SHARE = 2;
//    private final int REQUEST_TYPE_QUIT = 3;
//    private static final int PICK_CLUB_ID = 123;
    private int avatarId;
    private Uri mCropImageUri;
    private SimpleDraweeView img_club_cover;
    private EditText txt_club_name;
    private EditText txt_club_description;//描述
    private EditText txt_club_invitation_address;//俱乐部分享地址
//    private Button btn_share_invitation_address;//俱乐部分享按钮

    private Button btn_quit_club;
    private View layout_club_manager;
    private TextView tv_desc_number_limit;

    private String sName;
    private String sDescription;
    private boolean isMember = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_club);
        setPageName("EditClubActivity");
        isMember = getIntent().getBooleanExtra("isMember", true);
        initToolbar();
        initViews();
        getShareClubUrl();
        FitmixUtil.deleteTempPhotoFile();
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        img_club_cover = (SimpleDraweeView) findViewById(R.id.img_club_cover);
        txt_club_name = (EditText) findViewById(R.id.txt_club_name);
        txt_club_description = (EditText) findViewById(R.id.txt_club_description);

        tv_desc_number_limit = (TextView) findViewById(R.id.tv_desc_number_limit);
        tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_club_club_description_tips), 250));
        txt_club_description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int number = txt_club_description.getText().length();
                tv_desc_number_limit.setText(String.format(getString(R.string.activity_edit_club_club_description_tips), 250 - number));
            }
        });
        txt_club_invitation_address = (EditText) findViewById(R.id.txt_club_invitation_address);
//        btn_share_invitation_address = (Button) findViewById(R.id.btn_share_invitation_address);
        btn_quit_club = (Button) findViewById(R.id.btn_quit_club);
        layout_club_manager = findViewById(R.id.layout_club_manager);

        if (isClubCreator()) {//如果当前用户是管理员
            txt_club_name.setEnabled(true);
            txt_club_description.setEnabled(true);
            btn_quit_club.setVisibility(View.GONE);
            layout_club_manager.setVisibility(View.VISIBLE);
        } else {
            txt_club_name.setEnabled(false);
            txt_club_description.setEnabled(false);
            btn_quit_club.setVisibility(View.VISIBLE);
            layout_club_manager.setVisibility(View.GONE);
        }

        //if (!isMember) {//如果不是开放俱乐部的成员
        //   btn_quit_club.setVisibility(View.GONE);
        //}

        /** v2.0.3 bug Caused by: java.lang.NullPointerException
         *  at com.fitmix.sdk.EditClubActivity.initViews(EditClubActivity.java:204)*/
        if (getClub() != null) {
            txt_club_name.setText(getClub().getName() != null ? getClub().getName() : "");
            txt_club_description.setText(getClub().getDesc() != null ? getClub().getDesc() : "");
            if (TextUtils.isEmpty(getClub().getBackImageUrl())) {//默认专辑图片
                img_club_cover.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_club_badge)).build());
            } else {
                img_club_cover.setImageURI(Uri.parse(getClub().getBackImageUrl()));
            }
        }
    }

    private Club getClub() {
        return getMyConfig().getMemExchange().getCurrentClub();
    }

    /**
     * 检查输入错误
     *
     * @return Config.ERROR_NO_ERROR   正确
     * 其它                             错误号
     */
    private int checkInputError() {
        sName = txt_club_name.getText().toString();
        sDescription = txt_club_description.getText().toString();

        if (sName.length() < Config.USERNAME_LENGTH_MIN)
            return Config.ERROR_USERNAME_TOO_SHORT;
        return Config.ERROR_NO_ERROR;
    }

    /**
     * 处理提交创建任务
     */
    private void processModifyClub() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            //showErrorMsg(error, null);
            return;
        }
        modifyClub();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
//        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
//                + "\n result:" + dataReqResult.getResult());
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_CLUB + 12://退出俱乐部
                afterQuitClub(true);
                break;
            case Config.MODULE_CLUB + 13://分享俱乐部
                setClubShareUrl(dataReqResult.getResult());
                break;

            case Config.MODULE_CLUB + 15://更改俱乐部
                afterModifyClub(dataReqResult.getResult());
                break;
            case Config.MODULE_CLUB + 16://删除俱乐部
                afterRemoveClub(true);
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.i(Logger.DEBUG_TAG, "发生了错误啊,requestId:" + requestId + " error:" + error);
    }

    /**
     * 发送创建俱乐部请求
     */
    private void modifyClub() {
        if (getClub() == null)
            return;
        int requestId = ClubDataManager.getInstance().modifyClub(getClub().getId(), sName, sDescription, FitmixUtil.getTempPhotoFile(), "image", true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void afterModifyClub(String sResult) {
        ModifyClub modifyClub = JsonHelper.getObject(sResult, ModifyClub.class);

        if (modifyClub != null) {
            Club club = modifyClub.getClub();
            getMyConfig().getMemExchange().setCurrentClub(club);
            getMyConfig().getMemExchange().setNeedRefreshClubList(true);
            finish();
        }
    }

    /**
     * 发送删除俱乐部请求
     */
    private void removeClub() {
        if (getClub() == null)
            return;
        int requestId = ClubDataManager.getInstance().deleteClub(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 发送创建俱乐部请求
     */
    public void afterRemoveClub(boolean isSuccess) {
        if (isSuccess) {
            getMyConfig().getMemExchange().setCurrentClub(null);
            getMyConfig().getMemExchange().setNeedRefreshClubList(true);
            finish();
        }
    }

    /**
     * 发送创建俱乐部请求
     */
    public void afterQuitClub(boolean isSuccess) {
        if (isSuccess) {
            getMyConfig().getMemExchange().setCurrentClub(null);
            getMyConfig().getMemExchange().setNeedRefreshClubList(true);
            finish();
        }
    }

    /**
     * 获得俱乐部的分享地址
     */
    public void getShareClubUrl() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getShareClubUrl(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    private void setClubShareUrl(String sResult) {
        ClubShareInfo clubShareInfo = JsonHelper.getObject(sResult, ClubShareInfo.class);

        if (clubShareInfo != null) {
            String url = clubShareInfo.getShareUrl();
            if (url != null)
                txt_club_invitation_address.setText(url);
        }
    }

    /**
     * 分享俱乐部
     *
     * @param url 俱乐部地址
     */
    private void shareClub(String url) {
        if (TextUtils.isEmpty(url) || getClub() == null) return;
        ShareUtils.getInstance().shareClub(this, getClub().getBackImageUrl(), url);
    }

    /**
     * 发送退出俱乐部请求
     */
    private void quitClub() {
        if (!isMember) {//如果不是开放俱乐部的成员
            SettingsHelper.putBoolean(Config.SETTING_SHOW_OPEN_CLUB, false);
            getMyConfig().getMemExchange().setCurrentClub(null);
            getMyConfig().getMemExchange().setNeedRefreshClubList(true);
            finish();
        } else {
            if (getClub() == null)
                return;
            int requestId = ClubDataManager.getInstance().quitClub(getClub().getId(), true);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * @return 是否俱乐部创建者
     */
    public boolean isClubCreator() {
        return getClub() != null && getClub().getUid() == UserDataManager.getUid();
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.img_club_cover://修改俱乐部背景墙图片
                if (!isClubCreator()) break;
                onPickImage(v);
                break;
            case R.id.btn_share_invitation_address://分享俱乐部
                if (!isMember) {
                    new MaterialDialog.Builder(this)
                            .title(R.string.prompt)
                            .content(R.string.visitors_permissions)
                            .positiveText(R.string.ok)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            break;
                                    }
                                }
                            }).show();
                } else {
                    shareClub(txt_club_invitation_address.getText().toString());
                }
                break;

            case R.id.btn_quit_club://退出俱乐部
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.quit_Club)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        quitClub();
                                        break;
                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
                break;
            case R.id.btn_delete_club://删除俱乐部
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.remove_Club)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        removeClub();
                                        break;
                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
                break;
            case R.id.btn_save://保存修改
                processModifyClub();
                break;
        }
    }

    /**
     * 从相册或相机获取图片
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
        avatarId = view.getId();//保存ID,之后图片设置用

    }

    /**
     * 剪裁图片
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(43, 58)//172 232
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;
            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    View v = findViewById(avatarId);
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (v != null && bitmap != null) {
                        ImageHelper.adjustPhotoToFitSize(bitmap, Config.USER_CLUB_WIDTH, Config.USER_CLUB_HEIGHT, FitmixUtil.getTempPhotoFile());
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            break;
                    }
                }
                break;
        }
    }
}
