package com.fitmix.sdk.view.activity;


import android.Manifest;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.ParcelUuid;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.common.bluetooth.ble.HRSManager;
import com.fitmix.sdk.common.bluetooth.scanner.BluetoothLeScannerCompat;
import com.fitmix.sdk.common.bluetooth.scanner.ExtendedBluetoothDevice;
import com.fitmix.sdk.common.bluetooth.scanner.ScanCallback;
import com.fitmix.sdk.common.bluetooth.scanner.ScanFilter;
import com.fitmix.sdk.common.bluetooth.scanner.ScanResult;
import com.fitmix.sdk.common.bluetooth.scanner.ScanSettings;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.database.SportRecord;
import com.fitmix.sdk.model.database.SportRecordsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.view.adapter.DeviceListAdapter;
import com.fitmix.sdk.view.adapter.RunSettingViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomPageTransformer;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.RunSettingBaseFragment;
import com.fitmix.sdk.view.fragment.RunSettingCalorieFragment;
import com.fitmix.sdk.view.fragment.RunSettingDistanceFragment;
import com.fitmix.sdk.view.fragment.RunSettingDurationFragment;
import com.fitmix.sdk.view.fragment.RunSettingFreeFragment;
import com.fitmix.sdk.view.fragment.RunSettingPaceFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.ViewUtils;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

public class RunSettingActivity extends BaseActivity implements CompoundButton.OnCheckedChangeListener, ViewPager.OnPageChangeListener {
    /**
     * 编辑个人信息请求
     */
    private final int EDIT_PROFILE = 1;
    /**
     * 导航到MiUi神隐设置
     */
    private final int GOTO_MI_GOD = 2;
//    /**
//     * 导航到android M以上电量优化设置
//     */
//    private final int GOTO_BATTERY_OPTIMIZE = 3;
    /**
     * 切换viewPager 动画
     */
    public static final int MSG_SCROLL_PAGER = 0x789456;

    private ViewPager vp_run_setting;
    //    private int taskType;
    private RunSettingBaseFragment currentFragment;
    private List<RunSettingBaseFragment> fragmentList;

    private String musicString;
    private Button btn_start, run_setting_heart;//,run_setting_btn;
    private RadioButton indoor_rb, outdoor_rb;

    private RunLogInfo lastRunLog;//最后一次跑步记录
    private RadioGroup run_setting_rg;
    private boolean isSelectHrView = false;
    private LinearLayout run_setting_view;
    private LinearLayout select_device_view;

    static class MyHandler extends Handler {
        private WeakReference<RunSettingActivity> mActivity;

        public MyHandler(RunSettingActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_SCROLL_PAGER://程序切换ViewPager动画
                    if (mActivity != null) {
                        RunSettingActivity activity = mActivity.get();
                        if (activity != null) {
                            activity.index -= 1;
                            if (activity.vp_run_setting != null && activity.index >= 0) {
                                activity.vp_run_setting.setCurrentItem(activity.index, true);
                                if (activity.index == 0) {
                                    activity.vp_run_setting.setPageTransformer(true, new ZoomPageTransformer());//设置切换效果
                                }
                            }
                            if (activity.mHandler != null && activity.index > 0) {
                                activity.mHandler.sendEmptyMessageDelayed(MSG_SCROLL_PAGER, 100);
                            }
                        }
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }

    private MyHandler mHandler = new MyHandler(this);
    private int index = -1;

    //选择心率设备界面id
    private final static long SCAN_DURATION = 5000;

    //	private BluetoothAdapter mBluetoothAdapter;
    private DeviceListAdapter mAdapter;
    private Button mScanButton;
    private TextView tv_scanner_title;//搜索框的标题栏

    private View mPermissionRationale;

    private ParcelUuid mUuid = new ParcelUuid(HRSManager.HR_SERVICE_UUID);

    private boolean mIsScanning = false;

    //region ============================= Activity生命周期相关 =============================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run_setting);
        setPageName("RunSettingActivity");
        //Android 6.0申请权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            getPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.BODY_SENSORS,
                    Manifest.permission.ACCESS_FINE_LOCATION});
        }
        //5.绑定心率服务
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {//ble
            connectToHeartRateService();
        }

        Intent intent = getIntent();
        if (intent != null) {
            musicString = intent.getStringExtra("musicInfo");
        }

        initToolbar();
        initViews();
        loadRunRecords();

        //忽略省电优化
        ignoreBatteryOptimization(this);
    }

    /**
     * 从数据库加载最近1条跑步记录
     */
    private void loadRunRecords() {
        int uid = UserDataManager.getUid();
        SportRecordsHelper.asyncGetLastRunRecord(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                SportRecord sportRecord = (SportRecord) operation.getResult();
                lastRunLog = new RunLogInfo();
                if (sportRecord != null) {
                    lastRunLog.setUid(sportRecord.getUid());//用户ID
                    lastRunLog.setStartTime(sportRecord.getStartTime());//开始时间,单位毫秒
                    lastRunLog.setEndTime(sportRecord.getEndTime());//结束时间,单位毫秒
                    lastRunLog.setType(sportRecord.getType());//运动类型 0或1表示跑步
                    lastRunLog.setMode(sportRecord.getMode());//运动环境(1:室外,2:室内)
                    lastRunLog.setUploaded(sportRecord.getUploaded());//是否已同步到服务器,1:已同步,0:未同步
                    lastRunLog.setDistance(sportRecord.getDistance() == null ? 0 : sportRecord.getDistance());//运动距离,单位米
                    lastRunLog.setRunTime(sportRecord.getRunTime() == null ? 0 : sportRecord.getRunTime());//运动时长,单位毫秒
                    lastRunLog.setStep(sportRecord.getStep() == null ? 0 : sportRecord.getStep());//步数
                    lastRunLog.setBpm(sportRecord.getBpm() == null ? 0 : sportRecord.getBpm());//平均步频(每分钟步数)
                    lastRunLog.setCalorie(sportRecord.getCalorie() == null ? 0 : sportRecord.getCalorie());//卡路里
                }
                Logger.i(Logger.DEBUG_TAG, "RunSettingActivity-->loadRunRecords lastRunLog:" + lastRunLog);
                setDataToFragments();//刷新数据
            }
        });
    }

    /**
     * 设置fragment数据源
     */
    public void setDataToFragments() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (fragmentList != null) {
                    for (int i = 0; i < fragmentList.size(); i++) {
                        if (fragmentList.get(i) != null) {
                            fragmentList.get(i).setLastRunInfo(lastRunLog);
                        }
                    }
                }

            }
        });
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        run_setting_view = (LinearLayout) findViewById(R.id.run_setting_view);
        select_device_view = (LinearLayout) findViewById(R.id.select_hr_service_view);
        //初始化4个跑步类型fragment
        fragmentList = new ArrayList<>(4);
        //自由跑
        RunSettingFreeFragment runSettingFreeFragment = new RunSettingFreeFragment();
        fragmentList.add(runSettingFreeFragment);
        //配速跑
        RunSettingPaceFragment runSettingPaceFragment = new RunSettingPaceFragment();
        fragmentList.add(runSettingPaceFragment);
        //距离跑
        RunSettingDistanceFragment runSettingDistanceFragment = new RunSettingDistanceFragment();
        fragmentList.add(runSettingDistanceFragment);
        //时间跑
        RunSettingDurationFragment runSettingDurationFragment = new RunSettingDurationFragment();
        fragmentList.add(runSettingDurationFragment);
        //卡路里
        RunSettingCalorieFragment runSettingCalorieFragment = new RunSettingCalorieFragment();
        fragmentList.add(runSettingCalorieFragment);

        vp_run_setting = (ViewPager) findViewById(R.id.vp_run_setting);
        RunSettingViewPagerAdapter pageAdapter = new RunSettingViewPagerAdapter(getSupportFragmentManager(), fragmentList);
        vp_run_setting.setAdapter(pageAdapter);
        vp_run_setting.setOffscreenPageLimit(3);
        vp_run_setting.setPageMargin(ViewUtils.dp2px(this, 20));
        vp_run_setting.setClipToPadding(false);
        int padding = ViewUtils.dp2px(this, 40);
        vp_run_setting.setPadding(padding, 10, padding, 10);
        vp_run_setting.setPageTransformer(true, new ZoomPageTransformer());//设置切换效果
        vp_run_setting.addOnPageChangeListener(this);

//        index = fragmentList.size() - 1;
//        if (index >= 0) {
//            vp_run_setting.setCurrentItem(index, true);
//        }

        //开始按钮
        btn_start = (Button) findViewById(R.id.btn_start);
        btn_start.setOnTouchListener(touchListener);
        outdoor_rb = (RadioButton) findViewById(R.id.outdoor_rb);
        indoor_rb = (RadioButton) findViewById(R.id.indoor_rb);
//        run_setting_btn = (Button)findViewById(run_setting_btn);
        run_setting_heart = (Button) findViewById(R.id.run_setting_heart);


        int sportEnvironment = SettingsHelper.getInt(Config.SETTING_SPORT_ENVIRONMENT, RunLogInfo.SPORT_MODE_OUTDOOR);
        if (sportEnvironment == RunLogInfo.SPORT_MODE_OUTDOOR) {//室外模式
            outdoor_rb.setChecked(true);
            indoor_rb.setChecked(false);
        } else {
            outdoor_rb.setChecked(false);
            indoor_rb.setChecked(true);
        }

        run_setting_rg = (RadioGroup) findViewById(R.id.run_setting_rg);
        run_setting_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.indoor_rb) {
                    indoor_rb.setChecked(true);
                    showAppMessage(R.string.activity_run_setting_indoor_tip, AppMsg.STYLE_INFO);
                } else if (checkedId == R.id.outdoor_rb) {
                    outdoor_rb.setChecked(true);
                    showAppMessage(R.string.activity_run_setting_outdoor_tip, AppMsg.STYLE_INFO);
                }
            }
        });


        //选择心率设备界面
        final ListView listview = (ListView) findViewById(android.R.id.list);

        listview.setEmptyView(findViewById(android.R.id.empty));
        listview.setAdapter(mAdapter = new DeviceListAdapter(this));

        tv_scanner_title = (TextView) findViewById(R.id.tv_scanner_title);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final AdapterView<?> parent, final View view, final int position, final long id) {

                final ExtendedBluetoothDevice d = (ExtendedBluetoothDevice) mAdapter.getItem(position);

                if (heartRateService != null) {
                    heartRateService.setDevice(d.device);
                    if (heartRateService.getBleManager() != null) {
                        heartRateService.getBleManager().disconnect();
//                        heartRateService.getBleManager().setAutoConnect(true);//自动连接,连接比较慢,数据连接较稳定
                        heartRateService.getBleManager().connect(d.device);
                        showAppMessage(R.string.activity_watch_connecting, AppMsg.STYLE_INFO);
                    }
                }
            }
        });

        mPermissionRationale = findViewById(R.id.permission_rationale); // this is not null only on API23+

        mScanButton = (Button) findViewById(R.id.action_cancel);
        mScanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.action_cancel) {
                    if (mIsScanning) {

                    } else {
                        if (isBLEEnabled()) {
                            startScan();
                        } else {
                            requestBlueTooth();
                        }
                    }
                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        wheel_run_type = null;
        disconnectToHeartRateService();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mHandler = null;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {

        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        //当页面在滑动的时候会调用此方法,在滑动被停止之前,此方法会一直得到调用。
        //index:当前页面及你点击滑动页面,percent：当前页面偏移的百分比,offset：当前页面偏移的像素位置
    }

    @Override
    public void onPageSelected(int position) {
//        Logger.i(Logger.DEBUG_TAG, "onPageSelected-->position:" + position + ",screenWidth:"+ViewUtils.getScreenWidth(this));
        if (fragmentList != null && position < fragmentList.size()) {

            currentFragment = fragmentList.get(position);

            //自由跑不设置目标值
            if (position == 0) {
                currentFragment = null;
            }

        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //此方法在状态改变时调用
        //state==1正在滑动,state==2滑动完成,state==0什么都没做
    }

    //endregion ============================= Activity生命周期相关 =============================


//region ============================= 导航到其它界面 =============================

    /**
     * 开始跑步
     */
    private void gotoRunMain() {
        if (indoor_rb != null) {
            if (indoor_rb.isChecked()) {
                SettingsHelper.putInt(Config.SETTING_SPORT_ENVIRONMENT, RunLogInfo.SPORT_MODE_INDOOR);
            } else {
                SettingsHelper.putInt(Config.SETTING_SPORT_ENVIRONMENT, RunLogInfo.SPORT_MODE_OUTDOOR);
            }
        }

        Intent intent = new Intent(RunSettingActivity.this, RunMainActivity.class);
        if (PlayerController.getInstance().isMusicPlaying()) {//正在播放音乐
            Music currentMusic = PlayerController.getInstance().getCurrentMusic();
            if (currentMusic != null) {
                intent.putExtra("musicInfo", JsonHelper.createJsonString(currentMusic));
            }
        } else {
            //音乐播放开关
            boolean sportWithMusic = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_MUSIC, false);
            //这个是用户手动设置的歌曲 优先级比较高
            String expert_music = SettingsHelper.getString(Config.SETTING_EXPERT_MUSIC, "");
            if (sportWithMusic) {
                if ((!TextUtils.isEmpty(expert_music))) {
                    intent.putExtra("musicInfo", expert_music);
                } else {
                    if (TextUtils.isEmpty(musicString)) {
                        intent.putExtra("musicInfo", musicString);
                    }
                }
            }
        }

        int taskType = 0;
        if (currentFragment != null) {
            intent.putExtra("taskObject", currentFragment.getSelectValue());
            taskType = currentFragment.getTaskType();
            intent.putExtra("taskType", taskType);
            Logger.i(Logger.DEBUG_TAG, "taskObject:" + currentFragment.getSelectValue() + ",taskType:" + taskType + "\nmusicInfo:" + musicString);
        }
        //友盟统计开始运动
        String runType = "自由跑";
        String target = currentFragment != null ? String.valueOf(currentFragment.getSelectValue()) : "";
        switch (taskType) {
            case RunSettingBaseFragment.TASK_TYPE_FREE:
            default:
                target = "自由跑";
                break;
            case RunSettingBaseFragment.TASK_TYPE_DISTANCE:
                runType = "距离跑";
                break;
            case RunSettingBaseFragment.TASK_TYPE_TIME:
                runType = "时间跑";
                break;
            case RunSettingBaseFragment.TASK_TYPE_CALORIE:
                runType = "能量跑";
                break;
            case RunSettingBaseFragment.TASK_TYPE_PACE:
                runType = "配速跑";
                break;
        }
        //音乐播放开关
        boolean sportWithMusic = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_MUSIC, false);
        //语音播报开关
        boolean sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
        UmengAnalysisHelper.getInstance().startRunReportPlus(this, indoor_rb.isChecked(), sportWithMusic, sportWithVoice, runType, target);

        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
    }

    /**
     * 跳转用户信息设置界面
     */
    private void gotoEditProfile() {
        Intent intent = new Intent(RunSettingActivity.this, EditProfileActivity.class);
        startActivityForResult(intent, EDIT_PROFILE);
        overridePendingTransition(0, 0);
    }

    /**
     * 跳转到MiUI的后台运行权限管理页面
     *
     * @return true:表明可以导航到MiUI的后台运行权限管理页面,false:不能
     */
    private boolean gotoMiUiGod() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.miui.powerkeeper",
                "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"));
        intent.putExtra("package_name", "com.fitmix.sdk");
        intent.putExtra("package_label", "乐享动(FITMIX)");

        List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (list.size() > 0) {
            startActivityForResult(intent, GOTO_MI_GOD);
            overridePendingTransition(0, 0);
            return true;
        }
        return false;
    }

    /**
     * 开始运动
     */
    private void startRun() {
        int height = SettingsHelper.getInt(Config.SETTING_USER_HEIGHT, 0);
        int weight = SettingsHelper.getInt(Config.SETTING_USER_WEIGHT, 0);
        //1.没有身高、体重信息跳转设置
        if (height == 0 || weight == 0) {
            new MaterialDialog.Builder(this)
                    .title(R.string.warning)
                    .content(R.string.edit_profile_tip)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    gotoEditProfile();
                                    break;
                                case NEGATIVE:
                                    gotoRunMain();
                                    break;
                            }
                        }
                    }).show();
            return;
        }
        //2.室外模式,提示小米用户开启后台定位权限
        if (outdoor_rb != null && outdoor_rb.isChecked()) {
//            //1.位置采集周期
//            if (ignoreBatteryOptimization()) {
//                return;
//            } else {
            //2.提示小米用户开启后台定位权限
            boolean backgroundRun = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_BACKGROUND_RUN_PERMISSION, true);
            if ("xiaomi".equalsIgnoreCase(ApiUtils.getManufacturer()) && backgroundRun) {//小米
                View customView = getLayoutInflater().inflate(R.layout.dialog_background_run, null);
                CheckBox ckb_not_tips = (CheckBox) customView.findViewById(R.id.ckb_not_tips);
                ckb_not_tips.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        PrefsHelper.with(RunSettingActivity.this, Config.PREFS_SPORT)
                                .writeBoolean(Config.SP_KEY_BACKGROUND_RUN_PERMISSION, !isChecked);
                    }
                });

                new MaterialDialog.Builder(this)
                        .title(R.string.warning)
                        .customView(customView, false)
                        .positiveText(R.string.ok)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        if (!gotoMiUiGod()) {
                                            gotoRunMain();
                                        }
                                        break;
                                }
                            }
                        }).show();
                return;
            }
//            }
        }
        gotoRunMain();
    }

//    /**
//     * 在Android 6.0及以上系统，若定制手机使用到doze模式，请求将应用添加到白名单。
//     *
//     * @return true:设置成功,需要等待回复,false:设置失败,继续下一步操作
//     */
//    private boolean ignoreBatteryOptimization() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            String packageName = getPackageName();
//            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
//            boolean isIgnoring = powerManager.isIgnoringBatteryOptimizations(packageName);
//            if (!isIgnoring) {
//                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
//                intent.setData(Uri.parse("package:" + packageName));
//                try {
//                    startActivityForResult(intent, GOTO_BATTERY_OPTIMIZE);
//                    return true;
//                } catch (Exception ex) {
//                    ex.printStackTrace();
//                }
//            }
//        }
//
//        return false;
//    }

    //endregion ============================= 导航到其它界面 =============================

    //region ============================= 心率蓝牙相关 =============================
    private void requestEnableGpsBluetooth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (FitmixUtil.isBLEEnabled(this)) {
                    if (FitmixUtil.isGpsEnable(this)) {//开了GPS
                        startScan();
                    } else {
                        FitmixUtil.enableBleGPS(this);//去开启GPS
                    }
                } else {
                    FitmixUtil.requestBlueTooth(this);
                }
            } else {
                if (FitmixUtil.isBLEEnabled(this)) {
                    startScan();
                } else {
                    FitmixUtil.requestBlueTooth((this));
                }
            }
        } else {
            Toast.makeText(this, getResources().getString(R.string.heart_rate_warn_sdk_version), Toast.LENGTH_SHORT).show();
        }
    }

    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {
        @Override
        public void onDeviceConnected() {
            //连接成功：
            runOnUiThread(new Runnable() {
                @Override
                public void run() {//数据通道连接成功
                    if (heartRateService.getDevice() != null &&
                            !TextUtils.isEmpty(heartRateService.getDevice().getName())
                            && !TextUtils.isEmpty(heartRateService.getDevice().getAddress())) {
                        Logger.d("TT", "首次数据连接的设备：" + heartRateService.getDevice().getName()
                                + " 地址：" + heartRateService.getDevice().getAddress());

                        showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                    }
                }
            });

            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    setUiTitle(getResources().getString(R.string.title_activity_run_setting));
                    run_setting_view.setVisibility(View.VISIBLE);
                    select_device_view.setVisibility(View.GONE);
                }
            }, 3000L);

            startHeartRateService();
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.e(Logger.LOG_TAG, "心率设备断开");
            stopHeartRateService();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    run_setting_heart.setText(getResources().getString(R.string.activity_pair_heart_rate_hr_type));
                }
            });
        }

        @Override
        public void onError() {

        }

        @Override
        public void onHRValueReceived() {

            Logger.d(Logger.DEBUG_TAG, "hr value:" + getLatestHeartRate());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    run_setting_heart.setText(String.valueOf(getLatestHeartRate()));
                }
            });

        }

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {
            SettingsHelper.putString(Config.SETTING_HR_FIRMWARE_VERSION_CODE, firmwareVersion);
        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, int signalValue) {

        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {

        }

        @Override
        public void reDrawHeartRateData() {

        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime, int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode, boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {

        }
    };
    private HeartRateService heartRateService;
    private ServiceConnection heartRateServiceConnection;

    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);
        heartRateServiceConnection = new ServiceConnection() {

            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService == null)
                    return;

                heartRateService.setIfBindWithRunMain(true);
                heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };

        bindService(intent, heartRateServiceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (heartRateService != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                heartRateService.removeHeartRateItem(mPageName);
            }
        }
        if (heartRateServiceConnection != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(heartRateServiceConnection);
            }
        }
        heartRateServiceConnection = null;
    }

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Intent i = new Intent(this, HeartRateService.class);
        Logger.i(Logger.DEBUG_TAG, "RunSettingActivity --->  startHeartRateService()");
        startService(i);
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "RunSettingActivity --->stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    /**
     * UI界面上更新心率数值
     *
     * @return
     */
    public int getLatestHeartRate() {
        if (heartRateService != null && heartRateService.getDevice() != null) {
            return heartRateService.getLatestHeartRate();
        } else { // 设备断开情况
            return 0;
        }
    }

    /**
     * Scan for 5 seconds and then stop scanning when a BluetoothLE device is found then mLEScanCallback is activated This will perform regular scan for custom BLE Service UUID and then filter out.
     * using class ScannerServiceParser
     */
    private void startScan() {
        boolean permission = permissionIsGranted(Manifest.permission.ACCESS_COARSE_LOCATION);
        if (!permission) {
            getPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
        }


        // Hide the rationale message, we don't need it anymore.
        if (mPermissionRationale != null)
            mPermissionRationale.setVisibility(View.GONE);

        mAdapter.clearDevices();
        mScanButton.setText(R.string.scanner_action_cancel);
        tv_scanner_title.setText(getResources().getString(R.string.scanner_equipments_searching));

        final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        final ScanSettings settings = new ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(1000).setUseHardwareBatchingIfSupported(false).build();
        final List<ScanFilter> filters = new ArrayList<>();
        filters.add(new ScanFilter.Builder().setServiceUuid(mUuid).build());
        try {
            scanner.startScan(filters, settings, scanCallback);
        } catch (Exception e) {
            showAppMessage(R.string.scanner_empty, AppMsg.STYLE_ALERT);
        }

        mIsScanning = true;
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mIsScanning) {
                    stopScan();
                }
            }
        }, SCAN_DURATION);
    }

    /**
     * Stop scan if user tap Cancel button
     */
    private void stopScan() {
        if (mIsScanning) {
            mScanButton.setText(R.string.scanner_action_scan);
            tv_scanner_title.setText(getResources().getString(R.string.scanner_select_heart_rate_equipment));

            final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
            scanner.stopScan(scanCallback);

            mIsScanning = false;
        }
    }

    private ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(final int callbackType, final ScanResult result) {
            // do nothing
        }

        @Override
        public void onBatchScanResults(final List<ScanResult> results) {
            mAdapter.update(results);
        }

        @Override
        public void onScanFailed(final int errorCode) {
            // should never be called
        }
    };

    /**
     * 是否允许蓝牙4.0权限
     *
     * @return
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private boolean isBLEEnabled() {
        final BluetoothManager bluetoothManager = (BluetoothManager) this.getSystemService(Context.BLUETOOTH_SERVICE);
        final BluetoothAdapter adapter = bluetoothManager.getAdapter();
        return adapter != null && adapter.isEnabled();
    }

    /**
     * 请求蓝牙权限，去启动蓝牙
     */
    private void requestBlueTooth() {
        final Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivity(enableIntent);
    }

    //endregion ============================= 心率蓝牙相关 =============================

    private final View.OnTouchListener touchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Button button = (Button) v;
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                button.setAlpha(0.7f);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                button.setAlpha(1.0f);
            } else if (event.getAction() == MotionEvent.ACTION_CANCEL) {
                button.setAlpha(1.0f);
            }

            return false;
        }
    };


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_start:
                startRun();
                break;
            case R.id.run_setting_btn:
                Intent intent = new Intent(this, SiriSettingActivity.class);
                startActivity(intent);
                break;
            case R.id.run_setting_heart:
                isSelectHrView = true;
                run_setting_view.setVisibility(View.GONE);
                select_device_view.setVisibility(View.VISIBLE);
                setUiTitle(getResources().getString(R.string.select_hr_device));
                requestEnableGpsBluetooth();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //定义退出动画
        finish();
        overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case EDIT_PROFILE:
            case GOTO_MI_GOD:
                gotoRunMain();
                break;

//            case GOTO_BATTERY_OPTIMIZE:
//                //2.提示小米用户开启后台定位权限
//                boolean backgroundRun = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_BACKGROUND_RUN_PERMISSION, true);
//                if ("xiaomi".equalsIgnoreCase(ApiUtils.getManufacturer()) && backgroundRun) {//小米
//                    View customView = getLayoutInflater().inflate(R.layout.dialog_background_run, null);
//                    CheckBox ckb_not_tips = (CheckBox) customView.findViewById(R.id.ckb_not_tips);
//                    ckb_not_tips.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                        @Override
//                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                            PrefsHelper.with(RunSettingActivity.this, Config.PREFS_SPORT)
//                                    .writeBoolean(Config.SP_KEY_BACKGROUND_RUN_PERMISSION, !isChecked);
//                        }
//                    });
//
//                    new MaterialDialog.Builder(this)
//                            .title(R.string.warning)
//                            .customView(customView, false)
//                            .positiveText(R.string.ok)
//                            .onAny(new MaterialDialog.SingleButtonCallback() {
//                                @Override
//                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
//                                    dialog.dismiss();
//                                    switch (which) {
//                                        case POSITIVE:
//                                            if (!gotoMiUiGod()) {
//                                                gotoRunMain();
//                                            }
//                                            break;
//                                    }
//                                }
//                            }).show();
//                    return;
//                } else {
//                    gotoRunMain();
//                }
//                break;

            case Config.BLE_REQUEST_ENABLE_GPS://BLE功能请求GPS权限
                if (RESULT_OK == resultCode) {//成功授权
                    startScan();
                    return;
                }
                //GPS开启失败
                Toast.makeText(this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://返回
                if (isSelectHrView) {
                    run_setting_view.setVisibility(View.VISIBLE);
                    select_device_view.setVisibility(View.GONE);
                    isSelectHrView = false;
                    setUiTitle(getResources().getString(R.string.title_activity_run_setting));
                    return true;
                } else {
                    finish();
                }
                break;
        }

        return false;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                if (isSelectHrView) {
                    run_setting_view.setVisibility(View.VISIBLE);
                    select_device_view.setVisibility(View.GONE);
                    isSelectHrView = false;
                    setUiTitle(getResources().getString(R.string.title_activity_run_setting));
                } else {
                    finish();
                }
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
