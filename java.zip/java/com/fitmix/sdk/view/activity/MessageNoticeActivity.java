package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.NoticeFragmentListBean;
import com.fitmix.sdk.model.api.bean.UserPrivateMessageList;
import com.fitmix.sdk.model.database.ChatMessageInfoListHelper;
import com.fitmix.sdk.model.database.ChatMessageResultBean;
import com.fitmix.sdk.model.database.ChatMessageResultBeanHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MessageInfo;
import com.fitmix.sdk.model.database.MessageInfoHelper;
import com.fitmix.sdk.model.database.NoticeInfo;
import com.fitmix.sdk.model.database.NoticeInfoHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.MessageFragment;
import com.fitmix.sdk.view.fragment.NoticeFragment;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MessageNoticeActivity extends BaseActivity implements AdapterView.OnItemSelectedListener,
        MessageFragment.MessageFragmentCallback, NoticeFragment.NoticeFragmentCallback {

    /**
     * 当前选择的RadioGroup中radio button下标
     */
    private int currentNavIndex = -1;
    private final int FRAGMENT_PAGE_MESSAGE = 0;
    private final int FRAGMENT_PAGE_NOTICE = 1;
    private RadioGroup message_rg;
    private RadioButton message_rb, notice_rb;
    private FrameLayout message_container;
    private int messagePage = 1; //分页加载 消息
    private int noticePage = 1; //分页加载 通知
    private UserPrivateMessageList.PageBean messageListPage;
    // private List<UserPrivateMessageList.PageBean.ResultBean> messageListData = new ArrayList<>();
    List<NoticeFragmentListBean.NoticesBean> noticesListData = new ArrayList<>();
    private final int MESSAGE_DELETE = 2;// 消息删除
    private final int MESSAGE_SHIELD = 3;//消息屏蔽
    private final int MESSAGE_CANCEL_SHIELD = 4;//消息取消屏蔽
    private final int NOTICE_DELETE = 5;// 通知删除
    private int messageDeletePosition, noticeDeletePosition;
    private int messageShieldPosition;
    private int messageShieldReject;
    private int messageListTotalPages;//消息列表页数
    private List<NoticeInfo> noticeInfoListData = new ArrayList<>();//数据库存


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_notice);
        setPageName("MessageNoticeActivity");
        initToolbar();
        initViews();
    }

    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        message_rg = (RadioGroup) findViewById(R.id.message_rg);
        message_rb = (RadioButton) findViewById(R.id.message_rb);
        notice_rb = (RadioButton) findViewById(R.id.notice_rb);
        message_container = (FrameLayout) findViewById(R.id.message_container);

        message_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (ftCanCommit) {
                    getSupportFragmentManager().popBackStackImmediate();
                }

                switch (checkedId) {
                    case R.id.message_rb:
                        switchToFragment(FRAGMENT_PAGE_MESSAGE);
                        break;
                    case R.id.notice_rb:
                        switchToFragment(FRAGMENT_PAGE_NOTICE);
                        break;
                }
            }
        });

        setUiTitle("");
    }

    private List<NoticeFragmentListBean.NoticesBean> getNoticeAdapterDataList() {

        if (noticesListData.size() > 0)
            noticesListData.clear();

        noticeInfoListData = NoticeInfoHelper.getInstance().getNoticeInfoList();
        for (int i = 0; i < noticeInfoListData.size(); i++) {
            NoticeInfo noticeInfo = noticeInfoListData.get(i);
            NoticeFragmentListBean.NoticesBean noticesBean = new NoticeFragmentListBean.NoticesBean();
            Long addTime = noticeInfo.getAddTime();
            Integer selectChannel = noticeInfo.getSelectChannel();
            String msgBody = noticeInfo.getMsgBody();
            String fromUser = noticeInfo.getFromUser();
            Long noticeId = noticeInfo.getNoticeId();
            Integer status = noticeInfo.getStatus();
            noticesBean.setAddTime(addTime);
            noticesBean.setFromUser(JsonHelper.getObject(fromUser, NoticeFragmentListBean.NoticesBean.FromUserBean.class));
            noticesBean.setMsgBody(JsonHelper.getObject(msgBody, NoticeFragmentListBean.NoticesBean.MsgBodyBean.class));
            noticesBean.setSelectChannel(String.valueOf(selectChannel));
            noticesBean.setStatus(status);
            noticesBean.setId(Integer.parseInt(String.valueOf(noticeId)));
            Logger.d(Logger.DEBUG_TAG, "status:" + status);
            noticesListData.add(noticesBean);

        }
        return noticesListData;
    }

    // 获取用户通知列表 不考虑缓存
    private void getUserNoticeListData() {
        int requestId = UserDataManager.getInstance().getUserNoticeList(true);
        registerDataReqStatusListener(requestId);
    }

    // 获取私信列表 不考虑缓存
    private void getMessageListData() {
        int requestId = UserDataManager.getInstance().getUserPrivateMsgList(messagePage, true);
        registerDataReqStatusListener(requestId);
    }

    private void switchToFragment(int pageIndex) {
        Fragment fragment;
        String fragmentTag;
        if (currentNavIndex == pageIndex) {//防止同一个标签多次切换
            return;
        }
        switch (pageIndex) {
            case FRAGMENT_PAGE_MESSAGE:
                fragmentTag = MessageFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(MessageFragment.TAG);
                if (fragment == null) {
                    fragment = new MessageFragment().setFragmentCallback(this);
                } else {
                    return;
                }
                //   getMessageAdapterDataList();
                getMessageListData();
                break;
            case FRAGMENT_PAGE_NOTICE:
                fragmentTag = NoticeFragment.TAG;
                fragment = getSupportFragmentManager().findFragmentByTag(NoticeFragment.TAG);
                if (fragment == null) {
                    fragment = new NoticeFragment().setFragmentCallback(this);
                } else {
                    return;
                }
                getUserNoticeListData();
                break;
            default:
                return;
        }

        /**
         *  java.lang.IllegalStateException: Can not perform this action after onSaveInstanceState
         *  at android.support.v4.app.FragmentManagerImpl.checkStateLoss(FragmentManager.java:1489)
         *  at android.support.v4.app.FragmentManagerImpl.popBackStackImmediate(FragmentManager.java:584)
         *  at android.support.v4.app.FragmentActivity.onBackPressed(FragmentActivity.java:169)
         */
        if (ftCanCommit) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.message_container, fragment, fragmentTag)
                    .commitAllowingStateLoss();
        }

        RadioButton radioButton = (RadioButton) message_rg.getChildAt(pageIndex);
        radioButton.setChecked(true);
        this.currentNavIndex = pageIndex;
    }

    /**
     * 显示提示对话框
     */
    private void showConfirmTip(final int position, int stringId, final int type) {
        final MessageFragment messageFragment = (MessageFragment) getSupportFragmentManager().findFragmentByTag(MessageFragment.TAG);

        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(stringId)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE:
                                switch (type) {
                                    case MESSAGE_DELETE:////消息删除
                                        if (messageFragment != null) {
                                            int messageGroupId = messageFragment.getUserPrivateMessageList().get(position).getId();
                                            int requestId = UserDataManager.getInstance().deleteUserPrivateMsg(messageGroupId, true);
                                            registerDataReqStatusListener(requestId);
                                        }

                                        break;
                                    case MESSAGE_SHIELD://消息屏蔽

                                        if (messageFragment != null) {
                                            int messageGroupId = messageFragment.getUserPrivateMessageList().get(position).getId();
                                            int requestId = UserDataManager.getInstance().setUserPrivateMsgReject(messageGroupId, 1, true);
                                            registerDataReqStatusListener(requestId);
                                        }

                                        break;
                                    case MESSAGE_CANCEL_SHIELD://消息取消屏蔽
                                        if (messageFragment != null) {
                                            int messageGroupId = messageFragment.getUserPrivateMessageList().get(position).getId();
                                            int requestId = UserDataManager.getInstance().setUserPrivateMsgReject(messageGroupId, 0, true);
                                            registerDataReqStatusListener(requestId);
                                        }
                                        break;
                                    case NOTICE_DELETE://通知消息删除
                                        NoticeFragment noticeFragment = (NoticeFragment) getSupportFragmentManager().findFragmentByTag(NoticeFragment.TAG);
                                        if (noticeFragment != null) {
                                            NoticeInfoHelper.getInstance().deleteNoticeInfoByNoticeId(noticeFragment.getNoticeMessageList().get(position).getId());

                                            noticeFragment.getNoticeMessageList().remove(position);
                                            noticeFragment.setNoticeMessageList(noticeFragment.getNoticeMessageList());

                                        }
                                        break;
                                }

                                break;

                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (currentNavIndex == FRAGMENT_PAGE_MESSAGE || currentNavIndex == -1) {
            MessageFragment fragment = (MessageFragment) getSupportFragmentManager().findFragmentByTag(MessageFragment.TAG);
            if (fragment != null) {
                if (currentNavIndex == -1) {
                    if (message_rb != null) {
                        message_rb.setChecked(true);
                        currentNavIndex = FRAGMENT_PAGE_MESSAGE;
                    }
                }
                getMessageListData();

            } else {
                switchToFragment(FRAGMENT_PAGE_MESSAGE);
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getUserNoticeListData();
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.d(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        MessageFragment messageFragment = (MessageFragment) getSupportFragmentManager().findFragmentByTag(MessageFragment.TAG);
        NoticeFragment noticeFragment = (NoticeFragment) getSupportFragmentManager().findFragmentByTag(NoticeFragment.TAG);
        switch (requestId) {
            case Config.MODULE_USER + 69://用户私信列表
                UserPrivateMessageList messageList = JsonHelper.getObject(result, UserPrivateMessageList.class);
                if (messageList == null) return;
                messageListPage = messageList.getPage();
                if (messageListPage == null) return;
                List<UserPrivateMessageList.PageBean.ResultBean> pageNewResult = new ArrayList<>();
                List<UserPrivateMessageList.PageBean.ResultBean> pageResult = messageListPage.getResult();
                if (pageResult == null) return;
                Logger.d(Logger.DEBUG_TAG, "服务器返回的聊天组的数量：" + pageResult.size());


                //展示屏蔽消息用
                List<ChatMessageResultBean> messageInfoListShield = ChatMessageResultBeanHelper.getInstance().getMessageInfoList();
                Logger.d(Logger.DEBUG_TAG, "屏蔽的聊天组数量：" + messageInfoListShield.size());
                for (int j = 0; j < messageInfoListShield.size(); j++) {
                    ChatMessageResultBean chatMessageResultBean = messageInfoListShield.get(j);
                    String groupId = chatMessageResultBean.getGroupId();
                    MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(Long.parseLong(groupId));
                    if (messageInfoByID == null) {
                        messageInfoByID = new MessageInfo();
                    }
                    Logger.d(Logger.DEBUG_TAG, "屏蔽消息内容：" + chatMessageResultBean.getContent());

                    messageInfoByID.setMessageId(Long.parseLong(groupId));
                    messageInfoByID.setAddTime(chatMessageResultBean.getAddTime());
                    messageInfoByID.setLastContent(chatMessageResultBean.getContent());
                    messageInfoByID.setLastMsgUid(chatMessageResultBean.getUid());
                    messageInfoByID.setLastUpdateTime(chatMessageResultBean.getAddTime());
                    messageInfoByID.setType(2);
                    messageInfoByID.setReject(chatMessageResultBean.getReject());

                    UserPrivateMessageList.PageBean.ResultBean.UserBean userBean = new UserPrivateMessageList.PageBean.ResultBean.UserBean();
                    userBean.setAvatar(chatMessageResultBean.getAvatar());
                    userBean.setId(Integer.parseInt(String.valueOf(chatMessageResultBean.getUid())));
                    userBean.setName(chatMessageResultBean.getName());
                    messageInfoByID.setUser(JsonHelper.createJsonString(userBean));

                    //获取已屏蔽用户信息表已保存的表
                    MessageInfoHelper.getInstance().asyncWriteMessageInfo(messageInfoByID);


                    //刷新界面
                    UserPrivateMessageList.PageBean.ResultBean resultBean = new UserPrivateMessageList.PageBean.ResultBean();
                    resultBean.setType(2);
                    resultBean.setAddTime(chatMessageResultBean.getAddTime());
                    resultBean.setId(Integer.parseInt(groupId));
                    resultBean.setLastContent(chatMessageResultBean.getContent());
                    resultBean.setLastMsgUid(Integer.parseInt(String.valueOf(chatMessageResultBean.getUid())));
                    resultBean.setLastUpdateTime(chatMessageResultBean.getAddTime());
                    resultBean.setReject(chatMessageResultBean.getReject());
                    resultBean.setUser(userBean);
                    pageNewResult.add(resultBean);

                }


                //保存到数据库
                for (int i = 0; i < pageResult.size(); i++) {
                    UserPrivateMessageList.PageBean.ResultBean resultBean = pageResult.get(i);

                    MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(resultBean.getId());
                    if (messageInfoByID != null) {
                        messageInfoByID.setMessageId((long) resultBean.getId());
                        messageInfoByID.setAddTime(resultBean.getAddTime());
                        messageInfoByID.setLastContent(resultBean.getLastContent());
                        messageInfoByID.setLastMsgUid((long) resultBean.getLastMsgUid());
                        messageInfoByID.setMember(JsonHelper.createJsonString(resultBean.getMember()));
                        messageInfoByID.setReject(resultBean.getReject());
                        messageInfoByID.setUser(JsonHelper.createJsonString(resultBean.getUser()));

                        if (messageInfoByID.getLastUpdateTime() == resultBean.getLastUpdateTime()) {//如果消息没更新
                            resultBean.setType(2);
                        } else {
                            if (resultBean.getLastMsgUid() == UserDataManager.getUid()) {//如果是自己发送的消息
                                resultBean.setType(2);
                            }
                        }
                    } else {
                        messageInfoByID = new MessageInfo();
                        messageInfoByID.setMessageId((long) resultBean.getId());
                        messageInfoByID.setAddTime(resultBean.getAddTime());
                        messageInfoByID.setLastContent(resultBean.getLastContent());
                        messageInfoByID.setLastMsgUid((long) resultBean.getLastMsgUid());
                        messageInfoByID.setLastUpdateTime(resultBean.getLastUpdateTime());
                        messageInfoByID.setMember(JsonHelper.createJsonString(resultBean.getMember()));
                        messageInfoByID.setReject(resultBean.getReject());
                        if (resultBean.getLastMsgUid() == UserDataManager.getUid()) {//如果是自己发送的消息
                            resultBean.setType(2);
                        } else {
                            messageInfoByID.setType(resultBean.getType());
                        }

                        messageInfoByID.setUser(JsonHelper.createJsonString(resultBean.getUser()));
                    }

                    MessageInfoHelper.getInstance().asyncWriteMessageInfo(messageInfoByID);
                    pageNewResult.add(resultBean);
                }

//                List<MessageInfo> messageInfoList = MessageInfoHelper.getInstance().getMessageInfoList();
//                Logger.e(Logger.DEBUG_TAG, "数据库的数量:" + messageInfoList.size());

                messageListTotalPages = messageListPage.getTotalPages();

                Collections.sort(pageNewResult);
//                Logger.e(Logger.DEBUG_TAG, "界面展示的聊天组数量：" + pageNewResult.size());

//                for (int j = 0; j < pageNewResult.size(); j++) {
//                    long lastUpdateTime = pageNewResult.get(j).getLastUpdateTime();
//                    Logger.e(Logger.DATA_FLOW_TAG,"lastUpdateTime:"+lastUpdateTime);
//                }
                if (messageFragment != null) {
                    messageFragment.setUserPrivateMessageList(pageNewResult);
                    messageFragment.stopRefresh();
                    messageFragment.stopLoadMore();
                }

                break;
            case Config.MODULE_USER + 71://用户通知列表
                NoticeFragmentListBean noticeFragmentListBean = JsonHelper.getObject(result, NoticeFragmentListBean.class);
                if (noticeFragmentListBean == null) return;
                List<NoticeFragmentListBean.NoticesBean> noticesBeanList = noticeFragmentListBean.getNotices();
                if (noticesBeanList.size() > 0) {//大于0，说明有新增加的通知
                    for (int i = 0; i < noticesBeanList.size(); i++) {
                        NoticeFragmentListBean.NoticesBean noticesBean = noticesBeanList.get(i);
                        NoticeInfo noticeInfoByID;
                        noticeInfoByID = NoticeInfoHelper.getInstance().getNoticeInfoByID(noticesBean.getId());
                        if (noticeInfoByID != null) {
                            noticeInfoByID.setAddTime(noticesBean.getAddTime());
                            noticeInfoByID.setFromUser(JsonHelper.createJsonString(noticesBean.getFromUser()));
                            noticeInfoByID.setNoticeId((long) noticesBean.getId());
                            noticeInfoByID.setMsgBody(JsonHelper.createJsonString(noticesBean.getMsgBody()));
                            noticeInfoByID.setSelectChannel(Integer.parseInt(noticesBean.getSelectChannel()));
                            noticeInfoByID.setStatus(noticesBean.getStatus());
                        } else {
                            noticeInfoByID = new NoticeInfo();
                            noticeInfoByID.setAddTime(noticesBean.getAddTime());
                            noticeInfoByID.setFromUser(JsonHelper.createJsonString(noticesBean.getFromUser()));
                            noticeInfoByID.setNoticeId((long) noticesBean.getId());
                            noticeInfoByID.setMsgBody(JsonHelper.createJsonString(noticesBean.getMsgBody()));
                            noticeInfoByID.setSelectChannel(Integer.parseInt(noticesBean.getSelectChannel()));
                            noticeInfoByID.setStatus(noticesBean.getStatus());
                        }

                        noticeInfoListData.add(noticeInfoByID);
                        getNoticeAdapterDataList().add(noticesBean);
                        NoticeInfoHelper.getInstance().asyncWriteNoticeInfo(noticeInfoByID);
                    }
                } else if (noticesBeanList.size() == 0) {
                    SettingsHelper.putBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, false);
                }
//                Logger.e(Logger.DEBUG_TAG, "红点:" + SettingsHelper.getBoolean(Config.SETTING_NOTICE_TOPIC_ANSWER_DISCUSS_UPDATE, false));
//                Logger.e(Logger.DEBUG_TAG, "通知消息 数据库的数量:" + NoticeInfoHelper.getInstance().getNoticeInfoList().size());
                if (noticeFragment != null) {
                    noticeFragment.setNoticeMessageList(getNoticeAdapterDataList());
                    noticeFragment.stopRefresh();
                }
                break;
            case Config.MODULE_USER + 73://删除私信
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    int code = jsonObject.getInt("code");
                    if (0 == code) {
                        int id = messageFragment.
                                getUserPrivateMessageList().get(messageDeletePosition).getId();
                        //删除该消息列表
                        MessageInfoHelper.getInstance().deleteMessageInfoByMessageId(id);
                        //删除屏蔽用户信息表
                        ChatMessageResultBean chatMessageInfoListByID = ChatMessageResultBeanHelper.getInstance().getChatMessageInfoListByID(String.valueOf(id));
                        if (chatMessageInfoListByID != null) {
                            ChatMessageResultBeanHelper.getInstance().asyncDeleteMessageInfo(chatMessageInfoListByID);
                        }
                        //删除该组所有聊天消息
                        ChatMessageInfoListHelper.getInstance().asyncDeleteMessageInfoList(ChatMessageInfoListHelper.
                                getInstance().getChatMessageInfoListByID(String.valueOf(id)));
                        if (messageFragment != null) {
                            messageFragment.getUserPrivateMessageList().remove(messageDeletePosition);
                            messageFragment.setUserPrivateMessageList(messageFragment.getUserPrivateMessageList());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case Config.MODULE_USER + 74://用户私信关系设置
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    int code = jsonObject.getInt("code");
                    if (0 == code) {
                        if (messageFragment != null) {

                            UserPrivateMessageList.PageBean.ResultBean resultBean = messageFragment.getUserPrivateMessageList().get(messageShieldPosition);
                            if (0 == messageShieldReject) {
                                resultBean.setReject(1);
                                messageFragment.setUserPrivateMessageList(messageFragment.getUserPrivateMessageList());


                                MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(Long.parseLong(String.valueOf(resultBean.getId())));
                                if (messageInfoByID != null) {
                                    messageInfoByID.setReject(1);
                                    MessageInfoHelper.getInstance().asyncWriteMessageInfo(messageInfoByID);
                                }


                            } else if (1 == messageShieldReject) {
                                resultBean.setReject(0);
                                messageFragment.setUserPrivateMessageList(messageFragment.getUserPrivateMessageList());
                                MessageInfo messageInfoByID = MessageInfoHelper.getInstance().getMessageInfoByID(Long.parseLong(String.valueOf(resultBean.getId())));
                                if (messageInfoByID != null) {
                                    messageInfoByID.setReject(0);
                                    MessageInfoHelper.getInstance().asyncWriteMessageInfo(messageInfoByID);
                                }

                                ChatMessageResultBean chatMessageInfoListByID = ChatMessageResultBeanHelper.getInstance().getChatMessageInfoListByID(String.valueOf(resultBean.getId()));
                                if (chatMessageInfoListByID != null) {//取消屏蔽后删除该记录
                                    chatMessageInfoListByID.setReject(0);
                                    ChatMessageResultBeanHelper.getInstance().asyncDeleteMessageInfo(chatMessageInfoListByID);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case Config.MODULE_USER + 75://读取通知信息

                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "MessageNoticeActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onMessageRefresh() {
        messagePage = 1;
        //getMessageAdapterDataList();
        getMessageListData();
    }

    @Override
    public void onMessageLoadMore() {
        MessageFragment messageFragment = (MessageFragment) getSupportFragmentManager().findFragmentByTag(MessageFragment.TAG);
        if (messageFragment != null) {
            if (messagePage < messageListTotalPages) {
                messagePage++;
                getMessageListData();
            } else {
                messageFragment.loadNothingMore();
            }

        }

    }

    @Override
    public void onNoticeRefresh() {
        noticePage = 1;
        getNoticeAdapterDataList();
        getUserNoticeListData();
    }


    @Override
    public void onNoticeLoadMore() {
        NoticeFragment noticeFragment = (NoticeFragment) getSupportFragmentManager().findFragmentByTag(NoticeFragment.TAG);
        if (noticeFragment != null) {
            noticeFragment.loadNothingMore();
        }
    }

    @Override
    public void onReadNoticeMessage(int position) {
        NoticeFragment noticeFragment = (NoticeFragment) getSupportFragmentManager().findFragmentByTag(NoticeFragment.TAG);
        if (noticeFragment != null) {
            int requestId = UserDataManager.getInstance().readUserNoticeMsg(noticeFragment.getNoticeMessageList().get(position).getId(), true);
            registerDataReqStatusListener(requestId);
            int id = noticeFragment.getNoticeMessageList().get(position).getId();
            NoticeInfo noticeInfo = NoticeInfoHelper.getInstance().getNoticeInfoByID(id);
            noticeInfo.setStatus(2);
            NoticeInfoHelper.getInstance().asyncWriteNoticeInfo(noticeInfo);
        }

    }

    @Override
    public void onNoticeDelete(int position) {
        noticeDeletePosition = position;
        showConfirmTip(position, R.string.confirm_delete_this_message, NOTICE_DELETE);

    }

    @Override
    public void onMessageDelete(int position) {
        messageDeletePosition = position;
        showConfirmTip(position, R.string.confirm_delete_this_message, MESSAGE_DELETE);
    }

    @Override
    public void onMessageShield(int position, int reject) {
        messageShieldPosition = position;
        messageShieldReject = reject;
        if (0 == reject) {//屏蔽
            showConfirmTip(position, R.string.confirm_shield_this_user, MESSAGE_SHIELD);
        } else if (1 == reject) {//取消屏蔽
            showConfirmTip(position, R.string.confirm_cancel_shield_this_user, MESSAGE_CANCEL_SHIELD);
        }
    }

}
