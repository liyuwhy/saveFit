package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.common.sound.PlayerController;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.VideoDetail;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.bean.Video;
import com.fitmix.sdk.view.widget.AppMsg;


public class VideoDetailActivity extends BaseActivity {
    private SimpleDraweeView img_video_cover;
    private TextView tv_video_title;
    private TextView tv_track_length;
    private TextView tv_video_content;
    private Video video;
//    private ArrayList<Video> videoList;
//    private int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_detail);
        setPageName("VideoDetailActivity");
//        videoList = getIntent().getParcelableArrayListExtra("videoList");
//        index = getIntent().getIntExtra("currentIndex", -1);
//        video = videoList.get(index);
        String videoString = getIntent().getStringExtra("videoString");
        if (!TextUtils.isEmpty(videoString))
            video = JsonHelper.getObject(videoString, Video.class);
        initToolbar();
        initViews();
        initData();
        if (getIntent() != null) {
            if (getIntent().getBooleanExtra("isFromXinGe", false)) {//从信鸽推送消息跳转进来
                int requestId = DiscoverDataManager.getInstance().getVideoDetail(getIntent().getIntExtra("videoId", 0), true);
                registerDataReqStatusListener(requestId);
            }
        }
    }

    protected void initViews() {
        showGoToPlayMusicMenu = true;
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        img_video_cover = (SimpleDraweeView) findViewById(R.id.img_video_cover);
        tv_video_title = (TextView) findViewById(R.id.tv_video_title);
        tv_track_length = (TextView) findViewById(R.id.tv_track_length);
        tv_video_content = (TextView) findViewById(R.id.tv_video_content);
    }

    private void initData() {
        if (video == null)
            return;
        if (!TextUtils.isEmpty(video.getPosterUrl())) {
            img_video_cover.setImageURI(Uri.parse(video.getPosterUrl()));
        }
        tv_video_title.setText(video.getTitle());
        long time = Long.parseLong(video.getTrackLength());
        String videoTimeText = getString(R.string.activity_main_discovery_video_time, FormatUtil.formatMusicTime(time));
        tv_track_length.setText(videoTimeText);
        tv_video_content.setText(video.getContent());
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 60://完成每日分享运动视频金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, System.currentTimeMillis());//设置完成任务时间

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
            case Config.MODULE_COMPETITION + 21://获取视频详情
                VideoDetail videoDetail = JsonHelper.getObject(result, VideoDetail.class);
                video = videoDetail.getVideo();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (video == null)
                            return;
                        if (!TextUtils.isEmpty(video.getPosterUrl())) {
                            img_video_cover.setImageURI(Uri.parse(video.getPosterUrl()));
                        }
                        tv_video_title.setText(video.getTitle());
                        long time = Long.parseLong(video.getTrackLength());
                        String videoTimeText = getString(R.string.activity_main_discovery_video_time, FormatUtil.formatMusicTime(time));
                        tv_track_length.setText(videoTimeText);
                        tv_video_content.setText(video.getContent());
                    }
                });
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        //不处理
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem menu_second = menu.add(0, Menu.FIRST + 4, 4, "share_video").setIcon(R.drawable.ic_share_selector);
        menu_second.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case Menu.FIRST + 4://分享视频
                shareVideo();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.play:
                startPlayVideoActivity();
                break;
        }
    }

    public void shareVideo() {
        if (video != null)
            ShareUtils.getInstance().shareVideo(this, video);
    }

    private void startPlayVideoActivity() {
        if (video == null) return;
        if (PlayerController.getInstance().isMusicPlaying()) {
            PlayerController.getInstance().pauseMusic();
        }
        Intent intent = new Intent();
        if (video.getType() != 1) {
            intent.setClass(this, PlayVideoActivity.class);
        } else {
            intent.setClass(this, PlayVrVideoActivity.class);
        }
        intent.putExtra("videoString", JsonHelper.createJsonString(video));
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    if (data == null) return;
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                        case AuthShareHelper.REQUESTCODE_WECHAT_LOGIN:
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            int resCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, AuthShareHelper.RESULTCODE_FAILURE);//默认时是失败
                            if (resCode == AuthShareHelper.RESULTCODE_SUCCESS) {
                                finishShareVideoCoinTask();
                            }
                            break;
                    }
                }
                break;
        }
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成每日分享运动视频金币任务
     */
    private void finishShareVideoCoinTask() {
        long lastShareTime = SettingsHelper.getLong(Config.SETTING_COIN_TASK_SHARE_VIDEO, 0);
        if (!FitmixUtil.isToday(lastShareTime)) {//今日已分享过,不再处理
            int uid = UserDataManager.getUid();
            int requestId = UserDataManager.getInstance().finishShareVideoCoinTask(uid, true);
            registerDataReqStatusListener(requestId);
        }
    }

    //endregion ============================= 金币任务 =============================
}
