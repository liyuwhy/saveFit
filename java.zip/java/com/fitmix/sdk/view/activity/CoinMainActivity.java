package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.model.api.bean.AccountInfo;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.UserRunStatistics;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.widget.AppMsg;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

/**
 * 我的金币任务,导航界面
 */
public class CoinMainActivity extends BaseActivity {

    private TextView tv_total_coin_number;//总金币数量
    private Button btn_sign_in;
    private int signInRewards;//签到奖励的金币数
    private int coinNumbers;
    private boolean signed;//是否已签到
    private int level;//用户当前等级

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_main);
        setPageName("CoinMainActivity");
        initToolbar();
        initViews();

        getUserLevel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getCoinInfo();
    }

    /**
     * 获取用户等级
     */
    private void getUserLevel() {
        //1.加载个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (!TextUtils.isEmpty(email) || !TextUtils.isEmpty(password)) {
                int requestId = UserDataManager.getInstance().emailLogin(email, password);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                Logger.i(Logger.DEBUG_TAG, "openid:" + openid + " tokenId:" + tokenId);
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        }
    }

    /**
     * 获取用户信息,如金币数量等
     */
    private void getCoinInfo() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().getUserAccountInfo(uid, true);//忽略缓存
        registerDataReqStatusListener(requestId);
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        tv_total_coin_number = (TextView) findViewById(R.id.tv_total_coin_number);
        btn_sign_in = (Button) findViewById(R.id.btn_sign_in);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "CoinMainActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 2://邮箱或者手机账号登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录
                setUserLevel(result);
                break;

            case Config.MODULE_USER + 50://获取用户信息,金币总量,今日签到状态等
                AccountInfo accountInfo = JsonHelper.getObject(result, AccountInfo.class);
                if (accountInfo != null) {
                    if (accountInfo.getAccount() != null) {//总金币
                        coinNumbers = accountInfo.getAccount().getCoin();
                        if (tv_total_coin_number != null) {
                            tv_total_coin_number.setText(String.valueOf(coinNumbers));
                        }
                    }

                    if (accountInfo.getEVERY_DAY_SIGN_IN() != null) {//今日签到状态
                        int finishStatus = accountInfo.getEVERY_DAY_SIGN_IN().getFinishStatus();
                        if (finishStatus == 0) {//今天已签到
                            signed = true;
                            btn_sign_in.setText(getString(R.string.activity_coin_main_sign_success));
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                btn_sign_in.setBackground(ContextCompat.getDrawable(this, R.drawable.round_corner_orange_stroke_bg));
                            } else {
                                btn_sign_in.setBackgroundDrawable(ContextCompat.getDrawable(this, R.drawable.round_corner_orange_stroke_bg));
                            }
                            btn_sign_in.setTextColor(ContextCompat.getColor(this, R.color.orange_text));
                        } else if (finishStatus == 1) {
                            signed = false;
                            signInRewards = accountInfo.getEVERY_DAY_SIGN_IN().getCoin();
                            if (btn_sign_in != null) {
                                btn_sign_in.setText(String.format("%s%s%s", getString(R.string.activity_coin_main_total_coin_format1)
                                        , String.valueOf(signInRewards)
                                        , getString(R.string.activity_coin_main_total_coin_format2)));
                            }
                        }
                    }
                }
                break;

            case Config.MODULE_USER + 52://完成任务(每日签到)
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功,重新获取金币信息
                        //弹窗
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                        getCoinInfo();
                    }
                }
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "MainActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            int errorCode = bean.getCode();
            switch (requestId) {
                case Config.MODULE_USER + 50://获取用户信息,金币总量,今日签到状态等
                    if (errorCode == 8003) {
                        String text = bean.getMsg();
                        if (!TextUtils.isEmpty(text))
                            showAppMessage(text, AppMsg.STYLE_ALERT);
                    }
                    super.processReqError(requestId, error);
                    break;

            }
        }
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_sign_in://签到
                if (signed) {
                    return;
                } else {
                    int uid = UserDataManager.getUid();
                    int requestId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_EVERYDAY, Config.COIN_TASK_SIGN, true);
                    registerDataReqStatusListener(requestId);
                }

//                //发广播
//                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(MixApp.getContext());
//                Intent intent = new Intent();
//                intent.putExtra("flag", 1);//广播类型,1:用户等级升级金币,2:每日三公里金币
//                intent.putExtra("coin", 100);
//                intent.putExtra("taskName", "用户升级");
//                intent.putExtra("prevLevel",1);
//                intent.putExtra("level",4);
//                intent.setAction(Config.COIN_TASK_RUN_RECORD_BROADCAST);
//                lbm.sendBroadcast(intent);
//
//                Intent intent1 = new Intent();
//                intent1.putExtra("flag", 2);//广播类型,1:用户等级升级金币,2:每日三公里金币
//                intent1.putExtra("coin", 30);
//                intent1.putExtra("taskName", "每日三公里");
//                intent1.setAction(Config.COIN_TASK_RUN_RECORD_BROADCAST);
//                lbm.sendBroadcast(intent1);

                break;

            case R.id.btn_coin_quest://金币任务
                startCoinQuestActivity();
                break;

            case R.id.btn_coin_exchange://金币兑换
                startCoinExchangeActivity();
                break;

            case R.id.btn_coin_detail://金币明细
                startCoinDetailActivity();
                break;

            case R.id.btn_coin_explain://金币说明
                startCoinExplainActivity();
                break;
        }
    }


    /**
     * 设置用户等级
     */
    private void setUserLevel(String result) {
        Login login = JsonHelper.getObject(result, Login.class);
        if (login != null) {
            UserRunStatistics userRunStatistics = login.getUserRunStatistics();
            if (userRunStatistics != null) {
                level = userRunStatistics.getUserLevel();
            }
        }
    }


    /**
     * 启动我的金币任务界面
     */
    public void startCoinQuestActivity() {
        Intent intent = new Intent(this, CoinQuestActivity.class);
        intent.putExtra("nextLevel", (level + 1));//"RUN_LEVEL_"+
        Logger.i(Logger.DEBUG_TAG, "startCoinQuestActivity level:" + level);
        startActivity(intent);
    }

    /**
     * 启动金币兑换界面
     */
    public void startCoinExchangeActivity() {
        Intent intent = new Intent(this, CoinExchangeActivity.class);
        startActivity(intent);
    }

    /**
     * 启动金币明细记录界面
     */
    public void startCoinDetailActivity() {
        Intent intent = new Intent(this, CoinDetailActivity.class);
        startActivity(intent);
    }

    /**
     * 启动金币说明界面
     */
    public void startCoinExplainActivity() {
        Intent intent = new Intent(this, CoinExplainActivity.class);
        startActivity(intent);
    }

}
