package com.fitmix.sdk.view.activity;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.bluetooth.ble.HRSManager;
import com.fitmix.sdk.common.bluetooth.scanner.ScannerFragment;
import com.fitmix.sdk.model.api.bean.RestHeartRateBean;
import com.fitmix.sdk.model.api.bean.RestHeartRateList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.RestHeartRate;
import com.fitmix.sdk.model.database.RestHeartRateHelper;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.service.WatchService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AnimationNumberTextView;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.HeartRateDetectProgress;
import com.fitmix.sdk.watch.WatchDataProtocol;
import com.fitmix.sdk.watch.WatchFormatManager;

import java.lang.ref.WeakReference;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

/**
 * 静息心率界面
 */
public class HeartRateActivity extends BaseWatchActivity implements CompoundButton.OnCheckedChangeListener, ScannerFragment.OnDeviceSelectedListener {

    private CheckBox cb_connect_heart_rate;
    private Button btn_start_detect;
    private HeartRateDetectProgress arc_progress;
    private AnimationNumberTextView tv_rate;
    private long animationDefaultDuration;
    private TimeInterpolator interpolator;

    private float num_last_time_detect;//上一次检测的数值
    private TextView tv_upon_text;
    private ImageView iv_heart_rate_icon;
    private TextView tv_unit;
    private TextView tv_bottom;
    private RelativeLayout rl_heart_rate_record;

    private TextView tv_rest_hr_detect_title;
    private TextView tv_rest_hr_detect_warn;
    private TextView tv_rest_hr_detect_count_down;

    private BluetoothAdapter mBluetoothAdapter;

    private boolean checkByMan = true;
    private List<Integer> list_heart_rate;//点击检测后不断收集心率数据，不包括0
    private boolean showCurrentHeartRate;//是否显示瞬时心率（刚连接、检测时）两个时刻

    private ServiceConnection serviceConnection;//心率服务连接
    private HeartRateService heartRateService;//心率服务
    private RestHeartRate info;//数据库数据

    private int[] restingArea;
    //region ====================================== 检测倒计时相关 ======================================
    /**
     * 更新倒计时进度条消息
     */
    private static final int MSG_UPDATE = 26;
    private CountDownHandler mHandler;

    private int DELAYED = 1000;
    private int mCountDownTime = 120;
    private int time_now = 0;//现在已经执行的时间
    private Dialog tipDialog;
    private boolean isWatchConnect = false;
    private boolean dataChannelIsWatch = false;
    private boolean dataChannelIsEarSet = false;
    private String deviceName;

    public static class CountDownHandler extends Handler {
        private WeakReference<HeartRateActivity> mActivity;

        public CountDownHandler(HeartRateActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_UPDATE:
                    if (mActivity != null && mActivity.get() != null) {
                        mActivity.get().hr_detect_count_down();
                    }
                    break;
            }
        }
    }

    /**
     * 心率检测倒计时刷新
     */
    private void hr_detect_count_down() {
        if (heartRateService == null) {
            return;
        }
        time_now++;
        if (time_now < mCountDownTime) {//倒计时未结束
            showCurrentHeartRate = true;
            if (heartRateService.getLatestHeartRate() != 0) {//过滤掉心率值为0
                list_heart_rate.add(heartRateService.getLatestHeartRate());
            }
            arc_progress.setProgress(time_now * 100 / mCountDownTime);//设置进度
            mHandler.sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);
            Logger.i(Logger.DEBUG_TAG, "mCountDownTime:" + mCountDownTime + ",time_now:" + time_now + ",list_heart_rate.size()" + list_heart_rate.size());
            tv_rest_hr_detect_count_down.setText(String.format(getResources().getString(R.string.heart_rate_detect_count_down), String.format("%02d", (mCountDownTime - time_now) / 60) + ":" + String.format("%02d", ((mCountDownTime - time_now) % 60))));

        } else {//倒计时结束
            int value = 0;
            int value_size = list_heart_rate.size();
            if (value_size == 0) {
                return;
            }
            for (int i = value_size - 1; i >= 0; i--) {
                value += list_heart_rate.get(i);
            }
            value = value / value_size;
            arc_progress.setProgress(100);//设置进度
            tv_rest_hr_detect_count_down.setText("");
            showCurrentHeartRate = false;

            //静息心率相关统计数据置原
            mHandler.removeCallbacksAndMessages(null);
            list_heart_rate.clear();//重新点击开始检测时需要根据list_heart_rate.size()判断检测还是停止检测
            detectFinish(value);
        }
    }

    /**
     * 心率相关统计数据清空(需要时，调用在setProgress(0)之后)
     */
    private void HrDataClear() {
        time_now = 0;
        list_heart_rate.clear();
    }

    //endregion ====================================== 检测倒计时相关 ======================================


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate);
        setPageName("HeartRateActivity");
        int watchVersionNum = SettingsHelper.getInt(Config.SETTING_WATCH_VERSIONNUM, 0);
        if (watchVersionNum > 7) {
            bindWatchService();
        }
        initToolbar();
        initViews();
        setToolbar();
        if (mHandler != null) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
                        connectToHeartRateService();
                    }
                }
            }, 500);
        }

    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);

        }
        animationDefaultDuration = 2000; //默认2秒动画
        interpolator = new AccelerateDecelerateInterpolator();
        cb_connect_heart_rate = (CheckBox) findViewById(R.id.cb_connect_heart_rate);
        btn_start_detect = (Button) findViewById(R.id.btn_start_detect);
        arc_progress = (HeartRateDetectProgress) findViewById(R.id.arc_progress);
        tv_rate = (AnimationNumberTextView) findViewById(R.id.tv_rate);
        btn_start_detect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!dataChannelIsWatch && !dataChannelIsEarSet) {//都没连接
                    showUseTip(getResources().getString(R.string.before_use_tip), getResources().getString(R.string.i_know), false);
                }

                if (dataChannelIsWatch) {//当前数据通道是手表
                    if (isWatchConnect) {//已连接手表
                        if (cb_connect_heart_rate.isChecked()) {
                            if (heartRateService != null && heartRateService.getDevice() != null) {
                                if (list_heart_rate.size() <= 0) {
                                    sendSwitchWatchDetectHrUiCmd();
                                    showUseTip(getResources().getString(R.string.in_use_tip), getResources().getString(R.string.i_know), false);
                                    startDetect();
                                } else {
                                    stopDetect();
                                }
                            }
                        } else {
                            Toast.makeText(HeartRateActivity.this, getResources().getString(R.string.heart_rate_belt_to_connect), Toast.LENGTH_SHORT).show();
                        }
                    } else {//未连接手表
                        showUseTip(getResources().getString(R.string.to_bind_tip), getResources().getString(R.string.to_bind_button), true);
                    }

                }

                if (dataChannelIsEarSet) {//当前数据通道是耳机
                    if (cb_connect_heart_rate.isChecked()) {
                        if (heartRateService != null && heartRateService.getDevice() != null) {
                            if (list_heart_rate.size() <= 0) {
                                startDetect();
                            } else {
                                stopDetect();
                            }
                        }
                    } else {
                        Toast.makeText(HeartRateActivity.this, getResources().getString(R.string.heart_rate_belt_to_connect), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        cb_connect_heart_rate.setOnCheckedChangeListener(this);

        tv_upon_text = (TextView) findViewById(R.id.tv_upon_text);
        iv_heart_rate_icon = (ImageView) findViewById(R.id.iv_heart_rate_icon);
        tv_unit = (TextView) findViewById(R.id.tv_unit);
        tv_bottom = (TextView) findViewById(R.id.tv_bottom);
        rl_heart_rate_record = (RelativeLayout) findViewById(R.id.rl_heart_rate_record);
        rl_heart_rate_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HeartRateActivity.this, HeartRateRecordActivity.class);
                startActivity(intent);
            }
        });
        list_heart_rate = new ArrayList<>();

        //静息心率，数据库搜索最近一次的静息心率记录
        RestHeartRateHelper.getInstance().asyncGetLatestHeartRateInfo(HeartRateActivity.this, UserDataManager.getUid(), new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                RestHeartRate records = (RestHeartRate) operation.getResult();
                if (records != null) {
                    num_last_time_detect = ((records.getHeart_rate_record() != null) ? records.getHeart_rate_record() : 0);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showLastestRestHR();
                        }
                    });
                } else {
                    requestAllRestHeartRateHistory();
                }

            }
        });

        mHandler = new CountDownHandler(this);
        tv_rest_hr_detect_title = (TextView) findViewById(R.id.tv_rest_hr_detect_title);
        tv_rest_hr_detect_warn = (TextView) findViewById(R.id.tv_rest_hr_detect_warn);
        tv_rest_hr_detect_count_down = (TextView) findViewById(R.id.tv_rest_hr_detect_count_down);
        TextView tv_hr_range = (TextView) findViewById(R.id.tv_hr_range);
        tv_hr_range.setText(String.format(getResources().getString(R.string.heart_rate_tips),
                String.valueOf(getRestingArea()[0]),
                String.valueOf(getRestingArea()[1])));
    }

    private int[] getRestingArea() {
        if (restingArea == null) {
            restingArea = FitmixUtil.getRestingHRArea(SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE), SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE));
        }
        return restingArea;
    }

    //region ##################### 静息心率记录获取 #####################

    /**
     * 请求获取所有静息心率记录
     */
    public void requestAllRestHeartRateHistory() {
        int requestId = SportDataManager.getInstance().getAllRestHeartRateHistory(UserDataManager.getUid());
        registerDataReqStatusListener(requestId);
    }

    /**
     * 对比全部静息心率记录列表，存储数据库
     *
     * @param result 网络请求返回的结果
     */
    private void setRestHeartRateList(String result) {
        RestHeartRateList recordList = JsonHelper.getObject(result, RestHeartRateList.class);
        if (recordList != null) {
            //2.更新心率记录数据库表
            if (recordList.getList().size() == 0) return;
            boolean success = RestHeartRateHelper.getInstance().bulkAddOrUpdateRestHeartList(recordList.getList(), 1);//网络获取来的数据均为同步成功的
            //3.从数据请求状态表中,清除还在缓存有效期内的请求结果
            if (success) {
                UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(16));
                RestHeartRateBean bb = recordList.getList().get(0);
                num_last_time_detect = ((bb != null) ? bb.getHeartRateVal() : 0);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showLastestRestHR();
                    }
                });
            }
        }
    }

    //endregion ##################### 静息心率记录获取 #####################

    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);

        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Logger.e(Logger.DEBUG_TAG, "HeartRateActivity heartService onServiceConnected()");
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService != null) {
                    heartRateService.setIfBindWithRunMain(false);
                    heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);

                    if (heartRateService.getDevice() != null) {
                        String name1 = heartRateService.getDevice().getName();
                        if (name1 == null) {
                            gattCheckByProgram(false);
                            if (isWatchConnect) {
                                if (!dataChannelIsWatch && !dataChannelIsEarSet) {
                                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                                        BluetoothDevice device = mWatchService.getDevice();
                                        if (device != null) {
                                            heartRateService.setDevice(device);
                                            if (heartRateService.getBleManager() != null) {
                                                heartRateService.getBleManager().disconnect();
                                                heartRateService.getBleManager().connect(device);
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (TextUtils.isEmpty(name1)) return;
                            if (name1.contains("H10") ||
                                    name1.contains("ROC HR") ||
                                    name1.contains("ROC Model")) {
                                dataChannelIsWatch = false;
                                dataChannelIsEarSet = true;
                                showCurrentHeartRate = true;
                                showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                                gattCheckByProgram(true);
                                setSignalValueText();
                            } else if (name1.contains("IRON CLOUD")) {
                                dataChannelIsWatch = true;
                                dataChannelIsEarSet = false;
                                showCurrentHeartRate = true;
                                showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                                gattCheckByProgram(true);
                                setSignalValueText();
                            }
                        }


                    } else {
                        dataChannelIsEarSet = false;
                        gattCheckByProgram(false);
                        if (isWatchConnect) {
                            if (!dataChannelIsWatch && !dataChannelIsEarSet) {
                                if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                                    BluetoothDevice device = mWatchService.getDevice();
                                    if (device != null) {
                                        heartRateService.setDevice(device);
                                        if (heartRateService.getBleManager() != null) {
                                            heartRateService.getBleManager().disconnect();
                                            heartRateService.getBleManager().connect(device);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (heartRateService != null) {
                heartRateService.removeHeartRateItem(mPageName);
                //释放服务运用到的相关资源
            }
        }
        if (serviceConnection != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(serviceConnection);
            }
        }
        serviceConnection = null;
    }

    @Override
    protected void onStop() {
        super.onStop();
//        stopDetect();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity --- > onDestroy()");

        if (heartRateService != null && heartRateService.getBleManager() != null) {
            if (deviceName != null && deviceName.equalsIgnoreCase("IRON CLOUD")) {
                heartRateService.getBleManager().disableHRCharacterNotification();
            }
            heartRateService.getBleManager().disconnect();
        }

        disconnectToHeartRateService();
        unbindWatchService();
        mHandler.removeCallbacksAndMessages(null);

    }

    //region ##################### 检测心率上的UI相关 #####################

    /**
     * 接口调用，上传检测的静息心率记录
     *
     * @param heartRate
     */
    public void uploadInfo(int heartRate, long time) {
        int requestId = SportDataManager.getInstance().uploadRestHeartRate(UserDataManager.getUid(), heartRate, time);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 圆圈UI设置心率值
     *
     * @param progress
     */
    public void setHeartRateProgress(int progress) {
        if (arc_progress != null) {
            if (progress > 0 && progress < arc_progress.getMax()) {
                ValueAnimator animator = ValueAnimator.ofInt(0, progress);
                animator.setDuration(animationDefaultDuration);
                animator.setInterpolator(interpolator);
                animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        int t = (int) animation.getAnimatedValue();
                        arc_progress.setProgress(t);
                    }
                });
                animator.start();
            } else if (progress == 0) {//为0时,倒序
                if (time_now != 0) {
                    int initNumber = time_now * 100 / mCountDownTime;
                    ValueAnimator animator = ValueAnimator.ofInt(initNumber, 0);
                    animator.setDuration(animationDefaultDuration);
                    animator.setInterpolator(interpolator);
                    animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animation) {
                            int t = (int) animation.getAnimatedValue();
                            arc_progress.setProgress(t);
                        }
                    });
                    animator.start();
                }
            }
        }
    }


    /**
     * 检测完成
     */
    private void showAfterDetected(final int num, final boolean ifValuable) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                setHeartRateProgress((num / num + 50));//百分比
                setHeartRateProgress(100);
                if (tv_rate != null) {
                    tv_rate.setIntegerText(num);
                }
                showLastestRestHR();
                btn_start_detect.setText(getResources().getString(R.string.heart_rate_start_test));
                tv_upon_text.setText(getResources().getString(R.string.heart_rate_avg));
                tv_rest_hr_detect_title.setText(getResources().getString(R.string.heart_rate_detect_finish));
                tv_rest_hr_detect_warn.setText("");
                if (ifValuable) {
                    num_last_time_detect = num; //保存上一次记录
                    tv_rest_hr_detect_count_down.setText(getResources().getString(R.string.heart_rate_detect_finish_result));
                } else {
                    tv_rest_hr_detect_count_down.setText(getResources().getString(R.string.heart_rate_detect_finish_value_error));
                    showAppMessage(getResources().getString(R.string.heart_rate_detect_finish_value_error), AppMsg.STYLE_ALERT);//提示静息心率异常
                }
            }
        });
    }

    /**
     * 显示上一次静息心率值
     */
    private void showLastestRestHR() {
        if (tv_bottom == null) return;
        if (num_last_time_detect != 0) {
            tv_bottom.setVisibility(View.VISIBLE);
            String lastTime_num = getResources().getString(R.string.heart_rate_last_time_num);
            DecimalFormat decimalFormat = new DecimalFormat("0");
            String p = decimalFormat.format(num_last_time_detect);//format 返回的是字符串
            tv_bottom.setText(String.format(lastTime_num, p));
        } else {
            tv_bottom.setVisibility(View.GONE);
        }
    }

    /**
     * 点击断开连接
     */
    public void showUIDisconnected() {
        btn_start_detect.setText(getResources().getString(R.string.heart_rate_start_test));
        tv_rate.setVisibility(View.GONE);
        tv_upon_text.setVisibility(View.GONE);
        tv_unit.setVisibility(View.GONE);
//        tv_bottom.setVisibility(num_last_time_detect == 0 ? View.GONE : View.VISIBLE);
        showLastestRestHR();
        iv_heart_rate_icon.setVisibility(View.VISIBLE);
//        if(progress != 0) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    setHeartRateProgress(0);//百分比
//                }
//            });
//        }

        btn_start_detect.setBackgroundResource(R.drawable.common_yellow_square_button_unclickable_bg);
    }

    /**
     * 心率带连接
     */
    public void showUIConnected() {
        showCurrentHeartRate = true;
        btn_start_detect.setText(getResources().getString(R.string.heart_rate_start_test));
        tv_rate.setVisibility(View.VISIBLE);
        if (heartRateService != null) {
            if (heartRateService.getLatestHeartRate() != -1) {
                tv_rate.setText(String.valueOf(heartRateService.getLatestHeartRate()));
            }
        }
        tv_upon_text.setVisibility(View.VISIBLE);
        tv_upon_text.setText(getResources().getString(R.string.heart_rate_current));
        tv_unit.setVisibility(View.VISIBLE);
        iv_heart_rate_icon.setVisibility(View.GONE);
        showLastestRestHR();

        btn_start_detect.setBackgroundResource(R.drawable.common_yellow_square_button_bg);

    }

    /**
     * 开始静息心率检测
     */
    private void startDetect() {
        tv_rest_hr_detect_title.setText(getResources().getString(R.string.heart_rate_detecting));
        tv_rest_hr_detect_warn.setText(getResources().getString(R.string.heart_rate_detecting_warn));
        tv_rest_hr_detect_count_down.setText("");
        arc_progress.setProgress(0);//设置进度

        showCurrentHeartRate = true;
        btn_start_detect.setText(getResources().getString(R.string.heart_rate_stop_test));
        tv_upon_text.setText(getResources().getString(R.string.heart_rate_current));
        HrDataClear();
        mHandler.sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);

        list_heart_rate.add(heartRateService.getLatestHeartRate());//心率集存下第一个心率值
    }

    /**
     * 停止静息心率检测
     */
    private void stopDetect() {
        showCurrentHeartRate = true;
        mHandler.removeCallbacksAndMessages(null);
        setHeartRateProgress(0);//设置进度
        HrDataClear();

        tv_rest_hr_detect_title.setText(getResources().getString(R.string.heart_rate_please_detect));
        tv_rest_hr_detect_warn.setText("");
        tv_rest_hr_detect_count_down.setText("");

        btn_start_detect.setText(getResources().getString(R.string.heart_rate_start_test));
        tv_upon_text.setText(getResources().getString(R.string.heart_rate_current));

    }
    //endregion ##################### 检测心率上的UI相关 #####################

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_SPORT + 15://上传检测的静息心率
                if (info != null) {
                    info.setUploaded(1);
                    RestHeartRateHelper.getInstance().insertRestHeartRateInfo(info);
                    info = null;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showAppMessage(getResources().getString(R.string.heart_rate_record_upload_success), AppMsg.STYLE_INFO);//提示上传成功
                    }
                });
                break;
            case Config.MODULE_SPORT + 16://获取全部的静息心率记录
                setRestHeartRateList(result);
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "HeartRateActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        super.processReqError(requestId, error);
        switch (requestId) {
            case Config.MODULE_SPORT + 15://上传检测的静息心率
                info = null;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showAppMessage(getResources().getString(R.string.heart_rate_record_upload_fail), AppMsg.STYLE_ALERT);//提示上传失败
                    }
                });
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.cb_connect_heart_rate:
                if (checkByMan) {
                    if (dataChannelIsEarSet || dataChannelIsWatch) {
                        buttonView.setChecked(true);
                    }
                    if (!dataChannelIsWatch && !dataChannelIsEarSet) {
                        buttonView.setChecked(false);
                    }
                    if (isChecked) {
                        showScanningDialog();
                    } else {//去取消连接
                        /*if (heartRateService != null && heartRateService.getBleManager() != null) {
                            heartRateService.getBleManager().disconnect();
                        }
                        if (heartRateService != null) {
                            heartRateService.setDevice(null);
                        }*/
                        showScanningDialog();
                    }
                }
                break;
        }
    }

    private void showScanningDialog() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (FitmixUtil.isBLEEnabled(HeartRateActivity.this)) {
                    if (FitmixUtil.isGpsEnable(HeartRateActivity.this)) {//开了GPS
                        showDeviceScanningDialog(getFilterUUID());
                    } else {
                        FitmixUtil.enableGPS(HeartRateActivity.this);//去开启GPS
                    }
                } else {
                    FitmixUtil.requestBlueTooth(HeartRateActivity.this);
                }
            } else {
                if (FitmixUtil.isBLEEnabled(HeartRateActivity.this)) {//蓝牙已开启的前提下
//                            if (device == null) {//可能选择了一个设备进行连接，device！=null了，但是并未连接上
                    showDeviceScanningDialog(getFilterUUID());
//                            }
                } else {
                    FitmixUtil.requestBlueTooth(HeartRateActivity.this);
                }
            }
        } else {
            Toast.makeText(HeartRateActivity.this, getResources().getString(R.string.heart_rate_warn_sdk_version), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case Config.REQUEST_ENABLE_BLUETOOTH:
                if (resultCode == RESULT_OK) {
                    cb_connect_heart_rate.setChecked(true);
                } else if (resultCode == RESULT_CANCELED) {
                    //用户不允许开启蓝牙
                }
                break;
            case Config.REQUEST_ENABLE_GPS:
                if (RESULT_OK == resultCode) {//成功授权
                    showDeviceScanningDialog(getFilterUUID());
                    return;
                }
                //GPS开启失败
                Toast.makeText(HeartRateActivity.this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                break;
        }
    }

    /**
     * CheckBox由程序设定值
     *
     * @param isCheck true:选中,false:不选中
     */
    private void gattCheckByProgram(boolean isCheck) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (cb_connect_heart_rate != null) {
                    checkByMan = false;
                    cb_connect_heart_rate.setChecked(isCheck);
                    if (!isCheck) {
                        cb_connect_heart_rate.setText(getResources().getText(R.string.heart_rate_to_connect));
                        showUIDisconnected();
                    } else {
//                String aa = getResources().getString(R.string.heart_rate_electronic_num);
//                aa += String.format("%s%s", getResources().getString(R.string.heart_rate_unknown),getResources().getString(R.string.percent));
//                cb_connect_heart_rate.setText(aa);
                        cb_connect_heart_rate.setText(getResources().getString(R.string.heart_rate_equipment_connected));
                        showUIConnected();
                    }
                    checkByMan = true;
                }
            }
        });

    }

    private void setSignalValueText() {
        if (heartRateService != null && heartRateService.getRefreshSignalStrength() != -1) {
            if (cb_connect_heart_rate != null) {
               /* String rssi = getResources().getString(R.string.heart_rate_signal_strength);
                rssi += String.format("%d%s", heartRateService.getRefreshSignalStrength(), getResources().getString(R.string.percent));*/
                cb_connect_heart_rate.setText(getResources().getString(R.string.heart_rate_equipment_connected));
            }
        }
    }

    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if (mBluetoothAdapter == null) {
            showAppMessage(R.string.bt_not_supported, AppMsg.STYLE_ALERT);
        }
        return mBluetoothAdapter;
    }

    /**
     * 数据库增加记录，上传记录，检测完成的UI变化
     */
    private void detectFinish(int rhr) {
        boolean ifValuable = isHrValuable(rhr);
        if (ifValuable) {
            //记录存在数据库表
            long time = System.currentTimeMillis();
            info = new RestHeartRate();
            info.setUid(UserDataManager.getUid());//用户uid
            info.setId_start_time(time);//运动记录编号
            info.setTime(time);//轨迹点写入时间
            info.setType(Config.HEART_RATE_REST_TYPE);//定位类型
            info.setHeart_rate_record(rhr);
            info.setUploaded(0);
            RestHeartRateHelper.getInstance().insertRestHeartRateInfo(info);
            uploadInfo(rhr, time);
        }
        showAfterDetected(rhr, ifValuable);
    }

    /**
     * 判断静息静息是否有效（如果静息心率大于热身心率的下限则无效）
     *
     * @return
     */
    private boolean isHrValuable(int hrValue) {
        int[] area = getRestingArea();
        return hrValue <= area[1] && hrValue >= area[0];
    }

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity --->  startHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        startService(i);
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity --->  stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    public void setToolbar() {
        if (toolbar == null) return;
        toolbar.setNavigationOnClickListener(null);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (heartRateService != null && heartRateService.getDevice() != null && num_last_time_detect == 0) { //绑定了心率带，并且没有静息心率记录
                    new MaterialDialog.Builder(HeartRateActivity.this)
                            .title(R.string.prompt)
                            .content(R.string.heart_rate_exit_warn)
                            .positiveText(R.string.heart_rate_start_test)
                            .negativeText(R.string.heart_rate_detect_later)
                            .cancelable(true)
                            .onAny(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    dialog.dismiss();
                                    switch (which) {
                                        case POSITIVE:
                                            startDetect();
                                            break;
                                        case NEGATIVE:
                                            onBackPressed();
                                            break;
                                    }
                                }
                            }).show();
                } else {
                    onBackPressed();
                }
            }
        });
    }

    //region ##################### HeartRateService的回调 #####################

    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {

        @Override
        public void onDeviceConnected() {
            //连接成功：
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(HeartRateActivity.this, getResources().getString(R.string.gatt_connected), Toast.LENGTH_SHORT).show();
                    showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                    if (heartRateService != null) {
                        BluetoothDevice device = heartRateService.getDevice();
                        if (device == null) return;
                        deviceName = "";
                        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                            if (device.getAddress().equalsIgnoreCase(mWatchService.getDevice().getAddress())) {
                                deviceName = "IRON CLOUD";
                            }
                        } else {
                            deviceName = device.getName();
                        }

                        if (deviceName.contains("IRON CLOUD")) {
                            dataChannelIsEarSet = false;
                            dataChannelIsWatch = true;
                            gattCheckByProgram(true);
                        } else if (deviceName.contains("H10") ||
                                deviceName.contains("ROC HR") ||
                                deviceName.contains("ROC Model")) {
                            dataChannelIsEarSet = true;
                            gattCheckByProgram(true);
                        }
                    }

                }
            });
            startHeartRateService();
        }

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {

        }

        @Override
        public void onDeviceDisconnected() {
            Logger.i(Logger.DEBUG_TAG, "HeartRateActivity heartService onDeviceDisconnected()");
            //取消连接成功
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showAppMessage(R.string.activity_pair_heart_rate_disconnected, AppMsg.STYLE_ALERT);
                    dataChannelIsEarSet = false;
                    dataChannelIsWatch = false;
                    gattCheckByProgram(false);
                    tv_rest_hr_detect_title.setText(getResources().getString(R.string.heart_rate_please_detect));
                    tv_rest_hr_detect_count_down.setText("");
                    tv_rest_hr_detect_warn.setText("");
//                    //静息心率相关统计数据置原
                    setHeartRateProgress(0);
                    HrDataClear();
                }
            });


            mHandler.removeCallbacksAndMessages(null);

            stopHeartRateService();
        }

        @Override
        public void onError() {
            Logger.i("TT", "HeartRateActivity,onError()");
        }

        @Override
        public void onHRValueReceived() {
            if (heartRateService == null) return;
            if (showCurrentHeartRate) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (tv_rate != null) {
                            tv_rate.setText(String.valueOf(heartRateService.getLatestHeartRate()));
                        }
                    }
                });
            }
        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, int signalValue) {

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    setSignalValueText();
                }
            });

        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {
        }

        @Override
        public void reDrawHeartRateData() {

        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                              int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                              boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {

        }
    };

    //endregion ##################### HeartRateService的回调 #####################

    //region ##################### BLEDialog相关 #####################

    //ScannerFragment的两个回调方法
    @Override
    public void onDeviceSelected(BluetoothDevice device, String name) {
        Logger.i("TT", "onDeviceSelected(),连接蓝牙，存下连接的蓝牙设备标示");
        if (device == null) return;
        if (!dataChannelIsWatch && !dataChannelIsEarSet) {
            gattCheckByProgram(false);
        }
        if (!TextUtils.isEmpty(name)) {
            if (name.contains("IRON CLOUD")) {
                showUseTip(getResources().getString(R.string.to_bind_tip), getResources().getString(R.string.to_bind_button), true);
            } else if (name.contains("H10") ||
                    name.contains("ROC HR") ||
                    name.contains("ROC Model")) {
                if (heartRateService != null) {
                    heartRateService.setDevice(device);
                    if (heartRateService.getBleManager() != null) {
                        heartRateService.getBleManager().disconnect();
                        heartRateService.getBleManager().connect(device);
                    }
                }
                Logger.i(Logger.DEBUG_TAG, device.getAddress());
            } else {
                showUseTip(getResources().getString(R.string.to_re_select), getResources().getString(R.string.update_ok), false);
            }
        } else {
            showUseTip(getResources().getString(R.string.to_re_select), getResources().getString(R.string.update_ok), false);
        }

    }

    @Override
    public void onDialogCanceled() {
        Logger.i("TT", "onDialogCanceled()");
        if (!dataChannelIsWatch && !dataChannelIsEarSet) {
            gattCheckByProgram(false);
        }
    }


    private UUID getFilterUUID() {
        return HRSManager.HR_SERVICE_UUID;
    }

    /**
     * Shows the scanner fragment.
     *
     * @param filter the UUID filter used to filter out available devices. The fragment will always show all bonded devices as there is no information about their
     *               services
     * @see #getFilterUUID()
     */
    private void showDeviceScanningDialog(final UUID filter) {
        final ScannerFragment dialog = ScannerFragment.getInstance(filter);
        if (ftCanCommit) {
            dialog.show(getSupportFragmentManager(), "scan_fragment");
        }
    }


    //endregion ##################### BLEDialog相关 #####################

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.iv_showHeartRateIntroduce:
                Intent intent = new Intent(HeartRateActivity.this, RestHeartRateInfoActivity.class);
                startActivity(intent);
                break;
        }
    }

    /**
     * 显示使用提示窗口
     */
    private void showUseTip(String tipContent, String buttonText, boolean isToBindWatch) {
        if (tipDialog == null) {
            tipDialog = new Dialog(this, R.style.dialog);
        }
        View tipView = LayoutInflater.from(this).inflate(R.layout.static_heart_rate_tip_view, null);
        TextView tipTv = (TextView) tipView.findViewById(R.id.tip_content_tv);
        Button button = (Button) tipView.findViewById(R.id.confirm_btn);
        tipTv.setText(tipContent);
        button.setText(buttonText);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isToBindWatch) {
                    startActivity(new Intent(HeartRateActivity.this, EquipmentActivity.class));
                }
                tipDialog.dismiss();
            }
        });

        tipDialog.setCancelable(false);
        tipDialog.setCanceledOnTouchOutside(true);
        tipDialog.setContentView(tipView);
        tipDialog.show();
    }


//    /**
//     * 根据所检测的全部心率值计算静息心率值
//     * @param list
//     * @return -1表示检测失败
//     */
//    private int calculateRestHeartRate(List<Integer> list){
//        if(list.size()>10){
//            List<Integer> a = list.subList(list.size()-4,list.size());
//            List<Integer> b = list.subList(list.size()-8,list.size()-4);
//            int avg_a = 0;
//            int avg_b = 0;
//            for(int i =0; i<a.size();i++){
//                avg_a+=a.get(i);
//            }
//            avg_a = avg_a/a.size();
//            for(int i = 0;i<b.size();i++){
//                avg_b += b.get(i);
//            }
//            avg_b = avg_b/b.size();
//            if(avg_a != 0  && avg_b != 0){
//                double variance = 0; //方差1
//                double variance2 = 0;//方差2
//                for(int i=0;i<a.size();i++){
//                    variance += Math.pow((a.get(i) - avg_a),2);
//                    variance2 += Math.pow((b.get(i) - avg_b),2);
//                }
//                variance = variance / a.size();
//                variance2 = variance2 / b.size();
//                if(variance < 5.0 && variance2 <5.0 && (avg_a - avg_b) < 5.0){
//                    if(avg_b == 0){ // 以防全部值都为0的情况
//                        return -1;
//                    }
//                        return avg_b;
//                }
//            }
//        }
//        return -1;
//    }
//
//    /**
//     * 检测是否检测静息心率结束
//     * @return
//     */
//    private boolean setDetectFinish(){
//        int result = calculateRestHeartRate(list_heart_rate);
//        if(result != -1){
//            //结束
//            if(isDetecting) {
//                Logger.i(Logger.DEBUG_TAG,"setDetectFinish(),finish.result="+result);
//                isDetecting = false;
//                showCurrentHeartRate = false;
//                detectFinish(result);
//            }
//            return true;
//        }else{
//            //未结束
//            isDetecting = true;
//            return false;
//        }
//    }


    @Override
    protected void initWatchServiceFunction() {
        mWatchServiceFun = new WatchService.ServiceFunction() {

            @Override
            public void onDeviceConnected() {
                Logger.i(Logger.DEBUG_TAG, "HeartRateActivity watchService onDeviceConnected()");
                isWatchConnect = true;
            }

            @Override
            public void onDeviceReady() {
                Logger.i(Logger.DEBUG_TAG, "HeartRateActivity watchService onDeviceReady()");
                isWatchConnect = true;
                if (!dataChannelIsWatch && !dataChannelIsEarSet) {
                    if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                        BluetoothDevice device = mWatchService.getDevice();
                        if (device != null) {
                            heartRateService.setDevice(device);
                            if (heartRateService.getBleManager() != null) {
                                heartRateService.getBleManager().disconnect();
                                heartRateService.getBleManager().connect(device);
                            }
                        }
                    }
                }
            }

            @Override
            public void onDeviceDisconnected() {
                Logger.i(Logger.DEBUG_TAG, "HeartRateActivity watchService onDeviceDisconnected()");
                isWatchConnect = false;
                gattCheckByProgram(false);
            }

            @Override
            public void onResponse(int groupTag, final int cell, int iPos, final int result) {
                switch (groupTag) {
                    case WatchDataProtocol.UI_BLE_HR_REST://手表切换静息心率界面ui
                        if (WatchDataProtocol.PACKAGE_RESULT_SUCCESS == result) {
                            Logger.d(Logger.DEBUG_TAG, "手表切换静息心率界面ui成功");
                        } else if (7 == result) {

                        }

                        break;

//                    case WatchDataProtocol.TAG_GROUP_BIND:
////
//                        break;
//
//                    case WatchDataProtocol.TAG_GROUP_WEATHER://天气
//
//                        break;
                }
            }

            @Override
            public void onReceiveDataRefreshUi(int groupTag, final String dataJson) {
//                if (groupTag == WatchDataProtocol.TAG_GROUP_APP_OTHER_SETTINGS && dataJson != null) {
//
//                } else if (groupTag == WatchDataProtocol.TAG_GROUP_BIND && dataJson != null) {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//
//                        }
//                    });
//                }
            }
        };
    }

    @Override
    protected void onWatchServiceConnected() {
        Logger.i(Logger.DEBUG_TAG, "HeartRateActivity watchService onWatchServiceConnected()");
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            isWatchConnect = true;
        }

    }

    @Override
    protected void onWatchServiceDisconnected() {
        super.onWatchServiceDisconnected();
        if (!dataChannelIsEarSet) {
            isWatchConnect = false;
            gattCheckByProgram(false);
            detectFinish(0);
        }
    }

    /**
     * 手机主动请求手表切换心率检测界面的指令 WatchDataProtocol.TAG_GROUP_UI_SWITCH, WatchDataProtocol.UI_BLE_HR_MONITOR
     */
    private void sendSwitchWatchDetectHrUiCmd() {
        if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
            byte[] data = WatchFormatManager.getSwitchWatchDetectHrUiData();
            int tag = WatchFormatManager.generateTag(WatchDataProtocol.TAG_GROUP_UI_SWITCH, WatchDataProtocol.UI_BLE_HR_MONITOR);
            mWatchService.sendTotallyDataCmd(tag, data);
        } else {
            //   showAppMessage(R.string.activity_watch_ble_not_connect, AppMsg.STYLE_ALERT);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isWatchConnect && !dataChannelIsWatch && !dataChannelIsEarSet) {
            if (mWatchService != null && mWatchService.ifBLEFunctionOk()) {
                if (heartRateService != null) {
                    heartRateService.setDevice(mWatchService.getDevice());
                    if (heartRateService.getBleManager() != null) {
                        heartRateService.getBleManager().disconnect();
                        heartRateService.getBleManager().connect(mWatchService.getDevice());
                    }
                }
            }
        }
    }
}
