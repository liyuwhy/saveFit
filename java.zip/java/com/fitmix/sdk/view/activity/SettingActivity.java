package com.fitmix.sdk.view.activity;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.User;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.RunService;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

public class SettingActivity extends BaseActivity {


    private User user;

    private TextView tv_step_count;//后台计步设置的字样（打开、关闭）
    private SwitchCompat switch_message_push;//消息推送（打开、关闭）
    private ImageView btn_account_setting;//绑定的红点显示
    private ImageView btn_app_update_show;//app升级的红点显示

    /**
     * 是否由人为点击开关
     */
    private boolean toggleByMan = true;

    //region ======================================== Activity生命周期 ========================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_mine_viewpager_more);
        setPageName("SettingActivity");
        initToolbar();
        initViews();
    }


    @Override
    protected void onResume() {
        super.onResume();
        initData();//EditProfileActivity 更新信息后能及时刷新
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "SettingActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 2://邮箱或者手机账号登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录
                Login login = JsonHelper.getObject(result, Login.class);
                if (login != null) {
                    user = login.getUser();
                }
                setUserInfo();
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "MainActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        switch (requestId) {
        }
    }

    //endregion ======================================== Activity生命周期 ========================================

    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        // 个人信息
        btn_account_setting = (ImageView) findViewById(R.id.btn_account_setting_show);
        btn_app_update_show = (ImageView) findViewById(R.id.btn_app_update_show);

        // 后台计步
        tv_step_count = (TextView) findViewById(R.id.tv_stepcount);
        // 消息推送
        switch_message_push = (SwitchCompat) findViewById(R.id.switch_message_push);
        switch_message_push.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (toggleByMan) {
                    switch (buttonView.getId()) {
                        case R.id.switch_message_push://消息推送
                            SettingsHelper.putBoolean(Config.SETTING_MESSAGE_PUSH, isChecked);
                            FitmixUtil.applyMessagePush(isChecked);
                            break;
                    }
                }
            }
        });

    }

    /**
     * 更新一些没有进行网络访问的UI界面
     */
    public void updatePartlyInfo() {
        // 后台计步
        boolean daemonStepCounter = SettingsHelper.getBoolean(Config.SETTING_DAEMON_STEP_COUNTER, true);
        if (tv_step_count != null)
            tv_step_count.setText(daemonStepCounter ? R.string.open : R.string.close);

        // 消息推送
        boolean messagePush = SettingsHelper.getBoolean(Config.SETTING_MESSAGE_PUSH, true);
        toggleByMan = false;
        if (switch_message_push != null)
            switch_message_push.setChecked(messagePush);
        toggleByMan = true;
    }

    private void initData() {
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (!TextUtils.isEmpty(email) || !TextUtils.isEmpty(password)) {
                int requestId = UserDataManager.getInstance().emailLogin(email, password);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                Logger.i(Logger.DEBUG_TAG, "openid:" + openid + " tokenId:" + tokenId);
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        }

        updatePartlyInfo();
    }

    //region ############################# 我的设置 #############################

    /**
     * 设置用户信息,总的跑步记录
     */
    private void setUserInfo() {
        if (user != null) {
            //设置账户设置红点
            setAccountMessageShow(getShowAccountMessage());
            //设置app升级提示红点
            setUpdateMessageShow(getShowAppUpdate());
        }
    }

    /**
     * @return 显示app升级提示红点
     */
    private boolean getShowAppUpdate() {
        boolean showAppUpdate = false;
        int newVersion = SettingsHelper.getInt(Config.SETTING_NEW_VERSION, -1);
        int appVersion = ApiUtils.getApkVersionCode();
        if (appVersion < newVersion) {
            boolean isClickAboutAs = SettingsHelper.getBoolean(Config.SETTING_VERSION_UPDATE, false);
            int ignoreVersion = SettingsHelper.getInt(Config.SETTING_IGNORE_VERSION, -1);
            if (ignoreVersion < newVersion && !isClickAboutAs) {
                showAppUpdate = true;
            }
        }
        return showAppUpdate;
    }

    /**
     * @return 是否显示账号设置红点
     */
    private boolean getShowAccountMessage() {
        return !SettingsHelper.getBoolean(Config.SETTING_BIND_MOBILE, false)
                && TextUtils.isEmpty(SettingsHelper.getString(Config.SETTING_USER_MOBILE, ""));
    }

    /**
     * 设置升级提醒
     *
     * @param isShowRed 是否显示红点
     */
    public void setUpdateMessageShow(boolean isShowRed) {
        if (btn_app_update_show == null) return;
        if (isShowRed) {
            btn_app_update_show.setVisibility(View.VISIBLE);
        } else {
            btn_app_update_show.setVisibility(View.GONE);
        }
    }

    /**
     * 设置账户设置的红点显示
     *
     * @param isShowRed 是否显示红点
     */
    public void setAccountMessageShow(boolean isShowRed) {
        if (btn_account_setting == null) return;
        if (isShowRed) {
            btn_account_setting.setVisibility(View.VISIBLE);
        } else {
            btn_account_setting.setVisibility(View.GONE);
        }
    }


    //endregion ############################# 我的设置 #############################

    //region ================================ 启动其它Activity ================================

    /**
     * 启动个人信息设置界面
     */
    private void startEditProfileActivity() {
        if (user != null) {
            Intent intent = new Intent();
            intent.setClass(SettingActivity.this, EditProfileActivity.class);
            Bundle bundle = new Bundle();
            String userString = JsonHelper.createJsonString(user);
            bundle.putString("user", userString);
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }

    /**
     * 启动账号管理界面
     */
    private void startAccountSetActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, AccountSetActivity.class);
        startActivity(intent);
    }

    /**
     * 启动微信排名界面
     */
    private void startWeChatRankActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, WeChatRankActivity.class);
        startActivity(intent);
    }

    /**
     * 启动缓存管理界面
     */
    private void startCacheManagerActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, CacheManagerActivity.class);
        startActivity(intent);
    }

    /**
     * 启动后台计步设置界面
     */
    private void startSettingStepActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, SettingStepActivity.class);
        startActivity(intent);
    }

    /**
     * 启动检测传感器界面
     */
    private void startCheckSensorActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, CheckSensorActivity.class);
        startActivity(intent);
    }

    /**
     * 启动关于我们界面
     */
    private void startAboutUsActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, AboutUsActivity.class);
        startActivity(intent);
    }

    /**
     * 启动常见问题界面
     */
    private void startFaqActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, FaqActivity.class);
        startActivity(intent);
    }

    /**
     * 进入同步到QQ运动的界面
     */
    private void startSyncQQActivity() {
        Intent intent = new Intent();
        intent.setClass(SettingActivity.this, SyncToQQActivity.class);
        startActivity(intent);
    }


    //endregion ================================ 启动其它Activity ================================

    public void doClick(View v) {
        switch (v.getId()) {

            case R.id.btn_login_status://设置个人信息
                startEditProfileActivity();
                break;
            case R.id.btn_account_setting://设置账户信息
                startAccountSetActivity();
                break;

            case R.id.btn_weixin_rank://我的微信排名
                startWeChatRankActivity();
                break;

            case R.id.btn_clear_cache://清除缓存
                startCacheManagerActivity();
                break;

            case R.id.btn_stepcount://后台计步
                startSettingStepActivity();
                break;
            case R.id.btn_checksensor://检测传感器
                startCheckSensorActivity();
                break;
            case R.id.btn_about_us://关于我们
                startAboutUsActivity();
                break;

            case R.id.btn_faq://常见问题
                startFaqActivity();
                break;

            case R.id.sync_to_qq_health://获取QQ的token
                startSyncQQActivity();
                break;

            case R.id.btn_login_out://退出登录
                showLogoutDialog(false);
                break;
        }
    }

    /**
     * 显示退出登录对话框
     *
     * @param forceLogout 是否强制重新登录,true:是,false:否
     */
    private void showLogoutDialog(boolean forceLogout) {
        if (forceLogout) {
            new MaterialDialog.Builder(this)
                    .title(R.string.logout)
                    .content(R.string.fm_mine_more_force_logout_tip)
                    .positiveText(R.string.ok)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE://注销登录
                                    logout();
                                    break;
                            }
                        }
                    }).show();
        } else {
            new MaterialDialog.Builder(this)
                    .title(R.string.logout)
                    .content(R.string.fm_mine_more_logout_tip)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE://注销登录
                                    logout();
                                    break;
                                case NEGATIVE:
                                    break;
                            }
                        }
                    }).show();
        }
    }

    /**
     * 退出登录
     */
    private void logout() {
        ThreadManager.executeOnSubThread1(new Runnable() {
            @Override
            public void run() {
                //5.重置正在传输固件的版本，重置正在发送的固件版本进度及升级按钮选择状态
                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION,0);
                SettingsHelper.putString(Config.SP_KEY_WATCH_FIRM_UPGRADE, "");
                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_NEWEST, 0);
                SettingsHelper.putInt(Config.SP_KEY_WATCH_FIRM_IS_UPDATING_VERSION_PROGRESS,0);
                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_FORCE,false);
                SettingsHelper.putBoolean(Config.SP_KEY_WATCH_FIRM_UPDATE_SELECT,false);
                SettingsHelper.putString(Config.LAST_WATCH_FRESH_WEATHER_TIME,"");
                stopStepCount();
                SettingsHelper.putString(Config.SETTING_WATCH_INFO, "");//清除已配对的手表信息
                //1.重新设置Uid,登录类型
                UserDataManager.setUid(Config.ANONYMOUS_UID);
                PrefsHelper.with(SettingActivity.this, Config.PREFS_USER).writeInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
                //2.清除三方登录openid,access token
                AccessTokenKeeper.clear(SettingActivity.this);
                //3.清除数据请求表
                MixApp.getDaoSession(SettingActivity.this).getDataReqStatusDao().deleteAll();
                //4.启动登录界面
                startLoginActivity();
            }
        });


    }

    /**
     * 启动登录界面
     */
    public void startLoginActivity() {
        Intent intent = new Intent(SettingActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    /**
     * 停止后台今日计步
     */
    private void stopStepCount() {
        Intent i = new Intent(this, RunService.class);
        stopService(i);
    }


}
