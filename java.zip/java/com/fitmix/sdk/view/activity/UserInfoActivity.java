package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.fresco.FrescoHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.RulerView;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

import java.io.File;

import static com.fitmix.sdk.view.activity.EditProfileActivity.USER_AVATAR_HEIGHT;
import static com.fitmix.sdk.view.activity.EditProfileActivity.USER_AVATAR_WIDTH;

/**
 * 用户信息设置界面
 * <br/>
 * 新注册用户或者用户身高体重等信息为空时,登录成功后需要立刻设置这些信息
 */

public class UserInfoActivity extends BaseActivity implements RulerView.OnValueChangeListener, RadioGroup.OnCheckedChangeListener {

    private View layout_first;
    private View layout_second;
    private View layout_third;
    private View layout_four;
    private View layout_five;

    private RadioGroup rg_gender;

    private TextView tv_welcome_tip2;
    private TextView tv_welcome_tip3;
    private TextView tv_age;
    private TextView tv_height;
    private TextView tv_weight;

    private RulerView select_age;
    private RulerView select_height;
    private RulerView select_weight;

    private SimpleDraweeView img_user_avatar;
    private EditText txt_nickname;

    private int mGender;//性别 1:男 2:女
    private int mAge;
    private int mHeight;
    private int mWeight;
    private String mNickName;//昵称
    private String mAvatarUrl;//头像图片地址
    private String mSignature;//个性签名,如果没有,默认为"把握你节奏,跃动乐享动"

    private Uri mCropImageUri;

    private boolean selectByMan = true;//滑动选择是否人为设置

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        setPageName("UserInfoActivity");
        Intent intent = getIntent();
        if (intent != null) {
            mGender = intent.getIntExtra("gender", 0);
            mAge = intent.getIntExtra("age", Config.USER_DEFAULT_AGE);
            mHeight = intent.getIntExtra("height", Config.USER_DEFAULT_HEIGHT);
            mWeight = intent.getIntExtra("weight", Config.USER_DEFAULT_WEIGHT);
            mNickName = intent.getStringExtra("nickName");
            mAvatarUrl = intent.getStringExtra("avatar");
            mSignature = intent.getStringExtra("signature");
        }
        checkData();
        initViews();
    }

    private void checkData() {
        if (mAge < 6 || mAge > 100) {
            mAge = Config.USER_DEFAULT_AGE;
        }

        if (mHeight < 100 || mHeight > 220) {
            mHeight = Config.USER_DEFAULT_HEIGHT;
        }

        if (mWeight < 20 || mWeight > 125) {
            mWeight = Config.USER_DEFAULT_WEIGHT;
        }

        if (TextUtils.isEmpty(mSignature)) {
            mSignature = "把握你节奏,跃动乐享动";
        }
    }

    @Override
    protected void initViews() {
        layout_first = findViewById(R.id.layout_first);
        layout_second = findViewById(R.id.layout_second);
        layout_third = findViewById(R.id.layout_third);
        layout_four = findViewById(R.id.layout_four);
        layout_five = findViewById(R.id.layout_five);

        rg_gender = (RadioGroup) findViewById(R.id.rg_gender);
        rg_gender.setOnCheckedChangeListener(this);
        if (mGender == Config.GENDER_MALE) {
            rg_gender.check(R.id.radio_male);
        } else if (mGender == Config.GENDER_FEMALE) {
            rg_gender.check(R.id.radio_female);
        }
        tv_welcome_tip2 = (TextView) findViewById(R.id.tv_welcome_tip2);
        tv_welcome_tip3 = (TextView) findViewById(R.id.tv_welcome_tip3);
        tv_welcome_tip2.setText(Html.fromHtml(getString(R.string.activity_user_info_tip2)));
        tv_welcome_tip3.setText(Html.fromHtml(getString(R.string.activity_user_info_tip3)));

        tv_age = (TextView) findViewById(R.id.tv_age);
        tv_height = (TextView) findViewById(R.id.tv_height);
        tv_weight = (TextView) findViewById(R.id.tv_weight);
        setAgeText(mAge);
        setHeightText(mHeight);
        setWeightText(mWeight);

        select_age = (RulerView) findViewById(R.id.select_age);
        select_height = (RulerView) findViewById(R.id.select_height);
        select_weight = (RulerView) findViewById(R.id.select_weight);
        select_age.setOnValueChangeListener(this);
        select_height.setOnValueChangeListener(this);
        select_weight.setOnValueChangeListener(this);
        select_age.setValue(mAge, 6, 100, 1);//年龄范围 6 - 100岁
        select_height.setValue(mHeight, 100, 220, 1);//身高范围 100 - 220厘米
        select_weight.setValue(mWeight, 20, 125, 1);//体重范围 20 - 125千克

        img_user_avatar = (SimpleDraweeView) findViewById(R.id.img_user_avatar);


        txt_nickname = (EditText) findViewById(R.id.txt_nickname);
        txt_nickname.setText(mNickName);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        switch (requestId) {
            case Config.MODULE_USER + 7://修改个人信息
                hideLoadingDialog();
                setUserDataUseLess();//上传成功了,更改数据库个人信息的有效期为过期
                setResult(Activity.RESULT_OK);//设置结果为成功,返回mainActivity更新个人信息
                finish();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        //不处理
    }

    @Override
    public void onValueChange(View v, float value) {
        if (!selectByMan)
            return;
        switch (v.getId()) {
            case R.id.select_age:
                mAge = (int) value;
                setAgeText(mAge);
                break;

            case R.id.select_height:
                mHeight = (int) value;
                setHeightText(mHeight);
                break;

            case R.id.select_weight:
                mWeight = (int) value;
                setWeightText(mWeight);
                break;
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.radio_male:
                mGender = Config.GENDER_MALE;
                break;

            case R.id.radio_female:
                mGender = Config.GENDER_FEMALE;
                break;
        }
    }

    /**
     * 设置年龄文字
     */
    private void setAgeText(int age) {
        if (tv_age != null) {
            tv_age.setText(String.format(getString(R.string.activity_user_info_age_format), String.valueOf(age)));
        }
    }

    /**
     * 设置身高文字
     */
    private void setHeightText(int height) {
        if (tv_height != null) {
            tv_height.setText(String.format(getString(R.string.activity_user_info_height_format), String.valueOf(height)));
        }
    }

    /**
     * 设置体重文字
     */
    private void setWeightText(int weight) {
        if (tv_weight != null) {
            tv_weight.setText(String.format(getString(R.string.activity_user_info_weight_format), String.valueOf(weight)));
        }
    }

    /**
     * 显示指定布局
     *
     * @param index 布局编号,从0开始
     */
    private void showLayout(int index) {
        switch (index) {
            case 0:
                if (layout_second != null) {
                    layout_second.setVisibility(View.GONE);
                }
                showAnimation(layout_first);
                break;

            case 1:
                if (layout_first != null) {
                    layout_first.setVisibility(View.GONE);
                }
                if (layout_third != null) {
                    layout_third.setVisibility(View.GONE);
                }
                showAnimation(layout_second);
                break;

            case 2:
                if (layout_second != null) {
                    layout_second.setVisibility(View.GONE);
                }
                if (layout_four != null) {
                    layout_four.setVisibility(View.GONE);
                }
                showAnimation(layout_third);
                break;

            case 3:
                if (layout_third != null) {
                    layout_third.setVisibility(View.GONE);
                }
                showAnimation(layout_four);
                break;

            case 4:
                if (layout_four != null) {
                    layout_four.setVisibility(View.GONE);
                }
                showAnimation(layout_five);
                break;
        }

    }

    /**
     * 布局显示动画
     */
    private void showAnimation(View view) {
        if (view == null)
            return;
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0.0f);

        view.animate()
                .setDuration(300)
                .alpha(1.0f)
                .setListener(null);
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back_first:
                showLayout(0);
                break;

            case R.id.btn_back_second:
                showLayout(1);
                break;

            case R.id.btn_back_third:
                showLayout(2);
                break;

            case R.id.btn_start:
                showLayout(1);
                break;

            case R.id.btn_to_third:
                if (mGender != Config.GENDER_FEMALE && mGender != Config.GENDER_MALE) {
                    showAppMessage(R.string.activity_user_info_gender_select, AppMsg.STYLE_ALERT);
                    return;
                }
                showLayout(2);
                break;

            case R.id.btn_to_four:
                setUserAvatar();
                showLayout(3);
                break;

            case R.id.btn_to_five:
                mNickName = txt_nickname.getText().toString();
                if (TextUtils.isEmpty(mNickName)) {
                    showAppMessage(R.string.activity_user_info_name_empty, AppMsg.STYLE_ALERT);
                    return;
                }
                showLayout(4);
                break;

            case R.id.btn_done://完成用户信息输入
                sendModifyPersonInfoRequest();
                break;

            case R.id.img_user_avatar:
                CropImage.startPickImageActivity(this);
                break;
        }
    }

    private void setUserAvatar() {
        if (img_user_avatar == null)
            return;
        if (TextUtils.isEmpty(mAvatarUrl)) {//默认头像
            if (mGender == Config.GENDER_FEMALE) {
                img_user_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.activity_user_info_female)).build());
            } else {
                img_user_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.activity_user_info_male)).build());
            }
        } else {
            int uid = UserDataManager.getUid();
            String localFile = FitmixUtil.getPhotoPath() + uid + "_avatar.jpg";
            if (FileUtils.isFileExist(localFile)) {//本地有图片,则从本地加载
                img_user_avatar.setImageURI(Uri.fromFile(new File(localFile)));
            } else {
                Fresco.getImagePipeline().evictFromCache(Uri.parse(mAvatarUrl));
                img_user_avatar.setImageURI(Uri.parse(mAvatarUrl));
                FrescoHelper.saveImage2Local(MixApp.getContext(), mAvatarUrl, localFile);
            }
        }
    }


    /**
     * 发送修改个人信息请求
     */
    private void sendModifyPersonInfoRequest() {
        int uid = UserDataManager.getUid();
        String avatar = FitmixUtil.getPhotoPath() + uid + "_avatar.jpg";
        int requestId = UserDataManager.getInstance().updateUserInfo(uid, mNickName,
                mGender, mAge, mHeight, mWeight, Config.UNIT_TYPE_CHINESE, mSignature,
                avatar, "file");
        registerDataReqStatusListener(requestId);

        showLoadingDialog(R.string.busying, 1000);
    }


    /**
     * 启动图片剪裁界面
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(1, 1)
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    if (imageUri == null)
                        break;
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;

            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (bitmap != null) {//use bitmap
                        ((ImageView) (img_user_avatar)).setImageBitmap(bitmap);
                        String localFile = FitmixUtil.getPhotoPath() + UserDataManager.getUid() + "_avatar.jpg";
                        ImageHelper.adjustPhotoToFitSize(bitmap, USER_AVATAR_WIDTH, USER_AVATAR_HEIGHT, localFile);
                        if (!TextUtils.isEmpty(mAvatarUrl)) {//重置fresco缓存
                            Fresco.getImagePipeline().evictFromCache(Uri.parse(mAvatarUrl));
                            Fresco.getImagePipeline().evictFromCache(Uri.fromFile(new File(localFile)));
                        }
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

            default:
                super.onActivityResult(requestCode, resultCode, data);
                break;
        }
    }

}
