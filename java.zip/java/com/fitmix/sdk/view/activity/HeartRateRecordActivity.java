package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateInfo;
import com.fitmix.sdk.bean.HeartRateTime;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.AddRestHeartRateRecord;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.HeartRateGraphBean;
import com.fitmix.sdk.model.api.bean.RestHeartRateList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.RestHeartRate;
import com.fitmix.sdk.model.database.RestHeartRateHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.HeartRateRecordAdapter;
import com.fitmix.sdk.view.widget.BesselLineChart;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import de.greenrobot.dao.async.AsyncOperation;
import de.greenrobot.dao.async.AsyncOperationListener;

/**
 * 静息心率记录界面
 */
public class HeartRateRecordActivity extends BaseActivity {
    private TextView btn_sync_heart_rate_record;
    private ListView lv_heart_rate_record;
    private BesselLineChart linechart_stride;
    private HeartRateRecordAdapter adapter;

    /**
     * 全部静息心率数据
     */
    private List<HeartRateGraphBean> hrGraphBeanList;

    private List<HeartRateTime> monthList;//收集月与年的集合，降序，0为距离现在最近的。
    private int monthIndex = -1;//当前显示的monthList的position
    private boolean noDataToRefresh;//第一次加载数据时直接从数据库调，如果数据库没有数据，则设为true，在网络请求的结果中在刷新

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_record);
        setPageName("HeartRateRecordActivity");
        initToolbar();
        initViews();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        btn_sync_heart_rate_record = (TextView) findViewById(R.id.btn_sync_heart_rate_record);
        btn_sync_heart_rate_record.setOnClickListener(clickListener);
        lv_heart_rate_record = (ListView) findViewById(R.id.lv_heart_rate_record);

        linechart_stride = (BesselLineChart) findViewById(R.id.linechart_stride);
        linechart_stride.setGestureDetector(onGestureListener);

        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        emptyView.setText(getString(R.string.activity_heart_rate_empty_history_record));
        lv_heart_rate_record.setEmptyView(emptyView);
        adapter = new HeartRateRecordAdapter(this);

        lv_heart_rate_record.setAdapter(adapter);
        hrGraphBeanList = new ArrayList<>();
        monthList = new ArrayList<>();

        requestAllRestHeartRateHistory();
        refreshLogList(true);
    }

    /**
     * 请求获取所有静息心率记录
     */
    public void requestAllRestHeartRateHistory() {
        int requestId = SportDataManager.getInstance().getAllRestHeartRateHistory(UserDataManager.getUid());
        registerDataReqStatusListener(requestId);
    }

    public HeartRateRecordAdapter getAdapter() {
        if (adapter == null) adapter = new HeartRateRecordAdapter(this);
        return adapter;
    }

    public void setAdapter(HeartRateRecordAdapter adapter) {
        this.adapter = adapter;
    }


    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_sync_heart_rate_record:
                    syncRestHeartRateRecord();
                    break;

            }
        }
    };

    /**
     * 绘制指定年、月的静息心率图
     *
     * @param list
     * @param month 月份
     */
    private void drawRestHeartRateGraph(List<HeartRateGraphBean> list, int year, int month) {
        if (list == null || list.size() <= 0) {
            if (linechart_stride != null) {
                linechart_stride.clear();
            }
            return;
        }
        if (linechart_stride == null)
            return;

        //region ===================================== 需要展示数据筛选 =====================================

        list = getHRListByMonth(list, year, month);
        Collections.reverse(list);

        //endregion ===================================== 需要展示数据筛选 =====================================\

        List<BesselLineChart.Point> dataList = new ArrayList<>();
        for (HeartRateGraphBean heartRateGraphBean : list) {
            BesselLineChart.Point point = new BesselLineChart.Point(heartRateGraphBean.getDay(), heartRateGraphBean.getRestHR());
            dataList.add(point);
        }

        linechart_stride.clear();
        linechart_stride.setXUnit(getResources().getString(R.string.activity_graph_date_xunit));
        linechart_stride.setYUnit(getResources().getString(R.string.activity_hr_record_graph_info));
        linechart_stride.setTextCenter(String.format(getResources().getString(R.string.heart_rate_month), String.valueOf(month)));
        linechart_stride.setIsHeartRateMode(true);
        linechart_stride.setDataList(dataList, 0, true);
        linechart_stride.setXLength(getMonthLastDay(year, month));
        linechart_stride.setXSpace(5);
        linechart_stride.setColor(0xFFFF5819);
        linechart_stride.startLineAnimator();

    }

    GestureDetector.OnGestureListener onGestureListener = new GestureDetector.OnGestureListener() {
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float x = e2.getX() - e1.getX();

            if (x > 0) {//上个月
                if (monthIndex != -1 && monthIndex + 1 < monthList.size()) {
                    HeartRateTime time = monthList.get(++monthIndex);
                    drawRestHeartRateGraph(hrGraphBeanList, time.getYear(), time.getMonth());//绘制静息静息图表
                } else {
                    Toast.makeText(HeartRateRecordActivity.this, getResources().getString(R.string.heart_rate_empty_record_last_month), Toast.LENGTH_SHORT).show();
                }

            } else if (x < 0) {//下个月
                if (monthIndex != -1 && monthIndex - 1 >= 0) {
                    HeartRateTime time = monthList.get(--monthIndex);
                    drawRestHeartRateGraph(hrGraphBeanList, time.getYear(), time.getMonth());//绘制静息静息图表
                } else {
                    Toast.makeText(HeartRateRecordActivity.this, getResources().getString(R.string.heart_rate_empty_record_next_month), Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        }


        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public void onShowPress(MotionEvent e) {
            e.getEventTime();
        }


        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            return false;
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            return false;
        }

        @Override
        public void onLongPress(MotionEvent e) {
            e.getDownTime();
        }
    };

    /**
     * 得到指定月的天数
     */
    public static int getMonthLastDay(int year, int month) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DATE, 1);//把日期设置为当月第一天
        calendar.roll(Calendar.DATE, -1);//日期回滚一天，也就是最后一天
        return calendar.get(Calendar.DATE);
    }


    /**
     * 同步未与服务器同步的记录
     */
    private void syncRestHeartRateRecord() {
        int uid = UserDataManager.getUid();
        RestHeartRateHelper.getInstance().asyncUnSyncHeartRateRecords(this, uid, new AsyncOperationListener() {
            @Override
            public void onAsyncOperationCompleted(AsyncOperation operation) {
                RestHeartRate records = (RestHeartRate) operation.getResult();
                if (records == null) {
                    refreshLogList(false);
                    return;
                }
                int requestId = SportDataManager.getInstance().uploadRestHeartRate(UserDataManager.getUid(),
                        records.getHeart_rate_record(), records.getId_start_time());
                registerDataReqStatusListener(requestId);
            }
        });
        setSyncButtonVisible(View.GONE);//隐藏记录同步按钮
    }


    /**
     * 读取数据库中记录，刷新心率记录
     */
    private void refreshLogList(boolean isFirstRefresh) {
        if (isFirstRefresh) {
            showLoadingDialog(R.string.activity_heart_rate_record_loading, 1000);
        }
        int uid = UserDataManager.getUid();

        List<RestHeartRate> ll = RestHeartRateHelper.getInstance().getRestHeartRateList(uid);
        if (ll.size() <= 0) {
            if (isFirstRefresh) {
                hideDialog();
            }
            noDataToRefresh = true;
            return;
        }

        //list必须要顺序颠倒获取到数据集
        final List<HeartRateInfo> list = new ArrayList<>();

        Calendar c = Calendar.getInstance();
        RestHeartRate start_rhr = ll.get(0);
        if (start_rhr == null) {
            return;
        }
        c.setTimeInMillis(start_rhr.getId_start_time());
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);
        int day_all = year * 365 + month * 30 + day;

        int perDayRecordHRSum = 0;   // 一天的心率记录心率总和
        int sameDaySize = 0;//一天的心率记录总心率(因为存在一天当中有多条记录的情况)

        for (int i = 0; i <= ll.size(); i++) {
            if (i == ll.size()) {//之所以遍历多一遍的原因是因为获取贝赛尔曲线图数据源需要遍历多一遍，而正常listView的数据源不需要
                if (isFirstRefresh) {
                    monthList.add(new HeartRateTime(year, month));
                    hrGraphBeanList.add(new HeartRateGraphBean(perDayRecordHRSum / sameDaySize, year, month, day));
                    continue;
                } else {
                    continue;
                }
            }

            RestHeartRate rhr = ll.get(i);

            //region ===================================== listView数据源 =====================================

            list.add(new HeartRateInfo(rhr.getUid(), rhr.getHeart_rate_record(),
                    rhr.getId_start_time(), rhr.getType(), rhr.getId_start_time(), rhr.getUploaded()));

            //endregion ===================================== listView数据源 =====================================

            //region ===================================== 静息心率贝赛尔曲线数据源 =====================================
            if (isFirstRefresh) {
                c.setTimeInMillis(rhr.getId_start_time());

                if (year == c.get(Calendar.YEAR) && month == c.get(Calendar.MONTH) + 1) {//月份集合数据
                    if (i + 1 == ll.size()) {//最后一个
                        monthList.add(new HeartRateTime(year, month));
                    }
                } else {
                    monthList.add(new HeartRateTime(year, month));//month不同的话，天一定不同，month的改变放在天不同的情况下执行
                }
                if (c.get(Calendar.YEAR) * 365 + (c.get(Calendar.MONTH) + 1) * 30 + c.get(Calendar.DAY_OF_MONTH) == day_all) { //天集合数据
                    perDayRecordHRSum += rhr.getHeart_rate_record();
                    sameDaySize++;

                    if (i + 1 == ll.size()) {//最后一个
                        hrGraphBeanList.add(new HeartRateGraphBean(perDayRecordHRSum / sameDaySize, year, month, day));
                    }
                } else { //不同天
                    hrGraphBeanList.add(new HeartRateGraphBean(perDayRecordHRSum / sameDaySize, year, month, day));
                    perDayRecordHRSum = rhr.getHeart_rate_record();
                    sameDaySize = 1;

                    day_all = c.get(Calendar.YEAR) * 365 + (c.get(Calendar.MONTH) + 1) * 30 + c.get(Calendar.DAY_OF_MONTH);
                    year = c.get(Calendar.YEAR);
                    month = c.get(Calendar.MONTH) + 1;
                    day = c.get(Calendar.DAY_OF_MONTH);
                }
            }
            //endregion ===================================== 静息心率贝赛尔曲线数据源 =====================================

        }

        if ((list == null) || (list.size() == 0)) {
            if (isFirstRefresh) {
                hideDialog();
            }
            noDataToRefresh = true;
            return;
        }

        //region ===================================== 静息心率贝赛尔曲线展示数据 =====================================
        if (isFirstRefresh && hrGraphBeanList.size() > 0 && monthList.size() > 0) {
            monthIndex = 0;
            HeartRateTime time = monthList.get(monthIndex);
            drawRestHeartRateGraph(hrGraphBeanList, time.getYear(), time.getMonth());//绘制静息静息图表
        }
        //endregion ===================================== 静息心率贝赛尔曲线展示数据 =====================================


        //region ===================================== ListView展示数据，同步未同步数据 =====================================
        runOnUiThread(new Runnable() {//切换到UI线程
            @Override
            public void run() {
                hideLoadingDialog();
                if (!recordSynced(list)) {//如果有未同步的数据,在listView顶部显示同步按钮
                    setSyncButtonVisible(View.VISIBLE);
                }
                addMonthItem(list, Calendar.getInstance());//listView数据源增加月份item
                getAdapter().setList(list);
            }
        });
        //endregion ================================= ListView展示数据，同步未同步数据 =====================================

    }

    /**
     * 将显示出来的加载Dialog隐藏
     */
    private void hideDialog() {
        //取消loadingDialog，初始化listAdapter
        runOnUiThread(new Runnable() {//切换到UI线程
            @Override
            public void run() {
                hideLoadingDialog();
                getAdapter().setList(null);
            }
        });
    }

    /**
     * 列表数据增加月平均项
     *
     * @param list
     * @param c
     */
    private void addMonthItem(List<HeartRateInfo> list, Calendar c) {
        int oldTime = 0;
        int tempTime;
        HeartRateInfo log;
        Calendar temp = Calendar.getInstance();
        for (int i = 0; i < list.size(); i++) {//设置月份总距离
            c.setTimeInMillis(list.get(i).getStartTime());
            tempTime = c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH) + 1;
            if (oldTime != tempTime) {
                oldTime = tempTime;
                log = new HeartRateInfo();//新增一条记录作为月份总记录
                log.setUid(-1);//区分其它记录
                log.setStartTime(list.get(i).getStartTime());
                temp.setTimeInMillis(log.getStartTime());
                log.setRecord(getAvgHRByMonth(getHRListByMonth(hrGraphBeanList, temp.get(Calendar.YEAR), temp.get(Calendar.MONTH) + 1)));
                list.add(i, log);
                i++;
            }
        }
    }

    /**
     * 截取指定年月的无重复天数的心率集合
     *
     * @param list  无重复天数的心率集合
     * @param year
     * @param month
     * @return
     */
    private List<HeartRateGraphBean> getHRListByMonth(List<HeartRateGraphBean> list, int year, int month) {
        if (list == null || list.size() == 0) {
            return null;
        }
        //截取指定月的记录
        int startMonthIndex = -1;
        int endMonthIndex = -1;

        for (int i = 0; i < list.size(); i++) {
            HeartRateGraphBean bean = list.get(i);
            if (year == bean.getYear() && month == bean.getMonth() && startMonthIndex == -1) {
                startMonthIndex = i;
                continue;
            }
            if (year == bean.getYear() && month == bean.getMonth() && startMonthIndex != -1) {
                endMonthIndex = i;
                continue;
            }
            if ((year != bean.getYear() || month != bean.getMonth()) && startMonthIndex != -1) {
                break;
            }
        }
        if (startMonthIndex != -1 && endMonthIndex != -1) {
            return list.subList(startMonthIndex, endMonthIndex + 1);
        } else if (startMonthIndex != -1 && endMonthIndex == -1) {
            return list.subList(startMonthIndex, startMonthIndex + 1);
        }
        return list;
    }

    private int getAvgHRByMonth(List<HeartRateGraphBean> list) {
        if (list == null || list.size() == 0) {
            return 0;
        }
        int sum = 0;
        for (int i = 0; i < list.size(); i++) {
            sum += list.get(i).getRestHR();
        }
        return sum / list.size();
    }

    /**
     * 设置同步跑步记录按钮的可见性
     *
     * @param visibility view的可见性,View.GONE,View.VISIBLE等
     */
    public void setSyncButtonVisible(int visibility) {
        if (btn_sync_heart_rate_record != null) {
            btn_sync_heart_rate_record.setVisibility(visibility);
        }
    }

    /**
     * 判断跑步记录是否全部与服务器同步
     *
     * @param list 跑步记录列表
     * @return false:表示有未同步的数据
     */
    private boolean recordSynced(List<HeartRateInfo> list) {
        if (list == null || list.size() == 0) {
            return true;
        }
        for (HeartRateInfo log : list) {
            if (log.getUid() > 0 && log.getUploaded() == 0) {//月总记录的数据uid是小于0的,不用同步在此过滤掉.
                return false;
            }
        }
        return true;
    }

    /**
     * 对比全部静息心率记录列表，选择性存储数据库
     *
     * @param result 网络请求返回的结果
     */
    private void setRestHeartRateList(String result) {
        RestHeartRateList recordList = JsonHelper.getObject(result, RestHeartRateList.class);
        if (recordList != null) {
            //2.更新心率记录数据库表
            boolean success = RestHeartRateHelper.getInstance().ansyAddOrUpdateRestHeartList(recordList.getList(), 1);//网络获取来的数据均为同步成功的
            //3.从数据请求状态表中,清除还在缓存有效期内的请求结果
            if (success) {
                UserDataManager.getInstance().emptyDataReqResult(SportDataManager.getInstance().generateRequestId(16));
            }
        }
    }

    /**
     * 刷新跑步记录集合同步状态
     */
    private void updateRunLogList(String result) {
        AddRestHeartRateRecord addRecord = JsonHelper.getObject(result, AddRestHeartRateRecord.class);
        RestHeartRateHelper.getInstance().updateRestHeartRateRecord(this, UserDataManager.getUid(), addRecord.getDetectTime());
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_SPORT + 16://获取全部的静息心率记录
                setRestHeartRateList(result);
                if (noDataToRefresh) {
                    refreshLogList(true);
                    noDataToRefresh = false;
                }
                break;
            case Config.MODULE_SPORT + 15://上传静息心率记录
                updateRunLogList(result);
                syncRestHeartRateRecord();
                break;
        }

    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        Logger.e(Logger.DEBUG_TAG, "MainActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_SPORT + 16://获取全部的静息心率记录
//                    refreshLogList(true);
                    break;
                case Config.MODULE_SPORT + 15://上传静息心率几率
//                    refreshLogList(true);
                    break;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        hrGraphBeanList = null;
        monthList = null;
        onGestureListener = null;
    }
}
