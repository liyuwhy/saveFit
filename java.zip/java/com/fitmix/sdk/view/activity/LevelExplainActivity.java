package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.LevelEntity;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.UserRunStatistics;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.LevelAdapter;
import com.fitmix.sdk.view.widget.BounceListView;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

import java.util.ArrayList;

/**
 * 跑者等级说明界面
 */
public class LevelExplainActivity extends BaseActivity {

    private TextView tv_valid_distance;
    private BounceListView list_level;
    private LevelAdapter adapter;
    private ArrayList<LevelEntity> levelEntities;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_explain);
        setPageName("LevelExplainActivity");
        initToolbar();
        initViews();
        initData();

    }

    private void initData() {
        //1.加载个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录,或者手机号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (!TextUtils.isEmpty(email) || !TextUtils.isEmpty(password)) {
                int requestId = UserDataManager.getInstance().emailLogin(email, password, true);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid, true);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid, true);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid, true);
                registerDataReqStatusListener(requestId);
            }
        }

    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        tv_valid_distance = (TextView) findViewById(R.id.tv_valid_distance);

        list_level = (BounceListView) findViewById(R.id.list_level);
        levelEntities = new ArrayList<>();
        adapter = new LevelAdapter(this, levelEntities);
        list_level.setAdapter(adapter);

        String language = ApiUtils.getLanguage();
        if (language == null || language.endsWith("zh")) {//中文
            levelEntities.add(new LevelEntity("初级跑者", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_3, "合格总里程>0公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_2, "10公里≤ 合格总里程 <20公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_1, "20公里≤ 合格总里程 <30公里"));

            levelEntities.add(new LevelEntity("中级跑者", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_3, "30公里≤ 合格总里程 <50公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_2, "50公里≤ 合格总里程 <70公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_1, "70公里≤ 合格总里程 <100公里"));

            levelEntities.add(new LevelEntity("高级跑者", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_3, "100公里≤ 合格总里程 <200公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_2, "200公里≤ 合格总里程 <300公里"));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_1, "300公里≤ 合格总里程 <500公里"));

            levelEntities.add(new LevelEntity("顶级跑者", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_3, "500公里≤ 合格总里程 <1000公里\n且10公里≤45分钟"));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_2, "1000公里≤ 合格总里程 <1500公里\n且10公里≤40分钟"));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_1, "1500公里≤ 合格总里程 <2000公里\n且10公里≤35分钟"));

            levelEntities.add(new LevelEntity("神级跑者", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_3, "2000公里≤ 合格总里程 <3000公里\n且半马≤1小时40分钟"));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_2, "3000公里≤ 合格总里程 <5000公里\n且半马≤1小时35分钟"));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_1, "5000公里≤ 合格总里程\n且半马≤1小时30分钟"));
        } else {//英文
            levelEntities.add(new LevelEntity("Primary Runner", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_3, "RM > 0km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_2, "10km≤ RM < 20km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank5_1, "20km≤ RM < 30km"));

            levelEntities.add(new LevelEntity("Intermediate Runner", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_3, "30km ≤ RM < 50km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_2, "50km ≤ RM < 70km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank4_1, "70km ≤ RM < 100km"));

            levelEntities.add(new LevelEntity("Advanced Runner", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_3, "100km ≤ RM < 200km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_2, "200km ≤ RM < 300km"));
            levelEntities.add(new LevelEntity("", R.drawable.rank3_1, "300km ≤ RM < 500km"));

            levelEntities.add(new LevelEntity("Top Runner", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_3, "500km ≤ RM < 1000km\nand 10km ≤ 45minutes"));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_2, "1000km ≤ RM < 1500km\nand 10km ≤ 40minutes"));
            levelEntities.add(new LevelEntity("", R.drawable.rank2_1, "1500km ≤ RM < 2000km\nand 10km ≤ 35minutes"));

            levelEntities.add(new LevelEntity("Master Runner", 0, ""));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_3, "2000km ≤ RM < 3000km\nand half-marathon ≤ 1hour 40minutes"));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_2, "3000km ≤ RM < 5000km\nand half-marathon ≤ 1hour 35minutes"));
            levelEntities.add(new LevelEntity("", R.drawable.rank1_1, "5000km ≤ RM\nand half-marathon ≤ 1hour 30minutes"));
        }
        adapter.notifyDataSetChanged();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "LevelExplainActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 2://邮箱或者手机账号登录
            case Config.MODULE_USER + 3://QQ授权登录
            case Config.MODULE_USER + 4://新浪微博授权登录
            case Config.MODULE_USER + 5://微信授权登录
                setUserInfo(result);
                break;
        }
    }

    /**
     * 设置用户总的有效跑步距离
     */
    private void setUserInfo(String result) {
        Login login = JsonHelper.getObject(result, Login.class);
        if (login != null) {
            UserRunStatistics userRunStatistics = login.getUserRunStatistics();
            if (userRunStatistics != null) {
                String format1 = getString(R.string.activity_level_explain_valid_distance_format1);
                String format2 = getString(R.string.activity_level_explain_valid_distance_format2);
                int distance = userRunStatistics.getDistance() / 1000;
                if (tv_valid_distance != null) {
                    tv_valid_distance.setText(Html.fromHtml(format1 + "<font color=\"#FD8A22\">" + distance + "</font>" + format2));
                }

            }
        }
    }

}
