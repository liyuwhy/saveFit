package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.SeekBar;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.ActiveUser;
import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.model.api.bean.ActiveUserList;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.ClubActive;
import com.fitmix.sdk.model.api.bean.ClubDetail;
import com.fitmix.sdk.model.api.bean.ClubDynamicList;
import com.fitmix.sdk.model.api.bean.ClubMessageList;
import com.fitmix.sdk.model.api.bean.ClubNoticeList;
import com.fitmix.sdk.model.api.bean.ClubRankInfo;
import com.fitmix.sdk.model.api.bean.ClubRankList;
import com.fitmix.sdk.model.api.bean.ClubShareInfo;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.MessageHelper;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.ClubMemberRecyclerAdapter;
import com.fitmix.sdk.view.adapter.FragmentViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.bean.ClubMember;
import com.fitmix.sdk.view.bean.ClubMessage;
import com.fitmix.sdk.view.bean.ClubNotice;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.ClubMessageFragment;
import com.fitmix.sdk.view.fragment.ClubNewsFragment;
import com.fitmix.sdk.view.fragment.ClubNoticeFragment;
import com.fitmix.sdk.view.fragment.ClubRankFragment;
import com.fitmix.sdk.view.transition.ActivityTransition;
import com.fitmix.sdk.view.transition.ExitActivityTransition;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.NewVPIndicator;
import com.fitmix.sdk.view.widget.StickyTabLayout;
import com.fitmix.sdk.view.widget.recyclerview_decoration.SpacesItemDecoration;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class ClubDetailActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    private static final int ACTIVITY_CLUM_MEMBER_NEED_REFRESH = 1001;
    private static final int PAGE_CLUB_ACTIVITY = 0;
    private static final int PAGE_CLUB_NOTICE = 1;
    private static final int PAGE_CLUB_RANKING = 2;
    private static final int PAGE_CLUB_MESSAGE = 3;
    private static final int CLUB_TYPE_OPEN = 2;
    private StickyTabLayout stickTabLayout;
    private NewVPIndicator mIndicator;

    ///////////////////////内容///////////////////////
    private SimpleDraweeView img_club_badge;//俱乐部徽标
    private TextView tv_club_name;//俱乐部名称
    private TextView tv_club_description;//俱乐部描述
    private TextView tv_today_activation_left;//今日活跃度
    private SeekBar progress_today_activation;//进度条表示
//    private TextView tv_today_activation_right;//活跃度百分比

    private ClubMemberRecyclerAdapter rvAdapter;

    ///////////////////////菜单///////////////////////
//    private MenuItem leaveMessageMenu;//留言菜单,根据当前是否是留言板隐藏或显示
//    private MenuItem addNotice;//添加活动公告

    private int mTotalMembers;
    private int mActiveMembers;
    private int currentFragmentPage;

    //region ========================= 转场动画相关 =========================
    private SimpleDraweeView img_temp;//转场临时图标
    private ExitActivityTransition exitTransition;//退场动画

    //endregion ========================= 转场动画相关 =========================

    private ClubNewsFragment clubNewsFragment;
    private ClubNoticeFragment clubNoticeFragment;
    private ClubRankFragment clubRankFragment;
    private ClubMessageFragment clubMessageFragment;
    private int clubMessageIndex = 1;
    private int clubRankIndex = 1;
    private int clubNoticeIndex = 1;
    private int clubNewsIndex = 1;
    //    private int clubMembersIndex;
    private boolean bNeedRefreshFragment;
    private RecyclerView rv_club_member;
    private ViewPager viewpager_club_detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        setFragmentMode(true);
        super.onCreate(savedInstanceState);
        setPageName("ClubDetailActivity");
        setContentView(R.layout.activity_club_detail);

        bNeedRefreshFragment = false;
        initToolbar();
        initViews();

        Intent intent = getIntent();
        if (intent != null) {
            boolean cancelAnim = intent.getBooleanExtra("isFromXgNotify", false);
            if (cancelAnim) {
                stickTabLayout.setVisibility(View.VISIBLE);
                img_temp.setVisibility(View.GONE);
                img_club_badge.setVisibility(View.VISIBLE);
                if (stickTabLayout != null) {
                    stickTabLayout.clearAnimation();
                }

                int clubId = intent.getIntExtra("clubId", 0);
                int requestId = ClubDataManager.getInstance().findClub(clubId, false);
                registerDataReqStatusListener(requestId);
            } else {
                exitTransition = ActivityTransition
                        .with(intent)
                        .to(img_temp)
                        .start(savedInstanceState);
//            String title = intent.getStringExtra("clubName");
//            if (toolbar != null && !TextUtils.isEmpty(title)) {//设置界面标题为俱乐部名称
//               toolbar.setUiTitle(title);
//                setUiTitle(title);
//            }
                Animation show = new AlphaAnimation(0.0f, 1.0f);
                show.setDuration(300);
                show.setFillAfter(true);
                stickTabLayout.setVisibility(View.VISIBLE);
                if (show != null) {
                    stickTabLayout.startAnimation(show);
                }
                ThreadManager.getMainHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {//动画结束后,显示本来的布局,隐藏临时图标
                        img_temp.setVisibility(View.GONE);
                        img_club_badge.setVisibility(View.VISIBLE);
                        if (stickTabLayout != null) {
                            stickTabLayout.clearAnimation();
                        }
                    }
                }, 600);
            }
        } else {
            stickTabLayout.setVisibility(View.VISIBLE);
            img_temp.setVisibility(View.GONE);
        }
        sendActiveRequest();
        sendActiveUserRequest();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bNeedRefreshFragment) refreshCurrentFragmentData();
        bNeedRefreshFragment = true;
//        refresh();
    }

    /**
     * 初始化视图
     */
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        setUiTitle(getString(R.string.title_activity_edit_club));

        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单

        img_temp = (SimpleDraweeView) findViewById(R.id.img_temp);
        stickTabLayout = (StickyTabLayout) findViewById(R.id.stickTabLayout);
//        stickTabLayout.setOnTopVisibilityChangedListener(new StickyTabLayout.OnTopVisibilityChangedListener() {
//            @Override
//            public void onVisibilityChanged(boolean isTopHidden) {
//                if (isTopHidden) {//滑到顶部时,tabLayout背景改为暗色
//                    mIndicator.setBackgroundResource(R.color.colorPrimary);
//                    mIndicator.setTextColor(R.color.white_text);
//                } else {
//                    mIndicator.setBackgroundResource(android.R.color.transparent);
//                    mIndicator.setTextColor(R.color.light_gray_text);
//                }
//            }
//        });

        initContent();
        initMenu();
        refresh();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String sResult = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_CLUB + 2://获取俱乐部动态
                stopRefreshClubNewsFragmentList(sResult);
                refresh();
                break;
            case Config.MODULE_CLUB + 3://获取俱乐部公告
                stopRefreshClubNoticeFragmentList(sResult);
                refresh();
                break;
            case Config.MODULE_CLUB + 4://获取俱乐部排行列表
                stopRefreshClubRankFragmentList(sResult);
                refresh();
                break;
            case Config.MODULE_CLUB + 5://获取俱乐部排行信息
                setClubRankFragmentStaticInfo(sResult);
                refresh();
                break;
            case Config.MODULE_CLUB + 6://获取俱乐部留言
                stopRefreshClubMessageFragmentList(sResult);
                refresh();
                break;
            case Config.MODULE_CLUB + 7://获取俱乐部活跃信息
                setActiveInfo(sResult);
                break;
            case Config.MODULE_CLUB + 8://获取俱乐部活跃成员
                setActiveMember(sResult);
                break;
            case Config.MODULE_CLUB + 13://分享俱乐部
                setClubShareUrl(sResult);
                break;
            case Config.MODULE_CLUB + 20://添加俱乐部留言
                afterAddClubMessage(true);
                break;
            case Config.MODULE_CLUB + 22://查找俱乐部
                ClubDetail clubDetail = JsonHelper.getObject(sResult, ClubDetail.class);
                if (clubDetail != null) {
                    getMyConfig().getMemExchange().setCurrentClub(clubDetail.getDetail());
                }

                //重新获取公告通知列表、活跃成员列表、俱乐部消息列表
                sendClubNoticeListRequest();
                sendActiveUserRequest();
                sendActiveRequest();
                sendClubMessageListRequest();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (getIntent().getBooleanExtra("isMessage", false)) {//俱乐部消息推送
                            stickTabLayout.scrollToPage(1);
                            viewpager_club_detail.setCurrentItem(3, true);
                        } else {//俱乐部公告消息推送
                            stickTabLayout.scrollToPage(1);
                            viewpager_club_detail.setCurrentItem(1, true);
                        }
                    }
                });
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.i(Logger.DEBUG_TAG, "发生了错误啊,requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);

        refresh();
        if (bean == null) return;
        int errorCode = bean.getCode();
        switch (requestId) {
            case Config.MODULE_CLUB + 2://获取俱乐部动态
                if (clubNewsIndex > 1) {
                    processReqError(errorCode);
                    stopRefreshClubNewsWithError();
                }
                break;
            case Config.MODULE_CLUB + 3://获取俱乐部公告
                if (clubNoticeIndex > 1) {
                    processReqError(errorCode);
                    stopRefreshClubNoticeWithError();
                }
                break;
            case Config.MODULE_CLUB + 4://获取俱乐部排行列表
                if (clubRankIndex > 1) {
                    processReqError(errorCode);
                    stopRefreshClubRankWithError();
                }
                break;
            case Config.MODULE_CLUB + 6://获取俱乐部留言
                if (clubMessageIndex > 1) {
                    processReqError(errorCode);
                    stopRefreshClubMessageWithError();
                }
                break;
            case Config.MODULE_CLUB + 13://分享俱乐部
                if (errorCode < 1000) {
                    processReqError(errorCode);
                } else {
                    showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                }
                break;
            case Config.MODULE_CLUB + 20://添加俱乐部留言
                if (errorCode < 1000) {
                    processReqError(errorCode);
                } else {
                    showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                }
                break;
        }
    }

    /**
     * 初始化内容布局(上面一层)
     */
    private void initContent() {
        img_club_badge = (SimpleDraweeView) findViewById(R.id.img_club_badge);
        tv_club_name = (TextView) findViewById(R.id.tv_club_name);
        tv_club_description = (TextView) findViewById(R.id.tv_club_description);
        tv_today_activation_left = (TextView) findViewById(R.id.tv_today_activation_left);
        progress_today_activation = (SeekBar) findViewById(R.id.progress_today_activation);

        // tv_today_activation_right = (TextView) findViewById(R.id.tv_today_activation_right);


        rv_club_member = (RecyclerView) findViewById(R.id.rv_club_member);
        //布局管理器
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rv_club_member.setLayoutManager(linearLayoutManager);
        rv_club_member.setHasFixedSize(true);
        DefaultItemAnimator itemAnimator = new DefaultItemAnimator();
        rv_club_member.addItemDecoration(new SpacesItemDecoration(10));//10dp
        rv_club_member.setItemAnimator(itemAnimator);

        rvAdapter = new ClubMemberRecyclerAdapter(ClubMemberRecyclerAdapter.TYPE_LIST_HORIZONTAL);

        rvAdapter.setEnableDelete(false);
        rvAdapter.setIsClubCreator(isClubCreator());
        rvAdapter.setOnItemClickLister(new ClubMemberRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onAvatarClick(int position) {
                if (position == getClubMemberList().size() - 1) {
                    shareClub();
                } else {
                    startClubMemberInfoActivity(getClubMemberList().get(position));
                }
            }

            @Override
            public void onDeleteClick(int position) {
                if (getClubMemberList().get(position) != null)
                    if (getClubMemberList().get(position).getUser() != null)
                        sendRemoveClubMemberRequest(getClubMemberList().get(position).getUser().getId());
            }
        });
        rv_club_member.setAdapter(rvAdapter);
    }

    @Override
    protected void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "ClubDetailActivity --- > onDestroy() ");
        super.onDestroy();
    }

    /**
     * 初始化菜单布局(底下一层)
     */
    private void initMenu() {
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(getClubNewsFragment());
        fragments.add(getClubNoticeFragment());
        fragments.add(getClubRankFragment());
        fragments.add(getClubMessageFragment());

        String[] titles = new String[]{getString(R.string.activity_club_detail_tab_news)
                , getString(R.string.activity_club_detail_tab_notice)
                , getString(R.string.activity_club_detail_tab_rank)
                , getString(R.string.activity_club_detail_tab_message)};

        FragmentViewPagerAdapter viewPagerAdapter = new FragmentViewPagerAdapter(getSupportFragmentManager(), fragments);
        viewpager_club_detail = (ViewPager) findViewById(R.id.id_stickyTabLayout_viewPager);
        viewpager_club_detail.setOffscreenPageLimit(4);
        viewpager_club_detail.setAdapter(viewPagerAdapter);//给ViewPager设置适配器
        viewpager_club_detail.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果
        viewpager_club_detail.addOnPageChangeListener(this);
        mIndicator = (NewVPIndicator) findViewById(R.id.id_stickyTabLayout_indicator);
        mIndicator.setTitles(titles);
        mIndicator.setViewPager(viewpager_club_detail);
        mIndicator.setOnTabClickListener(new NewVPIndicator.OnTabClickListener() {
            @Override
            public void onTabClick(int index) {
                viewpager_club_detail.setCurrentItem(index);
                stickTabLayout.scrollToPage(1);
                //setRedDisMiss(index);
            }
        });
        checkMessageExist();
        viewpager_club_detail.requestLayout();
    }

    /**
     * 如果有未读的消息提醒 显示红点
     */
    private void checkMessageExist() {
        if (getClub() == null) return;
        if (MessageHelper.getInstance().clubHasNotice(getClub().getId())) {//检查有没有公告消息
            if (mIndicator != null)
                mIndicator.setMessage(1, true);
        }
        if (MessageHelper.getInstance().clubHasLiuYan(getClub().getId())) {//检查有没有留言消息
            if (mIndicator != null)
                mIndicator.setMessage(3, true);
        }
    }

    /**
     * 刷新界面
     */
    private void refresh() {
        if (getClub() == null) return;
        if (TextUtils.isEmpty(getClub().getBackImageUrl())) {//默认俱乐部徽标
            img_club_badge.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_club_badge)).build());
        } else {
            img_club_badge.setImageURI(Uri.parse(getClub().getBackImageUrl()));
        }
        if (tv_club_name != null) {
            tv_club_name.setText(getClub().getName());//设置俱乐部名称

            if (getClub().getType() == CLUB_TYPE_OPEN) {
                tv_club_name.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.icon_vip, 0);
            }
        }
        if (tv_club_description != null)
            tv_club_description.setText(getClub().getDesc());//设置俱乐部描述


        int percent = 0;
        if (mTotalMembers > 0) percent = 100 * mActiveMembers / mTotalMembers;
        String todayActivation = String.format(getString(R.string.activity_club_detail_today_activation_format), String.valueOf(mActiveMembers), String.valueOf(mTotalMembers));

        if (tv_today_activation_left != null)
            tv_today_activation_left.setText(todayActivation);//今日活跃度

        if (progress_today_activation != null)
            progress_today_activation.setProgress(percent);

    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //此方法在状态改变时调用
        //state==1正在滑动,state==2滑动完成,state==0什么都没做
    }

    @Override
    public void onPageScrolled(int index, float percent, int offset) {
        //当页面在滑动的时候会调用此方法,在滑动被停止之前,此方法会一直得到调用。
        //index:当前页面及你点击滑动页面,percent：当前页面偏移的百分比,offset：当前页面偏移的像素位置
        //mIndicator.scroll(index, offset);
    }

    /**
     * 获取当前页面
     *
     * @return 当前页面
     */
    private int getCurrentFragmentPage() {
        return currentFragmentPage;
    }

    /**
     * 设置当前页面
     *
     * @param page 页码
     */
    private void setCurrentFragmentPage(int page) {
        this.currentFragmentPage = page;
    }

    /**
     * 刷新当前页面数据
     */
    private void refreshCurrentFragmentData() {

        int index = getCurrentFragmentPage();
        switch (index) {
            case PAGE_CLUB_MESSAGE:     //留言
                startRefreshClubMessageFragmentList();
                break;
            case PAGE_CLUB_NOTICE:      //俱乐部公告
                startRefreshClubNoticeFragmentList();
                break;
            case PAGE_CLUB_ACTIVITY:    //俱乐部动态
                startRefreshClubNewsFragmentList();
                break;
            case PAGE_CLUB_RANKING:     //成员排名
                startRefreshClubRankFragmentList(getClubRankFragment().getChartType());
                break;
        }
    }

    @Override
    public void onPageSelected(int index) {
        setCurrentFragmentPage(index);
        setRedDisMiss(index);
    }

    /**
     * 如果有红点 就消失
     *
     * @param index tab角标
     */
    public void setRedDisMiss(int index) {
        if (getClub() == null) return;
        if (MessageHelper.getInstance().clubHasMessage(getClub().getId())) {
            MessageHelper.getInstance().switchMessageState(getClub().getId(), index + 1);
            if (mIndicator != null)
                mIndicator.setMessage(index, false);
            int pushType = -1;
            switch (index) {
                case 0:
                    break;
                case 1:
                    pushType = 12;//公告类型
                    break;
                case 2:
                    break;
                case 3:
                    pushType = 11;//留言类型
                    break;
            }
            if (pushType < 0) return;
            UserDataManager.getInstance().switchMessageState(pushType, getClub().getId());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {//复写返回操作,回退动画
        switch (item.getItemId()) {
            case android.R.id.home://返回
                this.onBackPressed();
                return true;
//            case R.id.menu_add_notice://活动公告
//                startPublishNoticeActivity();
//                return true;
//            case R.id.menu_leave_message://留言
//                startLeaveMessageActivity();
//                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (exitTransition != null) {
            //先隐藏本来布局
            if (stickTabLayout != null)
                stickTabLayout.setVisibility(View.GONE);
            if (img_club_badge != null) {
                img_club_badge.setVisibility(View.GONE);
            }
            if (img_temp != null)
                img_temp.setVisibility(View.VISIBLE);
            exitTransition.exit(this);//退场动画
        } else {
            finish();
            overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
        }
    }

    /**
     * 切换到编辑俱乐部信息
     */
    private void startEditClubActivity() {
        Intent intent = new Intent();
        intent.putExtra("isMember", getIsMember());
        intent.setClass(ClubDetailActivity.this, EditClubActivity.class);
        startActivity(intent);
    }

    /**
     * 切换到查看成员
     */
    private void startViewClubMemberActivity() {
        Intent intent = new Intent();
        intent.putExtra("isMember", getIsMember());
        intent.setClass(ClubDetailActivity.this, ViewClubMemberActivity.class);
        startActivityForResult(intent, ACTIVITY_CLUM_MEMBER_NEED_REFRESH);
    }

    /**
     * 切换到成员信息
     */
    private void startClubMemberInfoActivity(ClubMember clubMember) {
        Intent intent = new Intent();
        String clubMemberString = JsonHelper.createJsonString(clubMember);
        intent.putExtra("clubMemberString", clubMemberString);
        intent.setClass(ClubDetailActivity.this, ClubMemberInfoActivity.class);
        startActivity(intent);
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_edit_club://编辑俱乐部
                startEditClubActivity();
                break;

            case R.id.btn_view_member_list://查看俱乐部成员
                startViewClubMemberActivity();
                break;
        }
    }

    //region===========================分享俱乐部=============================

    /**
     * 发送分享俱乐部请求
     */
    private void shareClub() {
        if (getClub() == null) return;
        if (!getIsMember()) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.visitors_permissions)
                    .positiveText(R.string.ok)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    break;
                            }
                        }
                    }).show();
        } else {
            getShareClubUrl();
        }
    }

    /**
     * 分享俱乐部添加成员
     */
    public void getShareClubUrl() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getShareClubUrl(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    private void setClubShareUrl(String sResult) {
        ClubShareInfo clubShareInfo = JsonHelper.getObject(sResult, ClubShareInfo.class);
        if (clubShareInfo != null) {
            String url = clubShareInfo.getShareUrl();
            if (!TextUtils.isEmpty(url)) {
                shareClub(url);
            }
        }
    }

    /**
     * 分享俱乐部
     *
     * @param url 俱乐部地址
     */
    private void shareClub(String url) {
        if (TextUtils.isEmpty(url)) return;
        if (getClub() == null) return;
        ShareUtils.getInstance().shareClub(this, getClub().getBackImageUrl(), url);
    }

    //endregion========================================================

    //region===========================获得数据=============================

    /**
     * 获取成员列表
     */
    private List<ClubMember> getClubMemberList() {
        if (rvAdapter != null)
            return rvAdapter.getClubMemberList();
        return new ArrayList<>();
    }

    /**
     * 是否该俱乐部创建者
     */
    public boolean isClubCreator() {
        if (getClub() == null) return false;
        return getClub().getUid() == UserDataManager.getUid();
    }

    /**
     * 是否该俱乐部成员 主要应用于开放俱乐部
     */
    public boolean getIsMember() {
        if (getClub() == null) {
            return false;
        }
        int uid = UserDataManager.getUid();
        return !(getClub().getType() == CLUB_TYPE_OPEN && !getClub().getMemberUidSet().contains(uid));
    }

    /**
     * @return 获取当前俱乐部
     */
    private Club getClub() {
        return getMyConfig().getMemExchange().getCurrentClub();
    }

    //endregion========================================================

    //region=================================获取子页面================================

    private ClubNewsFragment getClubNewsFragment() {
        if (clubNewsFragment == null) {
            clubNewsFragment = new ClubNewsFragment();
            clubNewsFragment.setParentActivity(this);
            startRefreshClubNewsFragmentList();
        }
        return clubNewsFragment;
    }

    private ClubNoticeFragment getClubNoticeFragment() {
        if (clubNoticeFragment == null) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isMember", getIsMember());
            clubNoticeFragment = new ClubNoticeFragment();
            clubNoticeFragment.setArguments(bundle);
            clubNoticeFragment.setParentActivity(this);
            startRefreshClubNoticeFragmentList();
        }
        return clubNoticeFragment;
    }

    private ClubMessageFragment getClubMessageFragment() {
        if (clubMessageFragment == null) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isMember", getIsMember());
            clubMessageFragment = new ClubMessageFragment();
            clubMessageFragment.setArguments(bundle);
            clubMessageFragment.setParentActivity(this);
            startRefreshClubMessageFragmentList();
        }
        return clubMessageFragment;
    }

    private ClubRankFragment getClubRankFragment() {
        if (clubRankFragment == null) {
            clubRankFragment = new ClubRankFragment();
            clubRankFragment.setParentActivity(this);
            clubRankFragment.setOnRankSectionChangedListener(new ClubRankFragment.OnRankSectionChangedListener() {
                @Override
                public void RankSectionChanged(int sectionType) {
                    clubRankIndex = 1;
                    startRefreshClubRankFragmentList(sectionType);
                }
            });
            startRefreshClubRankFragmentList(2);
        }
        return clubRankFragment;
    }

    //endregion=================================获取子页面================================

    //region=================================发送请求================================

    /**
     * 获取俱乐部动态信息
     */
    private void sendClubNewsListRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubDynamic(getClub().getId(), clubNewsIndex, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取俱乐部公告信息
     */
    private void sendClubNoticeListRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubNotice(getClub().getId(), clubNoticeIndex, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取俱乐部留言信息
     */
    private void sendClubMessageListRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubMessage(getClub().getId(), clubMessageIndex, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取俱乐部排行列表信息
     */
    private void sendClubRankListRequest(int type) {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubRankList(getClub().getId(), type, clubRankIndex, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取俱乐部排行详细信息
     */
    private void sendClubRankRequest(int type) {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubRankInfo(getClub().getId(), type, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 俱乐部活跃信息
     */
    private void sendActiveRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubActiveInfo(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 俱乐部活跃成员
     */
    private void sendActiveUserRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubActiveUser(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

//    /**
//     * 成员列表
//     */
//    private void sendClubMemberListRequest() {
//        if (getClub() == null) return;
//        int requestId = ClubDataManager.getInstance().getClubMemberList(getClub().getId(), clubMembersIndex, true);
//        registerDataReqStatusListener(requestId);
//    }

    /**
     * 删除成员
     */
    public void sendRemoveClubMemberRequest(int uid) {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().deleteClubMember(getClub().getId(), uid, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 添加俱乐部留言
     *
     * @param content 俱乐部留言内容
     */
    public void sendAddClubMessageRequest(String content) {
        if (getClub() == null) return;
        if (TextUtils.isEmpty(content)) {
            String prompt = getString(R.string.activity_leave_message_empty_prompt);
            showAppMessage(prompt, AppMsg.STYLE_ALERT);
        } else {
            int requestId = ClubDataManager.getInstance().addClubMessage(getClub().getId(), content, true);
            registerDataReqStatusListener(requestId);
        }
    }

    /**
     * 添加俱乐部留言之后
     */
    public void afterAddClubMessage(boolean isSuccess) {
        if (isSuccess) {
            clubMessageIndex = 1;
            startRefreshClubMessageFragmentList();
        }
    }
    //endregion=================================发送请求================================

    //region=================================刷新界面================================

//    public void startRefreshClubMembersList() {
//        sendClubMemberListRequest();
//    }
//
//    public void nextRefreshClubMembersList() {
//        sendClubMemberListRequest();
//    }

    public void startRefreshClubNewsFragmentList() {
        sendClubNewsListRequest();
    }

    public void nextRefreshClubNewsFragmentList() {
        sendClubNewsListRequest();
    }

    public void startRefreshClubNoticeFragmentList() {
        clubNoticeIndex = 1;
        sendClubNoticeListRequest();
    }

    public void nextRefreshClubNoticeFragmentList() {
        sendClubNoticeListRequest();
        getClubNoticeFragment().startRefresh();
    }

    public void startRefreshClubRankFragmentList(int type) {
        sendClubRankRequest(type);
        sendClubRankListRequest(type);
    }

    public void nextRefreshClubRankFragmentList(int type) {
        sendClubRankListRequest(type);
    }

    public void startRefreshClubMessageFragmentList() {
        sendClubMessageListRequest();
    }

    public void nextRefreshClubMessageFragmentList() {
        sendClubMessageListRequest();
    }


    public void stopRefreshClubNewsFragmentList(String sResult) {
        ClubDynamicList clubDynamicList = JsonHelper.getObject(sResult, ClubDynamicList.class);

        if (clubDynamicList != null) {
            if (clubDynamicList.getList() != null && clubDynamicList.getList().size() > 0)
                clubNewsIndex++;
            getClubNewsFragment().stopRefresh(clubDynamicList.getList());
        } else {
            stopRefreshClubNewsWithError();
        }
    }

    public void stopRefreshClubNewsWithError() {
        getClubNewsFragment().stopRefreshWithError();
    }

    public void stopRefreshClubRankFragmentList(String sResult) {
        ClubRankList clubRankList = JsonHelper.getObject(sResult, ClubRankList.class);
        if (clubRankList != null) {
            getClubRankFragment().stopRefresh(clubRankList.getUserRanking(), clubRankIndex);
            if (clubRankList.getUserRanking() != null && clubRankList.getUserRanking().size() > 0)
                clubRankIndex++;
        } else {
            stopRefreshClubRankWithError();
        }
    }

    public void stopRefreshClubRankWithError() {
        getClubRankFragment().stopRefreshWithError();
    }

    public void setClubRankFragmentStaticInfo(String sResult) {
        ClubRankInfo clubRankInfo = JsonHelper.getObject(sResult, ClubRankInfo.class);

        if (clubRankInfo != null) {
            if (clubRankInfo.getTotalCount() != null) {
                long calorie = clubRankInfo.getTotalCount().getCalorie();
                long distance = clubRankInfo.getTotalCount().getDistance();
                long step = clubRankInfo.getTotalCount().getStep();
                getClubRankFragment().setClubTotalCalorie(FormatUtil.formatClubTotalCalorie(calorie));
                getClubRankFragment().setClubTotalDistance(FormatUtil.formatDistance(distance));

                DecimalFormat df = new DecimalFormat("0.00");
                String sStepValue = df.format(step / 10000.0f);
                getClubRankFragment().setClubTotalStep(sStepValue);
            }
            List<Integer> listData = clubRankInfo.getStatView();
            if (listData == null || listData.size() == 0) {
                getClubRankFragment().setChartData(null, getClubRankFragment().getChartType());
                return;
            }
            double data[] = new double[listData.size()];
            for (int i = 0; i < data.length; i++) {
                data[i] = listData.get(i) / 1000.0;
            }
            getClubRankFragment().setChartData(data, getClubRankFragment().getChartType());
        }
    }

    public void stopRefreshClubMessageFragmentList(String sResult) {
        ClubMessageList clubMessageList = JsonHelper.getObject(sResult, ClubMessageList.class);

        if (clubMessageList != null) {
            List<ClubMessage> clubMessages = new ArrayList<>();
            if (clubMessageList.getPage() != null) {
                clubMessages.addAll(clubMessageList.getPage());
            }
            if (clubMessages.size() > 0) clubMessageIndex++;
            getClubMessageFragment().stopRefresh(clubMessages, clubMessageIndex);
        } else {
            stopRefreshClubMessageWithError();
        }
    }

    public void stopRefreshClubMessageWithError() {
        getClubMessageFragment().stopRefreshWithError();
    }

    public void stopRefreshClubNoticeFragmentList(String sResult) {
        ClubNoticeList clubNoticeList = JsonHelper.getObject(sResult, ClubNoticeList.class);

        if (clubNoticeList != null) {
            List<ClubNotice> clubNotices = new ArrayList<>();
            if (clubNoticeList.getPage() != null) {
                clubNotices.addAll(clubNoticeList.getPage().getResult());
            }
            getClubNoticeFragment().stopRefresh(clubNotices, clubNoticeIndex);
            if (clubNotices.size() > 0) clubNoticeIndex++;
        } else {
            stopRefreshClubNoticeWithError();
        }
    }

    public void stopRefreshClubNoticeWithError() {
        getClubNoticeFragment().stopRefreshWithError();
    }

    private void setActiveInfo(String sResult) {
        ClubActive clubActive = JsonHelper.getObject(sResult, ClubActive.class);

        if (clubActive != null) {
            ClubActive.ActiveBean activeBean = clubActive.getActive();
            if (activeBean != null) {
                mTotalMembers = activeBean.getMemberCount();
                getClub().setMemberCount(mTotalMembers);
                mActiveMembers = activeBean.getActiveCount();
                refresh();
            }
        }
    }

    private void setActiveMember(String sResult) {
        ActiveUserList activeUserList = JsonHelper.getObject(sResult, ActiveUserList.class);

        if (activeUserList != null) {
            List<ActiveUser> activeUsers = activeUserList.getActiveUser();
            List<ClubMember> clubMembers = new ArrayList<>();
            if (activeUsers != null && activeUsers.size() > 0) {
                for (ActiveUser activeUser : activeUsers) {
                    ClubMember clubMember = new ClubMember();
                    if (activeUser != null)
                        clubMember.setUser(activeUser);
                    clubMembers.add(clubMember);
                }
            }

            if (clubMembers.size() == 0) {
                if (rvAdapter != null)
                    rvAdapter.setClubMemberList(null);
                refresh();
                return;
            }
            ClubMember clubMember = new ClubMember();
            ActiveUser user = new ActiveUser();
            user.setName(getResources().getString(R.string.activity_club_detail_add_friend));
            clubMember.setUser(user);
            clubMembers.add(clubMember);
            if (rvAdapter != null)
                rvAdapter.setClubMemberList(clubMembers);
            if (rv_club_member != null)
                rv_club_member.scrollToPosition(clubMembers.size() - 1);
            refresh();
        }

    }
    //endregion=================================刷新界面================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (getClub() == null) finish();
        switch (requestCode) {
            case ACTIVITY_CLUM_MEMBER_NEED_REFRESH://从成员列表中返回时要刷新活跃用户
                sendActiveUserRequest();
                break;
            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            break;
                    }
                }
                break;
        }
    }
}
