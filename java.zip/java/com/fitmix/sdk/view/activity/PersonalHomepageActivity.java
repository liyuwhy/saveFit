package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.PersonalHomePageBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.ViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.widget.CustomBounceViewPager;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户运动个人主页
 */
public class PersonalHomepageActivity extends BaseActivity {

    private int uid;
    private TextView tv_user_name, personal_sport_days, personal_location_province, personal_all_cal_unit,
            personal_location_city, personal_slogan, personal_all_dist, personal_all_steps, personal_all_steps_unit,
            personal_all_cal, this_month_dist, this_month_steps, this_month_times, this_month_cal, personal_all_dist_unit;
    private RelativeLayout personal_chat_view;
    private ImageView personal_sex;
    private SimpleDraweeView img_avatar;
    private int groupId = 0;
    private int reject = 0;
    private String targetName;
    DecimalFormat df = new DecimalFormat("######0.00");
    private String targetAvatar;

    private CustomBounceViewPager personal_homepage_vp;
    private TextView personal_homepage_line1;
    private TextView personal_homepage_line2;
    private TextView this_month_dist_view2;
    private TextView this_month_pace_view2;
    private TextView this_month_bpm_view2;
    private TextView this_month_stride_view2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_homepage);
        initToolbar();
        initViews();
        initData();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
            setUiTitle("");
        }
        tv_user_name = (TextView) findViewById(R.id.tv_user_name);
        personal_sport_days = (TextView) findViewById(R.id.personal_sport_days);
        personal_location_province = (TextView) findViewById(R.id.personal_location_province);
        personal_location_city = (TextView) findViewById(R.id.personal_location_city);
        personal_slogan = (TextView) findViewById(R.id.personal_slogan);
        personal_all_dist = (TextView) findViewById(R.id.personal_all_dist);
        personal_all_steps = (TextView) findViewById(R.id.personal_all_steps);
        personal_all_steps_unit = (TextView) findViewById(R.id.personal_all_steps_unit);
        personal_all_cal_unit = (TextView) findViewById(R.id.personal_all_cal_unit);
        personal_all_dist_unit = (TextView) findViewById(R.id.personal_all_dist_unit);
        personal_all_cal = (TextView) findViewById(R.id.personal_all_cal);
        img_avatar = (SimpleDraweeView) findViewById(R.id.img_avatar);
        personal_chat_view = (RelativeLayout) findViewById(R.id.personal_chat_view);
        personal_sex = (ImageView) findViewById(R.id.personal_sex);

        personal_chat_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PersonalHomepageActivity.this, ChatActivity.class);

                intent.putExtra("targetId", uid);
                intent.putExtra("groupId", groupId);
                intent.putExtra("reject", reject);
                intent.putExtra("targetName", targetName);
                intent.putExtra("targetAvatar", targetAvatar);
                startActivity(intent);

            }
        });
        personal_homepage_vp = (CustomBounceViewPager) findViewById(R.id.personal_homepage_vp);
        personal_homepage_line1 = (TextView) findViewById(R.id.personal_homepage_line1);
        personal_homepage_line2 = (TextView) findViewById(R.id.personal_homepage_line2);
        List<View> views = new ArrayList<>();
        View vp_view1 = getLayoutInflater().inflate(R.layout.personal_home_page_vp_view1, null);
        this_month_dist = (TextView) vp_view1.findViewById(R.id.this_month_dist);
        this_month_steps = (TextView) vp_view1.findViewById(R.id.this_month_steps);
        this_month_times = (TextView) vp_view1.findViewById(R.id.this_month_times);
        this_month_cal = (TextView) vp_view1.findViewById(R.id.this_month_cal);

        View vp_view2 = getLayoutInflater().inflate(R.layout.personal_home_page_vp_view2, null);
        this_month_dist_view2 = (TextView) vp_view2.findViewById(R.id.this_month_dist);
        this_month_pace_view2 = (TextView) vp_view2.findViewById(R.id.this_month_steps);
        this_month_bpm_view2 = (TextView) vp_view2.findViewById(R.id.this_month_times);
        this_month_stride_view2 = (TextView) vp_view2.findViewById(R.id.this_month_cal);

        views.add(vp_view1);
        views.add(vp_view2);
        ViewPagerAdapter pageAdapter = new ViewPagerAdapter(views);

        personal_homepage_vp.setAdapter(pageAdapter);
        personal_homepage_vp.setPagerCount(pageAdapter.getCount());//设置页数,回弹效果必须有
        personal_homepage_vp.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果 DepthPageTransformer在部分机子造成列表不能滑动
        personal_homepage_vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (0 == position) {
                    personal_homepage_line1.setBackgroundColor(getResources().getColor(R.color.fitmix_yellow));
                    personal_homepage_line2.setBackgroundColor(getResources().getColor(R.color.md_btn_selected_dark));
                } else if (1 == position) {
                    personal_homepage_line1.setBackgroundColor(getResources().getColor(R.color.md_btn_selected_dark));
                    personal_homepage_line2.setBackgroundColor(getResources().getColor(R.color.fitmix_yellow));
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void initData() {
        if (getIntent() != null && getIntent().getIntExtra("uid", 0) != 0) {
            uid = getIntent().getIntExtra("uid", 0);
            requestBrowseHomePage();
        }
    }

    private void requestBrowseHomePage() {
        //不考虑缓存
        int requestId = UserDataManager.getInstance().browseHomePage(uid, true);
        registerDataReqStatusListener(requestId);
    }


    /**
     * 设置运动总卡路里
     *
     * @param distance 运动总里程
     */
    public void setTotalRunDistance(long distance) {
        if (personal_all_dist == null) return;

        if (distance >= 1000000) {//如果大于1000公里
            personal_all_dist.setText(FormatUtil.formatDistance(distance / 1000));
            if (personal_all_dist_unit != null) {
                personal_all_dist_unit.setText(getResources().getString(R.string.personal_dist_unit_k));
            }
        } else {
            personal_all_dist.setText(FormatUtil.formatDistance(distance));
            if (personal_all_dist_unit != null) {
                personal_all_dist_unit.setText(getResources().getString(R.string.personal_dist_unit));
            }
        }
    }


    /**
     * 设置运动总卡路里
     *
     * @param runCalorie 运动总卡路里,单位为大卡
     */
    public void setTotalRunCalorie(long runCalorie) {
        if (personal_all_cal == null) return;
        personal_all_cal.setText(FormatUtil.formatTotalCalorie(runCalorie));
        if (personal_all_cal_unit != null) {
            String totalCalorieUnit;
            if (FitmixUtil.phoneLanguageIsChinese()) {
                totalCalorieUnit = String.format("%s(%s)", getResources().getString(R.string.fm_mine_run_record_total_run_calorie),
                        FormatUtil.formatTotalCalorieUnit(runCalorie));
                personal_all_cal_unit.setText(totalCalorieUnit);
            } else {
                totalCalorieUnit = String.format("%s\n(%s)", getResources().getString(R.string.fm_mine_run_record_total_run_calorie),
                        FormatUtil.formatTotalCalorieUnit(runCalorie));
                personal_all_cal_unit.setText(totalCalorieUnit);
            }
        }
    }

    /**
     * 设置运动总步数
     *
     * @param runSteps 运动总步数
     */
    public void setTotalRunSteps(long runSteps) {
        if (personal_all_steps == null) return;
        if (FitmixUtil.phoneLanguageIsChinese()) {
            personal_all_steps.setText(FormatUtil.formatChineseTotalSteps(runSteps));
            if (personal_all_steps_unit != null) {
                String totalStepsUnit = String.format("%s(%s)", getResources().getString(R.string.fm_mine_run_record_total_run_step),
                        FormatUtil.formatChineseTotalStepsUnit(runSteps));
                personal_all_steps_unit.setText(totalStepsUnit);
            }
        } else {
            personal_all_steps.setText(FormatUtil.formatTotalSteps(runSteps));
            if (personal_all_steps_unit != null) {
                String totalStepsUnit;
                totalStepsUnit = String.format("%s\n(%s)", getResources().getString(R.string.fm_mine_run_record_total_run_step),
                        FormatUtil.formatTotalStepsUnit(runSteps));
                personal_all_steps_unit.setText(totalStepsUnit);
            }
        }
    }


    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.d(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 66://请求个人主页接口
                PersonalHomePageBean homePageBean = JsonHelper.getObject(result, PersonalHomePageBean.class);

                if (homePageBean != null) {
                    PersonalHomePageBean.AllBean all = homePageBean.getAll();
                    if (all != null) {
                        setTotalRunSteps(all.getSumStep());
                        setTotalRunCalorie(all.getSumCalorie());
                        setTotalRunDistance(all.getSumDistance());
                        if (personal_sport_days != null) {
                            personal_sport_days.setText(String.format(getResources().getString(R.string.activity_share_run_day_format), all.getRunDay()));
                        }
                    }

                    PersonalHomePageBean.MonthBean month = homePageBean.getMonth();
                    if (month != null) {
                        if (this_month_cal != null) {
                            this_month_cal.setText(String.valueOf(month.getSumCalorie()));
                        }
                        if (this_month_dist != null) {
                            this_month_dist.setText(String.valueOf(df.format(month.getSumDistance() / 1000.00)));
                        }
                        if (this_month_steps != null) {
                            this_month_steps.setText(String.valueOf(month.getSumStep()));
                        }
                        if (this_month_times != null) {
                            this_month_times.setText(String.valueOf(month.getRunNum()));
                        }

                        if (month.getRunNum() > 0) {
                            this_month_dist_view2.setText(FormatUtil.formatDistance(month.getSumDistance() / month.getRunNum()));
                        } else {
                            this_month_dist_view2.setText("0.00");
                        }
                        if (month.getRunTime() > 0) {
                            this_month_bpm_view2.setText(FormatUtil.getIntNumber(month.getSumStep() / (month.getRunTime() / 1000.00 / 60)));
                        } else {
                            this_month_bpm_view2.setText("0");
                        }
                        if (month.getSumDistance() != 0) {
                            double pace_time = month.getRunTime() / 1000 / (month.getSumDistance() / 1000.00);
                            this_month_pace_view2.setText(FormatUtil.formatTimeQuotesStyle((int) pace_time));
                        } else {
                            this_month_pace_view2.setText("0'00''");
                        }

                        if (0 != month.getSumStep()) {
                            this_month_stride_view2.setText(FormatUtil.getTwoPointsNumber(month.getSumDistance() * 1.00D / month.getSumStep()));
                        } else {
                            this_month_stride_view2.setText("0");
                        }
                    }

                    PersonalHomePageBean.TargetUserBean targetUser = homePageBean.getTargetUser();
                    if (targetUser != null) {
                        PersonalHomePageBean.TargetUserBean.TaoBaoIpBean taoBaoIp = targetUser.getTaoBaoIp();
                        if (taoBaoIp != null) {
                            String region = taoBaoIp.getRegion();
                            String city = taoBaoIp.getCity();
                            if (city != null && city.length() > 2) {//对得到的城市名称处理 服务器端 只能解析如 "深圳"
                                if (city.endsWith("市")) {
                                    city = city.substring(0, city.length() - 1);
                                    personal_location_city.setText(city);
                                } else {
                                    personal_location_city.setText(city);
                                }
                            } else {
                                personal_location_city.setText(city);
                            }
                            if (region.length() > 2) {
                                if (region.endsWith("省") || region.endsWith("市")) {
                                    region = region.substring(0, region.length() - 1);
                                    personal_location_province.setText(region);
                                } else {
                                    personal_location_province.setText(region);
                                }
                            } else {
                                personal_location_province.setText(region);
                            }

                        }

                        targetAvatar = targetUser.getAvatar();
                        targetName = targetUser.getName();
                        if (personal_slogan != null) {
                            personal_slogan.setText(targetUser.getSignature());
                        }
                        if (tv_user_name != null) {
                            tv_user_name.setText(targetName);
                        }
                        if (img_avatar != null) {
                            if (!TextUtils.isEmpty(targetAvatar)) {
                                img_avatar.setImageURI(Uri.parse(targetAvatar));
                            } else {
                                img_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
                            }
                        }
                        if (personal_sex != null) {
                            if (targetUser.getGender() == Config.GENDER_FEMALE) {
                                personal_sex.setImageResource(R.drawable.personal_female_icon);
                            } else if (targetUser.getGender() == Config.GENDER_MALE) {
                                personal_sex.setImageResource(R.drawable.personal_man_icon);
                            }
                        }
                        if (targetUser.getId() != UserDataManager.getUid()) {
                            personal_chat_view.setVisibility(View.VISIBLE);
                        } else {
                            personal_chat_view.setVisibility(View.GONE);
                        }
                    }

                    PersonalHomePageBean.GroupBean group = homePageBean.getGroup();
                    if (group != null) {
                        groupId = group.getId();
                        reject = group.getReject();
                    }
                }
                break;
        }
    }
}
