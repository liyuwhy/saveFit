package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.api.bean.RecommendMusic;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.view.widget.MaterialRippleLayout;

/**
 * 运动语音设置界面
 */
public class SiriSettingActivity extends BaseActivity {

    private TextView switch_siri;//播报语调
    private Spinner spinner_siri_distance;
    private Spinner spinner_siri_time;

    private LinearLayout ll_skip_audio_rate;
    private Spinner spinner_skip_siri_rate, spinner_siri_pace_broadcast_duration;

    private View view_run_divider;
    private LinearLayout ll_run_distance;
    private LinearLayout ll_run_duration;
    private SwitchCompat switch_voice, switch_music;//语音开关  音乐开关
    private LinearLayout voice_content_view;
    private MaterialRippleLayout music_content_view;
    private TextView tv_music_name;//默认的跑步音乐设置
    /**
     * 音乐设置
     */
    public static final int SELECT_EXPERT_MUSIC = 457;
    private int sportType;//0为默认

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_siri_setting);
        setPageName("SiriSettingActivity");
        initToolbar();
        initViews();
        initData();
    }

    @Override
    protected void onResume() {
        refreshVoiceTypeState();
        super.onResume();
    }

    private int getSportType() {
        if (sportType == 0) {
            sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
        }
        return sportType;
    }

    private void refreshVoiceTypeState() {
        String voiceTypeName = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_NAME, getString(R.string.activity_siri_setting_female_tone));
        String voiceType = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
        if (voiceType.equals("female")) {
            if (switch_siri != null)
                switch_siri.setText(R.string.activity_siri_setting_default_voice_name);
        } else {
            if (switch_siri != null)
                switch_siri.setText(voiceTypeName);
        }
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        view_run_divider = findViewById(R.id.view_run_divider);

        ll_run_distance = (LinearLayout) findViewById(R.id.ll_run_distance);
        ll_run_duration = (LinearLayout) findViewById(R.id.ll_run_duration);

        ll_skip_audio_rate = (LinearLayout) findViewById(R.id.ll_skip_audio_rate);
        spinner_skip_siri_rate = (Spinner) findViewById(R.id.spinner_skip_siri_rate);
        spinner_siri_pace_broadcast_duration = (Spinner) findViewById(R.id.spinner_siri_pace_broadcast_duration);
        switch_siri = (TextView) findViewById(R.id.siri_choose);
        switch_music = (SwitchCompat) findViewById(R.id.switch_music);
        switch_voice = (SwitchCompat) findViewById(R.id.switch_voice);
        voice_content_view = (LinearLayout) findViewById(R.id.voice_content_view);
        music_content_view = (MaterialRippleLayout) findViewById(R.id.music_content_view);
        tv_music_name = (TextView) findViewById(R.id.tv_music_name);

        //语音播报开关
        boolean sportWithVoice = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
        if (sportWithVoice) {
            switch_voice.setChecked(true);
            voice_content_view.setVisibility(View.VISIBLE);
        } else {
            switch_voice.setChecked(false);
            voice_content_view.setVisibility(View.GONE);
        }
        switch_voice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    voice_content_view.setVisibility(View.VISIBLE);
                    SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_VOICE, true);
                } else {
                    voice_content_view.setVisibility(View.GONE);
                    SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_VOICE, false);
                }
            }
        });

        //音乐播放开关
        boolean sportWithMusic = SettingsHelper.getBoolean(Config.SETTING_SPORT_WITH_MUSIC, false);
        if (sportWithMusic) {
            switch_music.setChecked(true);
            music_content_view.setVisibility(View.VISIBLE);
        } else {
            switch_music.setChecked(false);
            music_content_view.setVisibility(View.GONE);
        }
        switch_music.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    music_content_view.setVisibility(View.VISIBLE);
                    SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_MUSIC, true);
                } else {
                    music_content_view.setVisibility(View.GONE);
                    SettingsHelper.putBoolean(Config.SETTING_SPORT_WITH_MUSIC, false);
                }
            }
        });


        //配速跑语音播报配速间隔
        int time_internal_position = SettingsHelper.getInt(Config.SETTING_PACE_RUN_VOICE_INTERVAL, 1);
        spinner_siri_pace_broadcast_duration.setSelection(time_internal_position);
        spinner_siri_pace_broadcast_duration.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SettingsHelper.putInt(Config.SETTING_PACE_RUN_VOICE_INTERVAL, position);
                if (view != null) {
                    TextView v = (TextView) view;
                    v.setTextColor(getResources().getColor(R.color.white_new_text));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //不处理
            }
        });


        refreshVoiceTypeState();
        if (getSportType() == Config.SPORT_TYPE_RUN) {
            if (view_run_divider != null) {
                view_run_divider.setVisibility(View.VISIBLE);
            }
            if (ll_skip_audio_rate != null) {
                ll_skip_audio_rate.setVisibility(View.GONE);
            }
            if (ll_run_duration != null) {
                ll_run_duration.setVisibility(View.VISIBLE);
            }
            if (ll_run_distance != null) {
                ll_run_distance.setVisibility(View.VISIBLE);
            }
            spinner_siri_distance = (Spinner) findViewById(R.id.spinner_siri_distance);
            spinner_siri_distance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (view != null) {
                        TextView v = (TextView) view;
                        v.setTextColor(getResources().getColor(R.color.white_new_text));
                    }
                    SettingsHelper.putInt(Config.SETTING_SIRI_DISTANCE, position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    //不处理
                }
            });

            spinner_siri_time = (Spinner) findViewById(R.id.spinner_siri_time);
            spinner_siri_time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (view != null) {
                        TextView v = (TextView) view;
                        v.setTextColor(getResources().getColor(R.color.white_new_text));
                    }
                    SettingsHelper.putInt(Config.SETTING_SIRI_TIME, position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    //不处理
                }
            });
        } else if (getSportType() == Config.SPORT_TYPE_SKIP) {
            if (view_run_divider != null) {
                view_run_divider.setVisibility(View.GONE);
            }
            if (ll_skip_audio_rate != null) {
                ll_skip_audio_rate.setVisibility(View.VISIBLE);
            }
            if (ll_run_duration != null) {
                ll_run_duration.setVisibility(View.GONE);
            }
            if (ll_run_distance != null) {
                ll_run_distance.setVisibility(View.GONE);
            }
            if (spinner_skip_siri_rate != null) {
                spinner_skip_siri_rate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String array[] = getResources().getStringArray(R.array.skip_siri_mode);
                        if (position != 0) {
                            String rate = array[position];
                            int rate_value = Integer.valueOf(rate);
                            PrefsHelper.with(SiriSettingActivity.this, Config.PREFS_SPORT).writeInt(Config.SY_KEY_SIRI_RATE_SKIP, rate_value);
                        } else {
                            PrefsHelper.with(SiriSettingActivity.this, Config.PREFS_SPORT).writeInt(Config.SY_KEY_SIRI_RATE_SKIP, -1);
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
            }


        }
    }

    private void getRecommendMusic() {
        //当用户没有设置音乐时才获取推荐音乐
        String expert_music = SettingsHelper.getString(Config.SETTING_EXPERT_MUSIC, "");
        if (TextUtils.isEmpty(expert_music)) {
            int requestId = MusicDataManager.getInstance().getRecommendMusic(false);
            registerDataReqStatusListener(requestId);
        } else {
            refreshExpertMusic();
        }
    }

    /**
     * 启动音乐设置界面
     */
    private void startSelectMusicActivity() {
        Intent intent = new Intent();
        intent.putExtra("single", true);
        intent.setClass(this, CreatePlaylistActivity.class);
        startActivityForResult(intent, SELECT_EXPERT_MUSIC);
    }

    private void initData() {
        updatePartlyInfo();
        getRecommendMusic();

        if (getSportType() == Config.SPORT_TYPE_RUN) {
            int siriDistance = SettingsHelper.getInt(Config.SETTING_SIRI_DISTANCE, 3);
            spinner_siri_distance.setSelection(siriDistance);
            int siriTime = SettingsHelper.getInt(Config.SETTING_SIRI_TIME, 0);
            spinner_siri_time.setSelection(siriTime);
        } else if (getSportType() == Config.SPORT_TYPE_SKIP) {

            int defaultSiriRate = PrefsHelper.with(SiriSettingActivity.this, Config.PREFS_SPORT).readInt(Config.SY_KEY_SIRI_RATE_SKIP, Config.SY_KEY_SIRI_RATE_SKIP_DEFAULT);
            String array[] = getResources().getStringArray(R.array.skip_siri_mode);
            if (defaultSiriRate == -1) {
                spinner_skip_siri_rate.setSelection(0);
            } else {
                String siriRateString = String.valueOf(defaultSiriRate);
                for (int i = 1; i < array.length; i++) {
                    if (array[i].equals(siriRateString)) {
                        spinner_skip_siri_rate.setSelection(i);
                        break;
                    }
                }
            }
        }

    }

    /**
     * 更新一些没有进行网络访问的UI界面
     */
    public void updatePartlyInfo() {
        String voiceTypeName = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_NAME, getString(R.string.activity_siri_setting_default_voice_name));
        String voiceType = SettingsHelper.getString(Config.SETTING_VOICE_PACKAGE_TYPE, "female");
        if (voiceType.equals("female")) {
            if (switch_siri != null)
                switch_siri.setText(getString(R.string.activity_siri_setting_default_voice_name));
        } else {
            if (switch_siri != null)
                switch_siri.setText(voiceTypeName);
        }

    }

    /**
     * 刷新音乐设置参数
     */
    public void refreshExpertMusic() {
        if (tv_music_name == null) return;
        //这个是用户手动设置的歌曲 优先级比较高
        String expert_music = SettingsHelper.getString(Config.SETTING_EXPERT_MUSIC, "");
        Music musicInfo = null;
        if (!TextUtils.isEmpty(expert_music)) {
            musicInfo = JsonHelper.getObject(expert_music, Music.class);
        } else {
            //这个是用后台推荐的歌曲 优先级比较低
            //当用户没有设置过歌曲就使用推荐的歌曲作为默认设置的歌曲
            String recommendMusic = SettingsHelper.getString(Config.RECOMMEND_MUSIC, "");
            if (!TextUtils.isEmpty(recommendMusic)) {
                musicInfo = JsonHelper.getObject(recommendMusic, Music.class);
            } else {
                //当推荐的歌曲为空时 就使用默认的歌曲 跑步使用 美好一天开始于5公里晨跑 跳绳使用 行动起来
                Music music;
                int sportType = SettingsHelper.getInt(Config.SETTING_SPORT_TYPE, Config.SPORT_TYPE_RUN);
                switch (sportType) {
                    case Config.SPORT_TYPE_RUN:
                        music = OperateMusicUtils.getMusicById(46);
                        if (music != null) {
                            musicInfo = music;
                            String musicString = JsonHelper.createJsonString(music);
                            if (!TextUtils.isEmpty(musicString))
                                SettingsHelper.putString(Config.SETTING_EXPERT_MUSIC, musicString);
                        } else {
                            musicInfo = new Music();
                            musicInfo.setName("美好一天开始于5公里晨跑");
                            musicInfo.setBpm("144");
                            musicInfo.setAuthor("DJ Shine");
                            musicInfo.setAlbumUrl("http://yyssb.ifitmix.com//1001/8a163b37b26e4bee9f976cad312f7446.JPG");
                            musicInfo.setUrl("http://yyssb.ifitmix.com//1000/3e6d8e36e14e47d799f9df08aa60dfd0.m4a");
                        }
                        break;
                    case Config.SPORT_TYPE_SKIP:
                        music = OperateMusicUtils.getMusicById(473);
                        if (music != null) {
                            musicInfo = music;
                            String musicString = JsonHelper.createJsonString(music);
                            if (!TextUtils.isEmpty(musicString))
                                SettingsHelper.putString(Config.SETTING_EXPERT_MUSIC, musicString);
                        } else {
                            musicInfo = new Music();
                            musicInfo.setName(getResources().getString(R.string.go_now));
                            musicInfo.setBpm("110");
                            musicInfo.setAuthor(getResources().getString(R.string.hip_hop));
                            musicInfo.setAlbumUrl("http://yyssb.ifitmix.com/1001/7867552709824aa89e45352c7ded62d5.jpg");
                            musicInfo.setUrl("http://yyssb.ifitmix.com/1000/c876335d896442bd875ed7be6c933f5d.m4a");
                        }
                        break;
                }
            }
        }
        if (musicInfo != null) {
            if (!TextUtils.isEmpty(musicInfo.getName())) {
                tv_music_name.setText(musicInfo.getName());
                tv_music_name.setSelected(true);//开启跑马灯效果
            }
        }
    }


    public void doClick(View view) {
        switch (view.getId()) {

            case R.id.btn_music://音乐设置
                startSelectMusicActivity();
                break;

            case R.id.ll_siri_type://语音播报设置
                goToChooseSiriTypeActivity();
                break;


        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case SELECT_EXPERT_MUSIC:
                if (data == null) break;
                String select_music = data.getStringExtra("musicString");
                if (select_music == null) break;
                Music music_select = JsonHelper.getObject(select_music, Music.class);
                if (music_select == null) break;
                SettingsHelper.putString(Config.SETTING_EXPERT_MUSIC, select_music);
                refreshExpertMusic();
                break;
        }
    }


    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "SettingActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_MUSIC + 13://获取推荐音乐
                setDefaultMusic(result);
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "SiriSettingActivity--发生了错误啊--- > requestId:" + requestId + " error:" + error);
        switch (requestId) {
            case Config.MODULE_MUSIC + 13://获取推荐音乐
                refreshExpertMusic();//请求失败 设置上一次的请求结果
                break;
        }
    }

    /**
     * 设置推荐的跑步音乐
     */
    public void setDefaultMusic(String result) {
        RecommendMusic recommendMusic = JsonHelper.getObject(result, RecommendMusic.class);
        if (recommendMusic != null) {
            String defaultMusicString = JsonHelper.createJsonString(recommendMusic.getCurrentMix());
            if (!TextUtils.isEmpty(defaultMusicString))
                SettingsHelper.putString(Config.RECOMMEND_MUSIC, defaultMusicString);
        }
        refreshExpertMusic();
    }

    //跳进语音包选择界面
    private void goToChooseSiriTypeActivity() {
        Intent intent = new Intent(this, VoiceManagerActivity.class);
        startActivity(intent);
    }


}
