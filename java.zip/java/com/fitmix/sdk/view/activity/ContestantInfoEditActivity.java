package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.SpinnerListItem;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.UserRealInfo;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusHelper;
import com.fitmix.sdk.model.database.ProvinceCityDB;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.SpinnerAdapter;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

import java.util.List;

/**
 * 用户个人参赛信息填写界面
 */
public class ContestantInfoEditActivity extends BaseActivity {

    private EditText mEditName;
    private EditText mEditIdentity;
    private EditText mEditPhoneNumber;
    private EditText mEditAddress;
    private EditText mEditEmail;
    private EditText mEditEmergencyName;
    private EditText mEditEmergencyNumber;

    private Spinner mSpProvince;
    private Spinner mSpCity;
    private Spinner mSpBloodType;
    private Spinner mSpDressSize;

    private String contestantName;
    private String identity;
    private String phoneNumber;
    private String address;
    private String email;
    private String emergencyName;
    private String emergencyNumber;
    private String province;
    private String city;
    private String bloodType;
    private String dressSize;

    private String currentContestantName;
    private String currentIdentity;
    private String currentPhoneNumber;
    private String currentAddress;
    private String currentEmail;
    private String currentEmergencyName;
    private String currentEmergencyNumber;
    private String currentProvince;
    private String currentCity;
    private String currentBloodType;
    private String currentDressSize;

    private boolean isModify;

    /**
     * 金币任务,完善个人参赛资料是否完成
     */
    private boolean coinTaskCompleteCompetitionInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contestant_info_edit);
        setPageName("ContestantInfoEditActivity");
        isModify = getIntent().getBooleanExtra("isModify", false);
        initToolbar();
        initViews();


        coinTaskCompleteCompetitionInfo = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_COMPLETE_COMPETITION_INFO, true);
    }


    @Override
    protected void onResume() {
        mEditName.setSelection(mEditName.getText().length());
        mEditIdentity.setSelection(mEditIdentity.getText().length());
        mEditPhoneNumber.setSelection(mEditPhoneNumber.getText().length());
        mEditAddress.setSelection(mEditAddress.getText().length());
        mEditEmail.setSelection(mEditEmail.getText().length());
        mEditEmergencyName.setSelection(mEditEmergencyName.getText().length());
        mEditEmergencyNumber.setSelection(mEditEmergencyNumber.getText().length());
        super.onResume();
    }

    @Override
    protected void initViews() {
        setUiTitle(getString(isModify ? R.string.change_contestant_info : R.string.edit_contestant_info));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        mEditName = (EditText) findViewById(R.id.et_contestant_name);
        mEditIdentity = (EditText) findViewById(R.id.et_contestant_identity);
        mEditPhoneNumber = (EditText) findViewById(R.id.et_contestant_number);
        mEditAddress = (EditText) findViewById(R.id.et_contestant_address);
        mEditEmail = (EditText) findViewById(R.id.et_contestant_email);
        mEditEmergencyName = (EditText) findViewById(R.id.et_emergency_name);
        mEditEmergencyNumber = (EditText) findViewById(R.id.et_emergency_number);

        mSpProvince = (Spinner) findViewById(R.id.spinner_provinces);
        mSpCity = (Spinner) findViewById(R.id.spinner_city);
        mSpBloodType = (Spinner) findViewById(R.id.spinner_blood_type);
        mSpDressSize = (Spinner) findViewById(R.id.spinner_dress_size);

        if (isModify) {//修改
            getDataFromDBOrNet();
        }

        Button btn_contestant_info_ok = (Button) findViewById(R.id.btn_contestant_info_ok);
        btn_contestant_info_ok.setText(isModify ? getString(R.string.modify) : getString(R.string.ok));
        btn_contestant_info_ok.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean inputNoError = checkInputInfo();

                if (inputNoError) {// 对所有输入框检测无误后 ----> 上传信息
                    // 弹出确认框
                    createAlertDialog();
                }
            }
        });
        mSpProvince.setPrompt(getString(R.string.select_provinces));
        mSpCity.setPrompt(getString(R.string.select_city));
        mSpBloodType.setPrompt(getString(R.string.select_blood_type));
        mSpDressSize.setPrompt(getString(R.string.select_dress_size));

        mEditName.setFocusable(true);
        mEditName.setFocusableInTouchMode(true);
        mEditName.requestFocus();


        mEditName.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentContestantName = mEditName.getText().toString();
            }
        });
        mEditIdentity.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentIdentity = mEditIdentity.getText().toString();
            }
        });
        mEditPhoneNumber.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentPhoneNumber = mEditPhoneNumber.getText().toString();
            }
        });
        mEditEmail.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentEmail = mEditEmail.getText().toString();
            }
        });
        mEditAddress.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentAddress = mEditAddress.getText().toString();
            }
        });
        mEditEmergencyName.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentEmergencyName = mEditEmergencyName.getText().toString();
            }
        });
        mEditEmergencyNumber.addTextChangedListener(new MyTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                currentEmergencyNumber = mEditEmergencyNumber.getText().toString();
            }
        });
    }

    private void initViewAfterGettingData(UserRealInfo info) {
        getContestantInfo(info);
        initSpinnerProvinceCity(province, city);
        initBloodType(bloodType);
        initDressSize(dressSize);

        mEditName.setHint(contestantName);
        mEditIdentity.setHint(identity);
        mEditPhoneNumber.setHint(phoneNumber);
        mEditEmail.setHint(email);
        mEditAddress.setHint(address);
        mEditEmergencyName.setHint(emergencyName);
        mEditEmergencyNumber.setHint(emergencyNumber);
        mEditName.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditName.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditName.getHint().toString())) {
                    mEditName.setHint(contestantName);
                }
            }
        });

        mEditIdentity.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditIdentity.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditIdentity.getHint().toString())) {
                    mEditIdentity.setHint(identity);
                }
            }
        });
        mEditIdentity.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditIdentity.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditIdentity.getHint().toString())) {
                    mEditIdentity.setHint(identity);
                }
            }
        });
        mEditPhoneNumber.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditPhoneNumber.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditPhoneNumber.getHint().toString())) {
                    mEditPhoneNumber.setHint(phoneNumber);
                }
            }
        });
        mEditEmail.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditEmail.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditEmail.getHint().toString())) {
                    mEditEmail.setHint(email);
                }
            }
        });
        mEditAddress.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditAddress.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditAddress.getHint().toString())) {
                    mEditAddress.setHint(address);
                }
            }
        });
        mEditEmergencyName.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditEmergencyName.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditEmergencyName.getHint().toString())) {
                    mEditEmergencyName.setHint(emergencyName);
                }
            }
        });
        mEditEmergencyNumber.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void changeHint() {
                mEditEmergencyNumber.setHint("");
            }

            @Override
            public void recoverHint() {
                if ("".equals(mEditEmergencyNumber.getHint().toString())) {
                    mEditEmergencyNumber.setHint(emergencyNumber);
                }
            }
        });
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String sResult = dataReqResult.getResult();
        if (sResult == null) {
            return;
        }
        //获取个人信息数据返回的信息
        switch (requestId) {
            case Config.MODULE_USER + 2:
            case Config.MODULE_USER + 3:
            case Config.MODULE_USER + 4:
            case Config.MODULE_USER + 5:
                Login login = JsonHelper.getObject(sResult, Login.class);
                if (login != null) {
                    //设置我的界面,个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
                    if (login.getUser() == null || login.getUser().getUserRealInfo() == null) break;
                    initViewAfterGettingData(login.getUser().getUserRealInfo());
                }
                break;
            case Config.MODULE_USER + 13:
                SettingsHelper.putString(Config.SETTING_USER_ID_CARD, currentIdentity);//用于标识用户填写过参赛资料的凭证
                int userInfoRequestId = getUserInfoRequestIdByLoginType();
                if (userInfoRequestId == -1) return;
                DataReqStatusHelper.getInstance().setDataReqStatusCacheUseless(userInfoRequestId);
                if (!coinTaskCompleteCompetitionInfo) {
                    finishCompleteInfoCoinTask();
                } else {
                    finish();
                }
                break;

            case Config.MODULE_USER + 52://完成完善个人参赛资料任务
                FinishTask finishTask = JsonHelper.getObject(sResult, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_COMPETITION_INFO, true);//完善个人参赛资料金币任务完成

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription(),
                                    new QuestRewardsDialog.OnQuestRewardsDialogDismiss() {
                                        @Override
                                        public void onRewardsDialogDismiss() {//对话框消失后,销毁activity
                                            finish();
                                        }
                                    });

                        }
                    }
                }
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 13:
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;

            case Config.MODULE_USER + 52://完善个人参赛资料任务
                super.processReqError(requestId, error);
                break;
        }
    }

    private void createAlertDialog() {
        View convertView = getLayoutInflater().inflate(R.layout.dialog_contestant_info, null);
        LinearLayout mNameContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_name);
        LinearLayout mIdentityContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_identity);
        LinearLayout mPhoneNumberContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_phone_number);
        LinearLayout mEmailContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_email);
        LinearLayout mAddressContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_address);
        LinearLayout mBloodTypeContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_blood_type);
        LinearLayout mDressSizeContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_dress_size);
        LinearLayout mEmergencyNameContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_emergency_name);
        LinearLayout mEmergencyNumberContainer = (LinearLayout) convertView.findViewById(R.id.container_dialog_emergency_number);

        TextView mTvName = (TextView) convertView.findViewById(R.id.dialog_name);
        TextView mTvIdentity = (TextView) convertView.findViewById(R.id.dialog_identity);
        TextView mTvPhoneNumber = (TextView) convertView.findViewById(R.id.dialog_phone_number);
        TextView mTvEmail = (TextView) convertView.findViewById(R.id.dialog_email);
        TextView mTvAddress = (TextView) convertView.findViewById(R.id.dialog_address);
        TextView mTvBloodType = (TextView) convertView.findViewById(R.id.dialog_blood_type);
        TextView mTvDressSize = (TextView) convertView.findViewById(R.id.dialog_dress_size);
        TextView mTvEmergencyName = (TextView) convertView.findViewById(R.id.dialog_emergency_name);
        TextView mTvEmergencyNumber = (TextView) convertView.findViewById(R.id.dialog_emergency_number);
        int i = 0;
        if (!currentContestantName.equals(contestantName)) {
            mNameContainer.setVisibility(View.VISIBLE);
            mTvName.setText(currentContestantName);
            i++;
        }
        if (!currentIdentity.equals(identity)) {
            mIdentityContainer.setVisibility(View.VISIBLE);
            mTvIdentity.setText(currentIdentity);
            i++;
        }
        if (!currentPhoneNumber.equals(phoneNumber)) {
            mPhoneNumberContainer.setVisibility(View.VISIBLE);
            mTvPhoneNumber.setText(currentPhoneNumber);
            i++;
        }
        if (!currentEmail.equals(email)) {
            mEmailContainer.setVisibility(View.VISIBLE);
            mTvEmail.setText(currentEmail);
            i++;
        }
        if (!currentAddress.equals(address) || !currentProvince.equals(province) || !currentCity.equals(city)) {
            mAddressContainer.setVisibility(View.VISIBLE);
            mTvAddress.setText(String.format(getString(R.string.string_format), currentProvince
                    + currentCity
                    + currentAddress));
            i++;
        }
        if (currentBloodType != null && !currentBloodType.equals(bloodType)) {
            mBloodTypeContainer.setVisibility(View.VISIBLE);
            mTvBloodType.setText(currentBloodType);
            i++;
        }

        if (currentDressSize != null && !currentDressSize.equals(dressSize)) {//判断是否为空，解决友盟统计空指针
            mDressSizeContainer.setVisibility(View.VISIBLE);
            mTvDressSize.setText(currentDressSize);
            i++;
        }

        if (currentEmergencyName != null && !currentEmergencyName.equals(emergencyName)) {
            mEmergencyNameContainer.setVisibility(View.VISIBLE);
            mTvEmergencyName.setText(currentEmergencyName);
            i++;
        }
        if (currentEmergencyNumber != null && !currentEmergencyNumber.equals(emergencyNumber)) {
            mEmergencyNumberContainer.setVisibility(View.VISIBLE);
            mTvEmergencyNumber.setText(currentEmergencyNumber);
            i++;
        }

        if (i == 0) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.check_information_no_change)
                    .positiveText(R.string.continue_do)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    break;
                                case NEGATIVE:
                                    finish();
                                    break;
                            }
                        }
                    })
                    .show();
        } else {
            new MaterialDialog.Builder(this)
                    .title(isModify ? R.string.check_information_change : R.string.check_information)
                    .customView(convertView, true)
                    .positiveText(R.string.ok)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    if (ApiUtils.getNetworkType() == Config.NETWORK_TYPE_NONE) {
                                        showAppMessage(R.string.check_network, AppMsg.STYLE_INFO);
                                    } else {
                                        modifyInNetwork();
                                    }
                                    break;
                                case NEGATIVE:
                                    break;
                            }
                        }
                    }).show();
        }
    }

    protected boolean checkInputInfo() {
        if (TextUtils.isEmpty(currentContestantName)) {
            showAppMessage(R.string.edit_name, AppMsg.STYLE_INFO);
            return false;
        } else if (!FitmixUtil.isIdentity(currentIdentity)) {
            showAppMessage(R.string.edit_identity, AppMsg.STYLE_INFO);
            return false;
        } else if (!FitmixUtil.isMobileNumber(currentPhoneNumber)) {
            showAppMessage(R.string.edit_phone_number, AppMsg.STYLE_INFO);
            return false;
        } else if (!FitmixUtil.isEmail(currentEmail)) {
            showAppMessage(R.string.edit_email, AppMsg.STYLE_INFO);
            return false;
        } else if (TextUtils.isEmpty(currentAddress)) {
            showAppMessage(R.string.edit_address, AppMsg.STYLE_INFO);
            return false;
        } else if (TextUtils.isEmpty(currentEmergencyName)) {
            showAppMessage(R.string.edit_emergency_name, AppMsg.STYLE_INFO);
            return false;
        } else if (TextUtils.isEmpty(currentEmergencyNumber)) {
            showAppMessage(R.string.edit_emergency_number, AppMsg.STYLE_INFO);
            return false;
        } else {// 所有输入框均有值
            return true;
        }
    }

    /**
     * 发送修改个人参赛信息网络请求
     */
    private void modifyInNetwork() {

        int uid = SettingsHelper.getInt(Config.SETTING_USER_ID, -1);
        int gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, -1);//1：男,2：女
        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, Config.USER_DEFAULT_AGE);

        //不考虑缓存
        int requestId = UserDataManager.getInstance().modifyContestant(
                uid, currentContestantName, gender, age, currentIdentity, currentPhoneNumber, currentEmail, currentProvince,
                currentCity, currentAddress, currentBloodType, currentDressSize, currentEmergencyName, currentEmergencyNumber, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 重新根据登录种类获取用户资料
     */
    private void getDataFromDBOrNet() {
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password))
                return;
            int requestId = UserDataManager.getInstance().emailLogin(email, password);
            registerDataReqStatusListener(requestId);
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                Logger.i(Logger.DEBUG_TAG, "openid:" + openid + " tokenId:" + tokenId);
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        }
    }


    private void getContestantInfo(UserRealInfo info) {
        contestantName = info.getName();
        identity = info.getIdCard();
        phoneNumber = info.getMobilePhone();
        email = info.getEmail();
        province = info.getRegion();
        city = info.getCity();
        address = info.getDetail();
        bloodType = info.getBloodType();
        dressSize = info.getClothesSize();
        emergencyName = info.getEmergencyName();
        emergencyNumber = info.getEmergencyPhone();
//        contestantName = SettingsHelper.getString(Config.SETTING_USER_CONTESTANT_NAME,"");
//        identity = SettingsHelper.getString(Config.SETTING_USER_ID_CARD, "");
//        phoneNumber = SettingsHelper.getString(Config.SETTING_USER_MOBILE, "");
//        email = SettingsHelper.getString(Config.SETTING_USER_EMAIL,"");
//        province = SettingsHelper.getString(Config.SETTING_USER_PROVINCE, "");
//        city = SettingsHelper.getString(Config.SETTING_USER_CITY, "");
//        address = SettingsHelper.getString(Config.SETTING_USER_ADDRESS, "");
//        bloodType = SettingsHelper.getString(Config.SETTING_USER_BLOOD_TYPE, "");
//        dressSize = SettingsHelper.getString(Config.SETTING_USER_DRESS_SIZE, "");
//        emergencyName = SettingsHelper.getString(Config.SETTING_USER_EMERGENCY_NAME,"");
//        emergencyNumber = SettingsHelper.getString(Config.SETTING_USER_EMERGENCY_NUMBER,"");
        currentContestantName = contestantName;
        currentIdentity = identity;
        currentPhoneNumber = phoneNumber;
        currentAddress = address;
        currentEmail = email;
        currentEmergencyName = emergencyName;
        currentEmergencyNumber = emergencyNumber;
        currentProvince = province;
        currentCity = city;
        currentBloodType = bloodType;
        currentDressSize = dressSize;
    }

    abstract class SpinnerOnSelectedListener implements OnItemSelectedListener {
        public abstract void onItemSelected(AdapterView<?> adapterView,
                                            View view, int position, long id);

        @Override
        public void onNothingSelected(AdapterView<?> adapterview) {
        }
    }

    private String getXNumber(int j, int k) {
        StringBuilder temp = new StringBuilder();
        for (int i = 0; i < j - k; i++) {
            temp.append("*");
        }
        return temp.toString();
    }

    /**
     * 修改-回显信息
     */
    private void initSpinnerProvinceCity(String provinceName, final String cityName) {
        List<SpinnerListItem> list = ProvinceCityDB.getInstance().getProvinceList();
        SpinnerAdapter myAdapter = new SpinnerAdapter(this, list);
        mSpProvince.setAdapter(myAdapter);
        mSpProvince.setOnItemSelectedListener(new SpinnerOnSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                currentProvince = ((SpinnerListItem) adapterView
                        .getItemAtPosition(position)).getName();
                initSpinnerCity(((SpinnerListItem) adapterView
                        .getItemAtPosition(position)).getId(), cityName);
            }
        });
        if (provinceName != null) {
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getName().equals(provinceName)) {
                    Logger.i(Logger.DEBUG_TAG, "当前省 : " + list.get(i).getName());
                    Logger.i(Logger.DEBUG_TAG, "所在省 : " + provinceName);
                    mSpProvince.setSelection(i);
                }
            }
        } else {
            mSpProvince.setSelection(18);
        }
    }

    /**
     * 修改-回显信息
     */
    private void initSpinnerCity(int provinceId, String cityName) {
        List<SpinnerListItem> cityList = ProvinceCityDB.getInstance().getCityList(provinceId);
        SpinnerAdapter myAdapter = new SpinnerAdapter(this, cityList);
        mSpCity.setAdapter(myAdapter);
        mSpCity.setOnItemSelectedListener(new SpinnerOnSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                currentCity = ((SpinnerListItem) adapterView
                        .getItemAtPosition(position)).getName();
            }
        });

        if (cityName != null) {
            for (int i = 0; i < cityList.size(); i++) {
                if (cityList.get(i).getName().equals(cityName)) {
                    mSpCity.setSelection(i);
                }
            }
        } else {
            mSpCity.setSelection(0);
        }
    }

    /**
     * 修改-回显信息
     */
    private void initBloodType(String Type) {
        String[] array = getResources().getStringArray(R.array.blood_type);
        SpinnerAdapter myAdapter = new SpinnerAdapter(this, array, 0);
        mSpBloodType.setAdapter(myAdapter);
        mSpBloodType.setOnItemSelectedListener(new SpinnerOnSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                currentBloodType = getResources().getStringArray(R.array.blood_type)[position];
            }
        });
        if (Type != null) {
            for (int i = 0; i < array.length; i++) {
                if (array[i].equals(Type)) {
                    mSpBloodType.setSelection(i);
                }
            }
        } else {
            mSpBloodType.setSelection(0);
        }
    }

    /**
     * 修改-回显信息
     */
    private void initDressSize(String Size) {
        String[] array = getResources().getStringArray(R.array.dress_size);
        SpinnerAdapter myAdapter = new SpinnerAdapter(this, array, 0);
        mSpDressSize.setAdapter(myAdapter);
        mSpDressSize.setOnItemSelectedListener(new SpinnerOnSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                currentDressSize = getResources().getStringArray(R.array.dress_size)[position];
            }
        });
        if (Size != null) {
            for (int i = 0; i < array.length; i++) {
                if (array[i].equals(Size)) {
                    mSpDressSize.setSelection(i);
                }
            }
        } else {
            mSpDressSize.setSelection(2);
        }
    }

    public abstract class MyTextWatcher implements TextWatcher {

        public void afterTextChanged(Editable s) {
        }

        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        public abstract void onTextChanged(CharSequence s, int start, int before, int count);
    }

    public abstract class OnFocusChangeListener implements View.OnFocusChangeListener {

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (hasFocus) {
                changeHint();
            } else {
                // 此处为失去焦点时的处理内容
                recoverHint();
            }
        }

        public abstract void changeHint();

        public abstract void recoverHint();
    }

    //region ============================= 金币任务 =============================

    /**
     * 完成完善个人参赛资料金币任务
     */
    private void finishCompleteInfoCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_COMPLETE_COMPETITION_INFO, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion ============================= 金币任务 =============================

}
