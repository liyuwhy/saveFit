package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.HRFirmwareUpdateVersionBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;

public class HeartRateSettingActivity extends BaseActivity {

    private ImageView moreIv;
    private View divideLine;
    private RadioGroup rg_light_type;
    private ImageView redPoint;
    private TextView coach_mode_tv;

    private boolean hrLedIsShow = false;
    private int HeartRateLightMode = 1;//默认为心率模式
    private String lastHrFirmwareVersion;

    @Override
    protected void onResume() {
        super.onResume();
        //显示当前设置的教练模式
        setTextView();
        checkHRFirmwareNewVersion();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        HeartRateLightMode = 1;
        super.onDestroy();
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.d(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_USER + 28://检查固件新版本
                HRFirmwareUpdateVersionBean hrFirmwareBean = JsonHelper.getObject(result, HRFirmwareUpdateVersionBean.class);
                if (hrFirmwareBean != null) {
                    String newVersionUrl = hrFirmwareBean.getUrl();
                    if (!TextUtils.isEmpty(newVersionUrl)) {
                        redPoint.setVisibility(View.VISIBLE);
                    } else {
                        redPoint.setVisibility(View.GONE);
                    }

                }

                break;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heart_rate_setting);
        initToolbar();
        initViews();

    }

    /**
     * 检查心率耳机固件版本
     */
    private void checkHRFirmwareNewVersion() {
        lastHrFirmwareVersion = SettingsHelper.getString(Config.SETTING_HR_FIRMWARE_VERSION_CODE, "");
        //不考虑缓存
        int requestId = UserDataManager.getInstance().checkHRFirmwareVersion(lastHrFirmwareVersion, true);
        registerDataReqStatusListener(requestId);
    }


    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        coach_mode_tv = (TextView) findViewById(R.id.coach_mode_tv);
        redPoint = (ImageView) findViewById(R.id.firmware_update_note_iv);
        divideLine = findViewById(R.id.divide_line);
        moreIv = (ImageView) findViewById(R.id.hr_more_iv);
        rg_light_type = (RadioGroup) findViewById(R.id.rg_light_type);

        rg_light_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                Intent intent = new Intent();
                switch (checkedId) {
                    case R.id.btn_hr:
                        HeartRateLightMode = 1;
                        intent.putExtra("lightModeValue", HeartRateLightMode);
                        setResult(Activity.RESULT_OK, intent);
                        break;
                    case R.id.btn_breath:
                        HeartRateLightMode = 2;
                        intent.putExtra("lightModeValue", HeartRateLightMode);
                        setResult(Activity.RESULT_OK, intent);
                        break;
                    case R.id.btn_off:
                        HeartRateLightMode = 3;
                        intent.putExtra("lightModeValue", HeartRateLightMode);
                        setResult(Activity.RESULT_OK, intent);
                        break;
                }

            }
        });


    }

    private void setTextView() {
        switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
            case 7:
                coach_mode_tv.setText(getText(R.string.heart_rate_free_mode));
                break;
            case 6:
                coach_mode_tv.setText(getText(R.string.heart_rate_custom_mode));
                break;
            case 5:
                coach_mode_tv.setText(getText(R.string.limit_mode));
                break;
            case 4:
                coach_mode_tv.setText(getText(R.string.body_mode));
                break;
            case 3:
                coach_mode_tv.setText(getText(R.string.heart_lung_mode));
                break;
            case 2:
                coach_mode_tv.setText(getText(R.string.fat_mode));
                break;
        }
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.coach_mode_view:
                Intent intent = new Intent(this, HeartRateCoachModeActivity.class);
                startActivity(intent);
                break;
            case R.id.hr_led_mode_view:
                if (!hrLedIsShow) {
                    moreIv.setRotation(90);
                    divideLine.setVisibility(View.VISIBLE);
                    rg_light_type.setVisibility(View.VISIBLE);
                    hrLedIsShow = true;
                } else {
                    moreIv.setRotation(0);
                    divideLine.setVisibility(View.GONE);
                    rg_light_type.setVisibility(View.GONE);
                    hrLedIsShow = false;
                }
                break;
            case R.id.item_update_view:
                Intent intent1 = new Intent(this, FirmwareUpdateActivity.class);
                startActivity(intent1);
                break;
        }
    }

}
