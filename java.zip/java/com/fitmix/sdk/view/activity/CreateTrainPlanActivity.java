package com.fitmix.sdk.view.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.CreateTrainPlanFifthFragment;
import com.fitmix.sdk.view.fragment.CreateTrainPlanFirstFragment;
import com.fitmix.sdk.view.fragment.CreateTrainPlanFourthFragment;
import com.fitmix.sdk.view.fragment.CreateTrainPlanSecondFragment;
import com.fitmix.sdk.view.fragment.CreateTrainPlanThirdFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.StepProgressView;

/**
 * 创建训练计划
 */
public class CreateTrainPlanActivity extends BaseActivity implements View.OnClickListener {

    private StepProgressView stepProgressView;
    private LinearLayout createPlan;
    private LinearLayout selectPlanMode;

    private CreateTrainPlanFirstFragment firstFragment;
    private CreateTrainPlanSecondFragment secondFragment;
    private CreateTrainPlanThirdFragment thirdFragment;
    private CreateTrainPlanFourthFragment fourthFragment;
    private CreateTrainPlanFifthFragment fifthFragment;
    private Fragment mTempFragment;

    private int mode;//训练计划类型 0 比赛 1 目标
    private int target;//训练计划目标 训练类型. 5km、10km、半马、全马
    private long startTime;//训练计划开始时间
    private int runProject;//目前能跑那个项目 00-20--> 0 ; 20-30-->1 ; 30-60-->2 ; 5km--> 3 ; 10km  4;半马-->5;全马  6
    private long projectTime;// 选取runProject在3~6，须填写该项，呈现方式为秒，若runProject为0~2，该项须输入0

    private int index = -1;
    private boolean canChangePage = true;//当进度更新中不可以更换页面

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            showRightFragment();
        }
        setContentView(R.layout.activity_create_training_plan);
        initToolbar();
        setPageName("CreateTrainingPlanActivity");
        initViews();
    }

    @Override
    protected void initViews() {
        showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        stepProgressView = (StepProgressView) findViewById(R.id.stepProgressView);
        stepProgressView.setStepTitles(getStepTitle(true));
        stepProgressView.setOnClickStepListener(new StepProgressView.OnClickStepListener() {
            @Override
            public void onClick(int position) {
                showFragment(position);
            }
        });
        stepProgressView.setOnStepViewAnimationListener(new StepProgressView.OnStepViewAnimationListener() {
            @Override
            public void onAnimationStart() {
                canChangePage = false;
            }

            @Override
            public void onAnimationEnd(int stopIndex) {
                canChangePage = true;
            }
        });
        createPlan = (LinearLayout) findViewById(R.id.create_plan);
        Button tvForCompetition = (Button) findViewById(R.id.tv_for_competition);
        Button tvForTarget = (Button) findViewById(R.id.tv_for_target);
        selectPlanMode = (LinearLayout) findViewById(R.id.select_plan_mode);

        tvForCompetition.setOnClickListener(this);
        tvForTarget.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        if (stepProgressView != null) {
            stepProgressView.endAnimation();
        }
        super.onDestroy();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "createTrainingPlan getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        switch (requestId) {
            case Config.MODULE_SPORT + 30://创建训练计划
                hideLoadingDialog();
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putString("trainString", dataReqResult.getResult());
                intent.putExtras(bundle);
                setResult(2016, intent);
                finish();
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_SPORT + 30://创建训练计划
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    switch (bean.getCode()) {
                        case 3014://训练计划时间失效
                            showAppMessage(bean.getMsg(), AppMsg.STYLE_INFO);
                            break;
                        default:
                            showErrorDialog();
                            break;
                    }
                }
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_for_competition:
                mode = 0;
                break;
            case R.id.tv_for_target:
                mode = 1;
                break;
        }
        if (selectPlanMode != null)
            selectPlanMode.setVisibility(View.GONE);
        if (createPlan != null)
            createPlan.setVisibility(View.VISIBLE);
        if (stepProgressView != null)
            stepProgressView.setStepTitles(getStepTitle(true));
        switchFragment(getFirstFragment(), 1);
    }

    private void showRightFragment() {
        firstFragment = (CreateTrainPlanFirstFragment) getSupportFragmentManager().findFragmentByTag(CreateTrainPlanFirstFragment.class.getName());
        secondFragment = (CreateTrainPlanSecondFragment) getSupportFragmentManager().findFragmentByTag(CreateTrainPlanSecondFragment.class.getName());
        thirdFragment = (CreateTrainPlanThirdFragment) getSupportFragmentManager().findFragmentByTag(CreateTrainPlanThirdFragment.class.getName());
        fourthFragment = (CreateTrainPlanFourthFragment) getSupportFragmentManager().findFragmentByTag(CreateTrainPlanFourthFragment.class.getName());
        fifthFragment = (CreateTrainPlanFifthFragment) getSupportFragmentManager().findFragmentByTag(CreateTrainPlanFifthFragment.class.getName());

        if (firstFragment != null) {
            getSupportFragmentManager().beginTransaction().hide(firstFragment).commitAllowingStateLoss();
        }
        if (secondFragment != null) {
            getSupportFragmentManager().beginTransaction().hide(secondFragment).commitAllowingStateLoss();
        }
        if (thirdFragment != null) {
            getSupportFragmentManager().beginTransaction().hide(thirdFragment).commitAllowingStateLoss();
        }
        if (fourthFragment != null) {
            getSupportFragmentManager().beginTransaction().hide(fourthFragment).commitAllowingStateLoss();
        }
        if (fifthFragment != null) {
            getSupportFragmentManager().beginTransaction().hide(fifthFragment).commitAllowingStateLoss();
        }
        if (mTempFragment != null)
            getSupportFragmentManager().beginTransaction().show(mTempFragment).commitAllowingStateLoss();
    }

    /**
     * 使用hide和show方法切换Fragment
     *
     * @param fragment 需要切换的fragment
     */
    private void switchFragment(Fragment fragment, int targetIndex) {
        if (fragment != mTempFragment) {
            if (mTempFragment != null) {
                if (!fragment.isAdded()) {
                    getSupportFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.push_right_in, R.anim.push_right_out, R.anim.push_left_in, R.anim.push_left_out)
                            .hide(mTempFragment)
                            .add(R.id.training_plan_create_container, fragment).commitAllowingStateLoss();
                } else {
                    if (targetIndex > index) {
                        getSupportFragmentManager().beginTransaction()
                                .setCustomAnimations(R.anim.push_right_in, R.anim.push_right_out, R.anim.push_left_in, R.anim.push_left_out)
                                .hide(mTempFragment)
                                .show(fragment).commitAllowingStateLoss();
                    } else {
                        getSupportFragmentManager().beginTransaction()
                                .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                                .hide(mTempFragment)
                                .show(fragment).commitAllowingStateLoss();
                    }
                }
            } else {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.push_right_in, R.anim.push_right_out, R.anim.push_left_in, R.anim.push_left_out)
                        .add(R.id.training_plan_create_container, fragment).commitAllowingStateLoss();
            }
            mTempFragment = fragment;
            index = targetIndex;
        }
    }

    /**
     * 获取进度的名称
     *
     * @param isFiveStep 是否是五个进度
     * @return 名称的数组
     */
    private String[] getStepTitle(boolean isFiveStep) {
        String[] stepTitle;
        if (isFiveStep) {
            stepTitle = new String[]{
                    getString(R.string.activity_create_training_plan_step_title_first),
                    mode == 0 ? getString(R.string.activity_create_training_plan_step_title_second) : getString(R.string.activity_create_training_plan_step_plan_title_second),
                    getString(R.string.activity_create_training_plan_step_title_third),
                    getString(R.string.activity_create_training_plan_step_title_fourth),
                    getString(R.string.activity_create_training_plan_step_title_fifth)
            };
        } else {
            stepTitle = new String[]{
                    getString(R.string.activity_create_training_plan_step_title_first),
                    mode == 0 ? getString(R.string.activity_create_training_plan_step_title_second) : getString(R.string.activity_create_training_plan_step_plan_title_second),
                    getString(R.string.activity_create_training_plan_step_title_third),
                    getString(R.string.activity_create_training_plan_step_title_fifth)
            };
        }
        return stepTitle;
    }

    public void createTrainPlan() {
        showCreatePromptDialog();
        int gender = SettingsHelper.getInt(Config.SETTING_USER_GENDER, Config.GENDER_MALE);
        int age = SettingsHelper.getInt(Config.SETTING_USER_AGE, 24);
        int requestId = SportDataManager.getInstance().createTrainingPlan(getRunDistance(), getPlanStartTime(), getCompetitionTime(), getAbilityProjectUseTime(), getAbilityProject(), gender, age, true);
        registerDataReqStatusListener(requestId);
    }

    private void showCreatePromptDialog() {
        loadingDialog = new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_create_training_plan_creating)
                .negativeText(android.R.string.cancel)
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(MaterialDialog dialog, DialogAction which) {
                        cancelRequest(Config.MODULE_SPORT + 30);//取消创建
                        dialog.dismiss();
                    }
                }).show();
    }

    private void showErrorDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_training_plan_creating_error)
                .positiveText(R.string.activity_training_plan_get_plan_again)
                .negativeText(R.string.activity_training_plan_get_plan_give_up)
                .cancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        finish();
                    }
                })
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://再次创建
                                createTrainPlan();
                                break;
                            case NEGATIVE:
                                finish();
                                break;
                        }
                    }
                }).show();
    }

    private void guide() {
        boolean isFirstGuide = PrefsHelper.with(this, Config.PREFS_SPORT).readBoolean(Config.SP_KEY_IS_FIRST_CREATE_TRAIN_PLAN, true);
        if (isFirstGuide) {
            stepProgressView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    int[] location = new int[2];
                    stepProgressView.getLocationOnScreen(location);
//                    int[] dimension = {60, stepProgressView.getHeight()};
//                    GuiderDialog dialog = new GuiderDialog(CreateTrainPlanActivity.this, R.drawable.create_train_plan_back_guide, location, dimension, 5);
//                    dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//                        @Override
//                        public void onRewardsDialogDismiss(DialogInterface dialog) {
//                            dialog.dismiss();
//                        }
//                    });
//                    dialog.show();
                }
            }, 1000);//1秒后

            //保存到shared
            PrefsHelper.with(this, Config.PREFS_SPORT).writeBoolean(Config.SP_KEY_IS_FIRST_CREATE_TRAIN_PLAN, false);
        }
    }

    public void showFragment(int position) {
        if (!canChangePage) return;
        stepProgressView.setCurrentStep(position);
        switch (position) {
            case 1:
                switchFragment(getFirstFragment(), 1);
                break;
            case 2:
                switchFragment(getSecondFragment(), 2);
                guide();
                break;
            case 3:
                switchFragment(getThirdFragment(), 3);
                break;
            case 4:
                if (runProject < 3) {//选择了分钟
                    switchFragment(getFifthFragment(), 5);
                    stepProgressView.setStepTitles(getStepTitle(false));
                } else {
                    switchFragment(getFourthFragment(), 4);
                    stepProgressView.setStepTitles(getStepTitle(true));
                }
                break;
            case 5:
                switchFragment(getFifthFragment(), 5);
                break;
        }
    }

    private CreateTrainPlanFirstFragment getFirstFragment() {
        if (firstFragment == null) {
            firstFragment = new CreateTrainPlanFirstFragment();
            String title;
            switch (mode) {
                case 0:
                    title = getString(R.string.activity_create_training_plan_competition_item);
                    break;
                case 1:
                    title = getString(R.string.activity_create_training_plan_target_item);
                    break;
                default:
                    title = getString(R.string.activity_create_training_plan_competition_item);
            }
            firstFragment.setTitle(title);
        }
        return firstFragment;
    }

    private CreateTrainPlanSecondFragment getSecondFragment() {
        if (secondFragment == null) {
            secondFragment = new CreateTrainPlanSecondFragment();
            String title;
            switch (mode) {
                case 0:
                    title = getString(R.string.activity_create_training_plan_competition_start_time);
                    break;
                case 1:
                    title = getString(R.string.activity_create_training_plan_target_start_time);
                    break;
                default:
                    title = getString(R.string.activity_create_training_plan_competition_start_time);
            }
            secondFragment.setTitle(title);
        }
        if (mode == 0)
            secondFragment.setMinDate(getMinTime(target));
        return secondFragment;
    }

    private CreateTrainPlanThirdFragment getThirdFragment() {
        if (thirdFragment == null) {
            thirdFragment = new CreateTrainPlanThirdFragment();
        }
        return thirdFragment;
    }

    private CreateTrainPlanFourthFragment getFourthFragment() {
        if (fourthFragment == null) {
            fourthFragment = new CreateTrainPlanFourthFragment();
        }
        String itemName = "";
        switch (runProject) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                itemName = getString(R.string.activity_create_training_plan_five_kilometre);
                break;
            case 4:
                itemName = getString(R.string.activity_create_training_plan_ten_kilometre);
                break;
            case 5:
                itemName = getString(R.string.activity_create_training_plan_half_marathon);
                break;
            case 6:
                itemName = getString(R.string.activity_create_training_plan_marathon);
                break;
        }
        fourthFragment.setTrainRunProjectTitle(itemName);
        return fourthFragment;
    }

    public CreateTrainPlanFifthFragment getFifthFragment() {
        if (fifthFragment == null) {
            fifthFragment = new CreateTrainPlanFifthFragment();
            String title;
            switch (mode) {
                case 0:
                    title = getString(R.string.activity_create_training_plan_competition_start_time);
                    break;
                case 1:
                    title = getString(R.string.activity_create_training_plan_target_start_time);
                    break;
                default:
                    title = getString(R.string.activity_create_training_plan_competition_start_time);
            }
            fifthFragment.setStartTimeTitle(title);
        }

        String runProjectName = "";
        switch (runProject) {
            case 0:
                runProjectName = getString(R.string.activity_create_training_plan_less_twenty_minute);
                break;
            case 1:
                runProjectName = getString(R.string.activity_create_training_plan_less_thirty_minute);
                break;
            case 2:
                runProjectName = getString(R.string.activity_create_training_plan_less_sixty_minute);
                break;
            case 3:
                runProjectName = getString(R.string.activity_create_training_plan_five_kilometre);
                break;
            case 4:
                runProjectName = getString(R.string.activity_create_training_plan_ten_kilometre);
                break;
            case 5:
                runProjectName = getString(R.string.activity_create_training_plan_half_marathon);
                break;
            case 6:
                runProjectName = getString(R.string.activity_create_training_plan_marathon);
                break;
        }
        fifthFragment.setRunProject(runProjectName, runProject);
        fifthFragment.setCurrentProject(runProjectName);
        fifthFragment.setUseTime(projectTime);
        fifthFragment.setStartTime(startTime);
        fifthFragment.setTargetItem(target);
        return fifthFragment;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setRunProject(int runProject) {
        this.runProject = runProject;
    }

    public void setProjectTime(long projectTime) {
        this.projectTime = projectTime;
    }

    private int getRunDistance() {
        return target;
    }

    private long getCompetitionTime() {
        long competitionTime = 0;
        if (mode == 0) {
            competitionTime = startTime;
        } else if (mode == 1) {
            competitionTime = 0;
        }
        return competitionTime;
    }

    private long getPlanStartTime() {
        long PlanStartTime = 0;
        if (mode == 0) {
            PlanStartTime = System.currentTimeMillis();
        } else if (mode == 1) {
            PlanStartTime = startTime;
        }
        return PlanStartTime;
    }

    private int getAbilityProject() {
        return runProject;
    }

    private long getAbilityProjectUseTime() {
        if (runProject < 3) {
            return 0;
        }
        return projectTime;
    }

    /**
     * 获取选择日期的最短时间
     */
    public long getMinTime(int targetProject) {
        long time = 0;
        switch (targetProject) {
            case 3:
                time = getDelayTime(147);
                break;
            case 2:
                time = getDelayTime(119);
                break;
            case 1:
                time = getDelayTime(35);
                break;
            case 0:
                time = getDelayTime(28);
                break;
        }
        return time;
    }

    private long getDelayTime(int day) {
        return System.currentTimeMillis() + day * 24 * 60 * 60 * 1000L;
    }
}

