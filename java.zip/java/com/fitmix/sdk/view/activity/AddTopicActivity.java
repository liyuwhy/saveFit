package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.StringUtils;
import com.fitmix.sdk.model.api.bean.AddTopic;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.UploadImage;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.richeditor.RichEditor;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 添加话题界面
 */
public class AddTopicActivity extends BaseActivity {

    private EditText txt_topic_title;
    private ImageView btn_insert_pic;
    private RichEditor txt_supplementary;
    private View status_upload;

    private String content;
    private boolean isSubmit = false;//防止重复提交


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_topic);
        setPageName("AddTopicActivity");

        initToolbar();
        initViews();

    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        txt_topic_title = (EditText) findViewById(R.id.txt_topic_title);
        btn_insert_pic = (ImageView) findViewById(R.id.btn_insert_pic);
        txt_supplementary = (RichEditor) findViewById(R.id.txt_supplementary);

        txt_supplementary.setEditorHeight(200);
        txt_supplementary.setEditorFontSize(18);
        txt_supplementary.setEditorFontColor(Color.BLACK);
        txt_supplementary.setPadding(10, 10, 10, 10);
        String hint = getString(R.string.activity_add_topic_supply_hint);
        txt_supplementary.setPlaceholder(hint);
        txt_supplementary.setOnTextChangeListener(new RichEditor.OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                content = text;
            }
        });

        txt_supplementary.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (btn_insert_pic != null) {
                        btn_insert_pic.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (btn_insert_pic != null) {
                        btn_insert_pic.setVisibility(View.GONE);
                    }
                }
            }
        });

        status_upload = findViewById(R.id.status_upload);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_COMPETITION + 11://添加话题
                isSubmit = false;
                hideLoadingDialog();
                Logger.i(Logger.DATA_FLOW_TAG, "添加话题:" + result);
                AddTopic addTopic = JsonHelper.getObject(result, AddTopic.class);
                if (addTopic != null) {
                    if (addTopic.getCode() == 0 || addTopic.getTheme() != null) {
                        showAppMessage(R.string.activity_add_topic_success, AppMsg.STYLE_ALERT);
                        setResult(RESULT_OK);
                        if (txt_topic_title != null) {
                            txt_topic_title.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    finish();
                                }
                            }, 1000);
                        } else {
                            finish();
                        }
                    } else {
                        if (!TextUtils.isEmpty(addTopic.getMsg())) {
                            showAppMessage(addTopic.getMsg(), AppMsg.STYLE_ALERT);
                        }
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 15://上传图片
                Logger.i(Logger.DATA_FLOW_TAG, "上传图片:" + result);
                setUploadStatus(false);
                UploadImage uploadImage = JsonHelper.getObject(result, UploadImage.class);
                if (uploadImage != null) {
                    String link = uploadImage.getLink();
                    if (!TextUtils.isEmpty(link)) {
                        insertImageTag(link);
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            String msg = bean.getMsg();
            switch (requestId) {
                case Config.MODULE_COMPETITION + 11://添加话题
                    hideLoadingDialog();
                    isSubmit = false;
                    break;

                case Config.MODULE_COMPETITION + 15://上传图片
                    if (!TextUtils.isEmpty(msg)) {
                        showAppMessage(msg, AppMsg.STYLE_ALERT);
                    }
                    setUploadStatus(false);
                    break;
            }
        }
        super.processReqError(requestId, error);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuItem menuItem = menu.add(0, Menu.FIRST, Menu.NONE, R.string.activity_add_topic_add);
        if (menuItem != null) {//调整样式
            menuItem.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case Menu.FIRST://提交问题
                submit();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 插入图片
     *
     * @param url 图片资源url
     */
    public void insertImageTag(String url) {
        if (txt_supplementary != null) {
            txt_supplementary.focusEditor();
            txt_supplementary.insertImage(url);
            Logger.i(Logger.DEBUG_TAG, "insertImageTag url:" + url);
        }
    }

    /**
     * 设置图片上传状态
     *
     * @param isUploading true:显示忙碌状态,false:隐藏忙碌状态
     */
    public void setUploadStatus(boolean isUploading) {
        if (isUploading) {
            if (txt_supplementary != null) {
                txt_supplementary.setEnabled(false);
            }
            if (btn_insert_pic != null) {
                btn_insert_pic.setEnabled(false);
            }
            if (status_upload != null) {
                status_upload.setVisibility(View.VISIBLE);
            }
        } else {
            if (txt_supplementary != null) {
                txt_supplementary.setEnabled(true);
            }
            if (btn_insert_pic != null) {
                btn_insert_pic.setEnabled(true);
            }
            if (status_upload != null) {
                status_upload.setVisibility(View.GONE);
            }
        }


    }

    /**
     * 提交问题
     */
    private void submit() {
        if (isSubmit)
            return;
        String topicTitle = txt_topic_title.getText().toString();
        if (StringUtils.isBlank(topicTitle)) {
            txt_topic_title.requestFocus();
            showAppMessage(R.string.activity_add_topic_title_empty, AppMsg.STYLE_ALERT);
            return;
        }

        if (topicTitle.length() < 3) {
            txt_topic_title.requestFocus();
            showAppMessage(R.string.activity_add_topic_title_short, AppMsg.STYLE_ALERT);
            return;
        }

//        if (StringUtils.isBlank(content)) {
//            txt_supplementary.focusEditor();
//            showAppMessage(R.string.activity_add_topic_content_empty, AppMsg.STYLE_ALERT);
//            return;
//        }

        Logger.i(Logger.DEBUG_TAG, "add topic topicTitle:" + topicTitle + ",content:" + content);
        String encodeContent = "";//content;
        if (content != null) {
            try {//需要对内容进行一次URLEncode
                encodeContent = URLEncoder.encode(content, "UTF-8");
                Logger.i(Logger.DEBUG_TAG, "AddTopicActivity-->submit Url encode content:" + encodeContent);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        isSubmit = true;
        MyConfig.getInstance().getMemExchange().setTopicContent("topicSupplementary", encodeContent);
        int requestId = DiscoverDataManager.getInstance().addTopic(topicTitle, "topicSupplementary", true);
        registerDataReqStatusListener(requestId);
        showLoadingDialog(R.string.busying, 1000);
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.btn_insert_pic:
                CropImage.startPickImageActivity(this);
                break;
        }
    }

    /**
     * 上传图片
     */
    private void uploadImage(Uri imageUri) {
        if (imageUri == null || TextUtils.isEmpty(imageUri.getPath())) {
            showAppMessage(R.string.activity_add_topic_add_image_fail, AppMsg.STYLE_ALERT);
            return;
        }
        //1.先调整图片大小
        String rawFile = FitmixUtil.getRealPathFromUri(this, imageUri);
        String photoFile = FitmixUtil.getTempPath() + System.currentTimeMillis() + ".jpg";
        boolean isRestricted = ImageHelper.restrictPhotoToScreenWidth(this, rawFile, photoFile);
        Logger.i(Logger.DEBUG_TAG, "imageUri.getPath():" + imageUri.getPath() + ",photoFile:" + photoFile + ",isRestricted:" + isRestricted);
        setUploadStatus(true);
        int requestId = DiscoverDataManager.getInstance().uploadImage(isRestricted ? photoFile : rawFile, true);
        registerDataReqStatusListener(requestId);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    Logger.i(Logger.DEBUG_TAG, "AddTopicAnswerActivity uri:" + imageUri);
                    if (imageUri != null) {
                        //上传图片
                        uploadImage(imageUri);
                    }


//                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
//                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
//                        // request permissions and handle the result in onRequestPermissionsResult()
//                        mCropImageUri = imageUri;
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
//                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
//                    } else {
//                      //上传图片
//                      uploadImage();
//                    }
                }
                break;
        }
    }
}
