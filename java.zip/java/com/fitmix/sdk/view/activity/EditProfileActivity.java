package com.fitmix.sdk.view.activity;


import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.FileUtils;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.fresco.FrescoHelper;
import com.fitmix.sdk.common.share.AccessTokenKeeper;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.Login;
import com.fitmix.sdk.model.api.bean.User;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.dialog.NumberPickerFragment;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;
import com.sina.weibo.sdk.auth.Oauth2AccessToken;

import java.io.File;

public class EditProfileActivity extends BaseActivity {

    /**
     * 用户头像图片宽度,240px
     */
    public static final int USER_AVATAR_WIDTH = 240;
    /**
     * 用户头像图片高度,240px
     */
    public static final int USER_AVATAR_HEIGHT = 240;
    private SimpleDraweeView img_user_avatar;

    private EditText edit_nickname;
    private EditText edit_signature;
    private TextView tv_gender;
    private TextView tv_age;
    private TextView tv_unit_type;
    private TextView tv_height;
    private TextView tv_weight;
    private TextView tv_signature_limit;
    private Button btn_contestant_info;

    private NumberPickerFragment numberPickerFragment;

    private boolean bFemale;
    private boolean bEnglishUnit;
    private int mAge;

    private int mHeight;
    private int mWeight;
    private String sName;
    private String sSignature;
    private boolean bAvatarChanged = false;
    private String idCard;

    private User user;
//    private boolean toSetAvatar = false;
    /**
     * 金币任务,完善个人资料是否完成
     */
    private boolean coinTaskCompletePersonalInfo;

    //    private int photoId;
    private Uri mCropImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        setPageName("EditProfileActivity");
        initToolbar();
        initViews();
        getDataFromDBOrNet();
        coinTaskCompletePersonalInfo = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_COMPLETE_PERSONAL_INFO, true);
//        Logger.i(Logger.DEBUG_TAG, "EditProfileActivity coinTaskCompletePersonalInfo:" + coinTaskCompletePersonalInfo);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        if (!toSetAvatar) {
//            //防止选取完头像照片回来刷新数据（头像数据保存在数据库未更改）
//            getDataFromDBOrNet();
//        } else {
//            toSetAvatar = false;
//        }
    }

    /**
     * 初始化视图
     */
    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        img_user_avatar = (SimpleDraweeView) findViewById(R.id.img_user_avatar);
        edit_nickname = (EditText) findViewById(R.id.txt_nickname);
        edit_signature = (EditText) findViewById(R.id.edit_signature);
        tv_signature_limit = (TextView) findViewById(R.id.tv_signature_limit);
        edit_signature.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int number = edit_signature.getText().length();
                tv_signature_limit.setText(String.format(getString(R.string.activity_create_playlist_playlist_description_tips), 40 - number));
            }
        });
        tv_gender = (TextView) findViewById(R.id.tv_gender);
        tv_age = (TextView) findViewById(R.id.tv_age);
        btn_contestant_info = (Button) findViewById(R.id.btn_contestant_info);
        tv_unit_type = (TextView) findViewById(R.id.tv_unit_type);
        tv_height = (TextView) findViewById(R.id.tv_height);
        tv_weight = (TextView) findViewById(R.id.tv_weight);
    }

    /**
     * 获取个人信息
     */
    private void getUserData(User user) {
        if (user != null) {
            mAge = user.getAge() > 0 ? user.getAge() : Config.USER_DEFAULT_AGE;
            mHeight = user.getHeight() > 0 ? user.getHeight() : Config.USER_DEFAULT_HEIGHT;
            mWeight = user.getWeight() > 0 ? user.getWeight() : Config.USER_DEFAULT_WEIGHT;
            sName = user.getName();
            bFemale = user.getGender() == Config.GENDER_FEMALE;
            bEnglishUnit = user.getType() == Config.UNIT_TYPE_ENGLISH;
            sSignature = user.getSignature();
            if (user.getUserRealInfo() != null) {
                idCard = user.getUserRealInfo().getIdCard();
            }
        }
    }

    /**
     * 重新根据登录种类获取用户资料
     */
    private void getDataFromDBOrNet() {
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType == 1 || loginType == 5) {//邮箱账号登录
            String email = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_USER);
            String password = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password))
                return;
            int requestId = UserDataManager.getInstance().emailLogin(email, password);
            registerDataReqStatusListener(requestId);
        } else if (loginType == 2) {//表示QQ授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.QQ_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                Logger.i(Logger.DEBUG_TAG, "openid:" + openid + " tokenId:" + tokenId);
                int requestId = UserDataManager.getInstance().qqLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 3) {//表示微信授权登录
            String openid = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_OPENID);
            String tokenId = PrefsHelper.with(this, AccessTokenKeeper.WECHAT_OAUTH_NAME).read(AccessTokenKeeper.KEY_ACCESS_TOKEN);
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiXinLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        } else if (loginType == 4) {//表示新浪微博授权登录
            Oauth2AccessToken weiboToken = AccessTokenKeeper.readSinaAccessToken(this);
            String openid = weiboToken.getUid();
            String tokenId = weiboToken.getToken();
            if (!TextUtils.isEmpty(openid)
                    && !TextUtils.isEmpty(tokenId)) {
                int requestId = UserDataManager.getInstance().weiBoLogin(tokenId, openid);
                registerDataReqStatusListener(requestId);
            }
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null)
            return;

        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);

        //获取个人信息数据返回的信息
        switch (requestId) {
            case Config.MODULE_USER + 2:
            case Config.MODULE_USER + 3:
            case Config.MODULE_USER + 4:
            case Config.MODULE_USER + 5:
                Login login = JsonHelper.getObject(result, Login.class);
                if (login != null) {
                    //设置我的界面,个人信息、运动总时长、总消耗、总步数、总距离(在登录接口中)
                    user = login.getUser();
                    getUserData(user);//获取数据
                    refreshInitData();//更新界面
                    refresh();
                }
                break;

            case Config.MODULE_USER + 7://修改个人信息
                hideLoadingDialog();
                setUserDataUseLess();//上传成功了,更改数据库个人信息的有效期为过期
                if (!coinTaskCompletePersonalInfo) {
                    finishCompletePersonalInfoCoinTask();
                } else {
                    setResult(Activity.RESULT_OK);//设置结果为成功,返回mainActivity更新个人信息
                    finish();
                }
                break;

            case Config.MODULE_USER + 52://完成完善个人资料任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                    if (accountFlowEntity != null) {
                        SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_COMPLETE_PERSONAL_INFO, true);//完善个人资料金币任务完成

                        showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription(),
                                new QuestRewardsDialog.OnQuestRewardsDialogDismiss() {
                                    @Override
                                    public void onRewardsDialogDismiss() {//奖励金币确定后,销毁activity
                                        setResult(Activity.RESULT_OK);//设置结果为成功,返回mainActivity更新个人信息
                                        finish();
                                    }
                                });
                    }
                }
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        switch (requestId) {
            case Config.MODULE_USER + 7:
                hideLoadingDialog();
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;

            case Config.MODULE_USER + 52://完成完善个人资料任务
                if (bean != null) {
                    if (bean.getCode() == 9002) {//任务已完成
                        finish();
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                        super.processReqError(requestId, error);
                    }
                }
                break;
        }
    }

    private void refreshInitData() {
        if (edit_nickname != null && sName != null) {
            edit_nickname.setText(sName);
        }
        if (user != null) {
            if (TextUtils.isEmpty(user.getAvatar())) {//默认头像
                img_user_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
            } else {
                String localFile = FitmixUtil.getPhotoPath() + user.getId() + "_avatar.jpg";
                if (FileUtils.isFileExist(localFile)) {//本地有图片,则从本地加载
                    img_user_avatar.setImageURI(Uri.fromFile(new File(localFile)));
                } else {
                    Fresco.getImagePipeline().evictFromCache(Uri.parse(user.getAvatar()));
                    img_user_avatar.setImageURI(Uri.parse(user.getAvatar()));
                    FrescoHelper.saveImage2Local(MixApp.getContext(), user.getAvatar(), localFile);
                }
            }
        }
    }

    /**
     * 刷新界面
     */
    private void refresh() {
        tv_age.setText(String.format("%02d", mAge));

        String[] gender = getResources().getStringArray(R.array.gender);
        tv_gender.setText(gender[bFemale ? 0 : 1]);
        tv_height.setText(String.valueOf(mHeight));
        tv_weight.setText(String.valueOf(mWeight));

        String[] unit = getResources().getStringArray(R.array.unit);
        tv_unit_type.setText(unit[bEnglishUnit ? 1 : 0]);
        edit_signature.setText(sSignature);
        btn_contestant_info.setText(TextUtils.isEmpty(idCard) ?
                getString(R.string.activity_edit_profile_contestant_info_none) :
                getString(R.string.activity_edit_profile_contestant_info_ready));
    }

    private void showSaveDialog() {
        sName = edit_nickname.getText().toString();
        sSignature = edit_signature.getText().toString();
        if (user == null || TextUtils.isEmpty(sName) || TextUtils.isEmpty(sSignature)) {
            finish();
            return;
        }
        if ((!bAvatarChanged)
                && (sSignature.equals(user.getSignature()))
                && sName.equals(user.getName())
                && (mAge == user.getAge())
                && (mHeight == user.getHeight())
                && (mWeight == user.getWeight())
                && (bEnglishUnit == (user.getType() == Config.UNIT_TYPE_ENGLISH))
                && (bFemale == (user.getGender() == Config.GENDER_FEMALE))
                ) {
            finish();
        } else {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.activity_edit_profile_dialog_save_prompt)
                    .positiveText(R.string.activity_edit_profile_dialog_save_button)
                    .negativeText(R.string.cancel)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    processModifyPersonInfo();
                                    break;
                                case NEGATIVE:
                                    finish();
                                    break;
                            }
                        }
                    }).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                showSaveDialog();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
//        if (getMyConfig().isLogOut())
//            Log.d(getMyConfig().getTag(), "onBackPressed");
        showSaveDialog();
    }


    public void doClick(View v) {
        int min;
        int max;
        int unit;
        switch (v.getId()) {
            case R.id.btn_change_avatar://更换头像
//                onPickImage(img_user_avatar);
                CropImage.startPickImageActivity(this);
                break;

            case R.id.tv_gender://选择性别
                int gender = bFemale ? 0 : 1;//0为女,1为男
                showNumberPickerDialog(R.string.dialog_pick_gender_title, gender, R.array.gender, tv_gender, 0,
                        R.string.activity_edit_profile_dialog_positive_button, R.string.activity_edit_profile_dialog_negative_button
                        , new NumberPickerFragment.OnNumberSetListener() {
                            @Override
                            public void onNumberSet(Integer number, View v) {
                                String[] gender = getResources().getStringArray(R.array.gender);
                                ((TextView) v).setText(gender[number]);
                                bFemale = number == 0;

                            }
                        }, "genderPicker");
                break;

            case R.id.tv_age://选择年龄
                showNumberPickerDialog(R.string.dialog_pick_age_title, mAge, 6, 100, tv_age,
                        R.string.dialog_pick_age_unit,
                        R.string.activity_edit_profile_dialog_positive_button, R.string.activity_edit_profile_dialog_negative_button
                        , new NumberPickerFragment.OnNumberSetListener() {
                            @Override
                            public void onNumberSet(Integer number, View v) {
                                ((TextView) v).setText(String.valueOf(number));
                                mAge = number;
                            }
                        }, "agePicker");

                break;

            case R.id.tv_unit_type://选择单位制度
                int unitType = bEnglishUnit ? 1 : 0;//0为国际标准,1为英制单位
                showNumberPickerDialog(R.string.dialog_pick_unit_title, unitType, R.array.unit, tv_unit_type, 0,
                        R.string.activity_edit_profile_dialog_positive_button, R.string.activity_edit_profile_dialog_negative_button
                        , new NumberPickerFragment.OnNumberSetListener() {
                            @Override
                            public void onNumberSet(Integer number, View v) {
                                String[] units = getResources().getStringArray(R.array.unit);
                                ((TextView) v).setText(units[number]);
                                bEnglishUnit = number != 0;
                                if (bEnglishUnit) {
                                    mHeight = (int) (mHeight * 0.3937008f);
                                    mWeight = (int) (mWeight * 2.2046226f);
                                } else {
                                    mHeight = (int) (mHeight * 2.54f);
                                    mWeight = (int) (mWeight * 0.4535924f);
                                }
                                refresh();
                            }
                        }, "genderPicker");
                break;

            case R.id.tv_height://选择身高
                if (bEnglishUnit) {//英制
                    min = 39;
                    max = 87;
                    unit = R.string.dialog_pick_english_height_unit;
                } else {
                    min = 100;
                    max = 220;
                    unit = R.string.dialog_pick_height_unit;
                }
                showNumberPickerDialog(R.string.dialog_pick_height_title, mHeight, min, max, tv_height,
                        unit,
                        R.string.activity_edit_profile_dialog_positive_button, R.string.activity_edit_profile_dialog_negative_button
                        , new NumberPickerFragment.OnNumberSetListener() {
                            @Override
                            public void onNumberSet(Integer number, View v) {
                                ((TextView) v).setText(String.valueOf(number));
                                mHeight = number;
                            }
                        }, "heightPicker");
                break;

            case R.id.tv_weight://选择体重

                if (bEnglishUnit) {//英制
                    min = 44;
                    max = 275;
                    unit = R.string.dialog_pick_english_weight_unit;
                } else {
                    min = 20;
                    max = 125;
                    unit = R.string.dialog_pick_weight_unit;
                }
                showNumberPickerDialog(R.string.dialog_pick_weight_title, mWeight, min, max, tv_weight,
                        unit,
                        R.string.activity_edit_profile_dialog_positive_button, R.string.activity_edit_profile_dialog_negative_button
                        , new NumberPickerFragment.OnNumberSetListener() {
                            @Override
                            public void onNumberSet(Integer number, View v) {
                                ((TextView) v).setText(String.valueOf(number));
                                mWeight = number;
                            }
                        }, "weightPicker");
                break;
            case R.id.btn_contestant_info://设置个人信息
                if (user == null) return;
                editProfile();
                break;
            case R.id.btn_save://完成
                processModifyPersonInfo();
                break;
        }
    }


    private void editProfile() {
        if (user != null) {
            if (TextUtils.isEmpty(user.getMobile()) && user.getUserRealInfo() == null) {//没有手机绑定过的用户
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.activity_edit_profile_bind_mobile)
                        .positiveText(R.string.activity_edit_profile_bind_mobile_sure)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        startPhoneBindActivity();
                                        break;
                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
            } else {
                View convertView = getLayoutInflater().inflate(R.layout.dialog_confirm_password, null);
                final EditText editText = (EditText) convertView.findViewById(R.id.et_confirm_password);
                final String pwd = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_LAST_PWD);
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .customView(convertView, true)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        String confirmPWD = editText.getText().toString();
                                        if (!pwd.equals(confirmPWD)) {
                                            showErrorMsg();
                                        } else {
                                            startToContestantActivity();
                                        }
                                        break;
                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
            }
        }
    }

    private void startPhoneBindActivity() {
        if (user != null) {
            Intent intent = new Intent();
            if (TextUtils.isEmpty(user.getEmail())) {//邮箱注册过的用户 代表有密码
                intent.putExtra("PhoneBindWithPWD", true);
            } else {
                intent.putExtra("PhoneBind", true);
            }
            intent.putExtra("isGoToContestantActivity", true);
            intent.setClass(this, PhoneBindActivity.class);
            startActivity(intent);
        }
    }

    private void startToContestantActivity() {
        if (TextUtils.isEmpty(SettingsHelper.getString(Config.SETTING_USER_ID_CARD, ""))) {// 该用户是否填写过资料
            startContestantInfoEditActivity();
        } else {
            startContestantInfoActivity();
        }
    }

    private void showErrorMsg() {
        showAppMessage(getString(R.string.rsp_error_password_error), AppMsg.STYLE_ALERT);
    }

    private void startContestantInfoActivity() {
        Intent intent = new Intent();
        intent.putExtra("isModify", true);
        intent.setClass(this, ContestantInfoEditActivity.class);
        startActivity(intent);
    }

    private void startContestantInfoEditActivity() {
        Intent intent = new Intent();
        intent.setClass(this, ContestantInfoEditActivity.class);
        startActivity(intent);
    }


    /**
     * 显示数字选择对话框
     *
     * @param titleResId          对话框标题资源ID
     * @param initValue           对话框数值选择器初始值
     * @param minValue            对话框数值选择器最小值
     * @param maxValue            对话框数值选择器最大值
     * @param callBackView        对话框选择器回设View
     * @param unitResId           对话框单位资源ID
     * @param positiveButtonResId 对话框确定按钮文字资源ID
     * @param negativeButtonResId 对话框取消按钮文字资源ID
     * @param listener            对话框设置回调监听
     * @param tag                 对话框tag标签
     */
    private void showNumberPickerDialog(int titleResId, int initValue, int minValue, int maxValue, View callBackView, int unitResId,
                                        int positiveButtonResId, int negativeButtonResId, NumberPickerFragment.OnNumberSetListener listener, String tag) {
        numberPickerFragment = new NumberPickerFragment();
        numberPickerFragment.setTitle(titleResId);
        numberPickerFragment.setMinValue(minValue);
        numberPickerFragment.setMaxValue(maxValue);
        if (initValue <= maxValue && initValue >= minValue) {
            numberPickerFragment.setValue(initValue);
        }

        numberPickerFragment.setView(callBackView);
        numberPickerFragment.setUnit(unitResId);
        numberPickerFragment.setPositiveButtonText(positiveButtonResId);
        numberPickerFragment.setNegativeButtonText(negativeButtonResId);
        numberPickerFragment.setOnNumberSetListener(listener);
//        numberPickerFragment.show(getSupportFragmentManager(), tag);
        if (ftCanCommit)
            numberPickerFragment.show(getFragmentManager(), tag);
    }

    /**
     * 显示数字选择对话框
     *
     * @param titleResId           对话框标题资源ID
     * @param initValue            对话框数值选择器初始值
     * @param displayedValuesResId 对话框数值选择器显示的文字数组资源ID
     * @param callBackView         对话框选择器回设View
     * @param unitResId            对话框单位资源ID
     * @param positiveButtonResId  对话框确定按钮文字资源ID
     * @param negativeButtonResId  对话框取消按钮文字资源ID
     * @param listener             对话框设置回调监听
     * @param tag                  对话框tag标签
     */
    private void showNumberPickerDialog(int titleResId, int initValue, int displayedValuesResId, View callBackView, int unitResId,
                                        int positiveButtonResId, int negativeButtonResId, NumberPickerFragment.OnNumberSetListener listener, String tag) {
        numberPickerFragment = new NumberPickerFragment();
        numberPickerFragment.setTitle(titleResId);
        numberPickerFragment.setDisplayedValuesResId(displayedValuesResId);
        numberPickerFragment.setValue(initValue);

        numberPickerFragment.setView(callBackView);
        numberPickerFragment.setUnit(unitResId);
        numberPickerFragment.setPositiveButtonText(positiveButtonResId);
        numberPickerFragment.setNegativeButtonText(negativeButtonResId);
        numberPickerFragment.setOnNumberSetListener(listener);
//        numberPickerFragment.show(getSupportFragmentManager(), tag);
        if (ftCanCommit)
            numberPickerFragment.show(getFragmentManager(), tag);
    }

    /**
     * 错误检验
     *
     * @return Config.ERROR_NO_ERROR 成功
     * 其它         失败
     */
    private int checkInputError() {
        sSignature = edit_signature.getText().toString();
        sName = edit_nickname.getText().toString();
        if (TextUtils.isEmpty(sName)) {
            edit_nickname.requestFocus();
            return Config.ERROR_NICKNAME_EMPTY;
        }
        if (TextUtils.isEmpty(sSignature)) {
            edit_signature.requestFocus();
            return Config.ERROR_SIGNATURE_EMPTY;
        }
        if (mHeight == 0 || mWeight == 0 || mAge == 0) {
            return Config.ERROR_PERSON_DATA;
        }
        return Config.ERROR_NO_ERROR;
    }

    /**
     * 处理个人信息修改
     */
    private void processModifyPersonInfo() {
        int error = checkInputError();
        if (error != Config.ERROR_NO_ERROR) {
            showErrorMsg(error);
            return;
        }
        sendModifyPersonInfoRequest();
    }

    /**
     * 发送修改个人信息请求
     */
    private void sendModifyPersonInfoRequest() {
        if (user == null) return;
        if (bAvatarChanged) {//有更改头像时,上传头像
            String avatar = FitmixUtil.getPhotoPath() + user.getId() + "_avatar.jpg";
            int requestId = UserDataManager.getInstance().updateUserInfo(user.getId(), sName,
                    (bFemale ? Config.GENDER_FEMALE
                            : Config.GENDER_MALE), mAge, mHeight, mWeight,
                    (bEnglishUnit ? Config.UNIT_TYPE_ENGLISH
                            : Config.UNIT_TYPE_CHINESE), sSignature,
                    avatar, "file");
            registerDataReqStatusListener(requestId);
        } else { //不带头像上传的信息修改
            int requestId = UserDataManager.getInstance().updateUserInfo(user.getId(), sName,
                    (bFemale ? Config.GENDER_FEMALE
                            : Config.GENDER_MALE), mAge, mHeight, mWeight,
                    (bEnglishUnit ? Config.UNIT_TYPE_ENGLISH
                            : Config.UNIT_TYPE_CHINESE), sSignature,
                    null, "file");
            registerDataReqStatusListener(requestId);
        }
        showLoadingDialog(R.string.busying, 1000);
    }

//    /**
//     * 选取图像
//     *
//     * @param view 图像view
//     */
//    public void onPickImage(View view) {
//        CropImage.startPickImageActivity(this);
//    }

    /**
     * 启动图片剪裁界面
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(1, 1)//USER_AVATAR_WIDTH, USER_AVATAR_HEIGHT
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    if (imageUri == null)
                        break;
                    // For API >= 23 we need to check specifically that we have permissions to read external storage.
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        // request permissions and handle the result in onRequestPermissionsResult()
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        // no permissions required or already grunted, can start crop image activity
                        startCropImageActivity(imageUri);
                    }
                }
                break;

            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    if (bitmap != null) {//use bitmap
                        ((ImageView) (img_user_avatar)).setImageBitmap(bitmap);
                        if (user != null) {//替换原有文件夹里的头像
                            String localFile = FitmixUtil.getPhotoPath() + user.getId() + "_avatar.jpg";
                            ImageHelper.adjustPhotoToFitSize(bitmap, USER_AVATAR_WIDTH, USER_AVATAR_HEIGHT, localFile);
                            if (!TextUtils.isEmpty(user.getAvatar())) {//重置fresco缓存
                                Fresco.getImagePipeline().evictFromCache(Uri.parse(user.getAvatar()));
                                Fresco.getImagePipeline().evictFromCache(Uri.fromFile(new File(localFile)));
                            }
                        } else {
                            ImageHelper.adjustPhotoToFitSize(bitmap, USER_AVATAR_WIDTH, USER_AVATAR_HEIGHT, FitmixUtil.getTempPhotoFile());
                        }
                        bAvatarChanged = true;
                    }

                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;

            default:
                super.onActivityResult(requestCode, resultCode, data);
                break;
        }
    }


    //region ============================= 金币任务 =============================

    /**
     * 完成完善个人资料金币任务
     */
    private void finishCompletePersonalInfoCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_COMPLETE_PERSONAL_INFO, true);
        registerDataReqStatusListener(reqId);
    }

    //endregion ============================= 金币任务 =============================


}

