package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.MixApp;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.ImageHelper;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.common.UmengAnalysisHelper;
import com.fitmix.sdk.model.api.bean.AlbumList;
import com.fitmix.sdk.model.database.CustomAlbumHelper;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.DataReqStatusDao;
import com.fitmix.sdk.model.manager.MusicDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.MusicTabPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.bean.Album;
import com.fitmix.sdk.view.fragment.MusicTabItemFragment;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.cropper.CropImage;
import com.fitmix.sdk.view.widget.cropper.CropImageView;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.dao.query.QueryBuilder;

public class CreatePlaylistActivity extends BaseActivity {

    ///////////////////第一步//////////////////////////
    private View layout_select_songs;//选择歌曲布局
    private TabLayout tablayout;
    private ViewPager viewPager;
    private Button btn_view_selected;
    private MusicTabPagerAdapter adapter;
    private TextView tv_empty_view;

    private ArrayList<MusicTabItemFragment> fragmentList;
    private List<Album> albums;

    private ArrayList<Integer> musicId;

    private List<Integer> musicList = new ArrayList<>();//保存歌曲ID

    ///////////////////第二步//////////////////////////
    private ScrollView scrollView;//创建歌单布局
    private EditText txt_playlist_name;
    private EditText txt_playlist_description;
    private TextView tv_desc_number_limit;

    private boolean isSelectSingle;//检验此界面的打开方式
    private boolean FromAlbumList;//检验此界面的打开方式

    private int id;
    private int photoId;
    private Uri mCropImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_playlist);
        setPageName("CreatePlaylistActivity");
        Intent intent = getIntent();
        if (intent != null) {
            isSelectSingle = intent.getBooleanExtra("single", false);
            FromAlbumList = intent.getBooleanExtra("FromAlbum", false);
            musicId = intent.getIntegerArrayListExtra("MusicId");
        }
        initToolbar();
        initViews();
        if (!FromAlbumList) {
            initData();
        }
        FitmixUtil.deleteTempPhotoFile();
    }

    private List<Album> getAlbumList() {
        DataReqStatusDao dataReqStatusDao = MixApp.getDaoSession(MixApp.getContext()).getDataReqStatusDao();
        QueryBuilder<DataReqStatus> qb = dataReqStatusDao.queryBuilder();
        qb.where(DataReqStatusDao.Properties.RequestId.eq(Config.MODULE_MUSIC + 1));
        List<Album> list = new ArrayList<>();
        if (qb.list().size() == 0) return list;
        DataReqStatus dataReqStatus = qb.list().get(0);
        if (dataReqStatus != null) {
            String sResult = dataReqStatus.getResult();
            AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
            if (albumList != null) {
                list.addAll(albumList.getList());
            }
        }
        if (OperateMusicUtils.getAlbumNumber() > 0) {
            list.addAll(OperateMusicUtils.getAlbumList());
        }
        return list;
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
////        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
//        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_MUSIC + 1:
                //hideLoadingDialog();
                getAlbumList(dataReqResult.getResult());
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        //hideLoadingDialog();
        tv_empty_view.setVisibility(View.VISIBLE);
    }

    /**
     * 从网络获取列表
     */
    private void getAlbumList(String sResult) {
        AlbumList albumList = JsonHelper.getObject(sResult, AlbumList.class);
        List<Album> list = new ArrayList<>();
        if (albumList != null) {
            list.addAll(albumList.getList());
        }
        if (OperateMusicUtils.getAlbumNumber() > 0) {
            list.addAll(OperateMusicUtils.getAlbumList());
        }
        refreshAlbumList(list);
    }

    /**
     * 刷新专辑列表
     *
     * @param list List<Album>
     */
    private void refreshAlbumList(List<Album> list) {
        if (list.size() == 0) {
            tv_empty_view.setVisibility(View.VISIBLE);
            return;
        }
        for (int i = 0; i < list.size() + 4; i++) {
            if (i == 0) {
                //对是否导入第三方歌曲进行判定
                if (OperateMusicUtils.getLocalMusicNumber() > 0) {
                    MusicTabItemFragment fm1 = new MusicTabItemFragment();
                    Album album = new Album();
                    album.setValue(1000);
                    album.setName(getString(R.string.activity_create_playlist_local));
                    albums.add(album);
                    String albumString = JsonHelper.createJsonString(album);
                    Bundle mBundle = new Bundle();
                    mBundle.putString("album", albumString);
                    mBundle.putBoolean("isSelectSingle", isSelectSingle);
                    fm1.setArguments(mBundle);
                    fragmentList.add(fm1);
                }
            } else if (i == 1) {
                // 获取已经下载过的歌曲列表
                if (OperateMusicUtils.getDownloadedMusicNumber() > 0) {
                    MusicTabItemFragment fm1 = new MusicTabItemFragment();
                    Album album = new Album();
                    album.setValue(1001);
                    album.setName(getString(R.string.activity_create_playlist_local));
                    albums.add(album);
                    String albumString = JsonHelper.createJsonString(album);
                    Bundle mBundle = new Bundle();
                    mBundle.putString("album", albumString);
                    mBundle.putBoolean("isSelectSingle", isSelectSingle);
                    fm1.setArguments(mBundle);
                    fragmentList.add(fm1);
                }
            } else if (i == 2) {
                // 获取查找收藏的歌曲
                if (OperateMusicUtils.getFavoriteMusicNumber() > 0) {
                    MusicTabItemFragment fm3 = new MusicTabItemFragment();
                    Album album = new Album();
                    album.setValue(1002);
                    album.setName(getString(R.string.activity_create_playlist_favorite));
                    albums.add(album);
                    String albumString = JsonHelper.createJsonString(album);
                    Bundle mBundle = new Bundle();
                    mBundle.putString("album", albumString);
                    mBundle.putBoolean("isSelectSingle", isSelectSingle);

                    fm3.setArguments(mBundle);
                    fragmentList.add(fm3);
                }
            } else if (i == 3) {
                // 获取最近播放的列表
                if (OperateMusicUtils.getRecentMusicNumber() > 0) {
                    MusicTabItemFragment fm4 = new MusicTabItemFragment();
                    Album album = new Album();
                    album.setValue(1003);
                    album.setName(getString(R.string.activity_create_playlist_recent));
                    albums.add(album);
                    String albumString = JsonHelper.createJsonString(album);
                    Bundle mBundle = new Bundle();
                    mBundle.putString("album", albumString);
                    mBundle.putBoolean("isSelectSingle", isSelectSingle);
                    fm4.setArguments(mBundle);
                    fragmentList.add(fm4);
                }
            } else {
                MusicTabItemFragment fm = new MusicTabItemFragment();
                albums.add(list.get(i - 4));
                Bundle mBundle = new Bundle();
                String albumString = JsonHelper.createJsonString(list.get(i - 4));
                mBundle.putString("album", albumString);
                mBundle.putBoolean("isSelectSingle", isSelectSingle);

                fm.setArguments(mBundle);
                fragmentList.add(fm);
            }
        }
        getMusicTabPagerAdapter().setList(fragmentList);
        tablayout.removeAllTabs();
        for (int i = 0; i < albums.size(); i++) {
            tablayout.addTab(tablayout.newTab().setText(albums.get(i).getName()), i);
        }
    }

    private void initData() {
        fragmentList = new ArrayList<>();
        albums = new ArrayList<>();
        List<Album> list = getAlbumList();
        if (list.size() == 0) {
            sendAlbumListRequest();
        } else {
            refreshAlbumList(list);
        }
    }

    /**
     * 发送请求
     */
    private void sendAlbumListRequest() {
        //showLoadingDialog(R.string.swipelayout_loading, 1001);
        int requestId = MusicDataManager.getInstance().getAlbumList(Config.REQUEST_MUSIC_ALBUM, false);
        registerDataReqStatusListener(requestId);
    }

    private List<Integer> getMusicSelectList() {
        return musicList;
    }

    private MusicTabPagerAdapter getMusicTabPagerAdapter() {
        if (adapter == null) adapter = new MusicTabPagerAdapter(getSupportFragmentManager());
        return adapter;
    }

    public void setSingleMusic(Music music) {
        //getMyConfig().getMemExchange().setCurrentMusic(music);
        Intent intent = new Intent();//这个
        if (music != null) {
            String musicString = JsonHelper.createJsonString(music);
            intent.putExtra("musicString", musicString);
        }
        setResult(RESULT_OK, intent);
        finish();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        if (isSelectSingle) {
            setUiTitle(getString(R.string.activity_create_playlist_choose_music));
        }

        tv_empty_view = (TextView) findViewById(R.id.tv_empty_view);
        ///////////////////第一步//////////////////////////
        layout_select_songs = findViewById(R.id.layout_select_songs);
        if (!FromAlbumList) {
            tablayout = (TabLayout) findViewById(R.id.tablayout);
            tablayout.setTabMode(TabLayout.MODE_SCROLLABLE);//可滚动

            viewPager = (ViewPager) findViewById(R.id.viewpager_songs);
            viewPager.setAdapter(getMusicTabPagerAdapter());
            viewPager.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                }

                @Override
                public void onPageSelected(int position) {

                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
            tablayout.setupWithViewPager(viewPager); // todo
            LinearLayout btn_group = (LinearLayout) findViewById(R.id.btn_group);
            if (!isSelectSingle) {
                btn_group.setVisibility(View.VISIBLE);
            }
            btn_view_selected = (Button) findViewById(R.id.btn_view_selected);
            setSelectedSongsButtonText();
        }

        ///////////////////第二步//////////////////////////
        scrollView = (ScrollView) findViewById(R.id.scrollView);

        txt_playlist_name = (EditText) findViewById(R.id.txt_playlist_name);
        txt_playlist_description = (EditText) findViewById(R.id.txt_playlist_description);

        tv_desc_number_limit = (TextView) findViewById(R.id.tv_desc_number_limit);
        tv_desc_number_limit.setText(String.format(getString(R.string.activity_create_playlist_playlist_description_tips), 100));

        txt_playlist_description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int number = txt_playlist_description.getText().length();
                tv_desc_number_limit.setText(String.format(getString(R.string.activity_create_playlist_playlist_description_tips), 100 - number));
            }
        });

        if (FromAlbumList) {
            layout_select_songs.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);
            id = OperateMusicUtils.getNextLocaleAlbumId();
            musicList = musicId;
            musicId = null;
        }
    }


    /**
     * 设置【已选择多少首歌】按钮的文字
     */
    public void setSelectedSongsButtonText() {
        String format = getString(R.string.activity_create_playlist_selected_count_format);
        if (getMusicSelectList().size() > 0) {
            btn_view_selected.setText(String.format(format, String.valueOf(getMusicSelectList().size())));
        } else {
            btn_view_selected.setText(String.format(format, "0"));
        }
    }

    /**
     * 设置【已选择多少首歌】
     */
    public void setSelectedSongsId(int id) {
        if (musicList.contains(id)) {
            removeMusic(id);
            musicList.remove((Object) id);
        } else {
            selectMusic(id);
            musicList.add(id);
        }
    }

    /**
     * 设置【已选择多少首歌】
     */
    public List<Integer> getSelectedSongsId() {
        return musicList;
    }

    private boolean selectMusic(int musicID) {
        return getMyConfig().getMemExchange().getListMusicId().add(musicID);
    }

    private boolean removeMusic(int musicID) {
        return getMyConfig().getMemExchange().getListMusicId().remove((Object) musicID);
    }

    public void doClick(View v) {
        switch (v.getId()) {

            case R.id.btn_view_selected://查看已选的歌曲列表
                // showAppMessage("查看已选的歌曲列表", AppMsg.STYLE_INFO);
                break;

            case R.id.btn_next_step://下一步
                id = OperateMusicUtils.getNextLocaleAlbumId();
                showNextStep();
                break;

            case R.id.btn_choose_playlist_cover://选择歌单封面
                onPickImage(v);
                break;

            case R.id.btn_create_playlist://创建歌单
                createMyPlayList();
                break;
        }
    }

    /**
     * 从相册或相机获取图片
     */
    public void onPickImage(View view) {
        FitmixUtil.deleteTempPhotoFile();
        CropImage.startPickImageActivity(this);
        //Intent chooseImageIntent = ImagePicker.getPickImageIntent(this);
        photoId = view.getId();//保存ID,之后图片设置用
        //startActivityForResult(chooseImageIntent, PICK_PLAYLIST_ID);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    Uri imageUri = CropImage.getPickImageResultUri(this, data);
                    if (CropImage.isReadExternalStoragePermissionsRequired(this, imageUri)) {
                        mCropImageUri = imageUri;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
                    } else {
                        startCropImageActivity(imageUri);
                    }
                }
                break;

            case CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE:
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    Bitmap bitmap = CropImage.getBitmapFromUri(this, result.getUri());
                    View v = findViewById(photoId);
                    if (v != null && bitmap != null) {
                        ImageHelper.adjustPhotoToFitSize(bitmap, Config.USER_ALBUM_WIDTH, Config.USER_ALBUM_HEIGHT, FitmixUtil.getPlayListPhotoFile(id));
                        ((ImageView) v).setScaleType(ImageView.ScaleType.FIT_XY);
                        ((ImageView) v).setImageBitmap(bitmap);
                    }
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    showAppMessage(R.string.crop_image_error, AppMsg.STYLE_CONFIRM);
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (mCropImageUri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // required permissions granted, start crop image activity
            startCropImageActivity(mCropImageUri);
        } else {
            showAppMessage(R.string.crop_image_no_permission, AppMsg.STYLE_CONFIRM);
        }
    }

    /**
     * 启动图片剪裁界面
     */
    private void startCropImageActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setAspectRatio(75, 32)// 750 * 320
                .setFixAspectRatio(true)
                .setGuidelines(CropImageView.Guidelines.ON_TOUCH)
                .start(this);
    }

//    private void showView(Bitmap bitmap) {
//        ImageView imageView = new ImageView(this);
//        imageView.setImageBitmap(bitmap);
//        new MaterialDialog.Builder(this)
//                .customView(imageView, true)
//                .positiveText(R.string.ok)
//                .negativeText(R.string.cancel)
//                .onAny(new MaterialDialog.SingleButtonCallback() {
//                    @Override
//                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
//                        dialog.dismiss();
//                        switch (which) {
//                            case POSITIVE:
//                            case NEGATIVE:
//                                break;
//                        }
//                    }
//                }).show();
//    }

    /**
     * 显示下一步
     */
    private void showNextStep() {
        if (!getMusicSelectList().isEmpty()) {
            layout_select_songs.setVisibility(View.GONE);
            scrollView.setVisibility(View.VISIBLE);
        } else {
            String info = getResources().getString(R.string.title_activity_create_playlist_error);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
        }
    }

    /**
     * 创建歌单
     */
    private void createMyPlayList() {
        String name = txt_playlist_name.getText().toString();
        String desc = txt_playlist_description.getText().toString();
        if (TextUtils.isEmpty(name) || name.length() < Config.USERNAME_LENGTH_MIN || name.length() > Config.CLUB_NAME_LENGTH_MAX) {
            showAppMessage(R.string.fm_create_club_club_name_hint, AppMsg.STYLE_CONFIRM);
            return;
        }
        if (TextUtils.isEmpty(desc)) {
            String info = getResources().getString(R.string.title_activity_create_playlist_desc_error);
            showAppMessage(info, AppMsg.STYLE_CONFIRM);
            return;
        }

        Album album = new Album();
        album.setName(name);
        Album.AlbumInfo albumInfo = new Album.AlbumInfo();
        albumInfo.setImage(FitmixUtil.getPlayListPhotoFile(id));
        albumInfo.setDesc(desc);
        album.setAlbumInfo(albumInfo);
        album.setId(id);
        album.setValue(0);
        OperateMusicUtils.addCustomAlbum(album);
        for (int i = 0; i < getMusicSelectList().size(); i++) {
            OperateMusicUtils.addCustomAlbumList(id, getMusicSelectList().get(i));
        }
        //友盟统计自定义歌单数量
        long num = CustomAlbumHelper.getInstance().getCustomAlbumCount();
        if (num > 0) {
            int uid = UserDataManager.getUid();
            UmengAnalysisHelper.getInstance().customAlbumReport(this, uid, num);
        }
        setResult(RESULT_OK);
        finish();
    }
}

