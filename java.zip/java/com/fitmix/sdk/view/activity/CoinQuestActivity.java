package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.CoinTaskInfo;
import com.fitmix.sdk.model.api.bean.TaskList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.CoinQuestAdapter;
import com.fitmix.sdk.view.adapter.ViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.widget.NewVPIndicator;

import java.util.ArrayList;
import java.util.List;


/**
 * 金币系统
 */
public class CoinQuestActivity extends BaseActivity implements CoinQuestAdapter.OnButtonClickListener {

    /**
     * CoinTaskActivity需要加载的Fragment类型,int型:
     * <p>
     * 1:MusicFragment
     * 2:DiscoveryFragment
     * 3:ClubFragment
     */
    public static final String INTENT_EXTRA_FRAGMENT_TYPE = "coinTaskNextFragment";

    private TextView tvTodayTaskNumber;
    private TextView tvHonorTaskNumber;
    //    private SimpleDraweeView ivCoinQuestBanner;
    private CoinQuestAdapter todayAdapter;
    private CoinQuestAdapter honorAdapter;

    private List<CoinTaskInfo> mTodayTaskList;
    private List<CoinTaskInfo> mHonorTaskList;

    private String nextLevelStr;
    private int nextLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        setContentView(R.layout.activity_coin_quest);

        if (getIntent() != null) {
            nextLevel = getIntent().getIntExtra("nextLevel", 0);
        }

        initToolbar();
        initViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int level = SettingsHelper.getInt(Config.SETTING_USER_LEVEL, 0);
        Logger.i(Logger.DEBUG_TAG, "CoinQuestActivity-->onResume level:" + level + ",nextLevel:" + nextLevel);
        if ((level + 1) > nextLevel) {
            nextLevel = level;
            nextLevelStr = "RUN_LEVEL_" + (level + 1);//更新等级任务级别
        } else {
            nextLevelStr = "RUN_LEVEL_" + nextLevel;//更新等级任务级别
        }

        getAllTaskList();
    }

    /**
     * 获取所有任务列表
     */
    private void getAllTaskList() {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().getAllTaskList(uid, true);
        registerDataReqStatusListener(requestId);
        showLoadingDialog(R.string.swipelayout_loading, 1000);
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        tvTodayTaskNumber = (TextView) findViewById(R.id.tv_today_task_number);
        tvHonorTaskNumber = (TextView) findViewById(R.id.tv_honor_task_number);
//        ivCoinQuestBanner = (SimpleDraweeView) findViewById(R.id.iv_coin_quest_banner);

        NewVPIndicator mIndicator = (NewVPIndicator) findViewById(R.id.indicator_coin_task_title);
        final ViewPager viewpager = (ViewPager) findViewById(R.id.vp_coin_task);
        List<View> views = new ArrayList<>();

        //今日任务 为空时提示
        mTodayTaskList = new ArrayList<>();
        View todayView = getLayoutInflater().inflate(R.layout.listview_task, null);
        if (todayView != null) {
            ListView todayList = (ListView) todayView.findViewById(R.id.list_task);//new ListView(this);
            TextView emptyView = (TextView) todayView.findViewById(R.id.tv_empty_view);
            todayList.setEmptyView(emptyView);
            todayList.setAdapter(getTodayAdapter());
            todayList.setDividerHeight(4);
            views.add(todayList);
        }

        //荣誉任务
        mHonorTaskList = new ArrayList<>();
        View honorView = getLayoutInflater().inflate(R.layout.listview_task, null);
        if (honorView != null) {
            ListView honorList = (ListView) honorView.findViewById(R.id.list_task);
            TextView emptyView = (TextView) honorView.findViewById(R.id.tv_empty_view);
            honorList.setEmptyView(emptyView);
            honorList.setAdapter(getHonorAdapter());
            honorList.setDividerHeight(4);
            views.add(honorList);
        }

        ViewPagerAdapter vAdapter = new ViewPagerAdapter();
        vAdapter.setViews(views);
        viewpager.setAdapter(vAdapter);//给ViewPager设置适配器
        viewpager.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果

        String[] titles = new String[]{getString(R.string.activity_coin_quest_today_task),
                getString(R.string.activity_coin_quest_honor_task),
        };
        mIndicator.setTitles(titles);

        mIndicator.setViewPager(viewpager);
        NewVPIndicator.OnTabClickListener mTabClickListener = new NewVPIndicator.OnTabClickListener() {
            @Override
            public void onTabClick(int index) {
                viewpager.setCurrentItem(index);
            }
        };
        mIndicator.setOnTabClickListener(mTabClickListener);
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 55://获取所有任务列表
                hideLoadingDialog();
                TaskList allTasks = JsonHelper.getObject(result, TaskList.class);
                if (allTasks != null && allTasks.getTaskList() != null) {
                    mTodayTaskList.clear();
                    mHonorTaskList.clear();

                    CoinTaskInfo taskEntity;
                    for (int i = 0; i < allTasks.getTaskList().size(); i++) {
                        taskEntity = allTasks.getTaskList().get(i);
                        if (taskEntity != null) {
                            if (taskEntity.getTaskType() == 0) {//每日任务
                                if (Config.COIN_TASK_SIGN.equals(taskEntity.getTaskKey())) {//不显示每日签到
                                    continue;
                                }
                                mTodayTaskList.add(taskEntity);
                            } else if (taskEntity.getTaskType() == 1) {//一次性任务
                                if (taskEntity.getFinishStatus() == 1) {//只显示未完成的任务
                                    mHonorTaskList.add(taskEntity);
                                }
                            } else if (taskEntity.getTaskType() == 2) {//下一个等级任务
                                if (!TextUtils.isEmpty(nextLevelStr) && nextLevelStr.equals(taskEntity.getTaskKey())) {
                                    mHonorTaskList.add(taskEntity);
                                }
                            }
                        }
                    }

                    //今日任务完成度
                    if (mTodayTaskList.size() == 0) {
                        if (tvTodayTaskNumber != null) {
                            tvTodayTaskNumber.setText("0/0");
                        }
                    } else {
                        int finished = 0;
                        for (int i = 0; i < mTodayTaskList.size(); i++) {
                            if (mTodayTaskList.get(i).getFinishStatus() == 0) {
                                finished++;
                            }
                        }
                        if (tvTodayTaskNumber != null) {
                            tvTodayTaskNumber.setText(String.format("%d/%d", finished, mTodayTaskList.size()));
                        }
                    }
                    if (todayAdapter != null) {
                        todayAdapter.notifyDataSetChanged();
                    }

                    //荣誉任务完成度
                    if (mHonorTaskList.size() == 0) {
                        if (tvHonorTaskNumber != null) {
                            tvHonorTaskNumber.setText("0");
                        }
                    } else {
                        if (tvHonorTaskNumber != null) {
                            tvHonorTaskNumber.setText(String.format("%d", mHonorTaskList.size()));
                        }
                    }
                    if (honorAdapter != null) {
                        honorAdapter.notifyDataSetChanged();
                    }

                }
                break;

        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        super.processReqError(requestId, error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 55:
                    hideLoadingDialog();
                    if (tvTodayTaskNumber != null) {
                        tvTodayTaskNumber.setText("0/0");
                    }
                    if (tvHonorTaskNumber != null) {
                        tvHonorTaskNumber.setText("0");
                    }

                    if (todayAdapter != null) {
                        todayAdapter.notifyDataSetChanged();
                    }
                    if (honorAdapter != null) {
                        honorAdapter.notifyDataSetChanged();
                    }
                    break;
            }
        }
    }

    /**
     * 今日任务数据适配器
     */
    public CoinQuestAdapter getTodayAdapter() {
        if (todayAdapter == null) {
            todayAdapter = new CoinQuestAdapter(mTodayTaskList);
            todayAdapter.setOnButtonClickListener(this);
        }
        return todayAdapter;
    }

    /**
     * 荣誉任务数据适配器
     */
    public CoinQuestAdapter getHonorAdapter() {
        if (honorAdapter == null) {
            honorAdapter = new CoinQuestAdapter(mHonorTaskList);
            honorAdapter.setOnButtonClickListener(this);
        }
        return honorAdapter;
    }


    @Override
    public void onClick(CoinTaskInfo taskEntity) {
        if (taskEntity != null) {
            String taskKey = taskEntity.getTaskKey();
            Intent intent = new Intent();
            if (taskKey == null)
                return;
            switch (taskKey) {
                case Config.COIN_TASK_THREE_MILE_KEY://每日完成3公里任务
                    intent.setClass(this, RunSettingActivity.class);//跳转到准备跑步
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_PLAY_MIX_KEY://每日播放歌曲任务
                    intent.setClass(this, CoinTaskActivity.class);//跳转到金币任务界面加载主界面-->动听fragment
                    intent.putExtra(INTENT_EXTRA_FRAGMENT_TYPE, 1);
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_SHARE_MIX_KEY://每日分享歌曲任务
                    intent.setClass(this, CoinTaskActivity.class);//跳转到金币任务界面加载主界面-->动听fragment
                    intent.putExtra(INTENT_EXTRA_FRAGMENT_TYPE, 1);
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_SHARE_RECORD_KEY://每日分享运动任务
                    intent.setClass(this, SportRecordActivity.class);//跳转到运动记录界面
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_SHARE_VIDEO_KEY://每日分享视频任务
                    intent.setClass(this, CoinTaskActivity.class);//跳转到金币任务界面加载主界面-->发现fragment
                    intent.putExtra(INTENT_EXTRA_FRAGMENT_TYPE, 2);
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_PHONE_BIND_KEY://手机绑定
                    intent.setClass(this, AccountSetActivity.class);//跳转账号管理界面
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_EMAIL_BIND_KEY://邮箱绑定
                    intent.setClass(this, AccountSetActivity.class);//跳转账号管理界面
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_COMPLETE_PERSONAL_INFO://完善个人资料任务
                    intent.setClass(this, EditProfileActivity.class);//跳转我的资料
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_COMPLETE_COMPETITION_INFO://完善个人参赛信息任务
                    intent.setClass(this, EditProfileActivity.class);////跳转我的资料
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_CREATE_JOIN_CLUB://创建或者加入俱乐部任务
                    intent.setClass(this, CoinTaskActivity.class);//跳转到金币任务界面加载主界面-->俱乐部fragment
                    intent.putExtra(INTENT_EXTRA_FRAGMENT_TYPE, 3);
                    startActivity(intent);
                    break;

                case Config.COIN_TASK_PAIRING_BT://使用我的设备配对一次任务
                    intent.setClass(this, EquipmentActivity.class);//跳转我的装备
                    startActivity(intent);
                    break;

                default:
                    if (taskKey != null && taskKey.contains("RUN_LEVEL_")) {//等级任务
                        intent.setClass(this, RunSettingActivity.class);//跳转到准备跑步
                        startActivity(intent);
                    }
                    break;
            }
//            showAppMessage(taskEntity.getDescription(), AppMsg.STYLE_INFO);
        }
    }

}

