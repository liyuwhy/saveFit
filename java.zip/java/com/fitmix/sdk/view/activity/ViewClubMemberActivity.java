package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.ActiveUser;
import com.fitmix.sdk.bean.Club;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.share.AuthShareHelper;
import com.fitmix.sdk.common.share.ShareUtils;
import com.fitmix.sdk.model.api.bean.ClubMemberList;
import com.fitmix.sdk.model.api.bean.ClubShareInfo;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.view.bean.ClubMember;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.ViewClubMemberGridFragment;
import com.fitmix.sdk.view.fragment.ViewClubMemberListFragment;
import com.fitmix.sdk.view.widget.AppMsg;

import java.util.ArrayList;
import java.util.List;

public class ViewClubMemberActivity extends BaseActivity {//implements SwipeRefreshLayout.OnRefreshListener {
//    private final int REQUEST_TYPE_MEMBER_LIST = 1;
//    private final int REQUEST_TYPE_MEMBER_REMOVE = 2;
//    private final int REQUEST_TYPE_MEMBER_ADD = 3;
//    private final int REQUEST_TYPE_MEMBER_QUIT = 4;
//    private final int REQUEST_TYPE_SHARE = 5;
//    private final int REQUEST_TYPE_LOAD_MORE = 6;

    private final String VIEW_CLUB_MEMBER_GRID = "clubMemberGrid";
    private final String VIEW_CLUB_MEMBER_LIST = "clubMemberList";

    //    private int clubMembersIndex;
    private List<ClubMember> clubMembers;//成员列表,ViewClubMemberListFragment和ViewClubMemberGridFragment共用的数据源
    private boolean isMember = true;
    private int listType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_club_member);
        setPageName("ViewClubMemberActivity");
        isMember = getIntent().getBooleanExtra("isMember", true);
        initToolbar();
        initViews();
//        clubMembersIndex = 1;
        if (savedInstanceState == null) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isMember", isMember);
            ViewClubMemberGridFragment clubMemberGrid = new ViewClubMemberGridFragment();
            clubMemberGrid.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.mainContainer, clubMemberGrid, VIEW_CLUB_MEMBER_GRID).commit();
        }
        clubMembers = new ArrayList<>();
    }

    @Override
    protected void onDestroy() {
        Logger.i(Logger.DEBUG_TAG, "ViewClubMemberActivity --- > onDestroy() ");
        super.onDestroy();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
    }


    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_view_all_member://查看全部成员
                addViewClubMemberListFragment();
                break;
            case R.id.btn_quit_club:
                new MaterialDialog.Builder(this)
                        .title(R.string.prompt)
                        .content(R.string.quit_Club)
                        .positiveText(R.string.ok)
                        .negativeText(R.string.cancel)
                        .onAny(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                dialog.dismiss();
                                switch (which) {
                                    case POSITIVE:
                                        sendClubMemberQuitRequest();
                                        break;
                                    case NEGATIVE:
                                        break;
                                }
                            }
                        }).show();
                break;
        }
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        Logger.i(Logger.DEBUG_TAG, "requestingCountChang-->requestingCount : " + requestingCount);
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
        Logger.i(Logger.DEBUG_TAG, "dataUpdateNotify-->requestId:" + requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_CLUB + 9://获取俱乐部成员列表
                refreshClubMemberList(dataReqResult.getResult());
                break;
            case Config.MODULE_CLUB + 10://删除俱乐部成员
                afterDeleteMumber(true);
                break;
            case Config.MODULE_CLUB + 12://退出俱乐部
                afterQuitClub(true);
                break;
            case Config.MODULE_CLUB + 13://分享俱乐部
                setClubShareUrl(dataReqResult.getResult());
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.i(Logger.DEBUG_TAG, "发生了错误啊,requestId:" + requestId + " error:" + error);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
    }


    /**
     * 导航到
     */
    private void addViewClubMemberListFragment() {
        ViewClubMemberListFragment listFragment = (ViewClubMemberListFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_LIST);
        if (listFragment == null) {
            listFragment = new ViewClubMemberListFragment();
        }

        //先隐藏gridFragment再添加listFragment
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ViewClubMemberGridFragment gridFragment = (ViewClubMemberGridFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_GRID);

        if (gridFragment != null) {
            ft.hide(gridFragment);
        }
        if (ftCanCommit) {
            ft.setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out)
                    .add(R.id.mainContainer, listFragment, VIEW_CLUB_MEMBER_LIST).commit();
        }
        if (clubMembers != null && clubMembers.size() > 2) {
            clubMembers.remove(clubMembers.size() - 1);
        }

    }

    public List<ClubMember> getClubMembers() {
        return clubMembers;
    }


    /**
     * @return 获取当前俱乐部
     */
    private Club getClub() {
        return getMyConfig().getMemExchange().getCurrentClub();
    }

    /**
     * 退出俱乐部
     */
    private void sendClubMemberQuitRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().quitClub(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 退出俱乐部之后
     */
    public void afterQuitClub(boolean isSuccess) {
        if (isSuccess) {
            getMyConfig().getMemExchange().setCurrentClub(null);
            getMyConfig().getMemExchange().setNeedRefreshClubList(true);
            finish();
        }
    }

    /**
     * 加载更多成员名单
     *
     * @param index 页码
     */
    public void sendClubMemberListRequest(int index) {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubMemberList(getClub().getId(), index, true);
        listType = 2;
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取第一页成员名单
     */
    public void sendClubMemberListRequest() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getClubMemberList(getClub().getId(), 1, true);
        listType = 1;
        registerDataReqStatusListener(requestId);
    }

    /**
     * 删除成员
     *
     * @param uid 成员的uid
     */
    public void sendRemoveClubMemberRequest(int uid) {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().deleteClubMember(getClub().getId(), uid, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 删除俱乐部成员之后
     */
    public void afterDeleteMumber(boolean isSuccess) {
        if (isSuccess) {
            sendClubMemberListRequest();
        }
    }

    /**
     * 切换到成员信息
     */
    public void startClubMemberInfoActivity(ClubMember clubMember) {
        Intent intent = new Intent();
        String clubMemberString = JsonHelper.createJsonString(clubMember);
        intent.putExtra("clubMemberString", clubMemberString);
        intent.setClass(ViewClubMemberActivity.this, ClubMemberInfoActivity.class);
        startActivity(intent);
    }

    private void refreshClubMemberList(String sResult) {
        ClubMemberList clubMemberList = JsonHelper.getObject(sResult, ClubMemberList.class);
        List<ClubMember> list = clubMemberList.getList().getResult();
        switch (listType) {
            case 1:
                ViewClubMemberListFragment clubMemberListFragment = (ViewClubMemberListFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_LIST);
                if (clubMemberListFragment != null) {//List Fragment更新
                    clubMemberListFragment.refresh(list);
                    clubMemberListFragment.stopRefresh();
                } else {
                    ViewClubMemberGridFragment clubMemberGridFragment = (ViewClubMemberGridFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_GRID);
                    if (clubMemberGridFragment != null) {//通知Grid Fragment更新
                        ClubMember member = new ClubMember();
                        ActiveUser user = new ActiveUser();
                        member.setUser(user);
                        list.add(member);
                        clubMemberGridFragment.refresh(list);
                    }
                }
                break;
            case 2:
                ViewClubMemberListFragment memberListFragment = (ViewClubMemberListFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_LIST);
                if (memberListFragment != null) {//List Fragment更新
                    memberListFragment.refresh(list);
                    memberListFragment.stopRefresh();
                }
                break;
        }
    }

    /**
     * 分享俱乐部添加成员
     */
    public void getShareClubUrl() {
        if (getClub() == null) return;
        int requestId = ClubDataManager.getInstance().getShareClubUrl(getClub().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    private void setClubShareUrl(String sResult) {
        ClubShareInfo clubShareInfo = JsonHelper.getObject(sResult, ClubShareInfo.class);
        String url = clubShareInfo.getShareUrl();
        if (url != null)
            shareClub(url);
    }

    /**
     * 发送分享俱乐部请求
     */
    public void shareClub() {
        if (!isMember) {
            new MaterialDialog.Builder(this)
                    .title(R.string.prompt)
                    .content(R.string.visitors_permissions)
                    .positiveText(R.string.ok)
                    .onAny(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            dialog.dismiss();
                            switch (which) {
                                case POSITIVE:
                                    break;
                            }
                        }
                    }).show();
        } else {
            getShareClubUrl();
        }
    }

    /**
     * 分享俱乐部
     *
     * @param url 俱乐部地址
     */
    private void shareClub(String url) {
        if (TextUtils.isEmpty(url)) return;
        ShareUtils.getInstance().shareClub(this, getClub().getBackImageUrl(), url);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //回退fragment栈
        ViewClubMemberListFragment listFragment = (ViewClubMemberListFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_LIST);
        if (listFragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ViewClubMemberGridFragment gridFragment = (ViewClubMemberGridFragment) getSupportFragmentManager().findFragmentByTag(VIEW_CLUB_MEMBER_GRID);
            //移除listFragment再显示gridFragment
            ft.hide(listFragment);
            if (gridFragment != null) {
                ft.setCustomAnimations(R.anim.push_right_in, R.anim.push_right_out).show(gridFragment);
            }
            ft.remove(listFragment);
            if (ftCanCommit) {
                ft.commit();
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {

            default:
                if (resultCode == Activity.RESULT_OK) {     //三方分享
                    if (data == null) return;
//                    int rCode = data.getIntExtra(AuthShareHelper.KEY_RESULT_CODE, 0);
                    String resultStr = data.getStringExtra(AuthShareHelper.KEY_RESULT_STRING);
                    switch (requestCode) {
                        case AuthShareHelper.REQUESTCODE_QQ_SHARE://QQ
                        case AuthShareHelper.REQUESTCODE_QZONE_SHARE://QQ空间
                        case AuthShareHelper.REQUESTCODE_WECHAT_SHARE://微信
                        case AuthShareHelper.REQUESTCODE_CIRCLE_SHARE://微信朋友圈
                        case AuthShareHelper.REQUESTCODE_SINA_SHARE:    //微博
                            if (!TextUtils.isEmpty(resultStr)) {
                                showAppMessage(resultStr, AppMsg.STYLE_INFO);
                            }
                            break;


                    }
                }
                break;
        }

    }

}
