package com.fitmix.sdk.view.activity;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.RunLogInfo;
import com.fitmix.sdk.common.FormatUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.LastRun;
import com.fitmix.sdk.model.api.bean.LastRunlogInfo;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.ClubDataManager;
import com.fitmix.sdk.view.bean.ClubMember;
import com.fitmix.sdk.view.bean.ClubNews;
import com.fitmix.sdk.view.bean.ClubRank;
import com.fitmix.sdk.view.widget.AppMsg;


public class ClubMemberInfoActivity extends BaseActivity {

    private SimpleDraweeView img_member_avatar;
    private TextView tv_member_name;
    private TextView tv_distance;
    private TextView tv_duration;
    private TextView tv_pace;
    private TextView tv_calorie;
    private TextView tv_step;
    private TextView tv_userid;
    private RunLogInfo runLog;
    private boolean isFromClubNews;
    private boolean isFromClubRanks;
    private ClubNews clubNews;
    private ClubRank clubRank;
    private ClubMember member;
    private final int RANK_TYPE_WEEK = 2;
    private final int RANK_TYPE_MONTH = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_member_info);
        setPageName("ClubMemberInfoActivity");
        isFromClubNews = getIntent().getBooleanExtra("isFromClubNews", false);
        isFromClubRanks = getIntent().getBooleanExtra("isFromClubRank", false);
        initToolbar();
        initViews();
        if (isFromClubNews) {
            String clubNewsString = getIntent().getStringExtra("clubNews");
            clubNews = JsonHelper.getObject(clubNewsString, ClubNews.class);
            initData();
            setUiTitle(getString(R.string.title_activity_club_member_info_day));
        } else if (isFromClubRanks) {
            String clubRankString = getIntent().getStringExtra("clubRank");
            clubRank = JsonHelper.getObject(clubRankString, ClubRank.class);
            int type = getIntent().getIntExtra("type", -1);
            if (type > 0) {
                switch (type) {
                    case RANK_TYPE_WEEK:
                        setUiTitle(getString(R.string.title_activity_club_member_info_week));
                        break;
                    case RANK_TYPE_MONTH:
                        setUiTitle(getString(R.string.title_activity_club_member_info_month));
                        break;
                }
            }
            initData();
        } else {
            String clubMemberString = getIntent().getStringExtra("clubMemberString");
            member = JsonHelper.getObject(clubMemberString, ClubMember.class);
            senClubMemberLastRunRequest();
            setUiTitle(getString(R.string.title_activity_club_member_info));
        }
    }

    /**
     * 初始化视图
     */

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        img_member_avatar = (SimpleDraweeView) findViewById(R.id.img_member_avatar);
        tv_member_name = (TextView) findViewById(R.id.tv_member_name);
        tv_distance = (TextView) findViewById(R.id.tv_distance);
        tv_duration = (TextView) findViewById(R.id.tv_duration);
        tv_pace = (TextView) findViewById(R.id.tv_pace);
        tv_calorie = (TextView) findViewById(R.id.tv_calorie);
        tv_step = (TextView) findViewById(R.id.tv_step);
        tv_userid = (TextView) findViewById(R.id.user_id);
    }

    /**
     * 初始化数据
     */
    private void initData() {
        if (isFromClubNews) {
            if (clubNews == null || clubNews.getUser() == null) return;
            if (TextUtils.isEmpty(clubNews.getUser().getAvatar())) {
                img_member_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
            } else {
                img_member_avatar.setImageURI(Uri.parse(clubNews.getUser().getAvatar()));
            }
            tv_member_name.setText(clubNews.getUser().getName());

            if (clubNews.getDistance() <= 0) {
                tv_distance.setText("0.00");
            } else {
                tv_distance.setText(FormatUtil.formatDistance(clubNews.getDistance()));
            }
            tv_duration.setText(FormatUtil.formatRunTime(clubNews.getRunTime() / 1000));
            tv_pace.setText(FormatUtil.formatSpeed(clubNews.getDistance(), clubNews.getRunTime() / 1000));
            tv_calorie.setText(String.valueOf(clubNews.getCalorie()));
            tv_step.setText(String.valueOf(clubNews.getStep()));
            tv_userid.setText("ID:" + clubNews.getUser().getId());

        } else if (isFromClubRanks) {
            if (clubRank == null || clubRank.getUser() == null) return;
            if (TextUtils.isEmpty(clubRank.getUser().getAvatar())) {
                img_member_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
            } else {
                img_member_avatar.setImageURI(Uri.parse(clubRank.getUser().getAvatar()));
            }
            tv_member_name.setText(clubRank.getUser().getName());

            if (clubRank.getDistance() <= 0) {
                tv_distance.setText("0.00");
            } else {
                tv_distance.setText(FormatUtil.formatDistance(clubRank.getDistance()));
            }
            tv_duration.setText(FormatUtil.formatRunTime(clubRank.getRunTime() / 1000));
            tv_pace.setText(FormatUtil.formatSpeed(clubRank.getDistance(), clubRank.getRunTime() / 1000));
            tv_calorie.setText(String.valueOf(clubRank.getCalorie()));
            tv_step.setText(String.valueOf(clubRank.getStep()));
            tv_userid.setText("ID:" + clubRank.getUser().getId());

        } else {
            if (getRunLog() == null) return;
            if (member == null || member.getUser() == null) return;
            if (TextUtils.isEmpty(member.getUser().getAvatar())) {
                img_member_avatar.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.default_avatar)).build());
            } else {
                img_member_avatar.setImageURI(Uri.parse(member.getUser().getAvatar()));
            }
            tv_member_name.setText(member.getUser().getName());

            long distance = getRunLog().getDistance();
            if (distance <= 0) {
                tv_distance.setText("0.00");
            } else {
                tv_distance.setText(FormatUtil.formatDistance(getRunLog().getDistance()));
            }
            tv_duration.setText(FormatUtil.formatRunTime(getRunLog().getRunTime() / 1000));
            tv_pace.setText(FormatUtil.formatSpeed(getRunLog().getDistance(), getRunLog().getRunTime() / 1000));
            tv_calorie.setText(String.valueOf(getRunLog().getCalorie()));
            tv_step.setText(String.valueOf(getRunLog().getStep()));
            tv_userid.setText("ID:" + member.getUser().getId());
        }
    }

    /**
     * @return 跑步记录
     */
    private RunLogInfo getRunLog() {
        return runLog;
    }

    /**
     * 设置跑步记录
     *
     * @param runLog 跑步记录
     */
    private void setRunLog(RunLogInfo runLog) {
        this.runLog = runLog;
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        switch (dataReqResult.getRequestId()) {
            case Config.MODULE_CLUB + 11:
                setRunlogInfo(dataReqResult.getResult());
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_CLUB + 11:
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                break;
        }
    }

    /**
     * 获取成员最后一次跑步成绩
     */
    private void senClubMemberLastRunRequest() {
        if (member == null) return;
        int requestId = ClubDataManager.getInstance().getLastRunlogInfo(member.getUser().getId(), true);
        registerDataReqStatusListener(requestId);
    }

    private void setRunlogInfo(String sResult) {
        LastRunlogInfo lastRunlogInfo = JsonHelper.getObject(sResult, LastRunlogInfo.class);
        if (lastRunlogInfo != null && lastRunlogInfo.getUser() != null) {
            LastRun lastRun = lastRunlogInfo.getUser().getLastRun();
            RunLogInfo runLogInfo = new RunLogInfo();
            if (lastRun != null) {
                runLogInfo.setDistance(lastRun.getDistance());
                runLogInfo.setRunTime(lastRun.getRunTime());
                runLogInfo.setCalorie(lastRun.getCalorie());
                runLogInfo.setStep(lastRun.getStep());
                runLogInfo.setUid(lastRun.getUid());
            }
            setRunLog(runLogInfo);
            initData();
        }
    }
}
