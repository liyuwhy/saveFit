package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.bean.TopicDiscuss;
import com.fitmix.sdk.bean.TopicMessage;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.TopicAnswerMessage;
import com.fitmix.sdk.model.api.bean.TopicDiscussMessage;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.view.adapter.TopicMessageAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * 话题消息列表界面
 */
public class TopicMessageActivity extends BaseActivity {

    private ListView list_msg;

    private TopicMessageAdapter adapter;
    private List<TopicMessage> topicMessageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_message);
        setPageName("TopicMessageActivity");

        initToolbar();
        initViews();
        initData();
    }

    private void initData() {
        getNewAnswerMessage();
        getNewDiscussMessage();
    }

    /**
     * 获取有关话题最新回答消息
     */
    private void getNewAnswerMessage() {
        int requestId = DiscoverDataManager.getInstance().getNewAnswerMessage(false);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取最新讨论的相关消息
     */
    private void getNewDiscussMessage() {
        int requestId = DiscoverDataManager.getInstance().getNewDiscussMessage(false);
        registerDataReqStatusListener(requestId);
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        list_msg = (ListView) findViewById(R.id.list_msg);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        list_msg.setEmptyView(emptyView);

        topicMessageList = new ArrayList<>();
        adapter = new TopicMessageAdapter(this);
        adapter.setTopicMessageList(topicMessageList);
        list_msg.setAdapter(adapter);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_COMPETITION + 18://获取与自己相关的最新话题回答消息
                Logger.i(Logger.DATA_FLOW_TAG, "获取与自己相关的最新话题回答消息:" + result);
                TopicAnswerMessage topicAnswerMessage = JsonHelper.getObject(result, TopicAnswerMessage.class);
                if (topicAnswerMessage != null && topicAnswerMessage.getThemes() != null) {
                    for (Topic topic : topicAnswerMessage.getThemes()) {
                        TopicMessage topicMessage = new TopicMessage(TopicMessage.TYPE_THEME_ANSWER, topic);
                        topicMessageList.add(topicMessage);
                    }
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 19://获取与自己相关的最新话题讨论消息
                Logger.i(Logger.DATA_FLOW_TAG, "获取与自己相关的最新话题讨论消息:" + result);
                TopicDiscussMessage topicDiscussMessage = JsonHelper.getObject(result, TopicDiscussMessage.class);
                if (topicDiscussMessage != null && topicDiscussMessage.getDiscuss() != null) {
                    for (TopicDiscuss topicDiscuss : topicDiscussMessage.getDiscuss()) {
                        TopicMessage topicMessage = new TopicMessage(TopicMessage.TYPE_THEME_DISCUSS, topicDiscuss);
                        topicMessageList.add(topicMessage);
                    }
                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }
                }
                break;
        }
    }


}
