package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.bean.TopicAnswer;
import com.fitmix.sdk.bean.TopicDiscuss;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.StringUtils;
import com.fitmix.sdk.common.share.ShareManager;
import com.fitmix.sdk.model.api.bean.AddTopicAnswerDiscuss;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.TopicAnswerById;
import com.fitmix.sdk.model.api.bean.TopicAnswerLike;
import com.fitmix.sdk.model.api.bean.TopicAnswerList;
import com.fitmix.sdk.model.api.bean.TopicDiscussLike;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.view.adapter.TopicAnswerAdapter;
import com.fitmix.sdk.view.adapter.TopicDiscussAdapter;
import com.fitmix.sdk.view.fragment.TopicAnswerDetailFragment;
import com.fitmix.sdk.view.fragment.TopicAnswerDiscussFragment;
import com.fitmix.sdk.view.fragment.TopicDetailFragment;
import com.fitmix.sdk.view.widget.AppMsg;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * 话题详情界面
 */
public class TopicDetailActivity extends BaseActivity implements TopicAnswerDetailFragment.OnActionClickListener,
        TopicAnswerDiscussFragment.OnActionClickListener {

    /**
     * 我要回答请求
     */
    private final static int REQUEST_ADD_TOPIC_ANSWER = 789;
    /**
     * 修改回答请求
     */
    private final static int REQUEST_EDIT_TOPIC_ANSWER = 790;

    private int topicId;
    private Topic topic;

    private TopicDetailFragment topicDetailFragment;
    private TopicDetailFragment.TopicDetailFragmentCallback topicDetailFragmentCallback;
    private TopicAnswerDetailFragment topicAnswerDetailFragment;
    private TopicAnswerDiscussFragment topicAnswerDiscussFragment;

    private TopicAnswer myTopicAnswer;//用户对该话题的回答
    /**
     * 重新返回discoveryFragment时,话题列表是否需要刷新.
     * 当用户有新增、修改回答,点赞,评论时则需要
     */
    private boolean discoveryFragmentShouldReload = false;//

    private int pageNo = 1;//答案列表分页编号,从1开始
    private int answerListOrderType = 4;//答案列表排序类型,默认按质量排序
    private List<TopicAnswer> mTopicAnswerList;//该话题的回答列表
    private boolean isFromXgNotify;
    private boolean isFromTopicDiscussReply;
    private int discussThemeUid = -1;
    private int discussId = -1;
    private int discussUid = -1;
    private boolean discussLike;
    private boolean isFromNoticeFragmentDiscuss;
    private boolean isFromNoticeFragmentAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_detail);
        setPageName("TopicDetailActivity");
        Intent intent = getIntent();
        if (intent == null) {
            showAppMessage(R.string.activity_topic_detail_invalid_topic, AppMsg.STYLE_ALERT);
            finish();
            return;
        }
        initToolbar();
        initViews();

        topicId = intent.getIntExtra("topicId", -1);
        topic = MyConfig.getInstance().getMemExchange().getTopic();

        isFromNoticeFragmentAnswer = intent.getBooleanExtra("isFromNoticeFragmentAnswer", false);//回答了问题


        isFromXgNotify = intent.getBooleanExtra("isFromXgNotify", false);//从信鸽推送进来
        if (isFromXgNotify || isFromNoticeFragmentAnswer) {
            int requestId = DiscoverDataManager.getInstance().getTopicAnswerList(topicId, 4, 1, 1, true);
            registerDataReqStatusListener(requestId);
        } else {
            getTopicAnswerList();//默认按质量排序,点赞数量
        }

        isFromNoticeFragmentDiscuss = intent.getBooleanExtra("isFromNoticeFragmentDiscuss", false);//评论了问题
        if (isFromNoticeFragmentDiscuss) {//从消息通知界面评论跳进来
            getTopicAnswerByAnswerId(topicId);
        }


        if (savedInstanceState == null) {
            createTopicDetailFragment();
        }
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

        mTopicAnswerList = new ArrayList<>();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    /**
     * 设置界面标题文字
     *
     * @param textResId 标题文字资源ID
     */
    public void setTitleText(int textResId) {
        setUiTitle(getString(textResId));
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_COMPETITION + 6://根据话题编号,获取该话题的回答列表
                Logger.i(Logger.DATA_FLOW_TAG, "话题的回答列表:" + result);
                TopicAnswerList topicAnswerList = JsonHelper.getObject(result, TopicAnswerList.class);
                if (isFromXgNotify) {
                    topic = topicAnswerList.getTheme();
                    if (topicDetailFragment != null) {
                        topicDetailFragment.setTopic(topic);
                        if (topic != null) {
                            if (topic.getAnswerId() > 0) {//获取当前用户对该话题的回答
                                getTopicAnswerByAnswerId(topic.getAnswerId());
                            }
                        }
                    }
                }
                if (isFromNoticeFragmentAnswer) {//从消息通知过来，请求回答详情
                    if (isFromNoticeFragmentAnswer) {
                        topic = topicAnswerList.getTheme();
                        int answerId = getIntent().getIntExtra("answerId", -1);
                        getTopicAnswerByAnswerId(answerId);
                    }
                }

                if (topicAnswerList != null && topicAnswerList.getPage() != null) {
                    List<TopicAnswer> list = topicAnswerList.getPage().getResult();
                    if (mTopicAnswerList != null && list != null) {
                        if (list.size() > 0) {
                            pageNo++;
                            mTopicAnswerList.addAll(list);
                            if (topicDetailFragment != null) {
                                topicDetailFragment.resetRefreshLoadMoreUi(true);
                                topicDetailFragment.refresh();
                            }
                        } else {
                            if (topicDetailFragment != null) {
                                topicDetailFragment.resetRefreshLoadMoreUi(false);
                                topicDetailFragment.refresh();
                            }
                        }
                    }

                    if (topicAnswerDetailFragment != null) {
                        topicAnswerDetailFragment.refresh();
                    }

                } else {
                    if (topicDetailFragment != null) {
                        topicDetailFragment.resetRefreshLoadMoreUi(false);
                        topicDetailFragment.refresh();
                    }
                    if (topicAnswerDetailFragment != null) {
                        topicAnswerDetailFragment.refresh();
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 7://根据话题编号,获取该话题的讨论列表
                Logger.i(Logger.DATA_FLOW_TAG, "话题的讨论列表:" + result);
                if (topicAnswerDiscussFragment != null) {
                    topicAnswerDiscussFragment.setTopicDiscussList(result);
                    TopicAnswer topicAnswer = topicAnswerDiscussFragment.getTopicAnswer();
                    setUiTitle(getString(R.string.title_fragment_topic_discuss_detail) + " (" + topicAnswer.getTaoLunNum() + ")");//设置话题评论标题
                }
                break;

            case Config.MODULE_COMPETITION + 13://添加话题答案的评论
                Logger.i(Logger.DATA_FLOW_TAG, "添加话题答案的评论:" + result);
                AddTopicAnswerDiscuss addTopicAnswerDiscuss = JsonHelper.getObject(result, AddTopicAnswerDiscuss.class);
                if (addTopicAnswerDiscuss != null) {
                    discoveryFragmentShouldReload = true;
                    showAppMessage(R.string.fragment_topic_discuss_submit_success, AppMsg.STYLE_INFO);
                    if (topicAnswerDiscussFragment != null) {
                        topicAnswerDiscussFragment.clearCommentContent();
                        if (addTopicAnswerDiscuss.getDiscuss() != null) {//重新刷新列表
                            TopicDiscuss topicDiscuss = addTopicAnswerDiscuss.getDiscuss();
                            TopicDiscussAdapter topicDiscussAdapter = topicAnswerDiscussFragment.getTopicDiscussAdapter();
                            if (topicDiscussAdapter != null && topicDiscussAdapter.getTopicDiscussList() != null) {
                                topicDiscussAdapter.getTopicDiscussList().add(topicDiscuss);
                                topicDiscussAdapter.notifyDataSetChanged();
                            }

                            TopicAnswer topicAnswer = topicAnswerDiscussFragment.getTopicAnswer();
                            if (topicAnswer != null) {
                                topicAnswer.setTaoLunNum(topicAnswer.getTaoLunNum() + 1);//对应的回答评论数量+1
                                if (topicAnswerDiscussFragment != null) {
                                    setUiTitle(getString(R.string.title_fragment_topic_discuss_detail) + " (" + topicAnswer.getTaoLunNum() + ")");//刷新话题评论标题
                                    topicAnswerDiscussFragment.refreshPublishDiscussEditText();
                                }
                            }

                            if (topicAnswerDetailFragment != null) {//回答评情界面,刷新评论数量
                                topicAnswerDetailFragment.refreshAnswerDiscussNum();
                            }

                        }
                    }

                }
                break;

            case Config.MODULE_COMPETITION + 14://话题答案点赞
                Logger.i(Logger.DATA_FLOW_TAG, "话题答案点赞:" + result);
                TopicAnswerLike topicAnswerLike = JsonHelper.getObject(result, TopicAnswerLike.class);
                if (topicAnswerLike != null) {
                    int code = topicAnswerLike.getCode();
                    if (code == 0) {
                        discoveryFragmentShouldReload = true;
                        showAppMessage(R.string.activity_topic_detail_like_success, AppMsg.STYLE_INFO);
                    }
                    int upNum = topicAnswerLike.getUpNum();
                    if (topicAnswerDetailFragment != null) {
                        topicAnswerDetailFragment.setAnswerLikeNum(upNum);
                    }
                }
                break;
            case Config.MODULE_COMPETITION + 16://根据话题答案编号,获取话题答案
                Logger.i(Logger.DATA_FLOW_TAG, "根据话题答案编号,获取话题答案:" + result);
                TopicAnswerById topicAnswerById = JsonHelper.getObject(result, TopicAnswerById.class);
                if (topicAnswerById != null) {
                    myTopicAnswer = topicAnswerById.getAnswer();

                    if (isFromNoticeFragmentAnswer) {
                        goToTopicAnswerDetail(myTopicAnswer, 0);
                    }

                    if (isFromNoticeFragmentDiscuss) {
                        goToTopicAnswerDiscuss(myTopicAnswer);
                    }
                }
                break;
            case Config.MODULE_COMPETITION + 22://评论答案点赞
                Logger.d(Logger.DATA_FLOW_TAG, "评论答案点赞:" + result);
                TopicDiscussLike topicDiscussLike = JsonHelper.getObject(result, TopicDiscussLike.class);
                if (topicDiscussLike != null) {
                    int code = topicDiscussLike.getCode();
                    if (code == 0) {
                        discoveryFragmentShouldReload = true;
                        showAppMessage(R.string.activity_topic_detail_like_success, AppMsg.STYLE_INFO);
                        if (topicAnswerDiscussFragment != null) {
                            topicAnswerDiscussFragment.refreshDiscussView(discussLike);
                        }
                    }
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        Logger.e(Logger.DEBUG_TAG, "TopicDetailActivity processReqError requestId:" + requestId + " error:" + error);
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            String msg = bean.getMsg();
            if (!TextUtils.isEmpty(msg)) {
                showAppMessage(msg, AppMsg.STYLE_ALERT);
            }
        }

        switch (requestId) {
            case Config.MODULE_COMPETITION + 13://添加话题答案的评论
                topicAnswerDiscussFragment.clearCommentContent();
                break;
            case Config.MODULE_COMPETITION + 6://根据话题编号,获取该话题的回答列表
                if (topicDetailFragment != null) {
                    topicDetailFragment.resetRefreshLoadMoreUi(false);
                    topicDetailFragment.refresh();
                }
                break;
        }
        super.processReqError(requestId, error);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        //回退fragment栈
        int stackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
//        Logger.i(Logger.DEBUG_TAG, "TopicDetailActivity-->onBackPressed stackEntryCount:" + stackEntryCount);
        if (stackEntryCount > 0) {
            if (ftCanCommit) {
                getSupportFragmentManager().popBackStack();
                if (isFromNoticeFragmentDiscuss || isFromNoticeFragmentAnswer) {
                    finish();
                }
                if (stackEntryCount == 1) {
                    setTitleText(R.string.title_activity_topic_detail);
                    if (topicDetailFragment != null) {
                        topicDetailFragment.refresh();
                    }
                } else if (stackEntryCount == 2) {
                    //   setUiTitle(getString(R.string.title_fragment_topic_answer_detail)+" ("+topicAnswerDiscussFragment.getTopicAnswer().getTaoLunNum()+")");
                    setTitleText(R.string.title_fragment_topic_answer_detail);
                }
            }

        } else {
//            Logger.i(Logger.DEBUG_TAG, "TopicDetailActivity-->discoveryFragmentShouldReload:" + discoveryFragmentShouldReload);
            if (discoveryFragmentShouldReload) {
                setResult(RESULT_OK);
            }
            super.onBackPressed();
        }
    }

    public void doClick(View v) {
        switch (v.getId()) {
            //region ============================ TopicDetailFragment ============================

            //endregion ============================ TopicDetailFragment ============================

            //region ============================ TopicAnswerDiscussFragment ============================
            case R.id.btn_submit_discuss://提交评论
                hideInputMethod();
                submitDiscuss();
                break;
            //endregion ============================ TopicAnswerDiscussFragment ============================
        }
    }


    //region ============================ TopicDetailFragment 话题详情界面 ============================

    /**
     * 创建话题详情界面
     */
    private void createTopicDetailFragment() {
        topicDetailFragment = new TopicDetailFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("topicId", topicId);
        topicDetailFragment.setArguments(bundle);

        topicDetailFragmentCallback = new TopicDetailFragment.TopicDetailFragmentCallback() {
            @Override
            public void onAnswerButtonClick(int answerId) {
                if (answerId == 0) {
                    goToAddTopicAnswerActivity();
                } else {
                    if (myTopicAnswer != null) {//查看答案
                        goToTopicAnswerDetail(myTopicAnswer, -1);
                    }
                }
            }

            @Override
            public void onAnswerItemClick(TopicAnswer topicAnswer, int position) {
                goToTopicAnswerDetail(topicAnswer, position);
            }

            @Override
            public void onAnswerCommentClick(TopicAnswer topicAnswer) {
                goToTopicAnswerDiscuss(topicAnswer);
            }

            @Override
            public void onRefresh() {
                pageNo = 1;
                if (mTopicAnswerList != null) {
                    mTopicAnswerList.clear();
                }
                if (topicDetailFragment != null) {
                    topicDetailFragment.refresh();
                }
                getTopicAnswerList();
            }

            @Override
            public void onLoadMore() {//加载更多
                getTopicAnswerList();
            }

            @Override
            public void onAnswerListOrderTypeChange(int orderType) {
                if (answerListOrderType != orderType) {//重新更新数据集
                    answerListOrderType = orderType;
                    pageNo = 1;
                    if (mTopicAnswerList != null) {
                        mTopicAnswerList.clear();
                    }
                    if (topicDetailFragment != null) {
                        topicDetailFragment.refresh();
                    }
                    getTopicAnswerList();
                }
            }

        };
        topicDetailFragment.setTopicDetailFragmentCallback(topicDetailFragmentCallback);
        topicDetailFragment.setTopicAnswerList(mTopicAnswerList);

        if (topic != null) {
            topicDetailFragment.setTopic(topic);
            if (topic.getAnswerId() > 0) {//获取当前用户对该话题的回答
                getTopicAnswerByAnswerId(topic.getAnswerId());
            }
        }
        getSupportFragmentManager().beginTransaction()
//                .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, 0, 0)
                .add(R.id.mainContainer, topicDetailFragment, TopicDetailFragment.TAG)
                .commit();
    }

    /**
     * 根据话题答案编号,获取话题答案
     *
     * @param answerId 话题答案编号
     */
    private void getTopicAnswerByAnswerId(int answerId) {
        int requestId = DiscoverDataManager.getInstance().getTopicAnswerByAnswerId(answerId, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 导航到答案详情界面
     *
     * @param topicAnswer 答案信息
     * @param position    答案信息在当前答案列表中的位置,-1表示查看自己的回答
     */
    private void goToTopicAnswerDetail(TopicAnswer topicAnswer, int position) {
        if (topicAnswer != null) {
            topicAnswerDetailFragment = new TopicAnswerDetailFragment();
            Bundle bundle = new Bundle();
//            bundle.putInt("topicId", topicAnswer.getParentThemeId());//话题编号
//            bundle.putInt("answerId", topicAnswer.getId());
            bundle.putBoolean("viewMyAnswer", position == -1);
            topicAnswerDetailFragment.setArguments(bundle);

            if (topic != null) {
                topicAnswerDetailFragment.setTopicTitle(topic.getTitle());
            }
            topicAnswerDetailFragment.setTopicAnswer(topicAnswer);
            topicAnswerDetailFragment.setTopicAnswerList(mTopicAnswerList);
            topicAnswerDetailFragment.setPosition(position);
            topicAnswerDetailFragment.setActionClickListener(this);
            if (ftCanCommit) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                        .add(R.id.mainContainer, topicAnswerDetailFragment, TopicAnswerDetailFragment.TAG)
                        .addToBackStack(null)
                        .commit();//
            }
        }
    }

    /**
     * 导航到添加话题答案界面
     */
    private void goToAddTopicAnswerActivity() {
        Intent intent = new Intent(this, AddTopicAnswerActivity.class);
        intent.putExtra("topicId", topicId);
        intent.putExtra("answerType", AddTopicAnswerActivity.ANSWER_TYPE_NEW);
        startActivityForResult(intent, REQUEST_ADD_TOPIC_ANSWER);
    }

    /**
     * 获取话题回答列表
     *
     * @param answerListOrderType 结果排序类型,1:根据添加时间排序,2:根据回答数排序,3:根据点赞数排序,4:根据综合质量排序
     * @param pageNo              页码
     */
    public void getTopicAnswerList(int answerListOrderType, int pageNo) {
        int requestId = DiscoverDataManager.getInstance().getTopicAnswerList(topicId, answerListOrderType, 0, pageNo, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 以当前设置的排序类型和页码获取话题回答列表
     */
    public void getTopicAnswerList() {
        getTopicAnswerList(answerListOrderType, pageNo);
    }

    //endregion ============================ TopicDetailFragment 话题详情界面 ============================


    //region ============================ TopicAnswerDetailFragment ============================

    /**
     * 导航到答案评论详情界面
     */
    private void goToTopicAnswerDiscuss(TopicAnswer topicAnswer) {
        if (topicAnswer != null) {
            topicAnswerDiscussFragment = new TopicAnswerDiscussFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("topicId", topicAnswer.getParentThemeId());//话题编号
            bundle.putInt("answerId", topicAnswer.getId());
            topicAnswerDiscussFragment.setArguments(bundle);
            topicAnswerDiscussFragment.setTopicAnswer(topicAnswer);
            topicAnswerDiscussFragment.setActionClickListener(this);
            if (ftCanCommit) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                        .add(R.id.mainContainer, topicAnswerDiscussFragment, TopicAnswerDiscussFragment.TAG)
                        .addToBackStack(null)
                        .commit();//
            }

            getTopicDiscussList(topicAnswer.getId(), 0);
        }
    }


    @Override
    public void onLikeButtonClick(TopicAnswer topicAnswer, boolean isLike) {
        if (topicAnswer != null) {
            int answerId = topicAnswer.getId();
            int type = isLike ? 1 : 0;
            int requestId = DiscoverDataManager.getInstance().likeTopicAnswer(answerId, type, true);
            registerDataReqStatusListener(requestId);
        }
    }

    @Override
    public void onEditAnswerClick(TopicAnswer topicAnswer) {
        //编辑答案功能
        if (topicAnswer != null) {
            Intent intent = new Intent(this, AddTopicAnswerActivity.class);
            intent.putExtra("topicId", topicId);
            intent.putExtra("answerId", topicAnswer.getId());
            intent.putExtra("answerType", AddTopicAnswerActivity.ANSWER_TYPE_EDIT);
            String contentKey = topicId + "_" + topicAnswer.getUid() + "_answer";
            String answerContent = topicAnswer.getContent();
//            Logger.i(Logger.DEBUG_TAG, "onEditAnswerClick contentKey:" + contentKey + "\nanswerContent:" + answerContent);
            MyConfig.getInstance().getMemExchange().setTopicContent(contentKey, answerContent);
            startActivityForResult(intent, REQUEST_EDIT_TOPIC_ANSWER);
        } else {
            showAppMessage("暂时不能编辑", AppMsg.STYLE_ALERT);
        }
    }

    @Override
    public void onShareAnswerClick(String topicTitle, TopicAnswer topicAnswer) {
        //分享答案
        if (topicAnswer != null && topicTitle != null) {
            String sContent = "";
            if (topicAnswer.getContent() != null) {
                String html = null;//URL加密
                try {
                    html = java.net.URLDecoder.decode(topicAnswer.getContent(), "UTF-8");
                    html = html.replaceAll("<img([\\w\\W]+?)[\\/]?>", getString(R.string.topic_answer_image_holder));//img标签替代
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                if (!TextUtils.isEmpty(html)) {
                    sContent = html.substring(0, html.length() > 150 ? 150 : html.length());
                }
            }

            String baseUrl = PrefsHelper.with(this, Config.PREFS_COMPETITION).read(Config.SP_KEY_TOPIC_ANSWER_SHARE);

            if (!TextUtils.isEmpty(baseUrl)) {
                String url = baseUrl + "?answerId=" + topicAnswer.getId();

                ShareManager share = new ShareManager(this);
                share.setContent(sContent);
                share.setFilename(ShareManager.DEFAULT_FILE_NAME);
                share.setTitle(topicTitle);
                share.setUrl(url);
                share.share();
            }
        }

    }

    @Override
    public void onViewCommentClick(TopicAnswer topicAnswer) {
        goToTopicAnswerDiscuss(topicAnswer);
    }
    //endregion ============================ TopicAnswerDetailFragment ============================

    //region ============================ TopicAnswerDiscussFragment ============================

    /**
     * 获取答案的评论列表
     *
     * @param answerId 答案ID
     * @param pageNo   分页页码
     */
    public void getTopicDiscussList(int answerId, int pageNo) {
        int requestId = DiscoverDataManager.getInstance().getTopicDiscussList(answerId, pageNo, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 提交对答案的评论
     */
    private void submitDiscuss() {
        if (topicAnswerDiscussFragment != null) {
            if (isFromTopicDiscussReply) {
                String commentContent = topicAnswerDiscussFragment.getDiscussContent();
                if (StringUtils.isBlank(commentContent)) {
                    showAppMessage(R.string.fragment_topic_discuss_content_empty, AppMsg.STYLE_ALERT);
                    return;
                }
                String contentKey = discussThemeUid + "_" + System.currentTimeMillis() + "_discuss";
                MyConfig.getInstance().getMemExchange().setTopicContent(contentKey, commentContent);
                if (discussUid == 0) {
                    showAppMessage(R.string.fragment_topic_discuss_content_err, AppMsg.STYLE_ALERT);
                    topicAnswerDiscussFragment.refreshPublishDiscussEditText();
                } else {
                    int requestId = DiscoverDataManager.getInstance().addTopicAnswerDiscussToOne(discussThemeUid, discussId, discussUid, contentKey, true);
                    registerDataReqStatusListener(requestId);
                }

            } else {
                int answerId = topicAnswerDiscussFragment.getAnswerId();
                String commentContent = topicAnswerDiscussFragment.getDiscussContent();
                if (StringUtils.isBlank(commentContent)) {
                    showAppMessage(R.string.fragment_topic_discuss_content_empty, AppMsg.STYLE_ALERT);
                    return;
                }
                String contentKey = answerId + "_" + System.currentTimeMillis() + "_discuss";
                MyConfig.getInstance().getMemExchange().setTopicContent(contentKey, commentContent);
                int requestId = DiscoverDataManager.getInstance().addTopicAnswerDiscussToOne(answerId, 0, 0, contentKey, true);
                registerDataReqStatusListener(requestId);
            }
            hideInputMethod();//隐藏键盘
        } else {
            showAppMessage(R.string.fragment_topic_discuss_submit_fail, AppMsg.STYLE_ALERT);
        }
    }

    /**
     * 提交对评论的点赞
     */
    @Override
    public void onDiscussLikeButtonClick(TopicDiscuss topicDiscuss, boolean isLike) {
        if (topicDiscuss != null) {
            discussLike = isLike;
            int answerId = topicDiscuss.getId();
            int type = isLike ? 1 : 0;
            int requestId = DiscoverDataManager.getInstance().likeTopicDiscuss(answerId, type, true);
            registerDataReqStatusListener(requestId);

            Logger.d(Logger.DEBUG_TAG, "discussId:" + answerId);
        }
    }

    /**
     * 提交对评论的回复
     */
    @Override
    public void onEditAnswerDiscussClick(TopicDiscuss topicDiscuss, boolean isFromReplyDiscuss) {
        discussThemeUid = topicDiscuss.getThemeId();
        discussUid = topicDiscuss.getDiscussUid();
        discussId = topicDiscuss.getId();
        Logger.d(Logger.DATA_FLOW_TAG, "discussUid:" + discussUid + " discussId:" + discussId);
        isFromTopicDiscussReply = isFromReplyDiscuss;
    }

    //endregion ============================ TopicAnswerDiscussFragment ============================


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        Logger.i(Logger.DEBUG_TAG, "TopicDetailActivity-->onActivityResult requestCode:" + requestCode + ",resultCode:" + resultCode);
        switch (requestCode) {
            case REQUEST_ADD_TOPIC_ANSWER://我要回答
                if (resultCode == RESULT_OK) {
                    discoveryFragmentShouldReload = true;
                    String newTopicAnswerJsonStr = MyConfig.getInstance().getMemExchange().getTopicContent(topicId + "_new_answer");
                    if (newTopicAnswerJsonStr != null) {
                        TopicAnswer topicAnswer = JsonHelper.getObject(newTopicAnswerJsonStr, TopicAnswer.class);
                        if (topicAnswer != null) {
                            if (topic != null) {//设置当前用户回答了该话题,界面下方按钮变成"查看回答"
                                topic.setDiscussNum(topic.getDiscussNum() + 1);//回答数加1
                                topic.setAnswerId(topicAnswer.getId());
                            }
                            myTopicAnswer = topicAnswer;
                            if (topicDetailFragment != null) {
                                topicDetailFragment.addNewTopicAnswer(topicAnswer);
                            }
                        }
                    }
                    MyConfig.getInstance().getMemExchange().removeTopicContent(topicId + "_new_answer");
                }
                break;

            case REQUEST_EDIT_TOPIC_ANSWER://修改回答
                if (resultCode == RESULT_OK) {
                    discoveryFragmentShouldReload = true;
                    String newTopicAnswerJsonStr = MyConfig.getInstance().getMemExchange().getTopicContent(topicId + "_edit_answer");
                    if (newTopicAnswerJsonStr != null) {
                        if (myTopicAnswer != null) {
                            myTopicAnswer.setContent(newTopicAnswerJsonStr);//更新回答内容
                            if (topicDetailFragment != null) {//更新话题详情界面列表中,我的回答内容
                                TopicAnswerAdapter topicAnswerAdapter = topicDetailFragment.getTopicAnswerAdapter();
                                if (topicAnswerAdapter != null) {
                                    for (TopicAnswer topicAnswer : topicAnswerAdapter.getTopicAnswerList()) {
                                        if (topicAnswer.getId() == myTopicAnswer.getId()) {
                                            topicAnswer.setContent(newTopicAnswerJsonStr);
                                        }
                                    }
                                }
                                topicDetailFragment.refresh();
                            }
                            if (topicAnswerDetailFragment != null) {
                                topicAnswerDetailFragment.setTopicAnswer(myTopicAnswer);
                                topicAnswerDetailFragment.refresh();
                            }
                        }
                    }
                    MyConfig.getInstance().getMemExchange().removeTopicContent(topicId + "_edit_answer");
                }
                break;
        }
    }
}
