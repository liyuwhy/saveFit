package com.fitmix.sdk.view.activity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.common.ThreadManager;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.bean.AppInformation;
import com.fitmix.sdk.view.fragment.WatchAppNotifyFragment;
import com.fitmix.sdk.view.fragment.WatchAppNotifyListFragment;
import com.fitmix.sdk.watch.bean.WatchAppNotify;
import com.fitmix.sdk.watch.notification.NotificationMonitor;

import java.util.ArrayList;
import java.util.List;

/**
 * 手表APP消息通知管理界面
 */
public class WatchAppNotifyActivity extends BaseActivity implements WatchAppNotifyFragment.WatchAppNotifyFragmentCallback {

    /**
     * 为乐享动请求监听通知的权限
     */
    private final int REQUEST_NOTIFICATION_LISTENER = 808;

    private WatchAppNotifyFragment watchAppNotifyFragment;//APP通知设置界面
    private WatchAppNotifyListFragment watchAppNotifyListFragment;//APP通知管理应用界面

    private List<AppInformation> appInfoList;//已安装APP列表
    private List<AppInformation> selectedAppInfoList;//已选择APP列表

    private WatchAppNotify appNotify;//APP通知设置

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watch_notify_base);
        initToolbar();
        initViews();
        //获取设置
        String appNotifyStr = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_WATCH_APP_NOTIFY);
        appNotify = JsonHelper.getObject(appNotifyStr, WatchAppNotify.class);

        ThreadManager.executeOnSubThread1(new Runnable() {
            @Override
            public void run() {
                getInstalledApp();//获取已安装APP列表信息,耗时
            }
        });

        if (savedInstanceState == null) {
            watchAppNotifyFragment = new WatchAppNotifyFragment();
            if (appNotify != null) {
                watchAppNotifyFragment.setAppSwitchNotify(appNotify.isAppNotify());
                watchAppNotifyFragment.setScreenSwitchNotify(appNotify.isScreenOffNotify());
                watchAppNotifyFragment.setSelectedAppList(selectedAppInfoList);
            } else {
                appNotify = new WatchAppNotify();
            }

            watchAppNotifyFragment.setWatchAppNotifyFragmentCallback(this);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.mainContainer, watchAppNotifyFragment, WatchAppNotifyFragment.TAG)
                    .commit();
        }
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.btn_app_list://管理应用
                watchAppNotifyListFragment = new WatchAppNotifyListFragment();
                watchAppNotifyListFragment.setInstallAppList(appInfoList);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.mainContainer, watchAppNotifyListFragment, WatchAppNotifyListFragment.TAG)
                        .setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_in, R.anim.push_right_out)
                        .addToBackStack(null)
                        .commit();
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home://pop fragment
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //回退fragment栈
        int stackEntryCount = getSupportFragmentManager().getBackStackEntryCount();
        if (stackEntryCount > 0) {
            if (ftCanCommit) {
                getSupportFragmentManager().popBackStack();
            }

            //从WatchAppNotifyListFragment返回,需要重新刷新标题和列表
            setToolbarTitle(R.string.title_activity_watch_app_notify);
            if (appInfoList != null && selectedAppInfoList != null) {
                selectedAppInfoList.clear();
                List<String> appList = null;
                if (appNotify != null) {
                    appList = appNotify.getAppList();
                } else {
                    appNotify = new WatchAppNotify();
                }

                if (appList == null) {
                    appList = new ArrayList<>();
                }

                appList.clear();

                for (AppInformation info : appInfoList) {
                    if (info.isNotifyEnable()) {
                        selectedAppInfoList.add(info);
                        appList.add(info.getAppPackageName());
                    }
                }
                appNotify.setAppList(appList);
                String jsonString = JsonHelper.createJsonString(appNotify);
                PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_APP_NOTIFY, jsonString);
            }
            if (watchAppNotifyFragment != null) {
                watchAppNotifyFragment.setSelectedAppList(selectedAppInfoList);
            }
        } else {
            setResult();
        }
    }

    /**
     * 设置页面结果给请求activity
     */
    private void setResult() {
        setResult(RESULT_OK);//都是成功,
        finish();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                onBackPressed();
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 设置界面标题
     */
    public void setToolbarTitle(int resId) {
        String title = getString(resId);
        if (!TextUtils.isEmpty(title)) {
            setUiTitle(title);
        }
    }

    /**
     * 获取已安装APP列表信息
     */
    private void getInstalledApp() {
        appInfoList = new ArrayList<>();
        selectedAppInfoList = new ArrayList<>();
        List<PackageInfo> packageInfoList = getPackageManager().getInstalledPackages(0);
        if (packageInfoList != null) {
            PackageInfo packageInfo;
            String appName;
            String appPackageName;
            for (int i = 0; i < packageInfoList.size(); i++) {
                packageInfo = packageInfoList.get(i);
                appPackageName = packageInfo.packageName;
                appName = packageInfo.applicationInfo.loadLabel(getPackageManager()).toString();
                if (isSystemPackage(packageInfo)) {//过滤系统应用
                    continue;
                }
                AppInformation appInfo = new AppInformation();
                appInfo.setAppPackageName(appPackageName);
                appInfo.setAppName(appName);
                appInfo.setAppIcon(packageInfo.applicationInfo.loadIcon(getPackageManager()));
                appInfoList.add(appInfo);
            }
        }
        //获取已选择的APP信息
        List<String> appList = appNotify.getAppList();
        if (appList != null && appList.size() > 0) {
            if (appInfoList != null) {
                for (AppInformation appInfo : appInfoList) {
                    for (int i = 0; i < appList.size(); i++) {
                        if (appList.get(i).equalsIgnoreCase(appInfo.getAppPackageName())) {
                            appInfo.setNotifyEnable(true);
                            selectedAppInfoList.add(appInfo);
                        }
                    }
                }
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (watchAppNotifyFragment != null) {
                        watchAppNotifyFragment.setSelectedAppList(selectedAppInfoList);
                    }
                }
            });
        }
        Logger.i(Logger.DEBUG_TAG, "getInstalledApp appInfoList size:" + appInfoList.size());
    }

    /**
     * 是否为系统应用
     */
    private boolean isSystemPackage(PackageInfo pkgInfo) {
        return pkgInfo != null && (pkgInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
    }

    //region ================================== WatchAppNotifyFragment相关 ==================================
    @Override
    public void appSwitchCheckChanged(boolean isChecked) {
        if (isChecked) {
            Intent intent = new Intent(this, NotificationMonitor.class);
            startService(intent);
            if (!isNotificationListenEnabled()) {
                requestNotificationListener();
                return;
            }
        } else {
            Intent intent = new Intent(this, NotificationMonitor.class);
            stopService(intent);
        }
        if (appNotify != null) {
            appNotify.setAppNotify(isChecked);
            if (!isChecked) {//关闭APP通知时,也关闭熄屏通知
                appNotify.setScreenOffNotify(false);
            }
            String jsonString = JsonHelper.createJsonString(appNotify);
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_APP_NOTIFY, jsonString);
        }

    }

    @Override
    public void screenSwitchCheckChanged(boolean isChecked) {
        if (appNotify != null) {
            appNotify.setScreenOffNotify(isChecked);
            String jsonString = JsonHelper.createJsonString(appNotify);
            PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_APP_NOTIFY, jsonString);
        }
    }

    //endregion ================================== WatchAppNotifyFragment相关 ==================================

    //region ================================== 消息通知相关 ==================================

    /**
     * 判断当前应用是否有监听通知的权限
     *
     * @return true:是,false:否
     */
    public boolean isNotificationListenEnabled() {
        String pkgName = getPackageName();
        final String flat = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 请求监听通知的权限
     */
    public void requestNotificationListener() {
        Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
        startActivityForResult(intent, REQUEST_NOTIFICATION_LISTENER);
    }

    //endregion ================================== 消息通知相关 ==================================


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_NOTIFICATION_LISTENER:
                //重新判断是否获取了权限
                boolean enabled = isNotificationListenEnabled();
                if (watchAppNotifyFragment != null) {
                    watchAppNotifyFragment.setAppSwitchNotify(enabled);
                }

                if (appNotify != null) {
                    appNotify.setAppNotify(enabled);
                    String jsonString = JsonHelper.createJsonString(appNotify);
                    PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_WATCH_APP_NOTIFY, jsonString);
                }
                break;
        }
    }
}
