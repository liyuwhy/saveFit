package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;

import com.fitmix.sdk.R;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.view.dialog.LevelUpgradeDialog;
import com.fitmix.sdk.view.dialog.QuestRewardsDialog;

import java.util.LinkedList;
import java.util.Queue;

/**
 * 对话框样式的activity,用于管理需要连续弹窗的情况或母activity即将销毁的情况
 */
public class DialogContainerActivity extends BaseActivity implements QuestRewardsDialog.OnQuestRewardsDialogDismiss, LevelUpgradeDialog.OnLevelUpgradeDialogDismiss {

    private Queue<DialogFragment> dialogs;

    /**
     * 当前是否有显示的对话框
     */
    private boolean isShow;
    /**
     * 任务列表
     */
    private Queue<String> taskNames;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setFinishOnTouchOutside(false);//禁止点击边框空白处销毁
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_container);

        Intent intent = getIntent();
        createDialog(intent);

        Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->onCreate getIntent is null:" + (intent == null));
    }


    @Override
    protected void onResume() {
        super.onResume();
        Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->onResume");
        if (getDialogQueue().size() > 0 && !isShow) {
            DialogFragment nextDialog = getDialogQueue().poll();
            getTaskNames().poll();
            if (nextDialog != null && ftCanCommit) {
                nextDialog.show(getSupportFragmentManager(), "");
                isShow = true;
            }
        }
    }

    @Override
    protected void initViews() {
        //不处理
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->onNewIntent intent is null:" + (intent == null));
        createDialog(intent);
    }

    /**
     * 获取对话框队列
     */
    private Queue<DialogFragment> getDialogQueue() {
        if (dialogs == null) {
            dialogs = new LinkedList<>();
        }

        return dialogs;
    }

    private Queue<String> getTaskNames() {
        if (taskNames == null) {
            taskNames = new LinkedList<>();
        }
        return taskNames;
    }


    @Override
    public void onRewardsDialogDismiss() {
        Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->dialog onRewardsDialogDismiss callback!");
        if (getDialogQueue().size() > 0) {
            DialogFragment nextDialog = getDialogQueue().poll();
            getTaskNames().poll();
            if (nextDialog != null && ftCanCommit) {
                nextDialog.show(getSupportFragmentManager(), "");
            }
        } else {
            finish();
        }
    }

    @Override
    public void onLevelUpDialogDismiss() {
        Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->dialog onLevelUpDialogDismiss callback!");
        if (getDialogQueue().size() > 0) {
            DialogFragment nextDialog = getDialogQueue().poll();
            getTaskNames().poll();
            if (nextDialog != null && ftCanCommit) {
                nextDialog.show(getSupportFragmentManager(), "");
            }
        } else {
            finish();
        }
    }

    /**
     * 从intent信息中创建Dialog
     */
    private void createDialog(Intent intent) {
        if (intent != null) {
            int dialogType = intent.getIntExtra("dialogType", 0);//1.用户等级升级,2:金币奖励
            int rewardCoin = intent.getIntExtra("rewardCoin", 0);
            String taskName = intent.getStringExtra("taskName");

            boolean created = false;//是否已经有创建
            for (String name : getTaskNames()) {
                if (taskName != null && taskName.equals(name)) {
                    created = true;
                }
            }

            if (created) {//有创建的话,不再重复创建
                return;
            }

            switch (dialogType) {
                case 1://用户等级升级
                    createQuestRewardDialog(rewardCoin, taskName);
                    int prevLevel = intent.getIntExtra("prevLevel", 0);
                    int level = intent.getIntExtra("level", 0);
                    createLevelUpgradeDialog(prevLevel, level);
                    break;

                case 2://金币奖励
                    createQuestRewardDialog(rewardCoin, taskName);
                    break;
            }
        }

    }

    /**
     * 创建金币奖励对话框
     *
     * @param rewardCoin 奖励金币数量
     * @param taskName   任务名称
     */
    private void createQuestRewardDialog(int rewardCoin, String taskName) {
        if (rewardCoin > 0 && taskName != null) {
            QuestRewardsDialog dialog = new QuestRewardsDialog();
            if (dialog != null) {
                dialog.setRewardCoin(rewardCoin)
                        .setTaskName(taskName)
                        .setCancelable(false);//防止用户误碰没有看清奖励
                dialog.setOnQuestRewardsDialogDismiss(this);

                getDialogQueue().offer(dialog);
                getTaskNames().offer(taskName);
                Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->createDialog createQuestRewardDialog rewardCoin:" + rewardCoin + ",taskName:" + taskName);
            }
        }
    }


    /**
     * 创建跑步等级升级动画对话框
     *
     * @param prevLevel 用户升级前的等级,[0,15]
     * @param level     用户升级后的等级,[1,16]
     */
    protected void createLevelUpgradeDialog(int prevLevel, int level) {
        if (prevLevel >= 0 && prevLevel < level && level < 17) {
            LevelUpgradeDialog dialog = new LevelUpgradeDialog();
            if (dialog != null) {
                dialog.setPrevLevel(prevLevel).setLevel(level);
                dialog.setOnLevelUpDialogDismiss(this);
                getDialogQueue().offer(dialog);
                getTaskNames().offer("levelUp");
                Logger.i(Logger.DEBUG_TAG, "DialogContainerActivity-->createDialog createLevelUpgradeDialog prevLevel:" + prevLevel + ",level:" + level);
            }
        }

    }


}
