package com.fitmix.sdk.view.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.Music;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.OperateMusicUtils;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.Training;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.view.dialog.NumberPickerFragment;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.fragment.TrainingDateFragment;
import com.fitmix.sdk.view.fragment.TrainingListFragment;
import com.fitmix.sdk.view.widget.AppMsg;

public class TrainingPlanActivity extends BaseActivity {

    private static final int LIST_MODE = 0;
    private static final int DATE_MODE = 1;
    private static final int CREATE_PLAN = 1001;
    private int currentMode = 0;

    private MenuItem menu_second;
    private TrainingListFragment trainingListFragment;
    private TrainingDateFragment trainingDateFragment;
    private Fragment mTempFragment;

    private boolean canChangeMode = false;
    private boolean createNewPlan = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training_plan);
        initToolbar();
        initViews();
        //parserData(getResourceAsStream());
        getTrainingPlanData();
    }

    @Override
    protected void initViews() {
        //showGoToPlayMusicMenu = true;//显示音乐播放状态导航菜单
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        changeShowMode();
    }

    /**
     * 获取进行中的训练计划
     */
    private void getTrainingPlanData() {
        showGetTrainPlanDialog();
        int requestId = SportDataManager.getInstance().getTrainingPlan();
        registerDataReqStatusListener(requestId);
    }

    private void showGetTrainPlanDialog() {
        loadingDialog = new MaterialDialog.Builder(this)
                .iconRes(R.drawable.notification_icon)
                .title(R.string.prompt)
                .content(R.string.activity_training_plan_get_plan)
                .cancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        finish();
                    }
                })
                .show();
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        Logger.i(Logger.DEBUG_TAG, "TrainingPlanActivity getDataReqStatusNotify requestId:" + dataReqResult.getRequestId()
                + "\n result:" + dataReqResult.getResult());
        int requestId = dataReqResult.getRequestId();
        switch (requestId) {
            case Config.MODULE_SPORT + 31://获取进行中的计划
                hideLoadingDialog();
                parserData(dataReqResult.getResult());
                break;
            case Config.MODULE_SPORT + 33://延期计划
                parserData(dataReqResult.getResult());
                break;
            case Config.MODULE_SPORT + 34://删除计划
                finish();
                break;
        }
    }


    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        switch (requestId) {
            case Config.MODULE_SPORT + 31://获取进行中的计划
                hideLoadingDialog();
                if (bean != null) {
                    switch (bean.getCode()) {
                        case 3012://获取到没有计划
                            showDialog();
                            break;
                        default:
                            showErrorDialog();
                            break;
                    }
                }
                break;
            case Config.MODULE_SPORT + 33://延期计划
                if (bean != null) {
                    switch (bean.getCode()) {
                        case 3015://延期计划失败
                            showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                            break;
                        default:
                            super.processReqError(requestId, error);
                            break;
                    }
                }
                break;
            case Config.MODULE_SPORT + 34://删除计划
                super.processReqError(requestId, error);
                break;
        }
    }

    private void showDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_training_plan_get_no_plan)
                .positiveText(R.string.activity_training_plan_to_create_now)
                .negativeText(R.string.activity_training_plan_to_create_next)
                .cancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        finish();
                    }
                })
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://开始创建
                                goToCreateTrainingPlanActivity(false);
                                break;
                            case NEGATIVE:
                                finish();
                                break;
                        }
                    }
                }).show();
    }

    private void showErrorDialog() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_training_plan_get_plan_error)
                .positiveText(R.string.activity_training_plan_get_plan_again)
                .negativeText(R.string.activity_training_plan_get_plan_give_up)
                .cancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        finish();
                    }
                })
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://获取数据
                                getTrainingPlanData();
                                break;
                            case NEGATIVE:
                                finish();
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 导航到创建训练计划界面
     *
     * @param createNewPlan 是否是创建的新计划
     */
    public void goToCreateTrainingPlanActivity(boolean createNewPlan) {
        this.createNewPlan = createNewPlan;
        Intent intent = new Intent(this, CreateTrainPlanActivity.class);
        startActivityForResult(intent, CREATE_PLAN);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        switch (currentMode) {
            case LIST_MODE:
                menu_second = menu.add(0, Menu.FIRST + 4, 4, "training_list").setIcon(R.drawable.icon_training_date);
                break;
            case DATE_MODE:
                menu_second = menu.add(0, Menu.FIRST + 4, 4, "training_date").setIcon(R.drawable.icon_training_list);
                break;
        }
        menu_second.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case Menu.FIRST + 4://切换模式
                if (canChangeMode) {
                    currentMode = (currentMode + 1) % 2;
                    changeShowMode();
                    invalidateOptionsMenu();
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void changeShowMode() {
        switch (currentMode) {
            case LIST_MODE:
                switchFragment(getTrainingListFragment());
                break;
            case DATE_MODE:
                switchFragment(getTrainingDateFragment());
                break;
        }
    }

    private void parserData(String result) {
        Training training = JsonHelper.getObject(result, Training.class);
        if (training != null) {
            getTrainingListFragment().setTrainingData(training);
            getTrainingDateFragment().setTrainingData(training);
            canChangeMode = true;
        }
    }

    public void setStepColor(int colorResId) {
        getTrainingDateFragment().setStepColor(colorResId);
    }

    public void setStepTitle(String stepTitle) {
        getTrainingDateFragment().setStepTitle(stepTitle);
    }

//    private Training getDummyDataSet() {
//        Gson gson = new Gson();
//        Training training = null;
//        try {
//            String trainingString = getResourceAsStream();
//            training = gson.fromJson(trainingString, Training.class);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return training;
//    }

//    private String getResourceAsStream() {
//        /*获取到assets文件下的TExt.json文件的数据，并以输出流形式返回。*/
//        InputStream is = getClass().getClassLoader().getResourceAsStream("assets/" + "test1.json");
//        InputStreamReader streamReader = new InputStreamReader(is);
//        BufferedReader reader = new BufferedReader(streamReader);
//        String line = "";
//        StringBuilder stringBuilder = new StringBuilder();
//        try {
//            while ((line = reader.readLine()) != null) {
//                stringBuilder.append(line);
//            }
//            reader.close();
//            reader.close();
//            is.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return stringBuilder.toString();
//    }

    /**
     * 使用hide和show方法切换Fragment
     *
     * @param fragment 需要切换的fragment
     */
    private void switchFragment(Fragment fragment) {
        if (fragment != mTempFragment) {
            if (mTempFragment != null) {
                if (!fragment.isAdded()) {
                    getSupportFragmentManager().beginTransaction().hide(mTempFragment)
                            .add(R.id.training_plan_Container, fragment).commitAllowingStateLoss();
                } else {
                    getSupportFragmentManager().beginTransaction().hide(mTempFragment)
                            .show(fragment).commitAllowingStateLoss();
                }
            } else {
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.training_plan_Container, fragment).commitAllowingStateLoss();
            }
            mTempFragment = fragment;
        }
    }

    /**
     * 获取训练列表形式Fragment
     */
    private TrainingListFragment getTrainingListFragment() {
        if (trainingListFragment == null) {
            trainingListFragment = new TrainingListFragment();
        }
        return trainingListFragment;
    }

    /**
     * 获取训练日期形式Fragment
     */
    private TrainingDateFragment getTrainingDateFragment() {
        if (trainingDateFragment == null) {
            trainingDateFragment = new TrainingDateFragment();
        }
        return trainingDateFragment;
    }

    public void deleteTrainPlan() {
        new MaterialDialog.Builder(this)
                .title(R.string.prompt)
                .content(R.string.activity_training_plan_delete_confirm)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://开始创建
                                int requestId = SportDataManager.getInstance().deleteTrainPlan();
                                registerDataReqStatusListener(requestId);
                                break;
                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    public void delayTrainPlan() {
        showNumberPickerDialog(R.string.activity_training_plan_set_delay_day, 1, R.array.delay,
                R.string.activity_training_plan_delay, R.string.activity_edit_profile_dialog_negative_button
                , new NumberPickerFragment.OnNumberSetListener() {
                    @Override
                    public void onNumberSet(Integer number, View v) {
                        //最小值 0 实际 应该为 1
                        int requestId = SportDataManager.getInstance().delayTrainPlan(number + 1);
                        registerDataReqStatusListener(requestId);
                    }
                }, "genderPicker");
    }

    /**
     * 显示数字选择对话框
     *
     * @param titleResId           对话框标题资源ID
     * @param initValue            对话框数值选择器初始值
     * @param displayedValuesResId 对话框数值选择器显示的文字数组资源ID
     * @param positiveButtonResId  对话框确定按钮文字资源ID
     * @param negativeButtonResId  对话框取消按钮文字资源ID
     * @param listener             对话框设置回调监听
     * @param tag                  对话框tag标签
     */
    private void showNumberPickerDialog(int titleResId, int initValue, int displayedValuesResId,
                                        int positiveButtonResId, int negativeButtonResId, NumberPickerFragment.OnNumberSetListener listener, String tag) {
        NumberPickerFragment numberPickerFragment = new NumberPickerFragment();
        numberPickerFragment.setTitle(titleResId);
        numberPickerFragment.setDisplayedValuesResId(displayedValuesResId);
        numberPickerFragment.setValue(initValue);
        numberPickerFragment.setPositiveButtonText(positiveButtonResId);
        numberPickerFragment.setNegativeButtonText(negativeButtonResId);
        numberPickerFragment.setOnNumberSetListener(listener);
        if (ftCanCommit)
            numberPickerFragment.show(getFragmentManager(), tag);
    }

    /**
     * 启动跑步设置界面
     */
    public void startRunSettingActivity() {
        Intent intent = new Intent();
        intent.setClass(TrainingPlanActivity.this, RunSettingActivity.class);
        String musicString = SettingsHelper.getString(Config.SETTING_EXPERT_MUSIC, "");
        if (!TextUtils.isEmpty(musicString)) {
            intent.putExtra("musicInfo", musicString);
        } else {
            Music music;
            music = OperateMusicUtils.getMusicById(46);
            if (music != null) {
                intent.putExtra("musicInfo", JsonHelper.createJsonString(music));
            } else {
                Music mMusicInfo = new Music();
                mMusicInfo.setId(46);
                mMusicInfo.setName("美好一天开始于5公里晨跑");
                mMusicInfo.setBpm("144");
                mMusicInfo.setAuthor("DJ Shine");
                mMusicInfo.setAlbumUrl("http://yyssb.ifitmix.com//1001/8a163b37b26e4bee9f976cad312f7446.JPG");
                mMusicInfo.setUrl("http://yyssb.ifitmix.com//1000/3e6d8e36e14e47d799f9df08aa60dfd0.m4a");
                intent.putExtra("musicInfo", JsonHelper.createJsonString(mMusicInfo));
            }
        }
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_PLAN) {
            if (resultCode == 2016) {//创建成功
                if (data != null) {
                    String trainString = data.getStringExtra("trainString");
                    Logger.i(Logger.DEBUG_TAG, " onActivityResult --- > train : " + trainString);
                    parserData(trainString);
                }
            } else {
                if (!createNewPlan) {
                    finish();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}

