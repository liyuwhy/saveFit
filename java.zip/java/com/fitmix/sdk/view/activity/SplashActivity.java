package com.fitmix.sdk.view.activity;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewStub;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.PrefsHelper;
import com.fitmix.sdk.model.api.ApiUtils;
import com.fitmix.sdk.model.api.bean.Adverts;
import com.fitmix.sdk.model.api.bean.Init;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.AdvertisementAdapter;
import com.fitmix.sdk.view.adapter.VersionIntroductionAdapter;
import com.fitmix.sdk.view.bean.VersionIntroduction;
import com.fitmix.sdk.view.widget.BounceViewPager;
import com.fitmix.sdk.view.widget.RoundProgressBar;
import com.fitmix.sdk.view.widget.ViewUtils;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


/**
 * 闪屏界面
 * 1.用户第一次使用时,显示开机视频
 * 2.用户已登录情况下,直接导航到主界面
 * 3.用户未登录情况下,导航到登录界面
 * 4.wifi情况下,检测新版本
 * 5.检测俱乐部邀请,并保存被邀请的俱乐部信息到本地,用于主界面处理
 */
public class SplashActivity extends BaseActivity {
//    private FullScreenVideoView videoView;

    private boolean bStartingMainActivity = false;//是否正在启动主界面,防止多次启动
//    private int playedTime;

    /**
     * 更新倒计时进度条消息
     */
    private static final int MSG_UPDATE = 26;
    //闪屏广告相关参数
    private int DELAYED = 10;
    private int FULL_TIME = 3000;
    private int time_now = 0;//现在已经执行的时间
    private MyHandler handler;
    private RoundProgressBar ad_round_pb;

    private LinearLayout dot_container;//viewPager下的滚轮
    private List<ImageView> dotViewList = new ArrayList<>();

    private BounceViewPager adverts_vp;
 //   private SimpleDraweeView footer_img;//启始页脚图片

    //    private int advertisementSize;
    private AdvertisementAdapter advertisementAdapter;

    //第一次进入时显示的版本新特性界面
    private LinearLayout versionDotContainer;
    private BounceViewPager versionLoopViewPager;
    private VersionIntroductionAdapter versionAdapter;
    private ViewPager.OnPageChangeListener versionInfoListener;
    private List<ImageView> versionDotViewList = new ArrayList<>();

    public static class MyHandler extends Handler {

        private WeakReference<SplashActivity> mActivity;

        public MyHandler(SplashActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_UPDATE:
                    if (mActivity != null && mActivity.get() != null) {
                        mActivity.get().updateProgress();
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        Logger.e(Logger.DEBUG_TAG,"SplashActivity ======= onCreate");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //透明导航栏
            //getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
        setPageName("SplashActivity");
        Intent intent = getIntent();
        if (intent != null) {
            Uri data = intent.getData();
//            Logger.i(Logger.DEBUG_TAG, "SplashActivity-->onCreate getIntent()!= null");
            if (data != null) {
                String scheme = data.getScheme(); // "fitmix"
                String host = data.getHost(); // ip club-member:俱乐部邀请 channel-app:第三方APP启动
//                Logger.i(Logger.DEBUG_TAG, "SplashActivity-->onCreate scheme:" + scheme + " host:" + host);
                if (scheme != null) {
                    scheme = scheme.toLowerCase();
                    if (scheme.equals("fitmix") && host != null && host.equals("club-member")) {//俱乐部邀请
                        Set<String> queryKeys = data.getQueryParameterNames();
                        String value;
                        for (String key : queryKeys) {
                            value = data.getQueryParameter(key);
                            if (value == null || value.isEmpty()) continue;
                            if (key.equals("clubId")) {
                                PrefsHelper.with(this, Config.PREFS_CLUB).write(Config.SP_KEY_INVITE_CLUB_IDS, value);
                            } else if (key.equals("clubName")) {
                                PrefsHelper.with(this, Config.PREFS_CLUB).write(Config.SP_KEY_INVITE_CLUB_NAMES, value);

                            }
//                        Logger.i(Logger.DEBUG_TAG, "for method query key:" + key + " query value:" + value);
                            startNextActivity();
                        }
                        return;//不用显示Splash界面
                    } else if (scheme.equals("fitmix") && host != null && host.equals("channel-app")) {//虾米音乐
                        startNextActivity();
                        return;//不用显示Splash界面
                    }
                }
            }
        }
        setContentView(R.layout.activity_splash);
        appInit();
        initViews();
    }

//    @Override
//    protected void attachBaseContext(Context base) {//解决由于getVideoView().setVideoURI(uri)引起的内存泄漏
//        super.attachBaseContext(AudioServiceActivityLeak.preventLeakOf(base));
//    }

    /**
     * APP 初始化
     */
    private void appInit() {
        SettingsHelper.putInt(Config.SETTING_APP_SPLASH_AD_SHOW_NUM, SettingsHelper.getInt(Config.SETTING_APP_SPLASH_AD_SHOW_NUM, 0) + 1);
        int appVersion = ApiUtils.getApkVersionCode();
        String lan = ApiUtils.getLanguage();
        if ("zh".equals(lan)) {
            int requestId = UserDataManager.getInstance().appInit(appVersion, "ch");
            registerDataReqStatusListener(requestId);
        } else {
            int requestId = UserDataManager.getInstance().appInit(appVersion, "en");
            registerDataReqStatusListener(requestId);
        }
    }

    protected void initViews() {
        handler = new MyHandler(this);
        //应用新特性展示页
        int versionCode = ApiUtils.getApkVersionCode();
        int lastVersionCode = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_APP_VERSION_CODE, 0);
        if (lastVersionCode < versionCode) {//版本升级了
            ViewStub stub = (ViewStub) findViewById(R.id.viewStub_first_use_version_info);
            stub.inflate();
            versionDotContainer = (LinearLayout) findViewById(R.id.version_info_dot_container);
            versionLoopViewPager = (BounceViewPager) findViewById(R.id.viewpager_version_info_banner);
            List<VersionIntroduction> versionList = new ArrayList<>();
            if (versionCode == 61) {//V2.4.5的版本新特征
                versionList.add(new VersionIntroduction(R.drawable.version_feature_one));
//                versionList.add(new VersionIntroduction(R.drawable.version_feature_two));
//                versionList.add(new VersionIntroduction(R.drawable.version_feature_three));
            } else {
                versionList.add(new VersionIntroduction(R.drawable.activity_enter_logined_pic));//默认封面
            }

            versionAdapter = new VersionIntroductionAdapter(SplashActivity.this, versionList);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewUtils.dp2px(this, 7), ViewUtils.dp2px(this, 7));
            params.setMargins(ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1), ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1));
            versionDotContainer.removeAllViews();
            versionDotViewList.clear();
            if (versionList.size() > 1) {
                for (int i = 0; i < versionList.size(); i++) {
                    ImageView dot = new ImageView(this);
                    if (i == 0) {
                        dot.setImageResource(R.drawable.dot_focused);
                    } else {
                        dot.setImageResource(R.drawable.dot_normal);
                    }
                    versionDotContainer.addView(dot, params);
                    versionDotViewList.add(dot);
                }
            }

            versionLoopViewPager.setAdapter(versionAdapter);
            versionLoopViewPager.addOnPageChangeListener(getVersionInfoPageChangeListener());
            PrefsHelper.with(this, Config.PREFS_USER).writeInt(Config.SP_KEY_APP_VERSION_CODE, versionCode);
            return;
        }

        ViewStub stub = (ViewStub) findViewById(R.id.viewStub_advertisement);
        stub.inflate();
        adverts_vp = (BounceViewPager) findViewById(R.id.vp_adv_pic);
        advertisementAdapter = new AdvertisementAdapter(this);
     //   footer_img = (SimpleDraweeView) findViewById(R.id.footer_img);

        dot_container = (LinearLayout) findViewById(R.id.dot_container);
        ad_round_pb = (RoundProgressBar) findViewById(R.id.adv_round_pb);
        if (ad_round_pb != null) {
            ad_round_pb.setOnClickListener(click_slip);
            time_now += DELAYED;
            handler.sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);
        }
    }

    /**
     * 刷新广告
     */
    private void updateAdvertisement() {
        if (advertisementAdapter == null)
            return;
        int advertisementCount = advertisementAdapter.getCount();
        if (advertisementCount > 1) {//当有两个banner 才可以来回滚动
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewUtils.dp2px(this, 7), ViewUtils.dp2px(this, 7));
            params.setMargins(ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1), ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1));
            dot_container.removeAllViews();
            dotViewList.clear();
            for (int i = 0; i < advertisementCount; i++) {
                ImageView dot = new ImageView(this);
                if (i == 0) {
                    dot.setImageResource(R.drawable.dot_focused);
                } else {
                    dot.setImageResource(R.drawable.dot_normal);
                }
                dot_container.addView(dot, params);
                dotViewList.add(dot);
            }
            adverts_vp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                }

                @Override
                public void onPageSelected(int position) {
                    if (advertisementAdapter != null) {
                        int advertisementSize = advertisementAdapter.getCount();
                        for (int i = 0; i < advertisementSize; i++) {
                            if (i == position % advertisementSize) {
                                dotViewList.get(position % advertisementSize).setImageResource(R.drawable.dot_focused);
                            } else {
                                (dotViewList.get(i)).setImageResource(R.drawable.dot_normal);
                            }
                        }
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                    //不处理
                }
            });
        }
    }

    /**
     * 更新倒计时进度条
     */
    private void updateProgress() {
        if (ad_round_pb != null) {
            ad_round_pb.setProgress(time_now * 100 / FULL_TIME);
        }

        if (time_now >= FULL_TIME) {
            startNextActivity();
        } else {
            time_now += DELAYED;
            handler.sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);
        }
    }

    View.OnClickListener click_slip = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (getActivitySize(SplashActivity.this) == 1) {
                startNextActivity();
            }
            if (handler != null) {
                handler.removeCallbacksAndMessages(null);
            }
            finish();
        }
    };

    /**
     * 获取当前任务下activity的个数,此方法不同机型会有不同表现
     *
     * @param context
     * @return
     */
    private int getActivitySize(Activity context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        if (manager != null) {
            List<ActivityManager.RunningTaskInfo> runningTasks = manager.getRunningTasks(1);
            if (runningTasks != null && runningTasks.size() > 0) {
                return runningTasks.get(0).numActivities;
            } else {
                return 1;
            }
        }
        return 1;
    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
//        Logger.i(Logger.DEBUG_TAG, "SplashActivity-->getDataReqStatusNotify requestId:" + requestId);
//        Logger.i(Logger.DEBUG_TAG, "SplashActivity-->getDataReqStatusNotify result:"  + result);
        switch (requestId) {
            case Config.MODULE_USER + 1://App初始化
                Init init = JsonHelper.getObject(result, Init.class);
                if (init != null) {
                    String keyUrl = init.getKeyUrl1();//加密公钥下载地址
                    String publicKeyUrl = PrefsHelper.with(this, Config.PREFS_USER).read(Config.SP_KEY_PUBLIC_KEY_URL, "");
                    Logger.i(Logger.DEBUG_TAG, "Init-->加密公钥下载地址:" + keyUrl + " ,publicKeyUrl:" + publicKeyUrl);
                    if (!TextUtils.isEmpty(keyUrl) && !keyUrl.equals(publicKeyUrl)) {
                        Logger.i(Logger.DEBUG_TAG, "Init-->加密公钥下载");
                        UserDataManager.getInstance().getPublicKey(keyUrl, true);
                        PrefsHelper.with(this, Config.PREFS_USER).write(Config.SP_KEY_PUBLIC_KEY_URL, keyUrl);
                    }

                    String shareLink = init.getAppUserRunShareLink();
                    String appDownload = init.getAppDownloadQRCodeLink();
                    String themeAnswerShareLink = init.getAppThemeAnswerShareLink();
                    PrefsHelper.with(this, Config.PREFS_SPORT).write(Config.SP_KEY_RUN_SHARE_URL, shareLink);
                    PrefsHelper.with(this, Config.PREFS_SPORT).write(Config.SP_KEY_APP_DOWNLOAD_QR, appDownload);
                    PrefsHelper.with(this, Config.PREFS_COMPETITION).write(Config.SP_KEY_TOPIC_ANSWER_SHARE, themeAnswerShareLink);

                    List<Adverts> advertsList = init.getAdverts();
                    List<Adverts> newAdvertsList = new ArrayList<>();
                    int showTime = SettingsHelper.getInt(Config.SETTING_APP_SPLASH_AD_SHOW_NUM, 0);
                    if (advertsList.size() > 1) {
                        for (int i = 0; i < advertsList.size(); i++) {
                            newAdvertsList.add(advertsList.get((showTime + i) % advertsList.size()));
                        }
                    } else {
                        newAdvertsList.addAll(advertsList);
                    }

                    if (newAdvertsList != null) {

                        if (advertisementAdapter != null) {
                            advertisementAdapter.setList(newAdvertsList);
                            if (adverts_vp != null) {
                                adverts_vp.setAdapter(advertisementAdapter);
                            }
                            updateAdvertisement();
                        }
//                        AdvertisementHelper.getInstance().insertAdvertiseList(advertsList);//不再存数据库
                    }

//                    if (init.getPage() != null && footer_img != null) {//启始页脚图片(对应后台启动闪屏页设置)
//                        if (!TextUtils.isEmpty(init.getPage().getBackgroundImg())) {
//                            footer_img.setImageURI(Uri.parse(init.getPage().getBackgroundImg()));
//                        } else {
//                            footer_img.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.activity_enter_login_text)).build());
//                        }
//                    } else {
//                        if (footer_img != null) {
//                            footer_img.setImageURI(new Uri.Builder().scheme("res").path(String.valueOf(R.drawable.activity_enter_login_text)).build());
//                        }
//                    }
                }
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        handler = null;
        click_slip = null;
        if (dotViewList != null) {
            dotViewList.clear();
        }
        dotViewList = null;

        if (versionDotViewList != null) {
            versionDotViewList.clear();
        }
        versionDotViewList = null;
    }

    @Override
    protected void clickToRun() {
    }//该activity不做操作

    /**
     * 启动登录界面
     */
    public void startLoginActivity() {
        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    /**
     * 根据是否登录,启动主界面或登录界面
     */
    public void startNextActivity() {
        if (bStartingMainActivity) return;
        bStartingMainActivity = true;
        Intent intent;
        int loginType = PrefsHelper.with(this, Config.PREFS_USER).readInt(Config.SP_KEY_LAST_LOGIN_TYPE, -1);
        if (loginType > 0) {//当前是已登录状态,启动主界面
            intent = new Intent(SplashActivity.this, MainActivity.class);
        } else {
            intent = new Intent(SplashActivity.this, LoginActivity.class);
        }
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_go2_login://开启FITMIX之旅
                startNextActivity();
                break;
            default:
                break;
        }
    }

    private ViewPager.OnPageChangeListener getVersionInfoPageChangeListener() {
        if (versionInfoListener == null) {
            versionInfoListener = new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                }

                @Override
                public void onPageSelected(int position) {
                    if (versionLoopViewPager != null && versionAdapter != null && versionDotViewList != null) {
                        for (int i = 0; i < versionDotViewList.size(); i++) {
                            if (versionDotViewList.get(i) != null) {
                                (versionDotViewList.get(i)).setImageResource(R.drawable.dot_normal);
                            }
                        }
                        if (position >= 0 && position < versionDotViewList.size()) {
                            if (versionDotViewList.get(position) != null) {
                                (versionDotViewList.get(position)).setImageResource(R.drawable.dot_focused);
                            }
                        }
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                }
            };
        }
        return versionInfoListener;
    }

}
