package com.fitmix.sdk.view.activity;

import android.os.Bundle;

import com.fitmix.sdk.R;
import com.fitmix.sdk.model.database.DataReqStatus;

/**
 * 静息心率说明界面
 */
public class RestHeartRateInfoActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest_heart_rate_info);
        setPageName("RestHeartRateInfoActivity");
        initToolbar();
        initViews();
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }

    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        //不处理
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        //不处理
    }
}
