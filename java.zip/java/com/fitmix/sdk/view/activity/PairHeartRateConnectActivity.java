package com.fitmix.sdk.view.activity;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.animation.LinearOutSlowInInterpolator;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.HeartRateChartInfo;
import com.fitmix.sdk.common.FitmixUtil;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.common.WeakHandler;
import com.fitmix.sdk.common.bluetooth.A2dpServiceListener;
import com.fitmix.sdk.common.bluetooth.ble.HRSManager;
import com.fitmix.sdk.common.bluetooth.scanner.BluetoothLeScannerCompat;
import com.fitmix.sdk.common.bluetooth.scanner.ExtendedBluetoothDevice;
import com.fitmix.sdk.common.bluetooth.scanner.ScanCallback;
import com.fitmix.sdk.common.bluetooth.scanner.ScanFilter;
import com.fitmix.sdk.common.bluetooth.scanner.ScanResult;
import com.fitmix.sdk.common.bluetooth.scanner.ScanSettings;
import com.fitmix.sdk.common.bluetooth.scanner.ScannerFragment;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.FinishTask;
import com.fitmix.sdk.model.api.bean.RestHeartRateList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.database.SettingsHelper;
import com.fitmix.sdk.model.manager.SportDataManager;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.service.HeartRateService;
import com.fitmix.sdk.view.adapter.ViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.dialog.material.DialogAction;
import com.fitmix.sdk.view.dialog.material.MaterialDialog;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.ArcCircle;
import com.fitmix.sdk.view.widget.BounceViewPager;
import com.fitmix.sdk.view.widget.HeartHRChart;
import com.fitmix.sdk.view.widget.ViewUtils;
import com.fitmix.sdk.view.widget.WaveView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class PairHeartRateConnectActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    /**
     * 更新倒计时设备搜索进度条消息
     */
    private static final int MSG_UPDATE = 26;
    /**
     * 刷新状态音频通道连接状态
     */
    private static final int MSG_REFRESH_STATUS = 111;


    //搜索界面布局
    private BounceViewPager viewPager;
    private LinearLayout dotContainer;
    private List<ImageView> dotViewList = new ArrayList<>();
    private ViewPager.OnPageChangeListener listener;
    private ViewPagerAdapter pageAdapter;

    private boolean mIsScanning = false;
    private int DELAYED = 10;
    private int FULL_TIME = 5000;
    private int time_now = 0;//现在已经执行的时间
    private final ArrayList<ExtendedBluetoothDevice> mListValues = new ArrayList<>();//搜索所得的BLE设备
    private RoundHandler roundHandler;


    Random random = new Random();
    private ServiceConnection serviceConnection;//心率服务连接
    private HeartRateService heartRateService;//心率服务

    private MyHandlerX mHandlerX;
    private BluetoothAdapter mBluetoothAdapter;
    private int a2dpState = BluetoothProfile.STATE_DISCONNECTED;


    private RelativeLayout connectingView;
    private RelativeLayout connectedView;
    private WaveView mSearchWaveView, mConnectWaveView;


    private LinearLayout searchView, connectView;
    private View detailView;
    private int HeartRateLightMode = 1;//默认为心率模式

    //心率详情界面
    private static final int LIST_MODE = 0;
    private int currentMode = 0;
    private MenuItem menu_second;
    private ArcCircle arcCircle;
    private HeartHRChart chart;
    private ImageView heart_rate_iv;
    private TextView heartValue;
    private Button coach_mode_btn;
    private Animation shakeAnim;
    private long startT = 0;
    private int tipCount = 0;
    private boolean isShowingGit = false;
    /**
     * 金币任务,使用我的设备配对一次任务是否完成
     */
    private boolean coinTaskPairBtFinished = true;

    private boolean isShowDetailView = false;
    private Dialog tipDialog;
    private MaterialDialog.Builder connectVoiceDialogBuilder;

    private boolean isTip = false;
    private boolean isDataConnected = false;
    private boolean isMusicConnected = false;
    private boolean canMove = false;

    //region ============================= Activity 生命周期相关 =============================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair_heart_rate_connect);
        setPageName("PairHeartRateConnectActivity");
        initToolbar();
        initViews();
        coinTaskPairBtFinished = SettingsHelper.getBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);
        searchHREquipments();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            connectToHeartRateService();
        }
        startT = System.currentTimeMillis();
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }


        //------------------------------start  搜索界面 ---------------------------------------
        //嵌套两view的viewpager
        viewPager = (BounceViewPager) findViewById(R.id.heart_rate_banner);
        //存放点的容器
        dotContainer = (LinearLayout) findViewById(R.id.dot_container);

        List<View> views = new ArrayList<>();

        View searching = getLayoutInflater().inflate(R.layout.viewpager_search_ear, null);
        //波浪形进度条
        mSearchWaveView = (WaveView) searching.findViewById(R.id.wave_view);
        mSearchWaveView.setDuration(7000);
        mSearchWaveView.setStyle(Paint.Style.STROKE);
        mSearchWaveView.setInitialRadius(240);
        mSearchWaveView.setColor(getResources().getColor(R.color.fitmix_yellow));
        mSearchWaveView.setInterpolator(new LinearOutSlowInInterpolator());
        mSearchWaveView.start();
        View searched = getLayoutInflater().inflate(R.layout.viewpager_search_ear_result, null);
        views.add(searching);
        views.add(searched);

        pageAdapter = new ViewPagerAdapter(views);
        viewPager.setAdapter(pageAdapter);
        viewPager.addOnPageChangeListener(getPageChangeListener());
        viewPager.setOffscreenPageLimit(2);
        viewPager.setPagerCount(pageAdapter.getCount());//设置页数,回弹效果必须有
        viewPager.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果 DepthPageTransformer在部分机子造成列表不能滑动
        viewPager.addOnPageChangeListener(this);

        //圆点设置填充
        dotContainer.removeAllViews();
        dotViewList.clear();
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewUtils.dp2px(this, 7), ViewUtils.dp2px(this, 7));
        params.setMargins(ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1), ViewUtils.dp2px(this, 5), ViewUtils.dp2px(this, 1));
        for (int i = 0; i < views.size(); i++) {
            ImageView dot = new ImageView(this);
            if (i == 0) {
                dot.setImageResource(R.drawable.dot_focused);
            } else {
                dot.setImageResource(R.drawable.dot_normal);
            }
            dotContainer.addView(dot, params);
            dotViewList.add(dot);
        }

        //------------------------------end  搜索界面 ---------------------------------------


        heart_rate_iv = (ImageView) findViewById(R.id.heart_iv);
        //圆环
        arcCircle = (ArcCircle) findViewById(R.id.arc_circle);
        arcCircle.setValue(360f);

        //心率走向图
        chart = (HeartHRChart) findViewById(R.id.heart_chart);
        heartValue = (TextView) findViewById(R.id.heart_value);

        searchView = (LinearLayout) findViewById(R.id.search_view);
        connectView = (LinearLayout) findViewById(R.id.heart_rate_connect_view);
        detailView = findViewById(R.id.heart_rate_detail_view);


        connectingView = (RelativeLayout) findViewById(R.id.heart_rate_connecting_view);
        connectedView = (RelativeLayout) findViewById(R.id.heart_rate_connected_view);
        coach_mode_btn = (Button) detailView.findViewById(R.id.btn_coach_mode);
        TextView note_tv = (TextView) connectingView.findViewById(R.id.search_connect_note_tv);
        note_tv.setText(getResources().getString(R.string.is_connecting));
        //波浪形进度条
        mConnectWaveView = (WaveView) connectingView.findViewById(R.id.wave_view);
        mConnectWaveView.setDuration(7000);
        mConnectWaveView.setStyle(Paint.Style.STROKE);
        mConnectWaveView.setInitialRadius(240);
        mConnectWaveView.setColor(getResources().getColor(R.color.fitmix_yellow));
        mConnectWaveView.setInterpolator(new LinearOutSlowInInterpolator());
        mConnectWaveView.start();

    }

    @Override
    protected void onStart() {
        super.onStart();

        requestAllRestHeartRateHistory();
        //为heart_rate_iv设置跳动动画
        shakeAnim = AnimationUtils.loadAnimation(this,
                R.anim.shake_y);
        shakeAnim.setRepeatCount(Animation.INFINITE);
        shakeAnim.setRepeatMode(Animation.RESTART);
        heart_rate_iv.setAnimation(shakeAnim);
        shakeAnim.cancel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mConnectWaveView.start();
        mSearchWaveView.start();
        refresh();
        setButtonTextView();
    }

    @Override
    protected void onPause() {
        super.onPause();
        getHandlerX().removeMessages(MSG_REFRESH_STATUS);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mConnectWaveView.stop();
        mSearchWaveView.stop();
        shakeAnim.cancel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Logger.d("TT", "PairHeartRateConnectActivity onDestroy---------");
        mSearchWaveView.stop();
        mConnectWaveView.stop();
        getHandlerX().setDiscardMsgFlag(true);
        getHandlerX().removeCallbacksAndMessages(null);
        mHandlerX = null;
        disconnectToHeartRateService();

        //自动搜索连接相关关闭：
        if (mIsScanning) {
            stopScan();
        }
        getRoundHandler().removeCallbacksAndMessages(null);
        roundHandler = null;
        scanCallback = null;

        shakeAnim.cancel();
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_SPORT + 16://获取全部的静息心率记录
                RestHeartRateList recordList = JsonHelper.getObject(result, RestHeartRateList.class);
                if (recordList != null) {
                    findViewById(R.id.heart_rate_no_detect).setVisibility(View.GONE);
                } else {
                    findViewById(R.id.heart_rate_no_detect).setVisibility(View.VISIBLE);
                }
                break;

            case Config.MODULE_USER + 52://完成使用我的设备配对一次金币任务
                FinishTask finishTask = JsonHelper.getObject(result, FinishTask.class);
                if (finishTask != null) {
                    if (finishTask.getCode() == 0) {//任务成功
                        FinishTask.AccountFlowEntity accountFlowEntity = finishTask.getAccountFlow();
                        if (accountFlowEntity != null) {
                            coinTaskPairBtFinished = true;
                            SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成任务

                            showQuestRewardsDialog(accountFlowEntity.getCoin(), accountFlowEntity.getDescription());
                        }
                    }
                }
                break;
        }

    }

    @Override
    protected void processReqError(int requestId, String error) {
        BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
        if (bean != null) {
            switch (requestId) {
                case Config.MODULE_USER + 52://设备配对一次金币任务
                    if (bean.getCode() == 9002) {//该任务已完成
                        coinTaskPairBtFinished = true;
                        SettingsHelper.putBoolean(Config.SETTING_COIN_TASK_PAIRING_BT, true);//设置完成
                    }
                    break;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (isShowDetailView) {
            switch (currentMode) {
                case LIST_MODE:
                    menu_second = menu.add(0, Menu.FIRST + 4, 4, "detail").setIcon(R.drawable.heart_rate_setting);
                    break;
            }
            menu_second.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        }
        super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if ((Menu.FIRST + 4) == item.getItemId()) {
            Intent intent = new Intent(this, HeartRateSettingActivity.class);
            startActivityForResult(intent, 1);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    //endregion ============================= Activity 生命周期相关 =============================

    /**
     * 自定义Handler用于检测蓝牙音频通道连接与否
     */
    public static class MyHandlerX extends WeakHandler {

        public MyHandlerX(Activity activity) {
            super(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            PairHeartRateConnectActivity activity = (PairHeartRateConnectActivity) getReference();
            if (activity == null)
                return;
            switch (msg.what) {
                case A2dpServiceListener.MSG_A2DP_CONNECT_SUCCESS:
                    activity.showAppMessage(R.string.bt_connect_success, AppMsg.STYLE_INFO);
                    break;

                case A2dpServiceListener.MSG_A2DP_CONNECT_FAIL:
                    activity.showAppMessage(R.string.bt_connect_fail, AppMsg.STYLE_ALERT);
                    break;

                case MSG_REFRESH_STATUS:
                    activity.refresh();
                    break;

            }
        }
    }

    private MyHandlerX getHandlerX() {
        if (mHandlerX == null) {
            mHandlerX = new MyHandlerX(this);
        }
        return mHandlerX;
    }

    /**
     * 刷新状态
     */
    private void refresh() {
        getHandlerX().sendEmptyMessageDelayed(MSG_REFRESH_STATUS, 1000);
        refreshA2dpState();
    }

    /**
     * 根据蓝牙连接状态刷新界面
     */
    private void refreshA2dpState() {
        if (getBluetoothAdapter() == null)
            return;
        int state = getBluetoothAdapter()
                .getProfileConnectionState(BluetoothProfile.A2DP);//0:未连接 2：连接
        switch (state) {
            case BluetoothProfile.STATE_CONNECTED:
                if (a2dpState != state) {//音频通道连接成功
                    Logger.d("TT", "音频通道连接成功");
                    isTip = true;
                    showAppMessage(R.string.a2dp_connected, AppMsg.STYLE_INFO);
                    isMusicConnected = true;
                    if (!isDataConnected) {
                        getHandlerX().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                hideSearchView();
                            }
                        }, 2000L);
                    }

                    if (isMusicConnected && isDataConnected) {
                        getHandlerX().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startT = System.currentTimeMillis() + 5000;
                                toDetailView();
                            }
                        }, 4000L);
                    }


                    if (connectVoiceDialogBuilder != null && connectVoiceDialogBuilder.build() != null) {
                        connectVoiceDialogBuilder.build().dismiss();
                    }
                }
                if (!coinTaskPairBtFinished) {//完成设备配对一次金币任务
                    finishPairBtCoinTask();
                }
                break;
            case BluetoothProfile.STATE_DISCONNECTED:
            case BluetoothProfile.STATE_DISCONNECTING:
                if (a2dpState != state) {//音频通道连接断开
                    Logger.d("TT", "音频通道连接断开");
                    isMusicConnected = false;
                    isTip = false;
                    mConnectWaveView.start();
                    showAppMessage(R.string.a2dp_disconnected, AppMsg.STYLE_ALERT);
                }
                break;

            case BluetoothProfile.STATE_CONNECTING:
                if (a2dpState != state) {// 正在连接音频通道
                    Logger.d("TT", "正在连接音频通道");
                    connectingView.setVisibility(View.VISIBLE);
                    connectedView.setVisibility(View.GONE);
                    showAppMessage(R.string.bt_connecting, AppMsg.STYLE_INFO);
                }
                break;
        }
        a2dpState = state;

    }

    /**
     * 获取蓝牙适配器,注意null值判断
     */
    private BluetoothAdapter getBluetoothAdapter() {
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if (mBluetoothAdapter == null) {
            showAppMessage(R.string.bt_not_supported, AppMsg.STYLE_ALERT);
        }
        return mBluetoothAdapter;
    }

    /**
     * 展示正确佩戴方式窗口
     */
    private void showTipDialog() {
        isShowingGit = true;
        tipCount++;
        if (tipDialog == null) {
            tipDialog = new Dialog(this, R.style.dialog);
        }
        View tipView = LayoutInflater.from(this).inflate(R.layout.load_correct_wear_way_view, null);
        ImageView deleteIv = (ImageView) tipView.findViewById(R.id.delete_iv);

        SimpleDraweeView simpleView = (SimpleDraweeView) tipView.findViewById(R.id.simple_view);
        DraweeController mDraweeController = Fresco.newDraweeControllerBuilder()
                .setAutoPlayAnimations(true)
                //设置uri,加载本地的gif资源
                .setUri(Uri.parse("res://" + getPackageName() + "/" + R.drawable.load_git_icon))//设置uri
                .build();
        //设置Controller
        simpleView.setController(mDraweeController);

        deleteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipDialog.dismiss();
                isShowingGit = false;
                startT = System.currentTimeMillis();
            }
        });
        tipDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                tipDialog.dismiss();
                isShowingGit = false;
                startT = System.currentTimeMillis();
            }
        });

        tipDialog.setCancelable(false);
        tipDialog.setCanceledOnTouchOutside(true);
        tipDialog.setContentView(tipView);
        tipDialog.show();
    }

    /**
     * 请求获取所有静息心率记录
     */
    public void requestAllRestHeartRateHistory() {
        int requestId = SportDataManager.getInstance().getAllRestHeartRateHistory(UserDataManager.getUid());
        registerDataReqStatusListener(requestId);
    }

    /**
     * 跳动心率详情界面
     */
    private void toDetailView() {

        Logger.d("TT", "toDetailActivity");
        isShowDetailView = true;
        connectView.setVisibility(View.GONE);
        mConnectWaveView.stop();
        detailView.setVisibility(View.VISIBLE);
        invalidateOptionsMenu();
        //自动搜索连接相关关闭：
        if (mIsScanning) {
            stopScan();
        }
    }

    /**
     * 完成使用我的设备配对一次任务
     */
    private void finishPairBtCoinTask() {
        int uid = UserDataManager.getUid();
        int reqId = UserDataManager.getInstance().finishTask(uid, Config.COIN_TASK_TYPE_ONCE, Config.COIN_TASK_PAIRING_BT, true);
        registerDataReqStatusListener(reqId);
    }

    /**
     * 连接音频通道提示窗
     */
    private void showToConnectA2dpTip() {
        connectVoiceDialogBuilder = new MaterialDialog.Builder(this);
        connectVoiceDialogBuilder.title(R.string.prompt)
                .content(R.string.heart_rate_connect_blue_error)
                .positiveText(R.string.ok)
                .negativeText(R.string.cancel)
                .onAny(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dialog.dismiss();
                        switch (which) {
                            case POSITIVE://MainActivity一直会在task底,退出MainActivity即退出程序
                                gotoBluetoothSettings();
                                break;

                            case NEGATIVE:
                                break;
                        }
                    }
                }).show();
    }

    /**
     * 用于搜索框的Handler
     */
    public static class RoundHandler extends Handler {
        private WeakReference<PairHeartRateConnectActivity> mActivity;

        public RoundHandler(PairHeartRateConnectActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_UPDATE:
                    if (mActivity != null && mActivity.get() != null) {
                        mActivity.get().updateSearchingProgress();
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }

    private void updateSearchingProgress() {

        if (time_now >= FULL_TIME) {//搜索结束，无论成功与否
            if (mListValues.size() > 0) {
                if (mIsScanning) {
                    connectDevice();
                }
            } else {
                if (!canMove) {
                    viewPager.setCurrentItem(1);
                    canMove = true;
                }
                getRoundHandler().sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);
            }
        } else {
            time_now += DELAYED;
            if (mListValues.size() > 0) {
                if (mIsScanning) {
                    connectDevice();
                }
            }
            getRoundHandler().sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);

        }
    }

    private RoundHandler getRoundHandler() {
        if (roundHandler == null) {
            roundHandler = new RoundHandler(PairHeartRateConnectActivity.this);
        }
        return roundHandler;
    }

    /**
     * 导航到系统蓝牙设置
     */
    private void gotoBluetoothSettings() {
        Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        if (intent != null && intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, Config.REQUEST_ENABLE_BLUETOOTH);
        }
    }

    /**
     * 发送心率耳机模式指令
     */
    private void sendHeartRateCmd() {
        if (heartRateService == null) {
            Toast.makeText(PairHeartRateConnectActivity.this, getResources().getString(R.string.heart_rate_set_not_connected), Toast.LENGTH_SHORT).show();
            return;
        }
        if (heartRateService.getDevice() != null && heartRateService.getDevice().getName() != null) {
            if (heartRateService.getDevice().getName().contains("H10") || heartRateService.getDevice().getName().contains("ROC HR")
                    || heartRateService.getDevice().getName().contains("ROC Model")) {
                if (heartRateService.getBleManager() != null) {
                    heartRateService.getBleManager().sendHRCmd(HeartRateLightMode);
                }
            } else {
                Toast.makeText(PairHeartRateConnectActivity.this, getResources().getString(R.string.heart_rate_shine_h10_not_connect), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(PairHeartRateConnectActivity.this, getResources().getString(R.string.heart_rate_shine_set_error), Toast.LENGTH_SHORT).show();
        }
    }

    private UUID getFilterUUID() {
        return HRSManager.HR_SERVICE_UUID;
    }

    /**
     * Shows the scanner fragment.
     *
     * @param filter the UUID filter used to filter out available devices. The fragment will always show all bonded devices as there is no information about their
     *               services
     * @see #getFilterUUID()
     */
    private void showDeviceScanningDialog(final UUID filter) {
        final ScannerFragment dialog = ScannerFragment.getInstance(filter);
        if (ftCanCommit) {
            dialog.show(getSupportFragmentManager(), "scan_fragment");
        }
    }

    /**
     * 自动搜索并连接HR设备(注意BLE功能必须要在4.4以上，同时如果6.0以上必须具备开启GPS)
     */
    private void searchHREquipments() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (FitmixUtil.isGpsEnable(this)) {//开了GPS
                    doSearchEquipments();
                } else {
                    FitmixUtil.enableGPS(this);//去开启GPS
                }
            } else {
                doSearchEquipments();
            }
        } else {
            Toast.makeText(this, getResources().getString(R.string.heart_rate_warn_sdk_version), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 搜索设备
     */
    private void doSearchEquipments() {
        if (FitmixUtil.isBLEEnabled(this)) {//蓝牙开启了
            mIsScanning = true;
            getRoundHandler().sendEmptyMessageDelayed(MSG_UPDATE, DELAYED);
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
            final ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(1000).setUseHardwareBatchingIfSupported(false).build();
            final List<ScanFilter> filters = new ArrayList<>();
            filters.add(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(HRSManager.HR_SERVICE_UUID)).build());  //带有心率特征值服务
            try {
                scanner.startScan(filters, settings, scanCallback);
            } catch (Exception ex) {
                showAppMessage(R.string.scanner_empty, AppMsg.STYLE_ALERT);
            }
        } else {//未开启蓝牙
            FitmixUtil.requestBlueTooth(this);
        }
    }

    /**
     * 停止搜索（一直搜索到）
     */
    private void stopScan() {
        final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        scanner.stopScan(scanCallback);
        mIsScanning = false;
    }

    private ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(final int callbackType, final ScanResult result) {
            // do nothing
        }

        @Override
        public void onBatchScanResults(final List<ScanResult> results) {
            for (final ScanResult result : results) {
                Logger.d(Logger.DEBUG_TAG, "device name:" + result.getDevice().getName() + " device address:" + result.getDevice().getAddress());

                if (result.getDevice() == null || result.getDevice().getName() == null) {
                    continue;
                }

                if (result.getDevice().getName().contains("ROC HR") ||
                        result.getDevice().getName().contains("H10") ||
                        result.getDevice().getName().contains("ROC Model")) {//过滤掉不是H10 ROC设备

                    final ExtendedBluetoothDevice device = findDevice(result);
                    if (device == null) {
                        mListValues.add(new ExtendedBluetoothDevice(result));
                    } else {
                        device.name = result.getScanRecord() != null ? result.getScanRecord().getDeviceName() : null;
                        device.rssi = result.getRssi();
                    }
                }

            }
        }

        @Override
        public void onScanFailed(final int errorCode) {
            //不处理
        }
    };

    private ExtendedBluetoothDevice findDevice(final ScanResult result) {
        for (final ExtendedBluetoothDevice device : mListValues)
            if (device.matches(result))
                return device;
        return null;
    }

    /**
     * 根据搜索获取的蓝牙设备集，连接设备
     */
    private void connectDevice() {
        if (mListValues.size() == 0) {
            return;
        }
        int max_rssi_index = 0;
        int max_rssi = 0;
        for (int i = 0; i < mListValues.size(); i++) {
            ExtendedBluetoothDevice device = mListValues.get(i);
            if (max_rssi == 0) {
                max_rssi = device.rssi;
                max_rssi_index = i;
                continue;
            }
            if (max_rssi < device.rssi) {
                max_rssi = device.rssi;
                max_rssi_index = i;
            }
        }

        if (heartRateService != null) {
            final BluetoothDevice bluetoothDevice = mListValues.get(max_rssi_index).device;
            String bluetoothDeviceName = bluetoothDevice.getName();
            if (!TextUtils.isEmpty(bluetoothDeviceName)) {
                if (bluetoothDeviceName.contains("H10") || bluetoothDeviceName.contains("ROC HR")
                        || bluetoothDeviceName.contains("ROC Model")) {
                    Logger.d(Logger.DEBUG_TAG, "已匹配的设备名:" + bluetoothDeviceName + " 地址:" + bluetoothDevice.getAddress());
                    stopScan();

                    if (!isTip)
                        showToConnectA2dpTip();
                    isTip = true;

                    heartRateService.setDevice(bluetoothDevice);
                    if (heartRateService.getBleManager() != null) {
                        heartRateService.getBleManager().disconnect();
                        heartRateService.getBleManager().connect(bluetoothDevice);
                    }

                    getHandlerX().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            hideSearchView();
                        }
                    }, 2000L);

                } else {
                    if (time_now >= FULL_TIME) {
                        if (!canMove) {
                            viewPager.setCurrentItem(1);
                            canMove = true;
                        }
                    }
                }
            }

        }

    }

    private void hideSearchView() {

        searchView.setVisibility(View.GONE);
        mSearchWaveView.stop();
        connectView.setVisibility(View.VISIBLE);
        connectingView.setVisibility(View.VISIBLE);
        mConnectWaveView.start();
    }

    //搜索界面viewPager
    private ViewPager.OnPageChangeListener getPageChangeListener() {
        if (listener == null) {
            listener = new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                }

                @Override
                public void onPageSelected(int position) {
                    if (viewPager != null && pageAdapter != null && dotViewList != null) {
                        for (int i = 0; i < dotViewList.size(); i++) {
                            if (dotViewList.get(i) != null) {
                                (dotViewList.get(i)).setImageResource(R.drawable.dot_normal);
                            }
                        }
                        if (position >= 0 && position < dotViewList.size()) {
                            if (dotViewList.get(position) != null) {
                                (dotViewList.get(position)).setImageResource(R.drawable.dot_focused);
                            }
                        }
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                }
            };
        }
        return listener;
    }

    private void setButtonTextView() {
        switch (SettingsHelper.getInt(Config.HEART_RATE_COACH_MODE, 7)) {
            case 7:
                coach_mode_btn.setText(getText(R.string.heart_rate_free_mode));
                break;
            case 6:
                coach_mode_btn.setText(getText(R.string.heart_rate_custom_mode));
                break;
            case 5:
                coach_mode_btn.setText(getText(R.string.limit_mode));
                break;
            case 4:
                coach_mode_btn.setText(getText(R.string.body_mode));
                break;
            case 3:
                coach_mode_btn.setText(getText(R.string.heart_lung_mode));
                break;
            case 2:
                coach_mode_btn.setText(getText(R.string.fat_mode));
                break;
        }
    }

    @Override
    protected void onMusicChanged() {
        super.onMusicChanged();
    }

    @Override
    protected void onMusicPlayStateChanged() {
        super.onMusicPlayStateChanged();
    }

    //region ============================= 心率服务回调 =============================
    private HeartRateService.HeartRateServiceFunction heartRateServiceFunction = new HeartRateService.HeartRateServiceFunction() {

        @Override
        public void onFirmwareVersionReceive(String firmwareVersion) {
            SettingsHelper.putString(Config.SETTING_HR_FIRMWARE_VERSION_CODE, firmwareVersion);
        }

        @Override
        public void onDeviceConnected() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {// 数据通道连接成功
                    showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);

                    hideSearchView();
                    isDataConnected = true;

                    if (isMusicConnected) {
                        getHandlerX().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startT = System.currentTimeMillis() + 5000;
                                toDetailView();
                            }
                        }, 4000L);
                    }

                }
            });
            startHeartRateService();
        }

        @Override
        public void onDeviceDisconnected() {
            Logger.e(Logger.DEBUG_TAG, "PairHeartRateConnectActivity,onDeviceDisconnected()");
            //连接断开：
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showAppMessage(R.string.activity_pair_heart_rate_disconnected, AppMsg.STYLE_ALERT);
                    isDataConnected = false;
                    mConnectWaveView.stopImmediately();
                    connectView.setVisibility(View.VISIBLE);
                    connectingView.setVisibility(View.GONE);
                    connectedView.setVisibility(View.VISIBLE);
                    shakeAnim.cancel();

                }
            });
            stopHeartRateService();
        }

        @Override
        public void onError() {
            Logger.e(Logger.DEBUG_TAG, "PairHeartConnectActivity  onError");
        }

        @Override
        public void onHRValueReceived() {
            if (heartRateService == null) return;

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int value = heartRateService.getLatestHeartRate();
                    Logger.d("TT", "PairHeartRateConnectActivity onHRValueReceived:" + value);
                    if (value == 0) {
                        heartValue.setText("--");
                        chart.addValue(100);
                    } else {
                        heartValue.setText(String.valueOf(value));
                        chart.addValue(100);
                        chart.addValue(100);
                        chart.addValue(100 + random.nextInt(100));
                        chart.addValue(100 - random.nextInt(100));
                        chart.addValue(100);
                        chart.addValue(100);
                        chart.addValue(100);
                    }
                    if (value > 0) {
                        if (tipDialog != null && tipDialog.isShowing()) {
                            tipDialog.dismiss();
                        }
                        shakeAnim.start();
                    } else {
                        shakeAnim.cancel();
                        if (isDataConnected) {
                            if (isShowDetailView) {
                                if (System.currentTimeMillis() - startT > 15000) {
                                    if (!isShowingGit) {
                                        if (tipCount < 2) {
                                            showTipDialog();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });

        }

        @Override
        public void onSignalValueReceived(boolean deviceOff, final int signalValue) {
            //不处理
        }

        @Override
        public void onHeartRateHistoryRecovery(List<HeartRateChartInfo> list) {
            //不处理
        }

        @Override
        public void reDrawHeartRateData() {
            //不处理
        }

        @Override
        public void playVoice(int latestHeartRate, int restHeartRate, int inCoachModeAllTime, int lowZoneTime,
                              int inZoneTime, int upZoneTime, int superZoneTime, boolean isNotFirstInHotMode,
                              boolean isNotFirstInFatMode, boolean isNotFirstInHeartLungMode, boolean isNotFirstInBodyMode, boolean isNotFirstInSuperMode) {
            //不处理
        }
    };

    /**
     * 绑定心率服务
     */
    private void connectToHeartRateService() {
        Intent intent = new Intent(this, HeartRateService.class);

        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                if (!name.getClassName().equals(HeartRateService.SERVICE_NAME))
                    return;
                heartRateService = ((HeartRateService.LocalBinder) service).getService();
                if (heartRateService != null) {
                    heartRateService.setIfBindWithRunMain(false);
                    heartRateService.addHeartRateServiceFunction(mPageName, heartRateServiceFunction);

                    if (heartRateService.getDevice() != null) {
                        isDataConnected = true;
                        showAppMessage(R.string.activity_pair_heart_rate_connected, AppMsg.STYLE_INFO);
                        if (isMusicConnected) {
                            getHandlerX().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    startT = System.currentTimeMillis() + 5000;
                                    toDetailView();
                                }
                            }, 4000L);
                        }
                    }
                }

            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                heartRateService = null;
            }
        };
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * 解绑心率服务
     */
    private void disconnectToHeartRateService() {
        heartRateServiceFunction = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            if (heartRateService != null) {
                heartRateService.removeHeartRateItem(mPageName);
                //释放服务运用到的相关资源
            }
        }
        if (serviceConnection != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                unbindService(serviceConnection);
            }
        }
        serviceConnection = null;
    }

    /**
     * 开启心率连接service
     */
    private void startHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "PairHeartRateActivity --->  startHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        startService(i);
    }

    /**
     * 关闭心率连接service
     */
    private void stopHeartRateService() {
        Logger.i(Logger.DEBUG_TAG, "PairHeartRateActivity --->  stopHeartRateService()");
        Intent i = new Intent(this, HeartRateService.class);
        stopService(i);
    }

    //endregion ============================= 心率服务回调 =============================

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        //不处理
    }

    @Override
    public void onPageSelected(int position) {
        //不处理
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //不处理
    }

    public void doClick(View v) {
        switch (v.getId()) {
            case R.id.btn_reConnect:
                doSearchEquipments();
                connectToHeartRateService();
                searchView.setVisibility(View.VISIBLE);
                connectingView.setVisibility(View.GONE);
                mSearchWaveView.start();
                detailView.setVisibility(View.GONE);
                break;

            case R.id.heart_rest_hr_view:
                Intent intent2 = new Intent(this, HeartRateActivity.class);
                startActivity(intent2);
                break;

            case R.id.btn_coach_mode:
                Intent intent3 = new Intent(this, HeartRateCoachModeActivity.class);
                startActivityForResult(intent3, 2);
                break;

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case Config.REQUEST_ENABLE_BLUETOOTH:
                if (RESULT_OK == resultCode) {
                    searchHREquipments();
                    showDeviceScanningDialog(getFilterUUID());
                } else if (RESULT_CANCELED == resultCode) {
                    if (!FitmixUtil.isBLEEnabled(this)) {
                        finish();
                    }
                }
                break;
            case Config.REQUEST_ENABLE_GPS:
                if (FitmixUtil.isGpsEnable(this)) {//开了GPS
                    doSearchEquipments();
//                    showDeviceScanningDialog(getFilterUUID());
                    return;
                }
                //GPS开启失败
                Toast.makeText(this, getString(R.string.heart_rate_ble_must_with_gps), Toast.LENGTH_SHORT).show();
                break;
            case 1:
                if (Activity.RESULT_OK == resultCode) {
                    HeartRateLightMode = data.getIntExtra("lightModeValue", -1);
                    Logger.d(Logger.DEBUG_TAG, "HeartRateLightMode:" + HeartRateLightMode);
                    sendHeartRateCmd();
                }

                break;
        }
    }

}
