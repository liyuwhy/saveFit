package com.fitmix.sdk.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.base.MyConfig;
import com.fitmix.sdk.bean.Topic;
import com.fitmix.sdk.bean.TopicAnswer;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.TopicAnswerList;
import com.fitmix.sdk.model.api.bean.TopicAnswerMessage;
import com.fitmix.sdk.model.api.bean.TopicDiscussMessage;
import com.fitmix.sdk.model.api.bean.TopicList;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.DiscoverDataManager;
import com.fitmix.sdk.view.adapter.MyTopicAnswerAdapter;
import com.fitmix.sdk.view.adapter.MyTopicQuestionAdapter;
import com.fitmix.sdk.view.adapter.ViewPagerAdapter;
import com.fitmix.sdk.view.animation.ZoomOutPageTransformer;
import com.fitmix.sdk.view.widget.NewVPIndicator;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * 话题-我的问答界面
 */
public class MyTopicActivity extends BaseActivity implements ViewPager.OnPageChangeListener {

    private ImageView img_has_new_msg;
    private NewVPIndicator vp_indicator;
    private ViewPager vp_my_topic;

    private SwipeLoadLayout answer_swipeLayout;
    private SwipeLoadLayout.OnRefreshListener mAnswerRefreshListener;
    private SwipeLoadLayout.OnLoadMoreListener mAnswerLoadMoreListener;

    private SwipeLoadLayout question_swipeLayout;
    private SwipeLoadLayout.OnRefreshListener mQuestionRefreshListener;
    private SwipeLoadLayout.OnLoadMoreListener mQuestionLoadMoreListener;

    private int answerPageNo;
    private int questionPageNo;

    private MyTopicQuestionAdapter myTopicQuestionAdapter;
    private MyTopicAnswerAdapter myTopicAnswerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_topic);
        setPageName("MyTopicActivity");
        initToolbar();
        initViews();
        initData();
    }

    private void initData() {
        getMyAnswerList();
        getMyQuestionList();
        getNewAnswerMessage();
        getNewDiscussMessage();
    }

    @Override
    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        img_has_new_msg = (ImageView) findViewById(R.id.img_has_new_msg);

        vp_indicator = (NewVPIndicator) findViewById(R.id.vp_indicator);
        String[] titles = new String[]{getString(R.string.activity_my_topic_answer), getString(R.string.activity_my_topic_question)};
        vp_indicator.setTitles(titles);
        vp_my_topic = (ViewPager) findViewById(R.id.vp_my_topic);

        List<View> views = new ArrayList<>();
        //我的回答列表
        View answerLayout = getLayoutInflater().inflate(R.layout.activity_my_topic_answer_list, null);
        answer_swipeLayout = (SwipeLoadLayout) answerLayout.findViewById(R.id.swipe_container);
        mAnswerRefreshListener = new SwipeLoadLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                answerPageNo = 1;
                getMyAnswerList();
            }

        };
        answer_swipeLayout.setLoadMoreEnabled(true);
        answer_swipeLayout.setOnRefreshListener(mAnswerRefreshListener);
        mAnswerLoadMoreListener = new SwipeLoadLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                getMyAnswerList();
            }
        };
        answer_swipeLayout.setOnLoadMoreListener(mAnswerLoadMoreListener);
        ListView answerList = (ListView) answerLayout.findViewById(R.id.swipe_target);
        myTopicAnswerAdapter = new MyTopicAnswerAdapter(this);
        answerList.setAdapter(myTopicAnswerAdapter);
        answerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (myTopicAnswerAdapter != null && myTopicAnswerAdapter.getTopicAnswerList() != null) {
                    if (position >= 0 && position < myTopicAnswerAdapter.getTopicAnswerList().size()) {
                        TopicAnswer topicAnswer = myTopicAnswerAdapter.getTopicAnswerList().get(position);
                        if (topicAnswer != null) {
                            Topic topic = topicAnswer.getParentTheme();
                            if (topic != null) {
                                topic.setAnswerId(topicAnswer.getId());//设置我的回答ID
                            }
                            goToTopicDetailActivity(topic);
                        }
                    }
                }

            }
        });
        answer_swipeLayout.setListViewEmptyText(getString(R.string.activity_my_topic_answer_empty), ContextCompat.getColor(this, R.color.fitmix_black));
        views.add(answerLayout);

        //我的提问列表
        View questionLayout = getLayoutInflater().inflate(R.layout.activity_my_topic_question_list, null);
        question_swipeLayout = (SwipeLoadLayout) questionLayout.findViewById(R.id.swipe_container);
        mQuestionRefreshListener = new SwipeLoadLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                questionPageNo = 1;
                getMyQuestionList();
            }

        };
        question_swipeLayout.setLoadMoreEnabled(true);
        question_swipeLayout.setOnRefreshListener(mQuestionRefreshListener);
        mQuestionLoadMoreListener = new SwipeLoadLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                getMyQuestionList();
            }
        };
        question_swipeLayout.setOnLoadMoreListener(mQuestionLoadMoreListener);
        ListView questionList = (ListView) questionLayout.findViewById(R.id.swipe_target);
        myTopicQuestionAdapter = new MyTopicQuestionAdapter(this);
        questionList.setAdapter(myTopicQuestionAdapter);
        question_swipeLayout.setListViewEmptyText(getString(R.string.activity_my_topic_question_empty), ContextCompat.getColor(this, R.color.fitmix_black));
        questionList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (myTopicQuestionAdapter != null && myTopicQuestionAdapter.getTopicList() != null) {
                    if (position >= 0 && position < myTopicQuestionAdapter.getTopicList().size()) {
                        Topic topic = myTopicQuestionAdapter.getTopicList().get(position);
                        goToTopicDetailActivity(topic);
                    }
                }
            }
        });
        views.add(questionLayout);

        ViewPagerAdapter pageAdapter = new ViewPagerAdapter(views);
        vp_my_topic.setOffscreenPageLimit(2);
        vp_my_topic.setAdapter(pageAdapter);
        vp_my_topic.setPageTransformer(true, new ZoomOutPageTransformer());//设置切换效果 DepthPageTransformer在部分机子造成列表不能滑动
        //vp_my_topic.addOnPageChangeListener(this);
        vp_indicator.setViewPager(vp_my_topic);

    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        switch (requestId) {
            case Config.MODULE_COMPETITION + 9://获取我的回答列表
                Logger.i(Logger.DATA_FLOW_TAG, "获取我的回答列表:" + result);
                TopicAnswerList topicAnswerList = JsonHelper.getObject(result, TopicAnswerList.class);
                List<TopicAnswer> answerList = new ArrayList<>();
                if (topicAnswerList != null && topicAnswerList.getPage() != null) {
                    answerList.addAll(topicAnswerList.getPage().getResult());
                }
                showAnswerList(answerList, answerPageNo);
                if (answerList.size() > 0) answerPageNo++;
                break;

            case Config.MODULE_COMPETITION + 10://获取我的提问列表
                Logger.i(Logger.DATA_FLOW_TAG, "获取我的提问列表:" + result);
                TopicList topicList = JsonHelper.getObject(result, TopicList.class);
                List<Topic> list = new ArrayList<>();
                if (topicList != null && topicList.getPage() != null) {
                    list.addAll(topicList.getPage().getResult());
                }
                showTopicList(list, questionPageNo);
                if (list.size() > 0) questionPageNo++;
                break;

            case Config.MODULE_COMPETITION + 18://获取与自己相关的最新话题回答消息
                Logger.i(Logger.DATA_FLOW_TAG, "获取与自己相关的最新话题回答消息:" + result);
                TopicAnswerMessage topicAnswerMessage = JsonHelper.getObject(result, TopicAnswerMessage.class);
                if (topicAnswerMessage != null && topicAnswerMessage.getThemes() != null) {
                    if (topicAnswerMessage.getThemes().size() > 0) {
                        if (img_has_new_msg != null) {
                            img_has_new_msg.setVisibility(View.VISIBLE);
                        }
                    }
                }
                break;

            case Config.MODULE_COMPETITION + 19://获取与自己相关的最新话题讨论消息
                Logger.i(Logger.DATA_FLOW_TAG, "获取与自己相关的最新话题讨论消息:" + result);
                TopicDiscussMessage topicDiscussMessage = JsonHelper.getObject(result, TopicDiscussMessage.class);
                if (topicDiscussMessage != null && topicDiscussMessage.getDiscuss() != null) {
                    if (topicDiscussMessage.getDiscuss().size() > 0) {
                        if (img_has_new_msg != null) {
                            img_has_new_msg.setVisibility(View.VISIBLE);
                        }
                    }
                }
                break;
        }
    }

    public void doClick(View view) {
        switch (view.getId()) {
            case R.id.btn_view_my_topic_msg:
                Intent intent = new Intent(this, TopicMessageActivity.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        //不处理
    }

    @Override
    public void onPageSelected(int position) {
        //不处理
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //不处理
    }

    /**
     * 获取我的答案列表
     */
    private void getMyAnswerList() {
        int requestId = DiscoverDataManager.getInstance().getMyAnswerList(answerPageNo, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取我的问题列表
     */
    private void getMyQuestionList() {
        int requestId = DiscoverDataManager.getInstance().getMyQuestionList(questionPageNo, true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取有关话题最新回答消息
     */
    private void getNewAnswerMessage() {
        int requestId = DiscoverDataManager.getInstance().getNewAnswerMessage(true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 获取最新讨论的相关消息
     */
    private void getNewDiscussMessage() {
        int requestId = DiscoverDataManager.getInstance().getNewDiscussMessage(true);
        registerDataReqStatusListener(requestId);
    }

    /**
     * 跳转至话题详情界面
     */
    private void goToTopicDetailActivity(Topic topic) {
        if (topic != null) {
            Intent intent = new Intent(this, TopicDetailActivity.class);
            intent.putExtra("topicId", topic.getId());
            MyConfig.getInstance().getMemExchange().setTopic(topic);
            startActivity(intent);
        }
    }

    /**
     * 展示我的提问列表
     */
    public void showTopicList(List<Topic> list, int index) {
        if (list == null || list.size() < 1) {
            if (question_swipeLayout != null) {
                if (question_swipeLayout.isLoadingMore()) {
                    question_swipeLayout.setLoadingNothing();
                }
                if (question_swipeLayout.isRefreshing()) {
                    question_swipeLayout.setRefreshing(false);
                }
            }
            return;
        } else {
            if (question_swipeLayout != null) {
                question_swipeLayout.setLoadMoreEnabled(true);//当有数据的时候才可以上拉加载
                if (question_swipeLayout.isLoadingMore())
                    question_swipeLayout.setLoadingMore(false);
                if (question_swipeLayout.isRefreshing())
                    question_swipeLayout.setRefreshing(false);
            }
        }
        if (index < 2) {
            if (myTopicQuestionAdapter != null)
                myTopicQuestionAdapter.setTopicList(list);
        } else {
            if (myTopicQuestionAdapter != null) {
                myTopicQuestionAdapter.getTopicList().addAll(list);
                myTopicQuestionAdapter.notifyDataSetChanged();
            }
        }
    }

    /**
     * 展示我的回答列表
     */
    public void showAnswerList(List<TopicAnswer> list, int index) {
        if (list == null || list.size() < 1) {
            if (answer_swipeLayout != null) {
                if (answer_swipeLayout.isLoadingMore()) {
                    answer_swipeLayout.setLoadingNothing();
                }
                if (answer_swipeLayout.isRefreshing()) {
                    answer_swipeLayout.setRefreshing(false);
                }
            }
            return;
        } else {
            if (answer_swipeLayout != null) {
                answer_swipeLayout.setLoadMoreEnabled(true);//当有数据的时候才可以上拉加载
                if (answer_swipeLayout.isLoadingMore())
                    answer_swipeLayout.setLoadingMore(false);
                if (answer_swipeLayout.isRefreshing())
                    answer_swipeLayout.setRefreshing(false);
            }
        }
        if (index < 2) {
            if (myTopicAnswerAdapter != null)
                myTopicAnswerAdapter.setTopicAnswerList(list);
        } else {
            if (myTopicAnswerAdapter != null) {
                myTopicAnswerAdapter.getTopicAnswerList().addAll(list);
                myTopicAnswerAdapter.notifyDataSetChanged();
            }
        }

    }
}
