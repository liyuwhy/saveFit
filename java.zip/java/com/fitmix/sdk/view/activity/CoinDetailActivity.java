package com.fitmix.sdk.view.activity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.fitmix.sdk.Config;
import com.fitmix.sdk.R;
import com.fitmix.sdk.bean.CoinRecord;
import com.fitmix.sdk.common.JsonHelper;
import com.fitmix.sdk.common.Logger;
import com.fitmix.sdk.model.api.bean.AccountFlow;
import com.fitmix.sdk.model.api.bean.BaseBean;
import com.fitmix.sdk.model.api.bean.CoinReward;
import com.fitmix.sdk.model.database.DataReqStatus;
import com.fitmix.sdk.model.manager.UserDataManager;
import com.fitmix.sdk.view.adapter.CoinDetailAdapter;
import com.fitmix.sdk.view.widget.AppMsg;
import com.fitmix.sdk.view.widget.swiperefresh.SwipeLoadLayout;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * 金币明细记录界面
 */
public class CoinDetailActivity extends BaseActivity {

    private SwipeLoadLayout swipeLayout;
    private ListView list_coin_detail;
    private List<CoinRecord> tempRecords;//用于存储所有
    private List<CoinRecord> coinRecords;
    private CoinDetailAdapter adapter;

    private int pageNo = 1; //分页加载
    private boolean isLastPage;//是否为最后一页

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_detail);
        setPageName("CoinDetailActivity");
        initToolbar();
        initViews();
        getCoinRecords(pageNo);
    }

    protected void initViews() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.toolbar_back);
        }
        swipeLayout = (SwipeLoadLayout) findViewById(R.id.swipe_container);
        swipeLayout.setLoadMoreEnabled(false);
        swipeLayout.setOnLoadMoreListener(new SwipeLoadLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                getCoinRecords(pageNo);
            }
        });

        //当为最后一页 不可以上拉加载
        if (isLastPage) {
            swipeLayout.setLoadMoreEnabled(false);
        }

        list_coin_detail = (ListView) findViewById(R.id.swipe_target);
        TextView emptyView = (TextView) findViewById(R.id.tv_empty_view);
        list_coin_detail.setEmptyView(emptyView);

        tempRecords = new ArrayList<>();
        coinRecords = new ArrayList<>();
        adapter = new CoinDetailAdapter(this, coinRecords);
        list_coin_detail.setAdapter(adapter);

    }

//    @Override
//    protected void requestingCountChang(int requestingCount) {
//        //不处理
//    }

    @Override
    protected void dataUpdateNotify(int requestId) {
        getDataReqStatusAsync(requestId);
    }

    @Override
    protected void getDataReqStatusNotify(DataReqStatus dataReqResult) {
        if (dataReqResult == null) return;
        int requestId = dataReqResult.getRequestId();
        String result = dataReqResult.getResult();
        Logger.i(Logger.DEBUG_TAG, "CoinDetailActivity-->getDataReqStatusNotify requestId:" + requestId + " result:" + result);
        switch (requestId) {
            case Config.MODULE_USER + 51://获取用户金币记录
                hideLoadingDialog();
                stopLoading();
                AccountFlow accountFlow = JsonHelper.getObject(result, AccountFlow.class);
                if (accountFlow != null) {
                    AccountFlow.PageEntity pageEntity = accountFlow.getPage();
                    if (pageEntity != null) {
                        isLastPage = pageEntity.isIsLastPage();
                        List<CoinReward> recordEntities = pageEntity.getList();
                        refreshDataSet(recordEntities);
                        if (isLastPage) {
                            stopLoadNothing();
                        }
                    }
                } else {
                    stopLoadError();
                }
                break;
        }
    }

    @Override
    protected void processReqError(int requestId, String error) {
        switch (requestId) {
            case Config.MODULE_USER + 51://获取用户金币记录
                hideLoadingDialog();
                BaseBean bean = JsonHelper.getObject(error, BaseBean.class);
                if (bean != null) {
                    if (bean.getCode() < 1000) {
                        super.processReqError(requestId, error);
                    } else {
                        showAppMessage(bean.getMsg(), AppMsg.STYLE_ALERT);
                    }
                }
                stopLoadError();
                break;
        }
    }

    /**
     * 获取金币记录明细
     *
     * @param pageNo 记录页码,>=1
     */
    private void getCoinRecords(int pageNo) {
        int uid = UserDataManager.getUid();
        int requestId = UserDataManager.getInstance().getUserCoinRecord(uid, pageNo, true);
        registerDataReqStatusListener(requestId);
        showLoadingDialog(R.string.activity_coin_detail_loading, 500);
    }

    /**
     * 刷新列表数据源
     */
    private void refreshDataSet(List<CoinReward> recordEntities) {
        if (recordEntities == null || recordEntities.size() == 0) {
            stopLoadNothing();
            return;
        }
        pageNo++;//指示下一页
        if (tempRecords.size() <= 0) {
            for (CoinReward entity : recordEntities) {
                tempRecords.add(new CoinRecord(entity.getAddTime(), entity.getDescription(), entity.getCoin(), entity.getFlowType()));
            }
        } else {
            for (CoinReward entity : recordEntities) {
                boolean add = true;
                for (int i = 0; i < tempRecords.size(); i++) {
                    if (entity.getAddTime() == tempRecords.get(i).time) {
                        add = false;
                    }
                }

                if (add) {
                    tempRecords.add(new CoinRecord(entity.getAddTime(), entity.getDescription(), entity.getCoin(), entity.getFlowType()));
                }
            }

        }

        if (tempRecords.size() > 0) {
            coinRecords.clear();

            Calendar calendar = Calendar.getInstance();
            int oldTime = 0;
            int tempTime;
            CoinRecord coinRecord;
            for (int i = 0; i < tempRecords.size(); i++) {
                coinRecord = tempRecords.get(i);
                calendar.setTimeInMillis(coinRecord.time);
                tempTime = calendar.get(Calendar.YEAR) * 12 + calendar.get(Calendar.MONTH);
                if (oldTime != tempTime) {
                    oldTime = tempTime;
                    coinRecords.add(new CoinRecord(coinRecord.time, "", 0, 0, 1));//添加一个月份
                    coinRecords.add(new CoinRecord(coinRecord.time, coinRecord.description, coinRecord.quantity, coinRecord.type));
                } else {
                    coinRecords.add(new CoinRecord(coinRecord.time, coinRecord.description, coinRecord.quantity, coinRecord.type));
                }

            }
        } else {
            stopLoadError();
        }
        adapter.notifyDataSetChanged();
    }


    /**
     * 显示加载完成
     */
    public void stopLoading() {
        if (swipeLayout != null) {
            swipeLayout.setLoadMoreEnabled(true);//当列表内有数据的时候才可以上拉加载
            swipeLayout.setLoadingMore(false);
        }
    }

    /**
     * 显示没有更多
     */
    public void stopLoadNothing() {
        if (swipeLayout != null)
            swipeLayout.setLoadingNothing();
    }

    /**
     * 显示加载失败
     */
    public void stopLoadError() {
        if (swipeLayout != null)
            swipeLayout.setLoadingError();
    }

}
